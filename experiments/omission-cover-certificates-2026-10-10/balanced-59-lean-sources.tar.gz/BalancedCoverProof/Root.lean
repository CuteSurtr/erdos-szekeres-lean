import BalancedCoverProof.Part00000
import BalancedCoverProof.Part00001
import BalancedCoverProof.Part00002
import BalancedCoverProof.Part00003
import BalancedCoverProof.Part00004
import BalancedCoverProof.Part00005
import BalancedCoverProof.Part00006
import BalancedCoverProof.Part00007
import BalancedCoverProof.Part00008
import BalancedCoverProof.Part00009
import BalancedCoverProof.Part00010
import BalancedCoverProof.Part00011
import BalancedCoverProof.Part00012
import BalancedCoverProof.Part00013
import BalancedCoverProof.Part00014
import BalancedCoverProof.Part00015
import BalancedCoverProof.Part00016
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionBalancedCover
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
theorem node1176 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 232 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 232 ∅) : Finset (Fin 252)) ((insert 41 (insert 163 ∅)) : Finset (Fin 252))
    27 node1177 node1178
theorem node875 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 (∅ : Finset (Fin 252)) ((insert 41 (insert 163 ∅)) : Finset (Fin 252))
    232 node1175 node1176
theorem node877 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 41 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 41 ∅) : Finset (Fin 252)) ((insert 232 (insert 163 ∅)) : Finset (Fin 252))
    27 node1033 node1034
theorem node878 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 232 (insert 41 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 232 (insert 41 ∅)) : Finset (Fin 252)) ((insert 163 ∅) : Finset (Fin 252))
    27 node879 node880
theorem node876 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 41 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 41 ∅) : Finset (Fin 252)) ((insert 163 ∅) : Finset (Fin 252))
    232 node877 node878
theorem node1 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 (∅ : Finset (Fin 252)) ((insert 163 ∅) : Finset (Fin 252))
    41 node875 node876
theorem node608 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 41 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 41 (insert 163 ∅)) : Finset (Fin 252)) ((insert 88 ∅) : Finset (Fin 252))
    185 node609 node610
theorem node3 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 163 ∅) : Finset (Fin 252)) ((insert 88 ∅) : Finset (Fin 252))
    41 node607 node608
theorem node5 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 88 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 88 (insert 163 ∅)) : Finset (Fin 252)) ((insert 185 ∅) : Finset (Fin 252))
    27 node457 node458
theorem node7 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 149 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)) ((insert 149 ∅) : Finset (Fin 252))
    41 node289 node290
theorem node10 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    195 node11 node12
theorem node8 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 149 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 149 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    102 node9 node10
theorem node6 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    149 node7 node8
theorem node4 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 88 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 88 (insert 163 ∅)) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    185 node5 node6
theorem node2 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 ((insert 163 ∅) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    88 node3 node4
theorem node0 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 59 (∅ : Finset (Fin 252)) (∅ : Finset (Fin 252))
    163 node1 node2
theorem excludes_budget :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 59 := by
  rintro ⟨holes, hbool, hrows, hb⟩
  exact node0 ⟨holes, hbool, hrows, hb, by simp, by simp⟩
#print axioms excludes_budget
end OmissionBalancedCover
