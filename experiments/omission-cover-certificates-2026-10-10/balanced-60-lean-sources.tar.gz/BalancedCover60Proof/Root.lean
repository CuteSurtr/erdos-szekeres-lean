import BalancedCover60Proof.Part00000
import BalancedCover60Proof.Part00001
import BalancedCover60Proof.Part00002
import BalancedCover60Proof.Part00003
import BalancedCover60Proof.Part00004
import BalancedCover60Proof.Part00005
import BalancedCover60Proof.Part00006
import BalancedCover60Proof.Part00007
import BalancedCover60Proof.Part00008
import BalancedCover60Proof.Part00009
import BalancedCover60Proof.Part00010
import BalancedCover60Proof.Part00011
import BalancedCover60Proof.Part00012
import BalancedCover60Proof.Part00013
import BalancedCover60Proof.Part00014
import BalancedCover60Proof.Part00015
import BalancedCover60Proof.Part00016
import BalancedCover60Proof.Part00017
import BalancedCover60Proof.Part00018
import BalancedCover60Proof.Part00019
import BalancedCover60Proof.Part00020
import BalancedCover60Proof.Part00021
import BalancedCover60Proof.Part00022
import BalancedCover60Proof.Part00023
import BalancedCover60Proof.Part00024
import BalancedCover60Proof.Part00025
import BalancedCover60Proof.Part00026
import BalancedCover60Proof.Part00027
import BalancedCover60Proof.Part00028
import BalancedCover60Proof.Part00029
import BalancedCover60Proof.Part00030
import BalancedCover60Proof.Part00031
import BalancedCover60Proof.Part00032
import BalancedCover60Proof.Part00033
import BalancedCover60Proof.Part00034
import BalancedCover60Proof.Part00035
import BalancedCover60Proof.Part00036
import BalancedCover60Proof.Part00037
import BalancedCover60Proof.Part00038
import BalancedCover60Proof.Part00039
import BalancedCover60Proof.Part00040
import BalancedCover60Proof.Part00041
import BalancedCover60Proof.Part00042
import BalancedCover60Proof.Part00043
import BalancedCover60Proof.Part00044
import BalancedCover60Proof.Part00045
import BalancedCover60Proof.Part00046
import BalancedCover60Proof.Part00047
import BalancedCover60Proof.Part00048
import BalancedCover60Proof.Part00049
import BalancedCover60Proof.Part00050
import BalancedCover60Proof.Part00051
import BalancedCover60Proof.Part00052
import BalancedCover60Proof.Part00053
import BalancedCover60Proof.Part00054
import BalancedCover60Proof.Part00055
import BalancedCover60Proof.Part00056
import BalancedCover60Proof.Part00057
import BalancedCover60Proof.Part00058
import BalancedCover60Proof.Part00059
import BalancedCover60Proof.Part00060
import BalancedCover60Proof.Part00061
import BalancedCover60Proof.Part00062
import BalancedCover60Proof.Part00063
import BalancedCover60Proof.Part00064
import BalancedCover60Proof.Part00065
import BalancedCover60Proof.Part00066
import BalancedCover60Proof.Part00067
import BalancedCover60Proof.Part00068
import BalancedCover60Proof.Part00069
import BalancedCover60Proof.Part00070
import BalancedCover60Proof.Part00071
import BalancedCover60Proof.Part00072
import BalancedCover60Proof.Part00073
import BalancedCover60Proof.Part00074
import BalancedCover60Proof.Part00075
import BalancedCover60Proof.Part00076
import BalancedCover60Proof.Part00077
import BalancedCover60Proof.Part00078
import BalancedCover60Proof.Part00079
import BalancedCover60Proof.Part00080
import BalancedCover60Proof.Part00081
import BalancedCover60Proof.Part00082
import BalancedCover60Proof.Part00083
import BalancedCover60Proof.Part00084
import BalancedCover60Proof.Part00085
import BalancedCover60Proof.Part00086
import BalancedCover60Proof.Part00087
import BalancedCover60Proof.Part00088
import BalancedCover60Proof.Part00089
import BalancedCover60Proof.Part00090
import BalancedCover60Proof.Part00091
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionBalancedCover60
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
theorem node7577 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 232 (insert 51 (insert 19 (insert 163 ∅))))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 (∅ : Finset (Fin 252)) ((insert 88 (insert 232 (insert 51 (insert 19 (insert 163 ∅))))) : Finset (Fin 252))
    185 node7733 node7734
theorem node7578 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 51 (insert 19 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 ∅) : Finset (Fin 252)) ((insert 232 (insert 51 (insert 19 (insert 163 ∅)))) : Finset (Fin 252))
    185 node7579 node7580
theorem node7287 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 51 (insert 19 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 (∅ : Finset (Fin 252)) ((insert 232 (insert 51 (insert 19 (insert 163 ∅)))) : Finset (Fin 252))
    88 node7577 node7578
theorem node7289 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 232 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 51 (insert 19 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 232 ∅) : Finset (Fin 252)) ((insert 88 (insert 51 (insert 19 (insert 163 ∅)))) : Finset (Fin 252))
    185 node7437 node7438
theorem node7290 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 232 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 19 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 232 ∅)) : Finset (Fin 252)) ((insert 51 (insert 19 (insert 163 ∅))) : Finset (Fin 252))
    185 node7291 node7292
theorem node7288 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 232 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 19 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 232 ∅) : Finset (Fin 252)) ((insert 51 (insert 19 (insert 163 ∅))) : Finset (Fin 252))
    88 node7289 node7290
theorem node6261 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 19 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 (∅ : Finset (Fin 252)) ((insert 51 (insert 19 (insert 163 ∅))) : Finset (Fin 252))
    232 node7287 node7288
theorem node7013 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 (insert 232 (insert 88 (insert 19 (insert 163 ∅))))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 ∅) : Finset (Fin 252)) ((insert 185 (insert 232 (insert 88 (insert 19 (insert 163 ∅))))) : Finset (Fin 252))
    233 node7159 node7160
theorem node7014 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 51 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 88 (insert 19 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 51 ∅)) : Finset (Fin 252)) ((insert 232 (insert 88 (insert 19 (insert 163 ∅)))) : Finset (Fin 252))
    233 node7015 node7016
theorem node6773 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 88 (insert 19 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 ∅) : Finset (Fin 252)) ((insert 232 (insert 88 (insert 19 (insert 163 ∅)))) : Finset (Fin 252))
    185 node7013 node7014
theorem node6774 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 232 (insert 51 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 19 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 232 (insert 51 ∅)) : Finset (Fin 252)) ((insert 88 (insert 19 (insert 163 ∅))) : Finset (Fin 252))
    185 node6775 node6776
theorem node6263 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 19 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 ∅) : Finset (Fin 252)) ((insert 88 (insert 19 (insert 163 ∅))) : Finset (Fin 252))
    232 node6773 node6774
theorem node6524 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 88 (insert 51 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 19 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 88 (insert 51 ∅))) : Finset (Fin 252)) ((insert 232 (insert 19 (insert 163 ∅))) : Finset (Fin 252))
    233 node6525 node6526
theorem node6265 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 51 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 19 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 51 ∅)) : Finset (Fin 252)) ((insert 232 (insert 19 (insert 163 ∅))) : Finset (Fin 252))
    185 node6523 node6524
theorem node6268 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 232 (insert 88 (insert 51 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 232 (insert 88 (insert 51 ∅)))) : Finset (Fin 252)) ((insert 19 (insert 163 ∅)) : Finset (Fin 252))
    233 node6269 node6270
theorem node6266 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 232 (insert 88 (insert 51 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 232 (insert 88 (insert 51 ∅))) : Finset (Fin 252)) ((insert 19 (insert 163 ∅)) : Finset (Fin 252))
    185 node6267 node6268
theorem node6264 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 51 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 51 ∅)) : Finset (Fin 252)) ((insert 19 (insert 163 ∅)) : Finset (Fin 252))
    232 node6265 node6266
theorem node6262 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 ∅) : Finset (Fin 252)) ((insert 19 (insert 163 ∅)) : Finset (Fin 252))
    88 node6263 node6264
theorem node4407 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 (∅ : Finset (Fin 252)) ((insert 19 (insert 163 ∅)) : Finset (Fin 252))
    51 node6261 node6262
theorem node5959 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 51 (insert 232 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 ∅) : Finset (Fin 252)) ((insert 88 (insert 51 (insert 232 (insert 163 ∅)))) : Finset (Fin 252))
    185 node6097 node6098
theorem node5960 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 19 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 232 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 19 ∅)) : Finset (Fin 252)) ((insert 51 (insert 232 (insert 163 ∅))) : Finset (Fin 252))
    185 node5961 node5962
theorem node5495 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 232 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 ∅) : Finset (Fin 252)) ((insert 51 (insert 232 (insert 163 ∅))) : Finset (Fin 252))
    88 node5959 node5960
theorem node5708 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 51 (insert 19 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 232 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 51 (insert 19 ∅))) : Finset (Fin 252)) ((insert 88 (insert 232 (insert 163 ∅))) : Finset (Fin 252))
    233 node5709 node5710
theorem node5497 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 19 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 232 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 19 ∅)) : Finset (Fin 252)) ((insert 88 (insert 232 (insert 163 ∅))) : Finset (Fin 252))
    185 node5707 node5708
theorem node5498 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 51 (insert 19 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 51 (insert 19 ∅))) : Finset (Fin 252)) ((insert 232 (insert 163 ∅)) : Finset (Fin 252))
    185 node5499 node5500
theorem node5496 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 19 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 19 ∅)) : Finset (Fin 252)) ((insert 232 (insert 163 ∅)) : Finset (Fin 252))
    88 node5497 node5498
theorem node4409 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 ∅) : Finset (Fin 252)) ((insert 232 (insert 163 ∅)) : Finset (Fin 252))
    51 node5495 node5496
theorem node5061 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 232 (insert 19 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 51 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 232 (insert 19 ∅)) : Finset (Fin 252)) ((insert 88 (insert 51 (insert 163 ∅))) : Finset (Fin 252))
    185 node5267 node5268
theorem node5062 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 232 (insert 19 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 232 (insert 19 ∅))) : Finset (Fin 252)) ((insert 51 (insert 163 ∅)) : Finset (Fin 252))
    185 node5063 node5064
theorem node4411 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 232 (insert 19 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 232 (insert 19 ∅)) : Finset (Fin 252)) ((insert 51 (insert 163 ∅)) : Finset (Fin 252))
    88 node5061 node5062
theorem node4727 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 232 (insert 19 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 232 (insert 19 ∅))) : Finset (Fin 252)) ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252))
    233 node4893 node4894
theorem node4728 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 51 (insert 232 (insert 19 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 51 (insert 232 (insert 19 ∅)))) : Finset (Fin 252)) ((insert 88 (insert 163 ∅)) : Finset (Fin 252))
    233 node4729 node4730
theorem node4413 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 232 (insert 19 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 232 (insert 19 ∅))) : Finset (Fin 252)) ((insert 88 (insert 163 ∅)) : Finset (Fin 252))
    185 node4727 node4728
theorem node4415 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 51 (insert 232 (insert 19 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 (insert 163 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 51 (insert 232 (insert 19 ∅)))) : Finset (Fin 252)) ((insert 185 (insert 163 ∅)) : Finset (Fin 252))
    233 node4571 node4572
theorem node4416 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 88 (insert 51 (insert 232 (insert 19 ∅))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 88 (insert 51 (insert 232 (insert 19 ∅))))) : Finset (Fin 252)) ((insert 163 ∅) : Finset (Fin 252))
    233 node4417 node4418
theorem node4414 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 51 (insert 232 (insert 19 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 51 (insert 232 (insert 19 ∅)))) : Finset (Fin 252)) ((insert 163 ∅) : Finset (Fin 252))
    185 node4415 node4416
theorem node4412 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 232 (insert 19 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 232 (insert 19 ∅))) : Finset (Fin 252)) ((insert 163 ∅) : Finset (Fin 252))
    88 node4413 node4414
theorem node4410 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 232 (insert 19 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 232 (insert 19 ∅)) : Finset (Fin 252)) ((insert 163 ∅) : Finset (Fin 252))
    51 node4411 node4412
theorem node4408 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 ∅) : Finset (Fin 252)) ((insert 163 ∅) : Finset (Fin 252))
    232 node4409 node4410
theorem node1 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 (∅ : Finset (Fin 252)) ((insert 163 ∅) : Finset (Fin 252))
    19 node4407 node4408
theorem node4071 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 51 (insert 19 (insert 88 ∅)))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 163 ∅) : Finset (Fin 252)) ((insert 232 (insert 51 (insert 19 (insert 88 ∅)))) : Finset (Fin 252))
    185 node4223 node4224
theorem node4072 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 232 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 19 (insert 88 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 232 (insert 163 ∅)) : Finset (Fin 252)) ((insert 51 (insert 19 (insert 88 ∅))) : Finset (Fin 252))
    185 node4073 node4074
theorem node3611 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 19 (insert 88 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 163 ∅) : Finset (Fin 252)) ((insert 51 (insert 19 (insert 88 ∅))) : Finset (Fin 252))
    232 node4071 node4072
theorem node3831 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 185 (insert 19 (insert 88 ∅)))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 163 ∅)) : Finset (Fin 252)) ((insert 232 (insert 185 (insert 19 (insert 88 ∅)))) : Finset (Fin 252))
    233 node3943 node3944
theorem node3613 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 (insert 19 (insert 88 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 163 ∅)) : Finset (Fin 252)) ((insert 185 (insert 19 (insert 88 ∅))) : Finset (Fin 252))
    232 node3831 node3832
theorem node3614 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 51 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 88 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 51 (insert 163 ∅))) : Finset (Fin 252)) ((insert 19 (insert 88 ∅)) : Finset (Fin 252))
    232 node3615 node3616
theorem node3612 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 88 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 163 ∅)) : Finset (Fin 252)) ((insert 19 (insert 88 ∅)) : Finset (Fin 252))
    185 node3613 node3614
theorem node2767 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 88 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 163 ∅) : Finset (Fin 252)) ((insert 19 (insert 88 ∅)) : Finset (Fin 252))
    51 node3611 node3612
theorem node3145 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 185 (insert 88 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 (insert 163 ∅)) : Finset (Fin 252)) ((insert 51 (insert 185 (insert 88 ∅))) : Finset (Fin 252))
    232 node3409 node3410
theorem node3148 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 232 (insert 51 (insert 19 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 (insert 88 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 232 (insert 51 (insert 19 (insert 163 ∅)))) : Finset (Fin 252)) ((insert 185 (insert 88 ∅)) : Finset (Fin 252))
    233 node3149 node3150
theorem node3146 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 19 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 (insert 88 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 19 (insert 163 ∅))) : Finset (Fin 252)) ((insert 185 (insert 88 ∅)) : Finset (Fin 252))
    232 node3147 node3148
theorem node2769 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 (insert 88 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 (insert 163 ∅)) : Finset (Fin 252)) ((insert 185 (insert 88 ∅)) : Finset (Fin 252))
    51 node3145 node3146
theorem node2771 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 19 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 88 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 19 (insert 163 ∅))) : Finset (Fin 252)) ((insert 51 (insert 88 ∅)) : Finset (Fin 252))
    232 node2973 node2974
theorem node2772 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 185 (insert 19 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 185 (insert 19 (insert 163 ∅)))) : Finset (Fin 252)) ((insert 88 ∅) : Finset (Fin 252))
    232 node2773 node2774
theorem node2770 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 19 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 19 (insert 163 ∅))) : Finset (Fin 252)) ((insert 88 ∅) : Finset (Fin 252))
    51 node2771 node2772
theorem node2768 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 (insert 163 ∅)) : Finset (Fin 252)) ((insert 88 ∅) : Finset (Fin 252))
    185 node2769 node2770
theorem node3 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 163 ∅) : Finset (Fin 252)) ((insert 88 ∅) : Finset (Fin 252))
    19 node2767 node2768
theorem node2285 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 19 (insert 185 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 163 ∅)) : Finset (Fin 252)) ((insert 51 (insert 19 (insert 185 ∅))) : Finset (Fin 252))
    232 node2561 node2562
theorem node2287 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 88 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 232 (insert 19 (insert 185 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 88 (insert 163 ∅))) : Finset (Fin 252)) ((insert 232 (insert 19 (insert 185 ∅))) : Finset (Fin 252))
    233 node2427 node2428
theorem node2288 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 232 (insert 51 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 185 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 232 (insert 51 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)) ((insert 19 (insert 185 ∅)) : Finset (Fin 252))
    233 node2289 node2290
theorem node2286 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 88 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 185 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 88 (insert 163 ∅))) : Finset (Fin 252)) ((insert 19 (insert 185 ∅)) : Finset (Fin 252))
    232 node2287 node2288
theorem node1749 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 185 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 163 ∅)) : Finset (Fin 252)) ((insert 19 (insert 185 ∅)) : Finset (Fin 252))
    51 node2285 node2286
theorem node2056 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 232 (insert 19 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 185 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 232 (insert 19 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)) ((insert 51 (insert 185 ∅)) : Finset (Fin 252))
    233 node2057 node2058
theorem node1751 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 (insert 88 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 185 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 (insert 88 (insert 163 ∅))) : Finset (Fin 252)) ((insert 51 (insert 185 ∅)) : Finset (Fin 252))
    232 node2055 node2056
theorem node1753 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 19 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 233 (insert 185 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 19 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)) ((insert 233 (insert 185 ∅)) : Finset (Fin 252))
    232 node1897 node1898
theorem node1754 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 233 (insert 51 (insert 19 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 233 (insert 51 (insert 19 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)) ((insert 185 ∅) : Finset (Fin 252))
    232 node1755 node1756
theorem node1752 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 19 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 19 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)) ((insert 185 ∅) : Finset (Fin 252))
    233 node1753 node1754
theorem node1750 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 (insert 88 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 (insert 88 (insert 163 ∅))) : Finset (Fin 252)) ((insert 185 ∅) : Finset (Fin 252))
    51 node1751 node1752
theorem node5 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 185 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 163 ∅)) : Finset (Fin 252)) ((insert 185 ∅) : Finset (Fin 252))
    19 node1749 node1750
theorem node1407 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 19 (insert 149 ∅))) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)) ((insert 51 (insert 19 (insert 149 ∅))) : Finset (Fin 252))
    233 node1593 node1594
theorem node1408 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 149 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)) ((insert 19 (insert 149 ∅)) : Finset (Fin 252))
    233 node1409 node1410
theorem node1019 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 149 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)) ((insert 19 (insert 149 ∅)) : Finset (Fin 252))
    51 node1407 node1408
theorem node1021 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 233 (insert 149 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)) ((insert 233 (insert 149 ∅)) : Finset (Fin 252))
    51 node1211 node1212
theorem node1022 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 233 (insert 19 (insert 185 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 149 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 233 (insert 19 (insert 185 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)) ((insert 149 ∅) : Finset (Fin 252))
    51 node1023 node1024
theorem node1020 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 149 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)) ((insert 149 ∅) : Finset (Fin 252))
    233 node1021 node1022
theorem node7 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 149 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)) ((insert 149 ∅) : Finset (Fin 252))
    19 node1019 node1020
theorem node641 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 149 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 19 (insert 102 ∅)) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 149 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)) ((insert 19 (insert 102 ∅)) : Finset (Fin 252))
    51 node879 node880
theorem node644 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 51 (insert 19 (insert 149 (insert 185 (insert 88 (insert 163 ∅)))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 102 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 51 (insert 19 (insert 149 (insert 185 (insert 88 (insert 163 ∅)))))) : Finset (Fin 252)) ((insert 102 ∅) : Finset (Fin 252))
    233 node645 node646
theorem node642 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 19 (insert 149 (insert 185 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 102 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 19 (insert 149 (insert 185 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)) ((insert 102 ∅) : Finset (Fin 252))
    51 node643 node644
theorem node9 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 149 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 102 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 149 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)) ((insert 102 ∅) : Finset (Fin 252))
    19 node641 node642
theorem node11 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 195 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)) ((insert 195 ∅) : Finset (Fin 252))
    19 node461 node462
theorem node13 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 195 (insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅)))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ ((insert 101 ∅) : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 195 (insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅)))))) : Finset (Fin 252)) ((insert 101 ∅) : Finset (Fin 252))
    19 node305 node306
theorem node16 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 183 (insert 101 (insert 195 (insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅)))))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 183 (insert 101 (insert 195 (insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅)))))))) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    175 node17 node18
theorem node14 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 101 (insert 195 (insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅))))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 101 (insert 195 (insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅))))))) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    183 node15 node16
theorem node12 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 195 (insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅)))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 195 (insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅)))))) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    101 node13 node14
theorem node10 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 102 (insert 149 (insert 185 (insert 88 (insert 163 ∅))))) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    195 node11 node12
theorem node8 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 149 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 149 (insert 185 (insert 88 (insert 163 ∅)))) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    102 node9 node10
theorem node6 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 185 (insert 88 (insert 163 ∅))) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    149 node7 node8
theorem node4 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 88 (insert 163 ∅)) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 88 (insert 163 ∅)) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    185 node5 node6
theorem node2 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ ((insert 163 ∅) : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 ((insert 163 ∅) : Finset (Fin 252)) (∅ : Finset (Fin 252))
    88 node3 node4
theorem node0 :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 252)), holes i = 0) := by
  exact split_excludes support demand 60 (∅ : Finset (Fin 252)) (∅ : Finset (Fin 252))
    163 node1 node2
theorem excludes_budget :
    ¬ ∃ holes : Fin 252 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 60 := by
  rintro ⟨holes, hbool, hrows, hb⟩
  exact node0 ⟨holes, hbool, hrows, hb, by simp, by simp⟩
#print axioms excludes_budget
end OmissionBalancedCover60
