import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries99349 : List (Fin 2295 × ℕ) := [(892, 1)]
def cs99349 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node99349 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 55 (insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99349 support demand code
    entries99349 ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)) ((insert 69 (insert 55 (insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries99351 : List (Fin 2295 × ℕ) := [(892, 1)]
def cs99351 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node99351 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 55 (insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99351 support demand code
    entries99351 ((insert 69 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 95 (insert 55 (insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries99352 : List (Fin 2295 × ℕ) := [(4, 9), (35, 10), (77, 16), (132, 4), (469, 6), (491, 2), (572, 18), (583, 2), (587, 17), (588, 3), (643, 15), (740, 3), (778, 11), (780, 2), (782, 7), (833, 1), (834, 3), (852, 6), (865, 10), (870, 1), (884, 2), (885, 6), (886, 2), (888, 2), (890, 23), (891, 5), (894, 4), (915, 8), (916, 10), (931, 1), (933, 3), (942, 12), (943, 10), (962, 12), (964, 8), (966, 2), (971, 12), (972, 7), (973, 14), (984, 12), (985, 1), (1006, 1), (1008, 4), (1012, 3), (1021, 2), (1025, 10), (1028, 2), (1043, 4), (1075, 1), (1076, 3), (1078, 2), (1122, 5), (1123, 5), (1126, 5), (1131, 4), (1155, 1), (1171, 4), (1179, 3), (1186, 9), (1199, 7), (1212, 1), (1223, 6), (1269, 3), (1471, 4), (1488, 3), (1651, 12), (1705, 6), (1767, 11), (1770, 4), (1780, 1), (1846, 1), (2169, 3)]
def cs99352 : List ℕ := [21, 26, 11, 11, 28, 33, 9, 33, 32, 12, 26, 15, 33, 17, 32, 0, 32, 32, 33, 20, 33, 45, 20, 26, 18, 98, 32, 83, 16, 17, 32, 60, 32, 32, 15, 32, 5, 32, 16, 80, 26, 33, 32, 33, 103, 33, 45, 32, 0, 31, 32, 41, 4, 33, 32, 87, 32, 33, 25, 33, 47, 30, 19, 32, 23, 33, 32, 26, 32, 0, 75, 32, 32, 17, 33, 33, 37, 19, 66, 32, 20, 54, 33, 31, 22, 33, 32, 32, 1, 32, 32, 33, 32, 32, 32, 3, 33, 32, 32, 32, 32, 32, 14, 33, 23, 32, 30, 25, 32, 74, 33, 32, 32, 29, 32, 32, 32, 32, 32, 32, 32, 28, 32, 32, 17, 21, 32, 32, 23, 32, 22, 14, 33, 32, 32, 32, 32, 19, 32, 32, 32, 24, 24, 32, 32, 23, 30, 29, 27, 32, 32, 24, 30, 25]
theorem node99352 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 69 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99352 support demand code
    entries99352 ((insert 95 (insert 69 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 55 (insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
theorem node99350 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 55 (insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154))
    95 node99351 node99352
theorem node99347 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)) ((insert 55 (insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154))
    69 node99349 node99350
def entries99348 : List (Fin 2295 × ℕ) := [(4, 93), (77, 163), (132, 43), (275, 18), (469, 23), (479, 16), (491, 117), (572, 115), (579, 113), (581, 12), (585, 100), (587, 127), (588, 12), (730, 24), (740, 33), (741, 27), (776, 10), (777, 56), (782, 47), (783, 18), (798, 8), (834, 22), (844, 18), (852, 78), (870, 66), (884, 51), (888, 28), (892, 50), (894, 25), (915, 120), (919, 39), (920, 33), (921, 46), (926, 116), (949, 74), (961, 10), (962, 72), (964, 46), (971, 54), (972, 72), (973, 128), (984, 101), (1009, 27), (1011, 3), (1012, 24), (1025, 27), (1069, 8), (1073, 42), (1075, 14), (1076, 6), (1077, 8), (1108, 6), (1119, 24), (1126, 14), (1128, 16), (1154, 18), (1155, 54), (1170, 52), (1171, 14), (1174, 24), (1175, 32), (1179, 27), (1212, 56), (1263, 4), (1273, 2), (1279, 32), (1281, 18), (1403, 6), (1417, 27), (1471, 109), (1488, 13), (1516, 1), (1556, 12), (1572, 23), (1594, 41), (1630, 4), (1651, 112), (1770, 71), (1851, 8), (2169, 15)]
def cs99348 : List ℕ := [107, 219, 18, 18, 187, 256, 117, 256, 138, 112, 163, 256, 255, 41, 256, 41, 256, 248, 256, 184, 256, 454, 139, 206, 185, 647, 255, 786, 204, 0, 256, 833, 385, 255, 168, 241, 0, 256, 208, 684, 178, 256, 256, 256, 710, 256, 507, 255, 28, 256, 256, 648, 217, 256, 255, 104, 257, 255, 233, 255, 604, 255, 209, 256, 149, 256, 263, 254, 256, 256, 499, 256, 256, 255, 255, 256, 312, 207, 705, 255, 237, 366, 254, 195, 186, 179, 257, 257, 56, 255, 255, 256, 255, 255, 256, 255, 256, 258, 256, 256, 255, 256, 90, 255, 252, 248, 204, 234, 256, 500, 256, 256, 256, 165, 256, 255, 256, 256, 256, 256, 256, 174, 218, 210, 199, 222, 256, 256, 197, 256, 255, 237, 256, 256, 256, 257, 256, 256, 256, 256, 256, 256, 242, 249, 256, 256, 246, 256, 256, 238, 238, 243, 256, 240]
theorem node99348 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99348 support demand code
    entries99348 ((insert 55 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node99345 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)) ((insert 32 (insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154))
    55 node99347 node99348
def entries99346 : List (Fin 2295 × ℕ) := [(4, 138), (77, 118), (132, 37), (181, 33), (469, 12), (471, 41), (482, 30), (491, 136), (572, 100), (579, 29), (583, 45), (585, 30), (629, 45), (679, 33), (730, 15), (731, 54), (740, 60), (741, 43), (782, 50), (784, 10), (834, 57), (852, 83), (856, 49), (870, 12), (884, 38), (885, 87), (888, 53), (891, 54), (892, 157), (894, 20), (898, 42), (915, 153), (919, 21), (920, 1), (921, 12), (926, 55), (931, 1), (943, 21), (949, 21), (953, 52), (961, 15), (962, 72), (964, 23), (971, 62), (972, 68), (973, 130), (984, 76), (985, 14), (1006, 25), (1008, 22), (1009, 27), (1012, 32), (1025, 50), (1043, 2), (1073, 20), (1075, 11), (1076, 13), (1119, 29), (1120, 2), (1123, 17), (1126, 45), (1144, 12), (1155, 45), (1171, 35), (1174, 10), (1175, 25), (1178, 1), (1179, 45), (1186, 29), (1212, 52), (1263, 4), (1281, 24), (1329, 54), (1471, 125), (1488, 31), (1556, 16), (1572, 5), (1770, 96), (2169, 42)]
def cs99346 : List ℕ := [120, 246, 65, 78, 221, 175, 136, 256, 196, 0, 118, 238, 257, 54, 256, 0, 257, 246, 257, 153, 256, 464, 75, 257, 161, 688, 256, 857, 118, 45, 257, 623, 55, 256, 131, 240, 54, 256, 151, 710, 142, 257, 157, 246, 848, 257, 493, 256, 69, 225, 257, 497, 256, 256, 257, 257, 256, 256, 243, 256, 561, 256, 256, 256, 158, 257, 256, 298, 256, 256, 453, 257, 256, 177, 257, 257, 485, 203, 571, 256, 255, 539, 256, 135, 199, 138, 258, 256, 36, 256, 255, 252, 256, 256, 248, 258, 256, 257, 256, 256, 257, 255, 113, 256, 246, 203, 227, 256, 257, 507, 255, 256, 256, 189, 182, 253, 257, 256, 256, 257, 256, 189, 208, 257, 183, 217, 256, 257, 141, 258, 184, 165, 257, 256, 258, 257, 257, 187, 255, 256, 257, 257, 195, 256, 256, 223, 256, 256, 251, 256, 244, 237, 256, 256]
theorem node99346 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 32 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99346 support demand code
    entries99346 ((insert 32 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node99335 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154))
    32 node99345 node99346
def entries99343 : List (Fin 2295 × ℕ) := [(4, 40), (37, 12), (72, 3), (77, 38), (275, 1), (485, 12), (491, 56), (497, 48), (506, 16), (540, 12), (572, 5), (587, 17), (629, 27), (679, 9), (731, 7), (738, 2), (740, 32), (782, 37), (813, 22), (834, 1), (835, 5), (847, 26), (852, 42), (853, 7), (870, 15), (873, 19), (884, 53), (892, 63), (894, 53), (920, 11), (924, 2), (926, 52), (931, 30), (944, 3), (949, 34), (953, 14), (957, 17), (961, 11), (962, 37), (963, 18), (964, 2), (966, 6), (971, 4), (972, 22), (973, 52), (982, 2), (984, 34), (1006, 7), (1011, 12), (1013, 8), (1025, 10), (1043, 20), (1073, 15), (1075, 4), (1077, 2), (1082, 9), (1089, 10), (1090, 4), (1123, 11), (1138, 14), (1155, 14), (1171, 18), (1183, 4), (1186, 29), (1188, 3), (1234, 19), (1410, 10), (1417, 18), (1488, 11), (1497, 3), (1546, 1), (1556, 14), (1630, 7), (1701, 13), (1770, 32), (2169, 1)]
def cs99343 : List ℕ := [32, 72, 26, 0, 82, 63, 56, 100, 100, 16, 41, 71, 99, 19, 93, 0, 65, 87, 100, 17, 100, 116, 17, 100, 18, 263, 100, 237, 41, 27, 100, 25, 100, 100, 65, 47, 0, 100, 88, 108, 35, 88, 76, 94, 267, 100, 170, 155, 36, 100, 101, 201, 100, 100, 100, 100, 100, 100, 99, 100, 292, 100, 98, 99, 66, 99, 99, 74, 100, 99, 164, 185, 99, 99, 100, 100, 176, 81, 267, 100, 50, 332, 99, 95, 63, 46, 100, 100, 47, 100, 99, 100, 102, 198, 100, 99, 100, 101, 98, 100, 101, 100, 40, 99, 81, 100, 96, 84, 100, 218, 100, 99, 99, 82, 98, 100, 99, 99, 100, 99, 100, 99, 77, 99, 98, 80, 100, 98, 98, 99, 86, 63, 99, 100, 99, 99, 100, 76, 99, 99, 99, 99, 66, 99, 98, 85, 83, 85, 99, 99, 85, 99, 99, 99]
theorem node99343 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 93 (insert 47 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99343 support demand code
    entries99343 ((insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 71 (insert 93 (insert 47 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries99344 : List (Fin 2295 × ℕ) := [(4, 127), (37, 84), (72, 30), (77, 66), (132, 52), (275, 48), (465, 8), (485, 77), (491, 134), (497, 7), (498, 38), (506, 61), (540, 32), (572, 112), (587, 57), (629, 16), (631, 49), (679, 25), (731, 29), (736, 41), (740, 116), (777, 12), (779, 6), (781, 22), (782, 104), (783, 17), (798, 5), (834, 19), (847, 60), (852, 106), (853, 46), (870, 39), (884, 108), (885, 19), (892, 192), (894, 138), (926, 14), (931, 35), (934, 17), (942, 27), (943, 30), (949, 43), (950, 39), (955, 27), (962, 7), (963, 61), (964, 29), (967, 4), (968, 90), (969, 1), (971, 34), (972, 73), (973, 139), (984, 61), (985, 6), (1002, 40), (1006, 33), (1011, 11), (1012, 32), (1025, 39), (1043, 55), (1072, 10), (1073, 17), (1076, 13), (1082, 46), (1090, 16), (1108, 10), (1123, 21), (1155, 21), (1171, 22), (1178, 10), (1184, 10), (1185, 16), (1186, 80), (1234, 22), (1417, 27), (1488, 48), (1499, 36), (1545, 2), (1767, 40), (1770, 49), (1780, 3), (1852, 11), (2169, 21)]
def cs99344 : List ℕ := [89, 176, 100, 40, 233, 256, 134, 255, 256, 61, 96, 173, 257, 0, 255, 0, 256, 255, 256, 196, 255, 330, 57, 256, 61, 770, 257, 659, 132, 65, 255, 21, 257, 255, 195, 256, 36, 256, 227, 274, 252, 257, 221, 211, 652, 256, 504, 314, 51, 237, 255, 727, 228, 256, 255, 256, 256, 255, 185, 256, 519, 254, 256, 255, 163, 257, 255, 167, 256, 255, 505, 21, 257, 255, 255, 257, 263, 195, 678, 257, 236, 626, 256, 257, 255, 92, 119, 256, 177, 256, 256, 249, 256, 572, 240, 256, 255, 256, 255, 257, 257, 256, 255, 256, 180, 256, 191, 208, 257, 595, 256, 255, 254, 255, 173, 257, 257, 256, 255, 256, 256, 256, 256, 257, 191, 194, 256, 256, 143, 256, 203, 179, 256, 256, 257, 256, 255, 176, 256, 256, 257, 256, 181, 256, 256, 193, 236, 245, 250, 241, 213, 256, 256, 256]
theorem node99344 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 47 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99344 support demand code
    entries99344 ((insert 71 (insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 47 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node99341 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 47 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 93 (insert 47 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154))
    71 node99343 node99344
def entries99342 : List (Fin 2295 × ℕ) := [(4, 28), (77, 44), (92, 3), (302, 15), (485, 11), (491, 55), (497, 48), (506, 23), (540, 24), (572, 11), (587, 16), (588, 3), (629, 25), (679, 32), (730, 12), (731, 15), (739, 16), (741, 26), (776, 2), (777, 15), (783, 13), (847, 31), (852, 49), (853, 17), (856, 1), (870, 24), (873, 6), (884, 55), (892, 57), (894, 41), (920, 8), (925, 10), (926, 37), (942, 2), (943, 1), (949, 16), (950, 7), (953, 16), (955, 9), (957, 10), (961, 16), (962, 31), (964, 13), (966, 12), (971, 18), (972, 16), (973, 55), (984, 20), (985, 8), (1006, 12), (1008, 6), (1011, 13), (1012, 3), (1025, 7), (1073, 4), (1075, 2), (1082, 6), (1089, 7), (1090, 11), (1108, 10), (1119, 9), (1121, 1), (1123, 15), (1138, 14), (1139, 2), (1155, 11), (1170, 2), (1171, 22), (1175, 3), (1177, 13), (1179, 16), (1185, 5), (1186, 22), (1273, 6), (1400, 3), (1417, 7), (1645, 7), (1770, 20)]
def cs99342 : List ℕ := [20, 48, 31, 0, 77, 49, 55, 100, 76, 23, 44, 79, 100, 9, 96, 0, 66, 72, 100, 11, 99, 98, 19, 100, 23, 248, 100, 224, 51, 25, 99, 8, 100, 101, 71, 66, 7, 99, 76, 100, 33, 99, 75, 87, 241, 100, 184, 159, 27, 93, 99, 195, 99, 100, 101, 101, 100, 100, 94, 101, 237, 92, 99, 101, 74, 101, 100, 60, 99, 101, 130, 100, 100, 100, 101, 101, 153, 48, 233, 98, 94, 164, 89, 71, 70, 75, 88, 100, 16, 99, 100, 99, 101, 0, 100, 102, 100, 69, 101, 88, 100, 99, 93, 100, 72, 30, 100, 99, 101, 215, 99, 100, 102, 68, 100, 73, 100, 100, 99, 101, 101, 100, 101, 100, 61, 91, 100, 100, 90, 101, 81, 73, 99, 99, 101, 100, 100, 82, 99, 99, 100, 100, 69, 100, 100, 98, 97, 100, 98, 99, 100, 100, 100, 99]
theorem node99342 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99342 support demand code
    entries99342 ((insert 93 (insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node99337 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 47 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154))
    93 node99341 node99342
def entries99339 : List (Fin 2295 × ℕ) := [(4, 144), (37, 52), (72, 7), (77, 88), (92, 5), (99, 147), (132, 34), (275, 86), (484, 18), (491, 144), (498, 60), (514, 19), (540, 18), (572, 43), (731, 14), (736, 2), (737, 44), (738, 39), (740, 94), (779, 3), (780, 20), (783, 45), (784, 26), (834, 21), (835, 5), (847, 104), (852, 77), (853, 80), (870, 37), (873, 13), (884, 134), (885, 10), (888, 47), (892, 203), (894, 155), (922, 28), (926, 22), (931, 17), (933, 19), (949, 76), (955, 20), (962, 74), (964, 45), (966, 57), (968, 29), (971, 61), (972, 27), (973, 148), (984, 49), (985, 10), (1006, 42), (1011, 41), (1012, 8), (1025, 56), (1043, 17), (1069, 4), (1073, 7), (1075, 17), (1077, 7), (1089, 29), (1090, 30), (1123, 42), (1131, 2), (1155, 3), (1170, 6), (1171, 29), (1176, 1), (1178, 11), (1179, 3), (1185, 29), (1186, 72), (1277, 3), (1316, 6), (1320, 2), (1400, 23), (1417, 24), (1488, 39), (1605, 39), (1705, 5), (1866, 75)]
def cs99339 : List ℕ := [75, 144, 104, 75, 221, 150, 219, 256, 256, 0, 114, 256, 256, 165, 257, 0, 215, 256, 442, 142, 256, 358, 0, 256, 0, 822, 250, 803, 95, 0, 256, 28, 201, 256, 184, 255, 0, 256, 147, 259, 113, 257, 163, 234, 812, 255, 481, 0, 53, 255, 256, 376, 183, 256, 256, 255, 256, 256, 213, 254, 326, 256, 230, 224, 226, 254, 256, 175, 256, 256, 365, 256, 256, 82, 255, 254, 530, 160, 648, 255, 143, 598, 257, 75, 233, 143, 255, 255, 47, 256, 257, 256, 256, 254, 175, 255, 256, 255, 255, 256, 254, 256, 249, 255, 199, 188, 196, 237, 255, 509, 256, 256, 256, 198, 255, 255, 254, 255, 256, 255, 255, 159, 255, 254, 204, 225, 255, 255, 136, 255, 204, 155, 255, 256, 254, 254, 255, 216, 256, 255, 255, 255, 212, 255, 255, 198, 212, 256, 256, 252, 256, 255, 255, 255]
theorem node99339 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99339 support demand code
    entries99339 ((insert 47 (insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries99340 : List (Fin 2295 × ℕ) := [(4, 50), (37, 6), (72, 1), (77, 40), (132, 1), (275, 6), (468, 5), (491, 76), (498, 35), (514, 5), (572, 19), (640, 3), (691, 23), (730, 13), (731, 36), (740, 16), (777, 2), (782, 7), (783, 9), (834, 1), (844, 13), (852, 9), (870, 19), (884, 59), (888, 21), (892, 50), (894, 49), (926, 44), (931, 10), (932, 7), (934, 6), (942, 22), (949, 34), (953, 1), (961, 1), (962, 26), (963, 2), (964, 19), (966, 14), (971, 17), (972, 19), (973, 51), (984, 34), (1006, 15), (1009, 6), (1011, 9), (1012, 5), (1025, 13), (1043, 7), (1073, 11), (1077, 2), (1082, 4), (1089, 4), (1090, 4), (1123, 3), (1126, 9), (1139, 12), (1155, 14), (1170, 4), (1171, 14), (1174, 4), (1175, 12), (1178, 6), (1179, 14), (1186, 20), (1198, 9), (1212, 11), (1277, 4), (1320, 4), (1400, 16), (1485, 5), (1488, 12), (1546, 4), (1556, 11), (1701, 18), (1780, 5), (2169, 2)]
def cs99340 : List ℕ := [22, 55, 0, 9, 68, 6, 76, 27, 100, 0, 55, 100, 69, 9, 100, 0, 70, 91, 0, 46, 99, 108, 0, 100, 0, 231, 40, 196, 41, 9, 99, 20, 50, 99, 16, 100, 0, 81, 47, 66, 43, 72, 81, 99, 150, 100, 124, 0, 49, 100, 101, 105, 81, 99, 100, 101, 100, 100, 51, 98, 171, 101, 100, 81, 88, 100, 101, 49, 100, 101, 160, 100, 99, 49, 100, 99, 145, 73, 269, 100, 91, 225, 98, 24, 91, 75, 74, 99, 33, 99, 98, 99, 100, 99, 80, 101, 99, 100, 101, 99, 100, 99, 61, 100, 102, 99, 73, 96, 100, 208, 100, 99, 100, 78, 100, 99, 100, 100, 100, 100, 100, 93, 96, 99, 59, 90, 100, 100, 80, 101, 84, 71, 100, 100, 100, 100, 101, 77, 99, 100, 100, 101, 75, 99, 101, 94, 89, 99, 100, 100, 99, 100, 100, 100]
theorem node99340 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 47 (insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99340 support demand code
    entries99340 ((insert 18 (insert 47 (insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node99338 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    18 node99339 node99340
theorem node99336 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    47 node99337 node99338
theorem node99311 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)) ((insert 39 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    31 node99335 node99336
def entries99331 : List (Fin 2295 × ℕ) := [(892, 1)]
def cs99331 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node99331 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 55 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99331 support demand code
    entries99331 ((insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 69 (insert 55 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries99333 : List (Fin 2295 × ℕ) := [(892, 1)]
def cs99333 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node99333 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 55 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99333 support demand code
    entries99333 ((insert 69 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 95 (insert 55 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries99334 : List (Fin 2295 × ℕ) := [(4, 26), (20, 6), (35, 33), (43, 7), (77, 44), (86, 1), (132, 5), (302, 45), (468, 8), (479, 25), (485, 1), (506, 76), (514, 12), (572, 24), (587, 34), (588, 17), (679, 17), (778, 49), (782, 24), (834, 3), (844, 37), (855, 24), (865, 13), (884, 14), (886, 11), (890, 74), (891, 49), (894, 9), (926, 2), (940, 6), (942, 42), (943, 38), (949, 6), (950, 23), (955, 3), (962, 48), (964, 20), (966, 14), (971, 21), (972, 19), (973, 46), (984, 39), (1008, 14), (1012, 10), (1021, 14), (1025, 35), (1043, 11), (1065, 6), (1078, 10), (1098, 4), (1120, 1), (1122, 2), (1123, 27), (1126, 5), (1161, 1), (1162, 6), (1169, 2), (1173, 9), (1186, 34), (1198, 5), (1212, 11), (1223, 12), (1241, 2), (1320, 2), (1356, 4), (1398, 2), (1488, 24), (1641, 3), (1657, 18), (1705, 5), (1846, 6), (1851, 12)]
def cs99334 : List ℕ := [72, 52, 4, 11, 90, 58, 7, 100, 100, 76, 74, 39, 100, 48, 100, 0, 81, 100, 100, 24, 100, 148, 51, 100, 76, 275, 101, 157, 44, 51, 100, 30, 130, 100, 13, 79, 52, 100, 61, 0, 99, 100, 101, 100, 173, 100, 141, 145, 0, 70, 99, 152, 16, 100, 101, 261, 101, 100, 100, 100, 211, 72, 65, 100, 94, 100, 112, 14, 99, 0, 286, 99, 100, 57, 101, 101, 97, 53, 199, 99, 44, 187, 100, 84, 57, 101, 76, 101, 0, 100, 99, 101, 100, 100, 100, 2, 101, 101, 100, 100, 99, 101, 65, 100, 60, 101, 88, 75, 100, 238, 101, 104, 100, 96, 100, 94, 100, 99, 101, 101, 94, 100, 100, 100, 64, 71, 101, 100, 67, 100, 80, 48, 101, 100, 99, 84, 101, 61, 100, 100, 100, 88, 75, 100, 98, 65, 79, 98, 94, 100, 99, 92, 99, 93]
theorem node99334 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 69 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99334 support demand code
    entries99334 ((insert 95 (insert 69 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 55 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node99332 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 55 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154))
    95 node99333 node99334
theorem node99325 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 55 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154))
    69 node99331 node99332
def entries99329 : List (Fin 2295 × ℕ) := [(164, 1)]
def cs99329 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node99329 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 69 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99329 support demand code
    entries99329 ((insert 55 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 95 (insert 69 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries99330 : List (Fin 2295 × ℕ) := [(4, 7), (37, 2), (72, 5), (77, 17), (146, 2), (302, 3), (359, 1), (468, 2), (491, 15), (506, 32), (585, 10), (587, 11), (588, 6), (621, 11), (731, 7), (741, 6), (777, 4), (782, 4), (783, 2), (819, 1), (844, 5), (852, 2), (884, 15), (894, 13), (925, 4), (926, 14), (932, 5), (942, 7), (949, 6), (950, 11), (957, 5), (962, 13), (964, 10), (966, 1), (972, 6), (973, 15), (984, 9), (1006, 4), (1008, 5), (1011, 2), (1012, 5), (1025, 7), (1069, 2), (1073, 3), (1075, 1), (1077, 2), (1090, 2), (1108, 3), (1120, 3), (1121, 3), (1123, 4), (1126, 2), (1138, 5), (1154, 6), (1171, 8), (1185, 4), (1186, 9), (1223, 7), (1227, 1), (1263, 10), (1273, 1), (1320, 2), (1400, 2), (1409, 10), (1488, 1), (1549, 2), (1630, 3), (1641, 2), (1657, 3), (1846, 1), (2187, 3)]
def cs99330 : List ℕ := [15, 12, 0, 0, 19, 2, 15, 19, 32, 32, 22, 27, 32, 0, 32, 0, 27, 17, 32, 2, 32, 44, 17, 32, 32, 71, 32, 72, 32, 0, 32, 31, 67, 32, 0, 27, 12, 32, 28, 0, 28, 32, 32, 33, 27, 32, 71, 66, 11, 23, 33, 83, 31, 32, 32, 9, 32, 32, 32, 32, 105, 33, 23, 32, 27, 26, 32, 18, 33, 50, 58, 33, 32, 32, 33, 32, 17, 32, 91, 31, 17, 51, 32, 22, 23, 16, 21, 32, 5, 32, 32, 31, 33, 31, 32, 3, 32, 31, 31, 32, 32, 31, 24, 32, 22, 22, 31, 32, 32, 64, 32, 32, 33, 32, 31, 26, 32, 32, 32, 32, 32, 32, 32, 31, 31, 27, 31, 31, 27, 32, 32, 15, 31, 31, 32, 33, 32, 19, 32, 32, 32, 24, 19, 32, 32, 21, 28, 31, 31, 32, 25, 24, 32, 29]
theorem node99330 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 55 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99330 support demand code
    entries99330 ((insert 95 (insert 55 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
theorem node99327 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154))
    95 node99329 node99330
def entries99328 : List (Fin 2295 × ℕ) := [(4, 19), (37, 5), (77, 56), (275, 34), (302, 6), (465, 2), (479, 31), (491, 40), (506, 100), (579, 15), (587, 60), (679, 11), (740, 31), (782, 8), (783, 17), (798, 5), (813, 4), (835, 17), (844, 50), (852, 13), (884, 44), (894, 30), (926, 45), (942, 7), (949, 28), (950, 22), (955, 11), (956, 22), (957, 11), (961, 12), (962, 39), (964, 17), (966, 16), (972, 14), (973, 47), (984, 35), (985, 3), (1012, 15), (1025, 4), (1072, 10), (1073, 14), (1082, 2), (1086, 6), (1089, 3), (1095, 9), (1123, 14), (1139, 12), (1154, 16), (1170, 12), (1172, 10), (1173, 23), (1174, 3), (1175, 24), (1179, 1), (1186, 12), (1212, 10), (1223, 6), (1249, 10), (1263, 44), (1273, 14), (1316, 4), (1488, 3), (1516, 5), (1641, 6), (1660, 13), (1851, 5)]
def cs99328 : List ℕ := [56, 19, 0, 0, 69, 5, 40, 100, 74, 100, 56, 46, 100, 0, 75, 0, 50, 69, 100, 5, 96, 89, 60, 100, 100, 224, 100, 129, 56, 0, 100, 90, 239, 100, 60, 94, 6, 100, 72, 0, 81, 100, 100, 100, 109, 100, 145, 171, 0, 50, 101, 259, 84, 100, 101, 8, 100, 100, 60, 100, 270, 85, 94, 100, 85, 100, 101, 74, 101, 0, 202, 100, 99, 71, 100, 100, 103, 89, 266, 92, 17, 147, 101, 99, 66, 64, 86, 100, 27, 86, 100, 100, 100, 101, 99, 101, 101, 101, 99, 101, 100, 101, 84, 99, 94, 101, 56, 85, 102, 244, 100, 101, 99, 65, 100, 102, 100, 99, 100, 102, 92, 101, 93, 100, 100, 97, 91, 101, 74, 100, 101, 101, 100, 102, 100, 100, 101, 83, 100, 101, 100, 96, 92, 93, 99, 86, 95, 101, 94, 95, 94, 93, 100, 83]
theorem node99328 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 55 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99328 support demand code
    entries99328 ((insert 69 (insert 55 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node99326 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154))
    69 node99327 node99328
theorem node99317 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 47 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154))
    55 node99325 node99326
def entries99321 : List (Fin 2295 × ℕ) := [(164, 1)]
def cs99321 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node99321 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 69 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99321 support demand code
    entries99321 ((insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 95 (insert 69 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries99323 : List (Fin 2295 × ℕ) := [(892, 1)]
def cs99323 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node99323 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 69 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99323 support demand code
    entries99323 ((insert 95 (insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 55 (insert 69 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries99324 : List (Fin 2295 × ℕ) := [(4, 16), (21, 5), (37, 9), (77, 16), (484, 3), (491, 18), (581, 11), (585, 10), (617, 4), (618, 1), (621, 16), (731, 5), (741, 4), (777, 5), (779, 1), (780, 6), (782, 4), (784, 2), (844, 8), (852, 5), (873, 16), (884, 17), (886, 1), (888, 6), (894, 21), (925, 8), (926, 5), (932, 8), (933, 2), (942, 1), (949, 5), (950, 10), (955, 3), (962, 3), (964, 9), (966, 1), (971, 7), (972, 5), (973, 17), (984, 10), (985, 1), (1006, 5), (1012, 4), (1025, 8), (1043, 3), (1070, 1), (1073, 3), (1077, 4), (1089, 4), (1120, 1), (1122, 2), (1123, 2), (1126, 3), (1133, 1), (1158, 2), (1171, 2), (1184, 3), (1185, 3), (1186, 12), (1263, 5), (1400, 6), (1469, 7), (1488, 2), (1545, 1), (1705, 7), (1861, 5), (1866, 1), (1886, 6)]
def cs99324 : List ℕ := [14, 16, 0, 11, 27, 12, 19, 25, 30, 0, 21, 24, 33, 16, 32, 0, 26, 30, 30, 21, 32, 53, 0, 32, 0, 81, 32, 100, 23, 0, 32, 32, 22, 31, 0, 32, 7, 32, 25, 0, 28, 32, 18, 33, 42, 31, 88, 0, 12, 28, 32, 42, 32, 33, 31, 17, 33, 33, 33, 32, 59, 32, 22, 33, 24, 30, 32, 25, 32, 60, 45, 32, 32, 22, 29, 32, 28, 30, 93, 27, 27, 51, 32, 12, 24, 15, 32, 32, 8, 32, 33, 32, 32, 33, 21, 3, 32, 32, 31, 32, 32, 31, 26, 31, 27, 30, 32, 32, 31, 51, 32, 32, 32, 32, 32, 32, 32, 32, 32, 31, 32, 26, 32, 32, 19, 24, 32, 32, 22, 32, 26, 19, 32, 31, 33, 28, 32, 21, 32, 32, 30, 22, 27, 32, 32, 30, 32, 32, 29, 31, 32, 32, 32, 32]
theorem node99324 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 95 (insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99324 support demand code
    entries99324 ((insert 55 (insert 95 (insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
theorem node99322 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 95 (insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154))
    55 node99323 node99324
theorem node99319 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154))
    95 node99321 node99322
def entries99320 : List (Fin 2295 × ℕ) := [(4, 87), (37, 73), (77, 169), (135, 9), (215, 2), (275, 40), (302, 4), (475, 21), (479, 67), (491, 144), (507, 47), (572, 51), (579, 51), (583, 31), (740, 24), (741, 23), (778, 82), (783, 29), (798, 33), (834, 66), (844, 98), (852, 32), (855, 43), (873, 97), (884, 87), (886, 57), (888, 27), (892, 27), (894, 129), (926, 45), (932, 55), (942, 41), (949, 35), (950, 26), (955, 54), (957, 19), (962, 67), (964, 40), (968, 19), (971, 56), (972, 55), (973, 120), (984, 98), (985, 19), (1009, 18), (1012, 8), (1021, 4), (1025, 32), (1043, 42), (1072, 33), (1073, 12), (1082, 6), (1089, 20), (1123, 24), (1138, 29), (1139, 29), (1154, 12), (1155, 10), (1162, 11), (1170, 39), (1172, 5), (1173, 4), (1174, 40), (1175, 18), (1178, 26), (1179, 21), (1186, 52), (1212, 39), (1241, 11), (1263, 46), (1273, 13), (1516, 22), (1660, 11), (1780, 13), (1807, 34), (1861, 14), (2169, 19)]
def cs99320 : List ℕ := [112, 87, 0, 35, 220, 150, 144, 245, 240, 81, 183, 179, 256, 131, 256, 0, 201, 185, 256, 151, 256, 284, 0, 257, 81, 781, 256, 442, 169, 0, 256, 257, 201, 256, 67, 257, 0, 256, 242, 19, 257, 256, 144, 256, 389, 256, 417, 34, 0, 203, 256, 375, 257, 211, 256, 255, 256, 257, 144, 257, 414, 205, 250, 240, 199, 256, 256, 202, 255, 27, 391, 256, 257, 19, 256, 255, 368, 191, 612, 255, 78, 329, 256, 158, 164, 150, 255, 255, 132, 255, 255, 256, 255, 254, 242, 254, 255, 254, 256, 255, 254, 256, 209, 256, 255, 254, 160, 222, 255, 568, 255, 256, 256, 210, 255, 254, 256, 256, 255, 255, 210, 251, 256, 254, 255, 212, 255, 255, 159, 255, 236, 244, 255, 255, 254, 255, 256, 233, 254, 255, 255, 255, 247, 235, 255, 208, 233, 255, 243, 255, 255, 255, 255, 245]
theorem node99320 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99320 support demand code
    entries99320 ((insert 69 (insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node99318 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    69 node99319 node99320
theorem node99313 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 32 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    47 node99317 node99318
def entries99315 : List (Fin 2295 × ℕ) := [(4, 76), (37, 50), (72, 20), (77, 114), (86, 4), (302, 13), (479, 68), (491, 161), (494, 12), (528, 87), (583, 19), (629, 47), (639, 30), (679, 71), (731, 91), (740, 93), (741, 11), (778, 43), (782, 31), (834, 31), (844, 50), (852, 67), (855, 48), (856, 51), (873, 118), (884, 91), (886, 38), (892, 162), (894, 104), (902, 2), (920, 8), (926, 28), (931, 11), (932, 103), (942, 57), (943, 51), (949, 76), (950, 43), (955, 25), (961, 19), (962, 72), (964, 34), (966, 17), (971, 67), (972, 16), (973, 132), (984, 65), (985, 35), (1008, 11), (1009, 30), (1011, 4), (1012, 17), (1021, 7), (1025, 22), (1043, 26), (1061, 4), (1069, 23), (1072, 19), (1073, 43), (1075, 30), (1082, 11), (1089, 5), (1090, 14), (1108, 18), (1122, 17), (1123, 28), (1139, 57), (1154, 14), (1171, 16), (1174, 15), (1175, 9), (1184, 17), (1185, 22), (1186, 93), (1263, 61), (1273, 10), (1488, 8), (1516, 4), (1556, 20), (1572, 12), (1657, 45), (1778, 3), (1780, 11), (1851, 19), (2169, 9)]
def cs99315 : List ℕ := [95, 121, 0, 0, 256, 149, 161, 245, 232, 0, 134, 210, 255, 208, 255, 0, 174, 175, 256, 50, 256, 349, 0, 256, 0, 699, 256, 510, 134, 47, 256, 256, 28, 256, 24, 256, 0, 256, 255, 17, 256, 256, 212, 256, 536, 218, 541, 256, 91, 256, 256, 417, 256, 201, 256, 388, 256, 255, 256, 432, 517, 182, 256, 255, 194, 257, 256, 129, 257, 256, 516, 257, 256, 209, 256, 256, 460, 248, 644, 256, 162, 626, 255, 154, 184, 92, 256, 257, 138, 257, 256, 257, 257, 257, 197, 255, 256, 257, 257, 256, 256, 257, 256, 256, 185, 256, 177, 245, 256, 511, 256, 257, 257, 256, 257, 256, 257, 256, 255, 255, 256, 257, 255, 256, 210, 189, 255, 256, 162, 255, 223, 160, 256, 257, 256, 257, 255, 162, 257, 257, 257, 202, 187, 257, 257, 184, 224, 257, 205, 256, 256, 234, 256, 257]
theorem node99315 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 32 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99315 support demand code
    entries99315 ((insert 32 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 59 (insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries99316 : List (Fin 2295 × ℕ) := [(4, 33), (72, 22), (77, 24), (86, 31), (181, 6), (468, 26), (491, 31), (572, 9), (579, 13), (585, 14), (629, 2), (679, 41), (731, 13), (740, 9), (741, 4), (778, 10), (779, 9), (782, 13), (798, 15), (834, 13), (844, 36), (855, 38), (873, 27), (884, 38), (892, 39), (894, 38), (898, 15), (926, 2), (941, 2), (943, 23), (949, 13), (955, 3), (956, 12), (962, 43), (963, 3), (964, 16), (966, 16), (971, 20), (972, 14), (973, 45), (984, 32), (985, 1), (1008, 6), (1009, 8), (1012, 11), (1021, 16), (1025, 15), (1043, 7), (1061, 6), (1072, 5), (1073, 6), (1075, 6), (1089, 9), (1123, 23), (1139, 8), (1155, 6), (1161, 5), (1170, 21), (1171, 10), (1172, 1), (1174, 11), (1175, 12), (1179, 5), (1186, 21), (1212, 12), (1241, 5), (1268, 35), (1273, 10), (1309, 10), (1440, 8), (1488, 19), (1545, 1), (1556, 10), (1604, 29), (1660, 1)]
def cs99316 : List ℕ := [36, 59, 29, 0, 33, 38, 31, 91, 33, 0, 54, 88, 100, 62, 87, 0, 101, 100, 100, 73, 101, 112, 21, 98, 29, 255, 100, 143, 75, 2, 100, 101, 2, 100, 24, 73, 29, 100, 87, 0, 73, 101, 62, 100, 142, 99, 141, 99, 13, 67, 66, 141, 102, 86, 99, 121, 100, 100, 63, 0, 142, 100, 93, 100, 84, 100, 101, 54, 100, 101, 100, 100, 100, 70, 101, 101, 183, 67, 180, 101, 92, 187, 101, 42, 57, 62, 99, 101, 23, 100, 100, 100, 100, 101, 100, 101, 101, 100, 100, 101, 99, 100, 95, 102, 100, 100, 95, 98, 99, 196, 100, 101, 99, 83, 101, 100, 100, 100, 101, 100, 100, 91, 88, 101, 89, 101, 100, 100, 73, 99, 96, 90, 100, 100, 99, 99, 100, 84, 99, 100, 100, 100, 93, 99, 99, 73, 83, 100, 98, 99, 98, 95, 83, 99]
theorem node99316 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 32 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99316 support demand code
    entries99316 ((insert 59 (insert 32 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node99314 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 32 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 32 (insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    59 node99315 node99316
theorem node99312 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    32 node99313 node99314
theorem node99303 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    39 node99311 node99312
def entries99309 : List (Fin 2295 × ℕ) := [(4, 29), (35, 43), (77, 11), (302, 36), (479, 42), (485, 29), (491, 19), (497, 14), (540, 15), (572, 9), (587, 15), (588, 29), (620, 9), (621, 16), (631, 1), (643, 21), (679, 55), (681, 2), (731, 17), (740, 10), (777, 4), (778, 8), (782, 33), (783, 9), (813, 1), (835, 2), (844, 30), (847, 16), (852, 12), (865, 36), (870, 27), (872, 4), (873, 21), (874, 33), (884, 39), (886, 5), (892, 17), (942, 27), (943, 34), (944, 3), (947, 3), (949, 25), (950, 9), (953, 3), (954, 12), (961, 10), (962, 43), (966, 19), (972, 14), (973, 51), (984, 23), (1006, 18), (1008, 17), (1009, 2), (1025, 22), (1033, 12), (1043, 9), (1061, 2), (1073, 2), (1076, 1), (1078, 3), (1123, 14), (1138, 1), (1155, 18), (1169, 7), (1170, 12), (1171, 10), (1174, 5), (1175, 3), (1178, 16), (1179, 4), (1186, 15), (1212, 14), (1273, 2), (1316, 15), (1395, 3), (1417, 1), (1488, 13), (1556, 4), (1630, 12), (1651, 27), (1705, 2), (1744, 2), (2169, 10)]
def cs99309 : List ℕ := [30, 29, 16, 0, 83, 99, 19, 100, 86, 27, 47, 46, 100, 101, 55, 0, 100, 86, 101, 9, 100, 17, 44, 100, 27, 261, 100, 143, 11, 44, 101, 100, 100, 100, 24, 100, 0, 100, 82, 101, 87, 100, 100, 100, 168, 100, 114, 186, 31, 101, 100, 227, 20, 101, 100, 230, 99, 102, 101, 100, 233, 93, 95, 101, 78, 100, 99, 7, 100, 101, 211, 100, 100, 101, 100, 100, 176, 93, 167, 100, 101, 227, 89, 54, 94, 77, 99, 100, 11, 100, 100, 88, 100, 100, 100, 100, 101, 100, 100, 100, 100, 100, 102, 100, 72, 87, 74, 88, 100, 210, 100, 100, 101, 67, 99, 99, 100, 100, 100, 100, 100, 79, 87, 99, 86, 100, 100, 100, 61, 100, 100, 78, 100, 100, 100, 101, 100, 91, 100, 100, 100, 100, 88, 100, 101, 79, 82, 99, 99, 95, 86, 100, 100, 100]
theorem node99309 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 47 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99309 support demand code
    entries99309 ((insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 55 (insert 47 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries99310 : List (Fin 2295 × ℕ) := [(4, 79), (72, 13), (77, 47), (181, 9), (302, 88), (469, 3), (479, 52), (485, 53), (491, 123), (497, 31), (540, 70), (571, 8), (572, 13), (587, 43), (621, 21), (629, 56), (679, 114), (681, 5), (740, 64), (741, 30), (777, 80), (782, 46), (783, 60), (813, 3), (835, 26), (844, 63), (847, 83), (852, 56), (856, 42), (870, 34), (874, 39), (884, 159), (898, 25), (919, 9), (920, 54), (926, 116), (942, 11), (943, 7), (944, 15), (949, 59), (950, 53), (956, 27), (957, 18), (961, 56), (962, 72), (963, 23), (964, 3), (966, 21), (972, 41), (973, 129), (984, 91), (1009, 20), (1012, 12), (1025, 13), (1043, 48), (1061, 2), (1072, 24), (1073, 49), (1075, 15), (1077, 1), (1082, 35), (1089, 16), (1123, 2), (1138, 4), (1139, 41), (1155, 44), (1170, 45), (1171, 13), (1174, 24), (1175, 17), (1178, 28), (1179, 9), (1182, 2), (1186, 55), (1212, 26), (1234, 11), (1268, 65), (1277, 2), (1285, 23), (1316, 34), (1488, 17), (1497, 20), (1630, 32), (1651, 43), (1831, 1), (2169, 6)]
def cs99310 : List ℕ := [63, 82, 83, 23, 187, 138, 123, 257, 133, 43, 60, 183, 255, 127, 209, 0, 255, 176, 256, 86, 256, 0, 77, 255, 69, 635, 255, 296, 60, 56, 256, 255, 255, 256, 124, 256, 0, 256, 223, 255, 226, 256, 188, 232, 308, 254, 199, 530, 43, 256, 255, 600, 224, 256, 256, 87, 255, 256, 256, 256, 742, 257, 256, 257, 180, 254, 262, 47, 255, 256, 564, 256, 256, 257, 256, 255, 327, 255, 550, 256, 256, 459, 255, 165, 123, 135, 255, 255, 43, 256, 255, 234, 257, 256, 256, 255, 239, 254, 256, 256, 256, 256, 257, 257, 225, 226, 255, 255, 256, 508, 255, 256, 257, 169, 255, 255, 255, 256, 255, 256, 256, 255, 256, 256, 256, 227, 255, 256, 254, 255, 256, 235, 255, 256, 256, 256, 244, 227, 255, 256, 255, 244, 218, 248, 256, 232, 229, 255, 225, 247, 211, 255, 255, 256]
theorem node99310 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99310 support demand code
    entries99310 ((insert 55 (insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node99305 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 47 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    55 node99309 node99310
def entries99307 : List (Fin 2295 × ℕ) := [(4, 396), (37, 224), (77, 538), (273, 49), (275, 104), (302, 219), (469, 352), (471, 129), (484, 34), (491, 506), (498, 126), (507, 128), (529, 2), (540, 12), (542, 54), (572, 206), (618, 282), (630, 24), (640, 109), (731, 417), (739, 5), (740, 126), (777, 99), (779, 95), (783, 149), (834, 97), (835, 45), (844, 286), (847, 2), (852, 89), (855, 159), (873, 355), (874, 324), (884, 462), (922, 264), (925, 41), (926, 380), (931, 194), (932, 120), (942, 119), (949, 288), (950, 217), (955, 151), (957, 16), (962, 95), (963, 29), (964, 210), (966, 47), (971, 50), (972, 206), (973, 496), (984, 279), (985, 60), (1009, 174), (1010, 1), (1043, 165), (1061, 25), (1072, 24), (1073, 328), (1075, 209), (1082, 42), (1089, 50), (1123, 109), (1126, 21), (1139, 47), (1155, 108), (1170, 112), (1171, 116), (1174, 17), (1175, 133), (1179, 43), (1184, 29), (1186, 205), (1212, 166), (1273, 25), (1296, 253), (1316, 61), (1395, 112), (1482, 136), (1485, 86), (1488, 176), (1572, 14), (1663, 16), (1859, 122), (1866, 20)]
def cs99307 : List ℕ := [428, 748, 131, 20, 485, 792, 648, 1000, 999, 128, 538, 1000, 1000, 934, 1000, 0, 1000, 702, 1880, 430, 1000, 0, 0, 963, 862, 2654, 689, 1778, 538, 160, 999, 1000, 878, 999, 152, 1000, 0, 1001, 762, 1000, 739, 1001, 506, 998, 1359, 1000, 549, 0, 417, 1000, 1001, 1481, 887, 1000, 1000, 1000, 1000, 1001, 999, 1000, 1744, 999, 809, 964, 608, 1001, 1000, 167, 999, 1000, 2109, 999, 1001, 626, 823, 999, 1319, 878, 2680, 1000, 722, 1410, 1002, 436, 999, 869, 999, 999, 464, 999, 1000, 860, 999, 1001, 889, 998, 1000, 1000, 999, 997, 999, 1000, 966, 1000, 840, 998, 474, 998, 998, 1873, 1000, 1000, 999, 990, 1000, 998, 999, 999, 1000, 999, 998, 805, 999, 999, 999, 914, 1001, 1000, 935, 1000, 999, 759, 1001, 1000, 999, 999, 941, 876, 1000, 1000, 998, 886, 853, 999, 999, 1000, 866, 1000, 1000, 1000, 890, 1000, 1000, 1000]
theorem node99307 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99307 support demand code
    entries99307 ((insert 47 (insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries99308 : List (Fin 2295 × ℕ) := [(4, 93), (35, 45), (72, 35), (77, 127), (132, 19), (479, 26), (491, 176), (498, 118), (571, 7), (572, 67), (618, 39), (620, 20), (630, 24), (730, 55), (731, 71), (740, 45), (777, 37), (778, 5), (779, 34), (783, 47), (835, 1), (844, 79), (851, 17), (852, 12), (857, 1), (870, 57), (873, 57), (884, 109), (886, 11), (888, 27), (892, 39), (915, 18), (916, 99), (919, 14), (922, 31), (926, 107), (931, 51), (942, 46), (949, 56), (950, 16), (962, 57), (963, 9), (964, 47), (966, 16), (971, 32), (972, 32), (973, 128), (984, 95), (1006, 27), (1009, 33), (1012, 1), (1025, 34), (1043, 34), (1061, 10), (1073, 34), (1075, 6), (1082, 6), (1119, 6), (1120, 8), (1123, 26), (1126, 2), (1128, 10), (1138, 15), (1139, 13), (1155, 47), (1170, 55), (1174, 42), (1175, 19), (1178, 27), (1179, 40), (1186, 22), (1212, 49), (1273, 10), (1316, 17), (1395, 9), (1482, 23), (1485, 31), (1488, 19), (1701, 35), (2169, 1)]
def cs99308 : List ℕ := [79, 93, 0, 0, 148, 45, 177, 134, 256, 0, 162, 233, 197, 102, 255, 0, 139, 230, 57, 101, 256, 39, 0, 256, 0, 668, 175, 284, 162, 92, 256, 224, 107, 256, 61, 257, 17, 224, 162, 255, 170, 256, 176, 256, 417, 256, 145, 0, 126, 255, 256, 319, 223, 257, 257, 255, 255, 233, 220, 255, 427, 257, 256, 249, 236, 257, 256, 117, 256, 256, 515, 256, 255, 173, 256, 257, 342, 198, 659, 255, 257, 373, 255, 67, 240, 230, 257, 256, 112, 256, 255, 234, 257, 256, 198, 256, 255, 256, 256, 255, 256, 256, 185, 256, 257, 256, 178, 199, 256, 495, 256, 256, 256, 211, 257, 256, 256, 256, 256, 257, 257, 210, 257, 256, 210, 243, 256, 256, 238, 256, 256, 244, 257, 256, 256, 256, 257, 256, 257, 256, 258, 256, 232, 248, 256, 256, 231, 256, 257, 251, 256, 245, 256, 256]
theorem node99308 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 47 (insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99308 support demand code
    entries99308 ((insert 18 (insert 47 (insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node99306 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    18 node99307 node99308
theorem node99304 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    47 node99305 node99306
theorem node99287 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)) ((insert 46 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    21 node99303 node99304
def entries99297 : List (Fin 2295 × ℕ) := [(4, 85), (35, 35), (70, 87), (77, 19), (302, 21), (485, 127), (491, 51), (506, 17), (571, 43), (572, 10), (587, 51), (588, 43), (631, 17), (643, 46), (679, 92), (681, 41), (731, 43), (740, 9), (778, 6), (779, 28), (782, 43), (783, 17), (813, 10), (844, 111), (857, 22), (865, 72), (870, 34), (871, 5), (872, 53), (873, 13), (874, 127), (884, 89), (886, 22), (891, 69), (916, 77), (920, 19), (931, 78), (942, 94), (943, 77), (944, 35), (949, 33), (954, 8), (961, 3), (962, 114), (964, 19), (966, 15), (971, 46), (972, 6), (973, 121), (984, 85), (1008, 34), (1009, 12), (1010, 1), (1021, 46), (1025, 56), (1033, 37), (1043, 14), (1061, 13), (1073, 10), (1122, 15), (1123, 33), (1126, 3), (1139, 5), (1154, 20), (1155, 27), (1167, 3), (1170, 31), (1171, 26), (1172, 10), (1174, 34), (1179, 30), (1186, 36), (1212, 39), (1248, 30), (1268, 23), (1273, 33), (1417, 9), (1449, 15), (1488, 31), (1546, 1), (1572, 5), (1589, 50), (1630, 20), (1651, 18), (1705, 18), (1851, 24), (2169, 30)]
def cs99297 : List ℕ := [111, 85, 0, 0, 85, 180, 73, 111, 120, 35, 178, 85, 256, 256, 191, 0, 256, 255, 256, 76, 256, 156, 94, 85, 35, 662, 256, 232, 19, 139, 256, 213, 256, 256, 44, 256, 69, 256, 222, 255, 175, 256, 257, 256, 533, 255, 0, 504, 63, 256, 255, 512, 68, 256, 256, 665, 257, 256, 256, 256, 562, 256, 241, 256, 205, 254, 255, 80, 256, 256, 558, 255, 257, 256, 233, 256, 455, 208, 468, 255, 256, 668, 256, 178, 249, 225, 255, 257, 112, 255, 255, 256, 255, 256, 257, 255, 256, 257, 255, 256, 256, 256, 256, 256, 184, 256, 212, 256, 256, 514, 255, 256, 256, 212, 242, 255, 256, 257, 256, 256, 252, 256, 242, 255, 256, 249, 257, 255, 161, 255, 255, 200, 256, 255, 256, 257, 256, 204, 256, 256, 256, 256, 204, 254, 256, 188, 238, 243, 215, 256, 255, 205, 255, 256]
theorem node99297 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99297 support demand code
    entries99297 ((insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 55 (insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries99301 : List (Fin 2295 × ℕ) := [(4, 52), (37, 17), (77, 40), (275, 16), (302, 42), (469, 14), (471, 9), (485, 16), (491, 48), (498, 24), (506, 69), (529, 34), (587, 42), (640, 1), (679, 8), (681, 6), (731, 22), (740, 31), (741, 5), (742, 1), (777, 26), (782, 29), (783, 16), (844, 26), (847, 25), (874, 35), (884, 46), (920, 25), (924, 3), (925, 6), (926, 35), (931, 1), (932, 11), (942, 9), (944, 10), (949, 33), (955, 12), (956, 1), (957, 11), (961, 21), (962, 24), (963, 13), (964, 4), (972, 22), (973, 48), (984, 40), (1006, 5), (1009, 4), (1011, 2), (1012, 10), (1025, 11), (1043, 20), (1072, 4), (1073, 22), (1075, 7), (1082, 15), (1089, 5), (1090, 2), (1123, 3), (1139, 2), (1154, 5), (1155, 12), (1170, 14), (1171, 8), (1174, 3), (1175, 11), (1179, 3), (1186, 24), (1212, 9), (1219, 16), (1268, 7), (1273, 7), (1320, 3), (1417, 8), (1488, 16), (1556, 11), (1589, 18), (1630, 10), (1651, 8), (1845, 2), (1846, 4), (1861, 5), (1866, 6), (2169, 3)]
def cs99301 : List ℕ := [37, 82, 34, 27, 52, 41, 54, 101, 93, 77, 45, 89, 101, 76, 92, 0, 100, 100, 228, 24, 101, 0, 42, 97, 100, 274, 100, 131, 40, 0, 100, 100, 206, 100, 55, 100, 0, 101, 99, 100, 61, 101, 100, 100, 122, 100, 0, 184, 32, 100, 101, 269, 72, 99, 101, 55, 99, 100, 100, 83, 300, 100, 92, 99, 67, 100, 101, 24, 100, 100, 282, 100, 96, 100, 76, 101, 131, 93, 245, 101, 90, 210, 99, 81, 83, 42, 100, 100, 26, 92, 100, 100, 101, 100, 100, 100, 101, 100, 100, 101, 101, 99, 67, 100, 90, 100, 96, 100, 101, 208, 100, 100, 99, 101, 100, 101, 101, 100, 101, 101, 101, 100, 102, 101, 99, 79, 100, 101, 100, 100, 99, 76, 100, 100, 101, 100, 101, 86, 99, 100, 99, 90, 76, 99, 100, 92, 89, 97, 99, 92, 78, 100, 100, 100]
theorem node99301 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 32 (insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99301 support demand code
    entries99301 ((insert 55 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 32 (insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries99302 : List (Fin 2295 × ℕ) := [(4, 134), (37, 23), (72, 17), (77, 43), (86, 23), (150, 7), (485, 90), (491, 176), (497, 15), (498, 83), (571, 90), (629, 23), (679, 84), (731, 3), (740, 58), (741, 24), (777, 58), (782, 39), (783, 42), (813, 14), (834, 17), (835, 2), (844, 68), (870, 22), (884, 166), (887, 19), (888, 30), (916, 122), (919, 26), (920, 52), (921, 8), (922, 19), (924, 24), (926, 104), (931, 7), (932, 49), (942, 24), (944, 23), (949, 10), (957, 1), (961, 17), (962, 74), (963, 19), (964, 22), (971, 21), (972, 59), (973, 122), (984, 108), (1009, 33), (1012, 21), (1025, 30), (1043, 41), (1061, 4), (1068, 2), (1073, 48), (1082, 13), (1123, 5), (1154, 18), (1155, 29), (1170, 54), (1173, 4), (1174, 50), (1175, 7), (1178, 25), (1179, 20), (1186, 25), (1212, 55), (1268, 5), (1273, 24), (1318, 3), (1320, 14), (1478, 8), (1488, 34), (1493, 57), (1546, 7), (1556, 14), (1572, 3), (1589, 15), (1630, 27), (1663, 26), (1845, 5), (2237, 40)]
def cs99302 : List ℕ := [68, 134, 0, 0, 134, 113, 176, 68, 255, 0, 60, 221, 256, 5, 194, 57, 256, 247, 5, 174, 244, 0, 57, 255, 57, 613, 256, 233, 60, 23, 256, 255, 275, 256, 61, 234, 57, 256, 257, 256, 151, 173, 256, 256, 321, 234, 0, 364, 70, 256, 256, 564, 223, 209, 257, 69, 256, 257, 208, 256, 654, 256, 257, 258, 186, 256, 257, 123, 256, 257, 530, 255, 257, 257, 245, 257, 297, 251, 564, 255, 257, 468, 257, 131, 182, 167, 257, 256, 113, 256, 257, 255, 255, 257, 256, 258, 257, 257, 257, 256, 255, 263, 258, 256, 258, 258, 258, 256, 256, 492, 256, 256, 256, 236, 259, 256, 257, 255, 257, 257, 255, 242, 257, 258, 250, 239, 257, 258, 230, 258, 257, 233, 258, 256, 257, 257, 257, 254, 257, 256, 257, 258, 231, 247, 257, 222, 249, 256, 257, 256, 221, 237, 257, 255]
theorem node99302 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 55 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 32 (insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99302 support demand code
    entries99302 ((insert 18 (insert 55 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 32 (insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node99299 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 32 (insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 32 (insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    18 node99301 node99302
def entries99300 : List (Fin 2295 × ℕ) := [(4, 61), (37, 10), (71, 4), (77, 7), (181, 16), (302, 27), (491, 54), (497, 12), (498, 17), (629, 17), (679, 53), (740, 32), (741, 11), (777, 6), (782, 16), (783, 1), (813, 17), (834, 5), (835, 3), (844, 21), (847, 12), (856, 28), (870, 7), (874, 23), (884, 51), (887, 5), (888, 12), (898, 9), (916, 20), (920, 30), (926, 14), (932, 14), (942, 13), (943, 27), (944, 6), (949, 19), (961, 6), (962, 30), (963, 7), (964, 3), (971, 10), (972, 26), (973, 48), (984, 40), (985, 4), (1006, 1), (1009, 8), (1010, 3), (1012, 3), (1025, 9), (1043, 22), (1061, 5), (1072, 7), (1073, 18), (1075, 11), (1077, 1), (1082, 12), (1089, 1), (1123, 8), (1138, 3), (1139, 6), (1155, 9), (1161, 2), (1170, 16), (1171, 2), (1174, 14), (1175, 1), (1178, 10), (1184, 5), (1186, 21), (1212, 15), (1217, 10), (1234, 17), (1268, 41), (1273, 8), (1320, 3), (1346, 6), (1372, 2), (1398, 1), (1488, 11), (1556, 6), (1572, 4), (1589, 6), (1630, 6), (1701, 8), (1770, 12), (1846, 1)]
def cs99300 : List ℕ := [43, 73, 22, 0, 61, 60, 54, 55, 100, 0, 11, 71, 100, 66, 68, 0, 61, 101, 100, 68, 101, 0, 25, 100, 0, 278, 100, 92, 7, 17, 101, 99, 14, 100, 49, 100, 0, 100, 99, 99, 82, 100, 87, 96, 143, 94, 0, 205, 23, 100, 81, 181, 71, 100, 100, 48, 100, 99, 73, 99, 201, 100, 100, 99, 78, 100, 108, 20, 100, 100, 205, 99, 100, 99, 76, 99, 144, 100, 185, 100, 100, 229, 99, 66, 67, 42, 100, 100, 29, 100, 99, 100, 99, 100, 100, 99, 100, 100, 99, 99, 100, 100, 98, 100, 100, 100, 100, 99, 100, 195, 100, 100, 99, 91, 100, 100, 100, 100, 99, 100, 100, 100, 100, 101, 92, 75, 100, 100, 84, 99, 84, 82, 100, 101, 100, 101, 100, 89, 100, 100, 100, 99, 85, 100, 101, 79, 97, 100, 99, 100, 85, 97, 92, 101]
theorem node99300 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 32 (insert 55 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99300 support demand code
    entries99300 ((insert 32 (insert 55 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node99298 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    32 node99299 node99300
theorem node99289 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 47 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    55 node99297 node99298
def entries99295 : List (Fin 2295 × ℕ) := [(4, 5), (77, 58), (132, 8), (236, 17), (469, 10), (491, 66), (498, 48), (527, 1), (572, 22), (643, 5), (730, 22), (731, 30), (740, 26), (780, 9), (782, 3), (783, 17), (784, 9), (834, 4), (844, 34), (847, 24), (851, 3), (855, 15), (870, 24), (873, 48), (884, 30), (885, 4), (886, 8), (888, 27), (890, 29), (892, 28), (915, 27), (916, 39), (922, 5), (926, 21), (931, 9), (932, 9), (933, 9), (942, 11), (943, 3), (944, 1), (949, 10), (962, 26), (964, 17), (971, 18), (972, 18), (973, 52), (984, 19), (985, 9), (1006, 16), (1008, 8), (1009, 7), (1010, 1), (1012, 2), (1025, 23), (1043, 7), (1061, 7), (1120, 1), (1122, 12), (1123, 8), (1125, 6), (1126, 1), (1130, 4), (1154, 1), (1155, 8), (1169, 12), (1170, 3), (1171, 6), (1174, 10), (1175, 2), (1178, 14), (1179, 12), (1186, 18), (1198, 37), (1212, 14), (1248, 16), (1273, 8), (1296, 2), (1482, 2), (1485, 14), (1488, 6), (1705, 13), (1780, 1), (2169, 12)]
def cs99295 : List ℕ := [71, 15, 24, 37, 45, 17, 66, 71, 92, 0, 95, 100, 100, 87, 100, 0, 52, 100, 99, 49, 100, 94, 0, 100, 12, 272, 100, 159, 58, 56, 100, 100, 21, 100, 36, 100, 3, 100, 58, 168, 57, 100, 70, 100, 260, 101, 57, 0, 52, 100, 101, 102, 68, 99, 101, 228, 100, 99, 100, 99, 162, 100, 100, 97, 71, 101, 101, 78, 100, 99, 232, 100, 100, 54, 87, 101, 189, 75, 231, 100, 101, 190, 100, 22, 98, 100, 101, 101, 30, 100, 101, 89, 101, 100, 69, 99, 100, 101, 100, 101, 100, 99, 61, 99, 101, 100, 76, 95, 101, 180, 99, 101, 101, 78, 100, 100, 100, 100, 100, 100, 100, 82, 101, 100, 77, 96, 100, 100, 68, 101, 88, 80, 100, 100, 100, 101, 100, 93, 100, 100, 101, 100, 88, 100, 100, 94, 100, 100, 100, 100, 99, 100, 97, 100]
theorem node99295 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 39 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99295 support demand code
    entries99295 ((insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 55 (insert 39 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries99296 : List (Fin 2295 × ℕ) := [(4, 98), (72, 21), (77, 137), (275, 12), (302, 42), (450, 18), (475, 13), (491, 166), (498, 60), (507, 27), (512, 5), (572, 63), (630, 41), (632, 8), (676, 4), (692, 3), (730, 7), (731, 101), (740, 61), (776, 59), (779, 20), (783, 63), (844, 85), (847, 106), (870, 53), (873, 12), (884, 119), (887, 18), (888, 17), (916, 72), (921, 4), (922, 38), (926, 124), (932, 48), (949, 76), (957, 23), (962, 45), (963, 34), (964, 63), (966, 7), (971, 9), (972, 47), (973, 131), (984, 91), (1009, 7), (1011, 22), (1012, 10), (1025, 18), (1042, 1), (1043, 33), (1045, 17), (1073, 45), (1075, 6), (1076, 5), (1082, 27), (1089, 9), (1090, 14), (1123, 20), (1154, 36), (1155, 3), (1170, 39), (1171, 35), (1174, 10), (1175, 30), (1178, 28), (1179, 22), (1186, 37), (1212, 31), (1248, 10), (1273, 53), (1296, 98), (1482, 14), (1485, 10), (1488, 29), (1584, 5), (1663, 6), (1701, 44), (1712, 4), (1845, 7)]
def cs99296 : List ℕ := [85, 98, 106, 13, 98, 98, 166, 191, 256, 27, 163, 232, 256, 110, 256, 0, 222, 236, 256, 98, 256, 0, 0, 256, 125, 731, 137, 375, 158, 67, 257, 256, 181, 257, 146, 256, 0, 255, 162, 428, 153, 255, 166, 256, 323, 239, 0, 4, 108, 257, 256, 334, 256, 257, 257, 62, 256, 229, 210, 257, 412, 255, 256, 255, 210, 255, 256, 95, 257, 256, 505, 256, 256, 167, 179, 255, 245, 197, 709, 258, 247, 292, 255, 85, 255, 154, 256, 257, 88, 257, 256, 254, 256, 256, 256, 234, 256, 255, 255, 257, 257, 257, 211, 255, 256, 208, 175, 186, 256, 523, 256, 257, 255, 257, 255, 258, 257, 256, 257, 256, 255, 237, 257, 255, 212, 218, 256, 256, 199, 255, 256, 211, 256, 257, 256, 256, 257, 256, 256, 257, 256, 255, 215, 257, 256, 256, 241, 257, 249, 244, 211, 257, 257, 255]
theorem node99296 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99296 support demand code
    entries99296 ((insert 55 (insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node99291 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    55 node99295 node99296
def entries99293 : List (Fin 2295 × ℕ) := [(4, 89), (37, 11), (77, 137), (86, 8), (132, 2), (146, 6), (302, 81), (350, 9), (491, 157), (498, 48), (507, 51), (571, 6), (630, 25), (640, 40), (676, 23), (731, 57), (740, 33), (779, 17), (782, 11), (783, 36), (813, 11), (834, 18), (835, 13), (844, 99), (873, 102), (874, 26), (884, 117), (887, 51), (925, 20), (926, 144), (932, 10), (942, 29), (949, 79), (950, 22), (953, 27), (956, 8), (957, 32), (962, 95), (963, 13), (964, 64), (966, 30), (972, 24), (973, 114), (984, 74), (1009, 20), (1010, 10), (1011, 17), (1012, 3), (1025, 65), (1043, 35), (1073, 36), (1082, 21), (1120, 2), (1122, 22), (1123, 21), (1126, 6), (1139, 12), (1154, 36), (1161, 28), (1169, 37), (1172, 20), (1173, 16), (1175, 14), (1178, 4), (1179, 28), (1186, 38), (1212, 40), (1263, 77), (1273, 55), (1277, 2), (1283, 47), (1313, 31), (1398, 22), (1482, 21), (1488, 32), (1516, 28), (1543, 2), (1556, 43), (1572, 12), (1701, 49)]
def cs99293 : List ℕ := [130, 89, 0, 31, 120, 42, 157, 99, 256, 51, 137, 165, 255, 175, 257, 0, 119, 233, 257, 115, 256, 77, 0, 255, 51, 597, 257, 234, 137, 46, 256, 181, 215, 256, 50, 255, 0, 257, 148, 49, 223, 255, 157, 256, 303, 258, 77, 0, 57, 257, 257, 319, 251, 236, 257, 257, 256, 241, 257, 257, 538, 256, 218, 246, 201, 258, 258, 77, 256, 256, 612, 562, 256, 103, 256, 257, 356, 194, 612, 256, 57, 507, 257, 132, 157, 198, 258, 256, 24, 256, 257, 208, 256, 257, 255, 256, 256, 257, 257, 256, 256, 255, 210, 256, 232, 256, 178, 256, 256, 569, 255, 256, 256, 246, 257, 255, 257, 255, 255, 256, 255, 257, 256, 250, 255, 237, 256, 258, 184, 256, 255, 225, 257, 256, 257, 256, 256, 231, 255, 256, 256, 256, 211, 255, 256, 226, 191, 255, 256, 208, 217, 238, 256, 249]
theorem node99293 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99293 support demand code
    entries99293 ((insert 39 (insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 71 (insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries99294 : List (Fin 2295 × ℕ) := [(4, 19), (37, 20), (77, 46), (86, 4), (132, 14), (135, 1), (302, 26), (450, 8), (491, 59), (498, 23), (529, 41), (571, 5), (572, 19), (639, 5), (640, 12), (730, 12), (731, 64), (740, 13), (777, 5), (778, 31), (779, 4), (781, 8), (782, 2), (783, 12), (798, 13), (835, 9), (844, 38), (870, 3), (873, 9), (874, 12), (884, 25), (886, 14), (922, 21), (926, 20), (932, 35), (942, 25), (943, 7), (944, 9), (949, 32), (950, 21), (955, 6), (956, 1), (963, 2), (964, 20), (966, 14), (968, 1), (971, 3), (972, 12), (973, 47), (984, 27), (985, 10), (1009, 26), (1012, 5), (1021, 16), (1043, 19), (1061, 5), (1072, 1), (1073, 21), (1075, 8), (1076, 2), (1078, 4), (1082, 5), (1122, 6), (1138, 1), (1139, 16), (1154, 2), (1155, 12), (1170, 8), (1174, 19), (1175, 12), (1178, 6), (1179, 13), (1184, 3), (1186, 14), (1212, 20), (1273, 7), (1313, 35), (1482, 3), (1485, 4), (1488, 3), (1859, 3), (2169, 1)]
def cs99294 : List ℕ := [76, 19, 0, 35, 54, 58, 62, 41, 97, 0, 46, 69, 99, 62, 100, 0, 57, 99, 100, 44, 100, 0, 0, 99, 0, 257, 33, 62, 46, 3, 100, 68, 23, 100, 31, 100, 0, 100, 66, 25, 99, 100, 75, 100, 100, 99, 0, 0, 76, 100, 99, 176, 74, 100, 100, 100, 101, 67, 90, 100, 170, 100, 101, 100, 68, 99, 100, 7, 100, 101, 256, 29, 101, 80, 100, 99, 101, 71, 256, 99, 100, 142, 101, 36, 101, 69, 99, 100, 67, 100, 100, 94, 99, 101, 64, 100, 100, 100, 100, 100, 99, 100, 99, 102, 99, 100, 63, 100, 100, 168, 100, 100, 101, 97, 99, 100, 99, 100, 100, 100, 101, 99, 99, 100, 101, 97, 100, 99, 91, 99, 92, 86, 99, 99, 98, 100, 97, 82, 99, 100, 98, 89, 84, 93, 99, 99, 94, 89, 98, 100, 99, 99, 99, 100]
theorem node99294 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 39 (insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99294 support demand code
    entries99294 ((insert 71 (insert 39 (insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))))) : Finset (Fin 154)) ((insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node99292 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    71 node99293 node99294
theorem node99290 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    39 node99291 node99292
theorem node99288 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    47 node99289 node99290
theorem node99265 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)) ((insert 70 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    46 node99287 node99288
def entries99283 : List (Fin 2295 × ℕ) := [(1, 6), (20, 12), (35, 111), (77, 57), (466, 7), (479, 46), (490, 28), (491, 64), (497, 43), (572, 18), (577, 15), (643, 33), (679, 20), (691, 59), (727, 16), (737, 20), (738, 54), (739, 3), (834, 23), (844, 56), (847, 22), (865, 74), (870, 76), (884, 105), (888, 58), (889, 17), (891, 44), (892, 135), (894, 60), (922, 32), (930, 23), (932, 19), (934, 22), (941, 62), (943, 40), (944, 49), (961, 40), (962, 77), (963, 45), (964, 18), (971, 23), (972, 48), (973, 124), (984, 47), (1006, 22), (1008, 9), (1025, 48), (1027, 61), (1033, 5), (1061, 20), (1075, 21), (1076, 28), (1111, 6), (1119, 4), (1120, 5), (1122, 46), (1123, 19), (1126, 7), (1155, 32), (1162, 4), (1167, 15), (1170, 34), (1171, 62), (1175, 14), (1178, 36), (1179, 22), (1186, 35), (1189, 90), (1212, 36), (1234, 15), (1279, 7), (1316, 35), (1342, 74), (1493, 90), (1572, 8), (1630, 27), (1648, 5), (1651, 138), (1705, 30)]
def cs99283 : List ℕ := [69, 97, 112, 12, 136, 256, 92, 234, 256, 138, 131, 182, 257, 123, 147, 90, 257, 255, 257, 76, 257, 256, 90, 193, 235, 664, 257, 769, 57, 123, 257, 256, 256, 257, 126, 122, 151, 256, 221, 457, 105, 256, 243, 257, 471, 255, 256, 468, 121, 256, 240, 425, 64, 256, 257, 622, 256, 255, 255, 255, 455, 256, 256, 256, 244, 255, 257, 75, 256, 256, 0, 256, 257, 231, 195, 256, 459, 217, 428, 256, 256, 397, 165, 202, 227, 199, 219, 257, 33, 256, 258, 196, 257, 255, 257, 256, 257, 254, 257, 257, 256, 256, 242, 257, 248, 218, 158, 217, 255, 517, 257, 274, 257, 226, 256, 233, 256, 258, 257, 256, 257, 255, 228, 257, 257, 257, 255, 256, 172, 257, 255, 187, 255, 257, 255, 257, 256, 256, 257, 257, 257, 256, 237, 257, 257, 235, 256, 257, 256, 257, 235, 245, 256, 227]
theorem node99283 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 39 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99283 support demand code
    entries99283 ((insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 55 (insert 39 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries99285 : List (Fin 2295 × ℕ) := [(1, 44), (37, 21), (77, 123), (479, 27), (490, 54), (491, 123), (497, 92), (514, 20), (629, 58), (729, 17), (730, 48), (731, 22), (739, 81), (776, 28), (777, 5), (813, 7), (819, 6), (834, 82), (847, 11), (852, 59), (856, 2), (870, 78), (884, 126), (888, 30), (892, 37), (894, 133), (919, 28), (922, 68), (925, 6), (926, 116), (931, 7), (932, 12), (944, 6), (956, 11), (961, 26), (962, 89), (963, 42), (964, 46), (971, 48), (972, 68), (973, 122), (984, 91), (1009, 2), (1010, 21), (1011, 20), (1012, 23), (1025, 43), (1043, 16), (1044, 11), (1069, 20), (1073, 34), (1075, 7), (1076, 16), (1090, 10), (1119, 5), (1123, 10), (1155, 66), (1170, 60), (1171, 29), (1175, 15), (1178, 23), (1179, 45), (1189, 107), (1212, 50), (1228, 9), (1234, 26), (1268, 21), (1316, 18), (1345, 30), (1384, 6), (1433, 11), (1485, 1), (1488, 37), (1497, 9), (1609, 45), (1630, 17), (1651, 80), (1701, 2), (1770, 7)]
def cs99285 : List ℕ := [51, 114, 118, 0, 193, 140, 177, 255, 250, 80, 143, 255, 255, 51, 230, 0, 256, 236, 256, 72, 248, 170, 0, 256, 110, 621, 255, 602, 123, 58, 255, 256, 256, 255, 140, 137, 0, 255, 232, 411, 67, 255, 149, 240, 490, 256, 256, 405, 119, 256, 254, 287, 212, 254, 255, 105, 255, 255, 255, 256, 501, 255, 255, 255, 255, 222, 255, 144, 256, 255, 0, 257, 255, 177, 254, 256, 299, 131, 624, 256, 255, 268, 256, 155, 253, 199, 256, 255, 34, 255, 256, 256, 256, 256, 256, 255, 256, 256, 257, 256, 256, 255, 256, 256, 255, 188, 257, 169, 257, 582, 256, 256, 493, 188, 249, 255, 257, 257, 256, 255, 257, 256, 254, 257, 246, 222, 255, 257, 176, 256, 247, 238, 257, 257, 256, 257, 245, 257, 257, 257, 257, 256, 257, 190, 257, 239, 215, 251, 256, 201, 236, 210, 235, 247]
theorem node99285 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 112 (insert 39 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99285 support demand code
    entries99285 ((insert 55 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 112 (insert 39 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries99286 : List (Fin 2295 × ℕ) := [(1, 5), (4, 17), (77, 23), (465, 15), (490, 6), (491, 49), (497, 28), (512, 7), (572, 20), (629, 38), (685, 6), (727, 6), (731, 14), (737, 17), (739, 10), (798, 9), (813, 5), (835, 15), (852, 28), (870, 23), (884, 38), (888, 18), (892, 32), (894, 39), (919, 8), (922, 18), (924, 17), (926, 34), (929, 12), (931, 2), (932, 5), (943, 1), (944, 13), (957, 2), (962, 24), (963, 21), (965, 14), (973, 45), (984, 40), (1006, 7), (1008, 3), (1009, 9), (1010, 3), (1011, 12), (1012, 3), (1025, 17), (1073, 10), (1076, 1), (1119, 10), (1120, 4), (1121, 11), (1123, 9), (1128, 4), (1130, 3), (1131, 8), (1139, 3), (1141, 2), (1155, 19), (1170, 16), (1171, 14), (1178, 15), (1179, 14), (1182, 7), (1186, 10), (1189, 33), (1212, 17), (1279, 22), (1342, 42), (1417, 5), (1497, 4), (1545, 2), (1572, 8), (1651, 33), (1663, 2), (1701, 19), (1705, 1), (1770, 12)]
def cs99286 : List ℕ := [17, 84, 33, 0, 78, 67, 55, 100, 78, 33, 30, 100, 100, 0, 73, 0, 100, 90, 100, 38, 101, 71, 0, 100, 55, 198, 99, 233, 23, 38, 100, 100, 97, 108, 45, 66, 0, 100, 83, 168, 27, 79, 63, 100, 204, 100, 99, 165, 56, 99, 87, 123, 91, 100, 100, 66, 99, 99, 100, 99, 158, 100, 99, 100, 100, 93, 100, 50, 98, 100, 0, 99, 99, 94, 100, 95, 118, 59, 197, 99, 100, 100, 85, 90, 56, 94, 67, 100, 14, 99, 100, 100, 99, 100, 75, 101, 99, 99, 100, 100, 99, 100, 95, 100, 101, 69, 100, 83, 99, 156, 99, 101, 0, 100, 100, 100, 99, 99, 100, 101, 100, 101, 93, 100, 99, 97, 100, 101, 99, 100, 100, 68, 100, 100, 100, 100, 84, 97, 100, 99, 99, 101, 86, 83, 100, 94, 97, 88, 100, 100, 101, 92, 98, 91]
theorem node99286 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 112 (insert 55 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99286 support demand code
    entries99286 ((insert 112 (insert 55 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node99284 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    112 node99285 node99286
theorem node99279 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    55 node99283 node99284
def entries99281 : List (Fin 2295 × ℕ) := [(4, 40), (77, 21), (215, 1), (350, 6), (466, 2), (485, 26), (491, 46), (512, 1), (587, 13), (621, 7), (629, 14), (679, 8), (728, 1), (730, 13), (738, 16), (739, 2), (776, 8), (777, 32), (845, 34), (852, 5), (856, 19), (857, 7), (874, 3), (884, 53), (888, 14), (894, 16), (922, 3), (924, 1), (926, 25), (929, 25), (931, 8), (932, 21), (941, 18), (943, 6), (944, 15), (956, 14), (961, 2), (962, 33), (963, 7), (964, 12), (966, 7), (971, 11), (972, 2), (973, 41), (984, 37), (1009, 11), (1010, 6), (1011, 20), (1012, 3), (1025, 13), (1043, 5), (1073, 10), (1075, 14), (1082, 4), (1090, 6), (1122, 9), (1123, 17), (1133, 2), (1139, 3), (1155, 3), (1158, 1), (1161, 10), (1171, 22), (1172, 9), (1175, 7), (1179, 10), (1182, 3), (1186, 14), (1212, 23), (1227, 26), (1268, 32), (1273, 14), (1316, 8), (1433, 5), (1488, 6), (1543, 9), (1572, 11), (1630, 19), (1765, 8), (1778, 7), (1779, 39), (1845, 3), (1859, 11), (1882, 15)]
def cs99281 : List ℕ := [13, 74, 0, 23, 84, 56, 64, 98, 63, 8, 22, 67, 100, 96, 61, 0, 93, 96, 100, 46, 101, 88, 13, 100, 8, 227, 99, 160, 21, 29, 100, 100, 100, 101, 16, 100, 0, 100, 99, 3, 100, 99, 80, 101, 112, 100, 100, 196, 32, 100, 86, 119, 100, 100, 99, 99, 99, 100, 99, 101, 197, 99, 100, 100, 90, 87, 99, 33, 99, 212, 0, 99, 100, 93, 100, 100, 125, 81, 208, 100, 99, 148, 101, 63, 67, 78, 95, 100, 39, 100, 100, 101, 77, 100, 100, 100, 97, 99, 100, 86, 99, 101, 74, 101, 92, 83, 101, 100, 99, 199, 101, 100, 101, 100, 100, 95, 99, 100, 100, 100, 100, 101, 99, 100, 99, 92, 100, 100, 100, 100, 99, 73, 101, 100, 99, 101, 100, 87, 101, 100, 100, 100, 76, 100, 100, 79, 96, 93, 100, 100, 100, 98, 99, 95]
theorem node99281 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99281 support demand code
    entries99281 ((insert 39 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries99282 : List (Fin 2295 × ℕ) := [(4, 20), (37, 73), (43, 5), (77, 63), (86, 55), (135, 45), (351, 3), (479, 5), (485, 32), (491, 55), (496, 54), (506, 152), (572, 28), (587, 64), (629, 72), (679, 120), (727, 37), (738, 43), (739, 14), (798, 75), (813, 46), (834, 44), (845, 152), (852, 38), (856, 2), (865, 49), (884, 104), (888, 15), (894, 99), (919, 9), (924, 8), (931, 31), (932, 3), (933, 7), (941, 52), (943, 56), (944, 14), (956, 2), (961, 66), (962, 84), (963, 53), (966, 20), (971, 63), (972, 63), (973, 128), (984, 68), (1010, 33), (1011, 33), (1012, 1), (1025, 24), (1034, 3), (1061, 16), (1069, 5), (1073, 6), (1075, 11), (1076, 19), (1090, 15), (1119, 29), (1120, 9), (1122, 31), (1123, 29), (1139, 39), (1155, 34), (1165, 7), (1169, 12), (1171, 16), (1172, 39), (1173, 50), (1175, 33), (1178, 33), (1179, 29), (1186, 31), (1212, 31), (1268, 28), (1313, 16), (1516, 4), (1543, 7), (1779, 60)]
def cs99282 : List ℕ := [16, 172, 0, 16, 139, 123, 60, 255, 163, 152, 112, 110, 256, 88, 104, 0, 181, 255, 256, 144, 256, 164, 64, 255, 152, 627, 257, 263, 63, 77, 256, 256, 256, 254, 129, 228, 0, 256, 256, 9, 216, 257, 189, 255, 376, 256, 256, 507, 0, 211, 125, 433, 229, 256, 256, 256, 255, 256, 136, 255, 387, 206, 202, 256, 236, 255, 257, 113, 255, 88, 0, 256, 256, 256, 256, 256, 326, 195, 478, 255, 200, 365, 249, 250, 126, 195, 191, 256, 67, 255, 256, 256, 256, 255, 256, 256, 257, 244, 256, 256, 255, 256, 238, 256, 211, 227, 226, 205, 255, 563, 256, 257, 256, 206, 242, 255, 256, 256, 256, 257, 256, 256, 204, 256, 255, 256, 255, 257, 255, 256, 256, 256, 257, 256, 256, 255, 256, 252, 256, 255, 256, 256, 229, 213, 256, 238, 254, 256, 256, 256, 256, 256, 219, 224]
theorem node99282 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 39 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99282 support demand code
    entries99282 ((insert 69 (insert 39 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node99280 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    69 node99281 node99282
theorem node99267 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    39 node99279 node99280
def entries99277 : List (Fin 2295 × ℕ) := [(4, 6), (37, 26), (77, 41), (92, 24), (275, 1), (474, 19), (475, 3), (482, 31), (490, 2), (491, 49), (542, 1), (572, 45), (583, 6), (617, 1), (632, 13), (730, 8), (731, 13), (736, 30), (738, 8), (739, 2), (777, 15), (834, 4), (852, 11), (870, 5), (873, 36), (884, 36), (885, 22), (888, 18), (892, 52), (894, 60), (919, 9), (922, 13), (926, 19), (943, 23), (961, 16), (962, 17), (963, 17), (967, 2), (971, 16), (972, 25), (973, 50), (984, 33), (1011, 17), (1025, 16), (1044, 4), (1069, 10), (1073, 5), (1075, 5), (1076, 1), (1078, 3), (1089, 8), (1122, 19), (1128, 2), (1131, 1), (1133, 2), (1137, 6), (1155, 1), (1170, 13), (1171, 18), (1178, 8), (1179, 15), (1186, 19), (1189, 52), (1212, 10), (1232, 8), (1273, 11), (1306, 11), (1316, 3), (1417, 3), (1485, 15), (1572, 6), (1584, 2), (1701, 12), (1705, 13), (1770, 15), (1866, 22)]
def cs99277 : List ℕ := [37, 73, 52, 44, 69, 83, 73, 100, 84, 0, 52, 100, 101, 60, 100, 0, 100, 100, 213, 89, 100, 118, 0, 59, 61, 295, 100, 319, 41, 13, 100, 101, 47, 100, 67, 99, 0, 100, 67, 189, 45, 41, 72, 101, 284, 100, 154, 0, 21, 97, 84, 72, 69, 100, 100, 125, 100, 80, 72, 100, 64, 100, 99, 80, 100, 91, 101, 60, 99, 101, 0, 100, 100, 23, 82, 91, 170, 39, 203, 100, 100, 148, 99, 56, 90, 77, 100, 100, 2, 99, 101, 100, 99, 101, 97, 100, 100, 100, 100, 95, 100, 99, 23, 100, 100, 75, 73, 72, 100, 205, 99, 100, 100, 63, 80, 100, 99, 100, 101, 99, 100, 82, 94, 100, 68, 87, 100, 100, 78, 100, 89, 73, 100, 99, 100, 100, 100, 100, 99, 99, 100, 100, 99, 100, 100, 94, 99, 100, 98, 100, 99, 100, 100, 99]
theorem node99277 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 18 (insert 21 (insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99277 support demand code
    entries99277 ((insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 18 (insert 21 (insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries99278 : List (Fin 2295 × ℕ) := [(4, 72), (37, 92), (77, 152), (86, 39), (146, 12), (164, 11), (475, 72), (479, 58), (484, 21), (491, 67), (496, 9), (512, 35), (572, 87), (581, 28), (583, 60), (585, 32), (621, 31), (730, 46), (731, 35), (736, 7), (737, 69), (738, 17), (798, 24), (834, 39), (844, 76), (852, 44), (873, 129), (884, 80), (886, 22), (888, 40), (892, 73), (894, 121), (919, 28), (922, 1), (925, 49), (926, 18), (931, 33), (943, 24), (955, 51), (961, 16), (962, 45), (963, 44), (968, 21), (971, 63), (972, 48), (973, 109), (984, 102), (985, 1), (1010, 19), (1011, 27), (1012, 16), (1025, 54), (1073, 15), (1075, 8), (1078, 6), (1089, 3), (1120, 3), (1122, 17), (1123, 29), (1131, 6), (1161, 16), (1170, 10), (1171, 37), (1172, 22), (1175, 15), (1178, 23), (1179, 31), (1186, 49), (1212, 44), (1228, 22), (1252, 10), (1273, 32), (1316, 13), (1516, 36), (1545, 7), (1572, 40), (1657, 17), (1705, 10), (1780, 16), (1859, 61)]
def cs99278 : List ℕ := [154, 89, 0, 72, 191, 174, 128, 256, 190, 0, 187, 256, 256, 129, 241, 0, 236, 216, 283, 219, 256, 325, 0, 256, 0, 661, 256, 519, 152, 0, 256, 255, 256, 256, 37, 255, 0, 256, 244, 29, 187, 256, 91, 255, 463, 256, 484, 0, 81, 256, 256, 179, 256, 254, 255, 256, 256, 181, 210, 255, 197, 257, 173, 256, 249, 211, 255, 179, 257, 256, 0, 257, 256, 134, 254, 243, 398, 177, 521, 256, 208, 231, 256, 191, 237, 199, 256, 255, 69, 256, 256, 255, 257, 256, 256, 255, 256, 257, 256, 237, 256, 255, 129, 231, 255, 256, 126, 223, 256, 522, 255, 255, 257, 244, 172, 254, 256, 256, 255, 255, 257, 203, 255, 256, 208, 214, 256, 256, 143, 256, 248, 211, 256, 256, 256, 256, 255, 219, 256, 256, 256, 256, 242, 247, 256, 222, 248, 256, 256, 255, 255, 256, 256, 256]
theorem node99278 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 21 (insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99278 support demand code
    entries99278 ((insert 39 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 18 (insert 21 (insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node99275 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 21 (insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 21 (insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    39 node99277 node99278
def entries99276 : List (Fin 2295 × ℕ) := [(4, 59), (35, 16), (37, 5), (77, 41), (132, 2), (468, 4), (490, 26), (491, 64), (512, 2), (526, 2), (572, 19), (583, 35), (677, 8), (691, 28), (731, 9), (777, 1), (834, 22), (844, 4), (873, 4), (884, 57), (885, 35), (888, 36), (892, 55), (894, 43), (915, 4), (919, 15), (922, 4), (926, 38), (931, 9), (957, 1), (961, 15), (962, 29), (963, 21), (971, 28), (972, 21), (973, 48), (984, 34), (1006, 9), (1008, 15), (1011, 9), (1012, 8), (1025, 14), (1076, 8), (1078, 3), (1120, 12), (1122, 5), (1123, 11), (1126, 7), (1155, 9), (1158, 5), (1161, 2), (1169, 2), (1170, 15), (1171, 20), (1175, 5), (1178, 6), (1179, 17), (1186, 10), (1212, 17), (1231, 5), (1249, 2), (1269, 1), (1273, 9), (1316, 3), (1360, 3), (1400, 14), (1485, 2), (1488, 5), (1572, 1), (1701, 14), (1886, 8), (1888, 19)]
def cs99276 : List ℕ := [4, 63, 0, 0, 67, 21, 90, 16, 99, 0, 43, 94, 43, 20, 100, 0, 100, 63, 4, 87, 100, 160, 0, 92, 0, 290, 86, 266, 41, 16, 100, 99, 66, 100, 5, 98, 0, 100, 46, 100, 57, 71, 64, 100, 161, 99, 176, 0, 9, 99, 101, 53, 100, 100, 99, 100, 100, 100, 14, 98, 114, 99, 100, 101, 99, 98, 99, 50, 101, 100, 14, 100, 100, 9, 81, 90, 167, 80, 217, 100, 65, 181, 101, 39, 70, 84, 65, 99, 14, 101, 100, 100, 99, 100, 100, 100, 100, 100, 100, 99, 99, 101, 24, 92, 99, 88, 61, 82, 100, 217, 101, 100, 100, 57, 80, 81, 100, 100, 100, 101, 100, 65, 72, 100, 77, 94, 100, 100, 62, 99, 90, 75, 99, 101, 99, 100, 93, 90, 101, 102, 100, 99, 101, 98, 100, 95, 93, 101, 101, 100, 101, 96, 101, 101]
theorem node99276 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99276 support demand code
    entries99276 ((insert 18 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node99273 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    18 node99275 node99276
def entries99274 : List (Fin 2295 × ℕ) := [(4, 41), (35, 24), (77, 43), (132, 4), (471, 20), (474, 3), (475, 36), (479, 24), (491, 45), (542, 15), (571, 1), (572, 28), (620, 36), (621, 2), (632, 3), (677, 4), (730, 21), (731, 17), (739, 13), (777, 11), (834, 9), (844, 24), (873, 23), (884, 37), (885, 24), (887, 12), (888, 21), (919, 11), (922, 17), (926, 26), (931, 19), (932, 5), (934, 1), (941, 5), (943, 7), (944, 9), (956, 1), (961, 8), (962, 25), (963, 24), (964, 5), (971, 17), (972, 17), (973, 49), (984, 24), (1009, 10), (1010, 10), (1011, 12), (1025, 14), (1043, 5), (1061, 9), (1076, 13), (1119, 1), (1120, 5), (1122, 7), (1123, 15), (1128, 5), (1131, 6), (1155, 12), (1169, 8), (1170, 12), (1171, 15), (1177, 9), (1178, 17), (1179, 11), (1186, 7), (1212, 17), (1273, 13), (1279, 15), (1372, 3), (1482, 11), (1485, 8), (1497, 4), (1572, 7), (1609, 2), (1663, 2), (1701, 10), (1705, 8), (1864, 1), (2033, 10)]
def cs99274 : List ℕ := [24, 56, 20, 39, 65, 39, 46, 93, 65, 0, 43, 100, 78, 50, 100, 0, 100, 65, 100, 62, 100, 0, 0, 100, 38, 256, 98, 132, 43, 39, 100, 100, 63, 100, 0, 99, 0, 100, 45, 100, 82, 80, 61, 99, 92, 99, 88, 2, 38, 96, 92, 33, 76, 100, 99, 100, 100, 72, 77, 99, 79, 100, 97, 100, 86, 99, 99, 9, 99, 98, 0, 100, 101, 49, 90, 98, 129, 100, 174, 100, 100, 105, 101, 43, 100, 95, 98, 100, 33, 100, 100, 94, 101, 101, 94, 98, 100, 74, 99, 99, 100, 101, 41, 101, 99, 100, 75, 80, 100, 200, 100, 100, 100, 69, 99, 100, 99, 100, 99, 100, 100, 83, 99, 99, 95, 100, 100, 99, 83, 98, 101, 92, 99, 100, 99, 101, 99, 99, 101, 100, 99, 99, 99, 100, 100, 99, 90, 93, 99, 99, 100, 99, 84, 98]
theorem node99274 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99274 support demand code
    entries99274 ((insert 21 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node99269 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 46 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    21 node99273 node99274
def entries99271 : List (Fin 2295 × ℕ) := [(4, 324), (37, 119), (77, 511), (86, 260), (425, 23), (466, 246), (482, 219), (484, 12), (490, 172), (491, 263), (572, 534), (630, 207), (691, 127), (731, 245), (736, 118), (738, 7), (739, 51), (777, 28), (798, 20), (834, 207), (844, 245), (849, 60), (873, 252), (874, 252), (884, 404), (885, 45), (888, 193), (922, 278), (926, 326), (931, 249), (941, 10), (943, 11), (944, 74), (962, 221), (963, 203), (964, 235), (966, 28), (971, 245), (972, 249), (973, 440), (984, 402), (1006, 33), (1008, 75), (1009, 83), (1011, 89), (1021, 125), (1025, 138), (1061, 69), (1069, 6), (1073, 67), (1119, 64), (1120, 13), (1123, 125), (1126, 22), (1128, 55), (1138, 179), (1155, 131), (1157, 64), (1158, 11), (1164, 54), (1170, 192), (1171, 127), (1175, 101), (1178, 101), (1179, 267), (1186, 116), (1191, 28), (1212, 99), (1232, 15), (1273, 13), (1281, 59), (1306, 14), (1313, 83), (1372, 20), (1482, 249), (1545, 22), (1701, 170), (1780, 136)]
def cs99271 : List ℕ := [661, 324, 59, 230, 435, 475, 435, 550, 554, 0, 525, 1000, 966, 524, 946, 0, 999, 1000, 999, 846, 999, 0, 0, 1000, 292, 2494, 999, 815, 511, 456, 999, 1000, 510, 999, 189, 999, 0, 1000, 630, 1000, 783, 910, 348, 999, 1319, 999, 0, 0, 245, 999, 662, 653, 1001, 1001, 1000, 999, 1000, 456, 545, 1000, 740, 1000, 684, 1000, 999, 956, 999, 22, 1000, 1001, 0, 999, 1000, 701, 799, 802, 1474, 798, 2108, 1000, 1000, 1442, 780, 484, 1001, 934, 1000, 999, 350, 1000, 1000, 1000, 999, 1857, 950, 1000, 696, 958, 1000, 930, 1000, 1000, 544, 1001, 1000, 1000, 700, 852, 999, 2096, 1000, 1116, 1000, 585, 1000, 1000, 999, 1000, 1000, 1000, 1001, 999, 708, 1000, 1000, 1000, 999, 1000, 881, 1000, 1000, 808, 1000, 1000, 1000, 999, 887, 1000, 1000, 999, 1000, 999, 936, 814, 1000, 1000, 999, 869, 1000, 901, 1000, 883, 922, 868]
theorem node99271 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99271 support demand code
    entries99271 ((insert 46 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries99272 : List (Fin 2295 × ℕ) := [(4, 55), (37, 61), (77, 140), (86, 40), (135, 12), (474, 12), (482, 41), (491, 128), (571, 91), (572, 54), (632, 58), (731, 42), (737, 33), (739, 38), (777, 39), (791, 31), (819, 3), (844, 53), (873, 39), (874, 4), (884, 114), (885, 60), (888, 50), (919, 9), (921, 19), (926, 58), (932, 43), (941, 48), (944, 2), (962, 39), (964, 60), (966, 57), (971, 39), (972, 65), (973, 115), (984, 96), (1004, 11), (1009, 33), (1012, 1), (1025, 3), (1061, 32), (1073, 8), (1076, 17), (1090, 1), (1102, 9), (1119, 5), (1120, 8), (1122, 16), (1123, 38), (1126, 25), (1138, 18), (1155, 9), (1157, 5), (1162, 1), (1169, 8), (1170, 47), (1171, 32), (1174, 22), (1175, 59), (1178, 5), (1179, 60), (1186, 51), (1189, 38), (1228, 8), (1231, 9), (1232, 25), (1273, 32), (1281, 29), (1304, 46), (1313, 23), (1372, 22), (1572, 17), (1663, 20), (1780, 26)]
def cs99272 : List ℕ := [105, 93, 67, 110, 116, 125, 174, 120, 177, 0, 140, 255, 204, 65, 256, 0, 256, 255, 254, 256, 256, 0, 0, 197, 128, 739, 256, 294, 140, 58, 256, 208, 58, 256, 119, 221, 0, 255, 201, 254, 188, 158, 141, 256, 253, 254, 0, 0, 42, 256, 235, 206, 238, 256, 256, 255, 256, 58, 142, 114, 229, 257, 201, 257, 256, 239, 255, 8, 255, 256, 0, 256, 256, 42, 224, 204, 339, 141, 519, 256, 185, 187, 120, 32, 236, 222, 255, 255, 133, 256, 256, 255, 257, 0, 255, 255, 183, 218, 255, 237, 255, 261, 234, 225, 256, 238, 177, 225, 255, 488, 256, 256, 256, 257, 255, 255, 255, 255, 256, 255, 256, 248, 256, 256, 129, 255, 257, 255, 251, 256, 224, 256, 256, 255, 255, 255, 253, 256, 255, 256, 254, 257, 255, 255, 255, 256, 256, 255, 255, 234, 256, 255, 227, 249]
theorem node99272 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 46 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs99272 support demand code
    entries99272 ((insert 93 (insert 46 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))))) : Finset (Fin 154)) ((insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node99270 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))))) : Finset (Fin 154)) ((insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    93 node99271 node99272
theorem node99268 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅)))))) : Finset (Fin 154)) ((insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    46 node99269 node99270
theorem node99266 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 70 (insert 36 (insert 34 (insert 67 (insert 88 ∅))))) : Finset (Fin 154)) ((insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    47 node99267 node99268
theorem node99264 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 67 (insert 88 ∅)))) : Finset (Fin 154)) ((insert 51 (insert 60 (insert 27 (insert 81 (insert 109 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    70 node99265 node99266
#print axioms node99264
end OmissionResidualCover31Fused
