import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries76355 : List (Fin 2295 × ℕ) := [(23, 251), (46, 103), (99, 328), (179, 206), (273, 12), (342, 121), (469, 12), (482, 506), (540, 139), (572, 246), (587, 253), (617, 204), (618, 70), (679, 62), (681, 320), (737, 316), (741, 122), (742, 248), (743, 22), (852, 258), (869, 108), (870, 19), (873, 55), (888, 167), (892, 553), (894, 393), (896, 447), (898, 12), (902, 12), (917, 86), (921, 11), (933, 139), (934, 166), (938, 98), (944, 67), (958, 124), (959, 6), (960, 383), (966, 106), (973, 465), (978, 93), (994, 16), (1006, 11), (1009, 72), (1011, 56), (1012, 83), (1043, 20), (1045, 11), (1049, 93), (1061, 82), (1069, 201), (1070, 90), (1073, 15), (1100, 72), (1122, 88), (1123, 206), (1152, 121), (1167, 294), (1173, 82), (1175, 78), (1186, 212), (1212, 29), (1223, 109), (1235, 133), (1261, 19), (1272, 24), (1281, 370), (1296, 15), (1297, 212), (1308, 132), (1517, 382), (1545, 299), (1554, 42), (1705, 88), (1991, 93), (2001, 50), (2061, 59), (2280, 353)]
def cs76355 : List ℕ := [479, 12, 370, 370, 618, 521, 485, 1000, 124, 0, 0, 1000, 1000, 398, 242, 0, 1000, 999, 1537, 413, 1000, 1496, 824, 645, 903, 0, 1000, 2999, 0, 662, 1000, 1000, 1000, 999, 160, 999, 0, 1000, 588, 1760, 551, 999, 794, 473, 3017, 722, 1969, 1000, 206, 718, 999, 1147, 1000, 999, 999, 1000, 999, 999, 1001, 1000, 0, 1000, 999, 651, 759, 999, 342, 2334, 895, 1000, 726, 1001, 538, 801, 999, 938, 1635, 999, 623, 1000, 999, 1703, 1000, 1000, 1000, 999, 1001, 852, 1000, 999, 1000, 779, 1620, 1607, 1000, 1001, 999, 1001, 999, 999, 1000, 999, 1000, 976, 1000, 1000, 1000, 999, 1000, 241, 933, 999, 875, 950, 1000, 1000, 1000, 1000, 1000, 664, 784, 1000, 1000, 856, 1000, 999, 1001, 1000, 1001, 1001, 1000, 837, 1001, 1000, 951, 1000, 846, 770, 1001, 1000, 889, 873, 1000, 1001, 670, 696, 948, 1000, 965, 1000, 1000, 955, 748, 918]
theorem node76355 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 18 (insert 39 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76355 support demand code
    entries76355 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 93 (insert 18 (insert 39 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries76356 : List (Fin 2295 × ℕ) := [(23, 33), (46, 20), (99, 5), (179, 13), (273, 3), (469, 7), (482, 52), (540, 15), (572, 8), (587, 20), (617, 32), (629, 2), (681, 24), (737, 31), (741, 28), (743, 24), (812, 6), (815, 4), (817, 23), (852, 13), (870, 8), (873, 13), (888, 16), (892, 67), (894, 49), (896, 10), (898, 3), (902, 7), (917, 21), (934, 19), (938, 3), (944, 14), (957, 31), (959, 3), (960, 29), (966, 16), (973, 46), (978, 7), (1007, 15), (1009, 6), (1011, 6), (1012, 18), (1041, 2), (1061, 3), (1070, 17), (1110, 2), (1111, 8), (1114, 3), (1123, 27), (1143, 10), (1167, 17), (1173, 6), (1175, 16), (1183, 2), (1186, 28), (1223, 31), (1226, 8), (1257, 1), (1281, 17), (1297, 11), (1488, 5), (1517, 37), (1572, 4), (1619, 3), (1635, 8), (1670, 9), (1705, 10), (1773, 9), (1870, 12), (1903, 4), (2258, 3), (2280, 34)]
def cs76356 : List ℕ := [48, 7, 17, 17, 77, 52, 66, 101, 31, 3, 0, 100, 100, 18, 44, 0, 100, 98, 130, 24, 100, 158, 73, 70, 79, 0, 77, 275, 0, 81, 100, 100, 100, 101, 22, 100, 0, 99, 49, 175, 27, 97, 80, 36, 302, 77, 188, 95, 33, 71, 100, 96, 99, 100, 101, 100, 98, 100, 100, 101, 0, 100, 99, 54, 100, 100, 22, 207, 99, 100, 77, 101, 95, 79, 101, 98, 169, 99, 73, 100, 100, 187, 100, 100, 99, 62, 100, 89, 101, 99, 101, 80, 168, 10, 99, 100, 100, 101, 100, 100, 100, 99, 100, 75, 91, 72, 99, 101, 71, 28, 82, 100, 99, 86, 100, 98, 100, 100, 100, 68, 61, 100, 101, 100, 100, 87, 101, 99, 101, 101, 91, 79, 100, 99, 72, 101, 72, 71, 100, 100, 74, 78, 99, 100, 80, 72, 90, 100, 93, 98, 97, 100, 84, 100]
theorem node76356 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 39 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76356 support demand code
    entries76356 ((insert 93 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 18 (insert 39 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76353 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 39 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 18 (insert 39 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    93 node76355 node76356
def entries76354 : List (Fin 2295 × ℕ) := [(46, 244), (179, 147), (273, 229), (466, 363), (512, 73), (514, 109), (572, 238), (587, 172), (588, 377), (617, 330), (650, 75), (679, 152), (681, 180), (737, 98), (741, 244), (742, 155), (743, 52), (813, 134), (815, 18), (817, 38), (819, 29), (851, 290), (858, 102), (869, 284), (892, 503), (896, 192), (898, 18), (917, 228), (918, 60), (921, 69), (934, 186), (938, 186), (944, 199), (957, 52), (958, 109), (959, 30), (960, 260), (966, 257), (973, 430), (978, 52), (1009, 154), (1012, 185), (1022, 12), (1049, 26), (1061, 116), (1069, 93), (1070, 89), (1081, 48), (1100, 110), (1110, 50), (1123, 259), (1143, 8), (1167, 311), (1173, 48), (1175, 129), (1186, 245), (1223, 293), (1227, 204), (1241, 66), (1253, 54), (1257, 14), (1263, 139), (1269, 3), (1286, 52), (1297, 127), (1308, 141), (1466, 19), (1471, 224), (1502, 45), (1517, 6), (1545, 139), (1572, 133), (1591, 118), (1669, 32), (1670, 101), (2061, 51), (2280, 143)]
def cs76354 : List ℕ := [710, 0, 0, 0, 637, 0, 352, 1000, 486, 0, 182, 1000, 849, 0, 244, 0, 892, 999, 0, 238, 1000, 1506, 857, 849, 0, 0, 912, 1552, 0, 534, 1000, 999, 1000, 999, 177, 1000, 344, 1000, 784, 946, 563, 1000, 1000, 414, 2630, 722, 1555, 1347, 248, 1000, 1000, 1610, 1000, 757, 1000, 1000, 1000, 1000, 811, 1000, 0, 1001, 1000, 894, 1000, 999, 74, 2137, 1001, 1000, 1000, 1000, 789, 1001, 998, 1000, 1023, 999, 629, 1000, 1001, 1903, 1000, 1000, 1000, 950, 1001, 613, 1000, 1000, 1002, 852, 1555, 1000, 999, 1000, 998, 1000, 1001, 1001, 1001, 998, 1002, 902, 893, 1000, 1000, 1000, 1001, 245, 856, 1000, 847, 829, 1000, 1001, 1001, 1001, 999, 559, 725, 1000, 1001, 790, 1001, 994, 1000, 1000, 1001, 1001, 1001, 927, 1000, 1001, 710, 1001, 833, 741, 1001, 1001, 652, 871, 1001, 1001, 637, 677, 882, 1000, 887, 850, 951, 844, 793, 1001]
theorem node76354 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76354 support demand code
    entries76354 ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 39 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node76349 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 39 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    18 node76353 node76354
def entries76351 : List (Fin 2295 × ℕ) := [(46, 3), (353, 1), (475, 11), (514, 2), (572, 28), (579, 20), (583, 4), (587, 35), (617, 35), (629, 8), (631, 7), (681, 29), (737, 22), (741, 20), (812, 14), (850, 15), (851, 15), (852, 11), (858, 30), (873, 13), (892, 44), (896, 16), (897, 8), (898, 29), (902, 2), (933, 3), (934, 36), (944, 22), (958, 18), (959, 7), (960, 49), (962, 16), (966, 15), (970, 5), (973, 44), (978, 3), (1009, 2), (1011, 7), (1012, 13), (1040, 1), (1055, 7), (1060, 4), (1061, 29), (1069, 2), (1070, 20), (1100, 22), (1110, 7), (1113, 2), (1114, 11), (1123, 15), (1143, 10), (1167, 41), (1175, 15), (1184, 8), (1186, 15), (1223, 20), (1227, 40), (1235, 4), (1276, 1), (1286, 17), (1308, 1), (1545, 4), (1591, 18), (1674, 1), (1705, 4), (1773, 7), (1807, 6), (1859, 48), (2000, 7), (2061, 12), (2073, 3), (2283, 5)]
def cs76351 : List ℕ := [68, 0, 0, 26, 52, 54, 89, 100, 26, 6, 2, 79, 100, 19, 11, 0, 76, 100, 93, 28, 100, 135, 72, 76, 6, 0, 97, 204, 0, 26, 70, 70, 100, 101, 15, 100, 15, 199, 76, 0, 73, 100, 67, 56, 177, 73, 161, 169, 0, 76, 100, 130, 99, 73, 100, 113, 100, 100, 100, 100, 6, 100, 89, 99, 99, 100, 0, 132, 86, 100, 42, 100, 65, 95, 101, 90, 144, 101, 32, 100, 99, 154, 99, 100, 63, 77, 99, 84, 100, 100, 99, 100, 208, 99, 99, 100, 101, 99, 101, 99, 99, 109, 99, 71, 72, 101, 101, 100, 99, 39, 100, 99, 98, 100, 87, 99, 100, 99, 100, 66, 100, 100, 99, 97, 99, 99, 100, 100, 101, 99, 99, 100, 100, 100, 92, 99, 61, 95, 101, 99, 81, 82, 100, 99, 43, 81, 100, 100, 86, 70, 91, 84, 68, 60]
theorem node76351 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76351 support demand code
    entries76351 ((insert 39 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries76352 : List (Fin 2295 × ℕ) := [(46, 43), (177, 3), (179, 1), (273, 45), (349, 6), (579, 45), (617, 49), (681, 30), (737, 17), (741, 31), (742, 10), (743, 2), (817, 14), (873, 42), (892, 55), (894, 25), (895, 8), (896, 24), (925, 2), (933, 1), (934, 31), (944, 31), (957, 8), (958, 13), (960, 35), (966, 10), (970, 2), (973, 50), (978, 9), (1009, 1), (1033, 11), (1040, 1), (1049, 1), (1061, 11), (1070, 16), (1100, 30), (1108, 1), (1110, 9), (1114, 27), (1123, 33), (1143, 18), (1152, 3), (1167, 37), (1175, 8), (1186, 12), (1188, 5), (1223, 51), (1226, 15), (1235, 13), (1253, 9), (1261, 1), (1281, 30), (1286, 4), (1375, 4), (1403, 12), (1545, 14), (1591, 19), (1652, 1), (1674, 11), (1859, 10), (2061, 3), (2283, 10)]
def cs76352 : List ℕ := [100, 0, 30, 30, 60, 10, 64, 100, 60, 0, 0, 100, 100, 42, 54, 0, 100, 100, 82, 0, 100, 211, 4, 100, 30, 0, 100, 197, 0, 58, 100, 75, 57, 100, 8, 100, 17, 10, 34, 30, 32, 100, 42, 49, 266, 51, 200, 30, 24, 58, 67, 120, 99, 64, 100, 134, 100, 100, 70, 100, 2, 100, 100, 41, 92, 101, 1, 193, 101, 99, 100, 100, 99, 70, 100, 75, 160, 101, 39, 100, 99, 167, 100, 101, 55, 58, 100, 99, 100, 95, 100, 81, 153, 101, 93, 100, 100, 100, 100, 100, 101, 100, 100, 101, 74, 100, 101, 94, 90, 12, 100, 100, 94, 78, 101, 100, 99, 100, 99, 58, 86, 100, 100, 99, 101, 91, 99, 100, 100, 101, 101, 95, 99, 100, 74, 100, 58, 87, 99, 100, 86, 72, 100, 99, 46, 77, 88, 100, 77, 93, 87, 91, 62, 62]
theorem node76352 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 39 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76352 support demand code
    entries76352 ((insert 37 (insert 39 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76350 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    37 node76351 node76352
theorem node76341 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 67 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    39 node76349 node76350
def entries76347 : List (Fin 2295 × ℕ) := [(23, 7), (177, 32), (179, 49), (181, 24), (484, 28), (490, 4), (514, 51), (572, 64), (588, 77), (617, 75), (618, 7), (629, 51), (631, 21), (679, 44), (681, 31), (737, 60), (741, 81), (813, 11), (816, 47), (818, 9), (819, 7), (846, 49), (850, 34), (851, 44), (852, 24), (860, 25), (870, 47), (873, 26), (888, 10), (892, 162), (897, 34), (898, 22), (902, 36), (921, 31), (933, 31), (944, 89), (959, 33), (960, 114), (962, 44), (966, 49), (970, 2), (973, 115), (978, 63), (994, 29), (1009, 16), (1012, 27), (1049, 11), (1061, 2), (1073, 14), (1076, 38), (1110, 3), (1122, 3), (1123, 35), (1143, 4), (1154, 14), (1162, 4), (1167, 33), (1173, 25), (1175, 40), (1186, 82), (1212, 15), (1223, 57), (1227, 42), (1233, 10), (1241, 14), (1281, 75), (1286, 1), (1308, 38), (1440, 39), (1516, 7), (1517, 30), (1554, 5), (1572, 71), (1607, 52), (1633, 27), (1651, 6), (1701, 12), (1765, 30), (1846, 39), (1903, 19), (1998, 1), (2000, 32), (2073, 19), (2204, 10)]
def cs76347 : List ℕ := [132, 49, 75, 139, 132, 34, 34, 256, 112, 36, 90, 243, 255, 26, 39, 0, 256, 256, 255, 74, 256, 295, 238, 237, 111, 0, 255, 534, 0, 205, 256, 257, 175, 255, 114, 255, 44, 497, 230, 257, 95, 255, 256, 136, 551, 222, 418, 414, 81, 179, 255, 340, 256, 257, 256, 255, 256, 257, 255, 256, 36, 255, 256, 222, 257, 256, 46, 63, 249, 256, 226, 333, 257, 255, 256, 233, 467, 256, 107, 256, 256, 527, 257, 257, 257, 209, 255, 258, 255, 256, 256, 221, 449, 258, 256, 256, 226, 255, 256, 258, 257, 256, 256, 189, 246, 256, 256, 256, 257, 141, 256, 256, 242, 236, 256, 256, 257, 256, 257, 169, 256, 256, 256, 256, 256, 225, 256, 256, 256, 256, 255, 195, 256, 256, 256, 256, 251, 237, 255, 256, 223, 227, 255, 256, 170, 173, 238, 255, 255, 256, 240, 256, 235, 255]
theorem node76347 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 71 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76347 support demand code
    entries76347 ((insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 71 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76348 : List (Fin 2295 × ℕ) := [(86, 3), (177, 23), (179, 17), (342, 1), (540, 11), (572, 22), (579, 24), (617, 15), (679, 12), (737, 23), (741, 34), (742, 1), (815, 4), (846, 5), (849, 11), (851, 5), (870, 11), (873, 46), (888, 11), (892, 53), (921, 35), (925, 2), (933, 17), (934, 8), (944, 56), (959, 16), (960, 38), (962, 5), (965, 5), (966, 12), (973, 49), (978, 9), (1003, 1), (1006, 2), (1009, 2), (1012, 3), (1033, 4), (1073, 16), (1093, 11), (1100, 2), (1110, 7), (1114, 4), (1123, 11), (1143, 19), (1162, 1), (1167, 24), (1171, 1), (1175, 5), (1186, 27), (1219, 28), (1223, 51), (1226, 14), (1227, 28), (1281, 6), (1286, 4), (1297, 19), (1308, 7), (1370, 12), (1403, 28), (1433, 4), (1572, 17), (1660, 1), (1670, 5), (1705, 10), (1846, 13), (1848, 1), (2000, 15), (2061, 15), (2247, 3)]
def cs76348 : List ℕ := [60, 33, 9, 45, 56, 3, 0, 98, 51, 0, 0, 99, 99, 46, 11, 0, 88, 94, 99, 33, 99, 105, 40, 99, 9, 1, 99, 158, 0, 40, 99, 99, 2, 99, 49, 99, 5, 0, 100, 99, 47, 39, 57, 54, 265, 45, 167, 64, 59, 88, 78, 117, 32, 99, 98, 123, 101, 99, 65, 99, 2, 100, 95, 78, 64, 100, 12, 24, 100, 100, 100, 176, 100, 98, 100, 55, 209, 100, 22, 100, 98, 228, 100, 100, 67, 62, 100, 94, 101, 100, 100, 65, 172, 99, 83, 99, 65, 99, 101, 100, 99, 100, 98, 100, 65, 99, 99, 101, 100, 32, 100, 101, 100, 80, 94, 100, 100, 101, 100, 70, 100, 100, 100, 100, 100, 93, 100, 100, 99, 100, 81, 78, 99, 101, 93, 97, 72, 89, 99, 100, 69, 73, 100, 100, 66, 81, 98, 100, 97, 100, 95, 100, 82, 100]
theorem node76348 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76348 support demand code
    entries76348 ((insert 37 (insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 71 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76343 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 71 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    37 node76347 node76348
def entries76345 : List (Fin 2295 × ℕ) := [(43, 45), (49, 29), (177, 81), (179, 29), (349, 25), (471, 70), (514, 20), (540, 65), (542, 21), (572, 134), (588, 88), (617, 48), (618, 25), (629, 90), (631, 1), (681, 58), (737, 65), (739, 9), (740, 46), (741, 61), (816, 28), (817, 24), (819, 23), (849, 59), (851, 36), (860, 3), (870, 106), (873, 4), (892, 169), (897, 5), (898, 51), (920, 21), (933, 48), (934, 39), (940, 1), (944, 84), (960, 51), (966, 11), (970, 45), (972, 12), (973, 124), (978, 17), (994, 63), (1006, 7), (1009, 8), (1012, 32), (1070, 34), (1076, 20), (1100, 46), (1122, 17), (1123, 83), (1143, 9), (1154, 30), (1167, 30), (1171, 10), (1175, 49), (1177, 8), (1186, 65), (1212, 1), (1223, 71), (1227, 20), (1247, 36), (1261, 11), (1281, 79), (1342, 4), (1375, 1), (1403, 38), (1486, 13), (1545, 8), (1572, 21), (1651, 15), (1670, 12), (1692, 4), (1902, 8), (1995, 51), (2061, 14), (2225, 45)]
def cs76345 : List ℕ := [150, 0, 149, 138, 107, 15, 45, 256, 103, 19, 20, 256, 256, 8, 131, 4, 255, 257, 256, 138, 256, 289, 254, 236, 164, 10, 237, 537, 4, 246, 256, 256, 107, 256, 112, 256, 36, 255, 255, 379, 221, 257, 192, 141, 504, 255, 425, 395, 130, 197, 252, 363, 211, 256, 256, 257, 254, 256, 255, 256, 15, 256, 256, 177, 256, 257, 18, 38, 256, 256, 257, 67, 191, 256, 255, 217, 297, 257, 21, 257, 256, 477, 258, 256, 255, 220, 141, 256, 255, 257, 257, 173, 358, 258, 255, 256, 243, 256, 255, 257, 256, 256, 256, 238, 170, 257, 255, 256, 210, 78, 257, 256, 164, 199, 256, 256, 257, 256, 256, 181, 135, 211, 256, 257, 255, 256, 256, 256, 220, 256, 256, 211, 256, 256, 185, 256, 212, 199, 256, 256, 255, 189, 221, 256, 256, 181, 182, 256, 207, 245, 253, 256, 240, 202]
theorem node76345 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76345 support demand code
    entries76345 ((insert 71 (insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 39 (insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76346 : List (Fin 2295 × ℕ) := [(43, 9), (86, 19), (177, 18), (179, 40), (273, 1), (349, 16), (484, 14), (514, 14), (572, 63), (579, 26), (583, 36), (587, 14), (588, 28), (681, 6), (736, 2), (737, 29), (739, 3), (741, 23), (816, 2), (844, 14), (851, 14), (870, 3), (873, 21), (892, 53), (902, 11), (933, 8), (934, 10), (944, 41), (945, 10), (946, 5), (960, 13), (970, 25), (973, 45), (978, 21), (985, 2), (1009, 15), (1012, 15), (1061, 8), (1069, 3), (1070, 19), (1073, 2), (1076, 7), (1100, 18), (1123, 31), (1167, 17), (1175, 28), (1186, 27), (1223, 37), (1227, 16), (1235, 13), (1247, 12), (1253, 2), (1297, 8), (1298, 1), (1342, 16), (1364, 7), (1370, 3), (1375, 8), (1403, 24), (1545, 7), (1705, 3), (1845, 3), (1848, 1), (1849, 6), (1859, 30), (2061, 3), (2225, 8), (2247, 2)]
def cs76346 : List ℕ := [85, 0, 2, 0, 53, 46, 39, 99, 39, 0, 14, 91, 99, 21, 9, 0, 99, 85, 67, 63, 99, 140, 100, 99, 2, 16, 100, 177, 0, 67, 99, 99, 87, 100, 28, 100, 16, 100, 96, 5, 81, 99, 97, 59, 203, 83, 168, 80, 89, 68, 94, 128, 92, 100, 99, 100, 99, 100, 94, 100, 0, 93, 89, 74, 99, 100, 0, 24, 99, 100, 84, 34, 54, 90, 100, 58, 132, 100, 7, 100, 100, 123, 100, 100, 97, 57, 66, 100, 99, 100, 100, 91, 118, 101, 100, 100, 85, 99, 99, 100, 99, 101, 100, 96, 52, 99, 99, 101, 99, 27, 101, 100, 40, 98, 99, 100, 101, 100, 100, 75, 83, 98, 99, 101, 100, 80, 99, 100, 92, 100, 97, 90, 100, 99, 81, 99, 76, 73, 99, 100, 100, 78, 100, 100, 76, 78, 92, 101, 94, 100, 99, 100, 72, 80]
theorem node76346 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 71 (insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76346 support demand code
    entries76346 ((insert 39 (insert 71 (insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76344 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    39 node76345 node76346
theorem node76342 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    71 node76343 node76344
theorem node76335 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    67 node76341 node76342
def entries76339 : List (Fin 2295 × ℕ) := [(49, 19), (177, 10), (179, 9), (273, 17), (471, 42), (475, 1), (482, 15), (484, 4), (490, 14), (540, 19), (571, 8), (572, 20), (587, 25), (588, 2), (617, 12), (681, 37), (737, 19), (739, 5), (741, 20), (742, 1), (743, 6), (849, 14), (851, 19), (860, 9), (870, 18), (873, 23), (874, 44), (898, 23), (902, 8), (933, 18), (934, 19), (938, 1), (944, 30), (958, 10), (960, 30), (966, 19), (970, 3), (973, 44), (978, 8), (994, 8), (1006, 13), (1009, 3), (1011, 12), (1012, 14), (1025, 5), (1049, 14), (1055, 5), (1061, 11), (1070, 18), (1100, 5), (1113, 3), (1114, 8), (1123, 14), (1153, 1), (1154, 6), (1167, 32), (1174, 2), (1175, 22), (1212, 18), (1223, 6), (1241, 6), (1247, 6), (1261, 1), (1281, 33), (1286, 9), (1308, 14), (1480, 22), (1488, 3), (1517, 28), (1545, 14), (1572, 10), (1618, 1), (1619, 8), (1623, 10), (1670, 14), (1717, 3), (1845, 9), (1998, 6), (2000, 6)]
def cs76339 : List ℕ := [39, 0, 75, 48, 25, 19, 42, 100, 34, 9, 0, 100, 101, 67, 19, 0, 100, 100, 204, 31, 100, 0, 69, 66, 99, 0, 94, 165, 0, 22, 99, 100, 100, 101, 38, 102, 19, 100, 101, 179, 68, 87, 57, 67, 203, 85, 34, 132, 45, 96, 99, 146, 27, 100, 100, 100, 100, 101, 99, 100, 0, 101, 100, 101, 100, 99, 14, 100, 100, 100, 61, 100, 91, 100, 100, 80, 144, 99, 28, 100, 101, 181, 85, 100, 102, 98, 99, 100, 100, 100, 99, 95, 145, 99, 79, 100, 90, 99, 100, 99, 99, 100, 100, 100, 83, 99, 98, 99, 98, 18, 97, 100, 101, 84, 84, 99, 99, 100, 99, 85, 82, 99, 98, 99, 100, 100, 99, 100, 100, 99, 100, 100, 99, 100, 55, 99, 83, 90, 99, 99, 67, 100, 100, 100, 62, 66, 96, 100, 93, 78, 100, 84, 83, 82]
theorem node76339 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 39 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76339 support demand code
    entries76339 ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 18 (insert 39 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries76340 : List (Fin 2295 × ℕ) := [(20, 66), (177, 37), (273, 43), (466, 36), (496, 15), (514, 13), (571, 110), (572, 19), (587, 21), (588, 104), (617, 33), (619, 8), (620, 1), (678, 24), (679, 17), (681, 41), (690, 16), (737, 19), (741, 39), (742, 40), (743, 9), (815, 6), (816, 46), (817, 2), (851, 82), (870, 44), (892, 29), (898, 46), (917, 39), (918, 22), (920, 25), (921, 56), (933, 24), (934, 18), (938, 33), (944, 102), (958, 7), (965, 33), (966, 49), (970, 6), (973, 120), (1007, 12), (1009, 19), (1012, 11), (1061, 16), (1069, 19), (1070, 3), (1072, 7), (1073, 23), (1082, 7), (1100, 4), (1111, 5), (1113, 15), (1114, 44), (1123, 41), (1143, 3), (1154, 2), (1155, 18), (1167, 76), (1173, 3), (1175, 60), (1178, 25), (1179, 28), (1212, 39), (1223, 68), (1226, 16), (1241, 12), (1281, 37), (1286, 2), (1296, 10), (1308, 16), (1403, 20), (1433, 39), (1442, 31), (1517, 71), (1572, 54), (1623, 9), (1626, 2), (1670, 67), (1701, 9), (1845, 5), (1848, 7), (2000, 24), (2061, 30), (2225, 2)]
def cs76340 : List ℕ := [141, 0, 37, 103, 150, 10, 71, 223, 159, 0, 13, 256, 166, 76, 31, 0, 164, 257, 47, 129, 256, 31, 210, 197, 47, 0, 244, 171, 0, 105, 256, 224, 241, 256, 63, 255, 82, 257, 212, 369, 186, 256, 242, 137, 509, 256, 154, 385, 120, 256, 256, 388, 22, 256, 255, 257, 256, 256, 256, 256, 0, 255, 257, 257, 257, 256, 56, 257, 256, 256, 225, 257, 256, 257, 256, 257, 255, 256, 94, 256, 256, 496, 256, 258, 256, 257, 256, 257, 256, 256, 255, 159, 233, 258, 256, 256, 203, 256, 256, 257, 255, 257, 257, 256, 255, 255, 257, 256, 257, 92, 228, 257, 256, 219, 256, 256, 256, 256, 257, 210, 113, 257, 255, 255, 256, 248, 256, 257, 256, 255, 256, 256, 255, 256, 202, 255, 256, 256, 256, 256, 220, 249, 256, 257, 209, 256, 207, 240, 256, 206, 256, 247, 256, 256]
theorem node76340 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76340 support demand code
    entries76340 ((insert 18 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 39 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76337 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 39 (insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    18 node76339 node76340
def entries76338 : List (Fin 2295 × ℕ) := [(20, 16), (83, 15), (86, 12), (177, 44), (273, 64), (349, 11), (571, 55), (587, 12), (617, 39), (618, 8), (620, 33), (679, 24), (680, 56), (681, 105), (737, 62), (741, 22), (815, 21), (844, 13), (851, 18), (858, 18), (870, 4), (873, 36), (874, 23), (897, 26), (898, 60), (902, 4), (925, 5), (933, 59), (934, 38), (938, 9), (944, 94), (946, 1), (958, 48), (960, 58), (962, 15), (966, 27), (970, 24), (973, 103), (978, 31), (1005, 14), (1006, 3), (1009, 13), (1011, 7), (1012, 35), (1049, 24), (1061, 28), (1069, 35), (1070, 10), (1073, 23), (1100, 52), (1113, 30), (1114, 49), (1123, 64), (1143, 5), (1152, 40), (1167, 115), (1175, 38), (1186, 12), (1188, 23), (1223, 82), (1226, 38), (1235, 30), (1241, 38), (1247, 26), (1253, 20), (1372, 57), (1403, 28), (1480, 1), (1488, 19), (1522, 18), (1545, 35), (1572, 23), (1670, 4), (1845, 26), (1859, 123), (1998, 7), (2000, 23), (2061, 4), (2073, 7), (2204, 3), (2283, 16)]
def cs76338 : List ℕ := [238, 0, 0, 16, 120, 141, 141, 256, 118, 0, 0, 256, 256, 150, 0, 0, 243, 224, 257, 55, 256, 0, 142, 256, 0, 13, 243, 185, 0, 60, 256, 45, 222, 256, 38, 256, 38, 257, 257, 4, 152, 257, 120, 176, 413, 257, 126, 329, 110, 204, 216, 350, 126, 256, 255, 256, 257, 257, 257, 255, 23, 257, 257, 247, 256, 256, 24, 256, 257, 258, 81, 257, 217, 257, 255, 256, 316, 257, 27, 257, 257, 419, 232, 256, 257, 238, 256, 257, 256, 256, 256, 256, 298, 255, 256, 256, 256, 256, 257, 257, 255, 266, 255, 256, 192, 256, 256, 256, 226, 27, 256, 256, 257, 255, 255, 255, 256, 256, 256, 171, 237, 256, 256, 248, 257, 238, 256, 256, 256, 256, 256, 256, 256, 256, 184, 256, 199, 251, 256, 256, 188, 179, 256, 256, 106, 164, 256, 256, 198, 190, 238, 198, 119, 157]
theorem node76338 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76338 support demand code
    entries76338 ((insert 39 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76336 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    39 node76337 node76338
theorem node76327 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    21 node76335 node76336
def entries76333 : List (Fin 2295 × ℕ) := [(23, 98), (46, 386), (177, 32), (273, 115), (471, 51), (512, 213), (531, 98), (571, 213), (572, 54), (587, 199), (588, 170), (617, 94), (639, 140), (678, 168), (679, 116), (681, 476), (737, 198), (741, 256), (742, 55), (813, 21), (851, 115), (858, 51), (859, 125), (873, 369), (874, 382), (888, 19), (898, 64), (900, 10), (902, 114), (917, 122), (918, 108), (933, 83), (934, 346), (938, 131), (944, 290), (958, 258), (960, 321), (966, 140), (973, 407), (978, 88), (994, 55), (1005, 3), (1009, 42), (1012, 185), (1034, 17), (1049, 86), (1061, 22), (1070, 184), (1073, 26), (1075, 33), (1100, 169), (1114, 24), (1123, 240), (1153, 4), (1167, 315), (1173, 23), (1174, 68), (1175, 209), (1186, 119), (1188, 77), (1226, 63), (1235, 62), (1241, 277), (1247, 150), (1253, 11), (1275, 20), (1281, 481), (1285, 140), (1286, 55), (1308, 28), (1403, 100), (1488, 24), (1545, 127), (1572, 60), (1591, 82), (1674, 104), (1773, 56), (1859, 244), (2000, 100), (2061, 156), (2280, 59), (2283, 10)]
def cs76333 : List ℕ := [736, 0, 532, 621, 224, 244, 841, 1000, 276, 0, 213, 876, 1001, 989, 546, 0, 1000, 1000, 1863, 286, 1000, 546, 524, 1000, 672, 0, 1000, 1278, 0, 637, 1000, 1000, 1000, 999, 300, 1000, 251, 1000, 892, 1000, 696, 1000, 881, 754, 1987, 455, 0, 1352, 172, 1000, 999, 1441, 1000, 999, 999, 1197, 1000, 1000, 1001, 999, 0, 1000, 999, 1000, 999, 999, 128, 1678, 938, 1001, 946, 1001, 830, 929, 868, 788, 1534, 1000, 228, 999, 999, 1936, 999, 1001, 1000, 921, 1000, 985, 1000, 976, 999, 999, 1221, 999, 1000, 1000, 998, 1001, 1000, 998, 999, 1063, 1000, 999, 769, 999, 1001, 998, 1000, 119, 999, 998, 1001, 888, 999, 999, 999, 1000, 999, 710, 637, 1000, 999, 823, 1000, 998, 1000, 999, 1000, 999, 999, 999, 999, 999, 550, 830, 767, 755, 999, 999, 526, 907, 999, 999, 383, 724, 999, 991, 999, 791, 999, 755, 530, 823]
theorem node76333 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 18 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76333 support demand code
    entries76333 ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 18 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries76334 : List (Fin 2295 × ℕ) := [(23, 7), (43, 17), (86, 42), (177, 28), (471, 7), (512, 67), (514, 23), (531, 24), (572, 89), (587, 19), (639, 20), (678, 7), (680, 18), (681, 86), (736, 1), (737, 66), (738, 4), (741, 58), (742, 19), (846, 61), (851, 16), (859, 63), (870, 12), (873, 89), (874, 102), (897, 7), (898, 84), (902, 58), (933, 21), (934, 67), (944, 138), (958, 14), (959, 32), (960, 53), (970, 25), (973, 135), (978, 37), (994, 10), (1009, 31), (1011, 20), (1012, 16), (1070, 64), (1073, 33), (1076, 36), (1123, 48), (1154, 17), (1167, 48), (1171, 16), (1174, 3), (1175, 69), (1186, 51), (1212, 1), (1226, 12), (1234, 5), (1241, 12), (1247, 21), (1281, 85), (1285, 28), (1286, 23), (1297, 20), (1308, 25), (1403, 58), (1480, 48), (1545, 11), (1572, 7), (1620, 14), (1670, 27), (1701, 18), (1751, 8), (1845, 2), (1846, 19), (1848, 4), (1859, 42), (2000, 37), (2244, 38)]
def cs76334 : List ℕ := [127, 99, 92, 151, 23, 42, 59, 256, 91, 0, 90, 247, 256, 257, 17, 14, 224, 255, 497, 89, 255, 31, 152, 255, 172, 16, 257, 372, 0, 59, 255, 256, 142, 256, 133, 257, 93, 256, 256, 256, 177, 234, 194, 169, 507, 172, 0, 352, 72, 256, 256, 345, 104, 256, 255, 256, 257, 256, 257, 255, 0, 256, 256, 242, 256, 256, 16, 73, 256, 257, 241, 256, 256, 222, 177, 123, 420, 257, 39, 255, 256, 468, 254, 257, 256, 176, 255, 255, 256, 238, 255, 220, 371, 256, 256, 255, 217, 256, 256, 247, 255, 261, 255, 257, 192, 255, 256, 256, 243, 52, 256, 256, 255, 209, 223, 255, 256, 257, 255, 260, 165, 255, 255, 256, 257, 240, 255, 255, 255, 255, 230, 255, 255, 256, 187, 200, 230, 212, 256, 257, 209, 252, 256, 255, 158, 237, 231, 256, 256, 247, 245, 256, 239, 246]
theorem node76334 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76334 support demand code
    entries76334 ((insert 67 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76329 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 18 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    67 node76333 node76334
def entries76331 : List (Fin 2295 × ℕ) := [(46, 75), (466, 68), (491, 5), (498, 75), (512, 6), (514, 6), (571, 139), (587, 58), (588, 55), (617, 23), (639, 5), (678, 8), (679, 77), (681, 62), (729, 6), (737, 5), (740, 5), (741, 18), (743, 6), (813, 64), (817, 5), (819, 9), (869, 13), (892, 34), (898, 27), (916, 11), (917, 45), (918, 48), (920, 24), (925, 38), (933, 22), (934, 65), (938, 76), (944, 63), (946, 7), (957, 7), (958, 80), (960, 7), (966, 52), (973, 110), (978, 15), (994, 8), (1011, 1), (1012, 28), (1034, 16), (1043, 13), (1049, 1), (1061, 18), (1069, 28), (1070, 33), (1072, 11), (1073, 9), (1082, 13), (1100, 31), (1113, 21), (1114, 18), (1123, 16), (1143, 1), (1167, 91), (1175, 56), (1178, 6), (1179, 49), (1186, 34), (1223, 19), (1226, 53), (1241, 56), (1247, 20), (1253, 94), (1258, 2), (1272, 17), (1286, 25), (1403, 4), (1433, 9), (1517, 58), (1523, 2), (1545, 15), (1547, 32), (1591, 26), (1623, 25), (1670, 15), (1773, 6), (2000, 4), (2061, 41), (2280, 41)]
def cs76331 : List ℕ := [181, 0, 0, 0, 113, 0, 144, 181, 188, 0, 12, 257, 256, 0, 81, 0, 193, 258, 0, 139, 256, 115, 181, 256, 0, 0, 256, 109, 0, 122, 257, 153, 256, 253, 56, 256, 94, 256, 166, 256, 226, 256, 234, 160, 447, 190, 53, 362, 75, 256, 256, 421, 235, 235, 256, 256, 258, 256, 256, 256, 38, 255, 257, 218, 257, 255, 56, 550, 256, 256, 256, 256, 178, 256, 228, 225, 247, 257, 101, 257, 256, 557, 258, 257, 255, 257, 256, 258, 256, 256, 256, 244, 241, 256, 256, 256, 257, 258, 256, 258, 256, 265, 258, 256, 229, 257, 256, 257, 256, 89, 257, 257, 257, 208, 256, 256, 257, 257, 256, 187, 188, 255, 256, 257, 258, 250, 257, 255, 257, 257, 257, 257, 256, 257, 185, 257, 207, 256, 258, 256, 159, 237, 257, 256, 116, 256, 256, 255, 258, 182, 256, 207, 210, 215]
theorem node76331 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76331 support demand code
    entries76331 ((insert 18 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76332 : List (Fin 2295 × ℕ) := [(43, 103), (177, 45), (342, 23), (466, 122), (498, 58), (512, 47), (514, 28), (571, 65), (572, 81), (587, 3), (588, 79), (617, 24), (678, 38), (679, 12), (681, 45), (690, 27), (691, 7), (737, 44), (741, 63), (812, 42), (815, 47), (816, 57), (817, 21), (859, 17), (870, 75), (888, 18), (892, 44), (897, 11), (898, 54), (918, 2), (920, 36), (921, 52), (933, 47), (934, 41), (944, 123), (959, 29), (960, 5), (962, 1), (965, 3), (966, 32), (970, 26), (973, 124), (978, 10), (994, 13), (1012, 2), (1070, 9), (1072, 7), (1073, 28), (1076, 1), (1098, 6), (1114, 39), (1123, 53), (1152, 3), (1155, 29), (1167, 68), (1171, 10), (1174, 3), (1175, 61), (1178, 22), (1179, 19), (1212, 19), (1223, 9), (1226, 7), (1241, 16), (1247, 14), (1253, 50), (1335, 14), (1403, 30), (1547, 38), (1572, 54), (1660, 4), (1670, 68), (1701, 5), (1712, 35), (1751, 12), (2061, 42), (2225, 8)]
def cs76332 : List ℕ := [181, 0, 0, 0, 59, 0, 103, 181, 134, 0, 75, 256, 256, 0, 103, 0, 256, 256, 0, 164, 256, 147, 192, 239, 0, 10, 255, 119, 0, 183, 256, 95, 129, 209, 64, 255, 67, 257, 243, 242, 234, 243, 256, 143, 347, 256, 53, 345, 120, 256, 257, 402, 86, 256, 256, 256, 256, 256, 257, 256, 0, 256, 256, 256, 256, 256, 69, 70, 256, 257, 256, 256, 248, 257, 206, 182, 312, 256, 45, 255, 255, 504, 256, 255, 257, 241, 255, 257, 257, 256, 255, 152, 407, 257, 256, 256, 229, 256, 257, 249, 255, 257, 256, 256, 255, 256, 255, 255, 255, 61, 257, 256, 256, 172, 256, 255, 256, 255, 257, 223, 154, 255, 255, 256, 255, 257, 256, 255, 256, 254, 216, 256, 257, 255, 220, 228, 252, 257, 256, 255, 228, 248, 256, 256, 208, 254, 186, 225, 256, 223, 253, 229, 256, 256]
theorem node76332 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 18 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76332 support demand code
    entries76332 ((insert 67 (insert 18 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76330 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    67 node76331 node76332
theorem node76328 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    18 node76329 node76330
theorem node76315 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    46 node76327 node76328
def entries76325 : List (Fin 2295 × ℕ) := [(46, 16), (179, 26), (181, 28), (484, 33), (491, 8), (514, 40), (572, 172), (587, 30), (618, 17), (680, 58), (681, 39), (690, 23), (737, 22), (819, 5), (850, 20), (852, 72), (858, 20), (859, 9), (860, 11), (869, 59), (870, 1), (873, 48), (896, 68), (898, 48), (902, 8), (913, 19), (914, 9), (916, 7), (917, 108), (920, 30), (921, 7), (934, 83), (944, 69), (958, 55), (966, 36), (970, 14), (971, 16), (972, 3), (973, 96), (978, 30), (985, 30), (993, 9), (1007, 14), (1011, 14), (1012, 16), (1041, 20), (1049, 4), (1061, 39), (1070, 18), (1096, 43), (1100, 75), (1110, 10), (1111, 3), (1114, 37), (1123, 67), (1142, 7), (1143, 22), (1167, 106), (1175, 53), (1178, 18), (1179, 35), (1182, 13), (1186, 50), (1227, 58), (1241, 30), (1253, 28), (1261, 29), (1275, 14), (1281, 17), (1342, 33), (1354, 3), (1364, 19), (1488, 7), (1517, 5), (1591, 9), (1607, 30), (1668, 2), (1859, 139), (1902, 2), (2000, 12), (2061, 13), (2280, 50)]
def cs76325 : List ℕ := [184, 0, 17, 37, 100, 172, 188, 256, 48, 0, 40, 257, 257, 48, 16, 0, 257, 257, 257, 172, 257, 172, 182, 192, 17, 30, 257, 402, 0, 150, 257, 257, 257, 256, 53, 255, 37, 479, 226, 257, 255, 257, 197, 188, 561, 255, 256, 375, 59, 257, 257, 452, 257, 256, 256, 255, 256, 256, 256, 256, 0, 255, 257, 256, 178, 256, 57, 485, 239, 256, 115, 191, 145, 227, 255, 188, 182, 256, 75, 257, 256, 0, 257, 257, 256, 211, 255, 238, 256, 256, 257, 255, 277, 257, 256, 255, 256, 255, 254, 255, 257, 268, 257, 225, 171, 256, 255, 257, 255, 122, 245, 255, 182, 198, 255, 255, 255, 256, 255, 163, 117, 256, 256, 248, 256, 215, 255, 255, 245, 256, 255, 255, 256, 255, 255, 256, 149, 255, 255, 255, 256, 197, 255, 255, 189, 254, 255, 255, 254, 185, 255, 255, 198, 190]
theorem node76325 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 67 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76325 support demand code
    entries76325 ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 67 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76326 : List (Fin 2295 × ℕ) := [(23, 3), (46, 19), (179, 31), (273, 30), (349, 5), (466, 6), (527, 2), (569, 6), (572, 36), (576, 4), (680, 3), (681, 8), (737, 25), (843, 28), (852, 8), (869, 12), (873, 48), (896, 26), (917, 35), (920, 2), (925, 17), (934, 23), (944, 20), (946, 18), (957, 8), (958, 29), (966, 22), (973, 40), (978, 17), (985, 10), (1007, 5), (1011, 3), (1012, 5), (1034, 1), (1045, 4), (1061, 4), (1068, 4), (1070, 14), (1073, 11), (1096, 1), (1100, 25), (1110, 2), (1111, 5), (1113, 7), (1114, 17), (1123, 22), (1143, 18), (1152, 4), (1167, 38), (1175, 18), (1179, 14), (1182, 2), (1186, 12), (1223, 34), (1227, 20), (1234, 9), (1241, 17), (1247, 5), (1253, 17), (1278, 6), (1281, 31), (1286, 1), (1296, 11), (1342, 14), (1364, 8), (1488, 14), (1516, 1), (1545, 6), (1580, 2), (1674, 13), (1690, 11), (2000, 4)]
def cs76326 : List ℕ := [88, 0, 31, 31, 64, 11, 32, 101, 62, 0, 0, 100, 101, 61, 34, 0, 99, 99, 101, 36, 100, 78, 31, 101, 42, 10, 101, 91, 0, 63, 100, 101, 47, 100, 18, 99, 17, 0, 100, 100, 61, 43, 33, 77, 239, 100, 100, 69, 83, 100, 29, 148, 95, 99, 100, 100, 98, 100, 100, 100, 17, 100, 99, 91, 80, 99, 14, 188, 100, 101, 33, 100, 73, 88, 99, 79, 109, 87, 33, 100, 100, 0, 100, 99, 89, 93, 100, 98, 99, 99, 100, 97, 84, 101, 84, 91, 81, 98, 100, 99, 100, 100, 99, 100, 58, 99, 99, 89, 94, 26, 100, 100, 91, 93, 98, 99, 99, 99, 99, 72, 69, 100, 100, 99, 98, 79, 100, 101, 100, 100, 99, 97, 100, 100, 78, 99, 58, 100, 99, 100, 68, 91, 99, 100, 78, 84, 100, 100, 99, 74, 96, 92, 68, 69]
theorem node76326 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76326 support demand code
    entries76326 ((insert 37 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76317 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    37 node76325 node76326
def entries76323 : List (Fin 2295 × ℕ) := [(23, 8), (179, 3), (471, 1), (482, 12), (512, 1), (529, 8), (530, 9), (572, 17), (585, 17), (588, 6), (639, 2), (681, 10), (737, 6), (797, 3), (817, 7), (852, 5), (857, 10), (870, 9), (873, 6), (898, 5), (917, 7), (920, 8), (921, 8), (932, 3), (934, 8), (944, 16), (946, 3), (966, 5), (969, 1), (971, 2), (973, 12), (978, 3), (993, 8), (994, 3), (1012, 2), (1033, 2), (1070, 2), (1076, 7), (1100, 4), (1108, 1), (1111, 3), (1122, 3), (1123, 3), (1143, 1), (1155, 7), (1167, 6), (1171, 2), (1174, 4), (1175, 10), (1179, 10), (1186, 1), (1233, 1), (1241, 6), (1245, 6), (1247, 2), (1281, 17), (1285, 2), (1517, 4), (1572, 2), (1607, 4), (1663, 2), (1670, 2), (1728, 1), (1859, 1), (2135, 2)]
def cs76323 : List ℕ := [18, 0, 18, 19, 13, 13, 15, 32, 2, 0, 1, 33, 32, 25, 0, 0, 32, 32, 64, 17, 33, 27, 16, 20, 32, 2, 32, 83, 0, 9, 33, 99, 14, 32, 14, 32, 0, 33, 23, 76, 28, 31, 24, 26, 62, 32, 32, 31, 10, 32, 25, 49, 29, 31, 32, 32, 32, 32, 33, 32, 0, 28, 32, 23, 30, 31, 12, 17, 32, 32, 24, 32, 29, 32, 32, 28, 35, 29, 10, 32, 32, 2, 32, 32, 31, 27, 32, 32, 32, 30, 30, 25, 36, 32, 32, 32, 26, 31, 31, 31, 32, 32, 33, 14, 30, 31, 26, 30, 32, 13, 32, 31, 28, 31, 31, 30, 32, 32, 32, 26, 8, 30, 30, 30, 33, 25, 31, 32, 31, 31, 31, 32, 32, 32, 22, 29, 30, 30, 32, 32, 26, 32, 32, 26, 24, 32, 29, 27, 32, 21, 32, 24, 25, 29]
theorem node76323 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 31 (insert 18 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76323 support demand code
    entries76323 ((insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 39 (insert 31 (insert 18 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
def entries76324 : List (Fin 2295 × ℕ) := [(43, 9), (86, 10), (177, 1), (179, 1), (271, 11), (284, 5), (349, 6), (507, 7), (514, 22), (572, 42), (583, 2), (585, 3), (681, 15), (737, 30), (797, 14), (817, 15), (850, 16), (851, 11), (852, 11), (860, 5), (870, 6), (873, 36), (898, 9), (902, 16), (921, 10), (924, 2), (925, 1), (934, 13), (944, 54), (945, 21), (946, 10), (970, 13), (972, 4), (973, 41), (978, 31), (985, 9), (1005, 1), (1007, 4), (1012, 14), (1033, 1), (1068, 6), (1070, 7), (1076, 4), (1098, 13), (1100, 13), (1110, 6), (1111, 2), (1113, 6), (1114, 2), (1122, 3), (1123, 20), (1149, 6), (1155, 4), (1167, 24), (1174, 1), (1175, 34), (1179, 14), (1186, 24), (1223, 25), (1227, 6), (1235, 12), (1241, 1), (1245, 47), (1247, 9), (1286, 4), (1293, 4), (1295, 2), (1297, 11), (1342, 12), (1488, 7), (1705, 9), (1715, 3), (1721, 17), (1846, 1), (1859, 49), (2040, 4)]
def cs76324 : List ℕ := [74, 4, 0, 20, 47, 49, 62, 100, 30, 11, 22, 94, 99, 53, 9, 17, 96, 100, 129, 42, 100, 84, 28, 100, 28, 9, 100, 133, 17, 32, 100, 95, 94, 101, 52, 100, 11, 100, 99, 16, 72, 100, 80, 73, 167, 98, 99, 93, 62, 64, 81, 150, 94, 100, 100, 99, 99, 99, 99, 100, 6, 93, 100, 82, 100, 99, 14, 24, 99, 99, 33, 63, 73, 99, 100, 65, 133, 74, 4, 101, 100, 0, 100, 98, 100, 51, 99, 101, 99, 100, 100, 98, 85, 99, 99, 79, 59, 100, 98, 100, 99, 100, 99, 99, 56, 95, 99, 100, 99, 42, 100, 100, 77, 101, 101, 100, 99, 99, 100, 78, 61, 100, 100, 100, 99, 71, 101, 99, 100, 100, 86, 100, 100, 99, 99, 100, 82, 86, 101, 100, 100, 80, 100, 75, 79, 100, 93, 100, 100, 94, 100, 99, 79, 81]
theorem node76324 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 18 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76324 support demand code
    entries76324 ((insert 39 (insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 31 (insert 18 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76321 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 18 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 31 (insert 18 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    39 node76323 node76324
def entries76322 : List (Fin 2295 × ℕ) := [(23, 33), (177, 26), (179, 41), (269, 41), (273, 7), (484, 66), (507, 30), (514, 54), (542, 32), (572, 98), (576, 19), (639, 4), (680, 86), (681, 17), (737, 49), (816, 6), (817, 61), (846, 17), (852, 70), (860, 54), (870, 84), (873, 94), (888, 34), (892, 17), (896, 40), (898, 30), (902, 17), (921, 48), (934, 47), (944, 118), (945, 8), (946, 23), (960, 9), (965, 34), (970, 26), (972, 22), (973, 111), (978, 63), (985, 9), (994, 20), (1011, 12), (1012, 17), (1033, 1), (1061, 2), (1068, 28), (1076, 20), (1098, 4), (1100, 73), (1110, 26), (1111, 38), (1114, 17), (1122, 20), (1123, 52), (1143, 2), (1155, 11), (1167, 62), (1175, 51), (1177, 32), (1179, 51), (1186, 45), (1219, 30), (1234, 71), (1235, 62), (1293, 2), (1297, 31), (1364, 4), (1370, 4), (1401, 15), (1479, 11), (1488, 7), (1572, 31), (1705, 11), (1859, 106), (2000, 5)]
def cs76322 : List ℕ := [106, 47, 0, 30, 103, 172, 106, 256, 54, 30, 54, 220, 256, 94, 47, 0, 256, 256, 376, 132, 256, 57, 97, 200, 30, 9, 256, 297, 0, 67, 256, 48, 250, 256, 98, 256, 0, 256, 257, 212, 145, 235, 172, 192, 516, 257, 247, 220, 169, 144, 256, 351, 86, 256, 256, 256, 257, 256, 256, 256, 0, 256, 256, 256, 109, 256, 117, 102, 256, 256, 55, 181, 239, 187, 257, 199, 319, 165, 38, 256, 256, 26, 189, 256, 257, 243, 257, 246, 256, 256, 255, 215, 237, 256, 242, 241, 202, 258, 256, 255, 256, 256, 256, 231, 199, 258, 257, 256, 256, 118, 256, 256, 256, 258, 255, 256, 256, 256, 256, 206, 152, 257, 256, 256, 255, 193, 257, 256, 256, 256, 255, 256, 257, 255, 256, 256, 225, 252, 257, 255, 256, 204, 254, 160, 198, 256, 230, 256, 256, 204, 256, 241, 207, 198]
theorem node76322 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76322 support demand code
    entries76322 ((insert 31 (insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 18 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76319 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    31 node76321 node76322
def entries76320 : List (Fin 2295 × ℕ) := [(43, 23), (177, 2), (179, 14), (269, 18), (466, 97), (512, 65), (514, 23), (572, 144), (588, 80), (621, 12), (643, 20), (680, 16), (681, 16), (690, 40), (737, 59), (817, 39), (843, 4), (851, 82), (852, 42), (870, 87), (873, 27), (897, 15), (898, 37), (920, 11), (921, 60), (934, 34), (944, 110), (945, 4), (946, 34), (959, 36), (965, 3), (966, 32), (970, 46), (973, 92), (978, 37), (993, 24), (1006, 20), (1007, 22), (1009, 9), (1012, 33), (1033, 11), (1034, 3), (1043, 7), (1061, 34), (1069, 16), (1076, 28), (1098, 6), (1100, 44), (1111, 5), (1113, 36), (1122, 15), (1123, 22), (1155, 32), (1159, 14), (1167, 73), (1175, 63), (1176, 12), (1177, 17), (1179, 85), (1182, 9), (1186, 25), (1223, 35), (1227, 131), (1233, 41), (1234, 38), (1235, 22), (1246, 21), (1247, 20), (1263, 35), (1293, 2), (1297, 7), (1488, 12), (1517, 37), (1572, 17), (1663, 7), (1667, 2)]
def cs76320 : List ℕ := [132, 0, 0, 0, 159, 0, 60, 256, 70, 0, 88, 256, 167, 27, 23, 0, 220, 257, 27, 144, 257, 189, 148, 167, 0, 0, 253, 303, 0, 39, 256, 257, 200, 256, 63, 256, 82, 257, 238, 255, 213, 178, 213, 161, 444, 256, 255, 354, 113, 255, 189, 419, 154, 256, 256, 257, 256, 257, 256, 256, 0, 257, 257, 257, 257, 257, 114, 119, 256, 256, 86, 143, 184, 256, 256, 233, 298, 257, 44, 256, 257, 36, 256, 257, 185, 256, 257, 257, 256, 256, 214, 210, 273, 256, 257, 257, 236, 256, 256, 255, 257, 257, 257, 70, 217, 256, 257, 256, 257, 110, 257, 256, 216, 256, 257, 256, 257, 257, 257, 184, 110, 256, 256, 256, 257, 201, 256, 258, 257, 255, 256, 257, 257, 257, 216, 257, 224, 257, 256, 256, 257, 218, 256, 187, 193, 257, 241, 256, 256, 158, 256, 197, 225, 197]
theorem node76320 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76320 support demand code
    entries76320 ((insert 18 (insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76318 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    18 node76319 node76320
theorem node76316 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    67 node76317 node76318
theorem node76307 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    81 node76315 node76316
def entries76313 : List (Fin 2295 × ℕ) := [(46, 1748), (179, 1781), (273, 3229), (469, 572), (475, 328), (484, 651), (512, 263), (514, 1589), (571, 3745), (585, 2214), (588, 269), (639, 400), (679, 1532), (680, 1088), (681, 3158), (690, 1075), (727, 933), (729, 384), (741, 768), (743, 825), (817, 920), (851, 1931), (858, 651), (859, 356), (860, 704), (869, 1603), (873, 1898), (892, 827), (896, 2774), (898, 1184), (900, 139), (902, 361), (916, 2076), (917, 3106), (921, 1010), (925, 195), (933, 1207), (944, 2292), (946, 1552), (958, 1026), (966, 1781), (972, 669), (973, 4619), (978, 1887), (985, 366), (1007, 757), (1011, 8), (1012, 1308), (1061, 1812), (1069, 1331), (1070, 30), (1096, 11), (1100, 1794), (1110, 546), (1113, 1131), (1114, 463), (1123, 2362), (1138, 581), (1143, 979), (1160, 127), (1167, 3494), (1173, 899), (1175, 1887), (1178, 34), (1179, 1677), (1182, 123), (1186, 1887), (1223, 3016), (1258, 576), (1263, 464), (1297, 1218), (1342, 2442), (1372, 2070), (1572, 204), (1623, 557), (1674, 618), (1859, 4481), (1991, 961), (2280, 584), (2283, 2221)]
def cs76313 : List ℕ := [7497, 572, 0, 328, 4947, 5132, 7498, 10000, 4540, 0, 1852, 10000, 10000, 3968, 2366, 0, 10000, 10001, 10000, 3745, 10000, 8645, 3818, 8461, 572, 366, 10000, 13835, 0, 4731, 10000, 9999, 10000, 10001, 2786, 9999, 2287, 10000, 10001, 9999, 5416, 10000, 5352, 6147, 27362, 10000, 9999, 11574, 5775, 8167, 9114, 16242, 10000, 9999, 10000, 10000, 10000, 10001, 9999, 9999, 195, 10000, 10000, 10001, 8823, 10001, 2610, 20136, 9999, 16712, 6108, 8836, 7832, 10001, 10000, 10001, 9945, 10001, 5018, 9999, 10001, 9999, 9999, 9999, 9991, 7669, 8893, 8208, 9999, 9905, 9493, 10000, 0, 9999, 8798, 10000, 10000, 10000, 10000, 9999, 9999, 10757, 9829, 10000, 6073, 10000, 10000, 9999, 9999, 4267, 10000, 9999, 7873, 8132, 10000, 10000, 10000, 9999, 10000, 6514, 7845, 9049, 9999, 10000, 9999, 9012, 10000, 10000, 9188, 10000, 10000, 10000, 10001, 9999, 8012, 9999, 8940, 9824, 9999, 9999, 9376, 8424, 10000, 10000, 8382, 8228, 9784, 10000, 9999, 9086, 9999, 9406, 8882, 7851]
theorem node76313 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 67 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76313 support demand code
    entries76313 ((insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 67 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries76314 : List (Fin 2295 × ℕ) := [(179, 50), (273, 57), (349, 19), (479, 55), (484, 10), (507, 54), (512, 3), (514, 69), (588, 17), (679, 83), (681, 90), (729, 11), (741, 20), (742, 4), (743, 42), (819, 1), (851, 2), (859, 70), (869, 45), (873, 77), (894, 54), (896, 2), (898, 42), (902, 28), (917, 47), (920, 4), (933, 8), (938, 71), (944, 11), (958, 56), (966, 31), (970, 27), (973, 108), (978, 67), (1009, 11), (1012, 29), (1041, 22), (1060, 13), (1061, 31), (1069, 38), (1070, 43), (1072, 2), (1073, 70), (1099, 22), (1100, 20), (1111, 36), (1113, 2), (1114, 7), (1123, 33), (1139, 6), (1143, 45), (1153, 10), (1167, 70), (1173, 25), (1175, 64), (1179, 13), (1182, 34), (1186, 29), (1223, 86), (1258, 6), (1261, 25), (1275, 9), (1281, 49), (1297, 44), (1354, 31), (1517, 10), (1555, 11), (1616, 6), (1623, 75), (1660, 11), (1674, 14), (1773, 50), (1859, 38), (1997, 2), (2000, 18), (2280, 64), (2286, 25)]
def cs76314 : List ℕ := [173, 25, 49, 51, 143, 48, 112, 255, 156, 56, 72, 255, 255, 102, 64, 0, 255, 256, 255, 0, 255, 145, 173, 256, 130, 0, 205, 250, 0, 180, 256, 255, 255, 256, 89, 166, 72, 255, 241, 255, 63, 255, 225, 137, 631, 255, 222, 327, 50, 202, 256, 312, 255, 256, 255, 256, 256, 256, 256, 256, 0, 177, 255, 255, 255, 256, 38, 528, 255, 27, 180, 255, 189, 255, 256, 178, 251, 257, 155, 256, 202, 256, 256, 255, 241, 211, 255, 256, 255, 256, 244, 248, 0, 256, 256, 255, 247, 256, 257, 256, 255, 256, 255, 256, 255, 256, 258, 256, 211, 42, 256, 255, 246, 203, 258, 256, 256, 255, 256, 244, 89, 209, 254, 257, 257, 214, 255, 255, 220, 255, 257, 242, 257, 256, 246, 256, 235, 202, 257, 255, 256, 213, 256, 255, 188, 255, 255, 243, 256, 213, 247, 255, 200, 207]
theorem node76314 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76314 support demand code
    entries76314 ((insert 69 (insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76309 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    69 node76313 node76314
def entries76311 : List (Fin 2295 × ℕ) := [(86, 47), (179, 136), (269, 201), (271, 68), (273, 60), (475, 111), (507, 232), (512, 210), (514, 360), (571, 116), (585, 21), (639, 141), (679, 251), (681, 346), (727, 85), (736, 53), (741, 222), (786, 49), (816, 154), (817, 96), (849, 80), (850, 126), (851, 109), (852, 460), (860, 33), (870, 213), (873, 466), (874, 248), (892, 261), (898, 75), (902, 216), (920, 26), (921, 171), (933, 8), (944, 428), (945, 55), (946, 94), (965, 74), (966, 35), (970, 123), (973, 363), (978, 460), (993, 61), (994, 42), (1012, 117), (1070, 71), (1073, 31), (1076, 103), (1100, 198), (1111, 232), (1122, 72), (1123, 262), (1153, 145), (1159, 36), (1167, 75), (1171, 4), (1174, 1), (1175, 384), (1186, 253), (1227, 127), (1233, 43), (1235, 36), (1247, 4), (1263, 20), (1281, 389), (1285, 122), (1293, 151), (1297, 106), (1316, 87), (1320, 9), (1364, 24), (1393, 35), (1572, 247), (1633, 38), (1703, 92), (1845, 56), (1859, 42), (1997, 77), (1999, 42), (2000, 48), (2240, 84)]
def cs76311 : List ℕ := [431, 0, 389, 905, 569, 42, 42, 1000, 175, 309, 570, 1001, 1000, 836, 0, 35, 1001, 1001, 1893, 116, 1001, 506, 303, 836, 855, 4, 1000, 1709, 35, 305, 1001, 1000, 1001, 1000, 465, 999, 144, 1001, 1000, 1001, 179, 1000, 823, 783, 2314, 875, 999, 1044, 377, 383, 1001, 1359, 709, 1000, 999, 1176, 1000, 999, 999, 999, 0, 845, 1001, 1000, 654, 1000, 4, 75, 1001, 999, 747, 995, 954, 1000, 999, 585, 1589, 1001, 175, 1001, 879, 999, 1001, 1001, 1000, 439, 999, 1000, 999, 1001, 1001, 940, 0, 1000, 1000, 1000, 681, 999, 999, 1001, 1000, 1001, 1001, 919, 738, 999, 1000, 1001, 1000, 340, 1001, 1001, 1000, 999, 886, 1000, 1000, 1000, 1000, 779, 729, 999, 999, 1000, 1000, 484, 999, 1000, 1000, 999, 954, 823, 999, 1001, 1000, 1000, 999, 532, 1001, 1001, 1000, 794, 812, 897, 999, 778, 795, 970, 1001, 731, 961, 1000, 893, 765]
theorem node76311 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76311 support demand code
    entries76311 ((insert 67 (insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries76312 : List (Fin 2295 × ℕ) := [(43, 16), (177, 22), (179, 48), (181, 52), (269, 26), (273, 35), (342, 8), (466, 85), (491, 21), (512, 58), (514, 27), (571, 64), (587, 17), (588, 81), (639, 6), (643, 62), (679, 71), (681, 79), (731, 4), (741, 33), (816, 19), (817, 25), (851, 85), (852, 21), (870, 85), (892, 64), (920, 22), (921, 66), (944, 101), (945, 40), (946, 40), (965, 46), (966, 5), (970, 27), (973, 105), (978, 66), (994, 1), (1033, 30), (1034, 6), (1069, 1), (1070, 25), (1073, 8), (1075, 1), (1097, 10), (1098, 9), (1100, 52), (1111, 49), (1113, 8), (1114, 17), (1122, 9), (1123, 70), (1143, 28), (1153, 25), (1155, 10), (1159, 6), (1167, 56), (1175, 85), (1177, 10), (1179, 34), (1186, 27), (1223, 65), (1263, 84), (1293, 39), (1297, 47), (1298, 21), (1342, 22), (1354, 13), (1403, 22), (1555, 26), (1572, 27), (1616, 6), (1745, 21), (1888, 22), (1998, 15), (2016, 15), (2061, 28)]
def cs76312 : List ℕ := [150, 0, 0, 15, 171, 0, 52, 256, 186, 0, 85, 256, 256, 15, 31, 0, 235, 238, 0, 86, 256, 201, 235, 256, 0, 0, 171, 276, 0, 101, 256, 256, 217, 256, 85, 256, 85, 256, 257, 256, 170, 256, 255, 172, 526, 258, 256, 322, 191, 249, 249, 403, 71, 256, 256, 257, 256, 256, 256, 256, 0, 173, 256, 257, 234, 257, 44, 71, 256, 256, 218, 180, 256, 238, 256, 125, 395, 256, 77, 256, 256, 256, 241, 256, 257, 182, 251, 255, 256, 256, 247, 207, 0, 255, 255, 257, 199, 255, 256, 254, 256, 256, 255, 256, 190, 256, 255, 255, 255, 61, 256, 255, 254, 175, 237, 255, 255, 256, 257, 208, 172, 257, 250, 256, 255, 190, 256, 256, 256, 256, 256, 256, 257, 255, 256, 256, 228, 206, 257, 255, 255, 191, 217, 223, 256, 242, 212, 237, 256, 196, 256, 255, 197, 221]
theorem node76312 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 67 (insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76312 support demand code
    entries76312 ((insert 18 (insert 67 (insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76310 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    18 node76311 node76312
theorem node76308 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    67 node76309 node76310
theorem node76279 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 27 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    92 node76307 node76308
def entries76305 : List (Fin 2295 × ℕ) := [(46, 32), (181, 12), (273, 21), (484, 12), (540, 29), (571, 12), (572, 13), (587, 11), (588, 1), (617, 5), (679, 12), (680, 20), (681, 13), (692, 3), (731, 4), (737, 35), (850, 24), (851, 7), (852, 14), (869, 42), (870, 8), (873, 20), (874, 7), (916, 52), (917, 3), (918, 9), (920, 3), (933, 7), (934, 15), (945, 2), (958, 24), (966, 10), (970, 13), (971, 17), (973, 41), (978, 22), (995, 6), (1007, 8), (1061, 18), (1069, 18), (1070, 3), (1073, 21), (1100, 10), (1111, 11), (1113, 15), (1123, 14), (1139, 5), (1143, 6), (1167, 29), (1175, 7), (1178, 16), (1186, 9), (1212, 11), (1223, 50), (1226, 4), (1293, 14), (1297, 11), (1375, 8), (1417, 8), (1442, 7), (1500, 5), (1502, 12), (1618, 10), (1619, 14), (1623, 33), (1674, 9), (1705, 2), (1766, 14), (1773, 16), (1845, 2), (1991, 6), (2160, 11), (2161, 7), (2280, 18)]
def cs76305 : List ℕ := [50, 0, 0, 24, 71, 26, 57, 71, 64, 38, 0, 100, 100, 27, 93, 0, 76, 182, 101, 25, 86, 57, 42, 100, 38, 0, 95, 0, 0, 75, 100, 100, 101, 100, 13, 101, 7, 92, 63, 160, 47, 101, 55, 58, 242, 99, 100, 119, 39, 100, 100, 177, 99, 82, 100, 104, 99, 99, 101, 228, 14, 101, 99, 73, 101, 99, 24, 249, 101, 96, 94, 101, 35, 88, 100, 76, 126, 100, 62, 100, 100, 101, 99, 99, 100, 86, 101, 101, 100, 100, 100, 87, 101, 100, 99, 100, 100, 100, 99, 100, 101, 100, 99, 99, 90, 100, 99, 100, 73, 61, 92, 100, 99, 80, 87, 100, 100, 100, 100, 69, 95, 99, 100, 100, 100, 70, 100, 100, 100, 99, 100, 89, 100, 100, 100, 100, 66, 96, 101, 101, 100, 86, 100, 101, 87, 95, 100, 101, 100, 80, 99, 98, 69, 72]
theorem node76305 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 17 (insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76305 support demand code
    entries76305 ((insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 59 (insert 17 (insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries76306 : List (Fin 2295 × ℕ) := [(21, 150), (46, 349), (273, 226), (387, 112), (484, 184), (540, 419), (542, 22), (572, 196), (576, 7), (587, 38), (588, 428), (617, 245), (678, 72), (679, 140), (680, 64), (813, 18), (817, 43), (835, 7), (850, 118), (851, 67), (869, 441), (870, 12), (873, 83), (874, 379), (917, 351), (921, 107), (933, 67), (934, 41), (938, 89), (946, 15), (958, 125), (960, 142), (966, 280), (970, 15), (973, 379), (978, 193), (1009, 169), (1012, 197), (1041, 35), (1060, 19), (1061, 212), (1069, 136), (1075, 32), (1081, 149), (1111, 57), (1123, 275), (1143, 21), (1167, 330), (1171, 12), (1173, 37), (1175, 228), (1186, 60), (1188, 122), (1212, 173), (1223, 180), (1226, 84), (1234, 52), (1253, 367), (1261, 171), (1272, 9), (1297, 118), (1342, 54), (1390, 5), (1433, 50), (1480, 115), (1502, 63), (1545, 100), (1555, 154), (1572, 174), (1619, 42), (1674, 118), (1773, 92), (1845, 55), (1846, 102), (2061, 44), (2280, 82)]
def cs76306 : List ℕ := [547, 0, 0, 268, 614, 184, 559, 614, 547, 42, 0, 1000, 999, 462, 1000, 0, 731, 1803, 956, 196, 1000, 559, 548, 988, 42, 12, 1000, 0, 0, 641, 1000, 458, 1000, 1000, 265, 1000, 434, 1000, 497, 911, 304, 1000, 758, 591, 2298, 773, 633, 1095, 369, 1000, 999, 1420, 1000, 1001, 999, 999, 1000, 1000, 1000, 288, 0, 1000, 1000, 988, 1000, 1000, 49, 2107, 876, 999, 520, 999, 946, 1000, 1000, 970, 1095, 1001, 632, 999, 1000, 998, 1000, 999, 1001, 977, 884, 721, 999, 999, 999, 1000, 940, 999, 1000, 1000, 935, 999, 999, 999, 999, 1115, 999, 998, 895, 984, 1000, 1000, 998, 233, 978, 1000, 1000, 943, 1000, 999, 999, 999, 1002, 607, 679, 1001, 1000, 933, 997, 971, 1001, 1000, 999, 1000, 999, 1000, 1002, 999, 482, 1000, 966, 898, 1000, 999, 940, 814, 1000, 999, 717, 607, 911, 999, 1000, 779, 1000, 861, 612, 884]
theorem node76306 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 17 (insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76306 support demand code
    entries76306 ((insert 59 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 17 (insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node76299 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 17 (insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 17 (insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    59 node76305 node76306
def entries76301 : List (Fin 2295 × ℕ) := [(177, 1), (179, 46), (484, 101), (494, 8), (540, 4), (572, 72), (576, 5), (588, 10), (679, 60), (680, 47), (681, 67), (692, 20), (693, 32), (737, 44), (741, 29), (743, 36), (842, 10), (852, 13), (869, 86), (873, 81), (874, 8), (898, 27), (916, 45), (917, 74), (918, 59), (920, 29), (921, 13), (934, 88), (938, 4), (944, 81), (957, 5), (958, 83), (966, 12), (969, 4), (970, 1), (973, 110), (1005, 1), (1007, 64), (1009, 7), (1011, 11), (1012, 1), (1044, 11), (1056, 2), (1061, 43), (1070, 11), (1073, 33), (1096, 17), (1100, 47), (1113, 28), (1114, 21), (1122, 38), (1123, 2), (1143, 24), (1155, 4), (1160, 6), (1167, 73), (1177, 16), (1179, 73), (1183, 14), (1212, 52), (1223, 155), (1247, 22), (1293, 41), (1297, 5), (1342, 6), (1349, 15), (1442, 52), (1488, 21), (1502, 24), (1618, 25), (1619, 26), (1623, 34), (1701, 2), (2280, 80)]
def cs76301 : List ℕ := [155, 0, 0, 0, 168, 101, 0, 176, 155, 51, 0, 241, 256, 89, 71, 0, 256, 159, 241, 72, 231, 0, 164, 226, 51, 0, 204, 0, 0, 127, 256, 256, 242, 256, 0, 256, 0, 218, 227, 446, 160, 256, 172, 138, 657, 255, 252, 297, 104, 255, 256, 403, 168, 256, 256, 255, 255, 256, 255, 596, 0, 209, 256, 192, 152, 255, 89, 494, 256, 112, 239, 255, 99, 152, 256, 205, 262, 256, 86, 257, 256, 255, 256, 256, 256, 220, 256, 255, 254, 256, 257, 166, 255, 256, 255, 255, 255, 255, 255, 257, 256, 256, 256, 256, 174, 254, 256, 257, 256, 125, 194, 257, 159, 142, 256, 256, 256, 256, 256, 170, 84, 255, 256, 256, 256, 190, 256, 257, 240, 257, 256, 234, 257, 256, 256, 256, 126, 256, 256, 257, 186, 239, 256, 257, 192, 249, 256, 257, 256, 210, 256, 202, 235, 191]
theorem node76301 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 17 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76301 support demand code
    entries76301 ((insert 17 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 59 (insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76303 : List (Fin 2295 × ℕ) := [(179, 22), (181, 8), (185, 7), (273, 16), (349, 17), (466, 12), (484, 30), (531, 4), (540, 9), (572, 21), (576, 21), (617, 11), (679, 31), (680, 3), (681, 22), (742, 22), (743, 12), (815, 1), (816, 13), (817, 9), (869, 23), (873, 24), (874, 42), (888, 4), (896, 24), (898, 15), (917, 45), (920, 14), (921, 9), (934, 5), (944, 19), (956, 1), (958, 21), (960, 6), (962, 2), (966, 22), (973, 42), (992, 2), (1005, 20), (1009, 16), (1012, 1), (1034, 18), (1041, 8), (1056, 7), (1060, 2), (1069, 16), (1070, 3), (1075, 3), (1082, 2), (1099, 23), (1113, 22), (1114, 1), (1122, 16), (1123, 40), (1143, 16), (1152, 5), (1153, 15), (1154, 34), (1167, 34), (1173, 8), (1175, 24), (1186, 5), (1223, 18), (1241, 17), (1253, 40), (1297, 1), (1342, 11), (1354, 5), (1403, 6), (1508, 4), (1572, 2), (1690, 1), (2146, 3), (2280, 38)]
def cs76303 : List ℕ := [70, 0, 0, 0, 58, 30, 0, 70, 58, 0, 0, 93, 100, 70, 9, 0, 100, 57, 100, 25, 100, 24, 83, 86, 0, 0, 100, 24, 0, 63, 100, 72, 84, 101, 32, 100, 40, 94, 93, 98, 26, 100, 80, 57, 315, 100, 72, 132, 34, 99, 100, 155, 63, 101, 99, 100, 100, 101, 100, 37, 0, 99, 101, 101, 100, 98, 12, 162, 100, 88, 84, 99, 99, 100, 100, 79, 110, 101, 32, 101, 101, 99, 100, 100, 100, 100, 73, 99, 99, 101, 95, 100, 54, 100, 100, 100, 97, 99, 99, 100, 99, 101, 96, 76, 68, 100, 99, 101, 100, 8, 81, 100, 71, 79, 100, 101, 99, 101, 98, 66, 29, 98, 100, 100, 100, 100, 100, 99, 90, 98, 101, 100, 98, 229, 72, 100, 92, 79, 100, 100, 100, 82, 101, 100, 99, 66, 100, 81, 100, 57, 100, 92, 96, 65]
theorem node76303 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 17 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 133 (insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76303 support demand code
    entries76303 ((insert 59 (insert 17 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 133 (insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries76304 : List (Fin 2295 × ℕ) := [(179, 22), (185, 17), (397, 1), (466, 18), (484, 35), (531, 1), (540, 17), (572, 36), (576, 17), (587, 5), (588, 8), (617, 19), (678, 24), (679, 13), (680, 13), (681, 4), (741, 4), (742, 5), (812, 6), (817, 15), (869, 17), (873, 9), (874, 32), (898, 26), (917, 40), (921, 15), (934, 8), (938, 20), (944, 32), (956, 3), (958, 25), (960, 11), (966, 6), (970, 4), (973, 38), (978, 5), (1009, 8), (1012, 26), (1034, 3), (1038, 5), (1040, 12), (1055, 13), (1061, 23), (1069, 9), (1070, 10), (1073, 5), (1100, 22), (1111, 6), (1114, 12), (1143, 6), (1167, 36), (1173, 17), (1175, 26), (1179, 1), (1186, 20), (1223, 11), (1226, 18), (1234, 4), (1253, 36), (1261, 3), (1354, 6), (1488, 21), (1555, 13), (1625, 2), (1690, 5), (1845, 4), (2280, 25)]
def cs76304 : List ℕ := [65, 0, 0, 0, 47, 35, 0, 65, 47, 0, 0, 82, 100, 42, 17, 0, 100, 58, 77, 36, 99, 0, 86, 99, 0, 0, 100, 0, 0, 49, 99, 56, 73, 100, 43, 99, 36, 101, 85, 89, 44, 100, 70, 58, 230, 100, 45, 127, 49, 99, 100, 141, 55, 92, 99, 100, 100, 99, 100, 19, 0, 100, 99, 99, 99, 94, 18, 173, 100, 99, 65, 99, 89, 100, 99, 99, 102, 100, 36, 99, 99, 99, 90, 99, 99, 98, 92, 67, 99, 94, 83, 95, 98, 99, 100, 100, 100, 99, 100, 99, 99, 100, 85, 99, 88, 100, 100, 99, 98, 24, 79, 98, 92, 100, 101, 99, 99, 100, 100, 69, 42, 99, 99, 94, 100, 99, 100, 100, 68, 99, 100, 100, 100, 41, 58, 100, 90, 97, 101, 99, 93, 99, 74, 100, 44, 70, 81, 100, 85, 87, 43, 90, 59, 71]
theorem node76304 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 133 (insert 59 (insert 17 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76304 support demand code
    entries76304 ((insert 133 (insert 59 (insert 17 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))))) : Finset (Fin 154)) ((insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76302 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 17 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 59 (insert 17 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    133 node76303 node76304
theorem node76300 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 17 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 17 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    59 node76301 node76302
theorem node76295 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 39 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    17 node76299 node76300
def entries76297 : List (Fin 2295 × ℕ) := [(46, 523), (177, 15), (273, 51), (349, 135), (466, 160), (479, 7), (484, 291), (571, 338), (587, 165), (588, 226), (617, 49), (639, 34), (679, 349), (681, 356), (737, 160), (741, 155), (742, 3), (813, 111), (819, 91), (873, 103), (874, 316), (896, 103), (898, 111), (902, 51), (925, 74), (933, 130), (934, 45), (938, 274), (944, 327), (958, 225), (960, 217), (966, 97), (970, 68), (973, 417), (978, 147), (1005, 18), (1006, 19), (1009, 118), (1012, 185), (1040, 15), (1049, 85), (1061, 193), (1069, 174), (1070, 205), (1073, 100), (1075, 24), (1100, 138), (1113, 90), (1123, 133), (1160, 5), (1167, 307), (1175, 277), (1186, 49), (1188, 70), (1212, 155), (1223, 262), (1226, 131), (1247, 72), (1253, 286), (1275, 102), (1286, 66), (1297, 114), (1308, 170), (1349, 76), (1375, 7), (1390, 58), (1401, 129), (1403, 146), (1433, 5), (1488, 37), (1545, 77), (1572, 17), (1580, 28), (1619, 42), (1623, 77), (1674, 23), (1845, 13), (2061, 17), (2280, 151)]
def cs76297 : List ℕ := [708, 0, 0, 0, 583, 291, 546, 743, 548, 42, 0, 708, 999, 447, 779, 0, 999, 1000, 780, 338, 999, 649, 668, 999, 42, 0, 818, 103, 0, 712, 998, 112, 1000, 999, 277, 1000, 286, 944, 720, 77, 548, 1000, 910, 711, 1984, 587, 663, 1363, 258, 698, 1001, 1478, 999, 1001, 1000, 1000, 999, 1001, 999, 999, 74, 1000, 816, 817, 1001, 1001, 85, 1685, 1000, 1000, 954, 1000, 648, 1000, 1000, 930, 1256, 1000, 239, 999, 1002, 2243, 999, 999, 1000, 1000, 1000, 1000, 1000, 1000, 945, 960, 1000, 999, 999, 1000, 999, 1000, 1001, 1000, 1000, 1006, 1000, 1001, 907, 1001, 1001, 999, 1000, 204, 931, 1001, 1001, 887, 1001, 1000, 1000, 998, 1000, 794, 875, 1000, 1000, 875, 999, 878, 1001, 1001, 1000, 999, 999, 1001, 1000, 1000, 853, 999, 885, 761, 999, 1000, 693, 842, 1000, 1000, 457, 794, 1000, 1000, 1000, 814, 1000, 1000, 621, 842]
theorem node76297 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76297 support demand code
    entries76297 ((insert 39 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 81 (insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries76298 : List (Fin 2295 × ℕ) := [(46, 83), (179, 34), (181, 4), (273, 90), (349, 8), (387, 19), (466, 44), (484, 80), (540, 1), (572, 128), (576, 19), (587, 4), (588, 57), (679, 43), (680, 75), (681, 21), (699, 28), (730, 7), (737, 56), (817, 16), (819, 9), (869, 6), (873, 84), (874, 15), (896, 70), (898, 19), (902, 19), (917, 56), (934, 33), (944, 70), (945, 14), (946, 37), (957, 31), (958, 83), (966, 36), (970, 7), (973, 99), (978, 51), (1007, 28), (1012, 29), (1034, 18), (1041, 6), (1061, 59), (1069, 18), (1070, 38), (1073, 22), (1096, 6), (1100, 62), (1111, 26), (1113, 26), (1123, 50), (1143, 43), (1153, 11), (1167, 101), (1173, 7), (1175, 56), (1178, 28), (1179, 28), (1183, 12), (1186, 12), (1212, 2), (1223, 88), (1235, 28), (1247, 17), (1253, 44), (1261, 12), (1297, 43), (1342, 6), (1401, 36), (1477, 32), (1488, 17), (1580, 25), (1616, 4), (1674, 14), (2061, 4), (2280, 24)]
def cs76298 : List ℕ := [176, 0, 0, 0, 157, 80, 97, 201, 132, 0, 0, 182, 256, 124, 159, 0, 256, 255, 204, 128, 257, 167, 142, 257, 0, 0, 256, 70, 0, 155, 237, 81, 255, 256, 63, 256, 44, 188, 211, 62, 214, 256, 169, 211, 557, 256, 239, 285, 98, 217, 86, 481, 254, 255, 256, 256, 256, 258, 256, 257, 0, 255, 255, 219, 203, 256, 63, 475, 257, 256, 100, 172, 182, 217, 256, 207, 288, 256, 55, 256, 256, 15, 256, 254, 256, 243, 257, 256, 256, 257, 257, 256, 217, 255, 255, 256, 222, 255, 255, 257, 256, 283, 256, 255, 203, 256, 255, 257, 257, 70, 255, 256, 153, 228, 255, 257, 257, 257, 256, 177, 94, 256, 257, 257, 257, 211, 256, 256, 256, 257, 257, 256, 256, 256, 236, 258, 180, 256, 257, 258, 221, 217, 257, 247, 119, 239, 257, 257, 257, 180, 234, 240, 152, 172]
theorem node76298 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 39 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76298 support demand code
    entries76298 ((insert 81 (insert 39 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76296 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    81 node76297 node76298
theorem node76281 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    39 node76295 node76296
def entries76293 : List (Fin 2295 × ℕ) := [(43, 39), (179, 1), (475, 24), (479, 10), (484, 18), (542, 11), (587, 20), (639, 3), (679, 3), (680, 24), (681, 28), (693, 21), (736, 52), (739, 9), (741, 26), (743, 2), (797, 5), (816, 21), (851, 6), (852, 9), (870, 18), (873, 6), (874, 22), (898, 13), (902, 9), (920, 26), (922, 20), (933, 4), (934, 12), (944, 70), (959, 13), (965, 6), (970, 15), (973, 47), (978, 31), (1009, 4), (1069, 25), (1070, 9), (1072, 1), (1073, 24), (1076, 4), (1113, 2), (1123, 5), (1152, 7), (1154, 9), (1160, 7), (1167, 12), (1174, 9), (1175, 2), (1178, 15), (1179, 6), (1223, 59), (1234, 23), (1241, 4), (1247, 8), (1293, 9), (1297, 32), (1308, 20), (1375, 1), (1386, 15), (1401, 11), (1403, 8), (1502, 8), (1619, 31), (1701, 16), (1703, 9), (1704, 6), (1845, 5), (1887, 2), (2061, 6), (2280, 8)]
def cs76293 : List ℕ := [59, 0, 0, 24, 84, 18, 39, 84, 59, 31, 0, 101, 101, 28, 61, 0, 77, 100, 101, 0, 81, 39, 57, 100, 31, 0, 43, 0, 0, 63, 100, 72, 101, 101, 11, 100, 6, 83, 94, 101, 26, 100, 98, 63, 191, 97, 100, 119, 70, 99, 96, 97, 19, 85, 101, 100, 99, 100, 101, 261, 0, 90, 101, 95, 100, 100, 21, 12, 100, 100, 85, 101, 97, 99, 101, 69, 146, 100, 6, 101, 85, 250, 100, 180, 99, 85, 93, 98, 100, 101, 100, 82, 100, 250, 100, 101, 45, 100, 99, 99, 101, 100, 98, 101, 101, 100, 99, 100, 99, 36, 100, 100, 99, 56, 73, 101, 99, 100, 100, 85, 99, 99, 100, 92, 99, 69, 100, 100, 99, 100, 47, 78, 99, 100, 100, 82, 83, 85, 99, 100, 55, 97, 100, 76, 43, 96, 100, 67, 100, 97, 99, 71, 64, 90]
theorem node76293 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 81 (insert 83 (insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76293 support demand code
    entries76293 ((insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 93 (insert 81 (insert 83 (insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries76294 : List (Fin 2295 × ℕ) := [(43, 34), (177, 9), (179, 16), (273, 5), (466, 23), (475, 10), (479, 19), (484, 24), (542, 6), (571, 5), (587, 39), (639, 5), (679, 13), (680, 14), (681, 8), (690, 21), (737, 29), (739, 12), (741, 13), (743, 26), (812, 2), (813, 9), (842, 2), (851, 11), (870, 24), (873, 15), (874, 29), (898, 11), (920, 23), (921, 32), (934, 7), (944, 60), (959, 23), (966, 20), (971, 3), (973, 45), (978, 29), (993, 9), (994, 7), (1012, 13), (1070, 13), (1073, 13), (1076, 16), (1098, 5), (1111, 12), (1114, 15), (1123, 22), (1126, 10), (1153, 4), (1154, 5), (1167, 10), (1174, 21), (1175, 19), (1177, 5), (1178, 3), (1212, 11), (1223, 43), (1257, 13), (1275, 4), (1295, 5), (1401, 5), (1572, 10), (1580, 3), (1619, 18), (1681, 16), (1751, 1), (1845, 6), (1846, 1), (2000, 18), (2016, 3), (2160, 18)]
def cs76294 : List ℕ := [66, 0, 0, 13, 76, 24, 37, 99, 46, 18, 0, 100, 100, 50, 51, 0, 90, 100, 99, 5, 80, 37, 78, 99, 18, 0, 49, 0, 0, 78, 100, 77, 96, 80, 40, 99, 11, 100, 99, 100, 34, 100, 99, 65, 203, 99, 76, 137, 62, 91, 100, 89, 25, 100, 101, 99, 99, 101, 99, 167, 0, 67, 84, 97, 101, 99, 8, 13, 100, 100, 99, 99, 99, 100, 100, 53, 146, 99, 20, 100, 91, 128, 99, 147, 101, 48, 100, 100, 100, 100, 101, 87, 100, 0, 99, 100, 77, 100, 99, 101, 100, 100, 100, 100, 84, 99, 100, 101, 100, 17, 100, 101, 100, 96, 80, 101, 100, 99, 100, 108, 71, 101, 100, 101, 100, 62, 100, 101, 101, 100, 86, 100, 100, 101, 65, 83, 100, 66, 101, 101, 58, 92, 100, 75, 71, 90, 97, 101, 102, 92, 101, 87, 79, 60]
theorem node76294 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 83 (insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76294 support demand code
    entries76294 ((insert 93 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 81 (insert 83 (insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76291 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 83 (insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 81 (insert 83 (insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    93 node76293 node76294
def entries76292 : List (Fin 2295 × ℕ) := [(43, 3), (177, 9), (179, 22), (273, 7), (475, 26), (479, 11), (484, 32), (507, 3), (540, 6), (542, 6), (572, 38), (587, 28), (680, 16), (681, 37), (690, 14), (737, 25), (739, 17), (816, 13), (842, 10), (850, 3), (851, 24), (852, 13), (870, 36), (873, 35), (897, 10), (917, 3), (920, 18), (921, 29), (934, 1), (943, 6), (944, 45), (946, 7), (965, 23), (970, 19), (973, 36), (978, 38), (993, 6), (1005, 13), (1042, 1), (1061, 6), (1067, 6), (1069, 7), (1070, 9), (1076, 2), (1098, 13), (1100, 3), (1111, 8), (1113, 1), (1114, 30), (1123, 31), (1152, 6), (1167, 21), (1175, 24), (1176, 6), (1178, 19), (1179, 13), (1223, 38), (1234, 8), (1257, 19), (1293, 17), (1401, 26), (1502, 2), (1516, 4), (1572, 14), (1605, 9), (1616, 13), (1703, 4), (1704, 3), (1849, 1)]
def cs76292 : List ℕ := [38, 0, 0, 29, 86, 32, 3, 86, 38, 3, 0, 100, 99, 35, 41, 0, 70, 101, 99, 38, 76, 3, 76, 87, 3, 0, 100, 0, 0, 41, 100, 61, 96, 102, 24, 100, 24, 99, 99, 100, 50, 100, 92, 91, 205, 99, 100, 99, 62, 99, 97, 138, 6, 101, 100, 100, 99, 99, 100, 163, 0, 65, 100, 90, 97, 100, 38, 24, 100, 40, 64, 70, 100, 100, 101, 86, 104, 101, 23, 104, 99, 0, 100, 190, 99, 101, 99, 101, 98, 101, 100, 93, 81, 100, 100, 96, 84, 99, 99, 100, 99, 101, 99, 88, 94, 94, 100, 101, 99, 38, 101, 100, 97, 80, 100, 91, 99, 100, 102, 66, 79, 101, 100, 99, 100, 61, 100, 99, 99, 101, 100, 100, 100, 100, 79, 70, 87, 89, 100, 99, 92, 100, 92, 61, 83, 92, 65, 84, 99, 72, 99, 85, 68, 49]
theorem node76292 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76292 support demand code
    entries76292 ((insert 81 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 83 (insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76289 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 83 (insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    81 node76291 node76292
def entries76290 : List (Fin 2295 × ℕ) := [(43, 27), (177, 81), (273, 138), (342, 371), (479, 5), (484, 331), (540, 6), (571, 33), (632, 169), (679, 187), (737, 247), (738, 148), (739, 110), (741, 17), (850, 103), (851, 132), (852, 172), (869, 228), (870, 207), (873, 341), (874, 99), (898, 320), (920, 413), (934, 53), (945, 117), (959, 54), (960, 232), (965, 129), (966, 2), (971, 67), (973, 472), (978, 321), (1007, 94), (1009, 71), (1012, 15), (1047, 131), (1049, 66), (1061, 17), (1070, 192), (1073, 211), (1076, 62), (1100, 60), (1110, 40), (1113, 19), (1114, 23), (1123, 49), (1148, 31), (1154, 156), (1167, 114), (1175, 77), (1176, 117), (1177, 184), (1179, 16), (1186, 23), (1212, 243), (1223, 565), (1234, 139), (1246, 6), (1247, 34), (1258, 23), (1316, 6), (1354, 159), (1370, 69), (1375, 19), (1403, 74), (1442, 126), (1572, 97), (1580, 126), (1660, 12), (1745, 27), (1845, 53), (1856, 77), (1887, 39), (1986, 164), (2022, 61), (2160, 83), (2161, 81), (2225, 18), (2294, 77)]
def cs76290 : List ℕ := [565, 0, 0, 103, 1000, 331, 27, 1000, 565, 0, 0, 1000, 999, 566, 285, 0, 896, 1000, 1000, 33, 823, 27, 478, 828, 0, 0, 506, 0, 0, 354, 1000, 544, 546, 983, 77, 1000, 132, 1000, 577, 1001, 217, 1000, 448, 561, 2078, 1001, 1000, 893, 420, 881, 999, 925, 617, 830, 999, 1001, 1000, 1000, 1000, 2156, 0, 981, 509, 998, 999, 1000, 514, 342, 999, 804, 801, 929, 359, 999, 999, 912, 1789, 999, 131, 1000, 690, 998, 999, 0, 999, 1000, 1000, 999, 1000, 999, 998, 825, 998, 998, 1000, 1000, 543, 999, 999, 998, 999, 1072, 997, 998, 999, 999, 1000, 999, 972, 355, 999, 1000, 998, 999, 533, 999, 998, 997, 999, 1100, 999, 998, 999, 998, 998, 688, 1000, 999, 999, 998, 997, 995, 998, 998, 998, 998, 947, 847, 998, 999, 998, 999, 999, 937, 998, 999, 983, 917, 999, 931, 912, 999, 978, 799]
theorem node76290 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 83 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76290 support demand code
    entries76290 ((insert 83 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node76283 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 59 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    83 node76289 node76290
def entries76287 : List (Fin 2295 × ℕ) := [(43, 20), (177, 10), (179, 19), (273, 12), (466, 38), (484, 27), (540, 16), (542, 5), (572, 27), (588, 34), (629, 13), (679, 22), (681, 14), (741, 14), (816, 24), (817, 5), (851, 27), (870, 27), (874, 73), (898, 26), (921, 29), (944, 34), (959, 15), (960, 14), (962, 5), (965, 14), (966, 11), (970, 11), (973, 39), (978, 21), (1009, 18), (1012, 11), (1022, 2), (1033, 4), (1034, 7), (1067, 1), (1068, 7), (1072, 11), (1073, 28), (1099, 14), (1100, 6), (1114, 14), (1123, 7), (1143, 9), (1154, 17), (1155, 1), (1167, 22), (1171, 15), (1173, 1), (1175, 32), (1212, 12), (1234, 6), (1253, 25), (1257, 9), (1269, 5), (1297, 4), (1308, 14), (1342, 2), (1370, 6), (1390, 6), (1403, 14), (1433, 4), (1516, 5), (1572, 13), (1660, 12), (1670, 19), (2000, 5), (2029, 10)]
def cs76287 : List ℕ := [73, 0, 0, 0, 52, 27, 20, 100, 25, 0, 0, 100, 100, 73, 41, 0, 100, 100, 100, 27, 100, 20, 89, 94, 0, 15, 79, 0, 0, 62, 100, 39, 73, 99, 33, 100, 52, 100, 97, 56, 27, 98, 68, 74, 227, 98, 27, 145, 56, 81, 100, 123, 28, 101, 100, 115, 100, 99, 100, 0, 0, 100, 75, 98, 100, 100, 16, 22, 100, 100, 62, 100, 99, 100, 95, 63, 197, 100, 41, 100, 99, 190, 90, 101, 99, 100, 100, 97, 101, 101, 80, 87, 98, 101, 100, 193, 99, 100, 100, 100, 101, 100, 99, 99, 100, 101, 99, 100, 101, 17, 101, 100, 99, 85, 68, 92, 100, 100, 101, 110, 71, 100, 100, 100, 101, 100, 101, 100, 100, 100, 100, 101, 100, 101, 100, 100, 100, 80, 101, 101, 101, 93, 91, 84, 62, 99, 91, 82, 101, 85, 76, 92, 101, 75]
theorem node76287 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 81 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76287 support demand code
    entries76287 ((insert 59 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 95 (insert 81 (insert 47 (insert 51 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries76288 : List (Fin 2295 × ℕ) := [(43, 64), (177, 49), (179, 34), (466, 46), (484, 8), (531, 149), (542, 16), (588, 106), (617, 53), (643, 27), (678, 38), (679, 64), (681, 47), (727, 5), (740, 13), (816, 54), (817, 7), (819, 15), (850, 52), (851, 60), (870, 60), (873, 47), (897, 29), (898, 6), (921, 57), (940, 35), (944, 103), (960, 38), (966, 50), (970, 31), (973, 109), (978, 49), (1009, 66), (1012, 23), (1021, 6), (1033, 15), (1070, 36), (1076, 60), (1098, 12), (1099, 18), (1100, 13), (1114, 31), (1122, 18), (1123, 91), (1143, 34), (1167, 31), (1173, 6), (1175, 40), (1186, 61), (1188, 44), (1212, 11), (1223, 54), (1235, 16), (1247, 16), (1253, 96), (1257, 27), (1370, 5), (1390, 44), (1403, 44), (1433, 18), (1572, 56), (1670, 24), (1892, 9), (1896, 12), (2061, 1)]
def cs76288 : List ℕ := [196, 0, 0, 52, 210, 8, 64, 256, 150, 0, 0, 256, 256, 196, 80, 0, 204, 256, 256, 0, 256, 64, 224, 212, 0, 0, 256, 0, 0, 147, 256, 233, 114, 242, 46, 256, 156, 201, 256, 144, 0, 256, 230, 125, 484, 257, 114, 337, 151, 240, 256, 173, 16, 199, 256, 256, 257, 256, 256, 54, 0, 255, 228, 239, 256, 256, 6, 31, 256, 255, 136, 255, 255, 250, 204, 242, 220, 256, 56, 255, 255, 409, 256, 257, 255, 246, 208, 234, 255, 256, 202, 196, 177, 257, 257, 71, 257, 257, 255, 255, 256, 256, 256, 208, 191, 256, 257, 256, 256, 72, 256, 256, 247, 156, 256, 255, 257, 256, 257, 149, 179, 256, 255, 256, 256, 219, 255, 256, 255, 256, 256, 180, 257, 256, 174, 255, 211, 140, 256, 255, 256, 225, 250, 255, 204, 149, 166, 255, 205, 234, 238, 255, 232, 205]
theorem node76288 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 59 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76288 support demand code
    entries76288 ((insert 95 (insert 59 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))))) : Finset (Fin 154)) ((insert 81 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76285 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 59 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 81 (insert 47 (insert 51 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    95 node76287 node76288
def entries76286 : List (Fin 2295 × ℕ) := [(177, 11), (179, 11), (342, 2), (466, 23), (484, 49), (540, 29), (542, 5), (572, 58), (576, 4), (577, 10), (587, 1), (588, 28), (643, 21), (678, 27), (680, 13), (731, 1), (816, 14), (817, 11), (833, 3), (851, 36), (869, 10), (870, 39), (873, 6), (874, 14), (920, 2), (921, 28), (944, 31), (945, 16), (946, 18), (965, 1), (966, 26), (970, 7), (973, 38), (978, 26), (1009, 1), (1012, 12), (1033, 6), (1034, 18), (1076, 1), (1098, 16), (1100, 3), (1111, 14), (1114, 19), (1123, 21), (1143, 8), (1155, 13), (1167, 25), (1173, 8), (1175, 28), (1177, 9), (1179, 24), (1186, 6), (1223, 28), (1234, 1), (1235, 3), (1257, 10), (1261, 7), (1293, 3), (1342, 7), (1477, 4), (1555, 13), (1572, 18), (1667, 5), (1704, 11), (1751, 2), (1846, 1), (2061, 10), (2280, 22)]
def cs76286 : List ℕ := [51, 0, 0, 0, 64, 49, 0, 87, 28, 0, 0, 100, 100, 20, 34, 0, 100, 100, 69, 58, 99, 0, 84, 85, 0, 0, 100, 0, 0, 55, 100, 51, 100, 99, 36, 100, 36, 100, 85, 100, 58, 100, 84, 75, 197, 100, 76, 103, 76, 85, 98, 161, 29, 98, 100, 99, 100, 100, 100, 30, 0, 89, 84, 99, 82, 100, 41, 35, 100, 101, 35, 55, 98, 94, 100, 85, 136, 100, 48, 100, 101, 14, 88, 99, 100, 99, 100, 99, 100, 100, 99, 100, 58, 99, 99, 100, 77, 100, 101, 99, 100, 100, 98, 70, 87, 100, 100, 100, 100, 30, 100, 100, 98, 67, 90, 100, 100, 99, 101, 75, 54, 102, 101, 100, 99, 82, 101, 101, 101, 100, 99, 100, 101, 100, 91, 100, 101, 90, 100, 100, 100, 88, 90, 72, 82, 99, 60, 93, 86, 76, 93, 89, 80, 70]
theorem node76286 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 59 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76286 support demand code
    entries76286 ((insert 81 (insert 59 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76284 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 59 (insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    81 node76285 node76286
theorem node76282 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    59 node76283 node76284
theorem node76280 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    67 node76281 node76282
theorem node76278 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    27 node76279 node76280
#print axioms node76278
end OmissionResidualCover31Fused
