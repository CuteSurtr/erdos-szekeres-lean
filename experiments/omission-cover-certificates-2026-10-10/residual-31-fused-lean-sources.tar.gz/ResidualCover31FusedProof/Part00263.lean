import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries78835 : List (Fin 2295 × ℕ) := [(164, 1)]
def cs78835 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node78835 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 81 (insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78835 support demand code
    entries78835 ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 95 (insert 81 (insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries78837 : List (Fin 2295 × ℕ) := [(892, 1)]
def cs78837 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node78837 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 81 (insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78837 support demand code
    entries78837 ((insert 95 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 55 (insert 81 (insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries78838 : List (Fin 2295 × ℕ) := [(23, 7), (46, 13), (179, 42), (471, 10), (514, 16), (551, 8), (552, 38), (571, 27), (581, 39), (588, 17), (622, 25), (625, 31), (675, 25), (739, 3), (741, 17), (813, 28), (842, 10), (869, 2), (870, 10), (889, 50), (890, 34), (891, 25), (893, 68), (894, 52), (895, 17), (896, 72), (900, 14), (902, 8), (908, 44), (916, 2), (917, 8), (921, 12), (925, 16), (938, 8), (952, 17), (957, 3), (958, 11), (971, 10), (972, 24), (973, 56), (978, 32), (1006, 13), (1009, 3), (1012, 7), (1043, 12), (1049, 18), (1056, 3), (1061, 6), (1069, 11), (1099, 6), (1110, 15), (1111, 6), (1126, 1), (1173, 2), (1178, 10), (1184, 10), (1185, 10), (1186, 32), (1223, 15), (1227, 14), (1281, 5), (1417, 2), (1466, 4), (1498, 18), (1517, 40), (1577, 18), (1620, 3), (1635, 3), (1636, 4), (1701, 3), (1705, 13), (1856, 2), (1859, 7), (1903, 3), (1950, 56), (1984, 4), (1991, 6), (2047, 1)]
def cs78838 : List ℕ := [27, 0, 15, 5, 22, 25, 82, 100, 71, 0, 16, 101, 101, 3, 35, 85, 71, 101, 32, 27, 101, 391, 62, 71, 100, 0, 101, 545, 100, 62, 101, 100, 101, 100, 2, 101, 426, 101, 56, 99, 101, 101, 100, 101, 426, 77, 411, 196, 42, 100, 100, 101, 82, 100, 117, 129, 101, 100, 100, 101, 101, 101, 100, 74, 101, 68, 177, 324, 84, 184, 100, 99, 100, 86, 101, 100, 84, 101, 138, 99, 100, 161, 101, 100, 100, 93, 76, 101, 100, 100, 100, 101, 99, 100, 84, 12, 102, 101, 99, 88, 100, 101, 76, 100, 99, 101, 100, 100, 99, 98, 101, 100, 64, 75, 67, 80, 100, 100, 101, 56, 92, 64, 100, 100, 89, 74, 101, 100, 62, 100, 100, 56, 101, 101, 91, 72, 81, 75, 101, 100, 100, 100, 101, 100, 101, 81, 91, 95, 100, 93, 96, 100, 100, 101]
theorem node78838 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 95 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78838 support demand code
    entries78838 ((insert 55 (insert 95 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78836 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 95 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    55 node78837 node78838
theorem node78833 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    95 node78835 node78836
def entries78834 : List (Fin 2295 × ℕ) := [(179, 78), (342, 21), (469, 6), (472, 31), (514, 45), (526, 23), (551, 94), (552, 8), (585, 117), (625, 100), (632, 10), (680, 41), (739, 4), (842, 67), (843, 6), (852, 2), (858, 5), (887, 30), (888, 3), (889, 63), (890, 49), (891, 150), (893, 134), (894, 102), (895, 94), (896, 74), (898, 4), (900, 38), (902, 50), (908, 120), (917, 41), (925, 65), (944, 26), (952, 65), (958, 60), (972, 49), (973, 108), (978, 67), (985, 23), (1007, 23), (1011, 5), (1034, 2), (1042, 31), (1043, 20), (1047, 30), (1049, 12), (1061, 45), (1099, 40), (1100, 12), (1110, 28), (1113, 10), (1114, 24), (1122, 2), (1123, 51), (1138, 15), (1167, 65), (1176, 31), (1177, 16), (1178, 53), (1179, 1), (1186, 24), (1212, 56), (1223, 36), (1273, 18), (1293, 5), (1358, 4), (1517, 117), (1537, 54), (1645, 23), (1705, 40), (1766, 26), (1773, 2), (1776, 10), (1798, 38), (1859, 11), (1903, 6), (1950, 65)]
def cs78834 : List ℕ := [51, 44, 123, 38, 38, 129, 135, 257, 219, 64, 83, 212, 257, 54, 40, 102, 245, 256, 135, 43, 256, 823, 82, 257, 257, 23, 257, 1161, 253, 90, 256, 256, 257, 256, 0, 227, 984, 256, 119, 256, 256, 256, 196, 257, 898, 253, 725, 400, 78, 256, 257, 257, 255, 257, 256, 428, 255, 256, 256, 255, 257, 33, 255, 256, 226, 238, 473, 732, 239, 272, 256, 256, 256, 246, 256, 257, 404, 256, 274, 257, 256, 30, 250, 241, 217, 257, 256, 257, 256, 257, 257, 250, 225, 256, 177, 257, 257, 257, 256, 237, 257, 263, 197, 256, 256, 257, 246, 257, 257, 201, 240, 258, 145, 182, 257, 257, 257, 256, 257, 160, 145, 257, 256, 257, 257, 173, 257, 257, 178, 257, 257, 251, 257, 257, 201, 226, 175, 257, 257, 257, 257, 245, 257, 257, 256, 218, 257, 253, 256, 249, 256, 257, 189, 212]
theorem node78834 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78834 support demand code
    entries78834 ((insert 81 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78829 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    81 node78833 node78834
def entries78831 : List (Fin 2295 × ℕ) := [(23, 128), (46, 29), (98, 258), (179, 335), (342, 176), (514, 119), (551, 250), (552, 170), (572, 77), (588, 25), (623, 72), (625, 503), (640, 35), (741, 148), (812, 93), (834, 89), (852, 35), (859, 72), (870, 119), (889, 354), (891, 390), (893, 657), (894, 589), (895, 201), (900, 44), (902, 101), (907, 77), (908, 348), (917, 7), (918, 279), (925, 100), (944, 22), (951, 56), (952, 205), (958, 231), (960, 72), (971, 51), (972, 68), (973, 490), (978, 213), (1007, 96), (1012, 35), (1042, 144), (1043, 104), (1047, 71), (1049, 17), (1061, 59), (1073, 104), (1100, 84), (1110, 86), (1113, 190), (1123, 45), (1155, 81), (1167, 201), (1173, 49), (1177, 140), (1178, 40), (1179, 177), (1184, 3), (1186, 265), (1212, 44), (1223, 52), (1235, 109), (1241, 61), (1254, 54), (1261, 94), (1273, 59), (1281, 70), (1417, 22), (1497, 25), (1517, 438), (1534, 132), (1537, 153), (1577, 71), (1623, 106), (1651, 90), (1701, 36), (1705, 5), (1798, 195), (1848, 8), (1921, 63), (1950, 313), (1991, 92), (2280, 151)]
def cs78831 : List ℕ := [122, 249, 418, 265, 269, 438, 538, 1000, 839, 285, 314, 999, 999, 411, 295, 491, 733, 1000, 894, 77, 999, 2478, 511, 740, 999, 0, 954, 3938, 1000, 515, 913, 999, 999, 1000, 49, 888, 3943, 999, 335, 1684, 1000, 1000, 984, 787, 3940, 1000, 1989, 1793, 335, 999, 1000, 999, 777, 1000, 1000, 1324, 1000, 1000, 1000, 1001, 1000, 567, 1000, 1000, 999, 1001, 1814, 2845, 1000, 77, 1000, 999, 1000, 1000, 923, 1001, 1502, 1000, 1339, 1000, 1000, 999, 1000, 997, 865, 1000, 1001, 1000, 1000, 1000, 999, 858, 999, 1000, 671, 1001, 1000, 999, 1001, 924, 1000, 1000, 1000, 852, 1001, 1000, 1000, 999, 1000, 729, 929, 999, 787, 482, 941, 1000, 1001, 1000, 1000, 734, 677, 764, 1000, 1001, 1000, 765, 1000, 1001, 837, 1001, 1000, 1000, 1001, 1000, 1001, 1000, 783, 1001, 1000, 1000, 1000, 895, 893, 1000, 1001, 978, 926, 1000, 892, 848, 987, 1001, 1001, 1000]
theorem node78831 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78831 support demand code
    entries78831 ((insert 69 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries78832 : List (Fin 2295 × ℕ) := [(25, 24), (46, 63), (98, 49), (179, 81), (273, 63), (472, 2), (478, 45), (506, 3), (550, 38), (551, 60), (552, 96), (582, 7), (583, 37), (625, 89), (639, 18), (675, 36), (736, 8), (741, 39), (812, 27), (851, 32), (858, 70), (889, 104), (890, 32), (891, 80), (893, 89), (894, 80), (895, 42), (896, 54), (900, 3), (902, 21), (908, 131), (925, 17), (944, 37), (951, 33), (952, 4), (958, 98), (959, 13), (960, 69), (970, 7), (971, 32), (973, 118), (978, 62), (1007, 13), (1012, 24), (1022, 4), (1042, 20), (1047, 44), (1060, 9), (1061, 29), (1073, 23), (1099, 4), (1100, 32), (1110, 8), (1113, 56), (1123, 27), (1167, 60), (1177, 53), (1179, 17), (1183, 4), (1186, 77), (1235, 29), (1241, 14), (1263, 58), (1293, 10), (1297, 17), (1379, 6), (1494, 53), (1495, 12), (1504, 41), (1528, 31), (1534, 12), (1577, 39), (1578, 6), (1635, 2), (1667, 17), (1779, 3), (1845, 14), (1849, 6), (1859, 28), (1950, 116), (1991, 29)]
def cs78832 : List ℕ := [28, 0, 2, 0, 110, 81, 206, 256, 227, 3, 118, 73, 255, 52, 108, 251, 148, 255, 83, 0, 255, 755, 81, 256, 256, 0, 251, 1035, 220, 144, 70, 256, 255, 256, 0, 256, 1124, 255, 81, 0, 256, 255, 256, 256, 778, 255, 666, 420, 81, 256, 190, 255, 256, 255, 279, 349, 255, 256, 256, 257, 255, 195, 256, 256, 256, 255, 467, 565, 246, 57, 257, 256, 256, 255, 255, 255, 401, 255, 176, 256, 256, 204, 257, 255, 115, 255, 255, 255, 254, 251, 216, 256, 256, 256, 156, 255, 254, 255, 255, 240, 254, 255, 192, 256, 255, 254, 255, 256, 255, 126, 244, 256, 171, 209, 254, 255, 255, 255, 255, 194, 207, 216, 255, 251, 255, 178, 255, 255, 254, 254, 255, 255, 255, 255, 255, 256, 202, 255, 255, 255, 254, 205, 229, 255, 190, 211, 255, 255, 243, 229, 223, 248, 212, 230]
theorem node78832 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 69 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78832 support demand code
    entries78832 ((insert 39 (insert 69 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78830 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    39 node78831 node78832
theorem node78815 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 47 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    69 node78829 node78830
def entries78825 : List (Fin 2295 × ℕ) := [(159, 1)]
def cs78825 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node78825 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 85 (insert 70 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78825 support demand code
    entries78825 ((insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 85 (insert 70 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries78827 : List (Fin 2295 × ℕ) := [(890, 1)]
def cs78827 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node78827 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 85 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 70 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78827 support demand code
    entries78827 ((insert 85 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 55 (insert 70 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries78828 : List (Fin 2295 × ℕ) := [(46, 27), (179, 96), (469, 5), (491, 36), (507, 67), (514, 82), (550, 29), (552, 42), (579, 13), (583, 30), (625, 105), (741, 62), (742, 14), (780, 3), (781, 18), (869, 20), (870, 7), (891, 27), (892, 35), (894, 183), (895, 91), (896, 132), (899, 34), (901, 2), (902, 40), (907, 36), (908, 84), (918, 20), (922, 18), (924, 2), (925, 77), (944, 8), (951, 11), (952, 33), (960, 4), (971, 54), (972, 41), (973, 130), (978, 55), (985, 12), (1007, 52), (1011, 13), (1012, 27), (1022, 26), (1043, 24), (1061, 19), (1073, 48), (1100, 5), (1110, 19), (1113, 26), (1114, 8), (1123, 10), (1149, 8), (1154, 8), (1167, 44), (1178, 11), (1179, 12), (1185, 35), (1186, 55), (1212, 27), (1223, 60), (1263, 7), (1293, 10), (1417, 18), (1459, 42), (1517, 75), (1528, 23), (1537, 111), (1607, 50), (1627, 2), (1641, 36), (1645, 32), (1669, 6), (1773, 28), (1778, 2), (1856, 8), (1950, 76), (1991, 33), (2122, 1)]
def cs78828 : List ℕ := [62, 5, 113, 0, 62, 113, 166, 256, 256, 67, 82, 205, 256, 113, 57, 71, 255, 256, 185, 0, 255, 627, 96, 256, 256, 12, 256, 952, 257, 201, 240, 256, 250, 256, 0, 256, 671, 243, 96, 256, 257, 256, 196, 189, 740, 256, 883, 0, 96, 257, 257, 257, 255, 255, 256, 149, 256, 396, 256, 255, 258, 141, 256, 137, 257, 256, 205, 654, 256, 255, 440, 257, 72, 197, 255, 244, 286, 256, 217, 256, 257, 256, 255, 256, 191, 85, 257, 257, 256, 256, 256, 256, 258, 255, 185, 255, 255, 257, 257, 256, 256, 281, 258, 254, 256, 255, 257, 255, 256, 253, 255, 255, 165, 195, 236, 255, 256, 256, 255, 191, 193, 139, 238, 255, 256, 182, 255, 256, 187, 255, 213, 200, 255, 255, 256, 199, 185, 215, 255, 255, 256, 235, 255, 256, 256, 219, 237, 256, 255, 229, 232, 247, 250, 254]
theorem node78828 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 85 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78828 support demand code
    entries78828 ((insert 55 (insert 85 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 70 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78826 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 85 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 85 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 70 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    55 node78827 node78828
theorem node78821 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 70 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    85 node78825 node78826
def entries78823 : List (Fin 2295 × ℕ) := [(99, 35), (342, 41), (469, 77), (472, 7), (482, 63), (514, 61), (552, 69), (580, 32), (583, 33), (624, 30), (625, 117), (632, 65), (675, 21), (755, 3), (858, 16), (860, 42), (887, 65), (888, 9), (891, 103), (894, 167), (895, 17), (896, 87), (901, 77), (908, 35), (922, 2), (924, 57), (925, 77), (926, 9), (944, 41), (951, 33), (958, 36), (959, 8), (960, 60), (972, 14), (973, 116), (978, 87), (985, 8), (1007, 1), (1012, 13), (1043, 34), (1047, 37), (1049, 33), (1100, 28), (1110, 27), (1113, 10), (1114, 8), (1122, 3), (1123, 3), (1149, 8), (1154, 1), (1155, 35), (1167, 52), (1173, 8), (1177, 49), (1179, 51), (1186, 27), (1212, 61), (1223, 11), (1293, 8), (1308, 4), (1358, 34), (1488, 4), (1497, 1), (1517, 101), (1535, 9), (1541, 5), (1572, 25), (1604, 3), (1623, 13), (1627, 19), (1645, 63), (1667, 28), (1705, 25), (1791, 2), (1856, 23), (1858, 15), (1861, 13), (1886, 8), (1950, 74), (2023, 17)]
def cs78823 : List ℕ := [77, 77, 29, 13, 47, 82, 117, 255, 146, 0, 74, 255, 256, 35, 19, 69, 211, 256, 188, 94, 255, 466, 0, 171, 238, 8, 229, 866, 257, 65, 255, 256, 257, 256, 8, 255, 599, 256, 0, 256, 256, 219, 212, 256, 612, 256, 753, 0, 0, 256, 257, 107, 255, 256, 256, 255, 256, 284, 256, 256, 256, 233, 255, 240, 257, 253, 335, 489, 256, 255, 33, 460, 118, 257, 256, 225, 489, 256, 175, 255, 257, 255, 255, 257, 120, 256, 255, 142, 294, 227, 254, 224, 256, 241, 212, 255, 256, 257, 256, 255, 254, 256, 246, 206, 256, 256, 256, 222, 256, 162, 256, 256, 122, 257, 197, 254, 256, 256, 257, 165, 176, 252, 255, 255, 256, 185, 256, 256, 255, 255, 256, 218, 256, 256, 255, 256, 240, 256, 256, 256, 255, 245, 256, 251, 257, 241, 256, 256, 255, 256, 256, 255, 256, 256]
theorem node78823 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78823 support demand code
    entries78823 ((insert 70 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 71 (insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78824 : List (Fin 2295 × ℕ) := [(46, 12), (179, 55), (273, 20), (342, 8), (469, 23), (472, 56), (482, 33), (514, 44), (534, 1), (552, 145), (571, 34), (572, 37), (583, 110), (625, 50), (664, 26), (843, 64), (858, 2), (859, 5), (860, 41), (870, 20), (871, 19), (892, 63), (894, 72), (895, 78), (896, 95), (899, 48), (907, 5), (908, 90), (922, 43), (944, 17), (951, 3), (952, 83), (958, 45), (971, 62), (972, 8), (973, 114), (978, 41), (1006, 38), (1007, 40), (1011, 39), (1012, 4), (1034, 19), (1049, 25), (1060, 4), (1061, 32), (1096, 11), (1099, 12), (1100, 36), (1110, 6), (1122, 8), (1123, 24), (1138, 15), (1154, 7), (1167, 60), (1173, 13), (1177, 35), (1178, 35), (1179, 42), (1183, 22), (1186, 66), (1212, 5), (1247, 10), (1269, 3), (1310, 33), (1335, 18), (1375, 25), (1517, 112), (1545, 7), (1583, 4), (1603, 22), (1622, 26), (1645, 45), (1705, 18), (1773, 9), (1861, 76), (1870, 2), (1950, 101)]
def cs78824 : List ℕ := [76, 23, 56, 76, 0, 33, 157, 256, 147, 0, 120, 253, 256, 20, 43, 145, 209, 256, 152, 71, 256, 487, 55, 146, 257, 0, 252, 901, 223, 76, 256, 257, 256, 255, 13, 214, 608, 256, 55, 257, 255, 256, 223, 242, 657, 256, 753, 19, 88, 255, 256, 255, 257, 255, 255, 255, 256, 205, 256, 256, 179, 195, 256, 223, 204, 256, 355, 588, 210, 256, 86, 0, 107, 256, 255, 256, 270, 256, 155, 255, 255, 207, 256, 256, 166, 255, 170, 244, 256, 233, 255, 256, 255, 219, 167, 255, 255, 256, 256, 255, 255, 255, 211, 186, 255, 256, 251, 243, 219, 218, 255, 255, 167, 183, 228, 255, 255, 256, 255, 188, 134, 256, 255, 255, 255, 227, 256, 256, 210, 255, 255, 209, 255, 255, 212, 222, 162, 255, 256, 255, 255, 245, 255, 255, 256, 255, 256, 255, 255, 251, 246, 255, 255, 207]
theorem node78824 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 70 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78824 support demand code
    entries78824 ((insert 71 (insert 70 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78822 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 70 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    71 node78823 node78824
theorem node78817 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 57 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    70 node78821 node78822
def entries78819 : List (Fin 2295 × ℕ) := [(46, 127), (100, 327), (179, 85), (273, 43), (342, 120), (469, 240), (483, 135), (484, 67), (514, 308), (552, 191), (571, 151), (581, 49), (585, 170), (622, 168), (623, 129), (625, 263), (639, 177), (675, 217), (781, 8), (842, 150), (858, 81), (859, 191), (891, 468), (892, 127), (895, 204), (896, 629), (900, 182), (907, 12), (908, 391), (916, 9), (919, 101), (920, 80), (924, 116), (925, 230), (952, 392), (971, 71), (972, 165), (973, 472), (978, 124), (1007, 93), (1009, 89), (1011, 213), (1021, 103), (1041, 49), (1043, 102), (1048, 73), (1049, 121), (1061, 134), (1099, 65), (1100, 50), (1110, 57), (1113, 10), (1122, 133), (1123, 56), (1139, 37), (1141, 16), (1149, 35), (1154, 52), (1167, 221), (1177, 6), (1178, 162), (1179, 145), (1182, 24), (1185, 23), (1186, 183), (1212, 124), (1223, 37), (1266, 73), (1279, 30), (1374, 43), (1517, 373), (1545, 165), (1585, 30), (1669, 15), (1705, 119), (1773, 73), (1861, 171), (1870, 79), (1886, 117), (1903, 57), (1921, 137), (1950, 368), (2090, 37), (2236, 6)]
def cs78819 : List ℕ := [208, 270, 0, 171, 191, 232, 654, 1000, 596, 0, 479, 851, 999, 327, 200, 191, 748, 999, 835, 268, 1000, 2138, 85, 574, 596, 0, 999, 3332, 1000, 285, 1000, 1000, 1000, 999, 0, 1000, 2911, 1000, 85, 1000, 1000, 1000, 692, 999, 3111, 1000, 2714, 0, 85, 999, 1000, 1000, 1000, 998, 999, 1172, 999, 0, 1000, 1000, 999, 794, 1000, 469, 971, 871, 1302, 2268, 930, 1787, 1000, 1000, 497, 824, 999, 943, 1638, 1000, 215, 1000, 1000, 1000, 771, 1000, 441, 999, 1000, 1000, 1000, 918, 1000, 943, 999, 1001, 783, 1000, 999, 999, 1000, 999, 1001, 999, 1000, 600, 1000, 999, 999, 999, 1001, 873, 999, 999, 522, 814, 946, 781, 1000, 1000, 999, 764, 392, 999, 1001, 1000, 1000, 999, 1000, 1089, 688, 1000, 1000, 699, 1000, 1000, 834, 752, 688, 1000, 1000, 1000, 1000, 1000, 1000, 1001, 1000, 904, 1000, 1000, 1001, 887, 1000, 962, 1000, 874]
theorem node78819 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78819 support demand code
    entries78819 ((insert 57 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries78820 : List (Fin 2295 × ℕ) := [(46, 235), (86, 17), (179, 270), (273, 65), (342, 102), (469, 248), (472, 268), (474, 3), (484, 216), (490, 249), (496, 110), (512, 11), (514, 259), (530, 104), (552, 258), (584, 7), (625, 567), (639, 176), (741, 45), (781, 48), (813, 41), (819, 73), (843, 16), (859, 187), (887, 74), (891, 314), (895, 317), (899, 120), (900, 87), (902, 35), (908, 379), (918, 143), (925, 194), (944, 97), (951, 199), (952, 150), (953, 96), (958, 380), (960, 225), (972, 129), (973, 437), (977, 30), (978, 181), (1007, 75), (1009, 4), (1012, 108), (1021, 16), (1039, 38), (1047, 97), (1049, 64), (1061, 244), (1100, 128), (1113, 104), (1114, 58), (1123, 130), (1143, 43), (1154, 68), (1160, 23), (1167, 303), (1173, 92), (1177, 200), (1179, 163), (1182, 31), (1186, 2), (1212, 191), (1272, 6), (1279, 216), (1293, 69), (1374, 20), (1488, 22), (1516, 60), (1517, 264), (1528, 102), (1534, 31), (1556, 51), (1585, 73), (1622, 53), (1645, 55), (1667, 58), (1705, 17), (1728, 2), (1950, 268), (1991, 119), (2236, 21)]
def cs78820 : List ℕ := [0, 464, 268, 3, 0, 432, 748, 1000, 565, 0, 270, 997, 1000, 104, 235, 258, 1000, 1000, 787, 74, 999, 926, 270, 585, 993, 0, 901, 2199, 1001, 505, 1001, 974, 999, 1000, 92, 452, 2620, 999, 270, 1000, 1000, 999, 716, 1001, 1829, 1000, 1432, 0, 270, 1001, 999, 565, 1000, 999, 1000, 1000, 999, 0, 1000, 1000, 1002, 533, 1000, 707, 779, 1000, 1514, 1953, 912, 127, 1001, 1001, 460, 999, 845, 999, 1386, 1000, 330, 1001, 1001, 999, 891, 1000, 501, 999, 1000, 1000, 1000, 996, 1000, 1000, 1001, 999, 516, 999, 999, 1001, 999, 999, 1001, 1000, 1001, 999, 1000, 999, 998, 998, 1001, 581, 999, 999, 623, 787, 999, 1000, 999, 1000, 998, 637, 717, 998, 1000, 1000, 999, 912, 1000, 999, 1000, 998, 1000, 1000, 999, 999, 862, 922, 831, 1000, 999, 1000, 763, 999, 1000, 1000, 991, 817, 1000, 935, 1000, 838, 1000, 873, 892, 653]
theorem node78820 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 57 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78820 support demand code
    entries78820 ((insert 69 (insert 57 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node78818 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 57 (insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    69 node78819 node78820
theorem node78816 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    57 node78817 node78818
theorem node78801 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    47 node78815 node78816
def entries78813 : List (Fin 2295 × ℕ) := [(83, 14), (177, 12), (342, 32), (494, 44), (540, 16), (542, 11), (551, 58), (619, 33), (620, 13), (622, 29), (640, 4), (675, 18), (681, 2), (743, 13), (780, 5), (784, 13), (850, 15), (851, 42), (858, 60), (869, 22), (870, 34), (871, 16), (872, 66), (873, 10), (874, 9), (880, 26), (907, 58), (908, 51), (915, 24), (916, 11), (918, 54), (924, 25), (925, 76), (944, 39), (949, 38), (951, 96), (953, 41), (958, 63), (959, 25), (960, 76), (973, 142), (977, 20), (978, 30), (1006, 12), (1009, 12), (1012, 26), (1043, 21), (1049, 33), (1060, 4), (1061, 29), (1100, 22), (1113, 30), (1114, 18), (1122, 3), (1123, 10), (1128, 16), (1143, 4), (1154, 25), (1167, 72), (1175, 22), (1177, 20), (1179, 42), (1183, 38), (1186, 38), (1212, 4), (1223, 42), (1254, 28), (1268, 8), (1286, 1), (1305, 2), (1346, 4), (1349, 59), (1362, 23), (1447, 4), (1466, 9), (1469, 118), (1493, 63), (1498, 27), (1501, 9), (1517, 4), (1522, 38), (1537, 73), (1545, 17), (1582, 5), (1585, 29), (1590, 30), (1628, 17), (1641, 68), (1667, 22), (1705, 19), (1861, 14), (1950, 14), (1991, 27)]
def cs78813 : List ℕ := [56, 28, 73, 34, 112, 143, 86, 257, 157, 0, 19, 175, 256, 220, 86, 209, 247, 256, 254, 8, 256, 0, 84, 257, 256, 0, 256, 423, 256, 42, 256, 256, 256, 257, 48, 256, 708, 255, 14, 256, 255, 256, 253, 222, 451, 256, 591, 256, 130, 257, 255, 608, 184, 257, 257, 255, 255, 257, 256, 257, 629, 256, 256, 256, 257, 256, 461, 438, 256, 255, 565, 256, 255, 255, 239, 256, 339, 256, 171, 257, 257, 631, 257, 256, 162, 257, 256, 256, 256, 257, 256, 251, 256, 256, 149, 256, 257, 256, 257, 257, 256, 256, 255, 255, 257, 256, 255, 257, 255, 125, 256, 256, 115, 256, 256, 256, 256, 256, 255, 184, 253, 256, 222, 256, 256, 238, 255, 257, 257, 256, 257, 256, 256, 257, 207, 237, 205, 256, 256, 256, 212, 245, 256, 255, 203, 245, 256, 256, 256, 240, 256, 230, 251, 222]
theorem node78813 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 51 (insert 60 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78813 support demand code
    entries78813 ((insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 70 (insert 51 (insert 60 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78814 : List (Fin 2295 × ℕ) := [(83, 18), (97, 12), (100, 3), (179, 52), (342, 19), (472, 6), (474, 10), (475, 24), (479, 41), (494, 52), (531, 5), (542, 76), (551, 46), (552, 82), (620, 27), (622, 15), (625, 30), (632, 56), (675, 86), (813, 38), (851, 24), (858, 28), (860, 29), (869, 74), (870, 26), (871, 46), (873, 31), (878, 61), (880, 15), (886, 22), (898, 3), (899, 6), (901, 25), (907, 71), (908, 69), (915, 57), (918, 90), (924, 9), (925, 34), (944, 55), (951, 44), (952, 20), (958, 75), (959, 35), (960, 26), (962, 18), (966, 1), (972, 24), (973, 125), (977, 13), (978, 46), (1006, 20), (1009, 3), (1011, 16), (1012, 14), (1043, 23), (1047, 4), (1049, 32), (1056, 3), (1061, 36), (1100, 44), (1110, 9), (1113, 32), (1114, 12), (1123, 20), (1154, 7), (1155, 10), (1167, 65), (1173, 19), (1177, 65), (1179, 48), (1186, 37), (1212, 28), (1268, 36), (1272, 4), (1293, 20), (1310, 50), (1354, 13), (1375, 8), (1469, 4), (1488, 2), (1493, 42), (1498, 58), (1534, 21), (1541, 19), (1560, 10), (1590, 13), (1636, 13), (1667, 12), (1739, 17), (1861, 90), (1950, 45), (1982, 1), (1991, 17)]
def cs78814 : List ℕ := [90, 0, 6, 124, 65, 58, 28, 258, 74, 0, 90, 242, 256, 133, 138, 256, 189, 257, 257, 36, 256, 0, 97, 257, 257, 22, 258, 411, 256, 121, 257, 257, 257, 256, 34, 211, 674, 256, 52, 257, 257, 243, 257, 228, 424, 256, 673, 257, 123, 257, 257, 287, 257, 257, 257, 255, 258, 220, 257, 257, 425, 256, 258, 256, 249, 254, 430, 491, 257, 257, 64, 256, 256, 257, 256, 256, 431, 256, 145, 256, 256, 502, 257, 258, 235, 256, 227, 257, 256, 238, 257, 250, 256, 258, 187, 256, 255, 256, 257, 257, 256, 255, 257, 251, 256, 255, 257, 245, 256, 165, 256, 257, 256, 256, 212, 256, 256, 256, 256, 206, 256, 257, 256, 256, 256, 232, 256, 256, 256, 257, 255, 255, 256, 255, 255, 247, 232, 255, 256, 255, 218, 243, 251, 256, 255, 238, 256, 255, 256, 241, 255, 255, 255, 200]
theorem node78814 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 60 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78814 support demand code
    entries78814 ((insert 70 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 51 (insert 60 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78811 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 60 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 51 (insert 60 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    70 node78813 node78814
def entries78812 : List (Fin 2295 × ℕ) := [(83, 95), (179, 126), (472, 194), (478, 5), (495, 199), (531, 97), (542, 165), (551, 340), (552, 337), (588, 44), (619, 46), (620, 95), (624, 87), (625, 316), (631, 224), (632, 154), (674, 2), (675, 113), (731, 124), (743, 54), (813, 87), (817, 24), (819, 39), (842, 41), (843, 221), (858, 50), (869, 217), (871, 215), (872, 396), (878, 191), (879, 35), (880, 129), (886, 2), (898, 98), (899, 83), (901, 37), (907, 490), (908, 107), (915, 26), (918, 428), (925, 341), (944, 235), (951, 121), (952, 24), (958, 319), (959, 99), (960, 275), (966, 47), (971, 15), (973, 541), (978, 264), (1012, 1), (1043, 144), (1049, 140), (1061, 37), (1097, 70), (1099, 4), (1100, 150), (1110, 102), (1113, 59), (1114, 158), (1122, 99), (1123, 79), (1143, 65), (1167, 195), (1177, 130), (1179, 140), (1185, 119), (1186, 264), (1223, 107), (1235, 5), (1254, 1), (1281, 85), (1358, 15), (1517, 179), (1541, 70), (1585, 65), (1590, 44), (1641, 340), (1667, 37), (1705, 121), (1751, 55), (1861, 208), (1950, 385)]
def cs78812 : List ℕ := [415, 1, 279, 293, 113, 0, 229, 1000, 692, 0, 208, 907, 1000, 708, 356, 885, 612, 1000, 1001, 0, 1001, 0, 268, 1000, 1000, 2, 999, 1548, 1000, 548, 999, 1000, 772, 999, 164, 1000, 3124, 1001, 126, 1000, 801, 1001, 1000, 924, 1818, 1000, 2459, 1000, 250, 997, 999, 145, 1001, 1000, 1090, 1076, 1000, 1001, 1000, 1000, 1289, 665, 1000, 999, 1000, 830, 1798, 1783, 998, 1000, 1000, 1001, 997, 908, 846, 1001, 1440, 1000, 347, 999, 1000, 1767, 1000, 999, 687, 1001, 873, 1001, 1002, 998, 998, 843, 1002, 999, 920, 1001, 760, 835, 1001, 998, 999, 1000, 1000, 846, 1001, 1001, 999, 999, 998, 538, 1000, 1000, 653, 1002, 829, 996, 998, 999, 1001, 671, 875, 902, 1000, 999, 998, 736, 1001, 1000, 1001, 1000, 999, 866, 1002, 999, 936, 999, 815, 1001, 1001, 1000, 845, 825, 957, 999, 999, 932, 990, 1000, 959, 1000, 1000, 1000, 1000, 924]
theorem node78812 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78812 support demand code
    entries78812 ((insert 51 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node78807 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    51 node78811 node78812
def entries78809 : List (Fin 2295 × ℕ) := [(23, 12), (179, 89), (472, 19), (541, 16), (542, 53), (551, 97), (552, 52), (571, 18), (588, 85), (622, 105), (625, 18), (672, 41), (675, 77), (681, 19), (729, 6), (741, 7), (742, 8), (743, 28), (851, 8), (869, 26), (870, 20), (873, 41), (874, 33), (878, 17), (880, 48), (898, 3), (900, 31), (902, 13), (907, 28), (908, 105), (916, 16), (917, 39), (918, 82), (921, 8), (922, 19), (934, 8), (944, 22), (952, 26), (958, 12), (960, 38), (962, 52), (966, 49), (970, 19), (971, 23), (972, 5), (973, 141), (978, 37), (1006, 18), (1009, 8), (1012, 20), (1043, 16), (1049, 14), (1056, 13), (1061, 39), (1100, 36), (1110, 26), (1113, 17), (1114, 18), (1123, 43), (1143, 4), (1167, 58), (1173, 25), (1177, 58), (1179, 39), (1185, 12), (1186, 54), (1247, 4), (1254, 3), (1261, 37), (1293, 8), (1308, 6), (1375, 4), (1384, 27), (1400, 3), (1433, 3), (1488, 7), (1517, 116), (1534, 16), (1537, 88), (1545, 57), (1623, 4), (1845, 6), (1846, 13), (1849, 2), (1861, 47), (1864, 5), (1901, 36), (1903, 10), (1950, 79), (1991, 13), (2283, 4)]
def cs78809 : List ℕ := [47, 3, 107, 47, 23, 88, 121, 256, 206, 0, 47, 217, 256, 198, 91, 197, 157, 257, 257, 18, 257, 0, 177, 256, 256, 0, 256, 504, 256, 94, 256, 256, 253, 257, 73, 257, 784, 256, 108, 466, 256, 256, 256, 195, 471, 257, 531, 256, 116, 256, 257, 256, 147, 258, 256, 265, 256, 257, 256, 255, 26, 256, 257, 257, 256, 258, 331, 475, 147, 257, 256, 255, 245, 116, 207, 236, 458, 257, 138, 257, 255, 488, 257, 256, 253, 259, 256, 256, 256, 256, 256, 237, 254, 256, 257, 257, 243, 256, 256, 256, 256, 257, 255, 226, 257, 256, 256, 257, 256, 185, 254, 257, 212, 256, 244, 257, 256, 257, 257, 199, 221, 256, 256, 257, 256, 250, 257, 257, 235, 256, 256, 257, 257, 256, 256, 256, 240, 257, 256, 256, 256, 241, 256, 256, 206, 238, 254, 257, 256, 256, 257, 257, 234, 217]
theorem node78809 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78809 support demand code
    entries78809 ((insert 60 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78810 : List (Fin 2295 × ℕ) := [(83, 22), (179, 64), (273, 5), (431, 9), (475, 12), (478, 60), (483, 61), (494, 20), (496, 6), (515, 4), (542, 2), (551, 141), (552, 55), (588, 11), (620, 9), (625, 1), (640, 6), (672, 33), (675, 51), (681, 58), (736, 12), (743, 27), (813, 14), (858, 113), (872, 43), (873, 36), (874, 34), (878, 12), (880, 61), (898, 12), (900, 5), (902, 36), (907, 54), (908, 84), (925, 6), (933, 12), (938, 8), (944, 45), (951, 23), (952, 7), (958, 58), (959, 51), (960, 68), (962, 3), (970, 46), (973, 122), (978, 66), (1006, 9), (1012, 28), (1043, 23), (1049, 53), (1061, 27), (1097, 14), (1098, 4), (1100, 22), (1110, 14), (1113, 25), (1123, 39), (1141, 4), (1167, 56), (1173, 6), (1176, 11), (1177, 67), (1179, 1), (1186, 67), (1269, 8), (1270, 30), (1293, 56), (1297, 33), (1308, 5), (1310, 24), (1349, 47), (1354, 2), (1375, 3), (1469, 26), (1488, 16), (1534, 12), (1545, 40), (1551, 54), (1636, 12), (1645, 12), (1667, 2), (1751, 24), (1845, 27), (1848, 2), (1861, 77), (1950, 99), (1991, 9)]
def cs78810 : List ℕ := [77, 0, 0, 89, 60, 61, 113, 256, 105, 0, 81, 111, 255, 167, 61, 257, 142, 257, 256, 0, 255, 0, 87, 255, 257, 0, 256, 456, 255, 94, 171, 142, 111, 255, 67, 256, 820, 255, 122, 0, 256, 255, 256, 256, 274, 255, 534, 256, 114, 256, 130, 256, 152, 256, 255, 256, 256, 255, 255, 255, 36, 255, 256, 256, 256, 256, 358, 373, 158, 255, 256, 256, 256, 157, 213, 238, 482, 256, 70, 257, 256, 460, 241, 255, 225, 255, 256, 255, 255, 257, 235, 251, 256, 256, 219, 256, 249, 255, 255, 257, 256, 256, 256, 244, 254, 254, 255, 257, 256, 71, 253, 256, 255, 255, 254, 257, 256, 256, 255, 200, 255, 254, 257, 256, 256, 193, 255, 255, 255, 256, 256, 256, 255, 256, 234, 258, 229, 256, 255, 257, 207, 220, 254, 257, 239, 190, 257, 245, 255, 248, 256, 256, 222, 222]
theorem node78810 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78810 support demand code
    entries78810 ((insert 39 (insert 60 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78808 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    39 node78809 node78810
theorem node78803 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    60 node78807 node78808
def entries78805 : List (Fin 2295 × ℕ) := [(23, 26), (98, 9), (179, 1), (244, 11), (494, 19), (514, 1), (526, 26), (542, 63), (551, 120), (552, 28), (588, 55), (623, 37), (624, 70), (625, 4), (632, 74), (675, 23), (731, 35), (817, 10), (842, 9), (851, 24), (852, 23), (869, 37), (870, 41), (873, 98), (880, 12), (896, 54), (898, 6), (908, 123), (915, 12), (916, 46), (917, 68), (919, 17), (920, 29), (924, 21), (925, 57), (944, 42), (946, 7), (952, 74), (958, 52), (971, 4), (972, 49), (973, 125), (978, 47), (1007, 21), (1009, 10), (1012, 14), (1022, 4), (1047, 26), (1049, 7), (1056, 6), (1061, 42), (1099, 23), (1100, 53), (1110, 29), (1113, 17), (1114, 17), (1122, 5), (1123, 23), (1143, 11), (1155, 4), (1167, 49), (1173, 5), (1176, 5), (1177, 52), (1179, 57), (1183, 35), (1186, 56), (1212, 13), (1223, 81), (1235, 21), (1272, 17), (1298, 2), (1400, 11), (1488, 27), (1493, 10), (1497, 22), (1517, 83), (1528, 7), (1537, 84), (1614, 14), (1645, 22), (1703, 30), (1705, 3), (1728, 10), (1857, 5), (1901, 4), (1981, 14), (2062, 36)]
def cs78805 : List ℕ := [81, 0, 84, 0, 154, 98, 97, 257, 219, 0, 15, 256, 256, 231, 91, 184, 194, 257, 257, 0, 256, 54, 102, 256, 256, 0, 256, 483, 256, 116, 256, 256, 254, 257, 17, 257, 585, 254, 31, 483, 231, 255, 256, 174, 612, 255, 556, 255, 78, 255, 253, 255, 190, 258, 256, 301, 255, 256, 256, 257, 255, 94, 256, 257, 180, 257, 398, 467, 251, 256, 257, 256, 244, 177, 257, 234, 359, 257, 112, 257, 256, 0, 229, 256, 248, 257, 245, 254, 256, 258, 257, 228, 256, 256, 241, 222, 256, 256, 254, 256, 257, 258, 213, 254, 256, 257, 255, 257, 257, 179, 257, 257, 127, 255, 242, 251, 256, 255, 256, 182, 189, 255, 257, 257, 256, 211, 256, 257, 244, 256, 256, 257, 256, 257, 213, 256, 194, 257, 256, 257, 256, 256, 257, 257, 255, 237, 256, 253, 257, 221, 256, 257, 251, 233]
theorem node78805 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78805 support demand code
    entries78805 ((insert 81 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78806 : List (Fin 2295 × ℕ) := [(83, 25), (387, 3), (475, 8), (479, 39), (529, 76), (550, 9), (551, 154), (552, 28), (588, 18), (620, 21), (624, 73), (625, 7), (632, 35), (817, 22), (819, 16), (851, 40), (852, 11), (858, 95), (870, 19), (871, 26), (872, 6), (873, 68), (878, 24), (880, 32), (886, 6), (895, 5), (896, 35), (900, 7), (902, 36), (908, 124), (917, 35), (924, 47), (925, 65), (944, 55), (945, 27), (946, 43), (952, 81), (957, 3), (958, 81), (970, 15), (971, 20), (972, 7), (973, 117), (978, 52), (1006, 8), (1007, 22), (1012, 9), (1042, 27), (1047, 25), (1049, 10), (1061, 57), (1100, 48), (1108, 11), (1110, 25), (1113, 19), (1114, 29), (1122, 1), (1123, 27), (1143, 1), (1152, 17), (1167, 65), (1173, 8), (1177, 43), (1179, 48), (1183, 23), (1186, 26), (1212, 26), (1223, 27), (1235, 38), (1237, 32), (1246, 3), (1270, 22), (1295, 18), (1400, 38), (1434, 12), (1488, 15), (1498, 32), (1501, 1), (1516, 3), (1528, 22), (1645, 52), (1703, 11), (1705, 14), (1859, 60), (1864, 17), (1950, 46), (1991, 12)]
def cs78806 : List ℕ := [87, 32, 0, 8, 149, 124, 172, 255, 85, 0, 0, 188, 255, 188, 41, 255, 157, 256, 256, 0, 255, 40, 30, 255, 255, 6, 256, 526, 256, 85, 187, 219, 257, 256, 40, 255, 646, 256, 14, 54, 247, 255, 256, 209, 394, 256, 514, 256, 84, 255, 217, 256, 186, 255, 256, 256, 257, 254, 256, 256, 258, 64, 256, 254, 255, 255, 371, 401, 254, 255, 256, 257, 256, 137, 255, 254, 385, 256, 62, 256, 256, 0, 227, 256, 152, 254, 222, 256, 256, 256, 256, 235, 257, 256, 241, 233, 229, 256, 257, 256, 256, 256, 245, 256, 255, 255, 256, 256, 256, 127, 256, 255, 163, 255, 255, 227, 255, 256, 255, 178, 164, 255, 255, 255, 256, 201, 254, 255, 255, 254, 257, 255, 254, 256, 243, 247, 190, 255, 255, 255, 255, 232, 256, 255, 183, 240, 255, 245, 255, 206, 255, 230, 217, 192]
theorem node78806 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 81 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78806 support demand code
    entries78806 ((insert 39 (insert 81 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78804 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    39 node78805 node78806
theorem node78802 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    81 node78803 node78804
theorem node78711 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 46 (insert 67 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    21 node78801 node78802
#print axioms node78711
end OmissionResidualCover31Fused
