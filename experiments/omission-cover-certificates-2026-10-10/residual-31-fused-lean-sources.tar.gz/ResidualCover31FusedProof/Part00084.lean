import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries94045 : List (Fin 2295 × ℕ) := [(164, 1)]
def cs94045 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node94045 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94045 support demand code
    entries94045 ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 95 (insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries94047 : List (Fin 2295 × ℕ) := [(168, 1)]
def cs94047 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node94047 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 105 (insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94047 support demand code
    entries94047 ((insert 95 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 105 (insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries94049 : List (Fin 2295 × ℕ) := [(892, 1)]
def cs94049 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node94049 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 95 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94049 support demand code
    entries94049 ((insert 105 (insert 95 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 55 (insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries94050 : List (Fin 2295 × ℕ) := [(4, 62), (12, 8), (32, 5), (92, 13), (177, 25), (355, 7), (491, 55), (571, 51), (581, 49), (585, 12), (588, 5), (639, 25), (678, 1), (727, 23), (738, 4), (741, 36), (776, 2), (819, 22), (834, 7), (846, 4), (847, 30), (852, 21), (856, 31), (860, 1), (884, 9), (885, 5), (886, 16), (890, 45), (904, 18), (920, 9), (923, 17), (926, 7), (933, 14), (942, 5), (943, 15), (944, 7), (945, 29), (946, 39), (956, 8), (968, 21), (972, 21), (973, 57), (984, 20), (985, 1), (1006, 17), (1008, 8), (1009, 3), (1011, 13), (1025, 22), (1033, 8), (1043, 7), (1049, 10), (1069, 7), (1089, 4), (1090, 7), (1099, 3), (1108, 3), (1123, 6), (1138, 18), (1139, 7), (1143, 4), (1145, 12), (1154, 3), (1171, 7), (1178, 6), (1184, 7), (1185, 10), (1186, 33), (1219, 5), (1223, 9), (1227, 3), (1263, 5), (1355, 3), (1363, 1), (1405, 8), (1451, 4), (1607, 3), (1626, 19), (1766, 18), (1767, 29), (1851, 11), (1859, 1), (2285, 3)]
def cs94050 : List ℕ := [39, 71, 67, 34, 100, 55, 56, 99, 100, 18, 0, 70, 99, 13, 62, 0, 63, 100, 100, 64, 99, 136, 49, 100, 36, 223, 100, 260, 13, 47, 99, 100, 67, 100, 99, 100, 0, 101, 48, 100, 83, 101, 101, 99, 177, 99, 180, 100, 100, 61, 101, 100, 100, 99, 100, 57, 99, 99, 101, 101, 99, 100, 101, 27, 49, 86, 99, 8, 100, 215, 159, 43, 73, 98, 100, 99, 81, 100, 20, 89, 100, 171, 101, 99, 63, 95, 29, 99, 170, 100, 100, 99, 0, 121, 93, 6, 55, 96, 101, 100, 99, 99, 98, 100, 59, 0, 95, 100, 100, 164, 97, 100, 99, 76, 85, 100, 99, 99, 99, 100, 99, 88, 100, 100, 100, 84, 99, 99, 76, 99, 78, 57, 99, 99, 99, 99, 100, 63, 99, 100, 99, 83, 78, 100, 99, 63, 81, 100, 98, 100, 99, 100, 100, 100]
theorem node94050 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 105 (insert 95 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94050 support demand code
    entries94050 ((insert 55 (insert 105 (insert 95 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node94048 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 95 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 105 (insert 95 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    55 node94049 node94050
theorem node94046 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 95 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    105 node94047 node94048
theorem node94039 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    95 node94045 node94046
def entries94041 : List (Fin 2295 × ℕ) := [(4, 148), (12, 19), (32, 76), (64, 61), (135, 14), (201, 34), (355, 47), (479, 46), (484, 33), (491, 143), (531, 38), (571, 43), (630, 15), (639, 68), (681, 78), (736, 14), (741, 33), (742, 55), (819, 44), (844, 65), (847, 54), (848, 23), (852, 43), (856, 38), (864, 4), (874, 65), (885, 17), (886, 82), (904, 92), (920, 86), (928, 21), (942, 17), (943, 31), (944, 29), (945, 20), (946, 90), (953, 17), (961, 1), (968, 51), (970, 4), (972, 41), (973, 123), (984, 51), (985, 47), (1006, 22), (1009, 61), (1033, 21), (1034, 3), (1043, 51), (1047, 2), (1048, 3), (1049, 20), (1061, 7), (1073, 11), (1075, 8), (1076, 29), (1089, 3), (1090, 5), (1100, 5), (1102, 32), (1104, 6), (1108, 7), (1123, 2), (1137, 12), (1139, 15), (1155, 36), (1165, 3), (1174, 35), (1175, 44), (1178, 17), (1179, 61), (1183, 4), (1186, 27), (1212, 45), (1219, 7), (1221, 17), (1240, 41), (1273, 22), (1363, 42), (1372, 22), (1405, 49), (1443, 3), (1699, 38), (1845, 5), (1851, 35), (2008, 32), (2082, 23), (2117, 77)]
def cs94041 : List ℕ := [82, 155, 113, 39, 256, 241, 166, 255, 256, 135, 0, 190, 237, 256, 171, 0, 247, 255, 255, 237, 255, 0, 38, 255, 164, 654, 256, 227, 95, 149, 256, 256, 133, 256, 539, 257, 40, 255, 255, 256, 256, 255, 203, 256, 449, 254, 112, 255, 256, 228, 255, 256, 236, 255, 257, 256, 255, 255, 256, 257, 256, 215, 255, 142, 256, 255, 256, 4, 255, 481, 430, 193, 186, 255, 256, 255, 548, 255, 102, 256, 256, 459, 256, 256, 231, 186, 229, 256, 647, 255, 257, 255, 1, 364, 255, 257, 202, 257, 257, 255, 256, 255, 216, 256, 242, 257, 244, 256, 251, 421, 255, 256, 255, 256, 256, 256, 254, 257, 256, 257, 257, 219, 205, 256, 255, 218, 256, 257, 258, 255, 213, 214, 256, 257, 256, 258, 256, 228, 257, 255, 257, 256, 216, 234, 258, 256, 252, 219, 242, 230, 255, 256, 256, 257]
theorem node94041 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 34 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94041 support demand code
    entries94041 ((insert 21 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 34 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries94043 : List (Fin 2295 × ℕ) := [(4, 164), (177, 16), (340, 12), (355, 56), (469, 55), (479, 16), (491, 143), (542, 8), (571, 46), (588, 18), (620, 16), (621, 12), (630, 93), (639, 24), (681, 18), (738, 15), (819, 21), (835, 2), (844, 41), (852, 50), (856, 62), (870, 8), (872, 3), (874, 69), (884, 57), (886, 83), (887, 49), (904, 1), (920, 43), (923, 91), (926, 9), (931, 88), (941, 67), (942, 39), (943, 17), (944, 44), (945, 71), (946, 76), (953, 35), (967, 10), (968, 52), (972, 38), (973, 121), (984, 76), (985, 42), (1006, 28), (1009, 55), (1025, 10), (1033, 13), (1034, 3), (1040, 20), (1043, 53), (1049, 7), (1090, 3), (1100, 12), (1103, 26), (1108, 31), (1123, 2), (1139, 29), (1141, 10), (1155, 49), (1174, 30), (1175, 30), (1176, 12), (1178, 14), (1179, 44), (1186, 31), (1212, 52), (1234, 35), (1248, 7), (1273, 3), (1281, 30), (1329, 13), (1332, 32), (1396, 28), (1405, 39), (1417, 9), (1443, 28), (1585, 12), (1651, 86), (1678, 1), (1851, 42), (2072, 1), (2163, 23)]
def cs94043 : List ℕ := [71, 220, 30, 43, 231, 148, 144, 192, 201, 86, 1, 249, 255, 85, 173, 0, 256, 214, 256, 95, 255, 0, 34, 255, 185, 526, 256, 384, 0, 109, 255, 255, 204, 256, 61, 256, 0, 255, 92, 255, 150, 235, 234, 255, 292, 257, 162, 255, 254, 256, 256, 256, 256, 254, 257, 257, 255, 256, 256, 255, 605, 81, 255, 94, 180, 257, 258, 1, 256, 530, 288, 168, 255, 257, 256, 257, 460, 254, 168, 255, 256, 473, 254, 256, 164, 232, 139, 255, 649, 255, 256, 255, 0, 419, 236, 257, 202, 255, 257, 256, 256, 255, 201, 257, 209, 256, 244, 255, 224, 471, 256, 256, 256, 257, 228, 256, 256, 256, 256, 257, 211, 258, 228, 258, 256, 204, 256, 257, 258, 258, 220, 193, 258, 256, 258, 257, 256, 189, 257, 256, 257, 257, 173, 257, 257, 244, 256, 238, 255, 256, 257, 257, 257, 256]
theorem node94043 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 21 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94043 support demand code
    entries94043 ((insert 34 (insert 21 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries94044 : List (Fin 2295 × ℕ) := [(4, 54), (20, 10), (37, 14), (72, 2), (177, 36), (340, 2), (355, 7), (471, 14), (484, 27), (491, 27), (571, 41), (588, 18), (618, 11), (620, 4), (621, 11), (630, 8), (632, 7), (639, 11), (643, 4), (678, 18), (681, 24), (727, 17), (728, 3), (738, 19), (741, 8), (742, 1), (798, 1), (819, 15), (844, 27), (852, 13), (873, 14), (885, 4), (886, 9), (887, 45), (897, 2), (920, 29), (931, 13), (933, 3), (942, 37), (943, 36), (944, 17), (945, 22), (946, 29), (964, 18), (968, 24), (970, 14), (972, 15), (973, 49), (984, 24), (985, 18), (1006, 9), (1008, 1), (1009, 26), (1033, 6), (1043, 16), (1076, 15), (1101, 6), (1102, 2), (1103, 5), (1122, 3), (1123, 3), (1139, 10), (1155, 19), (1165, 2), (1171, 5), (1174, 5), (1175, 16), (1176, 9), (1178, 5), (1179, 21), (1186, 15), (1212, 15), (1223, 1), (1247, 2), (1270, 8), (1277, 2), (1281, 41), (1443, 7), (1451, 5), (1623, 8), (1851, 15), (1861, 4), (1998, 3)]
def cs94044 : List ℕ := [73, 54, 55, 55, 68, 41, 27, 100, 79, 0, 6, 73, 100, 24, 56, 0, 100, 93, 100, 100, 100, 0, 56, 100, 55, 159, 100, 112, 2, 69, 100, 96, 49, 100, 23, 100, 0, 101, 94, 100, 57, 101, 100, 99, 117, 101, 40, 90, 94, 59, 99, 99, 52, 100, 101, 100, 101, 100, 100, 100, 9, 41, 100, 67, 93, 99, 101, 8, 100, 199, 115, 26, 100, 102, 91, 99, 177, 100, 41, 100, 99, 193, 101, 101, 79, 86, 77, 100, 205, 77, 101, 99, 0, 143, 99, 101, 73, 100, 100, 100, 101, 100, 100, 99, 77, 100, 93, 101, 100, 193, 99, 100, 99, 95, 100, 100, 100, 100, 99, 100, 87, 100, 83, 100, 101, 89, 100, 100, 101, 101, 84, 79, 100, 100, 101, 101, 100, 75, 100, 100, 101, 100, 79, 85, 100, 96, 92, 81, 97, 100, 100, 100, 100, 100]
theorem node94044 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 21 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94044 support demand code
    entries94044 ((insert 60 (insert 34 (insert 21 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node94042 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 21 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 21 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    60 node94043 node94044
theorem node94040 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    34 node94041 node94042
theorem node94033 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 46 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    21 node94039 node94040
def entries94037 : List (Fin 2295 × ℕ) := [(4, 171), (35, 33), (37, 4), (72, 74), (340, 23), (355, 83), (468, 3), (471, 29), (491, 101), (498, 36), (571, 141), (630, 44), (639, 36), (643, 14), (678, 38), (681, 71), (741, 38), (742, 58), (780, 41), (782, 24), (798, 2), (819, 77), (844, 74), (847, 60), (865, 6), (873, 4), (874, 48), (885, 56), (886, 15), (887, 31), (904, 112), (920, 98), (926, 34), (931, 106), (933, 9), (942, 26), (943, 26), (944, 34), (945, 1), (946, 101), (953, 55), (962, 12), (964, 11), (968, 41), (970, 2), (972, 43), (973, 121), (984, 41), (985, 71), (1006, 34), (1008, 22), (1009, 42), (1025, 22), (1028, 19), (1033, 16), (1034, 8), (1043, 30), (1076, 51), (1090, 8), (1102, 1), (1103, 1), (1104, 6), (1108, 6), (1122, 4), (1123, 2), (1137, 3), (1139, 7), (1155, 56), (1174, 42), (1175, 42), (1178, 26), (1179, 67), (1186, 10), (1198, 11), (1212, 58), (1240, 67), (1248, 7), (1273, 11), (1279, 34), (1405, 41), (1629, 38), (1651, 80)]
def cs94037 : List ℕ := [85, 208, 89, 11, 182, 151, 101, 200, 255, 80, 129, 138, 227, 96, 256, 0, 255, 256, 255, 176, 256, 11, 0, 255, 255, 654, 256, 348, 74, 155, 256, 255, 152, 256, 256, 256, 0, 256, 254, 528, 256, 255, 184, 256, 372, 255, 0, 256, 185, 256, 256, 566, 235, 256, 252, 254, 257, 256, 256, 256, 256, 153, 257, 210, 229, 255, 257, 38, 256, 554, 419, 176, 163, 256, 212, 255, 471, 237, 117, 256, 256, 596, 231, 256, 256, 169, 236, 256, 579, 239, 256, 257, 12, 439, 256, 256, 170, 257, 255, 255, 257, 256, 255, 257, 229, 256, 228, 256, 256, 484, 256, 256, 255, 227, 236, 257, 256, 255, 256, 257, 251, 150, 204, 256, 256, 200, 257, 256, 256, 255, 202, 208, 256, 256, 257, 255, 257, 217, 256, 256, 256, 256, 233, 206, 254, 257, 222, 206, 257, 231, 255, 257, 256, 256]
theorem node94037 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 39 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94037 support demand code
    entries94037 ((insert 46 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 51 (insert 39 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries94038 : List (Fin 2295 × ℕ) := [(4, 52), (177, 10), (355, 17), (468, 20), (471, 19), (491, 46), (527, 22), (630, 50), (639, 11), (690, 8), (727, 10), (729, 9), (738, 3), (741, 12), (742, 7), (819, 16), (844, 25), (847, 31), (856, 28), (872, 8), (873, 19), (874, 17), (884, 3), (885, 3), (886, 18), (887, 53), (904, 38), (918, 30), (919, 13), (920, 33), (926, 28), (931, 14), (942, 21), (943, 15), (944, 7), (945, 27), (946, 36), (962, 11), (967, 7), (968, 12), (972, 13), (973, 58), (984, 21), (985, 19), (1006, 1), (1009, 20), (1011, 1), (1025, 3), (1033, 1), (1043, 19), (1076, 5), (1101, 1), (1103, 13), (1108, 13), (1139, 19), (1144, 3), (1145, 7), (1154, 7), (1155, 9), (1174, 15), (1175, 4), (1178, 6), (1179, 5), (1180, 6), (1183, 7), (1184, 4), (1186, 26), (1199, 23), (1279, 5), (1328, 2), (1388, 11), (1405, 18), (1443, 5), (1451, 6), (1487, 3), (1629, 4), (1851, 25)]
def cs94038 : List ℕ := [25, 100, 50, 0, 75, 67, 69, 100, 86, 0, 4, 71, 100, 67, 75, 0, 83, 100, 99, 64, 100, 23, 10, 100, 73, 238, 100, 105, 11, 83, 100, 100, 32, 100, 99, 100, 0, 100, 10, 195, 25, 98, 68, 99, 190, 101, 0, 47, 90, 100, 100, 0, 96, 99, 100, 99, 102, 99, 99, 99, 101, 11, 100, 6, 63, 99, 100, 47, 101, 200, 147, 96, 89, 100, 62, 100, 210, 100, 47, 100, 99, 193, 99, 100, 40, 62, 50, 101, 263, 99, 100, 100, 11, 175, 90, 100, 58, 101, 100, 101, 100, 99, 89, 98, 52, 100, 95, 99, 87, 191, 98, 100, 99, 100, 90, 99, 101, 100, 99, 100, 99, 100, 73, 99, 101, 79, 99, 100, 101, 100, 98, 77, 100, 100, 100, 100, 99, 75, 100, 100, 101, 91, 74, 99, 100, 92, 91, 99, 93, 99, 100, 100, 100, 100]
theorem node94038 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 46 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94038 support demand code
    entries94038 ((insert 51 (insert 46 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node94035 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    51 node94037 node94038
def entries94036 : List (Fin 2295 × ℕ) := [(4, 679), (12, 153), (30, 264), (86, 4), (135, 7), (468, 46), (491, 425), (531, 331), (571, 320), (630, 73), (639, 147), (677, 238), (678, 112), (681, 179), (729, 3), (736, 175), (738, 111), (741, 8), (742, 88), (819, 167), (835, 4), (845, 265), (856, 372), (872, 61), (873, 182), (874, 162), (884, 52), (886, 226), (887, 126), (920, 261), (923, 226), (931, 306), (942, 253), (943, 279), (944, 143), (945, 175), (946, 309), (953, 55), (956, 61), (959, 65), (964, 133), (968, 191), (970, 99), (971, 2), (972, 163), (973, 480), (984, 248), (985, 119), (1006, 113), (1009, 216), (1021, 30), (1025, 17), (1033, 95), (1034, 6), (1043, 105), (1049, 133), (1072, 3), (1073, 72), (1076, 21), (1100, 66), (1138, 6), (1139, 31), (1155, 231), (1165, 52), (1169, 56), (1173, 35), (1174, 132), (1175, 231), (1179, 217), (1182, 14), (1186, 85), (1212, 203), (1363, 69), (1405, 58), (1443, 65), (1534, 55), (1702, 133), (1851, 92), (1853, 334), (1859, 264)]
def cs94036 : List ℕ := [264, 990, 153, 0, 832, 900, 689, 575, 943, 0, 0, 739, 947, 1000, 679, 133, 595, 1000, 1000, 599, 1000, 397, 133, 1000, 133, 2493, 1000, 689, 286, 206, 1000, 1000, 490, 1000, 1000, 1000, 0, 1000, 758, 261, 912, 1001, 847, 1000, 1600, 1000, 0, 1000, 951, 870, 1000, 1000, 570, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 904, 1000, 758, 977, 999, 999, 131, 999, 2180, 1034, 597, 1000, 1000, 935, 1000, 2196, 977, 540, 999, 1000, 2216, 861, 1000, 402, 861, 889, 1000, 2393, 824, 998, 1000, 120, 1704, 714, 999, 698, 1000, 1000, 998, 999, 1000, 986, 999, 945, 1000, 951, 999, 998, 1769, 1000, 1000, 1000, 999, 872, 998, 1000, 998, 1000, 1000, 881, 1000, 808, 999, 997, 930, 1000, 1000, 1000, 999, 702, 899, 1001, 999, 999, 998, 1000, 753, 999, 999, 998, 1000, 774, 820, 999, 1000, 995, 824, 999, 935, 1000, 999, 999, 999]
theorem node94036 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 46 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94036 support demand code
    entries94036 ((insert 39 (insert 46 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node94034 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    39 node94035 node94036
theorem node94025 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 93 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    46 node94033 node94034
def entries94031 : List (Fin 2295 × ℕ) := [(4, 350), (12, 105), (72, 242), (177, 243), (269, 15), (307, 88), (355, 238), (485, 5), (491, 438), (540, 219), (571, 426), (581, 271), (588, 75), (618, 130), (639, 331), (679, 243), (731, 97), (741, 250), (780, 22), (819, 305), (845, 126), (846, 236), (852, 421), (870, 217), (873, 30), (885, 39), (886, 49), (890, 217), (892, 484), (904, 376), (920, 71), (921, 225), (926, 85), (943, 188), (944, 118), (945, 81), (946, 283), (953, 220), (962, 162), (964, 185), (971, 161), (972, 239), (973, 489), (984, 158), (985, 230), (1009, 193), (1012, 122), (1028, 36), (1049, 25), (1069, 107), (1076, 216), (1089, 95), (1098, 22), (1103, 121), (1104, 80), (1108, 137), (1139, 64), (1143, 40), (1155, 177), (1171, 62), (1174, 117), (1175, 166), (1176, 27), (1179, 207), (1186, 146), (1212, 159), (1223, 41), (1263, 28), (1296, 84), (1469, 29), (1488, 22), (1498, 66), (1501, 59), (1572, 32), (1584, 29), (1585, 21), (1651, 301), (1712, 33), (1765, 128), (1766, 45), (1840, 45), (1845, 8), (1849, 20), (1855, 29), (1859, 105), (1866, 71)]
def cs94031 : List ℕ := [217, 712, 105, 199, 917, 606, 614, 1000, 676, 474, 242, 1000, 1000, 114, 811, 66, 735, 1000, 1000, 531, 1000, 1000, 422, 1000, 1000, 1432, 1001, 2431, 376, 276, 1000, 1001, 1000, 1000, 1000, 1000, 95, 999, 806, 1570, 742, 999, 923, 999, 2222, 1000, 1840, 1000, 1000, 825, 999, 2129, 471, 1000, 1000, 1001, 999, 999, 999, 1001, 1001, 1000, 1000, 535, 575, 975, 1000, 0, 1001, 2016, 1681, 937, 866, 660, 1000, 1000, 1824, 1000, 247, 1002, 1000, 1864, 1001, 999, 738, 1000, 705, 1000, 1835, 1001, 1001, 999, 162, 0, 999, 1001, 852, 1000, 1000, 1001, 1002, 1000, 1000, 999, 743, 831, 825, 1001, 909, 1752, 1000, 999, 1000, 1000, 876, 916, 1001, 1000, 999, 1000, 1000, 694, 856, 1001, 963, 744, 1000, 1000, 1000, 1002, 1001, 799, 1000, 1000, 1001, 1001, 1000, 704, 1000, 1000, 1000, 1001, 1001, 1000, 1000, 983, 862, 960, 936, 1000, 927, 1000, 1001, 971]
theorem node94031 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 39 (insert 51 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94031 support demand code
    entries94031 ((insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 46 (insert 39 (insert 51 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries94032 : List (Fin 2295 × ℕ) := [(4, 167), (12, 82), (72, 18), (177, 42), (307, 49), (355, 46), (469, 13), (471, 41), (490, 17), (491, 117), (571, 125), (632, 26), (639, 31), (643, 21), (679, 66), (690, 71), (741, 49), (819, 46), (844, 13), (845, 76), (847, 3), (872, 20), (873, 4), (874, 7), (885, 58), (886, 45), (887, 48), (904, 69), (920, 21), (921, 26), (923, 17), (941, 58), (943, 6), (944, 76), (945, 48), (946, 48), (953, 33), (962, 38), (964, 38), (971, 29), (972, 29), (973, 108), (984, 53), (985, 83), (1009, 52), (1012, 10), (1028, 21), (1043, 25), (1049, 14), (1061, 3), (1070, 4), (1076, 53), (1098, 16), (1108, 42), (1123, 25), (1155, 54), (1174, 7), (1175, 70), (1176, 45), (1178, 8), (1179, 69), (1186, 38), (1212, 31), (1228, 13), (1285, 55), (1309, 1), (1342, 22), (1443, 25), (1501, 22), (1584, 9), (1651, 79), (1691, 24), (1692, 1), (1712, 40), (1843, 27), (1845, 10), (1859, 34)]
def cs94032 : List ℕ := [47, 256, 126, 55, 249, 113, 168, 180, 222, 80, 18, 236, 257, 87, 185, 25, 257, 256, 256, 256, 257, 25, 64, 256, 257, 598, 256, 359, 125, 108, 257, 256, 194, 256, 256, 255, 0, 256, 215, 457, 256, 256, 221, 256, 231, 256, 0, 256, 258, 210, 256, 490, 183, 256, 256, 254, 257, 256, 257, 172, 255, 210, 257, 193, 185, 255, 255, 0, 257, 437, 330, 256, 211, 222, 154, 255, 511, 257, 38, 255, 257, 301, 256, 256, 195, 212, 255, 257, 491, 247, 255, 257, 38, 0, 221, 254, 233, 255, 256, 256, 255, 256, 245, 256, 242, 226, 217, 255, 229, 378, 256, 257, 190, 255, 255, 255, 254, 257, 255, 255, 166, 255, 216, 254, 257, 160, 255, 255, 255, 254, 256, 230, 255, 256, 254, 256, 255, 195, 256, 256, 255, 255, 221, 231, 256, 255, 239, 241, 255, 229, 256, 255, 246, 244]
theorem node94032 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 51 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94032 support demand code
    entries94032 ((insert 46 (insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 51 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node94029 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 51 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 51 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    46 node94031 node94032
def entries94030 : List (Fin 2295 × ℕ) := [(4, 483), (12, 240), (17, 103), (32, 12), (72, 111), (177, 40), (484, 113), (491, 448), (531, 40), (571, 433), (581, 145), (588, 13), (639, 264), (679, 372), (680, 190), (741, 142), (780, 73), (819, 226), (845, 166), (852, 277), (856, 107), (873, 320), (886, 163), (890, 150), (892, 317), (902, 21), (920, 263), (921, 89), (923, 359), (943, 330), (944, 169), (945, 223), (946, 267), (953, 158), (955, 52), (962, 103), (964, 59), (971, 162), (972, 98), (973, 396), (984, 277), (985, 239), (1009, 158), (1012, 51), (1021, 40), (1033, 37), (1049, 207), (1069, 134), (1070, 30), (1075, 12), (1076, 176), (1086, 34), (1089, 81), (1097, 154), (1099, 6), (1103, 134), (1108, 46), (1123, 17), (1139, 82), (1155, 233), (1169, 54), (1174, 203), (1175, 267), (1179, 158), (1186, 64), (1212, 273), (1263, 110), (1268, 140), (1534, 74), (1594, 110), (1692, 65), (1840, 39), (1843, 138), (1859, 386)]
def cs94030 : List ℕ := [386, 649, 240, 103, 1000, 728, 834, 829, 818, 65, 111, 834, 882, 778, 594, 175, 662, 752, 999, 1000, 1000, 1000, 92, 1000, 0, 1962, 1000, 1556, 538, 40, 1000, 1000, 975, 1001, 1000, 1000, 0, 999, 1000, 352, 935, 999, 999, 1000, 2311, 1001, 999, 999, 733, 252, 1000, 1866, 500, 999, 999, 999, 1000, 999, 1000, 935, 1000, 1000, 999, 798, 709, 721, 1001, 106, 999, 1932, 1181, 945, 999, 615, 999, 999, 2135, 1001, 59, 931, 1000, 1625, 833, 999, 640, 931, 999, 999, 1770, 829, 1001, 1000, 177, 0, 863, 999, 864, 1000, 999, 999, 999, 1000, 795, 1000, 999, 1000, 673, 1000, 930, 1457, 1001, 1000, 842, 882, 981, 988, 999, 999, 999, 1000, 704, 1000, 941, 1000, 999, 648, 1000, 1000, 999, 1000, 927, 920, 1000, 1000, 999, 999, 1000, 774, 1001, 1000, 999, 1000, 980, 813, 999, 955, 872, 833, 936, 936, 1000, 1000, 891, 966]
theorem node94030 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94030 support demand code
    entries94030 ((insert 39 (insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 51 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node94027 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 51 (insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    39 node94029 node94030
def entries94028 : List (Fin 2295 × ℕ) := [(4, 6905), (177, 1934), (355, 776), (471, 1536), (491, 5814), (514, 238), (527, 2231), (531, 3749), (581, 944), (632, 2579), (639, 3319), (729, 724), (731, 1650), (741, 3829), (819, 1820), (846, 933), (852, 3095), (856, 3583), (873, 1348), (885, 673), (886, 2059), (887, 924), (890, 2446), (892, 3515), (904, 2022), (919, 289), (920, 2304), (921, 1178), (923, 2770), (928, 1714), (941, 1298), (942, 60), (943, 1925), (944, 1350), (945, 1367), (946, 3768), (962, 294), (964, 1804), (968, 756), (971, 1766), (972, 1766), (973, 5573), (984, 1849), (985, 1748), (1009, 1925), (1012, 381), (1040, 754), (1043, 198), (1061, 449), (1076, 1003), (1089, 562), (1097, 908), (1098, 307), (1103, 980), (1108, 1574), (1139, 631), (1144, 980), (1155, 1574), (1174, 2114), (1175, 2114), (1179, 1333), (1184, 782), (1185, 450), (1186, 2233), (1212, 79), (1217, 1065), (1221, 1752), (1584, 91), (1845, 948), (1848, 204), (1849, 22), (1859, 279), (1997, 238), (2004, 853)]
def cs94028 : List ℕ := [3949, 7838, 4353, 1091, 10000, 6679, 6946, 9513, 6905, 1091, 238, 10001, 10001, 5097, 6905, 0, 7602, 8691, 10001, 924, 10001, 6905, 1934, 10001, 4649, 20487, 8698, 17623, 0, 5604, 10000, 10000, 4140, 10000, 10000, 9999, 1752, 10001, 3648, 10000, 0, 10000, 9327, 10000, 22326, 10001, 10000, 7112, 9495, 7300, 10000, 0, 9722, 10000, 9999, 10000, 10001, 9694, 10000, 8718, 9999, 7728, 10000, 2558, 7926, 9623, 10000, 0, 10000, 19272, 14189, 10001, 10001, 4340, 9446, 10000, 17553, 10000, 3518, 9999, 9999, 13315, 10001, 10001, 8852, 7935, 7290, 10000, 20315, 8742, 10000, 10000, 294, 756, 9196, 10000, 8636, 10000, 10000, 10000, 10000, 10000, 7624, 10000, 5759, 8600, 8072, 10000, 9490, 15526, 9999, 10000, 10001, 9070, 9185, 9999, 10001, 10000, 9999, 10781, 10000, 7343, 7970, 10000, 8828, 7498, 9999, 10001, 10000, 10001, 8881, 9801, 10000, 10000, 10001, 10000, 9999, 8762, 9999, 9999, 10000, 10000, 8982, 9999, 10000, 10000, 9946, 9550, 10000, 9999, 10000, 9999, 10000, 9909]
theorem node94028 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94028 support demand code
    entries94028 ((insert 51 (insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node94026 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    51 node94027 node94028
theorem node94009 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 27 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    93 node94025 node94026
def entries94021 : List (Fin 2295 × ℕ) := [(7, 10), (10, 25), (12, 6), (32, 49), (118, 18), (122, 16), (355, 18), (466, 14), (468, 2), (475, 10), (479, 7), (506, 2), (542, 27), (571, 38), (588, 21), (630, 44), (639, 5), (681, 27), (736, 16), (741, 4), (742, 9), (780, 10), (819, 12), (845, 48), (852, 11), (856, 7), (863, 31), (864, 13), (874, 34), (885, 5), (886, 16), (903, 14), (904, 33), (905, 20), (920, 27), (928, 2), (941, 15), (942, 22), (943, 17), (944, 10), (945, 19), (946, 30), (947, 24), (956, 2), (961, 3), (968, 20), (969, 2), (972, 18), (973, 50), (984, 21), (985, 15), (996, 5), (1009, 29), (1033, 8), (1043, 16), (1048, 1), (1073, 8), (1075, 3), (1076, 16), (1100, 8), (1104, 8), (1108, 8), (1123, 4), (1138, 1), (1139, 2), (1155, 21), (1165, 2), (1173, 5), (1174, 16), (1175, 13), (1178, 8), (1179, 21), (1186, 12), (1204, 31), (1212, 17), (1405, 18), (1451, 2), (1657, 10), (1765, 9), (1845, 5), (1851, 25)]
def cs94021 : List ℕ := [24, 101, 62, 50, 100, 56, 0, 92, 99, 55, 0, 45, 100, 100, 68, 34, 47, 101, 99, 93, 101, 100, 21, 100, 78, 235, 100, 0, 89, 44, 100, 100, 42, 100, 307, 100, 0, 84, 29, 99, 100, 100, 48, 101, 201, 100, 55, 99, 101, 99, 99, 100, 73, 101, 100, 100, 100, 100, 101, 76, 148, 59, 59, 56, 98, 90, 99, 2, 99, 183, 126, 64, 91, 100, 100, 100, 201, 84, 47, 100, 96, 185, 100, 100, 86, 64, 86, 100, 219, 99, 99, 101, 3, 162, 101, 100, 71, 101, 100, 99, 101, 100, 74, 101, 88, 101, 90, 98, 99, 175, 100, 100, 101, 92, 99, 100, 100, 100, 101, 101, 88, 89, 80, 100, 99, 84, 102, 99, 100, 100, 99, 79, 100, 100, 99, 100, 101, 87, 101, 100, 100, 100, 83, 89, 100, 100, 101, 87, 97, 100, 99, 100, 100, 100]
theorem node94021 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 34 (insert 93 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94021 support demand code
    entries94021 ((insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 34 (insert 93 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries94023 : List (Fin 2295 × ℕ) := [(4, 17), (43, 18), (70, 26), (340, 32), (355, 16), (479, 30), (485, 21), (542, 30), (571, 23), (588, 6), (639, 1), (643, 38), (677, 1), (678, 1), (681, 21), (738, 7), (742, 1), (780, 16), (819, 12), (845, 56), (855, 9), (871, 42), (873, 15), (874, 34), (884, 7), (886, 18), (890, 6), (892, 20), (912, 31), (919, 20), (920, 8), (923, 13), (931, 6), (941, 34), (942, 13), (943, 14), (944, 15), (945, 19), (946, 34), (953, 25), (967, 6), (968, 35), (972, 15), (973, 54), (984, 35), (1008, 1), (1009, 10), (1021, 2), (1023, 28), (1025, 4), (1033, 7), (1034, 4), (1043, 16), (1100, 11), (1101, 14), (1104, 1), (1108, 10), (1123, 1), (1126, 3), (1128, 6), (1139, 12), (1143, 2), (1155, 26), (1171, 4), (1174, 4), (1175, 18), (1178, 6), (1179, 18), (1182, 7), (1186, 17), (1198, 9), (1212, 4), (1223, 14), (1234, 11), (1248, 15), (1399, 5), (1405, 16), (1443, 4), (1547, 15), (1585, 4), (1851, 14)]
def cs94023 : List ℕ := [23, 73, 0, 9, 70, 30, 18, 100, 40, 0, 35, 14, 100, 100, 100, 0, 60, 100, 100, 23, 100, 79, 6, 100, 0, 181, 101, 26, 0, 84, 100, 100, 40, 100, 22, 101, 0, 47, 33, 100, 59, 100, 67, 100, 234, 99, 100, 102, 80, 100, 99, 102, 62, 100, 78, 319, 99, 101, 101, 100, 215, 34, 43, 95, 82, 99, 101, 38, 100, 190, 118, 100, 90, 101, 100, 101, 222, 99, 24, 100, 101, 189, 99, 99, 101, 74, 100, 99, 224, 100, 100, 100, 0, 158, 100, 100, 93, 88, 100, 100, 100, 100, 85, 100, 70, 100, 90, 101, 88, 235, 101, 100, 100, 99, 79, 100, 100, 100, 101, 100, 100, 100, 80, 101, 99, 98, 100, 100, 101, 100, 86, 76, 101, 101, 100, 100, 100, 78, 101, 101, 101, 100, 70, 101, 100, 96, 88, 88, 94, 94, 96, 101, 100, 101]
theorem node94023 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 93 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94023 support demand code
    entries94023 ((insert 34 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 55 (insert 93 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries94024 : List (Fin 2295 × ℕ) := [(4, 366), (72, 6), (177, 62), (340, 10), (355, 372), (468, 32), (479, 10), (506, 88), (542, 422), (588, 62), (630, 464), (677, 53), (681, 62), (690, 61), (780, 43), (782, 87), (819, 125), (845, 546), (852, 88), (856, 252), (874, 242), (884, 150), (885, 273), (887, 123), (919, 423), (920, 20), (922, 10), (923, 233), (926, 167), (931, 427), (943, 236), (944, 66), (945, 233), (946, 333), (953, 308), (956, 2), (967, 84), (968, 229), (972, 286), (973, 527), (984, 186), (985, 94), (1006, 175), (1009, 264), (1025, 85), (1033, 65), (1034, 129), (1043, 112), (1049, 31), (1073, 78), (1090, 23), (1100, 71), (1108, 113), (1123, 16), (1138, 94), (1141, 17), (1147, 3), (1155, 198), (1174, 162), (1175, 115), (1178, 83), (1179, 171), (1182, 23), (1183, 27), (1186, 202), (1212, 46), (1248, 213), (1268, 366), (1328, 22), (1405, 106), (1417, 27), (1443, 34), (1807, 170), (1851, 157), (2285, 46)]
def cs94024 : List ℕ := [0, 944, 0, 0, 634, 422, 0, 846, 536, 258, 6, 32, 1000, 778, 794, 0, 625, 912, 866, 489, 1000, 0, 124, 1000, 258, 1873, 999, 0, 6, 526, 1001, 999, 720, 1000, 277, 999, 0, 749, 130, 1000, 973, 1000, 374, 1001, 1324, 1001, 690, 1000, 1000, 1000, 1000, 1000, 898, 1001, 1000, 523, 1001, 1001, 1000, 999, 2500, 366, 734, 494, 568, 677, 1001, 52, 1000, 2186, 889, 400, 1000, 1001, 1001, 1001, 1939, 914, 627, 999, 1000, 1976, 1000, 1000, 572, 751, 636, 1001, 2486, 1000, 999, 1001, 0, 1825, 969, 1001, 834, 1001, 1199, 999, 1000, 1000, 962, 1001, 864, 1001, 922, 865, 854, 2006, 1001, 1001, 942, 1001, 728, 1000, 1000, 1000, 1001, 1001, 1000, 972, 807, 1000, 1000, 966, 1001, 1001, 1001, 1000, 838, 804, 1001, 1000, 1000, 1000, 1001, 808, 1000, 999, 1001, 1001, 623, 1000, 999, 1001, 912, 933, 976, 1000, 837, 1000, 999, 1000]
theorem node94024 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 34 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94024 support demand code
    entries94024 ((insert 55 (insert 34 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node94022 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    55 node94023 node94024
theorem node94017 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 93 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    34 node94021 node94022
def entries94019 : List (Fin 2295 × ℕ) := [(7, 5), (10, 5), (30, 4), (32, 13), (118, 1), (122, 2), (355, 2), (466, 2), (479, 2), (484, 2), (506, 1), (542, 13), (571, 17), (587, 3), (588, 6), (632, 10), (639, 1), (730, 1), (741, 6), (780, 4), (819, 8), (845, 17), (852, 5), (855, 6), (863, 9), (874, 9), (884, 1), (885, 3), (886, 8), (903, 2), (904, 16), (906, 5), (920, 7), (928, 9), (941, 9), (943, 2), (944, 4), (945, 12), (946, 9), (953, 3), (957, 2), (962, 3), (964, 3), (971, 4), (972, 4), (973, 14), (984, 9), (985, 5), (1004, 1), (1009, 9), (1012, 3), (1043, 4), (1049, 4), (1073, 2), (1076, 4), (1097, 4), (1098, 4), (1103, 1), (1104, 2), (1108, 6), (1139, 2), (1155, 8), (1174, 6), (1175, 8), (1179, 8), (1186, 2), (1204, 10), (1212, 8), (1691, 5), (1765, 5)]
def cs94019 : List ℕ := [2, 32, 15, 15, 27, 25, 0, 26, 32, 15, 0, 7, 32, 33, 23, 8, 16, 32, 32, 30, 32, 32, 9, 32, 29, 81, 32, 0, 21, 10, 32, 33, 22, 32, 91, 33, 0, 32, 9, 33, 32, 31, 16, 32, 68, 32, 20, 33, 32, 32, 31, 31, 25, 32, 32, 32, 32, 32, 33, 15, 42, 27, 12, 16, 23, 32, 33, 2, 32, 60, 21, 33, 31, 11, 32, 33, 65, 20, 15, 31, 33, 42, 32, 33, 25, 21, 27, 29, 72, 28, 31, 32, 3, 0, 32, 33, 22, 33, 37, 31, 32, 32, 22, 31, 32, 29, 23, 32, 29, 46, 33, 32, 32, 32, 32, 30, 32, 32, 31, 33, 20, 32, 28, 31, 32, 23, 32, 33, 32, 31, 32, 28, 32, 32, 32, 32, 32, 26, 32, 32, 32, 32, 30, 30, 32, 33, 28, 30, 32, 30, 32, 32, 32, 32]
theorem node94019 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 34 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94019 support demand code
    entries94019 ((insert 93 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 34 (insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
def entries94020 : List (Fin 2295 × ℕ) := [(4, 123), (177, 20), (355, 329), (506, 155), (542, 378), (588, 81), (632, 388), (643, 165), (677, 80), (681, 154), (690, 194), (741, 28), (780, 127), (819, 130), (845, 434), (852, 255), (855, 49), (871, 64), (873, 73), (874, 113), (885, 105), (886, 159), (887, 162), (919, 129), (920, 185), (921, 108), (923, 424), (941, 66), (943, 213), (944, 256), (945, 317), (946, 161), (953, 145), (961, 8), (962, 156), (971, 77), (972, 116), (973, 424), (984, 336), (985, 115), (1009, 214), (1012, 37), (1025, 88), (1033, 88), (1049, 159), (1069, 29), (1076, 106), (1097, 143), (1098, 183), (1102, 1), (1103, 3), (1104, 25), (1108, 134), (1123, 25), (1128, 60), (1139, 23), (1141, 88), (1155, 283), (1174, 152), (1175, 103), (1177, 205), (1179, 265), (1186, 25), (1212, 243), (1223, 188), (1268, 217), (1522, 17), (1584, 25), (1585, 114), (1765, 247), (1807, 64), (1845, 20), (1848, 1), (1855, 39)]
def cs94020 : List ℕ := [188, 557, 0, 247, 630, 130, 0, 941, 622, 466, 0, 435, 999, 548, 501, 0, 533, 557, 999, 379, 1000, 0, 101, 1000, 466, 1321, 999, 0, 0, 408, 1000, 999, 988, 1000, 255, 999, 0, 926, 174, 1000, 281, 999, 550, 999, 1863, 1000, 885, 999, 866, 675, 1000, 999, 766, 999, 948, 1000, 1001, 1000, 1000, 1000, 1928, 381, 574, 532, 458, 1000, 1000, 0, 1001, 1806, 793, 1000, 1001, 20, 1000, 1001, 2248, 832, 0, 1000, 1000, 956, 1001, 1001, 816, 872, 1000, 1001, 1779, 982, 1000, 1000, 164, 0, 848, 1000, 861, 1001, 1000, 1000, 1000, 999, 459, 1000, 1001, 942, 733, 1000, 949, 1314, 1000, 1000, 841, 956, 1001, 975, 1001, 1000, 1000, 1001, 549, 1002, 993, 1000, 1001, 638, 1001, 1001, 870, 1001, 1000, 884, 1001, 1001, 1000, 1002, 1001, 852, 1000, 1000, 1000, 1001, 957, 999, 1001, 1000, 840, 851, 1000, 992, 1001, 1000, 957, 975]
theorem node94020 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 93 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94020 support demand code
    entries94020 ((insert 34 (insert 93 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node94018 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    34 node94019 node94020
theorem node94011 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 60 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    93 node94017 node94018
def entries94013 : List (Fin 2295 × ℕ) := [(4, 43), (12, 33), (30, 13), (35, 13), (70, 30), (177, 13), (340, 11), (468, 27), (542, 8), (571, 54), (576, 5), (588, 26), (639, 20), (642, 9), (643, 52), (679, 29), (681, 1), (728, 1), (738, 11), (741, 3), (742, 1), (819, 10), (845, 28), (850, 23), (855, 3), (871, 29), (873, 17), (874, 28), (876, 10), (885, 2), (890, 12), (892, 44), (904, 12), (912, 12), (920, 15), (933, 12), (942, 47), (943, 37), (944, 9), (945, 28), (946, 29), (962, 4), (964, 16), (968, 17), (970, 15), (972, 28), (973, 45), (984, 34), (985, 4), (1009, 21), (1021, 4), (1033, 11), (1043, 20), (1049, 8), (1076, 8), (1101, 4), (1102, 10), (1103, 14), (1104, 11), (1108, 4), (1139, 9), (1143, 3), (1154, 2), (1155, 11), (1162, 6), (1165, 5), (1172, 2), (1173, 19), (1175, 15), (1179, 11), (1186, 15), (1212, 21), (1223, 19), (1401, 3), (1443, 1), (1488, 6), (1534, 5), (1552, 6), (1623, 10), (1702, 1), (1851, 15), (1987, 13)]
def cs94013 : List ℕ := [19, 98, 33, 23, 95, 29, 0, 74, 88, 0, 30, 46, 100, 100, 94, 1, 48, 99, 100, 87, 100, 100, 40, 100, 13, 208, 100, 56, 34, 75, 99, 100, 26, 100, 100, 101, 0, 70, 57, 100, 100, 99, 83, 99, 305, 99, 101, 99, 71, 97, 100, 100, 25, 100, 100, 346, 99, 100, 100, 99, 29, 64, 63, 78, 86, 100, 100, 28, 100, 202, 146, 100, 85, 99, 100, 84, 234, 99, 37, 100, 100, 240, 100, 100, 85, 101, 100, 98, 203, 97, 100, 99, 9, 99, 100, 100, 77, 99, 101, 100, 99, 100, 100, 100, 73, 99, 67, 101, 86, 207, 100, 99, 101, 100, 61, 99, 100, 101, 99, 100, 98, 101, 93, 100, 101, 91, 94, 99, 101, 100, 78, 62, 99, 101, 100, 102, 99, 64, 100, 100, 100, 99, 76, 93, 102, 91, 96, 87, 99, 100, 97, 99, 100, 92]
theorem node94013 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94013 support demand code
    entries94013 ((insert 60 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 55 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries94015 : List (Fin 2295 × ℕ) := [(4, 27), (7, 9), (12, 25), (30, 31), (32, 4), (64, 8), (72, 5), (100, 25), (118, 5), (122, 4), (137, 3), (355, 6), (356, 8), (433, 11), (466, 10), (484, 37), (542, 14), (571, 63), (576, 3), (588, 14), (630, 30), (639, 14), (679, 5), (729, 5), (736, 18), (738, 9), (741, 41), (819, 18), (845, 35), (847, 8), (864, 30), (885, 23), (904, 33), (906, 3), (920, 33), (928, 33), (943, 32), (944, 5), (945, 15), (946, 26), (964, 4), (968, 21), (970, 4), (971, 8), (972, 19), (973, 48), (984, 29), (985, 11), (1006, 6), (1009, 9), (1012, 7), (1047, 2), (1048, 2), (1049, 16), (1061, 2), (1069, 10), (1073, 3), (1075, 11), (1076, 3), (1086, 4), (1089, 8), (1097, 7), (1103, 6), (1139, 3), (1154, 4), (1155, 10), (1165, 2), (1172, 12), (1174, 18), (1175, 22), (1179, 18), (1186, 2), (1204, 27), (1212, 28), (1221, 7), (1223, 12), (1273, 12), (1405, 2), (1443, 1), (1451, 6), (1484, 10), (1584, 1), (1691, 24), (1845, 2), (1857, 2)]
def cs94015 : List ℕ := [29, 98, 67, 27, 100, 79, 0, 72, 101, 38, 5, 29, 101, 100, 73, 33, 92, 100, 100, 100, 81, 100, 14, 100, 36, 237, 100, 8, 67, 40, 101, 100, 75, 101, 272, 100, 7, 91, 43, 100, 95, 101, 51, 100, 206, 99, 29, 57, 98, 70, 101, 100, 54, 100, 100, 18, 100, 100, 101, 86, 0, 100, 60, 32, 99, 100, 99, 0, 100, 185, 91, 66, 75, 100, 79, 99, 210, 100, 55, 99, 100, 156, 99, 100, 71, 89, 100, 99, 225, 99, 99, 99, 0, 100, 100, 100, 64, 100, 100, 99, 100, 99, 99, 100, 100, 100, 81, 99, 91, 163, 99, 100, 99, 100, 100, 100, 98, 100, 99, 100, 100, 99, 82, 97, 100, 75, 100, 100, 83, 99, 90, 100, 99, 99, 100, 101, 100, 100, 99, 99, 99, 100, 99, 99, 100, 97, 97, 91, 99, 96, 99, 100, 100, 100]
theorem node94015 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 60 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 34 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94015 support demand code
    entries94015 ((insert 55 (insert 60 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 34 (insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries94016 : List (Fin 2295 × ℕ) := [(4, 4660), (37, 2101), (177, 5112), (212, 154), (355, 2076), (433, 135), (466, 1486), (468, 681), (484, 2959), (531, 2861), (540, 2251), (542, 708), (571, 3362), (588, 2037), (632, 126), (639, 253), (679, 872), (681, 1414), (727, 1098), (729, 1533), (738, 2067), (741, 4150), (819, 1216), (845, 4660), (873, 3075), (885, 2706), (887, 3563), (917, 1592), (920, 3735), (921, 77), (928, 195), (931, 1298), (933, 697), (943, 3812), (944, 416), (946, 2812), (960, 1239), (964, 1700), (966, 401), (968, 1835), (970, 378), (971, 1239), (972, 1617), (973, 4701), (984, 2878), (985, 1542), (1008, 227), (1009, 1964), (1012, 373), (1021, 969), (1033, 305), (1047, 424), (1049, 902), (1069, 1111), (1075, 568), (1076, 683), (1086, 230), (1097, 990), (1100, 20), (1102, 230), (1103, 1082), (1139, 650), (1154, 650), (1155, 1554), (1165, 201), (1170, 39), (1171, 428), (1174, 1756), (1175, 2004), (1178, 429), (1179, 1784), (1212, 2866), (1223, 214), (1273, 880), (1482, 777), (1484, 1026), (1623, 1350), (1701, 386), (1851, 185)]
def cs94016 : List ℕ := [1700, 10001, 0, 0, 4874, 5060, 0, 7041, 6975, 0, 0, 2381, 10000, 5936, 7619, 0, 8046, 9521, 8895, 9026, 10000, 0, 7149, 10000, 154, 19215, 10000, 0, 0, 7041, 10000, 10001, 4996, 10001, 3961, 10000, 0, 6925, 9694, 10000, 5357, 10000, 6265, 10001, 16380, 10000, 3173, 7149, 10000, 7621, 10000, 10000, 2637, 9999, 9999, 5288, 10000, 10000, 10000, 10000, 0, 7462, 7896, 5095, 10000, 10000, 10000, 2942, 10001, 16603, 10574, 7873, 8571, 10000, 7374, 9999, 18738, 10000, 4061, 10000, 10000, 21158, 10001, 10000, 9116, 8185, 9849, 10001, 23113, 9843, 10001, 10000, 1239, 9999, 10001, 9999, 5914, 9999, 10000, 10001, 9999, 10000, 9771, 10000, 8549, 10000, 9610, 10001, 9999, 16297, 10000, 10000, 10000, 10000, 9902, 10000, 10000, 10001, 10001, 10000, 10000, 7867, 8165, 7100, 10001, 8101, 10000, 10000, 10000, 10000, 8660, 8500, 10001, 10001, 10000, 10001, 10000, 8935, 10001, 10001, 10000, 10000, 8289, 8878, 10001, 10000, 10001, 7606, 10000, 9751, 10001, 10000, 10001, 10001]
theorem node94016 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 55 (insert 60 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94016 support demand code
    entries94016 ((insert 34 (insert 55 (insert 60 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node94014 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 60 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 60 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    34 node94015 node94016
theorem node94012 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    55 node94013 node94014
theorem node94010 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    60 node94011 node94012
theorem node93959 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 69 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    27 node94009 node94010
def entries94003 : List (Fin 2295 × ℕ) := [(4, 644), (12, 174), (32, 73), (37, 77), (72, 239), (92, 176), (177, 191), (275, 40), (340, 168), (469, 327), (474, 127), (490, 53), (491, 324), (529, 8), (530, 195), (579, 341), (583, 329), (588, 291), (631, 59), (639, 91), (679, 193), (681, 34), (729, 6), (741, 214), (742, 186), (780, 203), (819, 231), (847, 218), (852, 65), (873, 342), (874, 268), (885, 243), (886, 14), (888, 86), (897, 40), (917, 293), (918, 317), (919, 207), (920, 214), (926, 24), (943, 164), (944, 54), (945, 3), (946, 71), (953, 161), (960, 123), (964, 73), (967, 75), (968, 190), (970, 70), (971, 160), (972, 249), (973, 474), (984, 66), (985, 175), (994, 109), (1006, 112), (1009, 103), (1025, 75), (1033, 132), (1034, 37), (1061, 29), (1069, 166), (1076, 110), (1089, 16), (1090, 54), (1102, 101), (1103, 23), (1104, 42), (1108, 52), (1137, 89), (1141, 47), (1143, 19), (1155, 88), (1170, 65), (1174, 154), (1175, 132), (1178, 111), (1179, 261), (1186, 23), (1193, 88), (1204, 10), (1212, 242), (1263, 88), (1281, 151), (1305, 14), (1497, 9), (1511, 18), (1534, 23), (1616, 114), (1629, 215), (1651, 377), (1767, 239), (1998, 47)]
def cs94003 : List ℕ := [478, 999, 792, 545, 999, 545, 395, 1000, 998, 377, 472, 1000, 1000, 999, 999, 0, 1000, 999, 2446, 410, 1000, 768, 522, 999, 1000, 2558, 1000, 2807, 486, 250, 1000, 3002, 1000, 999, 1000, 691, 0, 1000, 734, 2946, 335, 999, 1001, 1001, 2738, 1001, 999, 1000, 265, 561, 1000, 1558, 880, 1000, 1000, 1000, 1001, 999, 1001, 998, 1000, 381, 1000, 797, 657, 1000, 1000, 825, 1001, 342, 1567, 1000, 757, 1001, 1000, 1001, 1574, 1000, 138, 999, 393, 1556, 999, 1000, 1001, 936, 1000, 1001, 1962, 999, 999, 1001, 232, 999, 1001, 1000, 646, 1001, 1001, 1000, 1000, 999, 960, 1001, 985, 1000, 1001, 999, 832, 1941, 1000, 1001, 982, 693, 1001, 999, 1000, 1000, 1001, 1001, 1000, 659, 858, 999, 818, 961, 1001, 1001, 786, 1000, 764, 923, 1001, 1000, 1001, 1000, 1001, 1000, 1000, 999, 1001, 1000, 996, 1000, 1000, 1001, 971, 999, 1001, 940, 1000, 1001, 1000, 941]
theorem node94003 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94003 support demand code
    entries94003 ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 31 (insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries94007 : List (Fin 2295 × ℕ) := [(4, 144), (37, 40), (72, 3), (92, 114), (177, 51), (491, 100), (498, 54), (506, 143), (507, 29), (629, 5), (631, 91), (639, 11), (679, 74), (681, 67), (694, 4), (736, 31), (738, 58), (741, 87), (780, 16), (819, 23), (844, 39), (847, 85), (849, 13), (852, 55), (853, 73), (873, 84), (874, 15), (885, 89), (892, 24), (904, 82), (920, 64), (926, 21), (931, 65), (943, 60), (944, 7), (946, 47), (953, 76), (959, 8), (960, 33), (964, 37), (967, 24), (968, 60), (970, 18), (971, 25), (972, 53), (973, 140), (984, 31), (985, 62), (1006, 13), (1009, 55), (1012, 5), (1033, 19), (1056, 3), (1069, 33), (1073, 34), (1076, 33), (1086, 14), (1089, 9), (1102, 7), (1108, 34), (1137, 5), (1139, 27), (1155, 41), (1176, 51), (1177, 24), (1178, 35), (1179, 22), (1182, 14), (1183, 19), (1184, 23), (1186, 56), (1223, 18), (1401, 40), (1417, 1), (1497, 1), (1572, 8), (1691, 3), (1866, 60), (1987, 20)]
def cs94007 : List ℕ := [117, 144, 85, 73, 217, 113, 160, 257, 256, 172, 3, 178, 257, 213, 187, 3, 107, 256, 616, 40, 257, 27, 51, 256, 254, 626, 256, 355, 6, 147, 257, 64, 256, 256, 256, 256, 0, 256, 255, 406, 69, 253, 167, 257, 600, 256, 251, 400, 101, 240, 257, 520, 196, 257, 256, 256, 255, 255, 256, 460, 256, 73, 256, 198, 152, 257, 256, 36, 256, 86, 348, 257, 147, 255, 256, 257, 385, 257, 135, 255, 208, 417, 195, 256, 256, 243, 256, 255, 506, 256, 256, 257, 41, 256, 257, 211, 189, 255, 257, 256, 256, 257, 256, 257, 208, 256, 245, 255, 226, 493, 257, 257, 257, 156, 257, 256, 256, 256, 257, 256, 236, 192, 195, 256, 218, 214, 257, 256, 256, 257, 233, 221, 257, 256, 255, 255, 256, 203, 257, 256, 256, 257, 246, 245, 256, 256, 254, 235, 256, 247, 246, 256, 256, 256]
theorem node94007 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 59 (insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94007 support demand code
    entries94007 ((insert 31 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 59 (insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries94008 : List (Fin 2295 × ℕ) := [(4, 34), (98, 7), (177, 53), (475, 39), (490, 3), (491, 57), (498, 30), (507, 57), (542, 8), (694, 17), (738, 3), (741, 16), (742, 9), (780, 15), (819, 3), (834, 18), (835, 2), (845, 4), (847, 45), (849, 27), (852, 51), (872, 11), (873, 34), (884, 2), (885, 18), (886, 32), (890, 13), (904, 9), (920, 26), (931, 7), (943, 24), (946, 8), (953, 6), (964, 7), (967, 9), (968, 27), (971, 14), (972, 28), (973, 52), (984, 9), (985, 28), (994, 11), (1012, 5), (1025, 5), (1033, 5), (1043, 9), (1047, 4), (1069, 6), (1076, 23), (1086, 5), (1089, 11), (1090, 11), (1102, 17), (1108, 8), (1137, 1), (1138, 2), (1155, 7), (1174, 14), (1175, 6), (1177, 8), (1178, 10), (1179, 24), (1183, 6), (1185, 2), (1186, 18), (1212, 6), (1273, 10), (1401, 27), (1405, 11), (1497, 5), (1585, 3), (1660, 1), (1857, 1), (1998, 13)]
def cs94008 : List ℕ := [0, 38, 45, 66, 85, 0, 60, 100, 64, 57, 0, 99, 100, 52, 69, 0, 52, 65, 220, 0, 99, 13, 53, 99, 66, 172, 91, 145, 0, 53, 99, 29, 99, 100, 101, 99, 0, 99, 53, 128, 24, 99, 81, 100, 237, 100, 99, 0, 62, 86, 99, 63, 65, 101, 100, 100, 99, 96, 100, 147, 58, 57, 99, 15, 83, 100, 100, 6, 100, 9, 177, 100, 71, 100, 101, 100, 122, 100, 22, 100, 9, 87, 87, 100, 63, 100, 101, 99, 176, 100, 100, 99, 0, 100, 88, 89, 86, 99, 101, 100, 101, 100, 77, 101, 82, 100, 84, 101, 91, 196, 99, 100, 101, 71, 101, 101, 100, 102, 100, 102, 101, 74, 74, 101, 78, 69, 100, 100, 65, 101, 102, 86, 99, 101, 101, 101, 100, 92, 101, 100, 102, 100, 101, 99, 102, 100, 97, 96, 92, 90, 90, 100, 100, 101]
theorem node94008 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 31 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94008 support demand code
    entries94008 ((insert 47 (insert 31 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 59 (insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node94005 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 59 (insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    47 node94007 node94008
def entries94006 : List (Fin 2295 × ℕ) := [(4, 131), (12, 14), (72, 76), (177, 80), (350, 7), (475, 55), (491, 105), (498, 25), (506, 73), (507, 108), (542, 27), (631, 76), (679, 20), (681, 53), (727, 3), (740, 37), (741, 13), (742, 23), (780, 73), (835, 10), (844, 71), (847, 104), (852, 29), (872, 48), (873, 68), (885, 62), (886, 71), (888, 7), (892, 43), (904, 24), (942, 32), (943, 68), (944, 7), (953, 35), (959, 3), (960, 48), (964, 66), (965, 2), (967, 18), (968, 82), (970, 29), (971, 7), (972, 59), (973, 133), (984, 30), (985, 39), (1006, 16), (1012, 32), (1023, 39), (1025, 19), (1033, 12), (1034, 9), (1073, 14), (1076, 20), (1086, 30), (1089, 33), (1090, 28), (1102, 12), (1123, 1), (1143, 2), (1154, 15), (1171, 25), (1174, 33), (1175, 45), (1178, 6), (1179, 39), (1183, 52), (1186, 49), (1219, 5), (1273, 22), (1285, 52), (1417, 20), (1497, 43), (1501, 4), (1545, 14), (1660, 14), (1770, 32), (1859, 16), (1987, 27)]
def cs94006 : List ℕ := [119, 168, 118, 112, 174, 48, 121, 257, 208, 181, 76, 233, 256, 168, 234, 0, 154, 239, 561, 21, 256, 43, 84, 256, 257, 655, 256, 357, 90, 156, 257, 52, 256, 256, 257, 161, 0, 256, 256, 279, 14, 256, 184, 256, 414, 257, 99, 256, 80, 95, 256, 361, 222, 256, 211, 256, 256, 255, 256, 29, 256, 159, 256, 195, 243, 257, 256, 66, 257, 43, 352, 255, 255, 256, 256, 237, 326, 187, 145, 255, 110, 321, 136, 256, 248, 257, 257, 254, 430, 255, 255, 255, 58, 229, 257, 257, 216, 255, 257, 255, 256, 254, 255, 257, 208, 256, 257, 240, 192, 503, 256, 255, 255, 189, 238, 256, 256, 256, 256, 256, 257, 191, 173, 256, 255, 256, 256, 257, 225, 256, 255, 254, 256, 255, 257, 255, 255, 212, 256, 255, 257, 256, 238, 256, 257, 257, 255, 210, 256, 240, 245, 255, 256, 256]
theorem node94006 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 31 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94006 support demand code
    entries94006 ((insert 59 (insert 31 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node94004 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    59 node94005 node94006
theorem node93997 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 27 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    31 node94003 node94004
def entries94001 : List (Fin 2295 × ℕ) := [(4, 90), (12, 35), (32, 64), (72, 21), (92, 20), (340, 12), (475, 9), (496, 12), (506, 135), (542, 23), (588, 13), (631, 112), (679, 93), (681, 92), (741, 38), (742, 3), (780, 51), (782, 18), (819, 17), (845, 125), (850, 20), (873, 72), (874, 74), (885, 90), (897, 53), (919, 80), (920, 36), (926, 4), (943, 35), (944, 65), (946, 6), (947, 51), (953, 90), (959, 51), (960, 92), (967, 2), (968, 44), (970, 38), (972, 27), (973, 131), (984, 53), (985, 44), (1006, 27), (1009, 72), (1012, 2), (1025, 4), (1033, 25), (1049, 4), (1075, 5), (1076, 22), (1099, 3), (1100, 5), (1108, 18), (1139, 10), (1143, 4), (1145, 32), (1154, 1), (1155, 75), (1174, 57), (1175, 35), (1177, 29), (1179, 56), (1186, 32), (1212, 17), (1223, 41), (1248, 39), (1322, 46), (1332, 7), (1417, 5), (1541, 19), (1580, 41), (1616, 1), (1623, 18), (1691, 45), (1702, 20), (1807, 49), (1851, 42)]
def cs94001 : List ℕ := [41, 215, 35, 29, 256, 113, 0, 256, 256, 184, 21, 50, 256, 256, 175, 65, 180, 235, 420, 99, 237, 65, 86, 256, 204, 522, 256, 0, 185, 132, 256, 256, 255, 256, 256, 237, 0, 256, 226, 263, 221, 256, 125, 256, 505, 255, 193, 547, 71, 98, 255, 617, 147, 256, 256, 256, 255, 256, 256, 256, 524, 227, 232, 220, 158, 255, 256, 18, 255, 80, 416, 256, 243, 255, 256, 255, 561, 231, 51, 255, 191, 593, 210, 256, 256, 200, 256, 255, 561, 255, 255, 255, 162, 256, 256, 256, 226, 256, 256, 254, 255, 256, 241, 255, 190, 256, 255, 248, 237, 356, 256, 255, 255, 179, 255, 255, 254, 256, 256, 256, 227, 256, 224, 255, 255, 230, 256, 255, 252, 254, 213, 252, 256, 256, 254, 256, 256, 197, 256, 256, 256, 256, 170, 208, 256, 256, 256, 198, 236, 237, 251, 253, 242, 256]
theorem node94001 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 60 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94001 support demand code
    entries94001 ((insert 27 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 60 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries94002 : List (Fin 2295 × ℕ) := [(4, 40), (12, 12), (32, 25), (37, 18), (177, 22), (475, 29), (498, 6), (507, 62), (529, 9), (540, 14), (542, 7), (639, 5), (742, 5), (778, 8), (780, 8), (782, 2), (819, 20), (845, 46), (850, 14), (852, 14), (855, 5), (872, 22), (873, 26), (884, 6), (885, 25), (886, 19), (904, 12), (919, 16), (920, 32), (943, 33), (944, 6), (946, 12), (953, 16), (967, 25), (968, 25), (971, 28), (972, 28), (973, 47), (984, 19), (985, 22), (1006, 5), (1009, 24), (1033, 9), (1034, 3), (1043, 11), (1045, 2), (1047, 6), (1068, 5), (1076, 20), (1100, 2), (1102, 9), (1108, 4), (1155, 20), (1174, 21), (1175, 21), (1178, 4), (1179, 20), (1183, 1), (1186, 11), (1212, 6), (1228, 6), (1229, 6), (1248, 15), (1417, 8), (1443, 2), (1580, 34), (1584, 4), (1604, 6), (1655, 2), (1663, 2), (1721, 9), (1851, 21)]
def cs94002 : List ℕ := [0, 86, 18, 43, 100, 48, 0, 100, 89, 62, 0, 29, 100, 100, 95, 9, 56, 100, 210, 61, 101, 9, 31, 101, 89, 237, 94, 0, 52, 31, 101, 100, 100, 100, 100, 100, 6, 48, 49, 100, 86, 101, 39, 101, 176, 100, 75, 0, 43, 59, 99, 106, 7, 100, 99, 99, 101, 101, 100, 100, 90, 71, 85, 7, 75, 100, 100, 1, 100, 12, 206, 100, 100, 81, 100, 100, 127, 95, 7, 100, 18, 75, 100, 101, 56, 100, 100, 101, 159, 101, 100, 100, 6, 101, 95, 91, 76, 101, 101, 100, 109, 100, 70, 101, 91, 101, 76, 96, 91, 210, 101, 99, 101, 67, 101, 101, 101, 100, 100, 100, 93, 67, 70, 102, 100, 80, 100, 100, 68, 101, 101, 89, 101, 100, 101, 100, 100, 96, 101, 100, 101, 100, 86, 80, 100, 100, 100, 78, 101, 85, 94, 97, 98, 97]
theorem node94002 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 27 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94002 support demand code
    entries94002 ((insert 47 (insert 27 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node93999 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    47 node94001 node94002
def entries94000 : List (Fin 2295 × ℕ) := [(4, 61), (10, 71), (37, 58), (137, 8), (468, 29), (475, 61), (479, 36), (507, 87), (540, 36), (588, 16), (631, 22), (679, 75), (681, 54), (690, 2), (727, 31), (738, 5), (741, 36), (742, 26), (818, 36), (819, 45), (845, 105), (872, 24), (873, 91), (874, 40), (885, 61), (887, 12), (888, 52), (897, 39), (917, 5), (918, 12), (919, 14), (920, 80), (942, 28), (943, 88), (944, 25), (960, 64), (963, 32), (964, 9), (967, 38), (968, 49), (969, 1), (970, 2), (971, 50), (972, 54), (973, 125), (978, 75), (985, 37), (1006, 8), (1009, 53), (1025, 2), (1033, 18), (1069, 37), (1075, 5), (1076, 37), (1100, 10), (1101, 3), (1102, 5), (1103, 20), (1122, 14), (1137, 2), (1139, 22), (1155, 50), (1170, 28), (1172, 8), (1174, 54), (1175, 38), (1178, 17), (1179, 56), (1186, 24), (1212, 51), (1223, 62), (1230, 2), (1247, 2), (1443, 9), (1580, 24), (1623, 9), (1663, 3), (1691, 80), (1721, 5), (1745, 25), (1851, 20), (1987, 6)]
def cs94000 : List ℕ := [62, 195, 71, 61, 254, 58, 0, 256, 181, 87, 0, 152, 257, 255, 121, 85, 160, 241, 332, 122, 256, 156, 60, 256, 92, 429, 242, 0, 85, 27, 257, 256, 249, 256, 256, 255, 0, 138, 198, 208, 73, 256, 129, 256, 561, 255, 158, 243, 85, 58, 257, 346, 22, 255, 256, 256, 255, 255, 255, 255, 14, 236, 194, 184, 206, 255, 255, 26, 257, 52, 306, 256, 255, 256, 256, 217, 509, 221, 77, 258, 218, 277, 255, 256, 202, 234, 256, 255, 433, 257, 256, 255, 116, 255, 255, 256, 179, 256, 255, 256, 257, 255, 256, 256, 256, 256, 192, 257, 220, 498, 255, 255, 257, 209, 255, 256, 256, 257, 256, 256, 219, 190, 208, 256, 257, 227, 256, 255, 240, 256, 256, 255, 255, 256, 257, 257, 256, 244, 256, 256, 257, 255, 253, 202, 257, 256, 256, 240, 256, 256, 256, 257, 256, 252]
theorem node94000 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 27 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs94000 support demand code
    entries94000 ((insert 60 (insert 27 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node93998 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    60 node93999 node94000
theorem node93989 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    27 node93997 node93998
def entries93995 : List (Fin 2295 × ℕ) := [(12, 39), (17, 41), (32, 6), (122, 10), (475, 29), (479, 15), (484, 7), (491, 53), (496, 13), (506, 22), (507, 21), (542, 7), (588, 3), (631, 9), (639, 12), (679, 23), (681, 34), (736, 30), (738, 3), (741, 29), (742, 16), (780, 5), (798, 3), (819, 9), (845, 21), (847, 18), (852, 27), (863, 10), (864, 42), (872, 24), (874, 9), (886, 33), (902, 15), (904, 7), (941, 11), (942, 9), (943, 25), (944, 19), (946, 20), (953, 21), (959, 1), (960, 12), (964, 8), (967, 14), (968, 34), (971, 10), (972, 10), (973, 51), (978, 15), (985, 24), (1006, 10), (1009, 3), (1033, 10), (1043, 14), (1048, 6), (1049, 16), (1086, 8), (1089, 1), (1090, 5), (1102, 12), (1139, 14), (1141, 6), (1155, 14), (1169, 17), (1174, 10), (1175, 19), (1178, 8), (1179, 15), (1182, 10), (1185, 1), (1186, 14), (1204, 19), (1212, 8), (1217, 15), (1219, 3), (1263, 11), (1273, 12), (1316, 2), (1443, 2), (1691, 19), (2009, 6)]
def cs93995 : List ℕ := [15, 43, 91, 92, 100, 34, 53, 99, 96, 101, 0, 100, 99, 99, 26, 29, 58, 99, 206, 45, 99, 100, 3, 98, 50, 198, 101, 100, 74, 15, 99, 99, 101, 99, 264, 99, 0, 101, 57, 43, 84, 101, 100, 99, 211, 100, 73, 101, 49, 73, 101, 130, 69, 100, 101, 99, 100, 99, 101, 126, 102, 53, 100, 72, 100, 100, 100, 27, 100, 29, 142, 100, 94, 100, 100, 84, 161, 96, 18, 89, 77, 135, 54, 99, 80, 99, 100, 100, 170, 88, 100, 100, 13, 100, 101, 78, 52, 100, 100, 100, 100, 100, 88, 101, 88, 100, 93, 74, 85, 202, 93, 100, 100, 73, 100, 100, 100, 100, 99, 100, 100, 88, 78, 99, 100, 81, 100, 100, 100, 100, 87, 97, 100, 99, 99, 100, 100, 91, 100, 100, 100, 100, 88, 101, 100, 93, 94, 95, 99, 89, 99, 100, 100, 100]
theorem node93995 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 34 (insert 59 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93995 support demand code
    entries93995 ((insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 34 (insert 59 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries93996 : List (Fin 2295 × ℕ) := [(72, 236), (146, 6), (177, 229), (475, 79), (479, 4), (491, 493), (506, 162), (507, 326), (631, 27), (639, 212), (679, 326), (681, 202), (694, 244), (736, 186), (738, 62), (741, 77), (742, 95), (780, 90), (819, 141), (845, 261), (852, 351), (873, 385), (884, 88), (886, 286), (897, 8), (920, 375), (923, 40), (931, 80), (942, 176), (943, 252), (944, 107), (946, 107), (953, 59), (957, 8), (960, 102), (967, 199), (968, 238), (971, 141), (972, 223), (973, 479), (985, 148), (1009, 156), (1021, 48), (1025, 7), (1033, 75), (1047, 35), (1048, 16), (1049, 102), (1061, 44), (1069, 215), (1076, 94), (1100, 14), (1102, 117), (1108, 6), (1139, 15), (1148, 57), (1155, 124), (1165, 24), (1169, 120), (1174, 110), (1175, 173), (1178, 68), (1179, 241), (1183, 23), (1186, 120), (1193, 229), (1204, 4), (1212, 159), (1223, 35), (1263, 379), (1273, 94), (1443, 98), (1501, 148), (1580, 93), (1584, 15), (1702, 8), (1779, 10), (1807, 128), (1851, 140), (1859, 118)]
def cs93996 : List ℕ := [382, 265, 4, 83, 854, 246, 611, 1000, 775, 616, 236, 725, 1000, 620, 562, 8, 655, 524, 1301, 0, 1000, 401, 393, 1000, 624, 1396, 1001, 1000, 244, 264, 1000, 1001, 1001, 1000, 319, 1000, 0, 1001, 1001, 375, 946, 1000, 1000, 1000, 1719, 1002, 1000, 1001, 344, 946, 1001, 1585, 528, 866, 1000, 1000, 1002, 1000, 1001, 2159, 1001, 436, 1000, 528, 710, 1000, 1001, 151, 998, 117, 1696, 1001, 882, 1000, 1000, 939, 1448, 1000, 191, 979, 635, 1321, 868, 1000, 835, 1001, 1001, 1001, 1680, 958, 999, 999, 102, 1000, 1000, 1001, 667, 1002, 999, 999, 999, 999, 904, 1000, 932, 1001, 851, 999, 942, 1970, 1000, 1000, 1000, 773, 1001, 1000, 998, 999, 1000, 1000, 905, 788, 800, 999, 999, 860, 1001, 1000, 827, 999, 895, 939, 1000, 1000, 999, 1000, 1000, 1000, 1000, 998, 1000, 1000, 932, 941, 999, 961, 1000, 956, 1000, 868, 917, 999, 999, 999]
theorem node93996 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93996 support demand code
    entries93996 ((insert 34 (insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 59 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node93991 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 59 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    34 node93995 node93996
def entries93993 : List (Fin 2295 × ℕ) := [(4, 66), (17, 3), (32, 90), (72, 63), (86, 26), (177, 10), (350, 37), (475, 38), (491, 94), (507, 48), (529, 60), (583, 95), (588, 56), (631, 19), (679, 50), (681, 42), (729, 9), (740, 54), (742, 9), (778, 5), (780, 62), (798, 25), (819, 47), (845, 95), (873, 99), (874, 46), (884, 24), (886, 70), (897, 33), (943, 71), (944, 11), (953, 49), (955, 16), (956, 6), (959, 16), (960, 92), (964, 10), (966, 7), (967, 43), (968, 53), (970, 28), (971, 25), (972, 53), (973, 127), (985, 53), (1006, 6), (1009, 52), (1023, 7), (1033, 26), (1034, 6), (1043, 9), (1047, 8), (1069, 23), (1076, 19), (1090, 1), (1100, 13), (1101, 8), (1102, 4), (1103, 21), (1104, 8), (1108, 11), (1138, 8), (1139, 19), (1155, 54), (1165, 3), (1169, 35), (1171, 9), (1174, 46), (1175, 42), (1178, 13), (1179, 53), (1186, 16), (1193, 41), (1212, 58), (1273, 1), (1313, 10), (1316, 3), (1497, 6), (1604, 61), (1663, 7), (1699, 48), (1702, 24), (1765, 13), (1766, 34), (1851, 32), (1859, 67)]
def cs93993 : List ℕ := [118, 161, 61, 64, 117, 201, 161, 223, 257, 143, 63, 238, 257, 256, 180, 24, 256, 244, 415, 199, 256, 122, 171, 257, 228, 559, 255, 256, 238, 101, 256, 256, 256, 256, 256, 167, 61, 364, 237, 0, 223, 257, 232, 255, 360, 257, 156, 256, 82, 155, 257, 311, 256, 256, 255, 256, 256, 256, 255, 0, 257, 228, 255, 204, 175, 256, 256, 57, 255, 46, 271, 255, 256, 256, 256, 245, 540, 248, 50, 195, 162, 365, 222, 255, 199, 256, 256, 257, 476, 231, 256, 256, 169, 255, 255, 256, 191, 256, 256, 256, 286, 256, 238, 256, 256, 255, 231, 245, 206, 470, 255, 256, 256, 183, 256, 256, 256, 256, 256, 256, 255, 198, 203, 257, 256, 249, 256, 256, 256, 256, 255, 256, 256, 257, 256, 258, 256, 243, 257, 256, 256, 256, 239, 219, 257, 256, 257, 248, 256, 256, 257, 256, 257, 256]
theorem node93993 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93993 support demand code
    entries93993 ((insert 59 (insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 37 (insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries93994 : List (Fin 2295 × ℕ) := [(4, 2), (32, 36), (37, 18), (72, 16), (86, 26), (177, 3), (349, 6), (350, 9), (468, 38), (506, 28), (507, 38), (529, 21), (583, 44), (679, 7), (740, 34), (741, 3), (742, 15), (780, 18), (782, 6), (819, 5), (845, 48), (873, 34), (874, 19), (923, 13), (941, 14), (942, 15), (943, 35), (944, 12), (945, 1), (946, 27), (953, 21), (964, 20), (967, 7), (968, 32), (970, 1), (971, 19), (972, 20), (973, 54), (978, 5), (985, 11), (1009, 19), (1021, 9), (1033, 6), (1034, 4), (1069, 10), (1072, 8), (1073, 4), (1076, 11), (1090, 3), (1095, 3), (1102, 1), (1122, 10), (1138, 2), (1139, 14), (1155, 16), (1170, 13), (1171, 3), (1174, 14), (1175, 19), (1179, 18), (1182, 1), (1183, 3), (1186, 17), (1193, 20), (1212, 10), (1223, 14), (1593, 10), (1660, 2), (1691, 21), (1851, 3), (1987, 28)]
def cs93994 : List ℕ := [34, 88, 0, 0, 36, 64, 0, 100, 100, 76, 16, 78, 100, 84, 38, 21, 52, 101, 140, 64, 100, 75, 3, 100, 66, 177, 100, 44, 73, 3, 100, 101, 100, 100, 100, 54, 0, 0, 82, 0, 36, 97, 47, 100, 144, 99, 58, 63, 52, 0, 99, 170, 70, 101, 99, 100, 98, 100, 100, 14, 100, 59, 50, 99, 66, 100, 99, 4, 100, 47, 138, 99, 100, 99, 100, 85, 165, 92, 40, 100, 63, 136, 100, 100, 67, 83, 100, 98, 143, 73, 99, 100, 0, 100, 100, 100, 70, 97, 99, 99, 100, 101, 100, 99, 79, 98, 82, 83, 84, 228, 101, 100, 100, 51, 98, 100, 100, 99, 100, 100, 99, 78, 73, 99, 99, 98, 100, 100, 98, 100, 77, 100, 99, 99, 100, 98, 100, 87, 99, 100, 98, 100, 92, 81, 99, 95, 86, 97, 99, 98, 100, 100, 100, 100]
theorem node93994 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 59 (insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93994 support demand code
    entries93994 ((insert 37 (insert 59 (insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node93992 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 59 (insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    37 node93993 node93994
theorem node93990 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    59 node93991 node93992
theorem node93973 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 18 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    39 node93989 node93990
def entries93987 : List (Fin 2295 × ℕ) := [(4, 25), (30, 74), (340, 3), (479, 71), (485, 120), (491, 153), (497, 64), (542, 20), (631, 56), (639, 23), (679, 58), (681, 126), (738, 58), (741, 35), (742, 16), (780, 34), (835, 7), (845, 71), (852, 96), (873, 31), (884, 40), (885, 41), (886, 49), (887, 26), (888, 15), (890, 41), (891, 39), (892, 17), (897, 47), (904, 46), (918, 14), (920, 77), (926, 70), (931, 42), (941, 31), (942, 28), (944, 27), (946, 57), (947, 55), (953, 50), (960, 39), (967, 48), (968, 68), (970, 14), (971, 25), (972, 46), (973, 130), (985, 50), (1006, 12), (1009, 62), (1013, 1), (1014, 2), (1025, 11), (1033, 5), (1043, 8), (1045, 32), (1061, 3), (1069, 40), (1073, 46), (1103, 1), (1108, 14), (1128, 2), (1139, 15), (1141, 7), (1144, 1), (1145, 2), (1155, 64), (1165, 4), (1174, 57), (1175, 10), (1178, 19), (1179, 13), (1182, 16), (1183, 3), (1186, 19), (1193, 64), (1212, 40), (1248, 59), (1322, 11), (1401, 11), (1417, 37), (1585, 20), (1692, 65), (1851, 35)]
def cs93987 : List ℕ := [64, 96, 0, 0, 256, 194, 153, 238, 227, 65, 0, 153, 255, 170, 120, 65, 250, 164, 31, 106, 255, 236, 47, 255, 46, 418, 256, 250, 65, 56, 255, 256, 255, 256, 256, 208, 39, 256, 184, 257, 113, 255, 183, 255, 538, 255, 256, 471, 122, 255, 256, 552, 232, 256, 257, 256, 256, 256, 230, 471, 595, 104, 256, 207, 198, 255, 256, 33, 256, 100, 487, 256, 147, 256, 256, 256, 471, 255, 156, 256, 256, 511, 256, 257, 256, 256, 256, 256, 582, 256, 255, 256, 54, 417, 255, 257, 197, 255, 255, 256, 256, 256, 206, 255, 256, 257, 216, 257, 256, 500, 256, 256, 256, 157, 239, 256, 255, 254, 257, 256, 256, 171, 205, 255, 255, 204, 256, 256, 256, 256, 228, 198, 255, 256, 256, 256, 256, 233, 256, 256, 255, 256, 189, 256, 255, 256, 257, 203, 256, 255, 256, 255, 255, 256]
theorem node93987 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 93 (insert 60 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93987 support demand code
    entries93987 ((insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 59 (insert 93 (insert 60 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries93988 : List (Fin 2295 × ℕ) := [(4, 37), (12, 14), (32, 24), (177, 14), (444, 14), (485, 40), (491, 35), (497, 19), (542, 10), (579, 8), (583, 15), (588, 16), (631, 26), (643, 1), (679, 8), (681, 44), (741, 6), (742, 17), (778, 9), (780, 27), (782, 1), (798, 1), (845, 40), (852, 2), (873, 25), (884, 28), (885, 18), (886, 13), (888, 16), (892, 27), (897, 8), (917, 15), (919, 43), (926, 28), (942, 16), (944, 16), (946, 25), (947, 32), (953, 22), (959, 10), (960, 15), (967, 20), (968, 20), (969, 6), (972, 8), (973, 46), (985, 18), (1006, 18), (1009, 33), (1021, 2), (1025, 3), (1033, 13), (1068, 1), (1069, 10), (1076, 7), (1100, 2), (1102, 4), (1103, 7), (1108, 4), (1155, 29), (1165, 3), (1169, 1), (1174, 24), (1175, 17), (1178, 4), (1179, 21), (1193, 20), (1212, 22), (1273, 4), (1316, 2), (1318, 4), (1417, 5), (1425, 15), (1534, 6), (1629, 1), (1692, 15), (1699, 3), (1851, 15)]
def cs93988 : List ℕ := [20, 77, 14, 0, 73, 64, 50, 42, 100, 18, 1, 50, 99, 43, 82, 15, 100, 100, 25, 72, 101, 80, 41, 101, 3, 217, 100, 101, 53, 43, 100, 100, 100, 100, 100, 18, 0, 101, 69, 78, 41, 100, 82, 100, 188, 101, 77, 161, 57, 100, 101, 203, 101, 100, 100, 100, 101, 100, 100, 2, 262, 49, 101, 77, 65, 92, 100, 17, 100, 52, 168, 100, 100, 100, 100, 99, 214, 67, 60, 100, 93, 203, 41, 99, 100, 95, 100, 100, 255, 101, 100, 100, 47, 135, 100, 100, 63, 100, 100, 100, 109, 100, 68, 101, 100, 101, 100, 80, 99, 176, 101, 100, 100, 67, 93, 101, 100, 101, 100, 101, 94, 76, 76, 100, 101, 100, 100, 100, 100, 100, 94, 88, 99, 101, 100, 102, 100, 78, 101, 101, 101, 100, 76, 90, 101, 100, 98, 73, 94, 92, 100, 98, 100, 101]
theorem node93988 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 60 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93988 support demand code
    entries93988 ((insert 59 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 60 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node93985 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 60 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 60 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    59 node93987 node93988
def entries93986 : List (Fin 2295 × ℕ) := [(4, 25), (32, 10), (479, 30), (485, 31), (491, 39), (497, 10), (574, 7), (629, 17), (631, 13), (639, 16), (679, 41), (681, 33), (690, 6), (741, 41), (780, 8), (819, 17), (845, 33), (852, 24), (856, 2), (865, 2), (870, 4), (873, 13), (884, 4), (885, 22), (886, 16), (888, 11), (890, 27), (892, 17), (917, 23), (919, 10), (920, 16), (921, 14), (941, 4), (943, 17), (944, 15), (946, 15), (953, 14), (960, 19), (962, 13), (964, 13), (971, 15), (972, 16), (973, 45), (985, 27), (1006, 1), (1009, 27), (1012, 2), (1028, 10), (1033, 8), (1069, 7), (1070, 6), (1076, 10), (1098, 11), (1100, 1), (1102, 6), (1103, 1), (1108, 24), (1146, 4), (1147, 1), (1148, 1), (1155, 23), (1174, 22), (1175, 26), (1179, 28), (1193, 18), (1212, 25), (1229, 1), (1273, 6), (1292, 11), (1501, 14), (1578, 2), (1585, 5), (1614, 13), (1621, 1), (1692, 42), (1846, 1)]
def cs93986 : List ℕ := [18, 58, 0, 0, 99, 67, 54, 89, 76, 42, 15, 58, 100, 55, 58, 57, 99, 80, 13, 70, 100, 88, 14, 98, 26, 170, 98, 100, 52, 30, 100, 100, 100, 100, 100, 74, 26, 100, 74, 100, 66, 99, 87, 100, 224, 101, 100, 187, 57, 96, 100, 184, 71, 99, 100, 101, 100, 101, 72, 99, 142, 74, 99, 89, 75, 101, 100, 23, 99, 32, 133, 100, 99, 100, 100, 101, 213, 99, 17, 100, 100, 119, 73, 100, 97, 96, 101, 100, 168, 99, 99, 100, 43, 0, 100, 100, 74, 100, 99, 100, 100, 100, 71, 100, 100, 78, 98, 99, 87, 157, 99, 100, 100, 64, 100, 98, 100, 100, 101, 100, 84, 64, 80, 99, 86, 74, 100, 100, 90, 100, 100, 94, 101, 100, 99, 101, 100, 76, 101, 100, 100, 101, 94, 100, 100, 100, 101, 95, 98, 92, 99, 100, 100, 100]
theorem node93986 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93986 support demand code
    entries93986 ((insert 93 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node93981 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    93 node93985 node93986
def entries93983 : List (Fin 2295 × ℕ) := [(4, 110), (32, 154), (72, 411), (137, 116), (349, 9), (479, 123), (514, 191), (583, 26), (587, 70), (588, 333), (629, 172), (679, 56), (681, 163), (729, 125), (741, 253), (742, 235), (798, 97), (818, 155), (845, 537), (852, 7), (873, 237), (885, 191), (888, 205), (890, 56), (892, 243), (897, 119), (904, 222), (917, 43), (920, 284), (921, 22), (942, 206), (943, 365), (944, 42), (945, 42), (946, 26), (960, 353), (963, 29), (964, 184), (966, 21), (968, 184), (970, 176), (971, 35), (972, 225), (973, 485), (985, 261), (1006, 23), (1009, 335), (1012, 76), (1069, 108), (1073, 22), (1075, 137), (1076, 177), (1086, 1), (1100, 53), (1101, 36), (1103, 50), (1122, 14), (1123, 46), (1138, 45), (1155, 214), (1172, 70), (1174, 222), (1175, 186), (1178, 30), (1179, 228), (1186, 59), (1193, 178), (1204, 10), (1212, 228), (1223, 157), (1230, 13), (1263, 306), (1448, 63), (1517, 115), (1623, 123), (1692, 137), (1987, 204)]
def cs93983 : List ℕ := [335, 657, 10, 10, 585, 154, 115, 824, 915, 137, 602, 272, 1000, 384, 709, 137, 655, 950, 237, 559, 1000, 841, 522, 1000, 222, 1968, 505, 1000, 702, 172, 1000, 1000, 655, 999, 1001, 861, 0, 1000, 834, 1000, 762, 999, 1001, 999, 2004, 1001, 981, 1242, 205, 410, 1000, 1456, 389, 1000, 1001, 1000, 1000, 999, 999, 1000, 0, 553, 1001, 799, 871, 1000, 1000, 281, 1001, 374, 1403, 1000, 1000, 999, 1000, 907, 1931, 957, 304, 1000, 821, 1476, 1000, 1538, 960, 850, 1001, 1000, 1919, 989, 1000, 1000, 558, 999, 1000, 1001, 795, 1001, 999, 987, 1077, 999, 825, 1000, 1001, 1001, 817, 999, 953, 1786, 1000, 1151, 999, 655, 1000, 1000, 1000, 1000, 1000, 1001, 999, 841, 803, 1000, 1000, 913, 1001, 1000, 1000, 1000, 1000, 963, 1001, 1000, 1000, 1001, 1001, 950, 1001, 1000, 1000, 1001, 973, 773, 1000, 1001, 1001, 842, 1001, 994, 1000, 1001, 1000, 999]
theorem node93983 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93983 support demand code
    entries93983 ((insert 60 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 83 (insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries93984 : List (Fin 2295 × ℕ) := [(4, 50), (72, 39), (137, 61), (177, 19), (340, 7), (479, 43), (514, 92), (573, 14), (588, 135), (631, 29), (679, 104), (681, 5), (729, 5), (740, 21), (741, 50), (742, 1), (817, 37), (818, 27), (819, 25), (845, 164), (852, 31), (873, 48), (883, 8), (885, 84), (887, 18), (888, 72), (890, 50), (892, 22), (918, 39), (920, 52), (942, 43), (943, 13), (945, 30), (960, 76), (962, 57), (963, 6), (964, 23), (966, 35), (970, 3), (971, 38), (972, 41), (973, 119), (985, 56), (1006, 11), (1007, 19), (1009, 62), (1021, 32), (1031, 33), (1033, 43), (1034, 14), (1045, 3), (1069, 4), (1076, 32), (1103, 1), (1104, 17), (1108, 21), (1137, 14), (1139, 17), (1155, 46), (1165, 14), (1170, 1), (1174, 59), (1175, 60), (1179, 60), (1183, 14), (1186, 31), (1193, 10), (1212, 45), (1263, 92), (1403, 12), (1692, 92), (1699, 31), (1851, 38)]
def cs93984 : List ℕ := [10, 214, 0, 0, 134, 0, 0, 238, 152, 123, 131, 0, 256, 171, 99, 92, 245, 238, 48, 227, 256, 256, 185, 256, 31, 487, 152, 256, 131, 79, 256, 257, 227, 256, 256, 256, 0, 256, 198, 183, 227, 256, 247, 256, 442, 255, 238, 278, 172, 0, 257, 393, 128, 256, 255, 256, 255, 256, 256, 257, 0, 256, 247, 241, 209, 242, 254, 61, 255, 70, 359, 195, 166, 256, 256, 159, 639, 256, 79, 255, 216, 377, 255, 16, 255, 256, 255, 255, 441, 256, 254, 256, 205, 147, 256, 256, 152, 255, 259, 255, 255, 257, 227, 255, 255, 256, 255, 255, 248, 364, 256, 257, 239, 155, 248, 256, 255, 253, 256, 256, 215, 185, 199, 255, 254, 239, 256, 256, 245, 255, 255, 253, 256, 255, 254, 255, 242, 230, 255, 255, 254, 238, 225, 230, 254, 240, 237, 231, 255, 254, 255, 255, 255, 255]
theorem node93984 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 83 (insert 60 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93984 support demand code
    entries93984 ((insert 83 (insert 60 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node93982 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    83 node93983 node93984
theorem node93975 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    60 node93981 node93982
def entries93979 : List (Fin 2295 × ℕ) := [(4, 163), (340, 49), (491, 155), (498, 200), (512, 6), (514, 497), (639, 162), (690, 57), (694, 120), (738, 108), (741, 298), (742, 105), (780, 60), (819, 208), (845, 341), (852, 239), (873, 251), (884, 93), (885, 180), (886, 223), (888, 102), (890, 302), (904, 247), (920, 435), (923, 89), (926, 226), (931, 131), (941, 96), (943, 45), (944, 123), (945, 213), (946, 213), (953, 131), (964, 56), (968, 277), (972, 177), (973, 504), (985, 240), (1007, 10), (1009, 173), (1012, 68), (1021, 14), (1033, 9), (1043, 88), (1047, 33), (1049, 39), (1068, 88), (1075, 24), (1076, 112), (1102, 81), (1108, 89), (1139, 28), (1147, 32), (1155, 212), (1169, 79), (1174, 184), (1175, 224), (1179, 244), (1193, 178), (1212, 154), (1230, 42), (1248, 81), (1263, 459), (1273, 88), (1316, 38), (1405, 208), (1410, 12), (1417, 28), (1443, 6), (1584, 56), (1692, 239), (1699, 106), (1847, 78)]
def cs93979 : List ℕ := [178, 504, 0, 0, 580, 0, 155, 580, 1000, 345, 503, 155, 1000, 596, 341, 239, 999, 682, 251, 447, 999, 1000, 106, 1000, 353, 1497, 353, 1419, 239, 106, 999, 1000, 560, 1000, 1000, 1000, 0, 658, 106, 1000, 816, 1000, 869, 1000, 1897, 1000, 1000, 0, 771, 1000, 1000, 1029, 701, 1000, 1000, 1000, 1000, 961, 677, 1870, 999, 435, 1000, 105, 932, 1000, 999, 79, 1000, 426, 2290, 999, 748, 891, 1001, 891, 2014, 1000, 280, 1000, 528, 1124, 999, 1001, 560, 1000, 999, 998, 2308, 841, 999, 999, 192, 1000, 1001, 1000, 702, 999, 1001, 999, 1059, 1000, 839, 1000, 909, 1000, 741, 1000, 831, 1903, 1000, 999, 1000, 673, 1000, 999, 1000, 1000, 1000, 999, 1001, 823, 650, 1000, 907, 770, 1000, 999, 743, 999, 856, 991, 999, 999, 1001, 999, 1000, 1000, 1000, 1000, 1000, 999, 891, 957, 1001, 1000, 971, 882, 958, 842, 1000, 952, 1000, 1000]
theorem node93979 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 27 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93979 support demand code
    entries93979 ((insert 47 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 59 (insert 27 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries93980 : List (Fin 2295 × ℕ) := [(4, 304), (37, 60), (137, 72), (177, 163), (275, 52), (498, 387), (514, 311), (574, 108), (583, 456), (620, 1), (740, 34), (741, 69), (742, 250), (778, 83), (819, 250), (845, 489), (848, 122), (873, 310), (885, 277), (886, 34), (888, 238), (890, 68), (892, 130), (917, 238), (919, 307), (926, 91), (943, 137), (944, 135), (945, 231), (946, 260), (953, 259), (960, 45), (964, 137), (968, 314), (971, 6), (972, 194), (973, 498), (985, 199), (1006, 106), (1009, 296), (1012, 29), (1033, 143), (1043, 18), (1061, 19), (1069, 82), (1076, 190), (1098, 19), (1101, 71), (1104, 30), (1154, 58), (1155, 241), (1169, 93), (1172, 7), (1174, 159), (1175, 242), (1179, 215), (1186, 11), (1193, 113), (1212, 173), (1221, 123), (1273, 5), (1363, 139), (1396, 88), (1405, 177), (1417, 44), (1629, 76), (1692, 346), (1845, 58), (1849, 13), (1851, 64)]
def cs93980 : List ℕ := [236, 793, 245, 0, 417, 183, 0, 734, 864, 346, 387, 123, 999, 656, 417, 346, 893, 906, 310, 752, 999, 1000, 163, 999, 0, 1962, 901, 1130, 346, 163, 999, 1001, 565, 999, 999, 733, 245, 387, 223, 898, 72, 1000, 583, 1000, 1850, 1000, 743, 0, 1000, 824, 1000, 1176, 767, 999, 999, 999, 1000, 1000, 801, 0, 1001, 443, 1000, 665, 870, 999, 999, 407, 1001, 621, 1441, 823, 1000, 1000, 921, 886, 2328, 871, 144, 1000, 729, 1269, 996, 1001, 434, 999, 999, 1000, 2276, 1000, 1000, 1001, 283, 922, 884, 998, 871, 1000, 1000, 1000, 1076, 1000, 878, 1001, 998, 999, 862, 686, 918, 1954, 1000, 1000, 1000, 673, 999, 999, 1001, 1000, 1000, 1000, 1001, 791, 685, 999, 1000, 1000, 999, 1000, 907, 1000, 918, 999, 1000, 1000, 999, 999, 999, 915, 1000, 1000, 1000, 1000, 993, 750, 999, 999, 888, 782, 1000, 841, 988, 968, 999, 928]
theorem node93980 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 47 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93980 support demand code
    entries93980 ((insert 59 (insert 47 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 27 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node93977 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 27 (insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    59 node93979 node93980
def entries93978 : List (Fin 2295 × ℕ) := [(17, 22), (37, 23), (498, 118), (540, 53), (542, 66), (694, 31), (741, 87), (742, 15), (780, 8), (782, 12), (819, 50), (845, 138), (852, 77), (869, 12), (873, 93), (885, 55), (886, 52), (887, 33), (888, 27), (890, 19), (904, 12), (919, 30), (920, 58), (926, 23), (941, 46), (943, 27), (944, 45), (945, 46), (946, 54), (953, 46), (960, 32), (964, 25), (967, 1), (968, 73), (972, 36), (973, 126), (984, 19), (985, 59), (1009, 70), (1033, 25), (1047, 1), (1061, 8), (1068, 5), (1069, 40), (1076, 15), (1100, 25), (1101, 23), (1104, 4), (1108, 55), (1139, 12), (1155, 68), (1169, 22), (1174, 33), (1175, 54), (1177, 2), (1179, 74), (1186, 3), (1193, 19), (1212, 42), (1230, 1), (1248, 39), (1273, 15), (1318, 6), (1405, 46), (1443, 13), (1623, 50), (1692, 39), (1699, 96), (1851, 18)]
def cs93978 : List ℕ := [19, 138, 0, 22, 96, 23, 0, 215, 182, 135, 0, 12, 256, 250, 138, 39, 107, 191, 93, 218, 257, 80, 96, 256, 108, 387, 153, 19, 39, 96, 257, 256, 62, 256, 256, 255, 0, 0, 119, 256, 127, 256, 72, 257, 528, 257, 215, 0, 235, 175, 256, 279, 66, 256, 255, 256, 256, 256, 193, 255, 256, 167, 157, 91, 196, 256, 256, 84, 255, 133, 473, 256, 229, 255, 256, 240, 614, 256, 25, 256, 127, 371, 256, 254, 97, 233, 256, 256, 578, 256, 256, 256, 59, 254, 238, 255, 171, 255, 257, 256, 254, 256, 195, 256, 230, 255, 237, 250, 187, 464, 256, 256, 219, 194, 255, 256, 255, 255, 255, 255, 256, 226, 174, 255, 255, 218, 255, 256, 245, 254, 244, 237, 255, 254, 255, 255, 255, 228, 255, 254, 254, 256, 206, 255, 256, 256, 240, 248, 242, 204, 255, 234, 251, 255]
theorem node93978 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 47 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93978 support demand code
    entries93978 ((insert 27 (insert 47 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node93976 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    27 node93977 node93978
theorem node93974 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    47 node93975 node93976
theorem node93961 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 51 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    18 node93973 node93974
def entries93971 : List (Fin 2295 × ℕ) := [(4, 46), (92, 89), (177, 66), (475, 120), (491, 69), (507, 133), (542, 45), (583, 23), (631, 30), (639, 35), (727, 7), (729, 37), (736, 88), (738, 23), (741, 61), (742, 7), (798, 22), (834, 35), (835, 16), (845, 40), (852, 45), (856, 30), (860, 1), (872, 63), (873, 84), (874, 7), (885, 15), (886, 79), (892, 2), (920, 89), (922, 14), (926, 3), (928, 81), (931, 43), (942, 12), (943, 88), (960, 27), (967, 48), (968, 63), (971, 51), (972, 73), (973, 137), (977, 5), (985, 60), (998, 2), (1009, 32), (1025, 15), (1033, 1), (1034, 5), (1043, 10), (1045, 25), (1047, 6), (1069, 41), (1072, 3), (1073, 32), (1076, 21), (1086, 2), (1089, 8), (1090, 24), (1102, 15), (1108, 11), (1139, 5), (1141, 15), (1145, 2), (1155, 26), (1174, 41), (1175, 12), (1178, 27), (1179, 31), (1182, 8), (1183, 16), (1185, 8), (1186, 31), (1189, 65), (1193, 49), (1212, 32), (1223, 9), (1273, 7), (1417, 17), (1578, 37), (1584, 4), (1585, 17), (1660, 12), (1702, 73), (1770, 56), (1779, 4), (1850, 4), (1851, 21), (1852, 6), (2009, 9)]
def cs93971 : List ℕ := [114, 207, 65, 120, 255, 95, 106, 256, 179, 142, 37, 235, 256, 256, 242, 110, 145, 256, 630, 0, 256, 139, 139, 255, 243, 449, 256, 256, 73, 178, 256, 257, 256, 255, 256, 255, 37, 256, 220, 256, 159, 171, 194, 257, 639, 256, 255, 222, 139, 257, 255, 0, 204, 255, 255, 256, 257, 256, 256, 496, 134, 233, 256, 105, 249, 254, 255, 24, 256, 13, 321, 256, 226, 256, 254, 256, 369, 255, 148, 256, 125, 327, 256, 256, 161, 254, 256, 257, 499, 255, 256, 257, 27, 404, 258, 219, 124, 256, 257, 256, 255, 256, 256, 257, 229, 256, 239, 256, 251, 493, 255, 257, 257, 246, 254, 255, 256, 258, 257, 257, 243, 200, 205, 254, 256, 169, 256, 256, 175, 255, 256, 192, 255, 257, 255, 257, 256, 255, 256, 256, 257, 256, 230, 256, 256, 256, 257, 239, 257, 256, 256, 256, 256, 257]
theorem node93971 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 93 (insert 18 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93971 support demand code
    entries93971 ((insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 59 (insert 93 (insert 18 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries93972 : List (Fin 2295 × ℕ) := [(4, 55), (10, 24), (12, 73), (135, 2), (177, 124), (471, 38), (475, 95), (491, 50), (507, 101), (542, 71), (577, 13), (583, 36), (588, 13), (631, 67), (729, 50), (740, 12), (741, 25), (778, 41), (798, 39), (834, 27), (835, 28), (845, 86), (856, 39), (873, 74), (874, 29), (884, 23), (885, 35), (886, 77), (888, 41), (919, 69), (920, 12), (923, 1), (926, 6), (928, 34), (942, 17), (943, 67), (956, 30), (960, 73), (963, 8), (964, 12), (967, 26), (968, 53), (969, 38), (971, 23), (972, 65), (973, 123), (984, 17), (985, 32), (1006, 7), (1009, 55), (1012, 4), (1023, 11), (1025, 26), (1033, 27), (1034, 13), (1043, 11), (1076, 28), (1090, 18), (1097, 1), (1098, 11), (1100, 17), (1103, 7), (1104, 4), (1122, 1), (1123, 12), (1155, 45), (1169, 3), (1170, 8), (1174, 51), (1175, 45), (1178, 19), (1179, 63), (1186, 12), (1189, 45), (1193, 40), (1204, 18), (1212, 58), (1281, 5), (1405, 15), (1497, 26), (1655, 12), (1846, 7), (1851, 35), (1859, 19), (1866, 11), (2287, 51)]
def cs93972 : List ℕ := [75, 255, 203, 129, 255, 58, 80, 255, 158, 101, 0, 231, 255, 196, 229, 0, 199, 255, 468, 114, 255, 129, 137, 255, 195, 588, 255, 255, 73, 191, 256, 255, 246, 255, 256, 121, 0, 255, 158, 255, 73, 211, 130, 255, 476, 256, 171, 203, 124, 169, 256, 0, 256, 256, 255, 256, 255, 255, 255, 12, 256, 174, 256, 127, 210, 256, 255, 33, 257, 29, 193, 255, 256, 256, 255, 256, 395, 252, 85, 256, 125, 232, 256, 255, 183, 255, 256, 255, 471, 257, 256, 256, 114, 352, 256, 256, 199, 256, 256, 256, 298, 256, 233, 257, 256, 256, 256, 222, 256, 474, 256, 255, 256, 202, 225, 256, 256, 256, 255, 256, 257, 220, 203, 256, 257, 245, 256, 256, 231, 256, 257, 256, 256, 256, 257, 255, 256, 236, 257, 256, 257, 256, 231, 193, 255, 257, 256, 222, 257, 244, 256, 257, 256, 238]
theorem node93972 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 18 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93972 support demand code
    entries93972 ((insert 59 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 18 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node93969 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 18 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 18 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    59 node93971 node93972
def entries93970 : List (Fin 2295 × ℕ) := [(4, 50), (7, 4), (32, 18), (92, 9), (177, 32), (449, 4), (460, 5), (471, 4), (475, 33), (479, 10), (491, 42), (507, 48), (542, 21), (583, 8), (629, 25), (639, 24), (729, 22), (741, 38), (819, 4), (845, 14), (846, 9), (852, 27), (856, 30), (872, 33), (873, 22), (874, 8), (885, 9), (886, 23), (919, 12), (920, 22), (923, 17), (928, 3), (942, 3), (943, 35), (944, 6), (946, 5), (960, 13), (964, 8), (967, 2), (968, 15), (971, 18), (972, 26), (973, 49), (984, 16), (985, 25), (1009, 16), (1033, 10), (1040, 4), (1043, 2), (1045, 15), (1073, 7), (1076, 13), (1089, 9), (1090, 9), (1097, 1), (1098, 9), (1100, 3), (1102, 18), (1104, 2), (1108, 5), (1144, 5), (1147, 1), (1148, 5), (1155, 7), (1174, 23), (1175, 23), (1179, 21), (1186, 21), (1204, 9), (1212, 7), (1273, 15), (1277, 1), (1281, 10), (1320, 1), (1572, 3), (1584, 1), (1585, 8), (1621, 2), (1767, 13), (2287, 13)]
def cs93970 : List ℕ := [23, 99, 36, 65, 100, 48, 42, 100, 77, 48, 0, 98, 100, 98, 80, 0, 46, 99, 202, 18, 100, 34, 32, 100, 75, 207, 100, 99, 18, 57, 101, 100, 98, 100, 99, 100, 0, 100, 35, 100, 28, 61, 83, 100, 251, 100, 88, 80, 37, 43, 100, 0, 96, 100, 100, 100, 100, 100, 100, 100, 90, 61, 92, 41, 73, 90, 100, 0, 101, 13, 141, 100, 100, 74, 100, 101, 126, 101, 11, 101, 30, 62, 99, 100, 59, 101, 100, 100, 158, 87, 101, 100, 13, 17, 100, 101, 68, 101, 100, 101, 100, 100, 36, 100, 83, 99, 93, 100, 75, 186, 100, 99, 99, 82, 101, 100, 101, 100, 100, 122, 92, 101, 79, 100, 63, 70, 100, 99, 73, 100, 100, 100, 101, 99, 100, 100, 100, 93, 100, 100, 100, 100, 94, 100, 100, 100, 100, 97, 88, 100, 79, 100, 100, 100]
theorem node93970 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93970 support demand code
    entries93970 ((insert 93 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 18 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node93963 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    93 node93969 node93970
def entries93965 : List (Fin 2295 × ℕ) := [(4, 4), (32, 14), (64, 18), (122, 10), (340, 5), (444, 2), (479, 12), (490, 1), (491, 17), (527, 4), (542, 4), (588, 6), (631, 6), (639, 4), (729, 5), (736, 2), (741, 2), (742, 1), (778, 2), (780, 2), (819, 2), (845, 10), (852, 4), (853, 4), (856, 5), (860, 2), (864, 1), (870, 4), (886, 13), (890, 10), (903, 1), (904, 14), (905, 1), (920, 7), (928, 9), (941, 8), (942, 6), (945, 2), (946, 2), (960, 9), (964, 3), (967, 4), (968, 7), (969, 4), (971, 4), (972, 6), (973, 16), (984, 6), (985, 6), (1009, 10), (1033, 2), (1043, 4), (1061, 2), (1072, 3), (1073, 1), (1075, 3), (1076, 4), (1100, 2), (1108, 2), (1145, 2), (1155, 8), (1174, 5), (1175, 7), (1179, 8), (1186, 1), (1204, 12), (1212, 6), (1273, 1), (1655, 1), (1846, 3), (1851, 10)]
def cs93965 : List ℕ := [0, 26, 12, 12, 32, 23, 18, 26, 32, 19, 0, 22, 25, 30, 20, 10, 13, 30, 5, 32, 32, 32, 6, 32, 16, 74, 6, 32, 24, 6, 31, 31, 7, 32, 87, 22, 0, 30, 9, 31, 26, 21, 28, 31, 61, 32, 32, 31, 32, 31, 32, 0, 32, 32, 32, 32, 32, 32, 17, 31, 32, 27, 31, 12, 24, 32, 32, 0, 32, 4, 48, 32, 20, 32, 33, 32, 56, 31, 13, 32, 18, 34, 30, 31, 28, 33, 25, 32, 75, 32, 31, 32, 9, 32, 31, 25, 27, 32, 32, 31, 34, 32, 31, 31, 28, 27, 32, 27, 32, 61, 32, 32, 31, 30, 33, 32, 29, 32, 32, 32, 31, 28, 23, 32, 30, 27, 32, 32, 30, 32, 32, 28, 33, 32, 32, 32, 32, 31, 32, 33, 32, 32, 26, 28, 32, 32, 32, 25, 32, 28, 32, 30, 31, 32]
theorem node93965 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 34 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93965 support demand code
    entries93965 ((insert 18 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 34 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
def entries93967 : List (Fin 2295 × ℕ) := [(4, 128), (177, 120), (340, 1), (444, 30), (468, 3), (479, 100), (491, 102), (527, 54), (574, 12), (583, 96), (588, 90), (631, 32), (644, 20), (729, 46), (741, 57), (798, 8), (845, 120), (852, 8), (856, 79), (870, 8), (873, 82), (884, 17), (885, 14), (886, 89), (888, 82), (890, 27), (917, 35), (918, 21), (919, 58), (920, 51), (923, 2), (926, 8), (928, 7), (931, 14), (941, 3), (942, 76), (943, 36), (944, 27), (945, 23), (946, 28), (960, 83), (964, 11), (967, 18), (968, 39), (969, 25), (970, 1), (971, 9), (972, 26), (973, 130), (984, 39), (985, 25), (1006, 17), (1009, 87), (1021, 4), (1023, 14), (1033, 34), (1061, 15), (1068, 3), (1075, 9), (1076, 27), (1099, 31), (1100, 36), (1108, 28), (1145, 45), (1155, 52), (1174, 48), (1175, 78), (1179, 48), (1183, 15), (1186, 45), (1212, 2), (1241, 13), (1316, 24), (1322, 9), (1610, 25), (1623, 43), (1629, 6), (1660, 2), (1851, 56)]
def cs93967 : List ℕ := [0, 251, 0, 0, 236, 79, 102, 231, 128, 0, 31, 113, 256, 82, 153, 0, 154, 256, 82, 94, 256, 148, 210, 256, 0, 517, 255, 256, 0, 152, 257, 449, 131, 256, 126, 256, 0, 255, 127, 256, 114, 142, 256, 255, 558, 257, 256, 254, 171, 256, 257, 0, 256, 256, 256, 256, 258, 255, 255, 257, 256, 83, 257, 133, 208, 256, 255, 120, 258, 51, 323, 256, 247, 234, 256, 255, 504, 253, 64, 257, 186, 384, 256, 256, 182, 256, 256, 256, 630, 228, 256, 256, 165, 257, 255, 211, 251, 257, 256, 256, 256, 256, 140, 256, 256, 257, 256, 257, 257, 391, 256, 256, 191, 224, 217, 257, 258, 256, 255, 256, 240, 256, 182, 258, 257, 252, 256, 257, 252, 257, 257, 256, 257, 257, 257, 256, 256, 192, 256, 257, 256, 257, 187, 257, 257, 256, 253, 205, 238, 225, 253, 255, 249, 257]
theorem node93967 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 18 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93967 support demand code
    entries93967 ((insert 34 (insert 18 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 31 (insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries93968 : List (Fin 2295 × ℕ) := [(4, 62), (177, 43), (444, 6), (468, 13), (491, 46), (527, 23), (542, 25), (587, 3), (588, 40), (620, 5), (629, 11), (639, 10), (690, 10), (736, 18), (741, 17), (843, 7), (845, 16), (852, 21), (856, 37), (870, 19), (873, 20), (886, 42), (888, 20), (890, 27), (892, 11), (904, 15), (920, 6), (923, 13), (928, 9), (931, 23), (941, 7), (942, 28), (943, 11), (945, 26), (955, 4), (959, 3), (960, 29), (964, 17), (966, 6), (968, 20), (972, 15), (973, 55), (981, 2), (984, 17), (985, 22), (1006, 1), (1009, 22), (1033, 5), (1045, 9), (1072, 7), (1073, 21), (1075, 2), (1076, 4), (1089, 2), (1108, 12), (1139, 4), (1145, 6), (1155, 14), (1174, 18), (1175, 18), (1179, 7), (1182, 9), (1183, 5), (1184, 1), (1186, 18), (1212, 9), (1316, 1), (1322, 3), (1400, 11), (1528, 10), (1534, 2), (1541, 3), (1584, 5), (1590, 1), (1848, 3), (1851, 16), (1852, 15)]
def cs93968 : List ℕ := [0, 91, 0, 0, 83, 37, 46, 50, 62, 0, 0, 78, 100, 20, 87, 1, 55, 97, 20, 20, 100, 38, 86, 100, 18, 196, 77, 101, 0, 55, 100, 6, 56, 99, 51, 75, 1, 101, 52, 52, 23, 47, 101, 100, 143, 100, 100, 101, 69, 100, 100, 0, 87, 101, 100, 100, 101, 100, 101, 99, 101, 37, 96, 49, 97, 100, 100, 18, 100, 37, 148, 92, 86, 99, 101, 100, 185, 100, 69, 99, 55, 150, 98, 99, 56, 100, 101, 100, 257, 99, 99, 101, 57, 98, 100, 101, 84, 101, 100, 100, 99, 101, 76, 99, 101, 100, 93, 79, 85, 144, 100, 101, 98, 75, 81, 99, 98, 99, 101, 119, 98, 100, 77, 99, 100, 78, 101, 101, 101, 99, 99, 91, 100, 101, 100, 99, 101, 73, 99, 101, 99, 100, 88, 100, 101, 101, 100, 99, 100, 100, 101, 100, 100, 101]
theorem node93968 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 34 (insert 18 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs93968 support demand code
    entries93968 ((insert 31 (insert 34 (insert 18 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node93966 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 18 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 18 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    31 node93967 node93968
theorem node93964 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    34 node93965 node93966
theorem node93962 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    18 node93963 node93964
theorem node93960 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 92 (insert 36 (insert 67 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    51 node93961 node93962
theorem node93958 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 36 (insert 67 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 81 (insert 70 (insert 88 (insert 109 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    69 node93959 node93960
#print axioms node93958
end OmissionResidualCover31Fused
