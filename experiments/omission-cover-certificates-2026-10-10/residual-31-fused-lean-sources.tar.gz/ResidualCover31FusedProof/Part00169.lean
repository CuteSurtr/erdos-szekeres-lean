import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries86835 : List (Fin 2295 × ℕ) := [(375, 1)]
def cs86835 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node86835 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 105 (insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86835 support demand code
    entries86835 ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)) ((insert 105 (insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries86837 : List (Fin 2295 × ℕ) := [(947, 1)]
def cs86837 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node86837 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86837 support demand code
    entries86837 ((insert 105 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 66 (insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries86841 : List (Fin 2295 × ℕ) := [(23, 43), (177, 86), (340, 1), (491, 38), (497, 19), (498, 58), (514, 77), (572, 128), (588, 20), (741, 55), (781, 73), (782, 92), (798, 11), (812, 4), (851, 37), (852, 35), (870, 77), (873, 33), (874, 18), (892, 110), (894, 35), (897, 27), (899, 25), (901, 13), (915, 69), (917, 17), (926, 37), (931, 93), (942, 38), (943, 36), (944, 13), (945, 49), (946, 20), (948, 99), (960, 116), (963, 67), (965, 29), (967, 18), (968, 67), (972, 27), (973, 133), (978, 63), (994, 47), (1006, 47), (1011, 15), (1013, 19), (1025, 15), (1033, 39), (1034, 7), (1043, 32), (1072, 17), (1073, 24), (1082, 6), (1095, 6), (1128, 10), (1139, 26), (1143, 3), (1155, 65), (1166, 9), (1167, 4), (1171, 24), (1174, 7), (1175, 27), (1178, 4), (1184, 34), (1185, 8), (1186, 50), (1219, 103), (1223, 17), (1234, 12), (1240, 46), (1247, 8), (1279, 20), (1375, 3), (1405, 26), (1417, 39), (1471, 58), (1489, 46), (1501, 48), (1545, 4), (1651, 38), (2169, 19), (2177, 34)]
def cs86841 : List ℕ := [17, 123, 0, 103, 132, 58, 38, 255, 94, 38, 77, 255, 255, 51, 0, 0, 255, 256, 255, 128, 255, 203, 181, 255, 58, 24, 255, 522, 0, 132, 255, 255, 143, 254, 137, 256, 37, 256, 190, 478, 221, 219, 233, 194, 675, 256, 255, 256, 167, 254, 255, 576, 166, 256, 255, 255, 257, 255, 255, 256, 631, 256, 256, 201, 151, 189, 212, 255, 256, 255, 591, 255, 256, 256, 255, 256, 464, 188, 585, 256, 255, 598, 257, 256, 226, 165, 185, 256, 780, 256, 255, 257, 466, 537, 257, 256, 255, 200, 255, 255, 256, 256, 256, 257, 195, 165, 256, 254, 256, 452, 256, 255, 255, 256, 128, 255, 256, 256, 255, 257, 256, 255, 221, 255, 240, 255, 243, 256, 256, 254, 255, 190, 256, 256, 256, 254, 238, 180, 256, 256, 256, 230, 182, 255, 249, 227, 215, 195, 245, 235, 240, 256, 256, 256]
theorem node86841 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 105 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 92 (insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86841 support demand code
    entries86841 ((insert 66 (insert 105 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 92 (insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries86842 : List (Fin 2295 × ℕ) := [(43, 3), (86, 5), (177, 88), (275, 11), (468, 95), (485, 40), (491, 108), (506, 23), (514, 3), (529, 100), (572, 89), (588, 19), (639, 3), (741, 65), (780, 15), (781, 50), (782, 74), (798, 20), (845, 2), (850, 1), (852, 40), (873, 35), (892, 82), (894, 107), (899, 84), (900, 6), (901, 5), (902, 13), (923, 17), (926, 21), (931, 167), (940, 19), (943, 45), (944, 20), (945, 71), (946, 23), (948, 120), (957, 2), (960, 105), (963, 87), (965, 13), (967, 14), (968, 48), (970, 8), (972, 3), (973, 133), (978, 65), (1009, 57), (1011, 28), (1013, 16), (1033, 30), (1043, 50), (1070, 1), (1072, 19), (1073, 44), (1082, 17), (1096, 4), (1128, 15), (1139, 11), (1141, 1), (1155, 58), (1166, 24), (1167, 34), (1173, 33), (1175, 16), (1178, 13), (1184, 40), (1186, 58), (1212, 7), (1234, 29), (1405, 37), (1417, 18), (1487, 8), (1489, 20), (1500, 23), (1501, 55), (1522, 69), (1778, 27), (1851, 7), (2029, 49)]
def cs86842 : List ℕ := [49, 97, 0, 1, 40, 109, 111, 213, 0, 23, 3, 257, 256, 231, 3, 0, 256, 183, 255, 89, 257, 219, 162, 257, 23, 2, 256, 327, 0, 91, 257, 223, 255, 257, 49, 256, 0, 255, 137, 0, 256, 256, 250, 204, 455, 255, 256, 255, 234, 256, 254, 517, 167, 256, 256, 256, 255, 256, 255, 256, 609, 257, 205, 149, 150, 255, 204, 257, 256, 255, 508, 256, 256, 255, 257, 256, 476, 248, 654, 256, 255, 600, 256, 254, 205, 156, 201, 256, 820, 255, 256, 256, 407, 547, 210, 257, 257, 170, 256, 256, 255, 313, 255, 255, 198, 217, 256, 257, 255, 410, 256, 256, 255, 256, 186, 256, 256, 254, 256, 256, 255, 256, 220, 257, 254, 257, 256, 257, 257, 256, 255, 199, 257, 255, 256, 255, 232, 198, 256, 256, 255, 217, 214, 256, 226, 228, 230, 232, 227, 247, 232, 245, 256, 256]
theorem node86842 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 66 (insert 105 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86842 support demand code
    entries86842 ((insert 39 (insert 66 (insert 105 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 92 (insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node86839 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 105 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 66 (insert 105 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 92 (insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    39 node86841 node86842
def entries86840 : List (Fin 2295 × ℕ) := [(177, 84), (275, 57), (491, 139), (498, 6), (514, 53), (571, 53), (631, 3), (640, 4), (681, 66), (741, 40), (780, 39), (782, 128), (798, 2), (846, 25), (851, 13), (852, 76), (870, 53), (873, 72), (892, 73), (894, 50), (899, 82), (902, 12), (917, 20), (923, 10), (926, 34), (928, 31), (931, 117), (941, 67), (943, 3), (945, 39), (946, 81), (956, 7), (963, 100), (964, 55), (965, 9), (967, 37), (968, 124), (971, 26), (972, 10), (973, 120), (978, 82), (1008, 1), (1009, 96), (1013, 19), (1033, 36), (1043, 40), (1045, 27), (1061, 18), (1069, 61), (1071, 10), (1072, 51), (1073, 32), (1082, 19), (1096, 3), (1126, 16), (1128, 10), (1139, 44), (1155, 48), (1166, 8), (1167, 19), (1173, 2), (1174, 14), (1175, 9), (1178, 17), (1182, 66), (1183, 4), (1186, 70), (1253, 25), (1263, 47), (1268, 1), (1273, 14), (1279, 18), (1296, 46), (1485, 7), (1501, 52), (1626, 9), (1651, 93), (1852, 2), (2029, 20), (2257, 1)]
def cs86840 : List ℕ := [45, 44, 1, 1, 114, 157, 139, 178, 124, 93, 53, 256, 256, 119, 0, 0, 256, 208, 256, 54, 256, 179, 145, 256, 158, 0, 257, 554, 0, 96, 215, 255, 255, 256, 50, 229, 38, 256, 190, 256, 218, 256, 256, 134, 503, 254, 255, 255, 204, 257, 256, 397, 231, 256, 256, 256, 255, 255, 256, 256, 525, 111, 257, 246, 112, 193, 50, 256, 255, 256, 350, 255, 256, 256, 256, 255, 398, 257, 542, 256, 217, 470, 255, 255, 237, 222, 217, 256, 690, 256, 255, 256, 0, 561, 220, 255, 256, 227, 257, 256, 256, 326, 256, 256, 239, 229, 256, 229, 255, 621, 256, 256, 256, 256, 256, 256, 255, 256, 257, 256, 257, 256, 216, 256, 239, 237, 256, 256, 256, 256, 255, 181, 255, 257, 255, 256, 256, 183, 256, 256, 256, 204, 209, 256, 256, 181, 225, 225, 216, 216, 234, 216, 256, 256]
theorem node86840 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 66 (insert 105 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86840 support demand code
    entries86840 ((insert 92 (insert 66 (insert 105 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node86838 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 105 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 66 (insert 105 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    92 node86839 node86840
theorem node86836 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 105 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    66 node86837 node86838
theorem node86829 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)) ((insert 70 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    105 node86835 node86836
def entries86831 : List (Fin 2295 × ℕ) := [(86, 11), (177, 34), (340, 25), (490, 45), (491, 17), (497, 60), (514, 71), (588, 30), (617, 54), (631, 20), (681, 11), (738, 74), (798, 24), (845, 11), (846, 24), (852, 95), (870, 57), (892, 95), (894, 65), (897, 19), (899, 53), (901, 9), (923, 7), (926, 43), (928, 98), (931, 87), (941, 25), (943, 25), (944, 18), (946, 12), (947, 19), (956, 29), (959, 35), (960, 73), (963, 93), (964, 15), (965, 30), (967, 33), (968, 92), (972, 27), (973, 130), (978, 63), (1006, 9), (1007, 6), (1009, 36), (1011, 26), (1033, 30), (1043, 2), (1061, 6), (1072, 31), (1073, 8), (1077, 20), (1078, 7), (1126, 1), (1127, 4), (1128, 17), (1143, 7), (1155, 68), (1166, 30), (1167, 24), (1173, 58), (1175, 16), (1177, 45), (1179, 30), (1182, 31), (1183, 6), (1186, 39), (1212, 13), (1234, 53), (1268, 66), (1279, 83), (1316, 6), (1405, 10), (1417, 7), (1501, 45), (1517, 3), (1534, 28), (1651, 76), (1852, 8), (1861, 7), (1877, 29), (2029, 19), (2064, 14)]
def cs86831 : List ℕ := [26, 118, 0, 7, 95, 159, 65, 239, 60, 76, 78, 256, 256, 66, 0, 0, 256, 256, 256, 66, 256, 160, 128, 256, 173, 11, 256, 486, 0, 54, 256, 255, 256, 255, 98, 215, 0, 257, 225, 257, 153, 256, 231, 156, 449, 256, 255, 507, 128, 237, 246, 314, 192, 257, 256, 256, 257, 256, 208, 256, 417, 255, 258, 256, 240, 225, 257, 255, 256, 255, 19, 256, 257, 255, 240, 256, 409, 225, 596, 256, 257, 477, 256, 257, 256, 209, 247, 255, 727, 256, 257, 255, 190, 552, 257, 256, 256, 255, 255, 257, 256, 289, 256, 256, 251, 255, 170, 201, 256, 512, 256, 257, 255, 256, 153, 219, 256, 256, 257, 256, 256, 255, 201, 256, 256, 257, 256, 256, 256, 257, 256, 215, 255, 255, 257, 257, 251, 211, 255, 256, 256, 256, 211, 256, 255, 236, 242, 207, 248, 257, 245, 257, 256, 256]
theorem node86831 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86831 support demand code
    entries86831 ((insert 70 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 47 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries86833 : List (Fin 2295 × ℕ) := [(86, 13), (177, 259), (340, 22), (356, 47), (514, 479), (572, 485), (581, 73), (583, 381), (619, 66), (632, 101), (677, 108), (738, 207), (812, 7), (834, 95), (846, 187), (852, 292), (859, 61), (860, 135), (870, 288), (873, 292), (892, 205), (894, 252), (899, 138), (915, 82), (919, 180), (923, 131), (926, 216), (928, 157), (931, 124), (932, 154), (943, 166), (944, 14), (946, 186), (947, 239), (959, 171), (963, 311), (965, 55), (967, 130), (968, 265), (972, 167), (973, 515), (978, 148), (1006, 17), (1009, 17), (1011, 128), (1033, 80), (1034, 85), (1043, 51), (1047, 70), (1048, 50), (1049, 21), (1061, 46), (1069, 17), (1070, 90), (1073, 137), (1078, 59), (1082, 13), (1111, 22), (1126, 11), (1155, 138), (1161, 7), (1162, 37), (1166, 66), (1167, 218), (1173, 197), (1175, 37), (1177, 133), (1179, 61), (1182, 79), (1183, 112), (1186, 235), (1188, 53), (1219, 27), (1279, 182), (1405, 140), (1417, 72), (1487, 6), (1500, 71), (1858, 58), (1861, 312), (1888, 88), (2061, 37), (2064, 53), (2285, 53)]
def cs86833 : List ℕ := [312, 396, 0, 339, 292, 182, 0, 1000, 284, 0, 791, 875, 805, 292, 0, 0, 1000, 1000, 1000, 573, 1000, 999, 259, 813, 235, 0, 926, 2252, 0, 360, 1000, 999, 659, 1000, 448, 1000, 61, 1000, 416, 999, 851, 587, 681, 486, 2248, 1000, 1492, 157, 616, 999, 1000, 812, 996, 1000, 1000, 1047, 1001, 999, 649, 1000, 1039, 999, 1000, 769, 656, 1000, 1000, 1000, 1000, 998, 239, 999, 999, 999, 1001, 942, 1523, 949, 2025, 1000, 999, 1362, 999, 1000, 613, 1000, 999, 1001, 2605, 1001, 1000, 1002, 999, 1625, 820, 999, 1001, 953, 1030, 1001, 999, 1001, 1000, 999, 866, 1001, 799, 754, 1000, 1844, 1001, 1001, 998, 1000, 850, 916, 1000, 999, 1001, 1000, 999, 999, 773, 1000, 1000, 1001, 1000, 1000, 999, 999, 1001, 903, 999, 1001, 999, 1000, 1000, 980, 1000, 1000, 999, 1000, 983, 998, 999, 999, 916, 1001, 955, 1000, 947, 999, 999, 1000]
theorem node86833 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 70 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86833 support demand code
    entries86833 ((insert 47 (insert 70 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries86834 : List (Fin 2295 × ℕ) := [(23, 36), (86, 23), (177, 16), (484, 14), (514, 93), (571, 18), (572, 116), (630, 22), (632, 16), (738, 83), (798, 30), (846, 8), (852, 19), (862, 16), (870, 42), (873, 43), (874, 1), (887, 2), (888, 23), (894, 53), (899, 23), (922, 33), (923, 83), (926, 45), (928, 17), (931, 86), (932, 36), (943, 40), (944, 1), (945, 14), (946, 62), (947, 20), (956, 4), (959, 41), (962, 15), (963, 91), (964, 59), (965, 1), (966, 12), (968, 71), (972, 45), (973, 133), (978, 25), (1007, 14), (1011, 37), (1033, 23), (1034, 2), (1043, 24), (1045, 5), (1047, 7), (1048, 10), (1061, 36), (1073, 38), (1081, 8), (1082, 23), (1139, 23), (1155, 49), (1166, 24), (1167, 61), (1170, 3), (1173, 52), (1175, 10), (1177, 28), (1179, 22), (1182, 12), (1183, 36), (1186, 38), (1240, 61), (1279, 88), (1355, 5), (1372, 29), (1405, 52), (1406, 22), (1417, 25), (1487, 3), (1517, 14), (1688, 6), (1861, 30), (1901, 7), (2029, 31), (2061, 7), (2064, 28), (2290, 2)]
def cs86834 : List ℕ := [61, 96, 0, 30, 55, 102, 14, 212, 23, 0, 123, 256, 186, 80, 0, 0, 256, 256, 256, 183, 256, 59, 16, 223, 116, 3, 255, 335, 0, 121, 256, 181, 186, 255, 70, 255, 0, 256, 94, 256, 256, 217, 134, 151, 390, 256, 78, 78, 116, 256, 256, 215, 256, 244, 255, 256, 255, 198, 233, 257, 199, 220, 252, 230, 246, 227, 256, 255, 256, 255, 43, 256, 255, 254, 176, 258, 377, 255, 560, 256, 256, 358, 256, 255, 212, 243, 256, 255, 592, 256, 256, 256, 255, 562, 254, 255, 255, 255, 257, 257, 255, 264, 255, 255, 256, 256, 169, 161, 256, 515, 255, 257, 255, 256, 194, 256, 255, 254, 257, 256, 255, 256, 162, 256, 255, 256, 256, 256, 256, 256, 255, 235, 255, 255, 255, 255, 257, 256, 255, 256, 255, 240, 245, 256, 255, 256, 256, 235, 244, 223, 251, 234, 230, 256]
theorem node86834 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 70 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86834 support demand code
    entries86834 ((insert 46 (insert 47 (insert 70 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node86832 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 70 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 70 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    46 node86833 node86834
theorem node86830 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 70 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    47 node86831 node86832
theorem node86817 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)) ((insert 27 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    70 node86829 node86830
def entries86823 : List (Fin 2295 × ℕ) := [(375, 1)]
def cs86823 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node86823 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 105 (insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86823 support demand code
    entries86823 ((insert 27 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 105 (insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries86825 : List (Fin 2295 × ℕ) := [(947, 1)]
def cs86825 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node86825 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 27 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86825 support demand code
    entries86825 ((insert 105 (insert 27 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 66 (insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries86827 : List (Fin 2295 × ℕ) := [(86, 1), (177, 27), (340, 1), (468, 23), (485, 23), (506, 32), (540, 12), (588, 13), (631, 17), (679, 4), (681, 40), (741, 33), (780, 13), (782, 42), (798, 7), (845, 6), (851, 23), (870, 14), (874, 46), (897, 29), (910, 19), (915, 42), (920, 7), (926, 23), (928, 1), (941, 4), (942, 18), (943, 11), (944, 16), (946, 15), (948, 28), (959, 24), (960, 34), (962, 12), (963, 14), (964, 5), (965, 12), (967, 11), (968, 21), (970, 12), (972, 4), (973, 52), (978, 33), (1008, 22), (1009, 15), (1013, 4), (1033, 7), (1034, 8), (1043, 17), (1045, 2), (1069, 6), (1072, 9), (1073, 12), (1082, 10), (1126, 2), (1128, 3), (1139, 16), (1143, 1), (1155, 21), (1166, 1), (1167, 11), (1173, 18), (1178, 7), (1182, 1), (1184, 7), (1186, 26), (1223, 40), (1234, 14), (1240, 11), (1268, 14), (1349, 16), (1417, 13), (1534, 1), (1709, 2), (1766, 8), (2169, 10), (2177, 26)]
def cs86827 : List ℕ := [40, 29, 0, 0, 63, 31, 2, 92, 48, 40, 0, 80, 100, 60, 30, 0, 94, 66, 100, 14, 99, 2, 69, 100, 40, 6, 100, 2, 19, 55, 99, 100, 99, 99, 18, 100, 42, 80, 97, 99, 14, 101, 43, 51, 263, 99, 89, 206, 56, 65, 100, 242, 32, 100, 100, 100, 100, 100, 99, 99, 269, 99, 50, 101, 81, 100, 67, 99, 99, 100, 209, 98, 100, 101, 101, 100, 173, 101, 194, 99, 93, 277, 99, 100, 100, 72, 64, 100, 249, 99, 99, 100, 99, 184, 99, 100, 99, 68, 99, 99, 99, 134, 101, 101, 82, 38, 100, 99, 99, 177, 99, 99, 99, 100, 97, 99, 99, 99, 99, 99, 99, 99, 78, 100, 100, 96, 99, 100, 99, 99, 100, 67, 99, 99, 99, 99, 93, 85, 99, 99, 88, 99, 71, 98, 89, 84, 88, 91, 80, 99, 90, 99, 99, 99]
theorem node86827 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 105 (insert 27 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86827 support demand code
    entries86827 ((insert 66 (insert 105 (insert 27 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries86828 : List (Fin 2295 × ℕ) := [(177, 26), (275, 3), (468, 31), (484, 4), (498, 10), (529, 23), (540, 16), (572, 31), (630, 21), (741, 13), (780, 12), (782, 48), (835, 2), (845, 3), (850, 26), (851, 32), (870, 23), (873, 36), (874, 10), (915, 36), (917, 2), (919, 4), (920, 19), (923, 20), (926, 13), (931, 24), (943, 28), (945, 24), (946, 33), (948, 41), (958, 6), (959, 15), (962, 13), (963, 17), (965, 5), (967, 18), (968, 7), (969, 1), (970, 4), (972, 7), (973, 52), (978, 24), (1008, 9), (1009, 23), (1013, 2), (1033, 5), (1034, 20), (1043, 21), (1045, 10), (1068, 6), (1069, 7), (1073, 31), (1082, 11), (1095, 2), (1096, 1), (1139, 11), (1155, 15), (1159, 1), (1166, 2), (1167, 13), (1173, 12), (1174, 3), (1175, 3), (1182, 2), (1186, 33), (1223, 25), (1349, 17), (1405, 18), (1417, 12), (1451, 9), (1482, 5), (1711, 7), (1857, 7), (2177, 15)]
def cs86828 : List ℕ := [25, 34, 0, 26, 57, 4, 0, 91, 35, 0, 7, 79, 99, 69, 40, 0, 67, 91, 99, 31, 99, 7, 26, 99, 0, 3, 99, 7, 0, 52, 99, 99, 40, 99, 18, 99, 32, 63, 26, 99, 55, 99, 35, 42, 251, 100, 65, 0, 90, 98, 99, 158, 39, 89, 99, 99, 101, 99, 100, 100, 191, 62, 69, 31, 82, 100, 65, 100, 100, 100, 216, 99, 99, 100, 100, 99, 187, 84, 196, 100, 95, 152, 100, 100, 42, 83, 99, 100, 263, 100, 99, 101, 100, 202, 82, 91, 100, 68, 100, 99, 100, 123, 100, 99, 92, 60, 84, 100, 100, 178, 101, 100, 99, 100, 79, 100, 100, 100, 100, 100, 100, 99, 79, 100, 99, 100, 100, 100, 100, 98, 92, 73, 101, 100, 100, 99, 98, 93, 100, 100, 99, 81, 67, 100, 88, 99, 80, 98, 69, 100, 77, 100, 100, 100]
theorem node86828 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 66 (insert 105 (insert 27 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86828 support demand code
    entries86828 ((insert 47 (insert 66 (insert 105 (insert 27 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node86826 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 105 (insert 27 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 66 (insert 105 (insert 27 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    47 node86827 node86828
theorem node86824 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 27 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 105 (insert 27 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    66 node86825 node86826
theorem node86819 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 70 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    105 node86823 node86824
def entries86821 : List (Fin 2295 × ℕ) := [(86, 1), (177, 12), (275, 20), (356, 15), (357, 3), (468, 19), (507, 3), (528, 2), (542, 3), (572, 20), (577, 10), (630, 10), (631, 8), (677, 1), (738, 21), (739, 9), (747, 1), (798, 7), (834, 1), (845, 6), (870, 25), (873, 19), (874, 20), (878, 27), (918, 32), (922, 28), (923, 20), (928, 30), (931, 43), (932, 10), (943, 32), (960, 25), (963, 37), (965, 16), (967, 13), (968, 17), (972, 23), (973, 44), (978, 19), (1006, 2), (1009, 6), (1011, 14), (1033, 8), (1034, 13), (1043, 6), (1045, 2), (1047, 2), (1048, 6), (1073, 22), (1082, 8), (1143, 7), (1155, 28), (1157, 5), (1166, 12), (1167, 15), (1173, 26), (1177, 10), (1178, 5), (1179, 5), (1186, 16), (1188, 5), (1212, 3), (1223, 20), (1240, 20), (1241, 2), (1261, 1), (1297, 1), (1358, 15), (1405, 14), (1417, 14), (1500, 10), (1522, 12), (1618, 17), (1667, 1), (1765, 3), (1807, 25), (1891, 2), (2061, 6), (2064, 14)]
def cs86821 : List ℕ := [35, 25, 0, 3, 45, 37, 0, 85, 48, 48, 0, 97, 100, 78, 30, 0, 91, 92, 101, 20, 100, 0, 12, 100, 62, 6, 101, 0, 0, 50, 99, 100, 100, 100, 26, 100, 0, 79, 62, 99, 100, 101, 32, 85, 178, 100, 100, 100, 62, 99, 99, 103, 42, 99, 99, 100, 99, 101, 100, 205, 77, 100, 78, 76, 97, 97, 99, 100, 99, 101, 0, 99, 99, 101, 98, 100, 170, 99, 214, 100, 100, 201, 100, 99, 100, 99, 101, 97, 279, 99, 99, 100, 99, 261, 99, 95, 100, 80, 104, 99, 101, 102, 99, 100, 96, 100, 70, 76, 99, 199, 100, 99, 100, 99, 54, 100, 99, 100, 99, 101, 99, 100, 87, 99, 98, 99, 100, 100, 99, 99, 99, 74, 100, 99, 100, 98, 99, 87, 99, 99, 99, 99, 65, 99, 99, 100, 89, 78, 79, 96, 79, 99, 82, 94]
theorem node86821 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 27 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86821 support demand code
    entries86821 ((insert 70 (insert 27 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 59 (insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries86822 : List (Fin 2295 × ℕ) := [(43, 1), (86, 27), (177, 98), (275, 21), (356, 42), (468, 10), (484, 36), (542, 105), (572, 83), (588, 9), (631, 49), (632, 21), (798, 19), (834, 37), (845, 17), (869, 40), (870, 65), (873, 46), (874, 82), (878, 23), (915, 52), (917, 48), (919, 38), (926, 10), (928, 57), (931, 39), (932, 8), (943, 51), (945, 24), (947, 55), (959, 11), (960, 82), (963, 55), (964, 13), (965, 34), (967, 13), (968, 27), (972, 31), (973, 124), (978, 31), (1011, 31), (1012, 27), (1033, 12), (1034, 15), (1048, 14), (1061, 15), (1069, 1), (1072, 9), (1073, 10), (1077, 27), (1126, 20), (1128, 2), (1140, 3), (1141, 1), (1143, 9), (1154, 18), (1155, 31), (1166, 18), (1167, 41), (1173, 49), (1175, 46), (1176, 12), (1177, 9), (1179, 46), (1183, 26), (1186, 27), (1212, 41), (1223, 78), (1240, 10), (1253, 23), (1386, 32), (1405, 40), (1487, 9), (1500, 18), (1503, 9), (1522, 91), (1604, 13), (1840, 40), (1857, 9), (2061, 42), (2064, 14)]
def cs86822 : List ℕ := [101, 27, 13, 0, 101, 127, 1, 141, 101, 0, 0, 257, 255, 219, 129, 0, 251, 254, 255, 96, 256, 1, 147, 257, 27, 17, 256, 0, 13, 179, 247, 256, 207, 256, 95, 256, 36, 256, 205, 257, 143, 256, 100, 149, 521, 255, 219, 256, 200, 235, 256, 300, 212, 227, 256, 255, 256, 256, 256, 125, 260, 256, 189, 257, 178, 255, 255, 262, 257, 255, 55, 256, 257, 256, 256, 249, 500, 256, 452, 257, 255, 328, 249, 257, 257, 214, 254, 255, 714, 257, 257, 255, 256, 370, 258, 255, 208, 254, 256, 252, 256, 256, 236, 258, 209, 255, 220, 222, 249, 416, 256, 256, 256, 254, 207, 209, 256, 257, 256, 255, 257, 255, 214, 257, 256, 256, 254, 255, 255, 256, 257, 232, 254, 255, 256, 256, 255, 238, 254, 256, 256, 240, 232, 257, 256, 235, 255, 253, 255, 256, 255, 256, 256, 249]
theorem node86822 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 70 (insert 27 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86822 support demand code
    entries86822 ((insert 59 (insert 70 (insert 27 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node86820 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 27 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 70 (insert 27 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    59 node86821 node86822
theorem node86818 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    70 node86819 node86820
theorem node86799 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)) ((insert 60 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    27 node86817 node86818
def entries86815 : List (Fin 2295 × ℕ) := [(49, 23), (177, 25), (340, 1), (356, 7), (498, 20), (512, 13), (514, 24), (571, 56), (588, 13), (617, 3), (678, 4), (738, 6), (741, 17), (742, 10), (813, 17), (818, 8), (819, 2), (846, 23), (851, 21), (859, 1), (870, 37), (888, 19), (892, 63), (896, 29), (897, 12), (916, 29), (917, 10), (922, 1), (926, 3), (927, 17), (928, 29), (931, 26), (932, 17), (942, 12), (943, 31), (945, 28), (946, 3), (960, 14), (962, 17), (963, 28), (964, 23), (965, 7), (968, 9), (972, 8), (973, 50), (978, 9), (994, 16), (1008, 1), (1011, 26), (1012, 12), (1033, 2), (1043, 12), (1073, 16), (1108, 12), (1154, 16), (1155, 7), (1166, 3), (1171, 14), (1176, 4), (1177, 3), (1178, 7), (1180, 5), (1183, 15), (1186, 16), (1212, 12), (1219, 20), (1223, 2), (1240, 23), (1279, 34), (1405, 12), (1417, 7), (1487, 7), (1500, 12), (1517, 8), (1534, 1), (1607, 5), (1626, 2), (1701, 18), (2061, 20)]
def cs86815 : List ℕ := [2, 77, 0, 20, 23, 34, 8, 100, 46, 0, 37, 101, 100, 0, 0, 0, 93, 100, 100, 75, 101, 99, 52, 76, 34, 14, 100, 244, 0, 55, 101, 99, 39, 100, 43, 100, 22, 100, 100, 203, 99, 83, 71, 62, 244, 99, 101, 100, 75, 99, 100, 110, 55, 99, 100, 99, 99, 100, 100, 99, 3, 100, 100, 88, 99, 98, 100, 99, 100, 249, 95, 92, 99, 100, 64, 99, 201, 59, 210, 99, 101, 270, 99, 99, 78, 71, 99, 69, 285, 99, 100, 99, 100, 212, 99, 100, 99, 98, 100, 99, 99, 99, 99, 99, 85, 99, 98, 90, 99, 198, 94, 100, 100, 99, 64, 82, 98, 100, 99, 100, 100, 100, 61, 99, 86, 100, 99, 99, 100, 100, 100, 57, 99, 100, 99, 100, 83, 69, 100, 101, 100, 87, 77, 100, 101, 88, 95, 90, 99, 96, 97, 100, 101, 100]
theorem node86815 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 39 (insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86815 support demand code
    entries86815 ((insert 60 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 69 (insert 39 (insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries86816 : List (Fin 2295 × ℕ) := [(177, 45), (275, 8), (498, 9), (512, 19), (514, 26), (572, 42), (579, 14), (588, 54), (681, 19), (738, 26), (741, 29), (742, 2), (846, 34), (851, 11), (859, 6), (860, 18), (870, 44), (873, 26), (888, 8), (892, 14), (894, 8), (917, 24), (928, 26), (931, 16), (942, 5), (943, 14), (947, 17), (955, 13), (958, 2), (959, 17), (960, 24), (963, 33), (964, 26), (965, 14), (967, 4), (968, 30), (970, 13), (972, 14), (973, 51), (978, 5), (985, 4), (1007, 3), (1011, 5), (1012, 1), (1033, 13), (1034, 8), (1043, 1), (1045, 3), (1061, 14), (1069, 8), (1072, 2), (1073, 10), (1082, 7), (1154, 7), (1155, 8), (1167, 16), (1171, 7), (1173, 1), (1174, 15), (1177, 16), (1178, 1), (1179, 10), (1183, 19), (1186, 20), (1223, 16), (1263, 6), (1273, 2), (1279, 38), (1296, 1), (1417, 12), (1471, 17), (1517, 1), (1534, 8), (1583, 1), (2061, 25), (2135, 1), (2285, 2)]
def cs86816 : List ℕ := [16, 72, 0, 0, 27, 39, 1, 99, 56, 0, 45, 99, 94, 27, 0, 0, 100, 100, 99, 50, 100, 59, 100, 70, 39, 11, 93, 178, 0, 46, 99, 100, 83, 99, 50, 100, 17, 101, 91, 159, 64, 81, 95, 57, 209, 99, 93, 100, 46, 83, 100, 133, 42, 99, 98, 100, 101, 100, 81, 99, 17, 99, 100, 92, 99, 100, 99, 100, 100, 14, 100, 99, 100, 95, 99, 94, 163, 91, 191, 100, 95, 158, 100, 100, 100, 100, 99, 87, 277, 101, 101, 101, 99, 159, 100, 100, 100, 100, 107, 100, 100, 100, 101, 101, 92, 99, 101, 69, 100, 194, 100, 99, 92, 100, 99, 97, 98, 101, 100, 99, 93, 100, 70, 101, 90, 100, 99, 101, 100, 101, 100, 98, 100, 100, 101, 100, 99, 94, 100, 100, 100, 100, 86, 101, 100, 100, 100, 87, 99, 96, 100, 100, 100, 100]
theorem node86816 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86816 support demand code
    entries86816 ((insert 69 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node86809 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 39 (insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    69 node86815 node86816
def entries86811 : List (Fin 2295 × ℕ) := [(177, 35), (275, 45), (340, 11), (468, 5), (475, 6), (572, 4), (588, 17), (678, 1), (681, 2), (738, 16), (741, 9), (742, 13), (842, 9), (851, 11), (858, 45), (873, 31), (874, 21), (888, 22), (893, 26), (894, 20), (895, 14), (896, 40), (899, 14), (900, 31), (917, 8), (928, 46), (931, 8), (932, 5), (936, 14), (945, 17), (955, 24), (956, 18), (957, 5), (959, 5), (960, 24), (961, 1), (963, 11), (965, 20), (967, 16), (968, 24), (972, 12), (973, 55), (978, 20), (1011, 11), (1012, 2), (1033, 4), (1043, 1), (1061, 8), (1068, 5), (1069, 11), (1070, 1), (1072, 2), (1073, 18), (1113, 13), (1139, 6), (1143, 1), (1154, 11), (1167, 18), (1172, 1), (1173, 19), (1175, 14), (1178, 3), (1179, 3), (1183, 4), (1184, 4), (1185, 5), (1186, 26), (1223, 20), (1240, 3), (1273, 2), (1277, 8), (1372, 10), (1400, 20), (1405, 2), (1534, 14), (1541, 1), (1583, 5), (1852, 8), (1858, 3), (1861, 30), (1877, 5), (2061, 7), (2130, 3)]
def cs86811 : List ℕ := [50, 5, 0, 36, 31, 0, 45, 66, 20, 3, 30, 61, 81, 65, 0, 0, 55, 83, 101, 29, 100, 100, 52, 100, 3, 0, 81, 195, 0, 38, 100, 11, 101, 101, 34, 100, 51, 101, 92, 8, 20, 101, 28, 65, 253, 99, 100, 100, 60, 62, 72, 63, 61, 99, 100, 100, 99, 100, 100, 100, 14, 100, 92, 53, 99, 99, 99, 281, 99, 100, 90, 100, 100, 100, 100, 98, 197, 100, 205, 100, 99, 142, 100, 101, 99, 93, 99, 75, 310, 94, 99, 100, 82, 194, 85, 100, 100, 55, 99, 99, 100, 100, 101, 99, 99, 99, 74, 93, 98, 207, 100, 100, 100, 100, 77, 98, 99, 99, 100, 100, 99, 99, 94, 99, 93, 100, 98, 100, 98, 100, 99, 88, 99, 100, 98, 100, 100, 90, 99, 100, 98, 88, 87, 100, 98, 93, 100, 100, 94, 100, 99, 99, 99, 100]
theorem node86811 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86811 support demand code
    entries86811 ((insert 39 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 67 (insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries86813 : List (Fin 2295 × ℕ) := [(86, 26), (146, 1), (177, 32), (285, 16), (350, 26), (514, 26), (571, 121), (585, 67), (639, 26), (738, 55), (741, 55), (742, 38), (798, 45), (813, 53), (852, 26), (859, 26), (873, 21), (874, 35), (888, 18), (892, 71), (897, 37), (923, 4), (927, 96), (928, 83), (931, 86), (932, 49), (942, 3), (943, 74), (944, 38), (945, 109), (946, 44), (960, 31), (961, 49), (962, 45), (963, 74), (964, 28), (966, 14), (968, 19), (973, 133), (978, 9), (1011, 69), (1033, 45), (1043, 21), (1048, 7), (1069, 9), (1073, 26), (1081, 8), (1082, 24), (1128, 7), (1138, 9), (1139, 15), (1154, 12), (1155, 12), (1157, 13), (1161, 2), (1166, 2), (1167, 39), (1173, 11), (1178, 15), (1179, 5), (1183, 27), (1186, 44), (1212, 40), (1223, 14), (1227, 41), (1253, 26), (1372, 43), (1386, 9), (1405, 19), (1417, 22), (1443, 8), (1451, 4), (1487, 23), (1545, 15), (1548, 10), (1607, 37), (1618, 2), (1861, 156), (2029, 34), (2061, 73), (2285, 8)]
def cs86813 : List ℕ := [230, 0, 0, 156, 66, 0, 0, 256, 66, 2, 182, 256, 256, 99, 0, 0, 256, 111, 257, 139, 256, 216, 69, 256, 2, 0, 257, 398, 0, 69, 256, 205, 162, 256, 11, 257, 52, 256, 252, 0, 256, 256, 138, 200, 340, 184, 256, 257, 187, 242, 256, 199, 256, 161, 256, 256, 257, 257, 256, 256, 4, 257, 208, 161, 257, 255, 257, 93, 257, 666, 159, 257, 257, 255, 226, 256, 545, 249, 504, 256, 256, 696, 257, 256, 54, 223, 256, 241, 686, 218, 257, 256, 256, 646, 191, 256, 250, 245, 255, 257, 256, 256, 256, 256, 134, 256, 256, 256, 256, 491, 256, 256, 256, 256, 195, 224, 257, 256, 256, 256, 255, 255, 147, 256, 257, 256, 255, 256, 255, 256, 256, 185, 256, 256, 256, 256, 194, 216, 256, 256, 220, 209, 239, 256, 200, 203, 256, 256, 256, 256, 242, 256, 256, 256]
theorem node86813 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 39 (insert 60 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86813 support demand code
    entries86813 ((insert 67 (insert 39 (insert 60 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries86814 : List (Fin 2295 × ℕ) := [(86, 9), (177, 42), (275, 1), (507, 14), (514, 9), (572, 35), (579, 30), (583, 6), (588, 40), (620, 9), (681, 17), (738, 12), (741, 15), (798, 1), (860, 5), (870, 9), (873, 36), (888, 15), (890, 1), (892, 4), (897, 10), (928, 26), (931, 38), (943, 21), (947, 7), (955, 9), (959, 12), (960, 22), (963, 38), (964, 12), (965, 1), (966, 4), (967, 11), (968, 26), (970, 14), (971, 1), (972, 16), (973, 50), (978, 15), (1010, 2), (1011, 9), (1033, 13), (1034, 2), (1043, 2), (1047, 1), (1061, 11), (1069, 13), (1072, 11), (1073, 9), (1078, 4), (1082, 12), (1139, 6), (1141, 5), (1154, 6), (1155, 4), (1167, 15), (1173, 15), (1175, 4), (1177, 14), (1178, 2), (1179, 14), (1183, 12), (1186, 20), (1212, 10), (1223, 22), (1273, 5), (1516, 2), (1534, 8), (1541, 7), (1545, 8), (1654, 4), (1778, 9), (1851, 15), (1861, 41), (1987, 7), (2029, 19), (2061, 17), (2249, 9)]
def cs86814 : List ℕ := [91, 0, 0, 41, 31, 0, 0, 100, 40, 14, 50, 100, 100, 45, 0, 0, 91, 76, 100, 50, 100, 54, 92, 100, 14, 0, 100, 113, 0, 42, 100, 73, 96, 91, 19, 99, 0, 100, 92, 9, 82, 100, 70, 84, 117, 92, 99, 100, 42, 50, 80, 97, 60, 88, 99, 99, 100, 100, 100, 99, 7, 99, 72, 85, 59, 99, 99, 44, 100, 13, 72, 99, 100, 100, 97, 87, 167, 97, 169, 99, 100, 149, 101, 99, 87, 98, 99, 99, 253, 96, 100, 100, 99, 171, 100, 87, 86, 64, 99, 100, 99, 99, 100, 100, 99, 98, 94, 79, 100, 186, 99, 99, 100, 98, 99, 99, 100, 101, 99, 99, 99, 99, 83, 100, 101, 99, 99, 100, 98, 100, 101, 87, 100, 100, 99, 100, 98, 82, 100, 101, 99, 92, 91, 101, 101, 93, 99, 95, 99, 100, 100, 100, 100, 101]
theorem node86814 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 67 (insert 39 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86814 support demand code
    entries86814 ((insert 69 (insert 67 (insert 39 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node86812 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 39 (insert 60 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 39 (insert 60 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    69 node86813 node86814
theorem node86810 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    67 node86811 node86812
theorem node86801 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 27 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    39 node86809 node86810
def entries86807 : List (Fin 2295 × ℕ) := [(275, 3), (459, 16), (468, 65), (484, 22), (498, 44), (529, 45), (540, 67), (572, 33), (588, 89), (630, 33), (678, 86), (729, 37), (738, 37), (741, 31), (843, 3), (850, 39), (852, 22), (869, 45), (870, 107), (872, 14), (873, 39), (874, 63), (878, 86), (897, 73), (915, 27), (917, 26), (918, 16), (922, 35), (927, 19), (928, 131), (931, 115), (943, 73), (955, 6), (959, 52), (960, 55), (962, 16), (963, 92), (964, 10), (965, 33), (966, 15), (968, 28), (972, 3), (973, 122), (978, 24), (1011, 35), (1012, 15), (1033, 18), (1034, 38), (1061, 5), (1072, 1), (1073, 40), (1078, 14), (1082, 12), (1111, 2), (1114, 5), (1128, 3), (1143, 11), (1154, 5), (1155, 49), (1166, 7), (1167, 33), (1173, 32), (1174, 27), (1175, 32), (1179, 37), (1183, 1), (1186, 53), (1212, 15), (1234, 21), (1253, 29), (1273, 16), (1405, 50), (1417, 23), (1534, 34), (1692, 8), (1842, 9), (1851, 11), (1891, 22), (2061, 70), (2131, 34)]
def cs86807 : List ℕ := [29, 74, 0, 39, 51, 22, 0, 125, 73, 42, 0, 255, 208, 203, 162, 8, 125, 255, 256, 75, 256, 8, 162, 214, 34, 0, 135, 0, 8, 33, 255, 183, 156, 256, 99, 255, 29, 256, 257, 256, 204, 256, 162, 134, 402, 233, 184, 456, 63, 256, 255, 341, 39, 225, 257, 255, 256, 626, 256, 256, 27, 256, 242, 257, 256, 255, 256, 256, 256, 256, 255, 256, 256, 226, 238, 256, 461, 208, 618, 256, 256, 499, 256, 256, 198, 209, 256, 256, 723, 255, 257, 257, 246, 576, 256, 256, 257, 257, 255, 251, 256, 256, 256, 255, 214, 257, 255, 213, 255, 441, 256, 257, 257, 257, 184, 256, 255, 256, 256, 257, 255, 256, 200, 255, 226, 257, 256, 256, 256, 256, 255, 214, 256, 256, 255, 256, 235, 215, 256, 256, 255, 242, 185, 255, 255, 254, 209, 225, 193, 257, 232, 256, 255, 256]
theorem node86807 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 57 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86807 support demand code
    entries86807 ((insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 47 (insert 57 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries86808 : List (Fin 2295 × ℕ) := [(177, 403), (356, 266), (468, 537), (484, 96), (498, 15), (507, 204), (540, 33), (571, 26), (572, 359), (630, 219), (632, 120), (738, 234), (741, 123), (834, 20), (850, 164), (852, 194), (869, 28), (870, 418), (873, 160), (878, 234), (916, 46), (917, 292), (922, 139), (928, 44), (931, 347), (932, 40), (943, 273), (944, 7), (945, 10), (946, 119), (948, 266), (962, 65), (963, 352), (964, 224), (965, 15), (966, 64), (968, 251), (972, 157), (973, 513), (978, 100), (1007, 3), (1011, 99), (1012, 49), (1033, 63), (1034, 71), (1043, 87), (1047, 21), (1048, 35), (1061, 104), (1073, 98), (1076, 3), (1078, 67), (1082, 9), (1154, 114), (1155, 70), (1166, 45), (1167, 135), (1172, 39), (1173, 109), (1174, 92), (1175, 133), (1176, 31), (1178, 81), (1179, 100), (1183, 154), (1186, 198), (1253, 16), (1273, 65), (1372, 38), (1405, 92), (1406, 18), (1417, 75), (1440, 179), (1503, 6), (1534, 68), (1545, 65), (1943, 171), (2061, 204), (2131, 166), (2289, 12)]
def cs86808 : List ℕ := [16, 537, 0, 164, 210, 267, 0, 747, 202, 370, 179, 999, 999, 535, 446, 0, 999, 890, 999, 581, 999, 179, 403, 780, 370, 0, 999, 179, 0, 742, 999, 822, 637, 999, 373, 999, 16, 949, 447, 923, 938, 999, 459, 484, 1612, 1002, 640, 44, 1000, 929, 1000, 1044, 583, 860, 1000, 1000, 999, 1181, 999, 1000, 266, 924, 970, 655, 1000, 1002, 1002, 999, 1000, 1000, 999, 999, 1000, 1001, 993, 929, 1538, 722, 2010, 1000, 1000, 1242, 1000, 1000, 470, 1001, 1001, 829, 2780, 1000, 1001, 999, 1000, 1734, 671, 873, 1000, 1000, 1001, 1001, 1001, 1000, 1001, 1001, 871, 1001, 847, 685, 956, 1933, 1000, 1000, 1002, 1000, 872, 1001, 1000, 1001, 1000, 1001, 1001, 1001, 685, 1001, 1000, 1000, 1000, 1000, 1000, 1002, 1000, 943, 1000, 998, 1001, 1001, 1000, 964, 1000, 999, 1000, 1001, 911, 1000, 1001, 1000, 908, 885, 962, 943, 910, 1000, 1000, 1000]
theorem node86808 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86808 support demand code
    entries86808 ((insert 47 (insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 57 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node86803 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 57 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    47 node86807 node86808
def entries86805 : List (Fin 2295 × ℕ) := [(86, 31), (177, 123), (468, 111), (484, 79), (571, 39), (588, 50), (589, 15), (617, 13), (631, 98), (738, 37), (741, 61), (742, 16), (798, 2), (818, 26), (845, 31), (852, 71), (870, 78), (873, 56), (874, 107), (888, 26), (900, 1), (916, 57), (917, 107), (922, 13), (928, 90), (931, 77), (942, 12), (943, 48), (947, 64), (955, 5), (959, 54), (960, 72), (962, 35), (963, 83), (964, 59), (965, 8), (966, 11), (967, 21), (968, 29), (970, 23), (972, 32), (973, 125), (978, 15), (1011, 46), (1012, 27), (1033, 22), (1034, 2), (1043, 22), (1048, 16), (1061, 19), (1069, 14), (1073, 37), (1082, 20), (1154, 32), (1167, 36), (1173, 15), (1174, 19), (1175, 13), (1178, 28), (1179, 7), (1182, 2), (1183, 45), (1186, 50), (1212, 30), (1253, 35), (1417, 10), (1500, 37), (1616, 5), (1618, 14), (1851, 10), (1858, 5), (1908, 2), (2061, 80), (2285, 17)]
def cs86805 : List ℕ := [35, 142, 0, 0, 106, 79, 0, 248, 35, 14, 2, 255, 256, 163, 2, 0, 227, 191, 256, 65, 179, 2, 188, 178, 14, 31, 183, 2, 0, 221, 256, 208, 143, 256, 47, 256, 37, 244, 213, 255, 116, 220, 100, 162, 531, 256, 71, 255, 174, 256, 256, 103, 136, 178, 256, 256, 257, 90, 255, 256, 64, 256, 145, 161, 234, 256, 256, 255, 256, 197, 221, 380, 257, 255, 256, 256, 520, 195, 549, 255, 180, 653, 257, 255, 234, 206, 256, 229, 817, 256, 256, 256, 256, 431, 255, 257, 256, 256, 306, 257, 255, 256, 255, 256, 220, 256, 256, 211, 257, 466, 256, 256, 255, 256, 236, 241, 251, 255, 256, 256, 255, 256, 196, 256, 238, 256, 256, 256, 256, 256, 256, 193, 256, 256, 256, 256, 224, 206, 256, 256, 255, 204, 238, 256, 255, 220, 256, 241, 253, 256, 256, 256, 256, 255]
theorem node86805 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86805 support demand code
    entries86805 ((insert 57 (insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 71 (insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries86806 : List (Fin 2295 × ℕ) := [(86, 1), (177, 73), (275, 51), (356, 17), (468, 42), (484, 105), (531, 15), (571, 22), (572, 128), (588, 92), (631, 27), (738, 45), (741, 31), (776, 1), (834, 8), (842, 10), (845, 12), (869, 16), (870, 88), (874, 91), (876, 11), (897, 9), (915, 12), (916, 70), (922, 40), (931, 102), (943, 51), (945, 26), (946, 52), (948, 70), (955, 12), (963, 107), (964, 9), (965, 28), (966, 10), (967, 58), (968, 83), (970, 14), (972, 34), (973, 135), (978, 31), (1011, 25), (1033, 34), (1034, 10), (1048, 14), (1049, 11), (1061, 22), (1072, 2), (1073, 24), (1081, 2), (1126, 1), (1128, 9), (1143, 8), (1154, 34), (1155, 15), (1166, 21), (1167, 34), (1173, 51), (1175, 6), (1176, 7), (1177, 44), (1178, 8), (1179, 39), (1183, 63), (1186, 43), (1247, 8), (1253, 97), (1316, 5), (1399, 3), (1405, 5), (1500, 19), (1545, 5), (1548, 11), (1576, 4), (1618, 8), (1851, 16), (1908, 11), (2061, 35)]
def cs86806 : List ℕ := [97, 54, 0, 0, 97, 105, 0, 151, 97, 8, 11, 244, 256, 106, 22, 0, 255, 203, 219, 150, 173, 11, 174, 140, 8, 12, 255, 11, 4, 100, 255, 138, 256, 221, 57, 256, 112, 244, 73, 226, 256, 199, 154, 133, 433, 256, 15, 139, 199, 256, 256, 275, 67, 178, 256, 255, 256, 11, 255, 257, 82, 247, 210, 158, 255, 256, 255, 255, 256, 255, 198, 27, 256, 256, 126, 255, 343, 256, 535, 255, 255, 389, 256, 256, 237, 254, 177, 255, 656, 255, 256, 257, 229, 526, 256, 255, 255, 228, 254, 254, 300, 256, 257, 256, 206, 256, 256, 184, 256, 516, 256, 256, 214, 257, 210, 255, 255, 256, 255, 257, 226, 254, 193, 254, 256, 255, 257, 255, 255, 255, 255, 226, 256, 257, 255, 256, 257, 216, 256, 257, 255, 255, 235, 255, 256, 256, 256, 221, 256, 256, 256, 244, 256, 256]
theorem node86806 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 57 (insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86806 support demand code
    entries86806 ((insert 71 (insert 57 (insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node86804 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 57 (insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    71 node86805 node86806
theorem node86802 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 60 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    57 node86803 node86804
theorem node86800 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    27 node86801 node86802
theorem node86777 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)) ((insert 81 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    60 node86799 node86800
def entries86797 : List (Fin 2295 × ℕ) := [(23, 118), (43, 4), (340, 186), (491, 196), (497, 26), (498, 106), (514, 259), (572, 399), (583, 141), (781, 68), (783, 85), (798, 9), (843, 30), (846, 24), (851, 82), (852, 448), (870, 259), (891, 238), (915, 219), (916, 112), (917, 145), (919, 221), (921, 93), (923, 151), (926, 179), (927, 180), (932, 239), (941, 61), (943, 60), (945, 226), (946, 258), (948, 210), (963, 371), (964, 23), (965, 80), (966, 26), (968, 202), (972, 293), (973, 450), (978, 199), (1006, 73), (1007, 157), (1011, 29), (1033, 141), (1034, 14), (1045, 24), (1061, 167), (1069, 45), (1072, 42), (1073, 139), (1077, 21), (1078, 188), (1127, 66), (1139, 154), (1140, 32), (1149, 36), (1154, 197), (1166, 6), (1167, 211), (1173, 130), (1174, 101), (1176, 34), (1177, 204), (1178, 67), (1179, 11), (1183, 38), (1186, 37), (1212, 113), (1227, 23), (1234, 117), (1240, 9), (1263, 10), (1279, 247), (1345, 194), (1405, 117), (1417, 127), (1471, 190), (1501, 132), (1517, 218), (1607, 162), (1626, 20), (1651, 300), (1663, 18), (1699, 60), (1901, 37), (2061, 18), (2209, 5), (2244, 80), (2285, 99)]
def cs86797 : List ℕ := [0, 351, 0, 80, 648, 741, 418, 999, 373, 360, 259, 1000, 1000, 291, 4, 0, 1000, 1001, 1000, 459, 1000, 793, 212, 583, 881, 0, 1001, 2462, 0, 255, 804, 2222, 1000, 1000, 315, 1000, 320, 1001, 409, 2457, 708, 1000, 853, 605, 2532, 998, 999, 1001, 661, 999, 1000, 1766, 1001, 1001, 1000, 1000, 1000, 1000, 1000, 999, 1846, 576, 1001, 1001, 494, 917, 1000, 1139, 1001, 1000, 1000, 999, 1000, 1000, 999, 999, 1507, 859, 2027, 1001, 1000, 0, 1000, 999, 973, 999, 998, 1000, 2396, 1001, 1001, 1000, 1001, 1394, 1000, 978, 999, 1000, 1020, 1000, 1000, 1041, 1001, 999, 900, 1000, 656, 666, 1000, 1946, 999, 1000, 999, 1001, 859, 831, 999, 1000, 999, 999, 999, 998, 946, 1000, 738, 936, 1000, 998, 998, 999, 1000, 1000, 998, 1000, 999, 1000, 1000, 929, 1000, 1000, 999, 998, 1000, 999, 1000, 998, 1000, 811, 999, 1000, 893, 998, 935, 638]
theorem node86797 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 60 (insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86797 support demand code
    entries86797 ((insert 81 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 31 (insert 60 (insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries86798 : List (Fin 2295 × ℕ) := [(212, 22), (275, 8), (340, 10), (485, 20), (491, 40), (497, 3), (498, 18), (506, 9), (514, 25), (527, 5), (572, 15), (631, 5), (640, 15), (677, 7), (696, 1), (781, 8), (783, 10), (818, 1), (846, 13), (852, 53), (870, 25), (873, 24), (888, 10), (890, 1), (894, 26), (896, 21), (899, 10), (901, 9), (902, 6), (903, 16), (923, 19), (926, 20), (927, 1), (931, 4), (932, 22), (941, 14), (943, 4), (946, 29), (948, 18), (950, 16), (954, 2), (963, 43), (965, 4), (968, 37), (972, 17), (973, 53), (978, 10), (981, 8), (1006, 15), (1007, 15), (1009, 4), (1012, 10), (1033, 6), (1034, 3), (1045, 4), (1061, 10), (1072, 17), (1073, 1), (1078, 7), (1096, 5), (1113, 2), (1114, 2), (1139, 9), (1140, 5), (1141, 8), (1154, 13), (1155, 1), (1167, 18), (1171, 4), (1173, 6), (1176, 7), (1177, 22), (1179, 9), (1183, 20), (1185, 1), (1186, 21), (1219, 33), (1234, 40), (1273, 4), (1405, 12), (1417, 4), (1545, 5), (1766, 20), (1840, 2), (1861, 1)]
def cs86798 : List ℕ := [1, 46, 0, 34, 53, 40, 40, 100, 41, 29, 26, 99, 100, 24, 0, 0, 99, 99, 100, 25, 99, 48, 2, 100, 75, 4, 101, 160, 0, 5, 99, 0, 99, 100, 68, 101, 0, 100, 43, 117, 42, 69, 81, 67, 214, 99, 101, 100, 69, 92, 99, 171, 85, 99, 100, 99, 100, 100, 100, 100, 202, 63, 99, 99, 25, 98, 100, 100, 99, 100, 99, 100, 100, 99, 100, 100, 123, 66, 198, 99, 94, 4, 100, 100, 98, 99, 99, 101, 235, 100, 100, 100, 101, 168, 83, 87, 100, 100, 99, 101, 100, 100, 99, 95, 85, 100, 78, 94, 84, 206, 100, 101, 99, 99, 80, 82, 99, 98, 101, 100, 99, 100, 88, 100, 83, 100, 100, 100, 99, 100, 99, 100, 100, 100, 100, 98, 92, 88, 99, 100, 98, 100, 99, 100, 99, 94, 98, 92, 100, 101, 96, 100, 100, 100]
theorem node86798 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86798 support demand code
    entries86798 ((insert 31 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 60 (insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node86793 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 60 (insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    31 node86797 node86798
def entries86795 : List (Fin 2295 × ℕ) := [(23, 17), (177, 64), (275, 17), (471, 78), (482, 12), (512, 7), (514, 55), (572, 118), (585, 80), (588, 105), (690, 1), (842, 16), (852, 57), (857, 38), (859, 60), (870, 100), (873, 45), (888, 19), (917, 70), (920, 6), (921, 53), (927, 70), (928, 12), (932, 73), (943, 49), (945, 10), (946, 41), (948, 21), (963, 90), (964, 56), (965, 37), (966, 9), (968, 76), (970, 1), (971, 38), (972, 16), (973, 117), (978, 11), (1007, 36), (1011, 17), (1012, 3), (1022, 6), (1033, 22), (1034, 38), (1043, 19), (1061, 48), (1073, 44), (1078, 16), (1082, 4), (1139, 20), (1141, 19), (1154, 49), (1167, 55), (1173, 17), (1174, 30), (1176, 23), (1177, 25), (1178, 21), (1179, 48), (1183, 32), (1186, 41), (1234, 28), (1263, 62), (1273, 25), (1279, 105), (1471, 57), (1517, 51), (1534, 24), (1852, 7), (1877, 27), (2061, 67)]
def cs86795 : List ℕ := [0, 105, 78, 0, 74, 117, 89, 257, 122, 0, 62, 256, 239, 45, 0, 0, 257, 255, 257, 137, 256, 199, 169, 167, 195, 0, 242, 562, 0, 64, 256, 523, 180, 256, 47, 256, 60, 256, 201, 550, 253, 194, 209, 133, 503, 256, 256, 242, 170, 256, 196, 330, 135, 240, 256, 255, 256, 256, 256, 256, 21, 187, 255, 247, 229, 241, 256, 265, 255, 256, 147, 192, 241, 256, 251, 257, 357, 210, 494, 255, 255, 24, 256, 256, 256, 256, 256, 233, 606, 255, 256, 256, 255, 389, 256, 252, 249, 257, 255, 209, 256, 286, 255, 256, 246, 257, 231, 186, 256, 477, 256, 257, 256, 256, 216, 199, 255, 255, 256, 256, 244, 256, 174, 255, 256, 256, 256, 255, 255, 255, 255, 256, 255, 256, 255, 256, 231, 241, 256, 255, 255, 256, 220, 250, 255, 255, 223, 213, 195, 247, 241, 204, 255, 215]
theorem node86795 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86795 support demand code
    entries86795 ((insert 60 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 31 (insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries86796 : List (Fin 2295 × ℕ) := [(23, 2), (177, 25), (190, 3), (212, 27), (275, 14), (498, 5), (512, 21), (514, 32), (572, 33), (588, 9), (678, 5), (681, 2), (739, 15), (818, 7), (834, 1), (846, 37), (852, 16), (859, 11), (860, 6), (870, 38), (873, 25), (892, 4), (893, 9), (894, 29), (896, 20), (902, 5), (927, 20), (932, 28), (943, 15), (945, 3), (946, 24), (955, 11), (960, 1), (963, 38), (964, 5), (965, 15), (967, 18), (968, 29), (971, 15), (972, 11), (973, 51), (978, 6), (1006, 6), (1007, 12), (1011, 5), (1012, 4), (1033, 11), (1034, 11), (1061, 11), (1072, 5), (1073, 7), (1082, 11), (1111, 1), (1122, 1), (1139, 11), (1140, 3), (1141, 3), (1154, 10), (1155, 4), (1166, 2), (1167, 18), (1173, 13), (1176, 10), (1177, 21), (1178, 5), (1179, 16), (1183, 12), (1186, 23), (1223, 25), (1234, 24), (1273, 10), (1545, 1), (1858, 3), (1861, 21), (1891, 5), (1997, 16), (2003, 15), (2061, 12)]
def cs86796 : List ℕ := [46, 37, 0, 37, 43, 0, 0, 101, 62, 16, 74, 100, 99, 25, 0, 0, 99, 101, 101, 48, 99, 62, 34, 74, 43, 0, 100, 175, 0, 41, 92, 0, 81, 100, 50, 100, 20, 99, 91, 107, 66, 92, 56, 44, 229, 100, 100, 100, 76, 86, 99, 98, 60, 102, 99, 101, 101, 100, 101, 100, 0, 91, 100, 89, 70, 87, 100, 102, 101, 100, 25, 72, 101, 101, 101, 100, 139, 60, 185, 101, 101, 8, 100, 102, 101, 101, 100, 101, 246, 101, 100, 99, 100, 178, 91, 86, 101, 100, 101, 102, 101, 101, 101, 100, 97, 101, 76, 78, 99, 210, 95, 100, 92, 100, 63, 79, 101, 101, 101, 99, 93, 90, 93, 101, 95, 100, 100, 100, 101, 101, 101, 100, 100, 100, 101, 100, 100, 90, 100, 100, 101, 100, 81, 100, 100, 100, 100, 93, 90, 100, 90, 100, 100, 100]
theorem node86796 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 60 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86796 support demand code
    entries86796 ((insert 31 (insert 60 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node86794 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    31 node86795 node86796
theorem node86785 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 27 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    60 node86793 node86794
def entries86791 : List (Fin 2295 × ℕ) := [(43, 8), (177, 11), (275, 12), (468, 7), (538, 18), (540, 15), (542, 1), (572, 41), (587, 4), (588, 9), (643, 19), (781, 13), (783, 11), (798, 15), (850, 24), (851, 1), (869, 9), (870, 23), (871, 8), (873, 21), (876, 14), (897, 7), (909, 7), (912, 3), (915, 4), (917, 32), (919, 9), (920, 13), (921, 9), (923, 1), (927, 12), (932, 24), (941, 14), (943, 29), (944, 10), (945, 7), (946, 20), (948, 12), (963, 45), (965, 3), (967, 11), (968, 41), (970, 1), (971, 16), (972, 18), (973, 52), (978, 16), (1007, 4), (1011, 1), (1025, 3), (1033, 12), (1043, 1), (1045, 1), (1061, 15), (1072, 12), (1073, 2), (1077, 3), (1078, 10), (1114, 1), (1127, 11), (1128, 4), (1138, 1), (1139, 14), (1141, 14), (1154, 20), (1167, 20), (1173, 17), (1175, 8), (1177, 19), (1178, 3), (1179, 16), (1183, 17), (1186, 11), (1223, 41), (1234, 32), (1273, 3), (1349, 15), (1442, 7), (1522, 15), (1543, 1), (1765, 14), (2061, 9), (2134, 4)]
def cs86791 : List ℕ := [41, 7, 0, 38, 42, 15, 8, 49, 55, 14, 0, 94, 101, 62, 60, 0, 63, 100, 100, 41, 100, 8, 31, 100, 18, 0, 100, 0, 7, 22, 95, 101, 55, 100, 25, 100, 8, 76, 55, 129, 65, 100, 52, 52, 224, 102, 100, 101, 70, 102, 100, 163, 1, 82, 101, 187, 100, 99, 100, 100, 101, 85, 86, 81, 44, 101, 101, 100, 100, 99, 100, 100, 100, 100, 100, 101, 145, 100, 169, 99, 100, 0, 99, 149, 90, 100, 101, 100, 237, 100, 99, 100, 101, 170, 99, 100, 99, 101, 100, 92, 100, 101, 100, 100, 81, 100, 76, 87, 92, 219, 99, 99, 100, 101, 85, 73, 100, 99, 99, 101, 99, 100, 100, 99, 91, 99, 100, 100, 100, 100, 99, 100, 99, 99, 100, 98, 100, 95, 98, 99, 99, 100, 99, 99, 99, 100, 97, 83, 100, 99, 99, 93, 99, 83]
theorem node86791 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 83 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86791 support demand code
    entries86791 ((insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 55 (insert 83 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries86792 : List (Fin 2295 × ℕ) := [(177, 82), (275, 5), (441, 3), (468, 31), (484, 97), (506, 63), (507, 2), (542, 3), (572, 104), (576, 10), (630, 15), (781, 17), (845, 4), (850, 5), (851, 30), (869, 23), (870, 69), (873, 30), (897, 53), (909, 8), (917, 139), (921, 57), (926, 27), (927, 63), (932, 21), (943, 73), (944, 4), (945, 37), (946, 83), (948, 101), (963, 123), (964, 13), (967, 31), (968, 63), (971, 3), (972, 88), (973, 119), (978, 57), (1007, 27), (1011, 14), (1012, 44), (1044, 20), (1071, 18), (1072, 18), (1073, 49), (1078, 36), (1127, 10), (1138, 32), (1139, 16), (1140, 4), (1141, 9), (1143, 26), (1149, 8), (1154, 50), (1155, 3), (1167, 53), (1171, 40), (1173, 26), (1175, 38), (1179, 7), (1183, 12), (1186, 40), (1212, 14), (1223, 93), (1234, 32), (1240, 18), (1241, 22), (1278, 21), (1316, 7), (1346, 12), (1349, 28), (1405, 3), (1417, 19), (1442, 34), (1497, 7), (1502, 19), (1545, 22), (1580, 33), (1807, 27), (1852, 10), (2064, 8)]
def cs86792 : List ℕ := [93, 35, 0, 5, 183, 124, 0, 218, 120, 92, 0, 224, 257, 90, 98, 0, 248, 219, 257, 104, 257, 0, 135, 257, 100, 44, 256, 0, 8, 115, 256, 256, 221, 256, 64, 257, 38, 215, 195, 351, 185, 257, 77, 226, 493, 256, 257, 256, 234, 255, 256, 445, 58, 256, 256, 114, 255, 257, 255, 257, 255, 143, 199, 189, 168, 257, 256, 285, 254, 256, 256, 255, 255, 257, 257, 256, 299, 208, 479, 255, 256, 0, 256, 458, 156, 222, 256, 255, 747, 255, 256, 256, 255, 391, 255, 248, 257, 256, 256, 213, 256, 256, 257, 256, 234, 256, 169, 190, 236, 519, 256, 256, 256, 256, 175, 230, 256, 256, 256, 256, 257, 255, 237, 256, 215, 253, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 249, 198, 255, 256, 257, 256, 256, 256, 256, 232, 255, 226, 256, 256, 209, 256, 256, 210]
theorem node86792 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86792 support demand code
    entries86792 ((insert 55 (insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 83 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node86787 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 83 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    55 node86791 node86792
def entries86789 : List (Fin 2295 × ℕ) := [(177, 92), (269, 2), (340, 70), (357, 8), (449, 15), (484, 5), (506, 94), (529, 16), (542, 14), (569, 10), (572, 11), (630, 60), (631, 23), (643, 20), (677, 23), (783, 52), (798, 39), (842, 13), (869, 34), (870, 29), (872, 4), (873, 69), (878, 49), (888, 23), (915, 78), (916, 52), (919, 77), (921, 3), (926, 71), (927, 9), (932, 12), (941, 58), (945, 43), (946, 88), (948, 76), (958, 1), (962, 36), (963, 60), (964, 16), (965, 2), (966, 21), (968, 19), (972, 48), (973, 124), (978, 88), (1007, 26), (1009, 3), (1033, 9), (1034, 23), (1045, 13), (1049, 2), (1061, 13), (1068, 5), (1070, 63), (1073, 36), (1077, 64), (1078, 25), (1126, 1), (1127, 8), (1138, 2), (1139, 18), (1140, 4), (1143, 1), (1149, 6), (1154, 7), (1155, 32), (1162, 1), (1167, 14), (1172, 5), (1174, 25), (1176, 15), (1177, 57), (1179, 20), (1183, 26), (1186, 55), (1212, 19), (1223, 192), (1316, 30), (1489, 46), (1497, 17), (1522, 9), (1766, 49), (1877, 26), (2285, 13)]
def cs86789 : List ℕ := [192, 0, 0, 0, 192, 63, 0, 192, 241, 143, 0, 255, 255, 98, 63, 0, 255, 165, 256, 34, 255, 0, 92, 255, 143, 0, 255, 0, 0, 175, 255, 255, 230, 255, 30, 256, 0, 169, 173, 293, 23, 222, 70, 119, 568, 257, 255, 256, 257, 190, 255, 329, 168, 171, 257, 257, 256, 257, 257, 256, 610, 49, 103, 255, 73, 257, 257, 254, 257, 257, 256, 257, 254, 256, 256, 255, 481, 256, 541, 256, 245, 36, 254, 35, 256, 228, 257, 256, 557, 257, 255, 257, 256, 203, 256, 222, 255, 155, 255, 256, 257, 255, 255, 255, 256, 257, 134, 122, 257, 530, 256, 255, 256, 257, 215, 226, 258, 254, 255, 257, 255, 255, 249, 256, 257, 169, 256, 256, 255, 255, 256, 257, 255, 256, 256, 255, 227, 246, 254, 257, 255, 256, 213, 256, 255, 238, 227, 218, 228, 257, 208, 256, 256, 256]
theorem node86789 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 83 (insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86789 support demand code
    entries86789 ((insert 83 (insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries86790 : List (Fin 2295 × ℕ) := [(177, 98), (275, 16), (340, 38), (484, 119), (540, 93), (572, 159), (588, 102), (643, 9), (678, 38), (739, 5), (818, 11), (842, 28), (850, 9), (852, 21), (869, 28), (870, 100), (873, 64), (915, 20), (916, 68), (917, 67), (921, 36), (927, 97), (928, 7), (932, 80), (945, 15), (946, 36), (948, 2), (962, 4), (963, 51), (964, 46), (965, 27), (966, 41), (968, 62), (972, 71), (973, 125), (978, 24), (1007, 7), (1011, 9), (1033, 44), (1034, 23), (1061, 30), (1072, 18), (1073, 8), (1078, 1), (1082, 24), (1125, 1), (1126, 19), (1131, 3), (1138, 12), (1139, 13), (1155, 24), (1166, 2), (1167, 47), (1173, 26), (1174, 21), (1176, 2), (1177, 62), (1179, 61), (1183, 25), (1186, 42), (1212, 10), (1223, 76), (1233, 14), (1252, 9), (1253, 33), (1316, 9), (1399, 12), (1440, 9), (1479, 13), (1780, 2), (1855, 37), (1857, 2), (1891, 7), (2029, 19), (2061, 58), (2285, 7)]
def cs86790 : List ℕ := [128, 0, 0, 9, 130, 119, 0, 149, 109, 0, 9, 256, 256, 64, 102, 0, 256, 229, 192, 159, 230, 9, 200, 230, 0, 0, 256, 9, 0, 98, 256, 228, 237, 256, 47, 256, 33, 239, 253, 328, 246, 256, 149, 150, 497, 257, 199, 257, 188, 257, 256, 330, 66, 185, 257, 256, 256, 257, 256, 257, 22, 179, 137, 254, 159, 216, 257, 257, 255, 238, 172, 180, 209, 256, 256, 227, 339, 193, 524, 256, 256, 4, 257, 172, 256, 256, 256, 256, 627, 255, 257, 255, 257, 306, 256, 219, 251, 257, 256, 257, 258, 263, 257, 256, 205, 257, 247, 229, 257, 417, 256, 257, 256, 258, 161, 249, 256, 256, 257, 257, 256, 258, 206, 257, 256, 256, 249, 256, 256, 257, 257, 257, 257, 257, 256, 257, 243, 233, 257, 257, 256, 253, 246, 256, 257, 256, 258, 257, 257, 257, 257, 239, 256, 240]
theorem node86790 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 83 (insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86790 support demand code
    entries86790 ((insert 60 (insert 83 (insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node86788 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 83 (insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 83 (insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    60 node86789 node86790
theorem node86786 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    83 node86787 node86788
theorem node86779 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 39 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    27 node86785 node86786
def entries86783 : List (Fin 2295 × ℕ) := [(86, 447), (146, 1121), (275, 430), (340, 1104), (351, 350), (479, 703), (491, 1690), (506, 940), (528, 1032), (572, 1468), (640, 197), (696, 560), (781, 1709), (783, 1124), (798, 1613), (852, 505), (873, 2854), (884, 1313), (888, 292), (894, 1925), (896, 2276), (899, 214), (901, 1603), (923, 1991), (926, 2102), (932, 1562), (941, 1369), (943, 400), (945, 294), (946, 2825), (948, 2589), (950, 822), (963, 4835), (967, 102), (968, 3622), (971, 884), (972, 1974), (973, 5150), (978, 3252), (1006, 218), (1007, 778), (1009, 1233), (1033, 1072), (1061, 526), (1072, 1726), (1078, 1329), (1127, 1227), (1128, 558), (1138, 279), (1139, 1025), (1141, 1168), (1154, 618), (1155, 1130), (1162, 524), (1166, 418), (1167, 822), (1172, 764), (1173, 746), (1174, 298), (1176, 28), (1177, 2798), (1179, 1528), (1183, 1545), (1186, 1824), (1212, 228), (1223, 5273), (1227, 154), (1234, 3086), (1316, 128), (1405, 566), (1489, 433), (1497, 34), (1501, 941), (1516, 107), (1522, 3414), (1580, 447), (1607, 1365), (1628, 112), (1644, 1313), (1709, 1165), (1773, 1103), (1775, 532), (1882, 183)]
def cs86783 : List ℕ := [5273, 0, 0, 183, 8241, 3414, 5915, 8241, 6769, 940, 0, 10000, 10000, 9243, 4560, 0, 10000, 7878, 10000, 1760, 10000, 9833, 941, 10000, 940, 1313, 10000, 10000, 0, 3183, 8600, 8875, 10001, 10000, 1808, 10001, 0, 10000, 3673, 0, 6053, 10000, 8360, 6174, 19407, 10001, 15238, 10000, 6205, 5252, 10000, 17493, 8985, 10001, 10000, 10000, 10001, 10000, 10000, 10000, 21779, 4984, 7928, 9612, 3388, 10001, 10000, 10000, 10000, 10000, 9999, 10000, 10000, 9999, 10000, 10000, 12643, 9955, 19802, 10000, 8398, 0, 10001, 10000, 9546, 8278, 10000, 10000, 22430, 10001, 10000, 10000, 9999, 17619, 9999, 8105, 10000, 10001, 10000, 9993, 9999, 11653, 9998, 10000, 7416, 10001, 7576, 7958, 8945, 21628, 10001, 10000, 9998, 9999, 7292, 8071, 9999, 10000, 10000, 10000, 9999, 10000, 9999, 10001, 9133, 9074, 10001, 10000, 10000, 9999, 10001, 10001, 9996, 10000, 10000, 9498, 9020, 8788, 10000, 10000, 10000, 10000, 9838, 10000, 10000, 10000, 9222, 8788, 10000, 10000, 10000, 10000, 10000, 9877]
theorem node86783 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86783 support demand code
    entries86783 ((insert 39 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 46 (insert 60 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries86784 : List (Fin 2295 × ℕ) := [(86, 9), (146, 3), (177, 6), (275, 5), (302, 1), (340, 16), (468, 16), (491, 58), (514, 3), (527, 15), (529, 35), (538, 5), (572, 29), (639, 1), (640, 7), (731, 7), (739, 13), (798, 15), (858, 6), (873, 25), (888, 4), (899, 28), (900, 24), (901, 6), (923, 29), (926, 16), (927, 27), (932, 39), (941, 22), (943, 1), (944, 5), (945, 11), (946, 26), (948, 1), (950, 15), (963, 46), (967, 6), (968, 28), (971, 3), (972, 20), (973, 46), (978, 18), (1006, 8), (1007, 11), (1011, 8), (1012, 5), (1033, 10), (1034, 3), (1047, 1), (1049, 7), (1061, 10), (1072, 8), (1073, 7), (1078, 12), (1128, 5), (1138, 2), (1139, 16), (1141, 6), (1143, 2), (1155, 18), (1162, 5), (1166, 5), (1167, 20), (1173, 23), (1175, 19), (1177, 12), (1179, 11), (1183, 6), (1186, 6), (1212, 15), (1223, 13), (1234, 24), (1273, 7), (1405, 9), (1497, 3), (1498, 13), (1501, 7), (1522, 26), (1651, 4), (1773, 10), (2029, 4), (2281, 4)]
def cs86784 : List ℕ := [17, 16, 0, 0, 13, 43, 74, 33, 13, 4, 3, 100, 91, 91, 10, 13, 79, 75, 95, 33, 100, 10, 13, 100, 17, 0, 101, 84, 0, 16, 99, 78, 100, 100, 42, 101, 13, 100, 57, 4, 82, 101, 100, 84, 121, 99, 13, 101, 74, 100, 100, 152, 100, 99, 99, 100, 99, 101, 100, 98, 167, 65, 98, 90, 74, 100, 101, 99, 100, 100, 99, 99, 100, 100, 86, 98, 128, 87, 226, 100, 101, 0, 98, 99, 98, 100, 100, 99, 230, 99, 100, 100, 101, 159, 100, 86, 98, 99, 99, 101, 99, 100, 100, 100, 91, 99, 58, 87, 96, 215, 100, 100, 99, 100, 68, 87, 101, 99, 101, 100, 100, 99, 101, 99, 100, 100, 101, 100, 99, 100, 99, 100, 100, 100, 100, 86, 100, 83, 100, 100, 99, 100, 99, 102, 99, 100, 90, 87, 100, 101, 99, 100, 83, 98]
theorem node86784 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 39 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86784 support demand code
    entries86784 ((insert 46 (insert 39 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node86781 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 60 (insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    46 node86783 node86784
def entries86782 : List (Fin 2295 × ℕ) := [(177, 17), (275, 25), (507, 14), (514, 1), (524, 8), (572, 45), (585, 3), (588, 6), (681, 13), (729, 3), (739, 19), (798, 12), (845, 1), (850, 5), (852, 12), (873, 26), (888, 4), (894, 1), (897, 10), (900, 8), (927, 32), (932, 21), (943, 4), (944, 2), (945, 6), (946, 25), (955, 2), (959, 2), (962, 3), (963, 40), (964, 9), (965, 2), (967, 20), (968, 30), (971, 15), (972, 23), (973, 48), (978, 16), (1006, 1), (1007, 11), (1011, 7), (1012, 2), (1033, 11), (1034, 9), (1047, 2), (1061, 7), (1072, 10), (1073, 9), (1082, 12), (1139, 11), (1141, 6), (1143, 1), (1154, 15), (1161, 2), (1162, 6), (1166, 11), (1167, 24), (1172, 3), (1173, 24), (1177, 25), (1179, 8), (1183, 16), (1186, 22), (1223, 36), (1227, 22), (1263, 2), (1273, 4), (1417, 1), (1440, 9), (1545, 1), (1607, 8), (1711, 6), (1775, 32), (1861, 44), (1877, 3), (1997, 8), (2040, 3), (2063, 2)]
def cs86782 : List ℕ := [80, 4, 0, 60, 48, 0, 35, 96, 38, 25, 60, 99, 99, 26, 47, 0, 96, 100, 100, 49, 100, 83, 33, 99, 25, 1, 100, 99, 0, 68, 100, 44, 100, 101, 27, 99, 0, 100, 87, 0, 70, 99, 60, 56, 154, 100, 99, 100, 51, 42, 68, 127, 95, 89, 100, 100, 101, 99, 101, 100, 0, 100, 77, 89, 70, 99, 99, 101, 100, 99, 27, 56, 92, 100, 100, 99, 122, 99, 176, 100, 99, 5, 101, 101, 100, 90, 99, 101, 209, 100, 100, 100, 96, 170, 100, 82, 95, 89, 100, 100, 100, 110, 101, 100, 83, 100, 72, 74, 100, 238, 100, 100, 98, 100, 65, 81, 100, 100, 100, 99, 100, 96, 99, 100, 100, 100, 100, 99, 95, 100, 100, 100, 100, 100, 99, 100, 99, 94, 100, 100, 99, 99, 91, 100, 100, 99, 100, 97, 92, 100, 90, 99, 100, 90]
theorem node86782 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 39 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86782 support demand code
    entries86782 ((insert 60 (insert 39 (insert 81 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node86780 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 81 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    60 node86781 node86782
theorem node86778 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    39 node86779 node86780
theorem node86757 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)) ((insert 51 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    81 node86777 node86778
def entries86775 : List (Fin 2295 × ℕ) := [(177, 73), (471, 6), (514, 85), (542, 7), (581, 48), (583, 3), (617, 66), (631, 89), (738, 11), (740, 47), (741, 63), (782, 73), (852, 87), (860, 10), (870, 92), (873, 4), (892, 127), (894, 78), (897, 62), (915, 105), (917, 9), (919, 1), (920, 14), (922, 4), (926, 35), (928, 108), (931, 131), (943, 32), (945, 19), (956, 10), (958, 23), (959, 54), (960, 64), (962, 12), (963, 79), (964, 26), (967, 29), (968, 52), (972, 11), (973, 134), (978, 65), (994, 53), (1006, 29), (1011, 27), (1033, 29), (1043, 46), (1045, 12), (1072, 23), (1073, 49), (1078, 14), (1082, 14), (1126, 21), (1141, 7), (1143, 4), (1154, 32), (1167, 2), (1171, 20), (1173, 5), (1175, 3), (1177, 19), (1178, 21), (1182, 15), (1183, 25), (1185, 22), (1186, 75), (1219, 96), (1247, 15), (1279, 67), (1405, 14), (1500, 46), (1501, 19), (1534, 14), (1545, 13), (1605, 16), (1852, 26), (1901, 59), (2061, 1), (2062, 23)]
def cs86775 : List ℕ := [0, 163, 6, 96, 87, 67, 0, 256, 92, 0, 85, 255, 255, 86, 7, 0, 254, 255, 255, 0, 255, 256, 154, 170, 73, 20, 93, 592, 0, 162, 255, 257, 54, 255, 104, 222, 0, 255, 181, 476, 131, 137, 136, 170, 627, 256, 360, 301, 154, 257, 256, 0, 230, 254, 256, 255, 255, 255, 255, 257, 256, 254, 255, 115, 152, 256, 255, 280, 256, 256, 256, 257, 256, 256, 256, 255, 455, 246, 620, 256, 255, 694, 253, 256, 195, 221, 212, 241, 782, 256, 257, 255, 256, 512, 255, 256, 256, 255, 269, 257, 256, 255, 255, 255, 252, 256, 255, 257, 256, 418, 243, 256, 255, 255, 212, 256, 256, 256, 256, 255, 255, 256, 216, 257, 224, 244, 255, 256, 256, 257, 257, 158, 256, 256, 257, 256, 227, 169, 256, 256, 256, 203, 212, 256, 256, 226, 235, 247, 239, 256, 256, 256, 256, 256]
theorem node86775 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 39 (insert 27 (insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86775 support demand code
    entries86775 ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 46 (insert 39 (insert 27 (insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries86776 : List (Fin 2295 × ℕ) := [(23, 14), (43, 54), (177, 18), (340, 9), (468, 53), (471, 20), (512, 2), (514, 80), (527, 48), (617, 19), (631, 42), (738, 44), (741, 55), (782, 36), (851, 29), (852, 22), (870, 82), (874, 67), (888, 35), (897, 32), (915, 70), (916, 63), (920, 14), (926, 44), (927, 56), (928, 69), (931, 89), (932, 25), (943, 41), (945, 33), (958, 29), (959, 55), (960, 53), (963, 103), (964, 28), (965, 12), (967, 28), (968, 47), (969, 4), (970, 20), (972, 4), (973, 125), (978, 38), (994, 36), (1006, 1), (1009, 1), (1011, 29), (1033, 37), (1034, 27), (1043, 44), (1072, 1), (1073, 55), (1081, 7), (1082, 31), (1114, 5), (1128, 25), (1154, 21), (1155, 26), (1166, 9), (1167, 41), (1171, 10), (1174, 8), (1175, 38), (1179, 17), (1183, 24), (1185, 2), (1186, 79), (1219, 12), (1279, 89), (1405, 28), (1417, 14), (1485, 4), (1500, 55), (1501, 49), (1517, 20), (1659, 14), (1851, 4), (1901, 35), (2061, 41), (2062, 19), (2285, 4), (2292, 31)]
def cs86776 : List ℕ := [0, 154, 20, 12, 65, 89, 74, 239, 54, 0, 82, 256, 256, 121, 54, 0, 256, 256, 256, 35, 256, 54, 99, 154, 109, 10, 116, 291, 0, 145, 256, 256, 115, 256, 58, 240, 29, 256, 143, 438, 114, 149, 179, 224, 442, 257, 22, 298, 151, 257, 256, 0, 191, 256, 256, 256, 257, 239, 256, 257, 218, 208, 256, 156, 256, 255, 255, 256, 257, 256, 255, 256, 258, 258, 242, 256, 431, 255, 591, 256, 256, 472, 257, 257, 236, 244, 204, 256, 735, 255, 257, 256, 256, 539, 257, 255, 255, 257, 255, 251, 258, 291, 257, 257, 255, 256, 256, 255, 257, 448, 255, 256, 257, 256, 210, 256, 257, 257, 255, 256, 256, 255, 215, 256, 224, 255, 257, 256, 256, 256, 256, 212, 257, 256, 256, 257, 225, 197, 256, 256, 256, 182, 192, 256, 256, 249, 200, 245, 203, 256, 237, 256, 256, 256]
theorem node86776 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86776 support demand code
    entries86776 ((insert 46 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 27 (insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node86773 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 39 (insert 27 (insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    46 node86775 node86776
def entries86774 : List (Fin 2295 × ℕ) := [(86, 93), (177, 433), (468, 98), (484, 52), (514, 210), (531, 113), (581, 260), (583, 10), (588, 208), (617, 171), (631, 92), (740, 58), (741, 244), (742, 134), (781, 179), (782, 205), (798, 23), (845, 225), (871, 107), (873, 182), (874, 208), (888, 73), (893, 32), (894, 350), (897, 167), (899, 210), (926, 220), (928, 481), (931, 620), (943, 64), (946, 201), (955, 52), (959, 155), (960, 118), (962, 6), (963, 427), (964, 26), (965, 44), (967, 201), (968, 236), (970, 56), (971, 44), (972, 68), (973, 516), (978, 308), (1006, 43), (1007, 33), (1008, 50), (1009, 233), (1011, 36), (1033, 137), (1043, 146), (1061, 3), (1072, 102), (1073, 174), (1082, 89), (1113, 17), (1128, 120), (1143, 17), (1154, 202), (1159, 3), (1166, 33), (1167, 100), (1172, 23), (1173, 85), (1175, 122), (1178, 67), (1183, 76), (1185, 100), (1186, 279), (1223, 76), (1273, 28), (1500, 18), (1501, 78), (1534, 224), (1545, 101), (1583, 5), (1643, 56), (1654, 159), (1775, 44), (1778, 13), (1779, 132), (1851, 20), (1861, 194), (2029, 27), (2264, 169)]
def cs86774 : List ℕ := [466, 492, 169, 194, 208, 221, 44, 934, 404, 0, 404, 657, 1000, 755, 44, 0, 826, 999, 1001, 73, 999, 1000, 886, 999, 169, 225, 758, 1360, 0, 569, 999, 804, 752, 999, 230, 1001, 201, 1001, 914, 0, 921, 1000, 604, 918, 1938, 1001, 1000, 1165, 708, 999, 1000, 0, 798, 1000, 999, 1001, 999, 1000, 1002, 1000, 999, 950, 514, 507, 732, 1000, 1000, 998, 999, 1001, 999, 1001, 1000, 1000, 1000, 1000, 1795, 999, 2463, 998, 1000, 2584, 1001, 999, 592, 715, 998, 998, 3186, 1000, 1001, 1000, 1000, 2125, 999, 1002, 999, 757, 999, 999, 1000, 1273, 1000, 999, 1001, 999, 998, 1000, 999, 1862, 1000, 1001, 999, 999, 777, 1000, 999, 998, 999, 1000, 999, 1000, 886, 1001, 868, 1000, 925, 1001, 1000, 1002, 999, 761, 1000, 1000, 1001, 999, 869, 711, 998, 1000, 994, 775, 815, 999, 998, 879, 883, 918, 881, 1000, 934, 1001, 1000, 999]
theorem node86774 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86774 support demand code
    entries86774 ((insert 39 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 27 (insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node86771 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 27 (insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    39 node86773 node86774
def entries86772 : List (Fin 2295 × ℕ) := [(177, 241), (468, 5), (484, 214), (531, 85), (542, 252), (617, 202), (631, 259), (738, 45), (740, 80), (741, 244), (742, 8), (782, 300), (845, 149), (870, 238), (871, 115), (873, 68), (874, 434), (897, 367), (900, 13), (915, 437), (916, 266), (919, 9), (920, 50), (926, 139), (927, 175), (928, 451), (931, 347), (942, 40), (943, 85), (944, 49), (959, 251), (960, 186), (962, 84), (963, 295), (964, 24), (965, 75), (966, 26), (967, 164), (968, 129), (972, 52), (973, 524), (978, 245), (1008, 87), (1009, 155), (1011, 84), (1021, 57), (1033, 125), (1034, 22), (1043, 164), (1073, 223), (1078, 72), (1082, 63), (1114, 55), (1126, 69), (1128, 15), (1139, 44), (1143, 18), (1154, 117), (1155, 29), (1166, 41), (1167, 133), (1173, 130), (1175, 82), (1178, 44), (1179, 26), (1183, 111), (1185, 62), (1186, 274), (1198, 3), (1223, 279), (1253, 161), (1313, 38), (1405, 146), (1417, 59), (1500, 138), (1618, 46), (1852, 59), (1858, 89), (2029, 154), (2285, 1), (2292, 117), (2293, 5)]
def cs86772 : List ℕ := [635, 154, 0, 41, 481, 252, 0, 748, 481, 46, 3, 837, 1000, 705, 293, 0, 813, 1001, 1000, 0, 1000, 3, 608, 905, 46, 190, 592, 0, 0, 625, 999, 1001, 399, 971, 212, 1000, 161, 1000, 867, 1000, 347, 877, 134, 722, 2447, 1001, 531, 1489, 547, 999, 1001, 0, 787, 930, 999, 1001, 1000, 1000, 1000, 1000, 1000, 1001, 372, 672, 912, 1002, 1000, 1001, 1001, 1000, 1001, 1001, 1000, 1000, 1000, 1001, 1730, 1001, 2485, 1001, 959, 2377, 1001, 1000, 718, 604, 916, 1001, 2983, 1001, 1000, 1000, 996, 1946, 1001, 1001, 1000, 999, 1002, 1000, 1001, 1185, 1000, 1001, 930, 1000, 1002, 1000, 1002, 1624, 1000, 999, 1001, 1001, 871, 992, 1003, 1001, 1000, 1000, 1001, 1001, 801, 1002, 912, 999, 1001, 1001, 1002, 1000, 1001, 739, 1001, 1000, 1002, 1001, 900, 786, 1001, 999, 1002, 783, 902, 1001, 1001, 958, 890, 1000, 882, 999, 964, 1001, 1000, 1000]
theorem node86772 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86772 support demand code
    entries86772 ((insert 27 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node86767 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 47 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    27 node86771 node86772
def entries86769 : List (Fin 2295 × ℕ) := [(86, 1306), (177, 2658), (471, 983), (479, 114), (484, 1275), (491, 2258), (514, 3630), (527, 654), (581, 297), (583, 1385), (617, 960), (738, 977), (741, 1495), (782, 2362), (846, 1893), (870, 2324), (873, 1402), (887, 860), (888, 2197), (892, 1436), (894, 1693), (897, 899), (899, 2909), (901, 654), (917, 382), (919, 161), (920, 60), (922, 294), (923, 1579), (926, 2335), (928, 887), (931, 3558), (932, 1343), (943, 548), (944, 764), (945, 3494), (946, 947), (960, 1788), (962, 365), (963, 3022), (964, 1748), (967, 167), (968, 1195), (969, 719), (972, 249), (973, 5153), (978, 1999), (1009, 1283), (1011, 1833), (1033, 1014), (1043, 1236), (1045, 222), (1047, 150), (1072, 441), (1073, 1782), (1077, 147), (1078, 600), (1082, 702), (1110, 12), (1114, 176), (1128, 846), (1139, 1171), (1149, 527), (1154, 1313), (1155, 203), (1166, 839), (1167, 1639), (1172, 580), (1173, 670), (1175, 790), (1179, 163), (1180, 408), (1181, 209), (1183, 1921), (1185, 95), (1186, 2628), (1279, 3596), (1372, 29), (1386, 1832), (1405, 1915), (1417, 533), (1451, 193), (1497, 148), (1500, 287), (1654, 3653), (1659, 1227), (1688, 1422), (1851, 476), (1861, 516), (1901, 306)]
def cs86769 : List ℕ := [516, 5489, 983, 516, 114, 4871, 2258, 7102, 3959, 0, 4146, 10000, 10000, 1737, 0, 0, 10000, 10000, 10000, 3057, 10000, 9886, 3557, 9095, 4579, 0, 6675, 23068, 0, 4080, 9999, 10000, 5705, 10000, 3933, 10000, 0, 10000, 3545, 9999, 5015, 4816, 7200, 5279, 17110, 10000, 10000, 1786, 8613, 9984, 10000, 0, 10001, 9999, 9998, 10000, 10000, 10000, 8285, 9999, 10000, 7218, 10000, 7770, 7456, 10001, 9999, 10000, 10000, 9999, 9006, 9999, 9999, 10000, 9999, 10000, 18346, 10000, 20590, 10000, 9999, 18705, 9999, 10000, 5293, 10001, 9999, 9999, 26978, 10000, 9999, 9999, 9999, 16710, 7231, 10000, 10000, 9874, 9999, 10000, 10000, 10913, 9999, 9999, 9999, 10000, 9743, 8137, 10000, 17605, 10000, 10000, 9999, 9998, 10001, 10001, 9999, 10000, 9999, 9999, 9998, 9999, 6441, 10001, 9999, 10000, 9999, 10000, 9999, 9999, 10000, 8310, 9999, 9999, 10000, 9999, 8376, 9204, 9999, 10000, 9999, 8104, 10000, 9999, 9999, 9038, 9068, 10000, 8900, 10000, 9532, 9512, 9999, 10000]
theorem node86769 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86769 support demand code
    entries86769 ((insert 47 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 27 (insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries86770 : List (Fin 2295 × ℕ) := [(20, 20), (86, 6), (177, 97), (356, 12), (468, 32), (479, 67), (484, 61), (542, 42), (617, 3), (630, 31), (632, 63), (741, 39), (780, 8), (781, 3), (782, 64), (835, 2), (843, 25), (845, 22), (852, 28), (870, 94), (873, 82), (874, 3), (878, 15), (888, 63), (897, 15), (899, 1), (915, 89), (916, 6), (917, 17), (919, 7), (920, 43), (926, 27), (928, 31), (931, 41), (932, 12), (943, 23), (944, 26), (946, 72), (947, 13), (963, 73), (964, 12), (965, 1), (966, 24), (968, 56), (972, 16), (973, 133), (978, 66), (1009, 57), (1011, 4), (1012, 9), (1021, 4), (1033, 27), (1034, 11), (1043, 39), (1045, 21), (1061, 6), (1072, 24), (1073, 26), (1077, 9), (1078, 11), (1114, 8), (1126, 11), (1128, 21), (1139, 14), (1149, 9), (1154, 36), (1155, 7), (1166, 7), (1167, 24), (1172, 29), (1174, 14), (1176, 11), (1177, 45), (1179, 9), (1183, 58), (1186, 58), (1223, 36), (1253, 33), (1358, 21), (1386, 42), (1405, 30), (1417, 20), (1449, 46), (1528, 3), (1534, 12), (1618, 76), (1709, 17), (1711, 22), (1943, 35), (2029, 16)]
def cs86770 : List ℕ := [106, 54, 0, 20, 164, 96, 17, 255, 124, 76, 22, 255, 256, 140, 96, 0, 256, 255, 257, 63, 256, 39, 112, 254, 76, 22, 257, 39, 0, 211, 255, 251, 199, 256, 43, 256, 33, 244, 128, 256, 120, 232, 88, 156, 549, 257, 248, 46, 257, 200, 256, 13, 197, 222, 256, 256, 257, 256, 257, 254, 258, 130, 182, 152, 149, 255, 256, 256, 256, 257, 257, 256, 256, 256, 255, 258, 511, 232, 464, 255, 257, 298, 255, 257, 109, 255, 257, 256, 654, 255, 255, 256, 257, 399, 147, 229, 255, 257, 263, 257, 256, 287, 255, 255, 257, 255, 242, 255, 257, 366, 255, 256, 256, 255, 254, 256, 257, 256, 256, 257, 255, 256, 245, 254, 256, 256, 256, 257, 256, 256, 255, 256, 255, 256, 256, 257, 254, 245, 255, 257, 256, 223, 255, 256, 255, 233, 225, 255, 256, 254, 246, 256, 256, 256]
theorem node86770 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 47 (insert 51 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86770 support demand code
    entries86770 ((insert 27 (insert 47 (insert 51 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node86768 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    27 node86769 node86770
theorem node86759 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 81 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    47 node86767 node86768
def entries86761 : List (Fin 2295 × ℕ) := [(20, 43), (43, 37), (340, 89), (468, 52), (479, 40), (514, 45), (587, 2), (588, 6), (677, 8), (729, 46), (781, 27), (783, 13), (798, 35), (850, 21), (851, 15), (857, 21), (861, 14), (870, 42), (873, 119), (888, 74), (892, 56), (894, 16), (901, 26), (915, 37), (916, 38), (917, 55), (919, 23), (927, 75), (932, 62), (941, 52), (943, 36), (944, 2), (945, 11), (946, 54), (963, 105), (964, 15), (965, 12), (967, 48), (968, 83), (971, 50), (972, 47), (973, 139), (978, 39), (1007, 17), (1009, 39), (1011, 8), (1021, 25), (1025, 18), (1033, 43), (1060, 3), (1061, 24), (1073, 27), (1078, 8), (1081, 9), (1082, 11), (1113, 11), (1114, 4), (1127, 18), (1128, 22), (1138, 1), (1139, 36), (1141, 7), (1154, 28), (1167, 53), (1174, 5), (1176, 15), (1177, 44), (1178, 12), (1179, 25), (1183, 56), (1186, 60), (1223, 81), (1501, 30), (1610, 35), (1861, 22), (1891, 35), (1902, 3), (1943, 21), (1946, 12), (2062, 33), (2286, 18), (2287, 9), (2292, 22), (2293, 12)]
def cs86761 : List ℕ := [103, 79, 0, 98, 136, 21, 58, 237, 204, 0, 102, 236, 256, 255, 72, 0, 256, 256, 255, 74, 256, 171, 38, 256, 27, 0, 255, 255, 0, 114, 223, 255, 128, 255, 5, 255, 15, 257, 75, 255, 137, 256, 210, 92, 647, 256, 255, 240, 99, 253, 256, 0, 203, 211, 255, 605, 256, 256, 256, 256, 255, 34, 160, 256, 90, 246, 334, 255, 256, 256, 120, 256, 256, 256, 256, 254, 460, 234, 479, 256, 219, 74, 256, 256, 256, 255, 255, 254, 573, 256, 256, 256, 211, 392, 257, 255, 255, 256, 255, 256, 255, 287, 256, 257, 255, 256, 254, 232, 217, 622, 256, 256, 256, 255, 199, 187, 255, 255, 256, 256, 256, 254, 255, 255, 211, 256, 256, 255, 255, 254, 255, 256, 256, 256, 254, 240, 256, 229, 256, 255, 254, 205, 256, 255, 255, 247, 255, 252, 255, 255, 256, 255, 255, 255]
theorem node86761 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86761 support demand code
    entries86761 ((insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 55 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries86763 : List (Fin 2295 × ℕ) := [(86, 100), (146, 15), (177, 263), (340, 24), (351, 54), (479, 41), (484, 168), (491, 10), (507, 239), (514, 156), (527, 61), (585, 218), (617, 204), (632, 3), (677, 70), (739, 164), (781, 92), (783, 141), (798, 148), (842, 18), (846, 240), (851, 61), (852, 68), (870, 239), (873, 59), (888, 139), (897, 56), (899, 66), (901, 76), (915, 223), (917, 108), (921, 29), (923, 89), (926, 182), (927, 357), (928, 294), (932, 232), (943, 91), (945, 108), (946, 244), (956, 111), (963, 234), (964, 310), (967, 57), (968, 322), (971, 118), (972, 182), (973, 534), (978, 174), (1007, 102), (1009, 139), (1011, 120), (1033, 87), (1034, 37), (1045, 15), (1061, 48), (1068, 19), (1072, 12), (1073, 212), (1078, 56), (1082, 89), (1111, 26), (1126, 67), (1139, 187), (1154, 91), (1166, 3), (1167, 71), (1173, 53), (1174, 112), (1175, 7), (1177, 2), (1178, 109), (1182, 27), (1183, 165), (1186, 301), (1223, 328), (1279, 133), (1417, 46), (1497, 192), (1501, 131), (1517, 28), (1579, 11), (1711, 197), (1802, 19), (1852, 115), (1997, 162), (2063, 19), (2249, 129)]
def cs86763 : List ℕ := [457, 373, 0, 162, 627, 301, 38, 1000, 476, 401, 372, 1000, 1000, 59, 197, 0, 1001, 999, 1001, 139, 1000, 415, 450, 892, 534, 0, 875, 1001, 0, 428, 999, 1000, 999, 999, 412, 1000, 61, 1000, 914, 1000, 440, 461, 628, 664, 1854, 998, 1000, 1000, 615, 978, 999, 0, 1000, 1000, 1000, 290, 998, 1001, 999, 1000, 1000, 401, 999, 568, 1001, 908, 1000, 999, 1000, 1000, 313, 999, 1000, 999, 1000, 1001, 1050, 825, 2322, 999, 1000, 0, 1000, 998, 620, 756, 951, 1000, 2708, 999, 1000, 1000, 1002, 1562, 999, 808, 1000, 998, 999, 1000, 999, 1023, 1654, 999, 926, 1000, 956, 860, 1000, 2087, 1000, 999, 1000, 1000, 765, 789, 1000, 999, 1000, 999, 999, 1000, 799, 999, 999, 1000, 1000, 1000, 999, 1000, 998, 929, 1000, 999, 999, 999, 727, 794, 999, 1000, 999, 866, 853, 999, 999, 910, 980, 999, 890, 1000, 959, 999, 999, 1000]
theorem node86763 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 102 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86763 support demand code
    entries86763 ((insert 55 (insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 102 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries86765 : List (Fin 2295 × ℕ) := [(23, 14), (49, 32), (99, 7), (177, 57), (340, 21), (479, 10), (484, 53), (507, 55), (514, 43), (542, 6), (587, 21), (617, 57), (629, 3), (781, 78), (798, 34), (842, 34), (846, 74), (852, 8), (870, 76), (888, 31), (894, 36), (901, 3), (915, 55), (916, 13), (917, 54), (919, 43), (920, 21), (921, 40), (923, 45), (926, 33), (927, 108), (928, 7), (930, 13), (932, 54), (943, 39), (946, 92), (963, 81), (965, 35), (968, 53), (971, 3), (972, 69), (973, 132), (978, 59), (994, 20), (1009, 45), (1012, 25), (1034, 26), (1045, 49), (1061, 14), (1071, 8), (1072, 4), (1073, 21), (1078, 1), (1081, 35), (1082, 8), (1099, 1), (1125, 2), (1126, 13), (1127, 30), (1128, 37), (1142, 7), (1148, 15), (1154, 25), (1155, 10), (1175, 32), (1176, 27), (1177, 31), (1179, 39), (1183, 41), (1185, 13), (1186, 60), (1223, 130), (1497, 16), (1517, 27), (1528, 5), (1540, 6), (1711, 30), (1997, 22), (2249, 19), (2293, 56)]
def cs86765 : List ℕ := [149, 74, 0, 22, 181, 53, 27, 255, 181, 77, 73, 255, 256, 7, 36, 0, 256, 255, 257, 31, 255, 66, 78, 168, 77, 0, 172, 256, 0, 138, 255, 255, 256, 256, 106, 255, 0, 255, 185, 449, 83, 161, 154, 114, 634, 257, 239, 230, 205, 249, 256, 0, 181, 256, 255, 97, 256, 256, 256, 255, 257, 133, 249, 143, 110, 246, 256, 256, 256, 256, 112, 256, 256, 211, 256, 257, 292, 187, 517, 256, 256, 0, 256, 255, 171, 227, 256, 256, 601, 256, 256, 256, 220, 367, 256, 232, 257, 256, 257, 215, 256, 256, 114, 256, 255, 256, 243, 257, 230, 411, 256, 256, 253, 255, 130, 207, 257, 256, 257, 255, 251, 257, 256, 257, 257, 228, 256, 256, 256, 257, 234, 253, 257, 256, 256, 257, 235, 235, 257, 256, 256, 249, 204, 256, 257, 255, 257, 220, 256, 256, 225, 255, 256, 256]
theorem node86765 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 102 (insert 55 (insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86765 support demand code
    entries86765 ((insert 102 (insert 55 (insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries86766 : List (Fin 2295 × ℕ) := [(86, 5), (99, 7), (146, 3), (177, 29), (340, 10), (479, 10), (484, 25), (494, 1), (514, 37), (530, 37), (585, 10), (617, 24), (639, 4), (640, 4), (781, 28), (798, 15), (852, 15), (888, 15), (894, 29), (899, 20), (900, 2), (901, 8), (923, 25), (926, 13), (927, 51), (928, 2), (930, 16), (932, 29), (943, 7), (946, 39), (962, 2), (963, 40), (967, 15), (968, 21), (971, 13), (972, 20), (973, 54), (978, 17), (1006, 6), (1007, 3), (1009, 5), (1011, 9), (1012, 15), (1043, 5), (1045, 3), (1061, 6), (1073, 10), (1081, 14), (1082, 6), (1096, 2), (1113, 4), (1127, 3), (1128, 13), (1139, 16), (1148, 1), (1154, 16), (1162, 4), (1166, 2), (1167, 18), (1173, 13), (1174, 1), (1175, 26), (1179, 3), (1183, 4), (1185, 16), (1186, 19), (1273, 6), (1400, 3), (1423, 7), (1501, 7), (1545, 6), (1775, 19), (1861, 21), (1997, 10), (2029, 2), (2242, 7), (2249, 26)]
def cs86766 : List ℕ := [63, 0, 7, 31, 51, 32, 19, 89, 33, 10, 58, 45, 101, 44, 19, 0, 99, 99, 100, 15, 100, 58, 36, 101, 17, 0, 100, 100, 0, 58, 101, 97, 101, 100, 40, 101, 7, 100, 98, 0, 79, 100, 80, 100, 119, 101, 101, 86, 68, 64, 101, 0, 99, 99, 99, 23, 101, 101, 100, 101, 101, 49, 84, 50, 85, 73, 100, 100, 100, 100, 41, 101, 100, 85, 100, 100, 103, 63, 226, 98, 96, 2, 100, 100, 66, 51, 99, 100, 249, 100, 100, 101, 98, 158, 101, 63, 101, 74, 101, 97, 100, 99, 67, 100, 99, 100, 68, 101, 79, 204, 100, 100, 98, 100, 44, 80, 100, 100, 100, 100, 101, 101, 100, 99, 90, 97, 99, 100, 100, 101, 100, 100, 99, 100, 99, 101, 99, 83, 101, 100, 100, 89, 93, 100, 100, 99, 101, 92, 100, 100, 97, 99, 96, 99]
theorem node86766 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 102 (insert 55 (insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs86766 support demand code
    entries86766 ((insert 39 (insert 102 (insert 55 (insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node86764 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 102 (insert 55 (insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 102 (insert 55 (insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    39 node86765 node86766
theorem node86762 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    102 node86763 node86764
theorem node86760 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 51 (insert 36 (insert 34 (insert 25 ∅))))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    55 node86761 node86762
theorem node86758 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 36 (insert 34 (insert 25 ∅)))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    81 node86759 node86760
theorem node86715 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 25 ∅))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 109 (insert 78 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    51 node86757 node86758
#print axioms node86715
end OmissionResidualCover31Fused
