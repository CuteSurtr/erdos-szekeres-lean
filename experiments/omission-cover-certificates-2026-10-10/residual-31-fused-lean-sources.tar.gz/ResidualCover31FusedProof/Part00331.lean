import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries73087 : List (Fin 2295 × ℕ) := [(890, 1)]
def cs73087 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node73087 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 21 (insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73087 support demand code
    entries73087 ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)) ((insert 57 (insert 21 (insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries73089 : List (Fin 2295 × ℕ) := [(890, 1)]
def cs73089 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node73089 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 85 (insert 21 (insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73089 support demand code
    entries73089 ((insert 57 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 85 (insert 21 (insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries73090 : List (Fin 2295 × ℕ) := [(37, 130), (70, 263), (75, 243), (92, 17), (135, 133), (157, 176), (471, 72), (479, 363), (491, 375), (507, 79), (588, 128), (730, 168), (731, 587), (742, 11), (797, 246), (814, 19), (815, 8), (817, 45), (846, 245), (852, 80), (855, 112), (860, 377), (865, 114), (871, 872), (884, 319), (886, 440), (888, 49), (896, 31), (920, 163), (935, 78), (937, 84), (939, 210), (940, 31), (944, 189), (948, 183), (949, 245), (950, 102), (952, 160), (958, 170), (969, 79), (973, 507), (982, 11), (984, 303), (985, 38), (1024, 223), (1025, 231), (1073, 272), (1095, 258), (1097, 195), (1100, 26), (1101, 26), (1103, 145), (1104, 60), (1123, 50), (1126, 78), (1130, 26), (1132, 88), (1133, 77), (1157, 145), (1158, 54), (1169, 49), (1175, 22), (1182, 248), (1184, 20), (1186, 217), (1193, 141), (1198, 111), (1217, 7), (1275, 40), (1307, 29), (1308, 95), (1344, 190), (1374, 90), (1511, 241), (1545, 7), (1605, 38), (1612, 123), (1652, 13), (1669, 4), (1710, 58), (1767, 233), (1852, 69), (1945, 24), (2138, 7), (2139, 124)]
def cs73090 : List ℕ := [492, 486, 312, 614, 936, 519, 645, 1000, 1000, 79, 972, 623, 999, 1000, 999, 0, 1000, 1000, 1907, 179, 999, 824, 128, 996, 432, 2877, 1000, 1523, 0, 617, 999, 1001, 207, 999, 507, 886, 0, 999, 130, 1001, 363, 1000, 692, 764, 2272, 1000, 1044, 1000, 793, 770, 1000, 1001, 928, 1000, 999, 2460, 999, 0, 1000, 1000, 2964, 872, 1000, 0, 514, 1000, 1922, 1000, 999, 1000, 1166, 1000, 1000, 999, 999, 1000, 343, 1000, 1278, 1000, 842, 1001, 644, 999, 921, 49, 1000, 968, 999, 1000, 1000, 1000, 1000, 1000, 618, 1000, 518, 1000, 1000, 1000, 999, 1000, 892, 1001, 832, 999, 1000, 682, 1000, 237, 1000, 999, 999, 999, 1000, 1001, 1000, 999, 999, 1887, 1000, 999, 1000, 1000, 1000, 556, 1001, 1000, 987, 1000, 1001, 1000, 1000, 999, 1001, 884, 959, 751, 1000, 1000, 1000, 936, 955, 1001, 785, 1000, 1000, 875, 999, 1000, 865, 921, 999, 916]
theorem node73090 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 85 (insert 57 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73090 support demand code
    entries73090 ((insert 85 (insert 57 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node73088 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 57 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154))
    85 node73089 node73090
theorem node73085 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154))
    57 node73087 node73088
def entries73086 : List (Fin 2295 × ℕ) := [(4, 60), (37, 31), (72, 110), (135, 37), (307, 54), (342, 5), (469, 3), (471, 32), (474, 50), (479, 41), (491, 64), (507, 33), (542, 28), (588, 45), (619, 51), (639, 11), (730, 64), (731, 39), (738, 13), (739, 12), (797, 38), (814, 17), (816, 21), (849, 1), (852, 77), (855, 87), (858, 33), (871, 163), (872, 93), (884, 39), (886, 101), (888, 45), (890, 74), (920, 47), (924, 29), (937, 7), (938, 23), (939, 22), (940, 15), (944, 94), (950, 28), (952, 35), (958, 28), (969, 11), (970, 62), (973, 130), (982, 5), (985, 54), (990, 6), (1008, 7), (1024, 8), (1025, 64), (1035, 18), (1073, 16), (1095, 35), (1096, 14), (1097, 1), (1100, 23), (1103, 55), (1104, 58), (1108, 7), (1123, 29), (1126, 12), (1128, 24), (1131, 70), (1133, 16), (1157, 7), (1158, 15), (1169, 88), (1174, 7), (1182, 37), (1186, 18), (1193, 30), (1258, 15), (1275, 50), (1281, 32), (1308, 47), (1344, 9), (1374, 39), (1528, 11), (1605, 41), (1612, 5), (1650, 21), (1651, 15), (1767, 72), (1864, 28), (2171, 25), (2238, 11)]
def cs73086 : List ℕ := [134, 63, 136, 155, 208, 133, 125, 257, 121, 48, 110, 177, 257, 256, 256, 0, 256, 196, 581, 76, 257, 74, 45, 256, 170, 709, 256, 455, 110, 28, 255, 257, 156, 255, 80, 256, 0, 257, 173, 257, 95, 171, 208, 255, 629, 257, 299, 255, 176, 224, 256, 256, 190, 256, 255, 611, 255, 255, 254, 255, 521, 234, 257, 93, 176, 256, 616, 255, 255, 255, 456, 255, 255, 254, 255, 256, 93, 255, 141, 255, 221, 255, 255, 256, 254, 255, 255, 254, 255, 181, 255, 243, 255, 255, 255, 255, 171, 254, 254, 255, 256, 255, 208, 255, 217, 254, 254, 250, 256, 18, 255, 256, 254, 255, 254, 254, 256, 255, 255, 507, 255, 254, 257, 250, 255, 218, 255, 255, 254, 256, 255, 255, 256, 254, 256, 255, 234, 219, 255, 256, 256, 190, 255, 256, 190, 255, 204, 255, 255, 256, 246, 229, 200, 198]
theorem node73086 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73086 support demand code
    entries73086 ((insert 21 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node73083 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)) ((insert 46 (insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154))
    21 node73085 node73086
def entries73084 : List (Fin 2295 × ℕ) := [(4, 87), (37, 23), (46, 39), (70, 101), (135, 61), (148, 26), (307, 85), (469, 34), (471, 25), (491, 78), (507, 83), (570, 7), (632, 8), (639, 29), (731, 96), (739, 54), (741, 9), (797, 22), (817, 30), (844, 50), (847, 61), (855, 120), (858, 41), (865, 1), (871, 90), (872, 166), (884, 20), (886, 71), (888, 57), (889, 84), (920, 58), (924, 11), (937, 47), (939, 13), (940, 13), (944, 109), (948, 6), (949, 36), (950, 64), (951, 24), (952, 2), (958, 6), (969, 19), (970, 64), (973, 138), (985, 52), (990, 29), (1008, 48), (1025, 66), (1033, 9), (1073, 90), (1100, 45), (1102, 22), (1103, 5), (1104, 47), (1123, 7), (1126, 8), (1131, 56), (1133, 28), (1139, 1), (1153, 44), (1154, 14), (1157, 6), (1169, 90), (1174, 6), (1175, 16), (1182, 28), (1186, 15), (1193, 28), (1275, 44), (1281, 78), (1293, 7), (1305, 22), (1344, 15), (1370, 1), (1374, 4), (1381, 3), (1489, 1), (1527, 42), (1528, 13), (1605, 37), (1612, 18), (1859, 2), (1866, 6), (1887, 8), (2237, 4), (2238, 36)]
def cs73084 : List ℕ := [164, 121, 164, 84, 115, 145, 166, 256, 138, 83, 102, 198, 256, 256, 255, 0, 257, 251, 672, 106, 256, 224, 0, 256, 220, 771, 256, 410, 0, 148, 256, 256, 131, 255, 83, 256, 84, 256, 106, 256, 85, 255, 187, 255, 619, 256, 0, 257, 173, 230, 255, 256, 192, 256, 256, 729, 257, 257, 256, 226, 627, 256, 256, 83, 255, 255, 679, 255, 256, 256, 622, 256, 256, 256, 191, 255, 177, 256, 255, 256, 231, 256, 256, 256, 224, 256, 257, 256, 256, 155, 255, 256, 256, 256, 216, 256, 205, 257, 255, 256, 256, 304, 257, 255, 256, 256, 255, 256, 258, 15, 256, 256, 257, 255, 255, 256, 257, 255, 256, 565, 256, 255, 256, 256, 255, 228, 256, 257, 253, 257, 206, 256, 257, 256, 257, 256, 245, 228, 256, 257, 256, 171, 256, 257, 206, 257, 245, 251, 229, 221, 218, 241, 247, 197]
theorem node73084 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73084 support demand code
    entries73084 ((insert 46 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node73075 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)) ((insert 18 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154))
    46 node73083 node73084
def entries73081 : List (Fin 2295 × ℕ) := [(4, 231), (35, 158), (148, 174), (215, 39), (342, 74), (361, 43), (466, 89), (479, 69), (491, 190), (498, 210), (588, 170), (616, 103), (639, 58), (640, 143), (641, 460), (730, 111), (731, 566), (743, 124), (780, 253), (781, 33), (784, 203), (844, 54), (852, 74), (856, 531), (858, 314), (865, 189), (867, 48), (871, 10), (872, 18), (884, 101), (886, 439), (888, 182), (889, 259), (890, 741), (920, 471), (939, 18), (940, 231), (944, 448), (947, 213), (950, 456), (952, 90), (969, 88), (970, 127), (973, 474), (985, 64), (990, 55), (1008, 142), (1011, 122), (1024, 44), (1025, 418), (1072, 52), (1096, 100), (1100, 77), (1103, 265), (1104, 112), (1123, 73), (1128, 70), (1131, 99), (1133, 100), (1154, 218), (1169, 241), (1174, 108), (1182, 14), (1193, 285), (1251, 109), (1275, 290), (1305, 6), (1322, 7), (1344, 234), (1374, 383), (1546, 69), (1556, 4), (1616, 30), (1647, 27), (1657, 116), (1887, 137), (2237, 3)]
def cs73081 : List ℕ := [544, 347, 0, 0, 775, 689, 504, 402, 1000, 0, 237, 395, 1000, 186, 632, 0, 745, 1000, 28, 356, 1000, 1000, 170, 1000, 0, 2496, 1000, 1741, 0, 158, 1000, 1000, 225, 1001, 108, 946, 259, 911, 30, 1000, 69, 1000, 882, 1000, 2524, 1000, 1000, 1000, 723, 1000, 1000, 999, 264, 1000, 1000, 2708, 999, 999, 893, 1000, 3613, 680, 1000, 104, 995, 1000, 3164, 1000, 1000, 1000, 3736, 694, 1001, 999, 1001, 2500, 479, 999, 814, 1000, 932, 2027, 754, 1000, 951, 1000, 1002, 1000, 1000, 901, 1000, 1000, 999, 999, 1001, 959, 397, 1001, 999, 1001, 1000, 1142, 582, 999, 997, 1001, 1000, 1001, 1001, 0, 1000, 1000, 999, 1001, 1000, 1001, 1001, 999, 692, 2237, 1000, 991, 1001, 1001, 1000, 715, 1001, 1001, 978, 1003, 793, 867, 1001, 1000, 1001, 1001, 1000, 715, 1001, 1000, 1000, 771, 838, 1001, 762, 976, 789, 715, 709, 751, 960, 973, 952, 794]
theorem node73081 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 75 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73081 support demand code
    entries73081 ((insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 75 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries73082 : List (Fin 2295 × ℕ) := [(4, 12), (75, 12), (137, 20), (215, 8), (466, 1), (479, 7), (490, 2), (491, 28), (498, 12), (572, 20), (632, 20), (639, 9), (640, 4), (641, 46), (692, 7), (731, 60), (777, 4), (781, 11), (785, 10), (797, 22), (833, 2), (844, 6), (856, 46), (865, 37), (871, 25), (884, 24), (886, 30), (889, 20), (890, 68), (920, 47), (935, 6), (937, 37), (939, 14), (944, 43), (948, 10), (950, 34), (952, 3), (958, 7), (969, 10), (970, 11), (972, 4), (973, 49), (985, 25), (990, 4), (1008, 17), (1024, 2), (1025, 27), (1072, 2), (1073, 36), (1096, 6), (1098, 13), (1103, 1), (1104, 21), (1108, 4), (1123, 4), (1126, 10), (1128, 3), (1131, 14), (1133, 16), (1139, 3), (1153, 8), (1154, 10), (1157, 4), (1169, 25), (1174, 21), (1179, 8), (1182, 13), (1193, 23), (1223, 25), (1242, 9), (1266, 3), (1275, 15), (1323, 8), (1443, 3), (1449, 8), (1605, 16), (1616, 3)]
def cs73082 : List ℕ := [55, 12, 0, 0, 67, 55, 30, 39, 81, 0, 49, 56, 99, 34, 47, 0, 100, 41, 25, 20, 99, 100, 0, 100, 0, 277, 100, 155, 0, 41, 99, 100, 6, 100, 21, 64, 20, 87, 0, 100, 47, 100, 71, 100, 294, 100, 100, 100, 76, 100, 100, 99, 67, 101, 75, 295, 92, 100, 80, 99, 340, 96, 100, 20, 92, 101, 269, 100, 101, 100, 226, 61, 100, 100, 100, 211, 67, 100, 81, 101, 100, 0, 99, 101, 100, 101, 94, 98, 99, 93, 100, 101, 99, 63, 100, 100, 60, 99, 100, 100, 100, 114, 50, 69, 100, 99, 99, 100, 100, 12, 101, 103, 99, 99, 69, 100, 100, 101, 100, 225, 100, 99, 100, 100, 100, 74, 101, 100, 99, 100, 100, 101, 100, 100, 100, 100, 101, 82, 99, 101, 100, 84, 100, 100, 84, 100, 90, 88, 86, 99, 92, 88, 88, 67]
theorem node73082 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73082 support demand code
    entries73082 ((insert 81 (insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 75 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node73077 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 75 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154))
    81 node73081 node73082
def entries73079 : List (Fin 2295 × ℕ) := [(4, 15), (37, 96), (72, 87), (75, 68), (86, 44), (148, 15), (342, 32), (479, 52), (485, 130), (491, 97), (497, 22), (498, 37), (571, 29), (572, 45), (588, 60), (640, 19), (642, 30), (690, 25), (692, 8), (731, 108), (743, 39), (777, 32), (816, 14), (817, 33), (844, 67), (852, 29), (865, 59), (870, 12), (884, 30), (886, 96), (888, 15), (890, 167), (917, 21), (920, 93), (921, 9), (937, 68), (939, 33), (944, 67), (947, 29), (948, 63), (949, 67), (950, 96), (951, 52), (952, 15), (958, 7), (970, 53), (973, 124), (982, 2), (990, 13), (1008, 55), (1024, 36), (1025, 95), (1061, 5), (1073, 110), (1098, 34), (1102, 6), (1103, 22), (1126, 14), (1128, 51), (1130, 12), (1132, 16), (1133, 30), (1139, 38), (1153, 36), (1154, 95), (1155, 1), (1169, 59), (1174, 36), (1183, 2), (1193, 73), (1198, 13), (1261, 35), (1275, 25), (1342, 1), (1370, 16), (1517, 32), (1605, 11), (1607, 7), (1612, 23), (1690, 41), (1845, 28), (1848, 4), (2134, 25), (2237, 2)]
def cs73079 : List ℕ := [153, 15, 0, 13, 182, 226, 129, 148, 256, 0, 227, 185, 256, 13, 256, 0, 256, 256, 0, 200, 255, 255, 60, 256, 27, 663, 256, 362, 87, 88, 256, 256, 235, 256, 36, 222, 0, 255, 227, 257, 126, 256, 256, 218, 499, 255, 255, 256, 163, 183, 256, 842, 255, 256, 226, 429, 256, 255, 255, 256, 739, 237, 256, 76, 222, 230, 757, 257, 256, 246, 772, 194, 256, 255, 255, 0, 161, 257, 312, 257, 255, 256, 256, 258, 255, 256, 256, 211, 257, 256, 256, 242, 257, 256, 257, 256, 152, 257, 258, 256, 256, 311, 257, 256, 256, 256, 257, 244, 256, 0, 256, 255, 257, 256, 257, 255, 255, 257, 255, 582, 256, 235, 255, 256, 257, 183, 255, 256, 236, 248, 257, 255, 255, 256, 239, 256, 255, 211, 255, 255, 257, 164, 223, 255, 256, 256, 208, 197, 142, 211, 221, 179, 255, 152]
theorem node73079 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73079 support demand code
    entries73079 ((insert 75 (insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 51 (insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries73080 : List (Fin 2295 × ℕ) := [(4, 15), (35, 27), (75, 11), (86, 11), (130, 13), (135, 2), (148, 16), (479, 11), (491, 45), (588, 28), (631, 9), (690, 11), (692, 2), (730, 42), (731, 14), (737, 15), (739, 2), (743, 22), (797, 14), (812, 8), (815, 11), (844, 37), (856, 47), (865, 18), (884, 3), (885, 13), (886, 47), (888, 37), (890, 89), (920, 51), (921, 12), (924, 8), (929, 4), (934, 3), (937, 6), (938, 33), (944, 27), (969, 12), (970, 30), (973, 51), (982, 1), (999, 6), (1008, 14), (1010, 14), (1024, 20), (1025, 23), (1073, 19), (1096, 4), (1097, 4), (1102, 2), (1103, 14), (1123, 16), (1126, 13), (1128, 14), (1131, 23), (1133, 18), (1153, 3), (1154, 5), (1157, 3), (1169, 11), (1175, 2), (1183, 26), (1193, 38), (1258, 16), (1275, 3), (1308, 8), (1370, 23), (1528, 15), (1611, 5), (1848, 3), (2166, 10), (2238, 2)]
def cs73080 : List ℕ := [75, 15, 0, 0, 64, 74, 45, 48, 80, 0, 29, 56, 84, 27, 64, 0, 78, 101, 0, 53, 100, 100, 28, 90, 11, 282, 100, 152, 0, 47, 100, 100, 36, 101, 12, 64, 0, 100, 11, 100, 20, 101, 100, 86, 193, 100, 100, 95, 63, 99, 100, 2, 91, 102, 101, 184, 98, 100, 100, 101, 113, 58, 99, 2, 101, 89, 200, 100, 100, 83, 210, 66, 100, 100, 85, 47, 58, 100, 40, 100, 100, 100, 101, 100, 95, 100, 93, 100, 101, 100, 101, 100, 92, 94, 101, 101, 70, 101, 100, 101, 100, 128, 101, 98, 100, 101, 100, 91, 100, 0, 100, 100, 100, 100, 99, 101, 100, 100, 100, 220, 88, 85, 100, 86, 100, 62, 100, 100, 86, 100, 100, 101, 99, 100, 98, 101, 100, 66, 99, 100, 100, 72, 91, 100, 95, 90, 82, 75, 95, 91, 99, 74, 75, 80]
theorem node73080 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 75 (insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73080 support demand code
    entries73080 ((insert 51 (insert 75 (insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node73078 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 75 (insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154))
    51 node73079 node73080
theorem node73076 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154))
    75 node73077 node73078
theorem node73019 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)) ((insert 60 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154))
    18 node73075 node73076
def entries73069 : List (Fin 2295 × ℕ) := [(157, 1)]
def cs73069 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node73069 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73069 support demand code
    entries73069 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 95 (insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries73071 : List (Fin 2295 × ℕ) := [(890, 1)]
def cs73071 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node73071 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73071 support demand code
    entries73071 ((insert 95 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 57 (insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries73073 : List (Fin 2295 × ℕ) := [(890, 1)]
def cs73073 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node73073 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 85 (insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73073 support demand code
    entries73073 ((insert 57 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 85 (insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries73074 : List (Fin 2295 × ℕ) := [(4, 20), (37, 50), (72, 21), (75, 23), (92, 27), (95, 5), (137, 20), (344, 14), (360, 5), (514, 4), (532, 58), (571, 9), (581, 43), (585, 36), (587, 6), (588, 36), (617, 28), (639, 22), (640, 4), (731, 20), (741, 6), (743, 5), (812, 1), (813, 27), (814, 4), (815, 2), (817, 21), (819, 14), (844, 16), (849, 1), (850, 9), (852, 29), (855, 14), (867, 26), (885, 3), (896, 18), (920, 17), (921, 5), (938, 28), (940, 28), (942, 1), (944, 32), (966, 13), (970, 10), (973, 52), (982, 19), (985, 5), (1008, 20), (1025, 38), (1027, 4), (1097, 5), (1099, 1), (1100, 3), (1101, 10), (1102, 5), (1103, 15), (1104, 6), (1123, 19), (1126, 5), (1132, 11), (1158, 5), (1171, 5), (1184, 3), (1186, 43), (1193, 24), (1217, 31), (1226, 24), (1295, 4), (1313, 6), (1500, 4), (1621, 10), (1652, 8), (1675, 6), (1767, 24), (1845, 8), (1846, 6), (2225, 14)]
def cs73074 : List ℕ := [101, 20, 55, 40, 79, 101, 0, 100, 100, 0, 80, 31, 101, 90, 100, 0, 58, 100, 175, 59, 101, 126, 42, 101, 19, 294, 100, 183, 21, 29, 100, 101, 42, 100, 56, 93, 0, 101, 71, 100, 29, 100, 98, 100, 235, 100, 153, 100, 53, 24, 100, 100, 69, 100, 99, 153, 101, 0, 100, 99, 0, 100, 93, 33, 96, 68, 134, 101, 101, 159, 111, 99, 100, 100, 99, 100, 28, 100, 18, 100, 81, 190, 99, 100, 88, 5, 99, 100, 101, 100, 101, 100, 98, 100, 100, 0, 74, 100, 100, 100, 100, 100, 66, 52, 71, 101, 99, 87, 100, 47, 100, 100, 98, 101, 100, 100, 100, 101, 100, 189, 99, 99, 100, 100, 100, 57, 100, 100, 89, 101, 83, 57, 100, 100, 100, 100, 100, 95, 100, 100, 83, 68, 79, 100, 99, 76, 82, 100, 87, 100, 100, 100, 98, 95]
theorem node73074 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 85 (insert 57 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73074 support demand code
    entries73074 ((insert 85 (insert 57 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node73072 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 57 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    85 node73073 node73074
theorem node73070 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 95 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    57 node73071 node73072
theorem node73067 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 21 (insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    95 node73069 node73070
def entries73068 : List (Fin 2295 × ℕ) := [(72, 192), (135, 16), (148, 12), (342, 70), (344, 22), (469, 64), (507, 38), (514, 23), (532, 125), (571, 10), (588, 23), (617, 2), (619, 91), (620, 6), (632, 6), (639, 35), (729, 16), (730, 20), (731, 21), (739, 10), (812, 15), (815, 12), (845, 4), (855, 43), (867, 42), (872, 131), (886, 30), (888, 25), (913, 15), (920, 77), (921, 29), (934, 48), (938, 129), (940, 22), (944, 110), (966, 17), (970, 29), (973, 131), (982, 3), (985, 59), (1008, 12), (1010, 11), (1025, 27), (1035, 13), (1036, 16), (1037, 12), (1095, 38), (1096, 16), (1102, 19), (1103, 70), (1104, 56), (1108, 24), (1123, 26), (1133, 45), (1158, 25), (1159, 30), (1169, 70), (1171, 54), (1174, 16), (1175, 2), (1186, 31), (1193, 31), (1217, 13), (1223, 72), (1231, 24), (1258, 19), (1272, 4), (1275, 22), (1281, 58), (1308, 40), (1313, 21), (1344, 12), (1370, 41), (1433, 1), (1481, 6), (1483, 16), (1500, 20), (1619, 44), (1657, 3), (1690, 54), (1701, 11), (1845, 11), (1859, 41), (2292, 20)]
def cs73068 : List ℕ := [239, 71, 71, 79, 127, 118, 41, 255, 127, 82, 257, 251, 255, 256, 247, 0, 256, 59, 578, 47, 256, 0, 23, 255, 207, 578, 256, 338, 192, 63, 256, 255, 146, 255, 31, 255, 0, 256, 246, 255, 58, 256, 248, 256, 569, 256, 172, 254, 179, 131, 256, 256, 157, 255, 256, 556, 257, 256, 255, 256, 30, 255, 257, 141, 196, 256, 539, 256, 257, 320, 394, 253, 240, 256, 255, 257, 107, 257, 71, 256, 223, 447, 256, 256, 256, 255, 257, 256, 256, 216, 257, 237, 257, 255, 235, 256, 176, 256, 256, 256, 257, 255, 256, 256, 180, 255, 223, 256, 257, 31, 256, 271, 256, 256, 256, 256, 257, 257, 255, 482, 255, 256, 257, 257, 257, 255, 256, 255, 257, 257, 237, 255, 257, 256, 257, 247, 255, 212, 257, 256, 238, 255, 225, 257, 200, 256, 255, 256, 257, 256, 234, 256, 211, 208]
theorem node73068 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73068 support demand code
    entries73068 ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node73063 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154))
    21 node73067 node73068
def entries73065 : List (Fin 2295 × ℕ) := [(37, 31), (72, 67), (342, 26), (479, 40), (491, 23), (507, 49), (532, 49), (572, 2), (588, 3), (629, 15), (631, 14), (639, 20), (640, 3), (736, 10), (738, 4), (739, 23), (741, 12), (743, 19), (797, 3), (812, 6), (814, 5), (843, 3), (845, 12), (849, 31), (852, 9), (860, 18), (867, 26), (885, 1), (886, 17), (890, 100), (913, 16), (920, 58), (922, 1), (934, 17), (938, 47), (940, 21), (944, 45), (970, 21), (973, 43), (984, 9), (985, 26), (998, 7), (999, 6), (1008, 7), (1010, 7), (1011, 2), (1025, 18), (1027, 4), (1072, 14), (1073, 3), (1096, 11), (1100, 10), (1101, 3), (1102, 27), (1104, 17), (1108, 16), (1123, 11), (1128, 3), (1133, 24), (1157, 7), (1158, 18), (1169, 11), (1174, 7), (1186, 8), (1193, 20), (1217, 8), (1223, 31), (1258, 21), (1272, 1), (1275, 7), (1277, 1), (1308, 2), (1344, 14), (1354, 14), (1728, 1), (1848, 18), (2149, 3), (2171, 24)]
def cs73065 : List ℕ := [59, 12, 8, 31, 100, 39, 23, 100, 100, 49, 93, 62, 100, 49, 87, 0, 57, 63, 137, 33, 100, 100, 6, 99, 49, 228, 100, 188, 67, 48, 92, 99, 55, 101, 46, 100, 0, 100, 98, 99, 72, 100, 100, 101, 337, 100, 198, 100, 0, 84, 100, 100, 81, 100, 100, 248, 100, 100, 100, 247, 17, 75, 101, 26, 95, 77, 247, 100, 100, 0, 280, 100, 81, 65, 101, 81, 48, 101, 0, 100, 2, 172, 100, 100, 46, 111, 99, 100, 99, 91, 100, 100, 99, 99, 100, 77, 59, 99, 99, 100, 99, 101, 99, 100, 77, 100, 99, 100, 100, 8, 100, 100, 46, 100, 100, 100, 101, 100, 100, 238, 80, 99, 100, 101, 101, 54, 99, 99, 99, 101, 83, 100, 100, 99, 100, 100, 99, 54, 100, 100, 100, 92, 72, 100, 84, 99, 94, 79, 100, 68, 80, 100, 72, 59]
theorem node73065 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73065 support demand code
    entries73065 ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 59 (insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries73066 : List (Fin 2295 × ℕ) := [(4, 11), (35, 9), (37, 42), (46, 4), (72, 15), (75, 25), (137, 35), (342, 6), (349, 12), (469, 21), (482, 28), (491, 15), (507, 33), (532, 33), (572, 7), (587, 13), (588, 32), (631, 18), (710, 15), (741, 6), (798, 14), (812, 8), (813, 14), (815, 9), (817, 26), (819, 6), (845, 34), (847, 11), (853, 2), (855, 2), (867, 17), (870, 4), (872, 47), (886, 10), (888, 26), (890, 53), (898, 3), (938, 17), (940, 5), (942, 25), (944, 26), (959, 14), (966, 2), (969, 15), (970, 21), (973, 52), (985, 4), (1008, 10), (1010, 1), (1011, 17), (1024, 25), (1025, 42), (1027, 12), (1096, 9), (1099, 5), (1100, 7), (1102, 10), (1103, 1), (1104, 8), (1123, 29), (1128, 5), (1133, 28), (1169, 20), (1170, 1), (1171, 5), (1186, 18), (1193, 27), (1199, 1), (1217, 8), (1258, 12), (1281, 18), (1323, 1), (1354, 6), (1370, 7), (1403, 16), (1508, 4), (1616, 12), (1675, 8), (1703, 1), (1770, 8), (1848, 17), (2013, 1), (2016, 9), (2171, 18)]
def cs73066 : List ℕ := [61, 75, 37, 28, 39, 100, 29, 100, 100, 33, 65, 66, 100, 100, 100, 0, 99, 99, 211, 75, 100, 100, 59, 100, 100, 295, 99, 181, 15, 76, 82, 67, 78, 99, 29, 80, 0, 100, 68, 100, 42, 100, 100, 99, 205, 100, 53, 99, 11, 10, 100, 99, 85, 99, 99, 249, 100, 100, 99, 0, 10, 72, 100, 43, 99, 100, 222, 100, 99, 0, 194, 100, 91, 68, 94, 84, 58, 100, 8, 99, 33, 146, 92, 100, 67, 126, 101, 100, 100, 99, 98, 100, 100, 101, 100, 74, 59, 100, 100, 100, 100, 122, 100, 101, 100, 99, 102, 64, 99, 43, 99, 129, 100, 99, 100, 99, 99, 100, 100, 225, 92, 99, 99, 99, 101, 78, 100, 100, 101, 100, 101, 99, 100, 99, 100, 99, 99, 73, 100, 99, 100, 83, 90, 100, 101, 80, 74, 91, 72, 81, 98, 99, 82, 82]
theorem node73066 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73066 support demand code
    entries73066 ((insert 59 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node73064 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154))
    59 node73065 node73066
theorem node73059 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 46 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154))
    69 node73063 node73064
def entries73061 : List (Fin 2295 × ℕ) := [(4, 80), (37, 33), (43, 26), (72, 96), (135, 29), (148, 41), (307, 20), (342, 56), (438, 17), (469, 5), (471, 46), (507, 47), (514, 39), (532, 98), (570, 19), (571, 11), (588, 16), (631, 26), (639, 29), (731, 11), (736, 21), (737, 6), (812, 24), (813, 112), (816, 26), (817, 51), (844, 62), (847, 29), (855, 81), (867, 42), (872, 139), (874, 19), (886, 28), (888, 28), (920, 88), (933, 26), (934, 40), (938, 110), (942, 12), (944, 124), (970, 41), (972, 14), (973, 139), (985, 52), (1008, 38), (1011, 21), (1025, 46), (1027, 22), (1033, 10), (1035, 1), (1099, 4), (1100, 13), (1101, 7), (1102, 61), (1103, 53), (1104, 7), (1123, 46), (1131, 24), (1133, 59), (1157, 5), (1158, 10), (1169, 81), (1173, 35), (1175, 21), (1183, 2), (1186, 19), (1193, 33), (1234, 42), (1258, 77), (1261, 9), (1275, 8), (1281, 61), (1293, 4), (1342, 38), (1500, 14), (1618, 32), (1667, 12), (1675, 21), (1690, 30), (1701, 26), (1861, 53), (2000, 6), (2225, 2)]
def cs73061 : List ℕ := [209, 85, 136, 114, 113, 114, 26, 256, 146, 79, 251, 119, 257, 256, 256, 0, 256, 201, 629, 113, 257, 47, 16, 256, 191, 667, 257, 275, 96, 73, 233, 255, 148, 256, 85, 257, 0, 257, 245, 255, 97, 256, 256, 257, 574, 257, 0, 256, 167, 167, 256, 256, 171, 256, 257, 588, 256, 255, 256, 256, 28, 225, 256, 172, 245, 257, 470, 256, 256, 257, 398, 255, 256, 255, 183, 228, 114, 230, 37, 255, 201, 467, 250, 254, 253, 255, 257, 256, 255, 163, 256, 256, 256, 254, 226, 181, 166, 431, 256, 255, 256, 313, 254, 255, 130, 255, 254, 255, 256, 45, 255, 272, 255, 255, 255, 256, 254, 256, 255, 514, 255, 255, 256, 255, 255, 255, 257, 255, 255, 254, 189, 256, 254, 255, 255, 255, 256, 222, 255, 256, 255, 190, 224, 255, 186, 223, 255, 239, 256, 234, 211, 256, 235, 168]
theorem node73061 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73061 support demand code
    entries73061 ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 97 (insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries73062 : List (Fin 2295 × ℕ) := [(4, 31), (37, 42), (43, 29), (137, 6), (307, 8), (342, 18), (469, 22), (471, 15), (484, 8), (507, 24), (514, 15), (532, 46), (570, 25), (571, 6), (588, 8), (617, 14), (631, 1), (639, 24), (640, 3), (680, 2), (681, 8), (730, 15), (741, 2), (814, 22), (815, 9), (816, 12), (844, 17), (855, 29), (867, 22), (872, 54), (886, 9), (920, 18), (921, 14), (931, 10), (932, 15), (933, 9), (934, 11), (936, 16), (938, 11), (942, 18), (944, 37), (970, 25), (973, 52), (985, 3), (1010, 18), (1025, 28), (1037, 3), (1061, 7), (1076, 3), (1095, 6), (1096, 21), (1100, 7), (1122, 8), (1123, 31), (1133, 17), (1158, 1), (1167, 6), (1169, 21), (1171, 8), (1173, 10), (1175, 2), (1186, 21), (1193, 17), (1226, 7), (1234, 4), (1258, 4), (1269, 3), (1281, 29), (1295, 6), (1342, 18), (1354, 4), (1370, 14), (1399, 4), (1618, 6), (1619, 4), (1670, 10), (1675, 23), (1690, 3), (1701, 2), (1846, 6), (1848, 11), (1861, 17)]
def cs73062 : List ℕ := [80, 53, 44, 46, 48, 79, 29, 100, 90, 34, 77, 68, 100, 100, 100, 0, 99, 100, 279, 48, 100, 52, 8, 100, 100, 228, 100, 120, 0, 53, 99, 100, 67, 100, 12, 99, 0, 100, 87, 100, 65, 100, 101, 99, 191, 100, 0, 100, 67, 78, 101, 99, 57, 99, 101, 230, 100, 99, 100, 100, 9, 100, 100, 69, 67, 100, 160, 99, 101, 100, 154, 101, 99, 100, 93, 81, 29, 98, 43, 100, 89, 160, 86, 101, 100, 99, 99, 99, 101, 81, 100, 82, 101, 99, 93, 99, 96, 8, 100, 100, 101, 114, 100, 100, 89, 99, 99, 99, 101, 39, 99, 101, 99, 93, 99, 100, 99, 101, 101, 127, 100, 100, 101, 99, 100, 97, 86, 100, 99, 100, 94, 100, 100, 100, 80, 74, 101, 85, 100, 101, 99, 87, 100, 101, 95, 85, 86, 100, 82, 95, 97, 93, 90, 83]
theorem node73062 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 97 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73062 support demand code
    entries73062 ((insert 97 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node73060 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154))
    97 node73061 node73062
theorem node73053 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154))
    46 node73059 node73060
def entries73057 : List (Fin 2295 × ℕ) := [(37, 358), (43, 17), (72, 152), (137, 299), (342, 85), (360, 2), (438, 72), (469, 115), (507, 162), (532, 570), (572, 85), (585, 299), (588, 2), (617, 53), (639, 38), (730, 56), (731, 579), (739, 23), (797, 84), (817, 296), (844, 175), (847, 163), (852, 46), (855, 267), (865, 149), (867, 69), (870, 80), (872, 430), (885, 96), (886, 4), (888, 107), (890, 253), (913, 48), (920, 426), (921, 14), (929, 211), (932, 7), (934, 204), (944, 280), (969, 222), (970, 45), (972, 126), (973, 448), (985, 315), (1008, 228), (1025, 238), (1027, 61), (1061, 89), (1072, 21), (1073, 367), (1095, 28), (1099, 104), (1101, 39), (1102, 133), (1104, 124), (1108, 56), (1123, 82), (1126, 113), (1128, 21), (1133, 305), (1139, 145), (1158, 92), (1167, 317), (1174, 119), (1175, 24), (1183, 175), (1186, 67), (1193, 149), (1223, 256), (1227, 49), (1258, 98), (1261, 58), (1275, 65), (1313, 57), (1354, 62), (1370, 11), (1393, 63), (1443, 39), (1605, 96), (1626, 34), (1629, 106), (1675, 285), (1717, 23), (1861, 239), (1866, 6), (1887, 44), (2225, 31)]
def cs73057 : List ℕ := [882, 115, 163, 302, 508, 682, 23, 1000, 820, 162, 1000, 696, 1000, 1000, 660, 63, 1000, 801, 2009, 573, 1000, 1000, 36, 1000, 340, 2650, 1000, 1545, 215, 407, 1000, 1000, 549, 1000, 306, 1000, 63, 1000, 827, 1000, 681, 425, 749, 1000, 2846, 1000, 1000, 1000, 756, 252, 1000, 1000, 838, 1000, 1001, 2169, 1000, 1000, 1002, 1000, 4, 1001, 1000, 553, 1000, 1000, 2081, 1000, 1000, 1412, 1181, 176, 1001, 1623, 1000, 999, 682, 969, 393, 1000, 1001, 0, 1000, 999, 1001, 1000, 945, 1001, 1001, 938, 1000, 1001, 502, 999, 1002, 920, 665, 1000, 1001, 1001, 1000, 1203, 1000, 671, 1001, 1001, 1001, 1000, 988, 193, 1001, 1001, 1001, 1002, 1000, 1001, 1001, 1000, 1001, 2282, 1000, 1003, 1001, 937, 1001, 765, 1000, 1001, 1000, 1002, 933, 1000, 1002, 1001, 1001, 1001, 921, 796, 1001, 1001, 1000, 803, 971, 1001, 1002, 975, 914, 1001, 1000, 655, 946, 1001, 657, 755]
theorem node73057 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 73 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73057 support demand code
    entries73057 ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 73 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries73058 : List (Fin 2295 × ℕ) := [(4, 86), (37, 344), (72, 349), (92, 94), (95, 71), (135, 94), (137, 6), (342, 311), (438, 118), (469, 34), (471, 82), (479, 85), (507, 477), (514, 152), (532, 452), (587, 189), (629, 23), (631, 184), (681, 3), (710, 336), (797, 271), (798, 7), (817, 40), (844, 51), (852, 196), (865, 151), (872, 383), (885, 133), (886, 176), (890, 383), (913, 55), (920, 104), (934, 279), (938, 135), (944, 113), (969, 142), (972, 84), (973, 507), (985, 348), (1008, 66), (1010, 45), (1024, 3), (1025, 142), (1027, 200), (1061, 68), (1072, 1), (1073, 431), (1075, 64), (1095, 16), (1099, 118), (1102, 59), (1104, 154), (1123, 28), (1126, 27), (1131, 23), (1133, 275), (1139, 101), (1153, 22), (1158, 28), (1167, 234), (1174, 182), (1175, 1), (1183, 252), (1186, 99), (1191, 103), (1193, 76), (1219, 2), (1223, 103), (1258, 58), (1261, 86), (1263, 138), (1275, 75), (1281, 155), (1307, 7), (1313, 150), (1370, 130), (1629, 89), (1634, 93), (1675, 235), (1728, 112), (1767, 290), (1887, 32), (2225, 7)]
def cs73058 : List ℕ := [928, 122, 527, 707, 799, 604, 7, 998, 1000, 477, 976, 294, 999, 1000, 999, 0, 999, 999, 2300, 344, 1000, 756, 189, 998, 755, 2681, 1000, 1586, 349, 497, 999, 699, 755, 999, 578, 999, 0, 1000, 789, 999, 508, 999, 1000, 999, 2709, 1001, 999, 999, 0, 455, 1001, 840, 999, 999, 1000, 2557, 1000, 1000, 999, 999, 176, 477, 1000, 320, 742, 818, 2004, 1000, 1000, 0, 1479, 548, 806, 876, 1000, 1000, 647, 1000, 345, 1000, 96, 135, 1000, 999, 582, 1000, 1000, 1000, 1001, 1000, 1000, 999, 279, 959, 999, 945, 675, 1000, 1000, 1000, 1001, 1128, 1000, 825, 805, 1001, 999, 912, 1000, 183, 1000, 1000, 808, 1001, 821, 1001, 1000, 1001, 1000, 2149, 412, 1000, 1001, 1001, 1000, 741, 1000, 999, 999, 1001, 1001, 1000, 1000, 1000, 1000, 1002, 860, 812, 1000, 1000, 1000, 856, 1000, 1000, 1000, 999, 1000, 979, 1000, 811, 970, 985, 718, 933]
theorem node73058 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 73 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73058 support demand code
    entries73058 ((insert 69 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 73 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node73055 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 73 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 73 (insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154))
    69 node73057 node73058
def entries73056 : List (Fin 2295 × ℕ) := [(4, 11), (37, 6), (70, 7), (72, 31), (75, 17), (137, 24), (349, 6), (361, 21), (469, 18), (471, 11), (491, 4), (507, 31), (532, 49), (572, 20), (588, 10), (681, 18), (737, 14), (776, 16), (777, 22), (797, 35), (798, 1), (817, 22), (833, 5), (844, 12), (852, 1), (855, 25), (857, 5), (865, 21), (872, 51), (885, 14), (886, 16), (890, 31), (896, 41), (920, 26), (921, 32), (932, 11), (934, 20), (944, 42), (965, 3), (972, 32), (973, 54), (985, 20), (1008, 15), (1010, 13), (1025, 32), (1072, 8), (1073, 12), (1095, 17), (1099, 6), (1100, 1), (1122, 2), (1123, 22), (1126, 19), (1133, 33), (1157, 5), (1158, 1), (1167, 19), (1174, 8), (1183, 19), (1186, 4), (1193, 25), (1223, 28), (1251, 3), (1258, 20), (1275, 1), (1298, 11), (1313, 4), (1675, 5), (1728, 1), (1861, 7), (1866, 23), (2055, 2)]
def cs73056 : List ℕ := [99, 29, 11, 34, 69, 35, 32, 100, 74, 31, 88, 80, 99, 100, 100, 0, 100, 99, 219, 26, 100, 101, 10, 99, 60, 261, 100, 161, 31, 29, 100, 87, 71, 100, 8, 100, 0, 99, 55, 101, 75, 37, 61, 99, 320, 99, 101, 77, 21, 93, 99, 99, 26, 86, 100, 212, 83, 100, 100, 100, 16, 51, 101, 45, 95, 99, 168, 101, 100, 100, 108, 63, 100, 0, 101, 75, 30, 99, 33, 101, 97, 0, 99, 84, 60, 101, 100, 100, 100, 99, 99, 99, 65, 97, 101, 79, 45, 99, 101, 99, 100, 126, 84, 83, 79, 100, 100, 69, 100, 36, 99, 106, 100, 91, 64, 100, 99, 100, 100, 186, 92, 101, 100, 99, 99, 73, 100, 100, 100, 100, 98, 100, 100, 100, 80, 54, 100, 73, 100, 100, 95, 100, 95, 99, 99, 69, 90, 97, 101, 71, 99, 96, 81, 78]
theorem node73056 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 73 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73056 support demand code
    entries73056 ((insert 73 (insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node73054 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154))
    73 node73055 node73056
theorem node73021 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154))
    81 node73053 node73054
def entries73047 : List (Fin 2295 × ℕ) := [(890, 1)]
def cs73047 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node73047 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73047 support demand code
    entries73047 ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 57 (insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries73049 : List (Fin 2295 × ℕ) := [(890, 1)]
def cs73049 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node73049 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 85 (insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73049 support demand code
    entries73049 ((insert 57 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 85 (insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries73051 : List (Fin 2295 × ℕ) := [(35, 39), (37, 6), (72, 33), (75, 19), (137, 19), (157, 52), (342, 18), (468, 26), (572, 42), (581, 10), (585, 21), (587, 2), (588, 49), (617, 22), (629, 7), (736, 1), (739, 2), (741, 20), (743, 8), (813, 16), (814, 2), (815, 8), (816, 18), (817, 7), (819, 15), (844, 35), (852, 10), (856, 17), (858, 16), (867, 16), (870, 1), (885, 32), (888, 2), (913, 9), (920, 52), (921, 11), (934, 23), (936, 1), (938, 38), (944, 30), (959, 10), (969, 24), (970, 10), (972, 3), (973, 35), (985, 24), (1008, 4), (1010, 41), (1025, 35), (1027, 30), (1036, 3), (1037, 18), (1095, 7), (1099, 7), (1100, 1), (1101, 6), (1103, 16), (1104, 16), (1108, 18), (1123, 22), (1126, 8), (1128, 6), (1133, 15), (1154, 14), (1157, 24), (1173, 6), (1193, 41), (1198, 5), (1201, 1), (1223, 7), (1226, 17), (1251, 13), (1258, 33), (1308, 11), (1370, 8), (1604, 16), (1701, 5), (1845, 1), (1848, 13), (2225, 6)]
def cs73051 : List ℕ := [88, 27, 16, 5, 64, 63, 16, 94, 99, 0, 73, 34, 85, 45, 99, 0, 100, 99, 0, 66, 100, 108, 51, 99, 16, 287, 99, 115, 49, 79, 101, 100, 51, 99, 7, 99, 16, 99, 39, 101, 100, 100, 99, 100, 189, 100, 116, 84, 17, 58, 100, 100, 65, 92, 99, 174, 99, 0, 84, 100, 17, 100, 95, 37, 99, 99, 80, 99, 100, 100, 119, 101, 78, 99, 99, 99, 45, 99, 6, 101, 99, 220, 100, 100, 87, 6, 100, 101, 100, 100, 100, 100, 192, 99, 99, 100, 34, 100, 99, 99, 101, 151, 100, 95, 88, 101, 100, 90, 101, 3, 100, 100, 100, 101, 100, 100, 101, 99, 101, 256, 91, 101, 100, 92, 100, 41, 100, 100, 84, 101, 100, 100, 102, 100, 102, 100, 100, 42, 102, 101, 101, 101, 67, 100, 100, 69, 80, 61, 97, 71, 90, 63, 95, 35]
theorem node73051 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 85 (insert 57 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73051 support demand code
    entries73051 ((insert 85 (insert 57 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries73052 : List (Fin 2295 × ℕ) := [(35, 91), (72, 38), (75, 36), (137, 107), (157, 44), (342, 3), (479, 38), (491, 75), (571, 101), (581, 2), (585, 25), (587, 8), (588, 102), (629, 50), (730, 66), (731, 9), (743, 49), (816, 9), (817, 35), (844, 123), (852, 32), (856, 69), (885, 75), (913, 20), (917, 3), (919, 29), (920, 117), (921, 32), (938, 76), (944, 68), (969, 65), (973, 123), (978, 57), (985, 34), (1024, 35), (1025, 78), (1027, 65), (1072, 1), (1073, 74), (1075, 20), (1095, 13), (1099, 19), (1101, 13), (1123, 9), (1126, 62), (1128, 18), (1133, 83), (1138, 8), (1139, 8), (1154, 24), (1157, 3), (1174, 30), (1175, 23), (1179, 1), (1183, 93), (1186, 3), (1193, 43), (1223, 58), (1251, 7), (1258, 2), (1323, 12), (1354, 8), (1370, 58), (1403, 29), (1703, 5), (1704, 25), (1886, 4), (1887, 35), (1888, 6), (2017, 27), (2225, 14)]
def cs73052 : List ℕ := [224, 0, 0, 0, 175, 187, 75, 255, 225, 0, 101, 133, 256, 118, 144, 0, 240, 223, 0, 111, 256, 144, 167, 256, 0, 643, 180, 156, 38, 254, 256, 256, 110, 256, 53, 239, 0, 255, 95, 256, 256, 256, 256, 257, 368, 256, 209, 249, 132, 64, 256, 256, 216, 153, 256, 324, 257, 0, 255, 255, 98, 188, 247, 110, 200, 244, 108, 255, 256, 257, 298, 35, 207, 256, 256, 169, 164, 256, 93, 256, 75, 338, 256, 256, 237, 1, 242, 256, 257, 256, 256, 257, 0, 224, 256, 256, 146, 256, 256, 256, 255, 288, 196, 256, 255, 257, 205, 200, 255, 4, 257, 270, 257, 256, 256, 255, 255, 256, 256, 582, 80, 255, 254, 244, 256, 123, 257, 256, 256, 254, 256, 214, 255, 256, 254, 255, 257, 158, 255, 255, 255, 238, 237, 255, 255, 256, 256, 188, 256, 189, 255, 251, 195, 219]
theorem node73052 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 85 (insert 57 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73052 support demand code
    entries73052 ((insert 92 (insert 85 (insert 57 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))))) : Finset (Fin 154)) ((insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node73050 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 85 (insert 57 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 85 (insert 57 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154))
    92 node73051 node73052
theorem node73048 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 57 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154))
    85 node73049 node73050
theorem node73041 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154))
    57 node73047 node73048
def entries73045 : List (Fin 2295 × ℕ) := [(890, 1)]
def cs73045 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node73045 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 85 (insert 57 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73045 support demand code
    entries73045 ((insert 21 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 85 (insert 57 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries73046 : List (Fin 2295 × ℕ) := [(4, 15), (35, 55), (72, 32), (137, 9), (342, 6), (468, 24), (479, 21), (491, 15), (498, 10), (542, 1), (588, 31), (617, 3), (619, 13), (620, 21), (729, 6), (743, 38), (813, 17), (815, 10), (844, 31), (852, 25), (865, 8), (867, 21), (883, 9), (885, 10), (886, 26), (888, 21), (898, 5), (913, 2), (914, 7), (917, 3), (920, 49), (921, 28), (930, 1), (938, 23), (944, 45), (959, 1), (960, 12), (965, 1), (966, 11), (969, 7), (970, 12), (973, 46), (982, 1), (985, 34), (1010, 19), (1025, 28), (1027, 6), (1037, 11), (1095, 21), (1101, 1), (1102, 4), (1103, 19), (1104, 8), (1108, 19), (1123, 23), (1127, 7), (1128, 11), (1133, 37), (1157, 11), (1158, 3), (1169, 9), (1171, 1), (1174, 12), (1183, 14), (1186, 4), (1193, 19), (1234, 47), (1258, 20), (1308, 3), (1342, 2), (1354, 3), (1370, 14), (1433, 7), (1443, 5), (1625, 11), (1646, 14), (1703, 1), (1848, 1), (2042, 6), (2225, 7)]
def cs73046 : List ℕ := [50, 39, 0, 0, 80, 55, 15, 101, 99, 0, 61, 39, 71, 55, 67, 0, 78, 65, 0, 35, 100, 0, 37, 99, 1, 279, 44, 84, 32, 76, 100, 101, 31, 100, 12, 100, 0, 100, 83, 100, 30, 99, 97, 100, 145, 101, 87, 101, 64, 58, 99, 100, 33, 99, 101, 121, 101, 113, 101, 101, 26, 87, 100, 77, 84, 99, 69, 99, 100, 100, 131, 93, 100, 100, 100, 63, 60, 100, 28, 100, 101, 166, 100, 100, 101, 10, 98, 101, 99, 99, 101, 100, 99, 99, 100, 94, 53, 99, 100, 100, 100, 99, 60, 99, 100, 99, 100, 100, 100, 4, 100, 109, 100, 100, 100, 100, 99, 100, 100, 211, 99, 100, 100, 100, 100, 56, 100, 100, 100, 99, 89, 100, 100, 100, 100, 99, 101, 62, 100, 101, 100, 93, 77, 100, 86, 79, 100, 78, 96, 85, 91, 90, 70, 64]
theorem node73046 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 85 (insert 21 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73046 support demand code
    entries73046 ((insert 85 (insert 21 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 57 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node73043 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 57 (insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154))
    85 node73045 node73046
def entries73044 : List (Fin 2295 × ℕ) := [(35, 80), (37, 56), (137, 59), (342, 69), (468, 162), (491, 12), (571, 66), (572, 76), (587, 10), (588, 81), (619, 83), (640, 7), (642, 61), (731, 57), (739, 6), (741, 16), (743, 16), (797, 32), (798, 20), (813, 14), (816, 3), (817, 68), (844, 23), (852, 66), (856, 66), (867, 36), (870, 5), (885, 36), (888, 49), (898, 20), (913, 38), (920, 77), (921, 31), (934, 28), (936, 17), (938, 90), (940, 16), (942, 30), (944, 85), (965, 11), (973, 124), (978, 13), (982, 12), (985, 46), (1008, 47), (1010, 26), (1025, 33), (1035, 22), (1037, 7), (1046, 21), (1048, 9), (1061, 3), (1095, 15), (1096, 26), (1102, 33), (1103, 56), (1104, 40), (1108, 32), (1123, 34), (1133, 95), (1154, 20), (1157, 1), (1158, 8), (1169, 51), (1171, 81), (1179, 35), (1193, 36), (1226, 13), (1251, 4), (1258, 26), (1308, 15), (1344, 22), (1354, 20), (1370, 11), (1403, 7), (1500, 25), (1517, 24), (1616, 71), (1701, 11), (1845, 5), (2088, 11)]
def cs73044 : List ℕ := [59, 162, 0, 0, 102, 202, 36, 251, 172, 0, 36, 203, 251, 80, 36, 11, 257, 101, 0, 247, 257, 0, 111, 257, 23, 570, 257, 166, 11, 118, 257, 180, 126, 257, 0, 257, 11, 221, 56, 257, 240, 257, 257, 257, 370, 257, 160, 215, 106, 88, 257, 257, 81, 256, 257, 418, 256, 0, 255, 256, 66, 255, 257, 150, 224, 257, 378, 256, 257, 255, 337, 161, 198, 256, 257, 258, 122, 257, 92, 257, 231, 448, 256, 257, 256, 258, 257, 256, 255, 258, 256, 256, 255, 256, 255, 257, 137, 256, 255, 256, 256, 297, 252, 256, 248, 256, 255, 248, 256, 65, 256, 314, 256, 257, 256, 256, 258, 256, 256, 538, 255, 256, 256, 257, 256, 256, 255, 256, 257, 258, 242, 231, 256, 255, 257, 256, 256, 215, 255, 255, 256, 256, 179, 256, 247, 256, 248, 207, 202, 206, 227, 231, 209, 195]
theorem node73044 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 21 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73044 support demand code
    entries73044 ((insert 57 (insert 21 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node73042 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154))
    57 node73043 node73044
theorem node73033 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 81 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154))
    21 node73041 node73042
def entries73037 : List (Fin 2295 × ℕ) := [(890, 1)]
def cs73037 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node73037 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 21 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73037 support demand code
    entries73037 ((insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 57 (insert 21 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries73039 : List (Fin 2295 × ℕ) := [(890, 1)]
def cs73039 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node73039 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 85 (insert 21 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73039 support demand code
    entries73039 ((insert 57 (insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 85 (insert 21 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries73040 : List (Fin 2295 × ℕ) := [(35, 163), (37, 286), (70, 209), (75, 150), (137, 259), (360, 75), (468, 190), (490, 272), (491, 14), (512, 14), (572, 455), (585, 456), (587, 68), (588, 355), (617, 180), (710, 83), (730, 149), (731, 119), (776, 15), (797, 72), (817, 414), (843, 5), (844, 223), (852, 226), (856, 134), (885, 352), (888, 7), (896, 186), (913, 121), (920, 356), (921, 188), (932, 20), (934, 266), (938, 61), (944, 368), (966, 15), (969, 207), (972, 43), (973, 354), (978, 103), (985, 166), (1008, 42), (1010, 161), (1024, 85), (1025, 395), (1027, 354), (1072, 74), (1073, 159), (1075, 21), (1099, 73), (1102, 2), (1103, 80), (1108, 75), (1123, 156), (1126, 341), (1131, 7), (1133, 310), (1153, 18), (1154, 59), (1157, 214), (1158, 35), (1174, 1), (1179, 166), (1183, 288), (1186, 20), (1193, 377), (1198, 42), (1258, 182), (1293, 19), (1443, 141), (1486, 60), (1495, 53), (1517, 104), (1657, 132), (1675, 90), (1887, 9), (2225, 35)]
def cs73040 : List ℕ := [774, 322, 0, 42, 777, 583, 390, 771, 1000, 0, 558, 712, 679, 205, 1000, 53, 1000, 981, 0, 748, 1002, 1133, 423, 1000, 53, 2583, 776, 1099, 0, 775, 1001, 1000, 866, 1000, 1, 1000, 53, 1001, 286, 1000, 1000, 1001, 948, 1001, 1160, 1000, 1000, 731, 343, 474, 939, 1000, 710, 816, 1000, 1199, 1000, 0, 902, 1000, 134, 723, 1000, 327, 1001, 1000, 593, 1000, 999, 1000, 500, 188, 1000, 999, 1000, 1000, 416, 1000, 323, 999, 1000, 61, 1000, 1000, 666, 166, 1000, 1001, 1000, 999, 999, 1000, 928, 1000, 1001, 655, 417, 1002, 1000, 1001, 999, 1391, 1001, 260, 991, 1000, 1001, 875, 1001, 229, 965, 1000, 1002, 1000, 868, 1000, 1000, 1000, 934, 2423, 186, 1000, 999, 999, 1001, 354, 1000, 998, 999, 999, 1000, 850, 999, 1000, 998, 1001, 999, 576, 1000, 999, 1000, 891, 677, 999, 1000, 803, 1000, 790, 1000, 596, 999, 719, 808, 662]
theorem node73040 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 85 (insert 57 (insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73040 support demand code
    entries73040 ((insert 85 (insert 57 (insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node73038 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 57 (insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154))
    85 node73039 node73040
theorem node73035 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154))
    57 node73037 node73038
def entries73036 : List (Fin 2295 × ℕ) := [(4, 2), (35, 132), (37, 4), (130, 6), (137, 60), (344, 2), (439, 4), (468, 35), (479, 89), (572, 36), (588, 23), (617, 11), (621, 12), (731, 16), (797, 11), (816, 20), (817, 48), (844, 72), (860, 44), (865, 53), (883, 3), (885, 64), (888, 37), (890, 70), (913, 61), (917, 13), (920, 93), (921, 15), (929, 16), (934, 31), (944, 99), (965, 26), (969, 43), (970, 2), (972, 29), (973, 117), (985, 62), (1008, 35), (1011, 2), (1025, 37), (1027, 27), (1034, 6), (1061, 28), (1076, 4), (1096, 17), (1100, 16), (1101, 13), (1102, 16), (1103, 17), (1104, 22), (1108, 14), (1123, 47), (1126, 14), (1133, 80), (1157, 1), (1158, 10), (1169, 84), (1171, 4), (1173, 43), (1174, 11), (1175, 34), (1179, 56), (1183, 25), (1193, 34), (1234, 56), (1254, 16), (1258, 26), (1269, 5), (1316, 8), (1323, 16), (1342, 46), (1370, 28), (1443, 18), (1517, 65), (1616, 25), (1667, 1), (1690, 12), (1703, 10), (1717, 40), (1728, 4), (1744, 2), (1864, 14), (2048, 7), (2166, 3)]
def cs73036 : List ℕ := [106, 53, 0, 0, 141, 136, 79, 212, 232, 0, 53, 130, 167, 132, 50, 0, 184, 173, 0, 117, 255, 70, 33, 256, 3, 580, 140, 214, 0, 257, 255, 216, 102, 256, 91, 257, 16, 256, 186, 256, 256, 257, 124, 256, 458, 257, 229, 256, 182, 78, 199, 256, 60, 256, 257, 483, 219, 256, 256, 257, 0, 208, 256, 256, 256, 256, 230, 257, 256, 214, 163, 31, 227, 256, 257, 205, 145, 256, 114, 256, 256, 0, 256, 257, 256, 257, 203, 256, 256, 256, 257, 257, 155, 256, 257, 209, 176, 255, 258, 257, 257, 297, 256, 257, 257, 256, 257, 257, 257, 93, 257, 263, 256, 256, 257, 257, 257, 257, 257, 466, 215, 256, 257, 257, 257, 248, 257, 257, 257, 257, 258, 257, 257, 256, 254, 256, 257, 257, 257, 257, 257, 252, 235, 258, 257, 258, 256, 233, 257, 193, 257, 257, 212, 167]
theorem node73036 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73036 support demand code
    entries73036 ((insert 21 (insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node73034 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154))
    21 node73035 node73036
theorem node73023 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154))
    81 node73033 node73034
def entries73031 : List (Fin 2295 × ℕ) := [(4, 9), (35, 74), (46, 17), (72, 95), (75, 13), (137, 4), (148, 61), (342, 43), (468, 69), (498, 65), (588, 82), (617, 40), (690, 1), (692, 19), (729, 27), (739, 9), (741, 79), (743, 5), (813, 31), (815, 25), (816, 13), (817, 53), (844, 122), (865, 35), (867, 31), (872, 3), (885, 61), (886, 5), (888, 47), (890, 187), (898, 2), (913, 41), (914, 32), (918, 9), (920, 120), (921, 14), (930, 11), (934, 65), (938, 45), (944, 130), (959, 4), (960, 49), (969, 41), (970, 9), (973, 127), (985, 48), (1010, 74), (1011, 11), (1025, 31), (1027, 40), (1037, 73), (1043, 1), (1096, 35), (1100, 20), (1101, 19), (1102, 8), (1103, 15), (1104, 80), (1108, 37), (1123, 21), (1131, 25), (1133, 55), (1157, 30), (1158, 5), (1169, 17), (1173, 49), (1174, 2), (1183, 19), (1186, 13), (1193, 69), (1198, 40), (1234, 41), (1258, 24), (1275, 55), (1308, 29), (1528, 4), (1562, 15), (1625, 32), (1640, 39), (1690, 34), (1701, 32), (1717, 1), (1848, 6), (2225, 5)]
def cs73031 : List ℕ := [231, 78, 0, 40, 118, 74, 17, 191, 257, 0, 214, 69, 256, 117, 243, 0, 139, 257, 3, 109, 257, 257, 84, 256, 0, 623, 188, 253, 95, 250, 257, 175, 82, 257, 51, 256, 0, 256, 197, 256, 70, 257, 255, 256, 507, 257, 187, 254, 130, 125, 257, 255, 106, 231, 255, 546, 255, 448, 255, 255, 5, 256, 256, 138, 255, 256, 453, 256, 256, 255, 556, 257, 216, 255, 178, 254, 102, 255, 79, 257, 255, 513, 255, 256, 255, 256, 256, 255, 255, 255, 256, 255, 412, 255, 255, 232, 121, 254, 256, 256, 256, 327, 255, 256, 248, 254, 255, 255, 255, 13, 255, 255, 255, 254, 256, 255, 256, 255, 255, 595, 256, 219, 254, 203, 256, 193, 255, 255, 256, 255, 191, 255, 256, 255, 256, 256, 249, 149, 256, 255, 255, 237, 174, 256, 143, 255, 255, 194, 255, 246, 233, 255, 164, 214]
theorem node73031 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 92 (insert 81 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73031 support demand code
    entries73031 ((insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 57 (insert 92 (insert 81 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries73032 : List (Fin 2295 × ℕ) := [(4, 50), (35, 84), (37, 28), (46, 44), (72, 43), (137, 34), (148, 77), (342, 61), (468, 111), (491, 29), (571, 28), (572, 75), (588, 58), (617, 31), (629, 15), (631, 32), (639, 12), (642, 88), (730, 30), (739, 17), (741, 55), (742, 7), (797, 4), (798, 26), (813, 48), (814, 10), (815, 17), (816, 51), (817, 41), (844, 84), (865, 6), (867, 26), (885, 48), (888, 45), (898, 18), (913, 28), (920, 94), (921, 25), (934, 45), (938, 93), (940, 32), (944, 98), (969, 49), (970, 23), (973, 116), (985, 37), (1010, 59), (1011, 26), (1025, 6), (1027, 27), (1036, 4), (1037, 45), (1048, 26), (1096, 62), (1101, 51), (1103, 6), (1104, 49), (1108, 22), (1123, 32), (1133, 56), (1154, 22), (1158, 24), (1159, 23), (1169, 56), (1171, 4), (1173, 79), (1179, 2), (1188, 38), (1193, 61), (1226, 36), (1251, 23), (1258, 21), (1269, 15), (1275, 36), (1308, 33), (1370, 12), (1403, 15), (1596, 48), (1616, 4), (1674, 10), (1845, 19)]
def cs73032 : List ℕ := [145, 161, 48, 0, 159, 112, 83, 195, 223, 0, 123, 140, 195, 132, 256, 48, 193, 249, 0, 253, 256, 102, 76, 256, 0, 609, 256, 61, 91, 213, 255, 255, 58, 255, 127, 256, 0, 212, 119, 255, 182, 256, 256, 254, 449, 255, 0, 151, 104, 87, 256, 256, 191, 255, 256, 416, 257, 0, 255, 256, 0, 256, 256, 95, 174, 255, 440, 257, 256, 209, 396, 256, 212, 256, 204, 232, 121, 255, 83, 255, 255, 538, 255, 257, 255, 255, 256, 255, 256, 254, 256, 255, 444, 256, 256, 256, 170, 255, 257, 256, 257, 319, 224, 256, 255, 255, 257, 255, 256, 2, 255, 268, 257, 240, 257, 255, 257, 257, 255, 518, 256, 256, 256, 226, 257, 255, 255, 256, 256, 256, 222, 255, 256, 257, 256, 257, 255, 193, 257, 256, 257, 256, 210, 237, 171, 255, 256, 194, 248, 199, 243, 255, 222, 156]
theorem node73032 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 81 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73032 support demand code
    entries73032 ((insert 57 (insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 81 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node73029 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 81 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 81 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))))) : Finset (Fin 154))
    57 node73031 node73032
def entries73030 : List (Fin 2295 × ℕ) := [(4, 78), (37, 48), (70, 84), (135, 17), (137, 30), (148, 58), (342, 29), (468, 100), (491, 12), (498, 31), (571, 105), (587, 44), (588, 88), (639, 19), (642, 10), (681, 17), (690, 2), (692, 2), (729, 44), (731, 78), (741, 9), (743, 49), (777, 8), (816, 13), (817, 21), (844, 63), (862, 62), (867, 81), (885, 73), (890, 70), (913, 31), (920, 138), (921, 9), (930, 25), (931, 29), (933, 34), (938, 87), (944, 83), (969, 46), (970, 10), (973, 121), (978, 91), (985, 21), (1008, 70), (1010, 76), (1021, 1), (1025, 76), (1027, 39), (1061, 2), (1072, 11), (1073, 36), (1096, 11), (1102, 17), (1103, 29), (1104, 59), (1108, 11), (1126, 20), (1128, 30), (1133, 91), (1139, 25), (1154, 30), (1165, 9), (1171, 53), (1174, 5), (1179, 59), (1183, 16), (1258, 8), (1269, 12), (1354, 8), (1370, 46), (1596, 19), (1616, 42), (1623, 3), (1690, 6), (1701, 18), (2017, 38), (2225, 22)]
def cs73030 : List ℕ := [63, 178, 19, 0, 97, 86, 12, 163, 257, 0, 222, 112, 256, 57, 219, 19, 220, 241, 0, 211, 256, 211, 170, 256, 0, 614, 163, 163, 19, 153, 255, 214, 132, 256, 33, 256, 0, 256, 153, 255, 198, 257, 256, 256, 418, 257, 70, 255, 122, 93, 256, 256, 96, 256, 255, 480, 256, 255, 255, 255, 0, 189, 255, 82, 255, 256, 404, 256, 255, 255, 517, 30, 171, 255, 211, 225, 111, 255, 123, 255, 178, 430, 255, 255, 256, 255, 248, 255, 256, 255, 255, 256, 0, 255, 256, 256, 113, 255, 256, 255, 255, 397, 179, 256, 251, 256, 255, 255, 255, 59, 255, 271, 255, 255, 256, 255, 255, 256, 255, 630, 192, 255, 255, 196, 256, 175, 255, 256, 243, 255, 195, 202, 255, 255, 256, 255, 255, 202, 255, 256, 256, 249, 171, 255, 256, 256, 224, 152, 216, 209, 255, 212, 230, 179]
theorem node73030 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73030 support demand code
    entries73030 ((insert 92 (insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node73025 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154))
    92 node73029 node73030
def entries73027 : List (Fin 2295 × ℕ) := [(4, 92), (35, 83), (70, 17), (75, 12), (137, 13), (342, 86), (468, 70), (498, 80), (572, 62), (588, 27), (617, 19), (642, 68), (690, 17), (731, 15), (797, 19), (817, 13), (845, 30), (865, 101), (869, 30), (885, 71), (888, 59), (913, 53), (917, 49), (920, 89), (921, 49), (929, 75), (932, 29), (934, 52), (944, 63), (965, 11), (966, 3), (969, 39), (970, 8), (973, 121), (978, 50), (982, 19), (985, 43), (1008, 79), (1010, 65), (1024, 5), (1025, 24), (1027, 5), (1061, 15), (1076, 10), (1096, 20), (1102, 16), (1103, 45), (1104, 45), (1108, 29), (1123, 34), (1126, 5), (1133, 81), (1139, 12), (1158, 12), (1169, 46), (1170, 7), (1171, 80), (1179, 55), (1183, 11), (1234, 62), (1241, 8), (1251, 12), (1252, 2), (1258, 38), (1272, 15), (1316, 27), (1323, 4), (1354, 7), (1370, 63), (1443, 5), (1517, 54), (1616, 8), (1690, 18), (1717, 20)]
def cs73027 : List ℕ := [0, 192, 0, 0, 92, 83, 54, 100, 255, 0, 130, 154, 180, 83, 121, 0, 154, 256, 0, 141, 255, 29, 27, 255, 19, 595, 160, 155, 0, 185, 255, 255, 81, 255, 0, 240, 0, 255, 175, 446, 176, 254, 176, 256, 445, 256, 0, 255, 115, 198, 256, 255, 118, 257, 256, 428, 256, 255, 195, 255, 0, 177, 255, 213, 257, 257, 344, 255, 256, 190, 254, 117, 175, 256, 227, 209, 114, 255, 216, 255, 255, 0, 255, 255, 255, 256, 178, 256, 255, 256, 255, 256, 241, 250, 255, 198, 171, 255, 255, 256, 255, 366, 255, 255, 257, 255, 255, 256, 255, 82, 256, 280, 255, 255, 255, 256, 255, 256, 256, 540, 163, 213, 255, 243, 255, 254, 256, 255, 227, 255, 255, 256, 255, 254, 255, 255, 237, 229, 254, 255, 254, 256, 217, 255, 255, 253, 255, 208, 254, 207, 255, 230, 255, 148]
theorem node73027 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73027 support demand code
    entries73027 ((insert 81 (insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 39 (insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries73028 : List (Fin 2295 × ℕ) := [(4, 15), (35, 35), (37, 10), (75, 16), (86, 28), (307, 18), (438, 2), (468, 48), (491, 7), (498, 9), (572, 19), (588, 23), (617, 12), (639, 3), (737, 2), (797, 24), (817, 14), (843, 1), (845, 20), (852, 5), (858, 5), (862, 20), (865, 21), (885, 12), (886, 17), (888, 4), (898, 11), (914, 5), (920, 21), (932, 13), (934, 23), (944, 30), (958, 9), (969, 10), (972, 11), (973, 47), (978, 12), (985, 25), (1008, 23), (1010, 13), (1021, 2), (1025, 7), (1027, 15), (1034, 3), (1061, 13), (1070, 5), (1073, 13), (1095, 4), (1102, 2), (1103, 7), (1104, 9), (1108, 8), (1122, 2), (1123, 8), (1131, 10), (1133, 23), (1153, 4), (1169, 30), (1171, 10), (1173, 11), (1175, 10), (1179, 23), (1183, 22), (1234, 26), (1258, 3), (1323, 7), (1342, 7), (1370, 10), (1443, 7), (1616, 18), (1648, 3), (1675, 13), (1690, 1), (1717, 28)]
def cs73028 : List ℕ := [0, 83, 0, 0, 20, 45, 12, 73, 89, 0, 50, 83, 97, 35, 44, 0, 77, 80, 0, 61, 101, 29, 34, 100, 0, 224, 63, 33, 0, 97, 100, 49, 23, 100, 21, 97, 0, 100, 75, 33, 101, 100, 73, 100, 113, 100, 5, 99, 65, 73, 33, 100, 101, 101, 101, 149, 100, 99, 99, 85, 17, 84, 101, 62, 100, 101, 81, 100, 100, 70, 71, 0, 84, 95, 88, 101, 50, 100, 59, 100, 100, 0, 100, 101, 99, 101, 100, 100, 100, 100, 100, 100, 101, 100, 99, 93, 78, 100, 100, 100, 101, 140, 100, 99, 99, 100, 100, 100, 101, 34, 99, 100, 96, 100, 100, 101, 100, 100, 100, 193, 75, 99, 101, 100, 100, 100, 99, 100, 101, 101, 100, 100, 100, 100, 90, 100, 85, 100, 100, 100, 101, 100, 99, 100, 100, 100, 99, 85, 100, 85, 100, 87, 77, 87]
theorem node73028 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 81 (insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs73028 support demand code
    entries73028 ((insert 39 (insert 81 (insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))))) : Finset (Fin 154)) ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node73026 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))))) : Finset (Fin 154)) ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154))
    39 node73027 node73028
theorem node73024 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))))) : Finset (Fin 154)) ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154))
    81 node73025 node73026
theorem node73022 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))))) : Finset (Fin 154)) ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154))
    46 node73023 node73024
theorem node73020 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅)))))) : Finset (Fin 154)) ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154))
    18 node73021 node73022
theorem node72955 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 109 (insert 78 (insert 76 ∅))))) : Finset (Fin 154)) ((insert 70 (insert 55 (insert 27 (insert 25 (insert 66 (insert 119 (insert 44 ∅))))))) : Finset (Fin 154))
    60 node73019 node73020
#print axioms node72955
end OmissionResidualCover31Fused
