import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries77483 : List (Fin 2295 × ℕ) := [(162, 1)]
def cs77483 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node77483 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 105 (insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77483 support demand code
    entries77483 ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 105 (insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries77485 : List (Fin 2295 × ℕ) := [(164, 1)]
def cs77485 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node77485 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77485 support demand code
    entries77485 ((insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 95 (insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries77487 : List (Fin 2295 × ℕ) := [(892, 1)]
def cs77487 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node77487 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77487 support demand code
    entries77487 ((insert 95 (insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 55 (insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries77489 : List (Fin 2295 × ℕ) := [(896, 1)]
def cs77489 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node77489 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 95 (insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77489 support demand code
    entries77489 ((insert 55 (insert 95 (insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 88 (insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries77490 : List (Fin 2295 × ℕ) := [(23, 10), (46, 1), (179, 7), (181, 13), (275, 3), (506, 9), (571, 5), (581, 7), (585, 18), (588, 4), (617, 1), (678, 10), (681, 3), (737, 6), (741, 11), (742, 4), (777, 4), (779, 9), (819, 5), (834, 4), (835, 2), (846, 2), (860, 4), (873, 5), (888, 2), (894, 15), (917, 1), (919, 1), (926, 1), (933, 4), (942, 1), (943, 7), (946, 2), (956, 5), (962, 12), (964, 4), (971, 5), (972, 6), (973, 18), (978, 9), (1009, 6), (1011, 4), (1012, 1), (1069, 8), (1081, 1), (1107, 1), (1108, 2), (1110, 1), (1111, 2), (1114, 1), (1123, 7), (1138, 5), (1143, 1), (1161, 2), (1173, 3), (1178, 2), (1179, 2), (1184, 2), (1185, 4), (1186, 10), (1219, 2), (1223, 18), (1234, 4), (1268, 1), (1316, 1), (1345, 5), (1398, 2), (1517, 12), (1540, 2), (1545, 3), (1766, 3), (1773, 1), (1775, 5)]
def cs77490 : List ℕ := [18, 4, 0, 2, 28, 8, 19, 32, 30, 12, 0, 32, 32, 11, 7, 0, 28, 32, 37, 8, 32, 47, 24, 28, 17, 0, 31, 71, 0, 14, 32, 33, 32, 32, 7, 31, 0, 32, 24, 33, 10, 32, 17, 9, 67, 33, 62, 52, 13, 12, 32, 43, 33, 32, 31, 10, 33, 32, 32, 32, 31, 32, 33, 21, 10, 33, 9, 43, 33, 51, 27, 32, 26, 32, 31, 32, 38, 32, 23, 32, 16, 45, 32, 23, 33, 23, 32, 31, 3, 32, 32, 32, 32, 54, 33, 4, 29, 32, 32, 32, 32, 33, 32, 32, 20, 0, 32, 32, 33, 70, 30, 32, 32, 31, 27, 33, 34, 32, 33, 22, 32, 24, 31, 32, 32, 27, 33, 33, 22, 33, 26, 18, 34, 32, 33, 32, 29, 24, 33, 33, 32, 32, 26, 32, 32, 24, 29, 32, 33, 32, 33, 33, 33, 32]
theorem node77490 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 55 (insert 95 (insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77490 support demand code
    entries77490 ((insert 88 (insert 55 (insert 95 (insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
theorem node77488 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 95 (insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 95 (insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    88 node77489 node77490
theorem node77486 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 95 (insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    55 node77487 node77488
theorem node77484 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 105 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    95 node77485 node77486
theorem node77481 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 46 (insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    105 node77483 node77484
def entries77482 : List (Fin 2295 × ℕ) := [(23, 71), (46, 127), (181, 55), (275, 44), (307, 5), (490, 72), (506, 14), (588, 18), (617, 5), (639, 25), (640, 25), (678, 151), (738, 22), (741, 46), (742, 37), (777, 10), (782, 17), (834, 38), (835, 8), (851, 38), (858, 35), (859, 44), (873, 11), (874, 173), (888, 14), (896, 94), (899, 13), (900, 45), (926, 26), (933, 45), (934, 44), (943, 83), (944, 7), (946, 84), (954, 6), (956, 81), (962, 47), (964, 27), (971, 36), (972, 15), (973, 127), (978, 59), (1006, 3), (1009, 46), (1011, 32), (1012, 10), (1025, 31), (1043, 24), (1049, 5), (1055, 5), (1061, 2), (1069, 22), (1070, 2), (1073, 11), (1076, 20), (1108, 2), (1122, 9), (1123, 46), (1143, 6), (1155, 33), (1167, 33), (1173, 35), (1178, 28), (1179, 12), (1180, 2), (1186, 56), (1212, 38), (1234, 74), (1268, 65), (1277, 2), (1279, 132), (1316, 23), (1386, 27), (1398, 30), (1433, 27), (1459, 7), (1488, 15), (1517, 1), (1522, 8), (1545, 48), (1556, 12), (1623, 45), (1651, 6), (1705, 31), (1766, 51), (1853, 5), (1859, 14), (2061, 12)]
def cs77482 : List ℕ := [14, 132, 0, 0, 109, 211, 249, 255, 95, 71, 0, 219, 255, 257, 127, 0, 211, 255, 545, 79, 254, 221, 73, 255, 203, 0, 256, 425, 0, 127, 255, 256, 254, 256, 35, 257, 82, 254, 230, 255, 159, 255, 108, 157, 590, 207, 94, 474, 163, 256, 255, 424, 256, 256, 256, 257, 255, 257, 257, 256, 255, 257, 255, 257, 256, 257, 100, 529, 256, 656, 255, 257, 178, 257, 184, 256, 467, 226, 122, 256, 219, 570, 256, 256, 210, 228, 220, 256, 257, 252, 256, 230, 219, 704, 256, 257, 256, 257, 257, 255, 257, 282, 213, 256, 219, 257, 257, 255, 256, 551, 256, 256, 258, 256, 256, 256, 257, 256, 255, 201, 257, 256, 256, 257, 255, 256, 257, 257, 257, 256, 255, 160, 257, 255, 258, 256, 239, 207, 256, 256, 256, 256, 218, 256, 256, 211, 231, 256, 221, 256, 256, 257, 256, 256]
theorem node77482 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77482 support demand code
    entries77482 ((insert 46 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node77479 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 21 (insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    46 node77481 node77482
def entries77480 : List (Fin 2295 × ℕ) := [(83, 35), (181, 12), (275, 64), (307, 6), (469, 29), (506, 35), (617, 28), (619, 22), (621, 56), (629, 21), (631, 37), (678, 126), (737, 1), (739, 16), (742, 84), (780, 35), (819, 14), (834, 20), (835, 8), (846, 30), (851, 50), (852, 1), (857, 26), (858, 59), (869, 46), (873, 21), (874, 120), (896, 56), (897, 40), (899, 5), (900, 1), (902, 20), (926, 47), (933, 24), (934, 23), (943, 47), (946, 52), (956, 59), (962, 80), (963, 10), (964, 46), (971, 34), (972, 42), (973, 137), (978, 23), (1006, 6), (1009, 38), (1012, 13), (1025, 27), (1061, 17), (1069, 62), (1072, 12), (1076, 5), (1100, 14), (1114, 1), (1122, 13), (1123, 29), (1139, 27), (1155, 20), (1167, 38), (1173, 16), (1174, 5), (1175, 8), (1178, 30), (1179, 22), (1182, 11), (1183, 18), (1186, 70), (1212, 11), (1223, 96), (1234, 48), (1268, 12), (1279, 50), (1316, 5), (1349, 25), (1375, 16), (1386, 35), (1433, 30), (1488, 28), (1522, 29), (1545, 45), (1562, 17), (1585, 13), (1623, 31), (1651, 57), (1712, 9), (1766, 24), (2061, 20)]
def cs77480 : List ℕ := [96, 109, 0, 0, 147, 160, 85, 256, 120, 116, 0, 256, 256, 182, 25, 0, 256, 257, 407, 12, 256, 56, 52, 256, 195, 0, 256, 385, 0, 67, 256, 256, 256, 256, 59, 257, 50, 257, 200, 256, 65, 256, 47, 100, 523, 254, 256, 497, 117, 169, 256, 446, 206, 256, 256, 257, 256, 255, 257, 257, 257, 256, 256, 256, 202, 258, 68, 429, 256, 518, 184, 256, 197, 256, 255, 256, 397, 256, 132, 256, 175, 473, 256, 256, 256, 232, 203, 257, 256, 256, 256, 190, 213, 619, 257, 257, 192, 256, 256, 256, 256, 256, 210, 256, 210, 256, 256, 255, 255, 602, 229, 255, 256, 255, 256, 256, 257, 256, 255, 189, 256, 255, 255, 256, 256, 255, 256, 256, 238, 257, 256, 188, 257, 255, 256, 221, 255, 227, 256, 256, 256, 250, 236, 256, 255, 197, 228, 256, 256, 256, 255, 256, 256, 256]
theorem node77480 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77480 support demand code
    entries77480 ((insert 21 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node77477 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    21 node77479 node77480
def entries77478 : List (Fin 2295 × ℕ) := [(46, 254), (181, 97), (275, 208), (485, 91), (497, 50), (498, 140), (571, 146), (587, 133), (617, 268), (629, 128), (631, 132), (639, 32), (678, 482), (680, 41), (741, 29), (742, 294), (776, 73), (777, 149), (779, 200), (782, 68), (819, 118), (835, 117), (851, 92), (858, 139), (888, 40), (892, 479), (896, 207), (897, 45), (900, 91), (915, 196), (916, 22), (917, 133), (918, 319), (919, 45), (925, 98), (926, 236), (933, 81), (934, 91), (938, 16), (943, 140), (956, 276), (958, 51), (962, 389), (964, 232), (971, 60), (972, 177), (973, 543), (978, 187), (1006, 74), (1009, 184), (1012, 78), (1043, 167), (1061, 51), (1069, 145), (1073, 7), (1076, 6), (1096, 40), (1100, 57), (1113, 83), (1114, 132), (1122, 81), (1123, 64), (1139, 112), (1155, 3), (1167, 185), (1173, 9), (1174, 5), (1175, 57), (1178, 133), (1179, 94), (1183, 187), (1186, 268), (1223, 314), (1234, 242), (1247, 4), (1253, 312), (1316, 95), (1375, 39), (1386, 13), (1517, 235), (1545, 159), (1562, 3), (1585, 16), (1623, 34), (2061, 5), (2165, 93)]
def cs77478 : List ℕ := [626, 0, 0, 0, 718, 91, 628, 718, 909, 0, 0, 861, 1000, 0, 254, 0, 717, 1000, 0, 186, 1000, 940, 275, 1000, 0, 0, 999, 1060, 0, 607, 1000, 765, 1001, 999, 71, 1001, 404, 1002, 768, 1000, 318, 1002, 273, 499, 2609, 989, 1000, 1444, 245, 1000, 1001, 1496, 1000, 632, 1001, 1000, 1000, 1001, 1002, 1000, 1000, 1001, 1000, 1000, 949, 1000, 276, 2597, 1001, 1915, 1001, 1000, 909, 1001, 1000, 1000, 1314, 1000, 737, 1000, 775, 1961, 1000, 1000, 958, 829, 1001, 1000, 1000, 1001, 1000, 859, 1001, 2346, 999, 1000, 852, 1000, 1000, 1000, 1002, 1104, 774, 1000, 965, 1000, 1000, 999, 1001, 2321, 1000, 999, 1000, 840, 1000, 1001, 1000, 1000, 1000, 612, 1000, 815, 1000, 999, 1001, 1000, 1000, 1000, 924, 999, 1000, 790, 1000, 1000, 1001, 1000, 926, 955, 1000, 1001, 1001, 784, 960, 1000, 1000, 874, 923, 1000, 1001, 1000, 1000, 1001, 1000, 1001]
theorem node77478 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77478 support demand code
    entries77478 ((insert 18 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node77473 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 27 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    18 node77477 node77478
def entries77475 : List (Fin 2295 × ℕ) := [(46, 85), (181, 80), (275, 57), (381, 8), (466, 80), (506, 34), (528, 7), (587, 48), (629, 17), (631, 25), (678, 148), (680, 9), (681, 48), (741, 32), (742, 40), (776, 44), (777, 6), (779, 25), (782, 50), (834, 16), (835, 36), (851, 59), (869, 57), (874, 75), (878, 28), (892, 44), (896, 66), (911, 13), (915, 95), (917, 2), (918, 56), (919, 14), (926, 58), (933, 13), (934, 55), (936, 10), (943, 66), (944, 4), (946, 22), (954, 15), (956, 75), (958, 29), (961, 2), (962, 84), (964, 25), (966, 13), (972, 35), (973, 142), (978, 61), (1009, 61), (1012, 1), (1043, 30), (1061, 12), (1069, 46), (1096, 11), (1100, 12), (1113, 14), (1114, 38), (1122, 1), (1123, 51), (1139, 1), (1155, 4), (1167, 52), (1174, 1), (1175, 11), (1178, 43), (1179, 18), (1183, 44), (1186, 59), (1223, 100), (1234, 2), (1253, 16), (1268, 80), (1273, 6), (1316, 36), (1331, 10), (1346, 1), (1386, 30), (1398, 26), (1488, 14), (1545, 25), (1546, 30), (1585, 1), (1641, 7), (1765, 2), (1766, 57), (1987, 12)]
def cs77475 : List ℕ := [196, 0, 0, 2, 175, 57, 85, 255, 175, 93, 0, 255, 255, 162, 113, 0, 253, 255, 255, 80, 234, 195, 128, 255, 93, 0, 255, 110, 0, 140, 254, 255, 256, 255, 12, 255, 82, 242, 219, 255, 148, 255, 118, 124, 653, 257, 255, 582, 24, 255, 256, 479, 256, 216, 255, 255, 256, 257, 257, 255, 520, 255, 256, 257, 124, 257, 76, 637, 256, 496, 255, 256, 256, 257, 255, 257, 410, 256, 205, 255, 141, 554, 249, 257, 230, 256, 222, 257, 255, 255, 255, 216, 255, 626, 255, 255, 233, 255, 256, 256, 255, 316, 256, 255, 193, 254, 256, 255, 256, 617, 255, 255, 255, 256, 256, 256, 257, 255, 256, 154, 255, 256, 255, 255, 255, 255, 255, 256, 222, 255, 255, 206, 256, 256, 256, 256, 230, 255, 255, 255, 254, 244, 238, 255, 254, 225, 213, 253, 255, 240, 256, 255, 255, 255]
theorem node77475 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77475 support demand code
    entries77475 ((insert 27 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries77476 : List (Fin 2295 × ℕ) := [(46, 30), (181, 20), (275, 40), (466, 24), (484, 22), (540, 10), (572, 8), (577, 3), (587, 28), (588, 3), (617, 14), (631, 14), (678, 46), (679, 14), (727, 14), (737, 14), (741, 4), (742, 25), (776, 2), (777, 10), (818, 10), (819, 9), (834, 8), (851, 30), (864, 6), (869, 30), (873, 8), (874, 56), (916, 3), (917, 18), (918, 49), (933, 10), (934, 3), (943, 19), (946, 5), (955, 7), (956, 25), (962, 46), (964, 35), (971, 16), (972, 18), (973, 50), (978, 19), (1006, 1), (1009, 22), (1012, 17), (1061, 7), (1069, 33), (1076, 1), (1100, 7), (1113, 3), (1114, 8), (1122, 12), (1123, 9), (1139, 15), (1143, 2), (1167, 18), (1173, 2), (1175, 9), (1178, 8), (1179, 4), (1183, 18), (1186, 31), (1223, 21), (1234, 5), (1253, 24), (1316, 5), (1335, 3), (1375, 5), (1410, 1), (1433, 1), (1545, 12), (1548, 4), (1625, 6), (1660, 4), (1766, 9), (1775, 3), (2061, 6)]
def cs77476 : List ℕ := [69, 0, 0, 0, 75, 31, 33, 99, 54, 15, 0, 99, 100, 64, 43, 0, 100, 100, 101, 8, 82, 33, 51, 88, 9, 0, 99, 0, 0, 53, 99, 70, 102, 99, 17, 99, 54, 102, 65, 100, 21, 101, 53, 47, 260, 95, 34, 154, 10, 99, 100, 132, 101, 76, 99, 100, 100, 99, 101, 100, 9, 100, 100, 100, 99, 99, 14, 223, 100, 130, 52, 100, 99, 100, 79, 99, 163, 97, 58, 100, 73, 202, 101, 100, 101, 98, 99, 100, 100, 100, 100, 93, 87, 205, 101, 99, 85, 98, 101, 100, 100, 115, 99, 100, 70, 99, 100, 99, 87, 262, 99, 99, 100, 99, 99, 100, 100, 100, 99, 59, 100, 78, 99, 99, 100, 99, 99, 100, 90, 100, 100, 77, 98, 100, 100, 99, 94, 84, 99, 99, 101, 64, 95, 100, 100, 71, 88, 99, 100, 99, 99, 100, 93, 99]
theorem node77476 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 27 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77476 support demand code
    entries77476 ((insert 60 (insert 27 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node77474 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    60 node77475 node77476
theorem node77465 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    27 node77473 node77474
def entries77471 : List (Fin 2295 × ℕ) := [(23, 172), (46, 18), (275, 192), (340, 13), (466, 34), (497, 36), (506, 247), (540, 30), (542, 91), (572, 253), (587, 260), (629, 122), (631, 240), (679, 605), (681, 3), (741, 18), (742, 214), (779, 58), (781, 80), (782, 28), (812, 115), (834, 62), (835, 161), (851, 16), (852, 57), (858, 100), (869, 245), (873, 124), (874, 39), (888, 140), (892, 39), (894, 272), (897, 250), (905, 123), (911, 4), (915, 533), (918, 185), (919, 72), (926, 205), (933, 171), (934, 18), (936, 241), (938, 51), (943, 140), (954, 118), (956, 333), (958, 182), (961, 132), (962, 424), (971, 61), (972, 203), (973, 523), (978, 160), (981, 65), (1006, 17), (1009, 74), (1012, 95), (1016, 10), (1061, 157), (1069, 354), (1073, 72), (1096, 26), (1111, 21), (1113, 177), (1114, 130), (1123, 66), (1139, 92), (1167, 243), (1174, 11), (1175, 75), (1178, 149), (1179, 85), (1183, 234), (1186, 169), (1219, 209), (1223, 512), (1307, 25), (1316, 151), (1345, 89), (1346, 65), (1398, 30), (1497, 11), (1546, 56), (1651, 96)]
def cs77471 : List ℕ := [546, 209, 0, 234, 757, 210, 143, 1000, 637, 343, 0, 1000, 1001, 252, 139, 0, 965, 1000, 1001, 393, 1001, 329, 510, 1001, 645, 0, 1001, 1002, 0, 384, 1000, 1000, 1000, 1000, 418, 1001, 16, 1001, 608, 1870, 442, 1001, 413, 431, 2633, 1001, 1001, 1952, 0, 998, 999, 1679, 999, 1000, 1000, 1000, 1000, 1001, 1000, 999, 1911, 1001, 1000, 712, 113, 1000, 492, 2641, 999, 78, 999, 1000, 998, 1000, 1000, 1000, 1290, 1000, 1039, 999, 1001, 1713, 999, 999, 863, 963, 752, 1000, 1000, 999, 999, 1000, 1443, 1633, 1000, 750, 881, 1000, 1000, 998, 1000, 1000, 999, 999, 942, 1000, 999, 898, 998, 2375, 954, 1000, 1000, 762, 938, 999, 1000, 1000, 1000, 681, 1000, 927, 999, 1000, 999, 868, 1000, 1000, 799, 1001, 1000, 863, 1000, 1000, 1000, 999, 963, 1000, 1000, 1000, 1000, 808, 1000, 1000, 1000, 930, 945, 956, 981, 833, 1000, 916, 928, 926]
theorem node77471 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 39 (insert 60 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77471 support demand code
    entries77471 ((insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 92 (insert 39 (insert 60 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries77472 : List (Fin 2295 × ℕ) := [(23, 8), (46, 16), (181, 7), (275, 5), (381, 5), (450, 14), (466, 9), (497, 5), (506, 27), (514, 2), (587, 7), (629, 24), (631, 7), (679, 33), (681, 48), (740, 1), (742, 12), (778, 26), (780, 9), (782, 1), (834, 3), (835, 21), (852, 23), (858, 8), (869, 10), (873, 31), (892, 18), (894, 9), (897, 4), (898, 20), (905, 17), (915, 38), (917, 15), (918, 14), (919, 2), (926, 40), (933, 4), (936, 12), (943, 3), (951, 7), (956, 26), (958, 26), (962, 7), (964, 9), (968, 24), (972, 21), (973, 56), (978, 21), (981, 13), (1009, 6), (1045, 4), (1061, 9), (1069, 30), (1072, 9), (1073, 3), (1113, 16), (1114, 8), (1123, 9), (1138, 8), (1139, 9), (1154, 1), (1167, 16), (1174, 10), (1175, 4), (1178, 14), (1179, 8), (1183, 18), (1186, 26), (1219, 7), (1223, 42), (1253, 11), (1316, 9), (1345, 26), (1517, 21), (1546, 12), (1851, 4), (1987, 10), (2169, 5)]
def cs77472 : List ℕ := [62, 7, 0, 7, 84, 26, 45, 100, 84, 27, 2, 100, 100, 57, 16, 0, 97, 99, 99, 0, 100, 43, 38, 100, 83, 0, 100, 99, 0, 47, 100, 100, 100, 100, 38, 65, 11, 100, 91, 188, 4, 100, 12, 37, 259, 98, 92, 218, 0, 100, 100, 171, 101, 84, 94, 99, 100, 100, 100, 100, 233, 12, 100, 100, 25, 80, 29, 229, 100, 18, 94, 100, 92, 98, 101, 100, 125, 99, 74, 101, 91, 137, 101, 101, 100, 78, 100, 101, 101, 100, 99, 99, 7, 198, 100, 100, 49, 102, 99, 101, 101, 99, 100, 100, 92, 101, 99, 89, 102, 211, 97, 99, 100, 62, 99, 101, 100, 101, 99, 82, 82, 85, 94, 99, 101, 78, 100, 99, 87, 100, 100, 86, 99, 100, 100, 101, 100, 98, 100, 100, 101, 97, 90, 100, 101, 85, 100, 98, 100, 100, 100, 100, 100, 100]
theorem node77472 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77472 support demand code
    entries77472 ((insert 92 (insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 39 (insert 60 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node77469 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 60 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    92 node77471 node77472
def entries77470 : List (Fin 2295 × ℕ) := [(46, 303), (181, 41), (275, 274), (381, 40), (466, 300), (491, 51), (528, 374), (572, 227), (587, 213), (588, 41), (679, 475), (681, 168), (740, 13), (742, 238), (778, 154), (780, 26), (781, 111), (782, 24), (835, 130), (850, 48), (852, 193), (858, 249), (873, 194), (874, 73), (886, 44), (892, 22), (894, 227), (895, 291), (896, 51), (897, 15), (898, 137), (899, 193), (926, 267), (933, 288), (936, 147), (943, 54), (954, 105), (955, 99), (956, 316), (958, 215), (962, 317), (964, 25), (971, 8), (972, 317), (973, 520), (977, 50), (978, 187), (1009, 73), (1012, 22), (1021, 2), (1056, 7), (1061, 220), (1069, 362), (1072, 117), (1073, 106), (1076, 7), (1095, 22), (1113, 193), (1114, 96), (1122, 38), (1128, 9), (1139, 157), (1167, 213), (1173, 45), (1175, 73), (1178, 116), (1179, 81), (1183, 242), (1186, 141), (1223, 401), (1247, 23), (1316, 63), (1346, 58), (1386, 167), (1410, 15), (1522, 205), (1545, 16), (1660, 70), (1779, 106), (1849, 11), (1987, 131), (1998, 12)]
def cs77470 : List ℕ := [701, 0, 0, 48, 700, 205, 603, 1000, 401, 0, 0, 752, 954, 952, 303, 0, 1000, 1000, 1000, 227, 1001, 1000, 447, 1000, 0, 44, 1000, 997, 0, 303, 1000, 685, 1000, 1000, 118, 1000, 291, 1000, 774, 0, 621, 1000, 359, 412, 1962, 1001, 1000, 1800, 0, 587, 1000, 1999, 1000, 593, 1000, 1000, 1000, 1001, 932, 1000, 1651, 1000, 1000, 799, 130, 1000, 347, 2569, 1000, 252, 998, 1001, 670, 1001, 1000, 999, 1428, 1000, 732, 1000, 1001, 1712, 1000, 1000, 1002, 962, 772, 999, 1001, 999, 1000, 999, 1000, 1856, 1002, 999, 909, 1000, 1002, 1000, 1001, 1000, 1001, 1001, 922, 1000, 999, 795, 907, 2405, 999, 1000, 1001, 915, 968, 1000, 1000, 1002, 999, 816, 1002, 998, 1000, 1000, 1001, 853, 1000, 1000, 824, 999, 938, 806, 999, 1000, 1001, 1001, 1000, 1000, 1000, 1000, 822, 912, 1000, 976, 1001, 896, 1000, 897, 1000, 834, 1000, 850, 805, 903]
theorem node77470 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77470 support demand code
    entries77470 ((insert 39 (insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 60 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node77467 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    39 node77469 node77470
def entries77468 : List (Fin 2295 × ℕ) := [(23, 16), (46, 66), (275, 72), (475, 12), (484, 12), (491, 2), (529, 7), (572, 94), (587, 96), (588, 51), (617, 18), (631, 5), (679, 101), (729, 34), (737, 46), (741, 17), (742, 45), (818, 26), (819, 20), (834, 11), (852, 51), (858, 1), (859, 27), (869, 36), (870, 5), (873, 93), (888, 8), (894, 45), (898, 11), (917, 66), (933, 63), (936, 66), (943, 16), (955, 6), (956, 86), (962, 90), (964, 63), (968, 14), (971, 50), (972, 59), (973, 129), (978, 36), (1007, 3), (1009, 29), (1011, 1), (1012, 39), (1060, 3), (1061, 48), (1069, 97), (1072, 13), (1073, 25), (1100, 1), (1113, 50), (1114, 18), (1123, 6), (1139, 37), (1167, 59), (1173, 1), (1174, 6), (1175, 22), (1178, 31), (1179, 7), (1180, 6), (1182, 2), (1183, 66), (1186, 61), (1219, 2), (1223, 62), (1253, 16), (1263, 12), (1279, 108), (1296, 4), (1316, 18), (1440, 52), (1517, 12), (1623, 7), (1660, 7), (1775, 39), (1859, 1), (1987, 1), (1998, 15), (2061, 25)]
def cs77468 : List ℕ := [79, 110, 0, 14, 145, 125, 121, 256, 121, 0, 52, 256, 256, 104, 157, 0, 257, 256, 255, 102, 256, 214, 158, 257, 112, 0, 256, 255, 0, 110, 257, 256, 256, 256, 31, 256, 43, 255, 102, 256, 169, 255, 256, 135, 505, 161, 222, 299, 0, 240, 228, 343, 256, 199, 256, 256, 255, 256, 256, 256, 0, 256, 255, 165, 186, 257, 47, 563, 244, 0, 225, 256, 171, 212, 255, 256, 295, 257, 183, 256, 256, 310, 256, 255, 256, 256, 255, 253, 255, 257, 256, 256, 256, 340, 255, 170, 256, 255, 256, 256, 256, 281, 256, 256, 228, 256, 256, 243, 197, 618, 256, 255, 256, 247, 238, 256, 256, 256, 256, 196, 231, 210, 255, 257, 256, 243, 255, 256, 202, 256, 232, 216, 256, 256, 256, 255, 255, 239, 256, 256, 256, 193, 256, 256, 256, 220, 255, 249, 256, 215, 247, 249, 217, 256]
theorem node77468 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77468 support demand code
    entries77468 ((insert 60 (insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node77466 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    60 node77467 node77468
theorem node77449 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    69 node77465 node77466
def entries77463 : List (Fin 2295 × ℕ) := [(83, 36), (179, 20), (482, 61), (484, 28), (571, 86), (617, 4), (618, 15), (619, 61), (620, 49), (630, 94), (730, 72), (737, 51), (738, 32), (739, 11), (742, 39), (777, 78), (779, 45), (780, 35), (834, 34), (851, 13), (852, 94), (858, 69), (869, 48), (873, 37), (874, 3), (888, 25), (892, 62), (896, 182), (899, 7), (901, 7), (919, 15), (923, 5), (925, 31), (926, 58), (933, 22), (943, 59), (944, 19), (945, 36), (946, 7), (956, 22), (961, 8), (962, 82), (963, 41), (964, 25), (971, 20), (972, 22), (973, 144), (978, 37), (1006, 16), (1009, 41), (1025, 36), (1038, 8), (1043, 15), (1069, 58), (1114, 27), (1122, 12), (1123, 30), (1139, 20), (1141, 12), (1155, 27), (1167, 54), (1178, 50), (1184, 31), (1186, 58), (1253, 66), (1273, 1), (1277, 11), (1279, 83), (1296, 19), (1316, 22), (1349, 15), (1372, 26), (1386, 9), (1398, 22), (1405, 16), (1484, 6), (1545, 39), (1585, 30), (1607, 12), (1623, 1), (1625, 24), (1705, 19), (1903, 7), (2082, 23)]
def cs77463 : List ℕ := [66, 83, 0, 0, 173, 191, 92, 256, 85, 0, 0, 256, 257, 85, 38, 0, 257, 244, 257, 111, 256, 256, 20, 256, 163, 0, 257, 636, 0, 179, 256, 257, 145, 256, 0, 257, 79, 256, 20, 257, 108, 257, 78, 137, 624, 164, 513, 0, 135, 255, 256, 132, 256, 257, 256, 256, 256, 257, 256, 256, 255, 257, 256, 97, 255, 256, 75, 497, 256, 772, 256, 257, 256, 256, 256, 255, 345, 257, 88, 256, 222, 490, 258, 213, 179, 256, 256, 255, 256, 249, 256, 181, 257, 604, 256, 256, 197, 255, 255, 256, 257, 276, 213, 256, 210, 256, 255, 257, 255, 524, 251, 256, 256, 255, 255, 255, 256, 255, 255, 180, 257, 200, 255, 256, 255, 255, 255, 255, 227, 256, 256, 198, 255, 255, 256, 249, 253, 256, 255, 256, 255, 216, 229, 255, 248, 213, 194, 256, 255, 248, 255, 252, 255, 248]
theorem node77463 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 46 (insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77463 support demand code
    entries77463 ((insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 27 (insert 46 (insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries77464 : List (Fin 2295 × ℕ) := [(46, 2331), (100, 1493), (275, 456), (466, 1899), (484, 2981), (540, 2315), (571, 1510), (577, 224), (617, 1415), (630, 4248), (677, 1018), (730, 3600), (731, 1035), (742, 1764), (777, 1639), (779, 881), (780, 313), (781, 755), (783, 1431), (818, 248), (819, 489), (834, 592), (835, 343), (852, 2551), (869, 2687), (873, 2495), (874, 3031), (878, 442), (901, 123), (914, 1213), (915, 489), (918, 3678), (919, 1438), (925, 648), (926, 1920), (933, 1407), (934, 116), (943, 2917), (944, 976), (945, 583), (946, 648), (956, 2169), (962, 2282), (963, 851), (964, 1046), (971, 476), (972, 1342), (973, 5018), (978, 3218), (1009, 3218), (1011, 156), (1012, 583), (1043, 1121), (1069, 1138), (1072, 31), (1073, 838), (1100, 892), (1113, 28), (1114, 1100), (1122, 598), (1123, 1290), (1139, 487), (1155, 664), (1167, 1764), (1174, 163), (1175, 1183), (1178, 716), (1179, 781), (1183, 1090), (1186, 2417), (1212, 666), (1247, 135), (1253, 4580), (1277, 145), (1316, 1118), (1375, 501), (1386, 1117), (1398, 1831), (1488, 584), (1545, 1252), (1585, 171), (1623, 1538), (1842, 540)]
def cs77464 : List ℕ := [6479, 540, 0, 0, 7131, 2981, 2331, 9570, 4580, 0, 0, 9706, 10000, 7019, 5628, 0, 10000, 10000, 10000, 1510, 10000, 2331, 0, 9457, 0, 0, 10000, 0, 0, 7792, 10000, 7314, 6005, 10000, 1346, 10000, 4580, 9460, 0, 10001, 3033, 10000, 3893, 5377, 27792, 5260, 6072, 0, 5866, 9862, 10000, 4281, 10000, 9546, 10000, 10000, 10001, 10000, 10000, 10001, 10000, 10000, 10001, 1897, 10000, 10000, 1497, 19193, 10000, 20018, 10001, 10000, 10000, 10000, 10000, 10000, 15361, 10001, 4458, 10000, 8920, 18133, 7432, 9383, 8027, 9448, 10000, 10002, 10000, 10000, 9999, 8975, 9828, 19207, 10001, 10000, 10001, 10000, 10000, 9999, 9999, 13218, 7846, 10000, 9217, 10000, 9999, 10000, 9999, 20274, 10000, 10000, 10001, 10000, 9999, 10000, 10000, 10001, 10000, 7389, 10000, 9946, 9999, 10000, 10000, 10000, 9999, 10000, 9999, 9999, 10000, 8128, 10000, 10000, 10000, 10000, 8623, 8279, 10000, 10000, 10000, 9124, 9039, 10000, 10000, 8536, 8358, 10000, 10000, 10000, 9477, 10000, 10000, 10000]
theorem node77464 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77464 support demand code
    entries77464 ((insert 27 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node77459 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    27 node77463 node77464
def entries77461 : List (Fin 2295 × ℕ) := [(23, 16), (46, 52), (100, 52), (179, 20), (275, 43), (469, 3), (475, 67), (482, 3), (512, 8), (529, 20), (569, 4), (571, 3), (617, 28), (630, 64), (640, 21), (730, 112), (731, 17), (738, 35), (742, 44), (777, 43), (779, 18), (780, 33), (782, 17), (819, 6), (834, 5), (835, 25), (851, 73), (858, 84), (873, 68), (874, 88), (888, 40), (899, 35), (900, 27), (901, 8), (918, 108), (923, 3), (926, 101), (933, 8), (934, 52), (943, 28), (944, 17), (945, 16), (956, 83), (962, 54), (963, 16), (964, 52), (968, 24), (971, 2), (972, 33), (973, 136), (978, 67), (1009, 58), (1011, 30), (1012, 23), (1025, 7), (1038, 2), (1043, 36), (1069, 7), (1070, 6), (1073, 4), (1100, 21), (1114, 43), (1122, 17), (1123, 37), (1143, 6), (1155, 9), (1167, 52), (1173, 9), (1175, 23), (1178, 23), (1179, 13), (1182, 9), (1183, 43), (1186, 64), (1212, 4), (1253, 44), (1279, 99), (1285, 21), (1316, 30), (1386, 28), (1398, 36), (1545, 45), (1546, 4), (1572, 6), (1623, 1), (1625, 11), (1705, 13), (1859, 21)]
def cs77461 : List ℕ := [65, 102, 0, 88, 133, 123, 157, 256, 65, 0, 8, 255, 255, 249, 52, 0, 175, 255, 462, 43, 256, 52, 20, 255, 126, 0, 256, 255, 0, 147, 255, 255, 243, 255, 32, 256, 117, 255, 20, 255, 63, 255, 45, 140, 592, 256, 0, 0, 165, 256, 255, 87, 255, 233, 256, 255, 256, 120, 256, 256, 255, 257, 257, 70, 256, 256, 85, 550, 257, 406, 256, 255, 209, 256, 185, 257, 409, 255, 191, 256, 256, 486, 256, 176, 257, 214, 255, 256, 255, 256, 256, 256, 256, 520, 256, 255, 255, 255, 254, 256, 257, 313, 246, 255, 238, 255, 254, 255, 257, 598, 255, 255, 256, 256, 251, 257, 256, 256, 257, 200, 256, 249, 257, 255, 257, 255, 257, 255, 225, 256, 256, 211, 256, 255, 256, 256, 224, 226, 256, 256, 255, 229, 244, 240, 255, 212, 235, 256, 255, 256, 255, 256, 256, 256]
theorem node77461 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77461 support demand code
    entries77461 ((insert 46 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 18 (insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries77462 : List (Fin 2295 × ℕ) := [(46, 15), (179, 11), (355, 2), (498, 34), (527, 5), (571, 27), (617, 17), (630, 41), (730, 38), (731, 6), (742, 20), (776, 5), (777, 31), (779, 13), (780, 2), (782, 4), (819, 13), (835, 7), (852, 9), (858, 16), (888, 2), (892, 35), (899, 5), (914, 18), (916, 3), (917, 8), (918, 49), (925, 25), (926, 32), (933, 10), (934, 6), (943, 16), (944, 3), (956, 20), (962, 17), (963, 10), (964, 17), (971, 3), (972, 19), (973, 53), (978, 22), (1009, 18), (1011, 1), (1012, 5), (1025, 3), (1043, 9), (1069, 17), (1072, 5), (1073, 6), (1082, 2), (1100, 8), (1113, 5), (1114, 14), (1122, 2), (1123, 5), (1138, 11), (1143, 13), (1155, 10), (1167, 24), (1173, 4), (1174, 1), (1175, 5), (1178, 5), (1179, 18), (1182, 1), (1183, 14), (1186, 15), (1212, 8), (1223, 6), (1253, 55), (1316, 4), (1386, 12), (1398, 7), (1405, 1), (1484, 2), (1517, 23), (1545, 21), (1585, 11), (1623, 5), (2061, 1)]
def cs77462 : List ℕ := [61, 0, 0, 0, 70, 0, 54, 70, 95, 0, 0, 84, 100, 0, 15, 0, 61, 100, 0, 29, 100, 50, 11, 100, 0, 0, 101, 74, 0, 87, 100, 76, 80, 100, 10, 100, 55, 100, 11, 99, 43, 100, 19, 63, 233, 97, 50, 0, 57, 100, 100, 61, 99, 75, 101, 100, 99, 100, 82, 99, 99, 100, 99, 27, 100, 100, 29, 222, 99, 205, 99, 99, 98, 100, 80, 99, 108, 100, 56, 99, 101, 181, 97, 98, 84, 99, 99, 98, 98, 100, 100, 81, 74, 202, 99, 99, 82, 98, 100, 98, 100, 118, 78, 100, 99, 99, 99, 100, 99, 197, 100, 100, 100, 98, 100, 100, 99, 99, 99, 74, 100, 88, 100, 100, 98, 100, 99, 99, 98, 100, 99, 83, 99, 100, 99, 99, 92, 100, 99, 100, 99, 93, 100, 93, 94, 87, 96, 100, 99, 95, 99, 99, 99, 100]
theorem node77462 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77462 support demand code
    entries77462 ((insert 18 (insert 46 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node77460 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    18 node77461 node77462
theorem node77451 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    46 node77459 node77460
def entries77453 : List (Fin 2295 × ℕ) := [(20, 8), (275, 28), (340, 21), (466, 37), (491, 5), (498, 15), (572, 29), (583, 23), (644, 18), (779, 18), (780, 3), (782, 15), (834, 28), (835, 4), (850, 18), (852, 35), (857, 20), (869, 13), (873, 57), (874, 14), (892, 3), (894, 29), (901, 16), (913, 3), (915, 35), (918, 11), (919, 5), (933, 18), (934, 10), (936, 41), (938, 2), (943, 27), (955, 10), (956, 22), (958, 12), (961, 7), (962, 23), (964, 5), (971, 8), (972, 34), (973, 52), (977, 2), (978, 14), (1009, 13), (1021, 2), (1033, 4), (1034, 11), (1043, 5), (1061, 11), (1069, 25), (1073, 10), (1108, 10), (1110, 2), (1114, 15), (1122, 8), (1138, 14), (1139, 4), (1143, 4), (1155, 6), (1167, 22), (1173, 10), (1175, 7), (1179, 26), (1183, 19), (1186, 13), (1223, 5), (1247, 3), (1253, 14), (1261, 5), (1279, 9), (1375, 3), (1386, 13), (1405, 9), (1517, 5), (1546, 3), (1625, 1), (1667, 4), (1709, 6), (1901, 2)]
def cs77453 : List ℕ := [56, 9, 0, 26, 54, 9, 36, 100, 44, 0, 0, 94, 100, 81, 6, 0, 67, 100, 100, 29, 101, 61, 0, 96, 9, 0, 100, 102, 0, 12, 101, 101, 33, 100, 17, 100, 14, 58, 0, 101, 57, 100, 59, 36, 286, 100, 101, 3, 0, 100, 100, 72, 100, 73, 99, 235, 100, 76, 60, 100, 97, 100, 100, 49, 36, 100, 38, 231, 100, 18, 100, 100, 100, 44, 99, 100, 178, 88, 104, 100, 29, 172, 100, 100, 100, 100, 100, 100, 100, 73, 100, 94, 100, 186, 100, 100, 101, 100, 101, 100, 100, 101, 96, 100, 83, 100, 101, 100, 100, 246, 100, 100, 100, 97, 99, 100, 100, 101, 100, 69, 100, 81, 99, 101, 101, 99, 99, 100, 88, 100, 90, 81, 100, 101, 100, 101, 99, 100, 100, 100, 101, 88, 98, 100, 102, 95, 84, 100, 100, 100, 101, 76, 91, 90]
theorem node77453 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77453 support demand code
    entries77453 ((insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 55 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries77457 : List (Fin 2295 × ℕ) := [(46, 206), (275, 216), (340, 177), (381, 38), (474, 262), (482, 54), (514, 152), (572, 482), (579, 47), (583, 38), (618, 237), (740, 10), (742, 128), (778, 44), (779, 58), (780, 103), (818, 14), (834, 203), (835, 88), (851, 156), (852, 339), (858, 188), (869, 78), (873, 271), (894, 500), (896, 31), (899, 97), (901, 78), (915, 142), (918, 104), (926, 226), (933, 153), (934, 61), (955, 141), (956, 212), (964, 102), (967, 37), (968, 51), (971, 214), (972, 301), (973, 530), (977, 27), (978, 134), (981, 31), (985, 3), (1007, 68), (1009, 29), (1012, 21), (1021, 62), (1034, 25), (1043, 132), (1061, 185), (1069, 138), (1072, 47), (1073, 132), (1108, 35), (1110, 49), (1113, 175), (1114, 77), (1123, 39), (1128, 10), (1138, 200), (1139, 18), (1167, 239), (1174, 113), (1175, 87), (1179, 231), (1183, 171), (1186, 196), (1253, 92), (1263, 179), (1273, 13), (1279, 10), (1316, 31), (1335, 12), (1386, 302), (1517, 155), (1545, 74), (1556, 98), (1585, 60), (1623, 104), (1859, 404)]
def cs77457 : List ℕ := [496, 10, 0, 262, 587, 468, 953, 1001, 271, 0, 152, 1001, 1001, 271, 206, 0, 739, 1000, 1001, 482, 1001, 1001, 0, 860, 357, 3, 1001, 2257, 0, 206, 1001, 1000, 1001, 1001, 200, 1000, 248, 899, 0, 1000, 875, 1001, 329, 436, 2335, 694, 1371, 0, 0, 1001, 1001, 962, 1000, 969, 1001, 741, 1000, 1001, 271, 1000, 1002, 1000, 1000, 317, 755, 1000, 231, 2442, 1000, 31, 1002, 1001, 766, 567, 1001, 1001, 1183, 1000, 1012, 1000, 482, 1084, 1000, 1000, 952, 936, 1000, 1001, 1000, 977, 1001, 956, 1001, 1653, 1000, 849, 1001, 1001, 1000, 1001, 1000, 1000, 902, 1000, 880, 1001, 906, 944, 1000, 2488, 1000, 1001, 999, 1001, 1001, 1000, 1000, 1000, 1001, 909, 1000, 917, 1001, 1000, 1000, 860, 1000, 1000, 878, 1000, 822, 969, 1000, 1001, 999, 1001, 1000, 1000, 1000, 1000, 1000, 921, 1001, 1000, 1000, 980, 1001, 1000, 1000, 938, 1001, 813, 1000, 910]
theorem node77457 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77457 support demand code
    entries77457 ((insert 55 (insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries77458 : List (Fin 2295 × ℕ) := [(46, 20), (275, 10), (340, 23), (450, 10), (469, 1), (484, 4), (514, 13), (572, 50), (639, 7), (640, 9), (742, 7), (780, 9), (782, 14), (812, 1), (813, 4), (834, 19), (835, 12), (851, 36), (852, 9), (858, 28), (869, 3), (873, 7), (895, 13), (899, 7), (901, 5), (918, 32), (926, 34), (933, 25), (943, 7), (956, 28), (958, 2), (961, 1), (962, 18), (963, 2), (964, 27), (966, 2), (971, 13), (972, 25), (973, 47), (977, 1), (978, 16), (1009, 16), (1011, 11), (1012, 6), (1025, 11), (1043, 1), (1061, 12), (1069, 14), (1073, 6), (1100, 13), (1114, 7), (1123, 17), (1138, 8), (1154, 12), (1167, 28), (1174, 4), (1175, 7), (1178, 13), (1179, 12), (1183, 14), (1186, 11), (1212, 3), (1253, 7), (1285, 14), (1296, 19), (1316, 7), (1335, 8), (1386, 21), (1402, 7), (1517, 4), (1528, 14), (1545, 11), (1548, 3), (1556, 5), (1585, 9), (1623, 10), (1859, 48), (2061, 9)]
def cs77458 : List ℕ := [55, 1, 0, 14, 52, 78, 100, 101, 40, 0, 13, 77, 99, 40, 20, 0, 99, 99, 100, 50, 100, 33, 0, 100, 41, 0, 100, 147, 0, 20, 100, 92, 100, 101, 11, 99, 56, 97, 0, 99, 75, 99, 43, 85, 178, 86, 9, 0, 0, 100, 100, 93, 100, 87, 99, 60, 99, 40, 20, 101, 84, 100, 99, 54, 99, 100, 25, 203, 100, 0, 100, 101, 74, 44, 99, 100, 99, 100, 52, 100, 50, 147, 100, 96, 78, 99, 100, 102, 101, 95, 99, 93, 100, 191, 100, 94, 101, 100, 101, 101, 100, 116, 81, 100, 92, 100, 89, 100, 100, 268, 100, 99, 100, 99, 101, 99, 101, 100, 99, 86, 100, 101, 80, 100, 101, 100, 98, 101, 91, 100, 88, 86, 100, 101, 101, 100, 98, 100, 100, 100, 100, 90, 100, 80, 101, 85, 89, 89, 100, 80, 101, 81, 100, 75]
theorem node77458 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 55 (insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77458 support demand code
    entries77458 ((insert 46 (insert 55 (insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 27 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node77455 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    46 node77457 node77458
def entries77456 : List (Fin 2295 × ℕ) := [(46, 27), (275, 35), (381, 6), (466, 26), (475, 1), (479, 3), (484, 36), (529, 24), (540, 5), (542, 29), (572, 31), (736, 6), (741, 2), (742, 17), (778, 4), (779, 7), (781, 2), (782, 4), (783, 10), (812, 6), (834, 14), (835, 6), (852, 33), (869, 29), (873, 40), (878, 3), (915, 30), (917, 1), (918, 21), (919, 6), (926, 13), (933, 14), (943, 23), (955, 4), (956, 28), (958, 1), (962, 20), (964, 18), (967, 10), (968, 11), (971, 14), (972, 20), (973, 53), (977, 1), (978, 19), (1009, 15), (1011, 2), (1012, 13), (1021, 3), (1061, 12), (1069, 30), (1073, 6), (1100, 3), (1111, 4), (1113, 14), (1114, 14), (1123, 11), (1126, 2), (1138, 7), (1155, 1), (1167, 26), (1175, 15), (1178, 3), (1179, 15), (1182, 1), (1183, 21), (1186, 16), (1223, 9), (1253, 29), (1316, 16), (1386, 14), (1398, 9), (1545, 10), (1585, 7), (1623, 7), (1851, 3)]
def cs77456 : List ℕ := [64, 0, 0, 1, 74, 36, 27, 100, 38, 0, 0, 94, 101, 64, 64, 0, 101, 101, 101, 31, 101, 27, 0, 101, 0, 0, 100, 0, 0, 27, 101, 99, 85, 100, 15, 100, 29, 37, 0, 101, 48, 101, 23, 52, 239, 81, 82, 0, 0, 101, 101, 101, 99, 78, 100, 84, 101, 61, 40, 100, 99, 100, 98, 47, 57, 100, 18, 209, 99, 0, 100, 101, 99, 35, 101, 99, 113, 101, 73, 98, 31, 124, 99, 100, 85, 101, 100, 100, 101, 100, 99, 100, 99, 170, 100, 65, 81, 99, 101, 99, 100, 113, 99, 100, 78, 101, 84, 101, 99, 266, 101, 101, 100, 100, 89, 101, 99, 100, 101, 76, 101, 78, 99, 100, 100, 97, 100, 101, 79, 99, 101, 94, 100, 101, 100, 100, 98, 97, 101, 100, 100, 80, 101, 99, 101, 92, 92, 101, 100, 83, 101, 87, 101, 91]
theorem node77456 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 55 (insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77456 support demand code
    entries77456 ((insert 27 (insert 55 (insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node77454 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    27 node77455 node77456
theorem node77452 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    55 node77453 node77454
theorem node77450 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    69 node77451 node77452
theorem node77431 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    47 node77449 node77450
def entries77445 : List (Fin 2295 × ℕ) := [(23, 31), (46, 85), (181, 39), (307, 2), (340, 21), (381, 65), (491, 67), (497, 56), (587, 9), (629, 12), (679, 118), (681, 49), (739, 10), (780, 31), (783, 8), (813, 1), (852, 42), (858, 46), (869, 9), (873, 56), (874, 10), (892, 66), (894, 28), (915, 36), (917, 100), (925, 54), (926, 118), (943, 4), (944, 6), (957, 64), (961, 50), (962, 77), (971, 6), (972, 46), (973, 125), (977, 24), (978, 57), (1007, 15), (1012, 22), (1014, 9), (1025, 13), (1040, 7), (1044, 9), (1069, 5), (1100, 29), (1108, 6), (1111, 14), (1113, 4), (1114, 36), (1122, 20), (1123, 14), (1143, 43), (1149, 8), (1154, 4), (1155, 16), (1167, 59), (1175, 21), (1179, 22), (1180, 14), (1181, 22), (1183, 49), (1184, 1), (1186, 29), (1188, 36), (1212, 23), (1223, 121), (1253, 4), (1268, 40), (1316, 12), (1342, 39), (1346, 35), (1372, 43), (1459, 25), (1502, 26), (1572, 24), (1585, 81), (1670, 14), (1712, 8), (1766, 57), (1859, 18), (1902, 3)]
def cs77445 : List ℕ := [143, 0, 0, 0, 198, 75, 216, 216, 238, 57, 0, 219, 256, 149, 85, 0, 224, 256, 255, 40, 256, 179, 48, 256, 57, 0, 256, 256, 0, 105, 257, 257, 256, 257, 21, 256, 4, 256, 228, 257, 42, 191, 107, 197, 713, 255, 257, 441, 89, 257, 256, 455, 257, 183, 203, 256, 256, 256, 256, 256, 639, 256, 196, 256, 106, 169, 22, 512, 256, 256, 256, 613, 257, 257, 256, 256, 434, 256, 149, 257, 256, 467, 153, 257, 231, 145, 255, 256, 256, 256, 255, 228, 256, 0, 256, 256, 201, 256, 255, 256, 255, 256, 256, 255, 111, 224, 255, 255, 227, 510, 256, 255, 255, 202, 256, 234, 255, 256, 256, 159, 256, 255, 255, 255, 256, 192, 256, 255, 238, 254, 230, 240, 255, 256, 255, 255, 196, 251, 256, 255, 255, 248, 257, 255, 255, 204, 239, 256, 256, 224, 256, 255, 255, 256]
theorem node77445 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 60 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77445 support demand code
    entries77445 ((insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 71 (insert 60 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries77447 : List (Fin 2295 × ℕ) := [(20, 5), (177, 1), (275, 6), (340, 1), (485, 7), (491, 3), (506, 9), (679, 17), (681, 5), (692, 1), (730, 1), (739, 1), (781, 6), (852, 6), (857, 6), (869, 9), (874, 6), (892, 9), (894, 1), (911, 17), (913, 7), (915, 8), (919, 3), (932, 1), (934, 5), (936, 2), (938, 7), (942, 9), (943, 11), (944, 3), (954, 5), (957, 1), (962, 15), (972, 8), (973, 16), (978, 4), (1006, 2), (1007, 3), (1009, 2), (1012, 7), (1049, 1), (1055, 3), (1061, 4), (1069, 5), (1076, 1), (1081, 1), (1099, 2), (1100, 1), (1110, 1), (1113, 4), (1155, 5), (1167, 8), (1173, 3), (1177, 5), (1179, 2), (1180, 1), (1182, 2), (1183, 4), (1186, 7), (1223, 10), (1246, 2), (1253, 7), (1268, 4), (1279, 3), (1316, 2), (1342, 4), (1488, 4), (1585, 3), (1651, 5), (1668, 2), (1779, 6), (1987, 2)]
def cs77447 : List ℕ := [17, 3, 0, 5, 29, 15, 9, 32, 22, 14, 0, 32, 32, 21, 0, 0, 32, 32, 33, 4, 29, 16, 1, 26, 17, 0, 32, 33, 0, 30, 32, 32, 27, 31, 3, 32, 7, 33, 31, 32, 16, 33, 18, 17, 75, 32, 32, 79, 8, 28, 33, 66, 5, 21, 32, 89, 32, 31, 31, 33, 50, 32, 27, 31, 14, 32, 16, 70, 32, 32, 33, 15, 31, 28, 31, 32, 43, 32, 21, 31, 31, 58, 7, 32, 31, 28, 14, 33, 33, 27, 31, 31, 33, 2, 32, 36, 31, 33, 33, 32, 32, 36, 32, 32, 16, 30, 33, 31, 19, 67, 31, 31, 31, 29, 32, 23, 32, 32, 32, 21, 29, 27, 32, 31, 32, 31, 32, 31, 18, 32, 32, 29, 32, 32, 32, 32, 29, 30, 32, 32, 32, 30, 32, 31, 32, 24, 32, 31, 32, 26, 24, 31, 31, 32]
theorem node77447 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 60 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77447 support demand code
    entries77447 ((insert 71 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 55 (insert 60 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
def entries77448 : List (Fin 2295 × ℕ) := [(23, 52), (46, 99), (177, 11), (275, 69), (353, 3), (381, 3), (479, 3), (485, 8), (491, 34), (497, 47), (506, 28), (514, 19), (542, 5), (587, 92), (588, 5), (617, 11), (679, 105), (737, 27), (741, 69), (780, 19), (781, 57), (869, 25), (870, 27), (874, 2), (892, 34), (894, 48), (897, 41), (915, 38), (916, 4), (919, 2), (926, 16), (934, 43), (943, 52), (946, 70), (954, 17), (955, 39), (957, 32), (961, 11), (962, 47), (971, 26), (972, 35), (973, 116), (978, 53), (981, 25), (1006, 19), (1007, 15), (1011, 25), (1012, 18), (1014, 3), (1016, 9), (1055, 28), (1061, 21), (1072, 6), (1073, 30), (1075, 7), (1100, 2), (1110, 21), (1111, 19), (1113, 29), (1114, 5), (1123, 2), (1149, 6), (1155, 15), (1167, 46), (1174, 16), (1175, 67), (1179, 43), (1183, 28), (1186, 30), (1212, 38), (1219, 6), (1223, 107), (1233, 7), (1253, 22), (1268, 102), (1273, 22), (1279, 27), (1316, 29), (1342, 26), (1346, 5), (1398, 27), (1502, 11), (1572, 21), (1585, 41), (1651, 1), (1711, 28), (1798, 7), (1807, 30), (1845, 14), (1877, 22), (1987, 22)]
def cs77448 : List ℕ := [129, 40, 7, 13, 214, 73, 133, 254, 213, 66, 54, 255, 255, 134, 139, 0, 255, 256, 255, 102, 255, 216, 149, 254, 118, 0, 256, 256, 0, 110, 255, 255, 256, 255, 89, 255, 29, 256, 186, 255, 185, 255, 230, 159, 528, 226, 255, 536, 129, 205, 174, 499, 256, 255, 255, 125, 256, 256, 256, 255, 485, 255, 256, 180, 158, 257, 60, 415, 256, 256, 254, 74, 256, 256, 255, 255, 348, 256, 146, 255, 256, 290, 153, 256, 256, 167, 230, 254, 255, 256, 255, 258, 254, 0, 256, 255, 251, 255, 255, 255, 255, 258, 255, 254, 232, 238, 255, 255, 205, 477, 241, 255, 255, 202, 256, 255, 257, 255, 256, 260, 255, 254, 254, 256, 242, 187, 256, 255, 254, 254, 255, 256, 257, 256, 255, 255, 226, 257, 256, 257, 255, 255, 256, 256, 256, 256, 256, 256, 256, 211, 248, 251, 256, 256]
theorem node77448 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 71 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77448 support demand code
    entries77448 ((insert 55 (insert 71 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 60 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node77446 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 60 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    55 node77447 node77448
theorem node77441 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    71 node77445 node77446
def entries77443 : List (Fin 2295 × ℕ) := [(46, 117), (100, 1), (177, 3), (275, 75), (484, 56), (491, 21), (571, 74), (587, 125), (617, 64), (618, 3), (629, 28), (640, 1), (679, 90), (680, 38), (681, 30), (729, 14), (737, 8), (739, 36), (741, 78), (819, 26), (851, 56), (858, 4), (869, 10), (870, 8), (873, 52), (874, 15), (892, 80), (894, 12), (897, 3), (902, 25), (916, 22), (917, 97), (920, 2), (934, 17), (942, 36), (943, 81), (946, 48), (955, 25), (957, 47), (961, 4), (962, 103), (964, 68), (971, 44), (972, 47), (973, 125), (978, 66), (1009, 19), (1012, 36), (1049, 22), (1061, 29), (1069, 8), (1072, 6), (1100, 33), (1110, 44), (1111, 17), (1114, 17), (1123, 20), (1155, 5), (1167, 51), (1173, 3), (1175, 68), (1179, 22), (1183, 37), (1186, 64), (1223, 101), (1253, 10), (1277, 25), (1279, 88), (1316, 13), (1349, 4), (1401, 9), (1425, 17), (1471, 29), (1502, 8), (1516, 5), (1572, 43), (1845, 23), (1987, 10), (2061, 9)]
def cs77443 : List ℕ := [111, 88, 0, 0, 167, 144, 159, 255, 111, 0, 0, 255, 255, 68, 147, 0, 255, 256, 212, 74, 254, 255, 131, 254, 88, 0, 256, 254, 0, 148, 256, 255, 256, 256, 71, 255, 66, 254, 171, 256, 91, 254, 244, 136, 618, 139, 255, 338, 51, 224, 188, 376, 255, 224, 255, 256, 255, 256, 256, 254, 0, 256, 213, 236, 254, 256, 47, 455, 257, 256, 226, 256, 257, 256, 256, 237, 399, 255, 175, 258, 256, 391, 208, 406, 257, 193, 256, 172, 256, 219, 257, 256, 232, 0, 257, 256, 256, 256, 256, 256, 256, 270, 255, 256, 244, 235, 255, 257, 197, 582, 256, 256, 256, 223, 256, 257, 257, 257, 257, 199, 255, 256, 256, 257, 256, 212, 257, 256, 243, 257, 256, 257, 257, 256, 257, 256, 247, 221, 256, 257, 256, 229, 257, 256, 256, 215, 221, 257, 255, 209, 252, 257, 224, 256]
theorem node77443 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77443 support demand code
    entries77443 ((insert 60 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 83 (insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries77444 : List (Fin 2295 × ℕ) := [(46, 33), (177, 23), (275, 20), (484, 21), (527, 1), (542, 6), (571, 20), (572, 11), (583, 2), (588, 31), (617, 4), (631, 4), (679, 52), (737, 17), (741, 23), (743, 3), (813, 17), (819, 4), (850, 6), (851, 33), (852, 4), (869, 11), (870, 11), (873, 25), (874, 11), (892, 28), (902, 2), (916, 25), (920, 10), (926, 9), (938, 3), (945, 23), (946, 3), (956, 16), (959, 1), (962, 41), (964, 21), (966, 1), (971, 4), (972, 24), (973, 45), (1007, 14), (1009, 5), (1011, 2), (1012, 28), (1040, 5), (1044, 3), (1045, 8), (1049, 8), (1055, 8), (1060, 7), (1061, 18), (1069, 6), (1100, 7), (1111, 3), (1113, 8), (1114, 2), (1121, 1), (1123, 5), (1154, 6), (1167, 25), (1173, 7), (1175, 23), (1182, 1), (1183, 19), (1185, 9), (1186, 26), (1223, 33), (1263, 9), (1270, 7), (1279, 30), (1316, 10), (1425, 2), (1440, 16), (1517, 13), (1572, 19), (2061, 3), (2130, 6)]
def cs77444 : List ℕ := [33, 30, 0, 6, 70, 51, 48, 100, 42, 6, 16, 100, 100, 42, 57, 0, 100, 99, 99, 37, 100, 90, 54, 98, 36, 0, 99, 100, 0, 67, 100, 100, 100, 100, 30, 99, 33, 100, 75, 100, 46, 101, 49, 29, 243, 88, 100, 94, 55, 50, 100, 136, 86, 77, 100, 98, 100, 101, 99, 100, 9, 99, 69, 87, 101, 99, 15, 154, 100, 98, 100, 99, 31, 75, 100, 99, 161, 100, 74, 99, 99, 153, 92, 0, 100, 85, 99, 79, 99, 99, 89, 100, 97, 16, 89, 98, 100, 99, 99, 101, 99, 100, 100, 90, 67, 99, 100, 100, 85, 180, 84, 100, 99, 100, 99, 89, 100, 100, 101, 70, 99, 96, 100, 98, 100, 85, 99, 99, 69, 100, 99, 96, 100, 100, 99, 100, 100, 86, 99, 100, 99, 84, 99, 99, 100, 68, 96, 99, 98, 80, 79, 94, 88, 99]
theorem node77444 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 83 (insert 60 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77444 support demand code
    entries77444 ((insert 83 (insert 60 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node77442 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    83 node77443 node77444
theorem node77433 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    60 node77441 node77442
def entries77439 : List (Fin 2295 × ℕ) := [(83, 2), (177, 28), (275, 16), (340, 60), (355, 8), (381, 38), (469, 17), (471, 44), (479, 24), (484, 56), (514, 28), (572, 91), (583, 49), (618, 58), (632, 11), (640, 1), (730, 27), (731, 41), (737, 51), (739, 29), (777, 4), (780, 85), (819, 16), (850, 6), (851, 55), (857, 10), (858, 1), (859, 20), (860, 31), (873, 90), (892, 70), (894, 111), (899, 6), (915, 18), (917, 45), (925, 39), (926, 11), (943, 30), (945, 36), (946, 40), (955, 50), (957, 46), (961, 10), (962, 62), (964, 44), (972, 70), (973, 121), (977, 12), (978, 66), (1006, 9), (1009, 6), (1012, 37), (1014, 13), (1055, 3), (1061, 21), (1073, 35), (1100, 32), (1110, 46), (1113, 26), (1114, 3), (1122, 11), (1123, 7), (1149, 30), (1154, 1), (1155, 6), (1167, 61), (1174, 6), (1175, 61), (1179, 20), (1183, 24), (1184, 4), (1186, 75), (1223, 83), (1263, 17), (1273, 30), (1285, 10), (1320, 9), (1346, 14), (1488, 26), (1502, 4), (1517, 101), (1572, 39), (1585, 21), (1845, 10), (1855, 9), (1859, 32), (1984, 9)]
def cs77439 : List ℕ := [115, 17, 44, 16, 162, 88, 153, 255, 161, 0, 28, 254, 255, 100, 9, 0, 255, 256, 255, 91, 255, 256, 28, 183, 71, 0, 256, 557, 0, 48, 256, 256, 255, 256, 67, 256, 75, 245, 28, 256, 132, 254, 118, 158, 678, 167, 452, 0, 189, 257, 255, 185, 255, 258, 256, 257, 255, 256, 255, 257, 257, 256, 256, 153, 222, 258, 20, 477, 256, 255, 257, 257, 257, 156, 257, 257, 447, 256, 203, 257, 256, 287, 256, 210, 255, 197, 257, 256, 257, 249, 257, 257, 257, 0, 246, 257, 256, 256, 256, 256, 257, 257, 162, 256, 165, 234, 256, 252, 249, 520, 257, 257, 256, 257, 256, 257, 257, 256, 257, 223, 256, 247, 257, 257, 255, 227, 257, 256, 256, 257, 256, 253, 257, 255, 257, 256, 257, 228, 256, 257, 256, 246, 256, 256, 256, 237, 253, 257, 256, 235, 195, 257, 230, 256]
theorem node77439 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 46 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77439 support demand code
    entries77439 ((insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 27 (insert 46 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries77440 : List (Fin 2295 × ℕ) := [(46, 37), (177, 39), (275, 36), (381, 23), (466, 28), (479, 5), (484, 127), (527, 9), (542, 97), (572, 89), (632, 60), (730, 54), (731, 18), (737, 32), (739, 11), (777, 13), (780, 71), (781, 25), (819, 21), (851, 70), (869, 81), (873, 83), (874, 46), (888, 14), (915, 8), (916, 47), (917, 66), (919, 33), (925, 49), (934, 14), (943, 79), (945, 13), (946, 52), (955, 1), (957, 61), (961, 12), (962, 46), (964, 29), (972, 52), (973, 113), (977, 1), (978, 66), (985, 8), (1009, 21), (1012, 28), (1014, 14), (1016, 6), (1034, 1), (1040, 1), (1061, 17), (1069, 5), (1073, 11), (1100, 50), (1110, 33), (1111, 3), (1113, 26), (1122, 21), (1123, 1), (1143, 8), (1149, 23), (1155, 18), (1167, 72), (1175, 66), (1179, 55), (1183, 20), (1186, 64), (1212, 5), (1223, 92), (1269, 7), (1273, 37), (1320, 5), (1333, 5), (1335, 7), (1346, 1), (1349, 22), (1401, 12), (1488, 9), (1497, 5), (1572, 49), (1585, 21), (1846, 2)]
def cs77440 : List ℕ := [120, 0, 0, 0, 167, 127, 37, 195, 92, 0, 0, 201, 256, 129, 168, 0, 248, 256, 256, 103, 256, 37, 39, 256, 0, 8, 256, 0, 0, 136, 257, 180, 212, 256, 66, 255, 70, 187, 39, 256, 108, 257, 79, 198, 625, 207, 233, 0, 176, 256, 257, 202, 256, 225, 256, 256, 257, 205, 233, 256, 257, 255, 222, 127, 192, 240, 69, 415, 257, 256, 256, 256, 256, 111, 256, 256, 398, 257, 126, 257, 253, 212, 256, 256, 257, 221, 256, 256, 256, 252, 258, 241, 255, 0, 230, 255, 256, 256, 256, 257, 256, 272, 109, 257, 200, 223, 257, 257, 228, 439, 256, 256, 256, 233, 256, 256, 256, 257, 256, 190, 218, 256, 256, 257, 257, 234, 255, 255, 255, 256, 257, 256, 256, 257, 255, 256, 256, 256, 256, 257, 255, 256, 257, 256, 257, 245, 253, 257, 255, 212, 213, 256, 256, 257]
theorem node77440 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77440 support demand code
    entries77440 ((insert 27 (insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node77435 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    27 node77439 node77440
def entries77437 : List (Fin 2295 × ℕ) := [(46, 88), (177, 34), (275, 36), (340, 1), (381, 34), (471, 28), (498, 70), (514, 62), (571, 2), (572, 81), (632, 39), (639, 26), (640, 6), (730, 41), (731, 49), (737, 19), (741, 72), (777, 4), (779, 33), (780, 2), (781, 36), (819, 13), (850, 14), (851, 83), (858, 49), (869, 15), (873, 74), (874, 31), (895, 7), (900, 14), (914, 9), (916, 72), (917, 64), (925, 55), (926, 17), (934, 24), (943, 64), (945, 13), (946, 67), (955, 12), (957, 54), (962, 46), (964, 45), (971, 10), (972, 52), (973, 116), (978, 16), (1007, 27), (1012, 26), (1014, 11), (1025, 22), (1061, 17), (1072, 2), (1073, 29), (1082, 5), (1100, 37), (1110, 16), (1113, 10), (1122, 3), (1143, 4), (1149, 15), (1155, 42), (1167, 74), (1174, 9), (1175, 57), (1178, 5), (1179, 50), (1183, 5), (1186, 32), (1212, 34), (1223, 45), (1253, 17), (1273, 28), (1285, 27), (1320, 15), (1346, 17), (1375, 11), (1488, 22), (1572, 37), (1585, 50), (1859, 83), (2061, 23)]
def cs77437 : List ℕ := [145, 0, 28, 41, 145, 83, 220, 256, 159, 0, 62, 187, 256, 132, 88, 0, 235, 256, 257, 83, 256, 95, 34, 256, 55, 0, 257, 256, 0, 170, 256, 241, 191, 256, 66, 256, 107, 256, 34, 256, 107, 255, 127, 195, 610, 237, 45, 0, 204, 257, 256, 261, 256, 206, 257, 257, 256, 145, 255, 256, 255, 255, 256, 46, 257, 257, 55, 463, 256, 255, 470, 256, 255, 125, 230, 256, 383, 257, 141, 256, 255, 198, 243, 256, 256, 189, 256, 243, 256, 229, 256, 175, 256, 0, 237, 257, 256, 257, 257, 256, 257, 256, 151, 257, 211, 204, 257, 256, 236, 466, 229, 256, 255, 246, 257, 237, 257, 257, 255, 235, 256, 256, 257, 256, 257, 228, 256, 257, 257, 257, 257, 256, 256, 257, 257, 258, 256, 256, 257, 256, 257, 256, 256, 257, 258, 257, 242, 256, 257, 217, 220, 248, 247, 257]
theorem node77437 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77437 support demand code
    entries77437 ((insert 46 (insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 70 (insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries77438 : List (Fin 2295 × ℕ) := [(46, 24), (177, 1), (275, 11), (484, 17), (514, 8), (572, 37), (617, 9), (632, 35), (677, 2), (730, 16), (737, 7), (777, 4), (843, 2), (851, 25), (858, 3), (859, 2), (869, 11), (873, 18), (874, 19), (895, 27), (915, 16), (917, 9), (918, 5), (919, 20), (925, 27), (926, 11), (934, 13), (943, 11), (944, 13), (945, 3), (946, 20), (956, 19), (957, 13), (962, 35), (964, 26), (972, 28), (973, 39), (978, 6), (1006, 1), (1007, 16), (1009, 3), (1012, 29), (1034, 6), (1061, 20), (1069, 10), (1100, 19), (1108, 10), (1113, 6), (1114, 13), (1123, 8), (1143, 19), (1155, 18), (1167, 41), (1173, 13), (1175, 18), (1177, 1), (1178, 4), (1179, 16), (1183, 16), (1186, 6), (1223, 21), (1233, 3), (1253, 9), (1273, 5), (1279, 25), (1364, 4), (1488, 12), (1517, 14), (1859, 20), (2061, 2)]
def cs77438 : List ℕ := [50, 25, 0, 0, 55, 62, 61, 100, 32, 0, 8, 100, 94, 37, 24, 0, 100, 99, 99, 37, 100, 51, 1, 75, 25, 0, 100, 97, 0, 60, 100, 75, 100, 100, 31, 86, 63, 99, 1, 100, 50, 97, 32, 50, 262, 100, 21, 0, 40, 101, 100, 48, 99, 99, 101, 99, 99, 37, 88, 46, 74, 99, 92, 26, 101, 99, 34, 198, 99, 99, 0, 100, 99, 17, 99, 100, 134, 99, 75, 99, 89, 59, 45, 100, 99, 91, 99, 99, 100, 83, 100, 100, 101, 24, 87, 99, 99, 100, 100, 99, 100, 107, 46, 95, 71, 93, 99, 98, 91, 172, 99, 99, 84, 100, 99, 98, 99, 99, 100, 58, 98, 95, 99, 99, 99, 99, 99, 100, 99, 100, 99, 99, 100, 100, 99, 100, 81, 100, 100, 99, 99, 88, 99, 99, 99, 78, 100, 99, 97, 71, 82, 87, 61, 87]
theorem node77438 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 46 (insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77438 support demand code
    entries77438 ((insert 70 (insert 46 (insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node77436 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    70 node77437 node77438
theorem node77434 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    46 node77435 node77436
theorem node77432 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    47 node77433 node77434
theorem node77403 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 51 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    93 node77431 node77432
def entries77429 : List (Fin 2295 × ℕ) := [(23, 23), (46, 1), (49, 10), (340, 33), (587, 30), (588, 7), (617, 16), (629, 13), (727, 27), (738, 8), (741, 7), (742, 30), (834, 20), (835, 5), (846, 23), (860, 36), (873, 19), (888, 20), (892, 54), (894, 66), (895, 7), (896, 57), (897, 4), (905, 16), (915, 46), (919, 13), (926, 17), (933, 13), (943, 1), (955, 20), (956, 34), (961, 14), (962, 40), (971, 21), (972, 27), (973, 58), (978, 28), (981, 4), (1006, 2), (1009, 11), (1012, 5), (1034, 2), (1043, 14), (1061, 3), (1069, 18), (1073, 6), (1108, 5), (1111, 3), (1113, 13), (1114, 11), (1123, 6), (1126, 1), (1139, 8), (1167, 3), (1174, 3), (1178, 17), (1179, 7), (1183, 15), (1184, 3), (1185, 2), (1186, 25), (1223, 28), (1279, 26), (1316, 7), (1433, 6), (1435, 4), (1488, 4), (1497, 3), (1517, 46), (1622, 15)]
def cs77429 : List ℕ := [28, 49, 0, 0, 51, 26, 47, 100, 74, 0, 0, 100, 100, 19, 1, 0, 54, 101, 101, 20, 100, 200, 41, 54, 46, 0, 55, 327, 0, 14, 100, 100, 100, 100, 42, 100, 7, 100, 0, 222, 13, 74, 71, 36, 414, 50, 256, 87, 0, 100, 100, 0, 101, 101, 100, 100, 102, 99, 80, 100, 100, 69, 101, 33, 44, 100, 44, 310, 100, 126, 41, 100, 100, 76, 100, 100, 180, 101, 127, 100, 69, 191, 100, 100, 95, 61, 83, 100, 101, 99, 99, 100, 100, 182, 100, 93, 100, 97, 100, 98, 100, 100, 62, 100, 101, 100, 81, 82, 99, 268, 99, 100, 99, 91, 71, 99, 100, 100, 100, 67, 100, 70, 89, 100, 82, 77, 100, 99, 63, 99, 64, 67, 99, 99, 100, 99, 93, 85, 99, 100, 99, 89, 81, 99, 100, 88, 94, 95, 99, 97, 99, 100, 100, 100]
theorem node77429 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 39 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77429 support demand code
    entries77429 ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 39 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries77430 : List (Fin 2295 × ℕ) := [(20, 6), (23, 2), (179, 4), (340, 4), (465, 2), (542, 17), (587, 35), (588, 5), (617, 8), (619, 3), (620, 10), (630, 15), (727, 26), (730, 11), (731, 3), (742, 34), (776, 9), (780, 9), (782, 2), (818, 2), (834, 2), (835, 18), (846, 30), (860, 33), (869, 17), (873, 8), (874, 39), (888, 18), (897, 9), (905, 21), (915, 17), (918, 48), (919, 13), (926, 22), (933, 5), (938, 11), (943, 19), (944, 5), (956, 37), (958, 6), (961, 3), (962, 51), (964, 4), (965, 7), (966, 1), (972, 18), (973, 55), (978, 12), (981, 6), (1006, 11), (1009, 14), (1012, 12), (1043, 15), (1044, 1), (1061, 4), (1069, 12), (1073, 5), (1095, 10), (1108, 1), (1113, 8), (1114, 16), (1123, 11), (1139, 5), (1143, 1), (1167, 19), (1174, 4), (1175, 1), (1178, 15), (1182, 6), (1183, 20), (1186, 25), (1223, 3), (1253, 37), (1279, 21), (1316, 11), (1346, 4), (1410, 12), (1417, 3), (1433, 5), (1497, 1), (1517, 16), (1546, 5), (1842, 6), (2294, 21)]
def cs77430 : List ℕ := [40, 57, 0, 6, 42, 21, 16, 99, 79, 0, 0, 100, 100, 53, 23, 0, 67, 100, 100, 18, 100, 0, 74, 84, 48, 0, 71, 82, 0, 46, 100, 99, 99, 100, 56, 101, 37, 101, 4, 196, 5, 69, 89, 43, 268, 71, 72, 101, 39, 99, 100, 0, 100, 100, 101, 101, 100, 100, 101, 100, 99, 101, 100, 33, 66, 100, 36, 203, 100, 101, 71, 101, 99, 101, 101, 101, 159, 100, 61, 100, 101, 227, 99, 100, 77, 76, 83, 99, 100, 100, 100, 89, 101, 214, 101, 101, 87, 100, 101, 100, 101, 100, 72, 101, 91, 100, 101, 100, 100, 226, 100, 99, 101, 101, 101, 99, 100, 101, 100, 65, 101, 94, 86, 100, 100, 100, 100, 101, 68, 100, 100, 81, 100, 100, 101, 100, 87, 92, 100, 100, 100, 87, 100, 100, 101, 79, 93, 100, 100, 100, 100, 100, 100, 100]
theorem node77430 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 39 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77430 support demand code
    entries77430 ((insert 21 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 39 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node77427 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 39 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 39 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    21 node77429 node77430
def entries77428 : List (Fin 2295 × ℕ) := [(23, 34), (46, 61), (471, 11), (482, 10), (527, 52), (587, 106), (630, 2), (690, 30), (693, 36), (727, 83), (730, 46), (742, 59), (777, 9), (782, 4), (834, 9), (835, 35), (846, 30), (858, 15), (869, 15), (874, 123), (888, 73), (895, 42), (897, 8), (905, 59), (915, 26), (916, 17), (918, 138), (919, 14), (926, 91), (933, 16), (943, 28), (944, 10), (956, 85), (958, 26), (961, 44), (962, 121), (963, 11), (964, 28), (966, 4), (968, 1), (972, 35), (973, 141), (978, 26), (994, 24), (1006, 26), (1009, 16), (1012, 24), (1025, 17), (1043, 77), (1061, 3), (1096, 18), (1113, 11), (1114, 47), (1122, 7), (1123, 39), (1139, 16), (1167, 49), (1174, 3), (1175, 6), (1178, 44), (1179, 1), (1182, 9), (1183, 50), (1186, 65), (1248, 2), (1253, 141), (1279, 40), (1316, 40), (1346, 18), (1384, 10), (1517, 60), (1528, 12), (1545, 17), (1546, 17), (1625, 31), (1901, 8), (2292, 14), (2293, 21)]
def cs77428 : List ℕ := [141, 70, 11, 0, 175, 50, 136, 256, 149, 0, 0, 256, 251, 131, 61, 0, 202, 256, 256, 73, 256, 103, 114, 181, 120, 0, 214, 250, 0, 129, 256, 256, 257, 256, 98, 256, 183, 257, 0, 547, 16, 128, 144, 177, 647, 168, 0, 242, 91, 256, 256, 0, 257, 257, 256, 256, 256, 221, 256, 256, 231, 256, 256, 43, 256, 255, 126, 641, 256, 256, 238, 256, 215, 231, 230, 255, 415, 256, 145, 256, 256, 591, 255, 256, 166, 220, 117, 257, 257, 255, 255, 194, 256, 524, 256, 256, 235, 256, 256, 255, 256, 256, 178, 255, 251, 257, 227, 255, 255, 594, 242, 256, 255, 257, 256, 255, 256, 256, 256, 167, 255, 209, 256, 255, 256, 256, 257, 256, 199, 255, 256, 199, 256, 257, 256, 256, 256, 235, 256, 256, 256, 201, 249, 249, 255, 210, 214, 255, 257, 256, 256, 256, 256, 256]
theorem node77428 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77428 support demand code
    entries77428 ((insert 46 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 39 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node77419 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    46 node77427 node77428
def entries77425 : List (Fin 2295 × ℕ) := [(46, 56), (340, 30), (449, 20), (450, 1), (496, 71), (507, 40), (581, 111), (583, 47), (587, 25), (588, 20), (617, 13), (664, 58), (727, 22), (729, 36), (737, 44), (741, 20), (742, 64), (779, 50), (780, 42), (834, 71), (835, 9), (852, 102), (858, 102), (859, 7), (860, 25), (873, 107), (886, 38), (888, 45), (892, 43), (894, 150), (895, 7), (896, 156), (899, 23), (901, 9), (926, 5), (933, 15), (943, 31), (955, 64), (956, 44), (958, 14), (962, 74), (967, 12), (968, 6), (971, 55), (972, 64), (973, 146), (977, 33), (978, 52), (1009, 20), (1012, 1), (1034, 10), (1043, 31), (1045, 2), (1061, 15), (1069, 32), (1072, 16), (1095, 15), (1110, 24), (1113, 3), (1114, 31), (1123, 19), (1138, 10), (1139, 18), (1167, 45), (1174, 15), (1175, 3), (1178, 42), (1179, 19), (1182, 9), (1183, 17), (1185, 15), (1186, 65), (1253, 44), (1277, 13), (1316, 18), (1386, 31), (1497, 11), (1528, 4), (1859, 98), (1861, 12)]
def cs77425 : List ℕ := [154, 0, 0, 12, 146, 98, 256, 256, 147, 40, 12, 154, 257, 107, 56, 0, 225, 255, 257, 45, 256, 570, 45, 257, 40, 38, 256, 726, 0, 56, 257, 229, 258, 255, 18, 256, 58, 257, 0, 0, 86, 221, 106, 108, 724, 125, 705, 103, 0, 213, 257, 0, 255, 135, 256, 256, 255, 255, 199, 257, 258, 256, 255, 77, 172, 256, 106, 687, 257, 310, 176, 257, 256, 104, 256, 257, 416, 255, 199, 256, 116, 400, 255, 256, 187, 171, 256, 257, 256, 256, 258, 257, 257, 422, 257, 236, 256, 257, 256, 258, 257, 263, 245, 257, 256, 256, 256, 214, 257, 596, 256, 257, 256, 258, 256, 257, 257, 257, 257, 180, 257, 253, 199, 256, 242, 222, 257, 256, 151, 257, 220, 220, 257, 256, 256, 257, 231, 254, 256, 257, 256, 257, 256, 257, 257, 210, 205, 256, 255, 257, 256, 256, 257, 256]
theorem node77425 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77425 support demand code
    entries77425 ((insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries77426 : List (Fin 2295 × ℕ) := [(20, 7), (83, 22), (464, 2), (587, 17), (617, 16), (618, 31), (620, 15), (640, 3), (664, 17), (727, 10), (731, 19), (736, 19), (738, 6), (739, 4), (742, 18), (777, 1), (780, 9), (782, 1), (834, 8), (835, 10), (844, 1), (852, 13), (858, 22), (859, 1), (860, 20), (873, 19), (874, 34), (886, 1), (888, 9), (901, 2), (926, 19), (933, 20), (936, 11), (943, 27), (946, 4), (956, 44), (958, 5), (961, 9), (964, 8), (965, 7), (968, 4), (971, 4), (972, 18), (973, 52), (977, 17), (978, 15), (1006, 15), (1009, 15), (1012, 9), (1043, 13), (1061, 7), (1072, 10), (1073, 6), (1096, 17), (1113, 5), (1114, 11), (1123, 13), (1128, 4), (1139, 3), (1143, 2), (1167, 18), (1174, 3), (1175, 2), (1178, 6), (1179, 2), (1182, 11), (1183, 18), (1186, 29), (1253, 30), (1301, 5), (1316, 6), (1346, 4), (1386, 31), (1410, 1), (1488, 10), (1545, 2), (1556, 6), (1618, 10), (1619, 4), (1625, 2), (1842, 7), (1859, 33), (2249, 7), (2293, 25)]
def cs77426 : List ℕ := [71, 7, 0, 7, 50, 33, 55, 91, 65, 14, 0, 92, 99, 60, 7, 0, 88, 92, 100, 9, 100, 0, 17, 101, 14, 2, 89, 101, 0, 34, 101, 29, 100, 99, 5, 99, 31, 99, 0, 0, 27, 100, 44, 59, 155, 60, 93, 52, 62, 100, 100, 0, 100, 99, 98, 99, 100, 90, 99, 99, 81, 99, 100, 15, 94, 99, 17, 162, 100, 99, 97, 99, 90, 99, 99, 99, 150, 99, 51, 100, 98, 186, 100, 100, 72, 87, 97, 99, 99, 90, 100, 100, 99, 225, 101, 98, 99, 98, 100, 101, 99, 100, 85, 102, 84, 98, 99, 100, 99, 210, 100, 100, 99, 99, 99, 99, 99, 102, 101, 73, 101, 98, 82, 99, 100, 100, 99, 98, 99, 98, 101, 75, 99, 99, 99, 99, 70, 78, 100, 99, 100, 83, 99, 100, 100, 85, 89, 99, 99, 99, 99, 91, 100, 99]
theorem node77426 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77426 support demand code
    entries77426 ((insert 21 (insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node77421 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    21 node77425 node77426
def entries77423 : List (Fin 2295 × ℕ) := [(43, 11), (46, 11), (307, 5), (340, 14), (484, 8), (527, 7), (531, 22), (587, 29), (617, 16), (630, 7), (640, 3), (727, 29), (729, 16), (742, 10), (778, 10), (780, 1), (782, 23), (783, 23), (798, 7), (834, 2), (835, 8), (852, 4), (858, 20), (860, 5), (873, 14), (874, 32), (895, 11), (898, 2), (900, 13), (901, 4), (918, 37), (925, 4), (926, 35), (933, 29), (936, 5), (943, 14), (946, 7), (956, 43), (958, 3), (962, 34), (964, 24), (971, 6), (972, 14), (973, 54), (978, 28), (1009, 28), (1011, 9), (1012, 8), (1043, 10), (1061, 1), (1069, 17), (1070, 6), (1073, 7), (1096, 6), (1114, 18), (1123, 11), (1128, 9), (1139, 2), (1154, 8), (1167, 18), (1178, 14), (1179, 1), (1183, 26), (1186, 20), (1253, 56), (1316, 12), (1384, 14), (1386, 13), (1417, 5), (1590, 6), (1625, 1), (1640, 5), (1643, 8), (1731, 4), (1773, 10), (1775, 3), (1859, 24), (2293, 4)]
def cs77423 : List ℕ := [80, 0, 0, 0, 60, 32, 79, 84, 61, 0, 0, 80, 100, 68, 35, 6, 88, 101, 100, 0, 100, 46, 31, 97, 6, 0, 99, 61, 0, 53, 100, 59, 100, 100, 0, 99, 73, 101, 0, 37, 34, 88, 76, 56, 205, 89, 9, 100, 38, 98, 87, 0, 102, 74, 99, 101, 100, 78, 100, 100, 100, 100, 100, 44, 99, 100, 20, 201, 101, 100, 101, 100, 61, 101, 69, 216, 127, 99, 63, 101, 99, 234, 98, 100, 77, 100, 97, 100, 99, 87, 100, 100, 99, 206, 100, 100, 89, 99, 99, 101, 100, 128, 99, 101, 99, 100, 100, 101, 100, 252, 100, 100, 100, 99, 93, 100, 101, 99, 100, 70, 99, 99, 101, 101, 99, 100, 100, 100, 79, 101, 99, 72, 100, 99, 100, 100, 85, 92, 99, 101, 99, 84, 98, 101, 99, 87, 80, 92, 99, 101, 99, 93, 100, 100]
theorem node77423 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77423 support demand code
    entries77423 ((insert 46 (insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 75 (insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries77424 : List (Fin 2295 × ℕ) := [(46, 24), (340, 4), (464, 3), (465, 5), (466, 19), (531, 40), (587, 37), (664, 16), (730, 3), (737, 27), (739, 1), (740, 1), (742, 27), (776, 4), (818, 6), (834, 2), (835, 29), (850, 1), (858, 32), (873, 25), (874, 24), (888, 29), (897, 3), (899, 19), (900, 13), (918, 31), (926, 37), (933, 16), (934, 5), (936, 8), (943, 13), (945, 9), (946, 1), (956, 30), (958, 25), (962, 34), (963, 7), (964, 9), (967, 12), (972, 27), (973, 54), (978, 15), (1009, 15), (1021, 2), (1033, 2), (1043, 23), (1061, 12), (1073, 11), (1096, 6), (1100, 8), (1113, 14), (1114, 16), (1123, 14), (1128, 6), (1138, 4), (1139, 10), (1167, 28), (1174, 2), (1175, 9), (1178, 14), (1181, 3), (1183, 18), (1186, 18), (1223, 7), (1253, 32), (1316, 5), (1386, 4), (1528, 5), (1562, 1), (1859, 10), (1987, 10), (2293, 17)]
def cs77424 : List ℕ := [68, 0, 0, 1, 39, 10, 66, 68, 39, 0, 0, 68, 69, 89, 24, 0, 68, 100, 100, 29, 100, 24, 40, 100, 0, 0, 86, 42, 0, 41, 100, 71, 100, 99, 11, 100, 32, 100, 11, 31, 21, 75, 54, 43, 173, 71, 7, 68, 31, 100, 100, 11, 100, 71, 100, 100, 99, 28, 100, 100, 72, 99, 100, 31, 99, 86, 43, 231, 100, 99, 49, 100, 81, 88, 91, 14, 162, 99, 69, 101, 74, 185, 101, 100, 67, 59, 76, 99, 100, 100, 101, 83, 100, 216, 99, 99, 92, 100, 99, 100, 100, 112, 100, 101, 99, 100, 77, 99, 100, 225, 99, 99, 99, 99, 99, 100, 99, 101, 98, 76, 100, 99, 99, 100, 101, 99, 99, 98, 98, 99, 101, 93, 98, 100, 99, 99, 93, 99, 99, 100, 100, 78, 100, 95, 100, 97, 96, 100, 99, 96, 99, 95, 80, 90]
theorem node77424 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 46 (insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77424 support demand code
    entries77424 ((insert 75 (insert 46 (insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node77422 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    75 node77423 node77424
theorem node77420 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    46 node77421 node77422
theorem node77415 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 27 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    39 node77419 node77420
def entries77417 : List (Fin 2295 × ℕ) := [(46, 256), (340, 2), (466, 94), (484, 297), (527, 6), (542, 172), (587, 493), (630, 60), (693, 88), (727, 311), (729, 20), (731, 90), (741, 59), (742, 102), (780, 90), (782, 77), (818, 46), (834, 168), (835, 26), (852, 157), (869, 303), (873, 134), (874, 567), (878, 99), (888, 270), (905, 146), (915, 186), (917, 8), (918, 632), (919, 174), (926, 208), (943, 201), (944, 104), (945, 49), (946, 43), (956, 305), (958, 55), (961, 119), (962, 463), (964, 91), (965, 45), (971, 91), (972, 125), (973, 509), (978, 300), (981, 6), (1006, 50), (1009, 266), (1011, 76), (1012, 95), (1043, 252), (1061, 14), (1069, 28), (1100, 34), (1110, 46), (1111, 25), (1113, 20), (1114, 127), (1123, 206), (1138, 105), (1167, 141), (1174, 39), (1175, 54), (1178, 112), (1179, 46), (1183, 134), (1186, 272), (1212, 53), (1226, 28), (1253, 480), (1277, 32), (1316, 120), (1332, 32), (1398, 80), (1433, 27), (1500, 12), (1528, 41), (1619, 2), (1842, 123), (1851, 31), (2293, 150)]
def cs77417 : List ℕ := [574, 123, 0, 0, 637, 297, 256, 854, 480, 2, 0, 1000, 1000, 701, 650, 0, 994, 1000, 1000, 270, 1000, 256, 493, 869, 154, 0, 886, 0, 0, 466, 1000, 1000, 1000, 1000, 239, 1000, 480, 1000, 0, 1543, 0, 507, 800, 529, 2838, 537, 583, 1001, 374, 1000, 1000, 0, 1000, 888, 1000, 1000, 1000, 1000, 1001, 1000, 999, 864, 999, 310, 866, 1000, 428, 2242, 1000, 1001, 600, 1001, 999, 835, 1000, 1000, 1938, 1000, 678, 1000, 1002, 2329, 999, 1000, 618, 761, 624, 1001, 1001, 1001, 999, 1000, 1001, 1785, 999, 1000, 1000, 923, 1000, 1000, 1000, 1216, 703, 999, 922, 1000, 1001, 1000, 1000, 2208, 1000, 999, 1000, 1000, 1000, 928, 1001, 999, 1000, 678, 1000, 965, 886, 1000, 1000, 966, 999, 1000, 746, 1000, 1000, 743, 1000, 1000, 1000, 999, 923, 808, 999, 1000, 999, 827, 883, 1000, 1000, 721, 789, 1000, 999, 1000, 992, 1000, 1000, 1000]
theorem node77417 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77417 support demand code
    entries77417 ((insert 27 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 39 (insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries77418 : List (Fin 2295 × ℕ) := [(20, 1), (46, 73), (466, 14), (475, 40), (479, 59), (484, 34), (531, 40), (576, 38), (577, 30), (587, 107), (588, 3), (630, 34), (640, 19), (727, 63), (729, 38), (730, 11), (736, 10), (738, 1), (739, 45), (741, 23), (742, 21), (780, 9), (782, 18), (834, 11), (835, 25), (852, 15), (873, 37), (874, 79), (878, 7), (886, 20), (888, 2), (897, 6), (901, 15), (918, 9), (926, 45), (933, 38), (936, 75), (943, 90), (944, 17), (956, 119), (961, 12), (962, 101), (963, 3), (964, 35), (965, 15), (966, 12), (971, 7), (972, 32), (973, 134), (977, 20), (978, 64), (1006, 1), (1009, 55), (1012, 24), (1043, 34), (1061, 13), (1069, 19), (1073, 44), (1095, 30), (1113, 9), (1114, 38), (1123, 42), (1128, 7), (1167, 51), (1174, 7), (1175, 27), (1178, 13), (1182, 20), (1183, 51), (1186, 71), (1188, 15), (1223, 60), (1253, 107), (1316, 31), (1398, 36), (1497, 6), (1500, 9), (1503, 11), (1618, 1), (1619, 24), (1851, 17), (2293, 31)]
def cs77418 : List ℕ := [181, 0, 0, 41, 241, 34, 73, 255, 168, 25, 0, 221, 255, 157, 80, 0, 255, 189, 255, 2, 256, 73, 116, 255, 25, 20, 171, 0, 0, 139, 255, 108, 254, 255, 34, 255, 107, 255, 0, 9, 97, 255, 217, 209, 447, 89, 209, 248, 102, 256, 255, 0, 257, 204, 256, 256, 257, 241, 255, 256, 163, 255, 243, 65, 237, 257, 15, 405, 256, 255, 256, 255, 227, 218, 256, 258, 382, 256, 143, 256, 205, 513, 257, 256, 150, 219, 182, 257, 255, 256, 256, 255, 256, 427, 256, 257, 257, 256, 256, 256, 256, 304, 227, 256, 212, 256, 257, 257, 256, 559, 256, 256, 256, 257, 246, 257, 256, 256, 257, 212, 255, 258, 257, 257, 256, 247, 257, 257, 256, 258, 256, 225, 257, 256, 256, 257, 221, 198, 256, 256, 256, 220, 256, 256, 256, 218, 221, 256, 256, 257, 256, 245, 256, 256]
theorem node77418 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77418 support demand code
    entries77418 ((insert 39 (insert 27 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node77416 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    39 node77417 node77418
theorem node77405 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    27 node77415 node77416
def entries77413 : List (Fin 2295 × ℕ) := [(177, 12), (340, 1), (471, 24), (484, 8), (514, 7), (542, 13), (581, 4), (587, 18), (617, 22), (618, 17), (619, 9), (620, 3), (632, 20), (730, 16), (731, 15), (737, 23), (739, 12), (776, 3), (780, 23), (819, 6), (850, 7), (852, 22), (858, 1), (860, 30), (869, 1), (873, 11), (874, 19), (888, 7), (892, 33), (894, 30), (896, 13), (901, 4), (917, 9), (925, 20), (926, 30), (938, 1), (942, 9), (943, 12), (944, 6), (946, 24), (957, 22), (962, 31), (964, 23), (972, 15), (973, 49), (977, 5), (978, 27), (1006, 3), (1009, 3), (1011, 6), (1012, 13), (1040, 3), (1043, 2), (1100, 8), (1110, 16), (1111, 2), (1114, 10), (1122, 11), (1123, 10), (1143, 4), (1149, 11), (1167, 21), (1174, 2), (1175, 15), (1181, 14), (1183, 11), (1184, 3), (1186, 28), (1219, 1), (1253, 23), (1273, 13), (1279, 30), (1316, 3), (1346, 5), (1488, 2), (1517, 22), (1572, 14), (1585, 13), (1668, 3), (1683, 13), (1688, 1), (1705, 1), (1846, 7), (1864, 3), (1984, 19)]
def cs77413 : List ℕ := [23, 31, 24, 8, 45, 38, 45, 100, 53, 0, 7, 99, 99, 30, 35, 0, 98, 99, 100, 7, 100, 100, 30, 93, 54, 0, 63, 217, 0, 68, 99, 100, 101, 100, 18, 100, 23, 100, 12, 100, 0, 100, 44, 64, 245, 88, 197, 31, 80, 89, 101, 0, 99, 98, 99, 101, 99, 100, 100, 100, 100, 99, 71, 44, 99, 100, 7, 164, 100, 192, 68, 101, 99, 75, 98, 100, 142, 100, 78, 100, 100, 149, 100, 100, 100, 58, 81, 100, 100, 92, 99, 100, 100, 13, 101, 99, 100, 100, 102, 99, 99, 100, 72, 101, 62, 100, 100, 99, 98, 182, 100, 99, 100, 99, 101, 94, 100, 101, 99, 72, 101, 88, 98, 100, 100, 87, 98, 100, 95, 99, 100, 87, 100, 100, 99, 100, 93, 91, 100, 100, 100, 95, 100, 100, 101, 79, 95, 100, 98, 100, 88, 99, 100, 101]
theorem node77413 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 46 (insert 69 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77413 support demand code
    entries77413 ((insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 27 (insert 46 (insert 69 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries77414 : List (Fin 2295 × ℕ) := [(20, 1), (46, 12), (177, 10), (484, 20), (531, 24), (542, 30), (587, 21), (617, 3), (632, 41), (727, 17), (730, 12), (731, 14), (737, 1), (739, 21), (741, 7), (779, 5), (780, 14), (781, 11), (819, 4), (850, 10), (852, 7), (869, 26), (873, 9), (874, 37), (915, 2), (916, 20), (917, 17), (919, 16), (920, 14), (925, 5), (926, 26), (942, 5), (943, 18), (944, 23), (945, 12), (946, 23), (957, 9), (961, 11), (962, 30), (964, 16), (972, 8), (973, 49), (978, 27), (1009, 9), (1011, 5), (1012, 12), (1040, 4), (1043, 6), (1055, 4), (1100, 9), (1110, 13), (1113, 3), (1114, 2), (1123, 14), (1141, 6), (1143, 1), (1149, 16), (1155, 6), (1167, 23), (1175, 26), (1179, 14), (1181, 1), (1183, 11), (1184, 4), (1186, 24), (1223, 29), (1247, 3), (1253, 38), (1273, 10), (1316, 6), (1346, 4), (1356, 1), (1398, 12), (1433, 1), (1488, 3), (1585, 4), (1681, 8), (1842, 3), (1845, 1), (1846, 7)]
def cs77414 : List ℕ := [67, 3, 1, 11, 75, 20, 12, 77, 68, 0, 0, 96, 100, 72, 45, 0, 90, 99, 100, 0, 100, 13, 31, 100, 0, 1, 50, 0, 0, 72, 100, 98, 72, 100, 27, 100, 38, 100, 10, 99, 0, 99, 62, 55, 252, 83, 69, 47, 79, 99, 99, 0, 100, 86, 100, 99, 101, 100, 99, 99, 99, 99, 76, 50, 96, 98, 14, 128, 100, 171, 99, 99, 100, 65, 100, 99, 162, 99, 53, 99, 90, 129, 99, 101, 99, 58, 70, 101, 100, 82, 99, 94, 99, 0, 100, 100, 100, 99, 99, 99, 100, 112, 85, 99, 61, 76, 100, 99, 99, 173, 99, 100, 99, 100, 99, 100, 99, 101, 101, 80, 99, 100, 100, 99, 101, 97, 99, 98, 100, 99, 100, 98, 99, 100, 100, 100, 97, 99, 100, 100, 98, 99, 100, 99, 99, 90, 100, 99, 100, 100, 94, 100, 98, 100]
theorem node77414 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 69 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77414 support demand code
    entries77414 ((insert 27 (insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 69 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node77411 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 69 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 69 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    27 node77413 node77414
def entries77412 : List (Fin 2295 × ℕ) := [(23, 31), (46, 250), (49, 48), (177, 58), (340, 30), (527, 147), (531, 203), (587, 328), (632, 394), (664, 91), (692, 51), (727, 65), (728, 59), (729, 217), (730, 108), (731, 208), (737, 34), (739, 259), (741, 38), (779, 120), (819, 29), (852, 164), (858, 164), (869, 42), (874, 406), (888, 46), (915, 19), (916, 169), (917, 51), (918, 103), (919, 7), (920, 13), (923, 54), (925, 79), (926, 417), (934, 49), (938, 123), (942, 125), (943, 30), (944, 130), (945, 71), (946, 203), (957, 243), (961, 71), (962, 329), (964, 277), (972, 29), (973, 487), (978, 248), (1004, 3), (1009, 109), (1011, 49), (1012, 171), (1040, 49), (1100, 64), (1110, 113), (1113, 43), (1114, 36), (1119, 41), (1121, 35), (1123, 132), (1141, 75), (1143, 42), (1149, 139), (1155, 90), (1167, 265), (1174, 1), (1175, 247), (1179, 81), (1181, 77), (1183, 135), (1186, 224), (1223, 34), (1247, 24), (1253, 458), (1273, 64), (1279, 313), (1316, 84), (1398, 91), (1517, 31), (1585, 122), (1681, 83), (1845, 11), (1846, 79)]
def cs77412 : List ℕ := [492, 313, 0, 0, 687, 313, 445, 1000, 540, 0, 0, 878, 1000, 609, 250, 0, 805, 1000, 1001, 46, 1000, 250, 386, 805, 313, 0, 504, 587, 0, 785, 1000, 1000, 1000, 1000, 248, 1000, 458, 1000, 58, 1000, 49, 959, 521, 782, 2247, 1000, 198, 752, 731, 999, 1000, 0, 1000, 1000, 999, 1000, 1001, 965, 1001, 998, 1000, 1002, 643, 356, 999, 999, 127, 1672, 1001, 1735, 999, 1001, 1000, 815, 820, 1000, 1455, 1000, 677, 999, 1001, 1398, 710, 1001, 1000, 693, 549, 1000, 1000, 910, 999, 958, 999, 103, 1000, 1000, 1000, 1000, 999, 999, 1000, 1109, 973, 999, 466, 994, 1000, 1000, 1000, 1838, 1000, 1000, 999, 1000, 1000, 991, 1000, 999, 871, 784, 1000, 1000, 1000, 999, 999, 1000, 1001, 1000, 1000, 1000, 999, 1000, 1000, 1000, 1000, 1000, 874, 1000, 1000, 1000, 1000, 925, 1000, 1000, 927, 892, 1000, 1000, 983, 986, 923, 1000, 953, 1000]
theorem node77412 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77412 support demand code
    entries77412 ((insert 46 (insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node77407 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    46 node77411 node77412
def entries77409 : List (Fin 2295 × ℕ) := [(177, 34), (340, 72), (475, 30), (479, 67), (484, 51), (514, 45), (527, 4), (569, 13), (587, 40), (588, 41), (617, 26), (629, 109), (727, 32), (737, 6), (739, 1), (741, 7), (780, 53), (850, 41), (852, 39), (858, 32), (869, 18), (872, 38), (873, 32), (888, 18), (894, 71), (897, 1), (902, 22), (911, 32), (915, 55), (917, 37), (919, 20), (920, 10), (926, 44), (934, 23), (942, 16), (943, 16), (955, 20), (960, 51), (961, 22), (962, 70), (964, 46), (971, 16), (972, 90), (973, 115), (977, 30), (978, 39), (1007, 2), (1009, 22), (1012, 22), (1040, 4), (1041, 11), (1043, 19), (1044, 7), (1045, 17), (1060, 23), (1061, 27), (1072, 14), (1073, 65), (1110, 40), (1113, 5), (1123, 16), (1138, 12), (1149, 27), (1154, 12), (1166, 11), (1167, 67), (1174, 39), (1175, 28), (1178, 19), (1183, 34), (1186, 74), (1223, 42), (1253, 67), (1273, 29), (1279, 13), (1346, 38), (1402, 9), (1488, 8), (1517, 49), (1540, 1), (1572, 27), (1585, 16), (1673, 29), (1709, 9), (1846, 23)]
def cs77409 : List ℕ := [109, 42, 0, 71, 215, 73, 90, 257, 109, 0, 45, 257, 257, 70, 9, 0, 257, 257, 256, 18, 257, 109, 116, 211, 51, 0, 143, 257, 0, 175, 257, 256, 255, 257, 67, 256, 67, 480, 34, 256, 90, 255, 223, 146, 634, 161, 257, 255, 34, 255, 256, 0, 255, 230, 256, 256, 256, 205, 255, 255, 256, 143, 189, 133, 199, 256, 75, 464, 256, 0, 255, 256, 256, 255, 256, 256, 358, 257, 244, 256, 76, 219, 256, 255, 248, 223, 256, 255, 256, 257, 256, 256, 255, 0, 256, 256, 256, 255, 255, 257, 256, 256, 161, 211, 255, 233, 243, 256, 242, 534, 256, 256, 256, 217, 256, 256, 256, 255, 255, 261, 256, 231, 255, 256, 248, 231, 255, 255, 256, 255, 256, 256, 255, 256, 256, 255, 255, 241, 256, 255, 255, 254, 256, 256, 255, 227, 255, 256, 239, 255, 165, 236, 201, 252]
theorem node77409 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77409 support demand code
    entries77409 ((insert 69 (insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries77410 : List (Fin 2295 × ℕ) := [(20, 40), (46, 45), (177, 89), (340, 26), (507, 55), (527, 7), (542, 58), (583, 41), (617, 41), (664, 29), (729, 44), (737, 63), (739, 13), (741, 46), (781, 6), (852, 40), (869, 40), (873, 45), (874, 33), (888, 9), (894, 35), (895, 57), (915, 49), (916, 31), (920, 3), (925, 69), (926, 9), (934, 15), (938, 45), (942, 19), (943, 16), (955, 81), (957, 5), (960, 23), (962, 56), (964, 40), (972, 103), (973, 124), (977, 8), (978, 60), (1009, 25), (1012, 18), (1060, 12), (1061, 28), (1069, 21), (1072, 16), (1073, 72), (1110, 37), (1113, 38), (1114, 2), (1149, 21), (1154, 20), (1167, 71), (1174, 13), (1175, 34), (1179, 3), (1180, 21), (1181, 2), (1183, 16), (1185, 7), (1186, 61), (1223, 63), (1253, 81), (1273, 43), (1279, 53), (1346, 19), (1402, 51), (1488, 17), (1502, 3), (1572, 32), (1579, 1), (1585, 10), (1617, 9), (1673, 4), (1846, 36), (1901, 1), (2284, 15)]
def cs77410 : List ℕ := [144, 72, 0, 40, 184, 104, 45, 256, 185, 70, 0, 256, 256, 119, 103, 0, 256, 256, 257, 9, 255, 197, 89, 255, 178, 0, 256, 257, 0, 174, 255, 257, 177, 256, 47, 255, 138, 0, 89, 257, 15, 119, 42, 199, 610, 257, 256, 59, 89, 239, 257, 15, 256, 256, 255, 257, 255, 256, 157, 257, 214, 134, 142, 165, 255, 257, 13, 517, 257, 33, 257, 257, 257, 115, 256, 255, 304, 256, 213, 257, 104, 222, 256, 228, 172, 224, 255, 256, 255, 249, 242, 250, 255, 0, 257, 255, 257, 255, 256, 256, 255, 280, 150, 256, 254, 255, 228, 255, 256, 487, 256, 255, 255, 255, 257, 236, 258, 255, 255, 259, 225, 228, 255, 257, 211, 242, 254, 256, 224, 255, 255, 255, 256, 254, 256, 255, 245, 257, 255, 256, 255, 252, 255, 256, 255, 256, 255, 256, 255, 221, 152, 240, 210, 251]
theorem node77410 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 69 (insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs77410 support demand code
    entries77410 ((insert 37 (insert 69 (insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node77408 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    37 node77409 node77410
theorem node77406 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    69 node77407 node77408
theorem node77404 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    93 node77405 node77406
theorem node77402 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 36 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 109 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    51 node77403 node77404
#print axioms node77402
end OmissionResidualCover31Fused
