import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries88809 : List (Fin 2295 × ℕ) := [(164, 1)]
def cs88809 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node88809 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 81 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88809 support demand code
    entries88809 ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 95 (insert 81 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries88811 : List (Fin 2295 × ℕ) := [(892, 1)]
def cs88811 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node88811 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 81 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88811 support demand code
    entries88811 ((insert 95 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 55 (insert 81 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries88812 : List (Fin 2295 × ℕ) := [(4, 524), (37, 355), (72, 112), (75, 364), (92, 227), (472, 171), (483, 202), (491, 8), (552, 376), (581, 429), (583, 14), (585, 101), (622, 349), (624, 55), (625, 150), (632, 87), (675, 271), (737, 74), (741, 111), (743, 174), (781, 51), (812, 6), (817, 50), (819, 1), (842, 195), (851, 64), (852, 339), (853, 166), (855, 133), (865, 3), (867, 438), (870, 8), (885, 24), (886, 417), (888, 80), (891, 537), (894, 724), (895, 87), (896, 720), (908, 157), (920, 182), (922, 51), (925, 213), (938, 17), (952, 63), (957, 324), (959, 193), (971, 15), (972, 322), (973, 544), (984, 180), (985, 194), (1009, 203), (1011, 82), (1025, 30), (1048, 9), (1049, 19), (1069, 167), (1070, 37), (1107, 40), (1108, 163), (1122, 239), (1124, 97), (1130, 61), (1131, 225), (1133, 48), (1169, 73), (1178, 22), (1179, 79), (1184, 156), (1186, 183), (1275, 71), (1276, 39), (1285, 121), (1374, 15), (1400, 25), (1459, 3), (1466, 32), (1517, 115), (1572, 57), (1629, 84), (1641, 238), (1688, 30), (1705, 150), (1767, 250), (2090, 73), (2226, 103)]
def cs88812 : List ℕ := [353, 627, 421, 474, 1000, 959, 226, 1000, 1000, 0, 1001, 355, 1000, 348, 1000, 376, 1001, 1000, 1000, 538, 1001, 3079, 0, 821, 870, 3420, 693, 4404, 999, 481, 1001, 1001, 515, 1000, 416, 895, 2833, 1001, 467, 1001, 1000, 1001, 384, 825, 3623, 999, 4005, 0, 0, 1001, 1000, 1000, 1001, 1000, 1000, 879, 1001, 1001, 1000, 1001, 1000, 1001, 1001, 322, 999, 882, 999, 2961, 1001, 1844, 1000, 999, 792, 755, 1000, 998, 1171, 1001, 724, 1001, 999, 1410, 1001, 1000, 454, 691, 999, 897, 1000, 1001, 1001, 1000, 1000, 1000, 903, 174, 1000, 1000, 999, 1001, 1000, 1000, 850, 1001, 998, 1000, 1000, 1000, 1000, 777, 1000, 999, 865, 999, 806, 1000, 1001, 1000, 999, 999, 567, 982, 999, 1000, 1001, 820, 1000, 1000, 590, 999, 725, 617, 999, 1000, 877, 886, 807, 718, 1000, 1000, 1000, 758, 813, 1000, 1000, 892, 911, 963, 1000, 952, 1000, 868, 1001, 837]
theorem node88812 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 95 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88812 support demand code
    entries88812 ((insert 55 (insert 95 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node88810 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 95 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    55 node88811 node88812
theorem node88799 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    95 node88809 node88810
def entries88805 : List (Fin 2295 × ℕ) := [(162, 1)]
def cs88805 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node88805 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 105 (insert 93 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88805 support demand code
    entries88805 ((insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 105 (insert 93 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries88807 : List (Fin 2295 × ℕ) := [(896, 1)]
def cs88807 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node88807 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 93 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88807 support demand code
    entries88807 ((insert 105 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 88 (insert 93 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries88808 : List (Fin 2295 × ℕ) := [(4, 47), (37, 16), (75, 17), (92, 24), (179, 23), (215, 4), (472, 35), (475, 6), (550, 26), (585, 48), (623, 5), (624, 47), (675, 39), (781, 16), (842, 11), (847, 7), (852, 8), (853, 1), (860, 9), (865, 13), (867, 33), (870, 10), (886, 36), (888, 8), (891, 49), (894, 49), (895, 25), (908, 35), (920, 9), (925, 22), (937, 1), (952, 23), (957, 5), (958, 10), (972, 35), (973, 48), (984, 20), (985, 25), (1009, 17), (1011, 7), (1068, 13), (1069, 13), (1073, 18), (1096, 7), (1107, 4), (1108, 7), (1114, 9), (1122, 15), (1130, 8), (1131, 13), (1169, 19), (1178, 2), (1179, 17), (1212, 23), (1235, 14), (1252, 5), (1261, 2), (1273, 3), (1275, 6), (1276, 6), (1285, 29), (1400, 6), (1471, 15), (1517, 21), (1545, 4), (1573, 2), (1645, 13), (1669, 4), (1675, 2), (1728, 2), (1767, 9), (1785, 4), (1852, 5), (1859, 24), (1949, 17), (2074, 3), (2085, 8)]
def cs88808 : List ℕ := [33, 47, 51, 44, 72, 41, 45, 100, 101, 0, 69, 90, 101, 53, 70, 26, 95, 87, 100, 24, 100, 209, 23, 100, 90, 253, 60, 355, 100, 48, 100, 101, 99, 100, 17, 101, 291, 99, 39, 101, 100, 98, 6, 100, 258, 100, 315, 0, 23, 101, 99, 101, 101, 100, 101, 103, 100, 101, 100, 101, 100, 44, 100, 47, 100, 90, 101, 218, 99, 97, 98, 100, 64, 100, 100, 99, 129, 99, 64, 99, 100, 0, 100, 94, 61, 87, 100, 99, 30, 89, 100, 100, 100, 143, 101, 76, 100, 100, 100, 99, 99, 104, 98, 99, 100, 19, 100, 90, 98, 80, 100, 99, 99, 65, 68, 85, 99, 100, 99, 99, 83, 50, 98, 99, 100, 84, 79, 100, 59, 97, 99, 67, 99, 99, 97, 98, 61, 99, 99, 98, 99, 67, 99, 99, 99, 92, 88, 99, 99, 98, 99, 83, 99, 90]
theorem node88808 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 105 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88808 support demand code
    entries88808 ((insert 88 (insert 105 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node88806 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 105 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    88 node88807 node88808
theorem node88801 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 93 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    105 node88805 node88806
def entries88803 : List (Fin 2295 × ℕ) := [(4, 94), (37, 67), (60, 4), (75, 121), (92, 7), (244, 32), (273, 4), (472, 39), (474, 78), (514, 14), (550, 51), (552, 17), (625, 109), (632, 11), (639, 6), (675, 9), (779, 4), (781, 59), (842, 46), (843, 14), (847, 34), (849, 26), (851, 5), (852, 69), (860, 22), (867, 47), (870, 37), (886, 73), (888, 71), (891, 87), (894, 61), (895, 74), (896, 70), (914, 11), (920, 43), (925, 78), (946, 12), (952, 27), (957, 69), (960, 20), (966, 38), (972, 50), (973, 121), (984, 42), (985, 86), (1009, 17), (1025, 14), (1045, 8), (1056, 26), (1061, 7), (1069, 1), (1073, 32), (1100, 22), (1108, 10), (1122, 27), (1133, 7), (1140, 6), (1155, 24), (1169, 50), (1174, 41), (1175, 6), (1177, 13), (1178, 8), (1179, 69), (1186, 2), (1212, 55), (1247, 18), (1251, 4), (1253, 15), (1266, 15), (1273, 18), (1276, 6), (1323, 19), (1471, 50), (1488, 7), (1497, 24), (1517, 42), (1537, 53), (1572, 1), (1582, 17), (1629, 44), (1645, 55), (1675, 3), (1705, 7), (1767, 39), (1856, 5), (1864, 38), (1921, 15), (1991, 10)]
def cs88803 : List ℕ := [54, 94, 165, 160, 183, 137, 97, 254, 255, 0, 246, 210, 254, 60, 256, 85, 255, 255, 254, 138, 256, 481, 0, 200, 255, 700, 183, 857, 164, 216, 256, 256, 257, 255, 146, 226, 546, 256, 67, 478, 256, 257, 51, 247, 735, 256, 494, 17, 12, 255, 256, 256, 256, 255, 254, 255, 257, 256, 256, 256, 256, 150, 256, 202, 255, 231, 255, 715, 256, 174, 257, 256, 215, 130, 254, 256, 364, 257, 149, 256, 256, 25, 251, 256, 117, 191, 256, 256, 256, 203, 256, 256, 256, 70, 215, 251, 256, 257, 255, 256, 256, 256, 257, 235, 256, 255, 255, 219, 256, 202, 255, 256, 255, 205, 255, 255, 256, 256, 255, 257, 175, 256, 214, 255, 256, 212, 255, 257, 216, 257, 209, 255, 256, 257, 238, 256, 197, 256, 256, 257, 257, 257, 256, 256, 255, 256, 256, 256, 257, 256, 256, 235, 257, 226]
theorem node88803 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88803 support demand code
    entries88803 ((insert 93 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries88804 : List (Fin 2295 × ℕ) := [(4, 21), (37, 22), (75, 30), (92, 13), (472, 11), (475, 6), (550, 24), (579, 25), (580, 12), (583, 8), (625, 38), (639, 8), (781, 17), (842, 14), (843, 8), (851, 12), (852, 16), (859, 8), (867, 44), (870, 9), (886, 28), (888, 18), (891, 30), (892, 1), (894, 36), (895, 24), (896, 34), (920, 9), (925, 29), (946, 11), (952, 16), (957, 21), (960, 6), (966, 12), (972, 19), (973, 46), (984, 19), (985, 15), (1009, 8), (1011, 8), (1041, 3), (1045, 1), (1061, 2), (1073, 10), (1096, 3), (1100, 19), (1108, 5), (1110, 4), (1122, 12), (1123, 7), (1143, 6), (1149, 3), (1155, 7), (1169, 29), (1174, 9), (1175, 7), (1177, 8), (1179, 24), (1186, 11), (1212, 9), (1263, 16), (1266, 10), (1273, 7), (1275, 2), (1276, 2), (1297, 12), (1313, 8), (1323, 11), (1356, 9), (1572, 8), (1627, 14), (1645, 21), (1675, 13), (1785, 13), (1859, 28), (1866, 2), (1949, 6), (1991, 4), (2226, 12)]
def cs88804 : List ℕ := [64, 33, 34, 28, 86, 84, 42, 101, 89, 0, 100, 71, 100, 22, 99, 24, 93, 52, 69, 52, 100, 265, 0, 99, 49, 265, 81, 310, 71, 56, 101, 93, 101, 100, 25, 81, 212, 100, 22, 18, 100, 101, 26, 100, 251, 99, 240, 0, 11, 100, 94, 100, 99, 99, 101, 100, 100, 99, 101, 101, 100, 63, 100, 75, 99, 97, 100, 244, 101, 46, 101, 101, 100, 38, 100, 99, 136, 100, 48, 101, 100, 7, 100, 100, 26, 78, 99, 99, 99, 84, 101, 99, 100, 34, 99, 92, 100, 99, 99, 100, 100, 102, 100, 52, 99, 99, 99, 87, 100, 70, 100, 100, 94, 86, 77, 99, 97, 99, 100, 99, 69, 100, 97, 102, 100, 86, 99, 99, 92, 102, 76, 99, 101, 100, 97, 101, 81, 100, 101, 101, 100, 94, 100, 101, 100, 98, 101, 100, 100, 101, 100, 100, 92, 96]
theorem node88804 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 93 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88804 support demand code
    entries88804 ((insert 39 (insert 93 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node88802 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    39 node88803 node88804
theorem node88800 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    93 node88801 node88802
theorem node88789 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 69 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    81 node88799 node88800
def entries88795 : List (Fin 2295 × ℕ) := [(4, 227), (37, 382), (72, 82), (75, 250), (137, 151), (273, 43), (409, 16), (469, 108), (471, 68), (482, 224), (527, 116), (550, 78), (552, 9), (579, 63), (583, 95), (584, 295), (625, 592), (675, 74), (743, 10), (780, 69), (781, 138), (842, 14), (843, 74), (847, 23), (851, 237), (852, 106), (886, 229), (888, 8), (891, 352), (894, 375), (895, 266), (908, 170), (915, 419), (916, 78), (918, 279), (920, 97), (922, 83), (925, 93), (938, 28), (952, 52), (958, 250), (959, 184), (960, 265), (962, 11), (965, 3), (966, 38), (972, 142), (973, 501), (984, 137), (985, 242), (1006, 58), (1009, 139), (1012, 21), (1025, 1), (1045, 28), (1061, 1), (1068, 98), (1072, 13), (1073, 158), (1107, 27), (1113, 93), (1114, 24), (1123, 121), (1130, 7), (1154, 39), (1155, 12), (1169, 186), (1174, 150), (1175, 158), (1178, 2), (1179, 147), (1185, 2), (1186, 222), (1212, 90), (1235, 118), (1241, 99), (1261, 48), (1273, 72), (1275, 3), (1281, 67), (1285, 61), (1323, 13), (1400, 124), (1471, 64), (1488, 71), (1511, 229), (1516, 5), (1517, 480), (1535, 155), (1537, 101), (1572, 38), (1629, 161), (1636, 36), (1675, 39), (1770, 64), (1785, 71), (1852, 61), (1870, 59), (1949, 15), (1991, 77), (2286, 56)]
def cs88795 : List ℕ := [131, 684, 259, 357, 969, 1000, 709, 1000, 1000, 0, 832, 1001, 1001, 218, 898, 87, 1001, 1000, 1001, 545, 1001, 1926, 0, 991, 1001, 2473, 516, 3363, 999, 360, 1001, 2542, 855, 1000, 395, 742, 2344, 870, 464, 2662, 999, 1001, 119, 1001, 3147, 999, 1889, 0, 0, 1001, 1001, 999, 1000, 1001, 1000, 1000, 1001, 999, 1000, 1001, 1000, 597, 1001, 879, 1001, 1000, 998, 2982, 1001, 56, 1001, 999, 799, 1000, 1001, 1000, 1845, 1000, 977, 1001, 999, 1001, 1000, 1000, 250, 1000, 1001, 1001, 1363, 833, 1001, 1001, 999, 842, 752, 1001, 1000, 1000, 1000, 1002, 1001, 999, 999, 1002, 1000, 1000, 1000, 1002, 1001, 688, 1001, 1000, 1002, 628, 863, 1002, 1002, 1002, 1001, 1001, 918, 1000, 866, 1000, 1003, 948, 1000, 999, 999, 1000, 1001, 1000, 999, 1000, 1001, 1003, 848, 998, 1001, 1001, 1002, 999, 1000, 1001, 1001, 966, 1001, 999, 1000, 1000, 999, 989, 999, 1001]
theorem node88795 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88795 support demand code
    entries88795 ((insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries88797 : List (Fin 2295 × ℕ) := [(4, 41), (37, 29), (75, 46), (92, 35), (161, 2), (273, 13), (483, 59), (490, 4), (491, 9), (498, 25), (550, 15), (552, 21), (623, 6), (625, 32), (675, 35), (736, 5), (743, 2), (781, 6), (842, 5), (847, 53), (851, 3), (852, 32), (860, 5), (865, 21), (885, 9), (886, 25), (890, 4), (891, 18), (892, 4), (894, 71), (895, 45), (908, 17), (925, 6), (938, 3), (951, 19), (957, 3), (958, 24), (960, 29), (972, 23), (973, 54), (981, 5), (984, 16), (985, 17), (1025, 8), (1043, 1), (1045, 10), (1053, 3), (1056, 8), (1061, 7), (1068, 1), (1073, 21), (1100, 2), (1113, 5), (1119, 7), (1122, 3), (1123, 8), (1149, 5), (1169, 19), (1176, 7), (1177, 10), (1178, 9), (1179, 5), (1184, 3), (1185, 9), (1186, 27), (1217, 7), (1235, 2), (1261, 8), (1273, 10), (1293, 14), (1335, 6), (1488, 5), (1517, 54), (1556, 23), (1572, 15), (1641, 7), (1645, 3), (1705, 1), (1770, 5), (1856, 9), (2169, 5)]
def cs88797 : List ℕ := [12, 46, 60, 0, 76, 100, 67, 100, 100, 0, 67, 74, 101, 35, 87, 36, 100, 100, 100, 29, 100, 190, 0, 73, 100, 288, 62, 333, 58, 46, 100, 5, 92, 100, 65, 97, 263, 88, 29, 138, 100, 99, 30, 57, 308, 100, 251, 0, 0, 100, 99, 100, 82, 100, 100, 100, 100, 100, 101, 85, 96, 75, 99, 32, 79, 99, 100, 278, 99, 4, 94, 100, 33, 66, 100, 100, 129, 100, 71, 99, 100, 99, 100, 101, 33, 80, 100, 101, 100, 92, 99, 99, 100, 100, 74, 86, 100, 192, 99, 99, 99, 100, 101, 100, 100, 100, 101, 74, 93, 86, 99, 100, 100, 101, 72, 99, 100, 99, 100, 100, 100, 100, 91, 85, 100, 78, 100, 100, 100, 99, 100, 90, 100, 99, 101, 93, 100, 98, 100, 99, 100, 100, 99, 98, 100, 100, 99, 100, 99, 99, 86, 100, 95, 100]
theorem node88797 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 39 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88797 support demand code
    entries88797 ((insert 31 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 97 (insert 39 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries88798 : List (Fin 2295 × ℕ) := [(4, 41), (37, 30), (72, 6), (75, 46), (91, 2), (92, 37), (273, 4), (472, 19), (483, 17), (491, 14), (498, 22), (550, 8), (552, 56), (623, 23), (625, 41), (743, 2), (780, 28), (781, 3), (847, 19), (849, 4), (851, 30), (855, 7), (867, 20), (885, 2), (886, 32), (888, 11), (891, 37), (892, 9), (894, 60), (896, 67), (908, 2), (920, 5), (925, 22), (938, 8), (952, 7), (957, 13), (958, 8), (959, 10), (966, 8), (972, 16), (973, 54), (981, 1), (984, 18), (985, 27), (1025, 6), (1041, 9), (1043, 5), (1044, 5), (1056, 5), (1071, 9), (1073, 11), (1095, 8), (1096, 12), (1100, 12), (1123, 13), (1131, 20), (1140, 1), (1149, 1), (1169, 22), (1178, 9), (1179, 13), (1184, 4), (1185, 12), (1186, 23), (1198, 7), (1212, 1), (1217, 4), (1258, 3), (1273, 6), (1335, 1), (1400, 18), (1417, 2), (1517, 33), (1669, 4), (1689, 7), (1770, 2), (1856, 23), (1859, 14), (2074, 3), (2085, 6), (2226, 12)]
def cs88798 : List ℕ := [39, 55, 42, 23, 78, 86, 73, 100, 100, 0, 79, 77, 100, 46, 100, 64, 100, 99, 101, 53, 99, 226, 0, 100, 101, 295, 91, 377, 84, 53, 99, 5, 93, 100, 29, 100, 247, 100, 36, 70, 100, 100, 70, 99, 298, 100, 269, 0, 0, 101, 100, 99, 90, 99, 100, 114, 99, 100, 101, 72, 100, 68, 99, 58, 100, 96, 99, 291, 100, 76, 100, 100, 72, 101, 100, 100, 148, 98, 68, 99, 89, 87, 99, 100, 22, 69, 101, 70, 100, 84, 100, 100, 98, 91, 67, 100, 99, 0, 100, 100, 100, 99, 72, 100, 100, 99, 100, 68, 94, 86, 99, 99, 84, 32, 100, 99, 101, 100, 100, 100, 54, 93, 100, 91, 100, 77, 96, 102, 83, 101, 99, 81, 101, 99, 101, 97, 75, 100, 100, 100, 100, 87, 99, 100, 100, 101, 99, 100, 86, 100, 100, 100, 101, 100]
theorem node88798 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 97 (insert 31 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88798 support demand code
    entries88798 ((insert 97 (insert 31 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node88796 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    97 node88797 node88798
theorem node88791 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    31 node88795 node88796
def entries88793 : List (Fin 2295 × ℕ) := [(4, 3290), (37, 3621), (72, 276), (75, 4130), (92, 4074), (475, 2204), (479, 135), (483, 1803), (552, 7353), (572, 645), (579, 2995), (583, 725), (618, 1115), (623, 972), (625, 2309), (675, 3628), (743, 517), (780, 1217), (851, 2165), (855, 86), (858, 920), (867, 3935), (874, 656), (886, 4392), (891, 1838), (894, 4213), (895, 810), (896, 2408), (925, 2880), (933, 522), (938, 1458), (951, 31), (952, 654), (957, 875), (958, 564), (959, 2044), (960, 2227), (962, 327), (966, 429), (969, 339), (972, 831), (973, 4797), (984, 1857), (985, 1953), (1009, 854), (1041, 597), (1068, 182), (1069, 501), (1072, 344), (1073, 1406), (1100, 940), (1108, 521), (1123, 1244), (1141, 400), (1143, 247), (1155, 984), (1169, 2825), (1174, 527), (1176, 56), (1177, 1589), (1178, 608), (1179, 884), (1186, 1277), (1212, 579), (1223, 157), (1235, 842), (1238, 845), (1261, 700), (1263, 488), (1273, 559), (1297, 1799), (1323, 564), (1502, 206), (1535, 2281), (1556, 346), (1572, 717), (1641, 164), (1657, 1289), (1675, 144), (1773, 872), (1791, 338), (1845, 697), (1846, 7), (1861, 1515), (1866, 1339), (1887, 716), (1949, 274), (1991, 622), (2074, 1606), (2085, 1084), (2169, 317), (2204, 463)]
def cs88793 : List ℕ := [5145, 4579, 845, 5058, 9591, 5510, 3131, 10000, 9690, 0, 10000, 7349, 10000, 4730, 10001, 7353, 10001, 7710, 9874, 6547, 10000, 18623, 0, 10000, 10001, 29137, 8013, 30117, 5838, 5146, 10000, 7786, 7938, 10000, 527, 9999, 24442, 9999, 3897, 317, 10000, 9999, 8369, 10000, 21118, 10000, 27690, 0, 0, 10001, 9999, 9999, 10000, 9204, 10000, 10000, 10001, 9999, 10001, 10000, 10001, 6553, 10000, 4060, 10000, 10000, 10000, 25844, 10000, 3064, 9765, 10000, 9999, 10001, 10000, 10001, 15841, 10000, 4642, 9999, 9999, 10000, 9998, 17505, 1390, 10000, 8684, 9415, 10000, 7576, 10000, 8607, 9998, 8759, 8135, 9999, 9999, 10001, 9999, 10000, 10000, 10333, 10000, 10000, 9999, 10000, 10001, 8172, 9999, 5065, 10000, 10000, 9999, 9448, 9744, 9999, 9999, 9999, 10000, 9999, 9136, 9958, 9248, 9999, 10000, 8476, 10000, 9999, 10000, 9999, 9999, 10000, 10000, 10000, 9999, 9999, 8187, 10000, 10000, 10000, 10000, 9477, 10000, 9998, 9999, 10000, 9999, 9999, 10001, 9999, 10000, 9999, 8253, 9995]
theorem node88793 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88793 support demand code
    entries88793 ((insert 39 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 83 (insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries88794 : List (Fin 2295 × ℕ) := [(4, 424), (37, 161), (72, 227), (75, 349), (92, 318), (179, 114), (273, 151), (351, 1), (479, 25), (483, 110), (484, 113), (507, 220), (550, 143), (579, 110), (583, 222), (625, 417), (675, 361), (736, 28), (737, 25), (742, 87), (743, 47), (779, 72), (781, 263), (842, 211), (843, 133), (844, 136), (851, 228), (855, 23), (858, 220), (867, 318), (886, 509), (891, 341), (892, 144), (894, 443), (895, 61), (896, 431), (922, 89), (938, 74), (952, 110), (957, 94), (958, 336), (960, 296), (972, 52), (973, 482), (977, 29), (984, 317), (985, 116), (1009, 301), (1011, 52), (1045, 56), (1061, 5), (1068, 49), (1069, 31), (1073, 164), (1100, 111), (1113, 35), (1122, 49), (1123, 76), (1130, 25), (1131, 66), (1141, 30), (1148, 38), (1155, 74), (1169, 145), (1174, 88), (1175, 82), (1177, 43), (1178, 48), (1179, 183), (1186, 76), (1212, 260), (1263, 226), (1273, 109), (1535, 218), (1572, 145), (1645, 4), (1689, 11), (1861, 106), (1866, 220), (1949, 66), (1991, 38)]
def cs88794 : List ℕ := [462, 424, 0, 326, 961, 407, 440, 999, 811, 220, 1000, 326, 1000, 318, 1000, 143, 867, 1000, 1000, 379, 1000, 2327, 114, 999, 473, 2945, 842, 2985, 866, 463, 1000, 890, 953, 999, 170, 853, 1949, 1000, 502, 89, 1000, 1000, 0, 1000, 2738, 1002, 2985, 0, 114, 999, 670, 1000, 1001, 1000, 1000, 1001, 1001, 1001, 765, 999, 994, 814, 968, 639, 999, 1001, 1001, 2471, 1001, 575, 1000, 1000, 632, 568, 1000, 1002, 1607, 1000, 443, 1001, 1000, 776, 1001, 155, 275, 1001, 1002, 980, 1001, 937, 1001, 1001, 999, 982, 637, 1002, 1000, 1000, 1001, 1001, 1002, 1245, 1000, 1000, 1002, 1000, 1001, 817, 826, 728, 1000, 1001, 806, 1000, 718, 1002, 1001, 1001, 1001, 1002, 839, 1001, 1002, 902, 1000, 966, 1002, 1002, 979, 994, 1000, 878, 1001, 1001, 905, 874, 871, 1001, 1000, 1001, 1001, 984, 925, 973, 1001, 1002, 1001, 1001, 1002, 1002, 1001, 1002, 1001, 1001]
theorem node88794 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 83 (insert 39 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88794 support demand code
    entries88794 ((insert 83 (insert 39 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node88792 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    83 node88793 node88794
theorem node88790 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    39 node88791 node88792
theorem node88753 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 36 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    69 node88789 node88790
def entries88785 : List (Fin 2295 × ℕ) := [(37, 73), (75, 18), (92, 78), (137, 58), (164, 54), (469, 79), (471, 15), (474, 130), (479, 10), (572, 94), (579, 9), (583, 110), (585, 33), (731, 32), (743, 4), (781, 8), (873, 88), (885, 1), (886, 31), (888, 74), (894, 115), (915, 133), (917, 42), (918, 3), (920, 29), (921, 6), (922, 33), (925, 17), (934, 43), (944, 17), (957, 16), (958, 2), (960, 15), (969, 33), (971, 35), (972, 21), (973, 128), (984, 21), (985, 64), (1006, 30), (1009, 12), (1010, 9), (1011, 9), (1025, 31), (1043, 3), (1045, 2), (1056, 9), (1061, 31), (1073, 30), (1089, 16), (1107, 10), (1108, 1), (1122, 41), (1155, 22), (1169, 53), (1171, 20), (1174, 9), (1176, 21), (1177, 18), (1178, 9), (1179, 41), (1186, 42), (1188, 9), (1189, 94), (1204, 21), (1212, 31), (1226, 41), (1251, 1), (1261, 8), (1273, 10), (1275, 11), (1293, 25), (1308, 2), (1313, 36), (1449, 35), (1459, 30), (1488, 12), (1497, 10), (1500, 7), (1511, 32), (1517, 15), (1607, 22), (1622, 59), (1629, 151), (1636, 7), (1675, 28), (1705, 30), (1767, 29), (1770, 29), (1785, 27), (1991, 15)]
def cs88785 : List ℕ := [94, 255, 159, 248, 193, 170, 47, 256, 256, 0, 256, 256, 256, 187, 256, 0, 256, 256, 610, 241, 256, 496, 0, 251, 256, 786, 256, 976, 0, 95, 256, 766, 183, 256, 182, 256, 0, 256, 73, 880, 205, 256, 72, 256, 896, 256, 490, 0, 89, 255, 256, 256, 256, 256, 255, 298, 256, 256, 177, 255, 254, 257, 257, 168, 137, 256, 256, 678, 255, 257, 137, 257, 252, 177, 255, 255, 416, 256, 268, 256, 257, 257, 256, 256, 162, 216, 257, 255, 257, 210, 254, 253, 358, 255, 209, 256, 256, 256, 257, 254, 254, 255, 176, 157, 256, 255, 256, 254, 255, 189, 255, 255, 256, 189, 256, 254, 254, 256, 255, 256, 257, 256, 254, 242, 255, 253, 255, 256, 257, 254, 214, 248, 255, 255, 255, 254, 230, 240, 255, 255, 255, 255, 255, 254, 255, 256, 240, 255, 255, 251, 256, 240, 243, 244]
theorem node88785 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88785 support demand code
    entries88785 ((insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries88787 : List (Fin 2295 × ℕ) := [(37, 358), (46, 144), (75, 357), (92, 21), (137, 101), (164, 174), (273, 71), (475, 144), (484, 182), (507, 94), (540, 41), (572, 369), (576, 155), (617, 5), (731, 63), (737, 268), (780, 257), (781, 106), (784, 23), (797, 7), (833, 90), (847, 27), (849, 56), (852, 210), (860, 188), (867, 283), (870, 60), (873, 385), (886, 419), (888, 147), (894, 744), (896, 359), (925, 119), (933, 38), (934, 275), (938, 104), (957, 241), (958, 194), (970, 28), (972, 153), (973, 501), (984, 185), (985, 314), (1025, 121), (1043, 75), (1049, 42), (1055, 40), (1073, 53), (1107, 41), (1108, 58), (1119, 58), (1122, 97), (1141, 8), (1143, 20), (1149, 21), (1153, 32), (1155, 152), (1160, 103), (1169, 208), (1176, 87), (1177, 123), (1178, 30), (1179, 213), (1188, 177), (1189, 394), (1212, 167), (1226, 226), (1228, 66), (1251, 17), (1261, 152), (1266, 55), (1293, 109), (1296, 60), (1316, 1), (1323, 75), (1449, 21), (1502, 81), (1517, 152), (1663, 7), (1669, 11), (1705, 36), (1770, 131), (1773, 64), (1859, 239), (2001, 24)]
def cs88787 : List ℕ := [370, 525, 421, 200, 604, 970, 599, 1001, 1000, 94, 640, 595, 1000, 466, 1000, 0, 1001, 1001, 1733, 874, 1001, 1842, 0, 835, 154, 2777, 1000, 2619, 0, 565, 1001, 60, 1001, 1000, 608, 1000, 0, 1000, 358, 880, 783, 993, 64, 1000, 2897, 1001, 1892, 0, 466, 1000, 1000, 1000, 1000, 1001, 1000, 1150, 1000, 1000, 945, 1000, 1000, 1000, 1001, 101, 783, 1001, 1000, 2890, 1001, 999, 822, 1001, 779, 565, 830, 1519, 1639, 882, 744, 1000, 987, 999, 1000, 824, 620, 946, 1001, 1000, 1000, 792, 1000, 1000, 1649, 998, 720, 1000, 999, 999, 1001, 999, 1000, 1000, 998, 1000, 1001, 999, 1000, 547, 999, 564, 1000, 999, 1000, 823, 992, 1000, 998, 1000, 999, 1001, 999, 1000, 1000, 991, 1000, 737, 1000, 1000, 753, 998, 1001, 1000, 999, 1000, 1000, 807, 928, 999, 1001, 999, 1000, 999, 1000, 1000, 977, 980, 964, 1000, 1001, 859, 1000, 968, 931, 1000]
theorem node88787 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 39 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88787 support demand code
    entries88787 ((insert 31 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 75 (insert 39 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries88788 : List (Fin 2295 × ℕ) := [(4, 29), (37, 69), (46, 40), (75, 68), (92, 13), (137, 24), (159, 60), (164, 42), (273, 98), (484, 16), (572, 24), (640, 9), (737, 133), (741, 16), (743, 41), (815, 2), (817, 2), (852, 32), (855, 70), (867, 57), (873, 121), (886, 49), (888, 111), (894, 170), (896, 93), (934, 19), (952, 15), (957, 32), (958, 28), (959, 3), (960, 11), (969, 8), (972, 44), (973, 127), (981, 55), (984, 58), (1025, 10), (1042, 33), (1043, 26), (1056, 8), (1072, 13), (1073, 28), (1110, 10), (1113, 11), (1114, 41), (1122, 41), (1131, 6), (1133, 5), (1141, 16), (1155, 12), (1169, 63), (1175, 21), (1185, 19), (1186, 40), (1189, 79), (1198, 3), (1212, 26), (1219, 2), (1223, 50), (1226, 68), (1235, 15), (1261, 33), (1293, 31), (1296, 25), (1454, 2), (1497, 8), (1500, 53), (1517, 53), (1545, 47), (1675, 38), (1705, 22), (1770, 33), (1846, 7), (1859, 43), (1866, 17), (1887, 9), (2001, 38)]
def cs88788 : List ℕ := [146, 143, 79, 22, 193, 256, 153, 256, 255, 0, 166, 165, 256, 162, 257, 0, 209, 256, 419, 204, 255, 514, 0, 255, 80, 657, 256, 674, 0, 149, 256, 25, 227, 256, 135, 255, 0, 256, 69, 247, 67, 255, 38, 188, 779, 240, 460, 0, 121, 256, 256, 255, 253, 256, 256, 257, 256, 255, 242, 256, 119, 257, 255, 24, 231, 256, 255, 697, 256, 256, 166, 258, 223, 227, 256, 0, 518, 255, 170, 255, 256, 236, 256, 204, 165, 131, 232, 189, 257, 256, 256, 240, 439, 255, 240, 255, 256, 255, 258, 256, 257, 256, 256, 255, 256, 255, 256, 229, 216, 129, 256, 256, 257, 219, 210, 249, 256, 256, 256, 257, 257, 254, 257, 255, 255, 198, 255, 256, 230, 256, 255, 252, 256, 256, 256, 256, 184, 197, 256, 257, 257, 187, 255, 256, 256, 245, 214, 256, 241, 256, 247, 257, 202, 224]
theorem node88788 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 31 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88788 support demand code
    entries88788 ((insert 75 (insert 31 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node88786 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    75 node88787 node88788
theorem node88777 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    31 node88785 node88786
def entries88783 : List (Fin 2295 × ℕ) := [(4, 296), (37, 545), (46, 284), (72, 107), (164, 131), (387, 9), (475, 141), (479, 228), (484, 19), (507, 119), (572, 256), (579, 266), (581, 23), (583, 144), (731, 223), (737, 222), (741, 54), (742, 97), (743, 79), (779, 96), (780, 103), (781, 193), (797, 24), (844, 262), (852, 175), (855, 102), (867, 404), (873, 405), (886, 404), (888, 199), (892, 2), (894, 450), (896, 369), (925, 97), (933, 57), (934, 317), (938, 76), (957, 13), (958, 207), (960, 126), (972, 106), (973, 482), (984, 252), (985, 219), (1009, 225), (1043, 81), (1068, 7), (1069, 52), (1070, 74), (1073, 161), (1090, 30), (1100, 59), (1122, 112), (1123, 36), (1143, 2), (1149, 27), (1152, 18), (1155, 119), (1169, 266), (1174, 153), (1175, 100), (1179, 149), (1186, 28), (1188, 172), (1212, 176), (1226, 60), (1247, 18), (1261, 34), (1263, 141), (1266, 108), (1269, 47), (1273, 70), (1275, 54), (1293, 144), (1323, 73), (1488, 49), (1618, 20), (1674, 64), (1705, 29), (1785, 249), (1859, 334), (1991, 35), (2001, 32), (2073, 28), (2283, 1), (2288, 30)]
def cs88783 : List ℕ := [596, 296, 0, 141, 699, 1000, 682, 999, 982, 139, 760, 475, 999, 405, 1000, 0, 757, 906, 1140, 1000, 1000, 2123, 0, 999, 139, 3106, 999, 2264, 107, 597, 1000, 802, 730, 999, 253, 999, 0, 1000, 652, 0, 999, 1000, 313, 999, 2276, 1000, 1929, 0, 475, 1000, 999, 1315, 1001, 996, 1001, 1000, 1001, 1001, 999, 1140, 1001, 999, 1001, 172, 775, 999, 1000, 2422, 1001, 1000, 1213, 999, 897, 455, 1000, 1001, 1710, 1000, 450, 1000, 930, 1000, 1001, 632, 659, 773, 1000, 1000, 1000, 999, 1000, 1000, 1769, 1000, 774, 1001, 1000, 1001, 1000, 1000, 1001, 1255, 980, 1000, 1001, 1001, 1002, 743, 1000, 529, 1000, 999, 1000, 984, 925, 1000, 1001, 999, 1001, 1001, 999, 1001, 1000, 989, 1000, 1000, 1001, 1000, 1001, 1001, 999, 1001, 1002, 1000, 1001, 953, 895, 932, 1001, 1000, 903, 1001, 971, 1000, 946, 953, 1001, 1000, 1001, 957, 1001, 965, 882, 929]
theorem node88783 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 51 (insert 70 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88783 support demand code
    entries88783 ((insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 59 (insert 51 (insert 70 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries88784 : List (Fin 2295 × ℕ) := [(4, 77), (37, 101), (46, 87), (72, 31), (75, 14), (137, 65), (164, 33), (179, 31), (475, 18), (529, 24), (572, 68), (579, 111), (731, 17), (741, 34), (743, 25), (779, 82), (781, 39), (797, 24), (844, 65), (852, 62), (855, 59), (867, 77), (873, 101), (886, 77), (888, 87), (892, 11), (894, 121), (896, 95), (925, 18), (934, 18), (952, 20), (957, 40), (958, 55), (960, 31), (969, 1), (971, 1), (972, 20), (973, 118), (984, 69), (985, 70), (1009, 42), (1021, 7), (1023, 2), (1025, 1), (1043, 2), (1068, 3), (1069, 10), (1070, 5), (1073, 32), (1100, 30), (1108, 10), (1122, 42), (1123, 3), (1133, 8), (1155, 30), (1162, 17), (1169, 52), (1174, 56), (1175, 30), (1179, 17), (1186, 36), (1188, 48), (1212, 40), (1258, 14), (1261, 18), (1266, 20), (1275, 1), (1281, 12), (1293, 27), (1323, 7), (1500, 36), (1528, 1), (1545, 13), (1560, 10), (1572, 10), (1669, 4), (1674, 27), (1785, 20), (1791, 12), (1859, 96), (1861, 6), (1887, 4), (1991, 12), (2073, 8), (2240, 15), (2286, 15)]
def cs88784 : List ℕ := [179, 92, 12, 36, 139, 256, 210, 256, 178, 0, 148, 147, 256, 140, 256, 0, 256, 256, 331, 256, 256, 534, 31, 256, 27, 777, 256, 577, 31, 179, 256, 162, 138, 256, 86, 256, 0, 256, 163, 27, 151, 255, 47, 256, 618, 257, 448, 0, 132, 95, 256, 420, 256, 256, 256, 255, 256, 256, 202, 80, 256, 222, 256, 88, 162, 256, 256, 601, 256, 255, 355, 256, 220, 102, 255, 256, 523, 256, 121, 256, 256, 255, 256, 164, 176, 148, 241, 255, 297, 256, 256, 257, 471, 256, 201, 254, 255, 255, 256, 256, 256, 281, 221, 252, 255, 255, 255, 189, 256, 124, 256, 256, 255, 254, 199, 255, 255, 256, 256, 256, 255, 255, 255, 255, 255, 221, 255, 256, 255, 255, 255, 256, 255, 256, 254, 246, 228, 215, 255, 256, 255, 255, 225, 256, 254, 218, 256, 256, 256, 257, 255, 256, 256, 229]
theorem node88784 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 70 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88784 support demand code
    entries88784 ((insert 59 (insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 51 (insert 70 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node88781 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 70 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 51 (insert 70 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    59 node88783 node88784
def entries88782 : List (Fin 2295 × ℕ) := [(4, 31), (46, 21), (159, 37), (164, 10), (179, 5), (352, 3), (475, 32), (479, 39), (496, 14), (507, 35), (581, 16), (583, 28), (731, 16), (737, 14), (741, 4), (742, 3), (743, 5), (779, 17), (781, 24), (844, 35), (852, 6), (855, 3), (858, 13), (867, 37), (873, 24), (886, 48), (888, 41), (894, 34), (896, 33), (925, 8), (934, 27), (938, 30), (957, 3), (958, 14), (960, 8), (969, 4), (970, 6), (972, 4), (973, 46), (977, 1), (984, 19), (985, 18), (1009, 13), (1011, 11), (1012, 5), (1039, 1), (1073, 3), (1100, 23), (1108, 8), (1114, 6), (1123, 7), (1128, 3), (1141, 1), (1149, 4), (1153, 1), (1155, 18), (1169, 28), (1174, 3), (1175, 24), (1179, 22), (1186, 1), (1188, 21), (1212, 17), (1226, 4), (1258, 1), (1261, 9), (1266, 2), (1293, 7), (1323, 8), (1488, 7), (1528, 2), (1667, 3), (1668, 4), (1785, 25), (1859, 15), (1887, 6), (1991, 3), (2072, 3), (2074, 9), (2240, 8)]
def cs88782 : List ℕ := [50, 31, 0, 32, 76, 18, 49, 95, 45, 35, 62, 47, 99, 24, 77, 0, 64, 100, 109, 41, 100, 204, 5, 99, 35, 244, 100, 223, 0, 51, 99, 97, 90, 100, 27, 100, 0, 100, 5, 0, 80, 93, 25, 100, 215, 54, 217, 0, 46, 90, 100, 0, 100, 90, 101, 107, 101, 99, 100, 100, 100, 100, 101, 40, 61, 100, 100, 247, 99, 100, 122, 100, 100, 51, 79, 99, 166, 101, 34, 100, 82, 101, 99, 74, 61, 100, 100, 100, 103, 81, 99, 100, 158, 100, 74, 101, 100, 100, 101, 98, 101, 106, 100, 100, 101, 101, 100, 79, 99, 44, 101, 100, 101, 95, 101, 100, 99, 101, 100, 101, 101, 101, 99, 100, 100, 91, 101, 100, 101, 99, 100, 101, 101, 100, 100, 99, 79, 99, 101, 100, 101, 101, 100, 99, 100, 101, 100, 100, 101, 92, 100, 100, 98, 82]
theorem node88782 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88782 support demand code
    entries88782 ((insert 51 (insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 70 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node88779 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 70 (insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    51 node88781 node88782
def entries88780 : List (Fin 2295 × ℕ) := [(4, 77), (37, 106), (46, 37), (72, 47), (137, 10), (350, 9), (475, 57), (496, 49), (507, 9), (572, 92), (581, 65), (583, 75), (737, 87), (797, 6), (833, 32), (844, 30), (852, 57), (858, 85), (867, 21), (873, 97), (886, 106), (888, 57), (892, 26), (894, 138), (896, 76), (924, 18), (925, 33), (933, 21), (934, 41), (957, 12), (958, 37), (969, 38), (973, 112), (984, 53), (985, 81), (1009, 4), (1011, 2), (1012, 8), (1025, 23), (1043, 8), (1069, 25), (1073, 27), (1100, 11), (1119, 2), (1123, 47), (1141, 16), (1149, 16), (1155, 41), (1169, 91), (1173, 3), (1174, 22), (1175, 31), (1178, 12), (1179, 30), (1186, 8), (1188, 34), (1212, 41), (1219, 27), (1226, 44), (1247, 5), (1261, 34), (1273, 21), (1277, 3), (1293, 2), (1297, 12), (1308, 10), (1323, 22), (1488, 9), (1500, 11), (1675, 36), (1785, 58), (1859, 93), (1887, 17), (1991, 25), (2021, 10)]
def cs88780 : List ℕ := [123, 104, 0, 84, 134, 199, 215, 207, 232, 9, 162, 177, 256, 97, 255, 0, 236, 256, 283, 255, 256, 511, 0, 256, 9, 716, 255, 606, 47, 131, 256, 189, 210, 255, 83, 255, 0, 256, 153, 27, 213, 215, 94, 255, 581, 256, 486, 0, 89, 255, 201, 255, 255, 240, 255, 256, 255, 213, 195, 255, 157, 255, 255, 85, 255, 196, 255, 591, 256, 256, 0, 256, 212, 127, 248, 161, 408, 256, 141, 256, 238, 211, 256, 255, 110, 174, 256, 182, 256, 199, 256, 256, 376, 256, 216, 256, 256, 256, 256, 256, 257, 260, 244, 135, 255, 256, 255, 173, 258, 112, 256, 256, 229, 246, 238, 257, 257, 256, 256, 256, 223, 256, 257, 257, 255, 226, 257, 256, 256, 256, 257, 256, 256, 256, 257, 257, 240, 245, 257, 257, 257, 246, 256, 255, 256, 229, 219, 257, 255, 257, 256, 226, 208, 248]
theorem node88780 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88780 support demand code
    entries88780 ((insert 70 (insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node88778 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    70 node88779 node88780
theorem node88771 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 92 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    39 node88777 node88778
def entries88773 : List (Fin 2295 × ℕ) := [(4, 115), (37, 93), (46, 64), (72, 29), (75, 47), (92, 25), (137, 17), (159, 23), (307, 4), (475, 65), (482, 9), (571, 41), (585, 35), (639, 9), (730, 112), (731, 75), (743, 14), (833, 19), (842, 10), (843, 47), (846, 12), (852, 104), (853, 22), (867, 134), (873, 69), (885, 2), (886, 123), (887, 10), (892, 90), (894, 185), (896, 155), (915, 30), (917, 61), (920, 22), (921, 23), (925, 60), (933, 15), (938, 15), (957, 85), (958, 25), (969, 6), (971, 28), (973, 111), (984, 86), (985, 59), (1009, 13), (1025, 36), (1041, 11), (1049, 7), (1069, 47), (1070, 6), (1073, 10), (1089, 7), (1090, 23), (1096, 14), (1100, 13), (1108, 42), (1122, 54), (1130, 7), (1131, 10), (1155, 18), (1169, 16), (1171, 20), (1174, 20), (1175, 21), (1178, 4), (1179, 71), (1186, 37), (1212, 16), (1231, 33), (1235, 1), (1263, 48), (1273, 41), (1323, 8), (1374, 43), (1523, 17), (1629, 10), (1675, 1), (1705, 25), (1770, 65), (1859, 47), (1886, 28)]
def cs88773 : List ℕ := [112, 192, 0, 65, 247, 236, 111, 256, 256, 0, 221, 112, 256, 94, 256, 0, 208, 256, 314, 172, 256, 676, 0, 255, 9, 839, 148, 863, 29, 112, 256, 256, 182, 255, 140, 256, 0, 256, 122, 256, 153, 256, 1, 255, 956, 257, 693, 0, 187, 256, 256, 256, 257, 255, 255, 308, 256, 256, 256, 255, 256, 256, 257, 28, 156, 191, 257, 871, 255, 546, 178, 256, 250, 228, 255, 257, 295, 255, 235, 256, 187, 256, 256, 256, 256, 207, 209, 174, 263, 243, 254, 256, 0, 256, 256, 256, 256, 164, 257, 255, 256, 256, 37, 224, 256, 254, 256, 200, 255, 197, 255, 257, 256, 199, 228, 255, 244, 256, 256, 256, 221, 237, 255, 255, 255, 160, 255, 257, 216, 256, 225, 168, 256, 257, 243, 255, 255, 202, 256, 256, 255, 256, 183, 255, 255, 256, 256, 245, 256, 255, 256, 197, 235, 256]
theorem node88773 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88773 support demand code
    entries88773 ((insert 92 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries88775 : List (Fin 2295 × ℕ) := [(4, 96), (37, 76), (46, 71), (72, 47), (75, 42), (92, 5), (137, 45), (177, 35), (273, 4), (351, 4), (475, 61), (479, 8), (491, 14), (507, 68), (512, 21), (639, 1), (741, 24), (743, 27), (780, 68), (833, 16), (842, 15), (843, 26), (847, 3), (852, 133), (857, 1), (867, 109), (873, 73), (885, 27), (886, 117), (888, 26), (892, 37), (894, 173), (896, 108), (915, 52), (917, 88), (918, 8), (920, 17), (925, 8), (938, 36), (945, 35), (946, 79), (957, 64), (958, 43), (959, 18), (969, 22), (970, 3), (973, 114), (984, 79), (985, 62), (1012, 1), (1025, 8), (1041, 21), (1045, 15), (1049, 23), (1052, 18), (1069, 19), (1073, 12), (1090, 19), (1099, 28), (1100, 28), (1107, 11), (1108, 11), (1114, 12), (1123, 35), (1148, 3), (1149, 2), (1153, 9), (1155, 31), (1169, 26), (1174, 6), (1175, 78), (1176, 30), (1179, 53), (1212, 55), (1235, 6), (1247, 10), (1261, 12), (1263, 83), (1276, 10), (1323, 9), (1616, 38), (1770, 61), (1859, 24), (1866, 27)]
def cs88775 : List ℕ := [112, 157, 3, 88, 237, 161, 137, 256, 255, 68, 219, 126, 256, 78, 256, 0, 234, 256, 322, 102, 257, 514, 35, 256, 68, 817, 167, 661, 47, 148, 257, 256, 213, 255, 148, 255, 0, 257, 158, 256, 136, 256, 14, 256, 872, 255, 547, 0, 149, 257, 256, 255, 234, 257, 256, 256, 257, 256, 255, 255, 245, 90, 257, 66, 158, 256, 255, 838, 256, 259, 256, 255, 254, 102, 256, 256, 447, 257, 225, 255, 140, 218, 255, 257, 0, 166, 257, 257, 548, 255, 256, 256, 44, 256, 123, 257, 256, 258, 256, 256, 257, 256, 118, 257, 255, 256, 258, 161, 234, 108, 256, 255, 193, 197, 257, 255, 257, 256, 256, 257, 195, 256, 227, 255, 257, 145, 257, 256, 257, 257, 254, 257, 257, 256, 248, 257, 257, 211, 256, 255, 257, 256, 209, 256, 257, 257, 256, 238, 257, 238, 257, 256, 241, 248]
theorem node88775 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88775 support demand code
    entries88775 ((insert 69 (insert 92 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 88 (insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries88776 : List (Fin 2295 × ℕ) := [(4, 365), (37, 451), (46, 287), (72, 105), (75, 83), (92, 60), (137, 121), (273, 91), (469, 203), (474, 61), (475, 237), (490, 11), (507, 337), (530, 59), (583, 136), (736, 216), (743, 209), (778, 131), (780, 76), (833, 92), (852, 315), (867, 423), (873, 410), (885, 36), (886, 435), (887, 103), (888, 92), (894, 641), (915, 181), (920, 66), (921, 26), (925, 92), (933, 111), (938, 68), (957, 224), (958, 110), (969, 78), (972, 53), (973, 470), (984, 224), (985, 305), (1025, 131), (1049, 11), (1061, 1), (1069, 39), (1073, 68), (1096, 124), (1114, 21), (1122, 144), (1123, 57), (1131, 128), (1133, 20), (1143, 20), (1149, 48), (1153, 1), (1155, 79), (1169, 306), (1171, 14), (1174, 87), (1175, 87), (1179, 224), (1212, 224), (1217, 144), (1261, 110), (1263, 184), (1273, 161), (1277, 26), (1293, 104), (1304, 37), (1316, 31), (1323, 8), (1374, 77), (1471, 40), (1488, 22), (1572, 124), (1591, 26), (1616, 40), (1629, 47), (1674, 160), (1770, 151), (1859, 186), (2169, 8)]
def cs88776 : List ℕ := [481, 719, 144, 335, 680, 932, 681, 999, 1000, 337, 658, 879, 1000, 529, 1000, 0, 969, 1000, 1885, 646, 999, 1531, 0, 1000, 638, 3210, 1001, 2264, 105, 530, 999, 1001, 1001, 1000, 469, 754, 0, 941, 556, 1000, 416, 1000, 160, 1000, 2522, 1000, 1376, 0, 0, 969, 1000, 1000, 1000, 999, 1000, 1122, 1000, 1001, 806, 1000, 1000, 487, 1000, 257, 840, 1000, 1000, 2647, 1000, 103, 859, 1001, 1000, 209, 1000, 1001, 1071, 1000, 876, 1000, 92, 999, 1001, 926, 245, 718, 1000, 1000, 292, 1000, 1000, 1000, 92, 1000, 920, 999, 1001, 999, 1001, 1000, 1000, 1000, 424, 999, 1001, 999, 1000, 639, 999, 693, 1000, 1000, 577, 530, 1000, 999, 999, 1000, 1000, 999, 591, 709, 903, 998, 1000, 838, 999, 1000, 778, 1000, 977, 950, 999, 1000, 998, 1001, 1000, 1000, 1000, 999, 998, 1000, 1000, 982, 1000, 999, 843, 1000, 999, 1000, 1001, 829, 950, 1000]
theorem node88776 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 69 (insert 92 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88776 support demand code
    entries88776 ((insert 88 (insert 69 (insert 92 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node88774 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 92 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    88 node88775 node88776
theorem node88772 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    69 node88773 node88774
theorem node88755 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 18 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    92 node88771 node88772
def entries88769 : List (Fin 2295 × ℕ) := [(4, 397), (37, 442), (46, 427), (137, 52), (215, 26), (479, 345), (490, 349), (496, 34), (526, 40), (573, 275), (690, 4), (730, 330), (731, 170), (737, 72), (741, 20), (743, 33), (845, 80), (852, 171), (856, 359), (867, 70), (886, 419), (888, 282), (890, 381), (892, 114), (894, 579), (895, 7), (896, 96), (915, 353), (917, 23), (925, 58), (937, 89), (949, 139), (951, 65), (952, 261), (957, 139), (958, 288), (960, 211), (969, 32), (971, 69), (972, 21), (973, 464), (984, 199), (985, 302), (1009, 72), (1043, 93), (1047, 69), (1048, 16), (1049, 57), (1073, 65), (1100, 80), (1107, 3), (1108, 68), (1123, 130), (1125, 3), (1143, 10), (1149, 20), (1155, 169), (1169, 265), (1174, 155), (1175, 116), (1178, 64), (1179, 77), (1188, 52), (1212, 203), (1226, 54), (1241, 34), (1261, 104), (1263, 40), (1293, 171), (1323, 109), (1374, 36), (1435, 19), (1488, 89), (1500, 50), (1546, 1), (1591, 31), (1605, 62), (1622, 72), (1623, 134), (1629, 414), (1657, 87), (1667, 37), (1674, 10), (1705, 43), (1785, 80), (1887, 75)]
def cs88769 : List ℕ := [87, 564, 0, 0, 1000, 801, 786, 683, 1000, 0, 564, 436, 640, 0, 1001, 0, 972, 1001, 0, 999, 1000, 1806, 0, 955, 0, 3192, 916, 2122, 0, 517, 1000, 1001, 821, 1000, 271, 999, 7, 833, 442, 1001, 471, 1000, 90, 999, 2538, 1000, 1959, 359, 718, 1001, 999, 999, 944, 965, 999, 1026, 1001, 1000, 1000, 1000, 1799, 1001, 1001, 52, 999, 684, 2487, 3082, 872, 1000, 999, 1001, 1001, 750, 999, 1000, 1590, 998, 1071, 1001, 1000, 1000, 872, 795, 808, 1001, 846, 1000, 1002, 832, 1000, 999, 1001, 1000, 818, 1000, 1000, 1001, 1002, 999, 999, 1000, 696, 999, 1000, 1001, 1001, 652, 998, 434, 999, 1000, 1001, 714, 1001, 998, 1000, 1001, 999, 1000, 1001, 893, 1000, 1000, 999, 821, 1001, 1001, 1003, 1001, 999, 1000, 1002, 1000, 1001, 999, 864, 939, 1000, 999, 1001, 1001, 972, 1000, 1001, 935, 999, 1000, 1001, 988, 1001, 966, 819, 870]
theorem node88769 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 66 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88769 support demand code
    entries88769 ((insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 66 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries88770 : List (Fin 2295 × ℕ) := [(4, 70), (37, 139), (46, 84), (72, 43), (137, 73), (409, 32), (479, 84), (490, 46), (526, 4), (573, 27), (583, 32), (585, 26), (730, 43), (731, 39), (737, 18), (741, 3), (743, 6), (845, 38), (852, 50), (885, 15), (886, 32), (887, 2), (888, 88), (890, 92), (892, 6), (894, 117), (896, 39), (917, 22), (921, 4), (934, 20), (938, 44), (958, 14), (960, 34), (962, 6), (966, 23), (969, 14), (970, 1), (971, 24), (972, 9), (973, 124), (984, 54), (985, 62), (1009, 12), (1010, 9), (1011, 16), (1046, 5), (1047, 18), (1073, 18), (1100, 32), (1107, 16), (1108, 2), (1110, 11), (1113, 3), (1114, 9), (1122, 28), (1123, 13), (1133, 7), (1139, 5), (1155, 28), (1169, 57), (1171, 12), (1174, 24), (1175, 34), (1177, 3), (1179, 54), (1186, 24), (1188, 35), (1212, 48), (1261, 24), (1293, 10), (1308, 23), (1323, 15), (1488, 19), (1517, 35), (1528, 23), (1545, 55), (1605, 51), (1623, 51), (1629, 107), (1657, 29), (1664, 3), (1675, 15), (1688, 16), (1705, 13), (1737, 23), (1785, 15), (1887, 1)]
def cs88770 : List ℕ := [29, 137, 23, 0, 256, 139, 165, 201, 238, 0, 180, 110, 71, 23, 256, 0, 256, 256, 0, 256, 255, 465, 0, 256, 23, 784, 117, 516, 43, 130, 256, 258, 188, 256, 81, 257, 0, 204, 182, 257, 177, 248, 30, 256, 540, 255, 495, 0, 168, 170, 256, 255, 257, 226, 257, 256, 256, 257, 195, 256, 32, 256, 256, 144, 257, 196, 483, 655, 230, 257, 145, 257, 140, 209, 257, 170, 364, 256, 152, 255, 256, 258, 257, 257, 217, 256, 223, 256, 257, 222, 255, 256, 256, 257, 203, 257, 256, 257, 256, 256, 255, 256, 165, 256, 257, 257, 258, 197, 255, 165, 256, 256, 256, 178, 257, 255, 256, 255, 256, 256, 256, 247, 254, 255, 255, 208, 256, 256, 257, 256, 255, 256, 257, 255, 256, 255, 220, 256, 257, 255, 255, 257, 256, 214, 256, 247, 256, 255, 256, 256, 257, 255, 251, 224]
theorem node88770 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88770 support demand code
    entries88770 ((insert 60 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 66 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node88757 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 66 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    60 node88769 node88770
def entries88767 : List (Fin 2295 × ℕ) := [(4, 5), (46, 13), (70, 7), (137, 9), (151, 6), (179, 1), (387, 1), (468, 1), (572, 9), (579, 2), (617, 5), (618, 11), (640, 2), (731, 12), (743, 1), (778, 1), (779, 27), (780, 3), (781, 18), (785, 9), (797, 5), (845, 2), (867, 8), (886, 7), (892, 1), (894, 12), (896, 17), (915, 15), (920, 4), (925, 15), (933, 1), (934, 5), (957, 11), (958, 1), (960, 11), (972, 2), (973, 16), (984, 4), (985, 12), (1006, 3), (1009, 3), (1023, 1), (1073, 7), (1142, 6), (1143, 2), (1154, 5), (1155, 9), (1169, 10), (1174, 4), (1179, 4), (1212, 2), (1223, 10), (1253, 5), (1263, 2), (1273, 2), (1275, 3), (1374, 6), (1445, 3), (1471, 3), (1517, 5), (1528, 1), (1607, 2), (1629, 1), (1887, 4), (2016, 4), (2169, 4)]
def cs88767 : List ℕ := [15, 8, 0, 4, 20, 0, 22, 18, 26, 0, 16, 21, 20, 4, 29, 0, 33, 29, 0, 15, 32, 63, 5, 32, 0, 65, 25, 64, 0, 27, 33, 32, 21, 32, 4, 32, 5, 16, 5, 32, 26, 32, 0, 33, 88, 31, 60, 0, 17, 33, 32, 31, 32, 32, 32, 32, 32, 32, 12, 31, 105, 32, 32, 9, 28, 30, 4, 107, 33, 32, 99, 32, 33, 14, 32, 96, 37, 33, 30, 32, 32, 32, 32, 26, 21, 32, 25, 83, 32, 24, 32, 32, 90, 32, 21, 31, 33, 32, 31, 32, 31, 33, 32, 25, 31, 32, 31, 29, 32, 10, 33, 32, 31, 32, 28, 32, 31, 32, 32, 31, 27, 31, 23, 32, 32, 33, 32, 31, 26, 30, 32, 30, 31, 32, 31, 28, 21, 30, 32, 32, 32, 29, 28, 32, 31, 31, 22, 28, 27, 25, 25, 23, 31, 32]
theorem node88767 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 75 (insert 87 (insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88767 support demand code
    entries88767 ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 70 (insert 75 (insert 87 (insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
def entries88768 : List (Fin 2295 × ℕ) := [(4, 36), (20, 3), (46, 26), (60, 13), (70, 27), (137, 31), (151, 15), (479, 15), (572, 40), (583, 24), (737, 29), (845, 13), (852, 3), (865, 18), (867, 11), (870, 7), (886, 22), (892, 4), (894, 57), (896, 29), (914, 7), (915, 35), (922, 11), (924, 12), (925, 18), (934, 13), (957, 28), (969, 4), (970, 4), (971, 7), (972, 6), (973, 42), (984, 15), (985, 32), (1009, 13), (1012, 11), (1025, 1), (1045, 2), (1069, 20), (1073, 15), (1107, 4), (1108, 6), (1114, 10), (1121, 4), (1123, 7), (1128, 6), (1155, 25), (1169, 30), (1174, 18), (1175, 10), (1179, 7), (1188, 23), (1198, 4), (1212, 21), (1223, 13), (1226, 11), (1261, 8), (1272, 4), (1275, 7), (1297, 2), (1308, 25), (1320, 3), (1344, 1), (1488, 5), (1500, 10), (1517, 11), (1545, 3), (1591, 2), (1622, 3), (1629, 33), (1675, 7), (1688, 12), (1852, 1), (1887, 15)]
def cs88768 : List ℕ := [17, 49, 0, 7, 71, 0, 37, 44, 69, 0, 100, 31, 39, 7, 100, 0, 99, 100, 0, 55, 99, 193, 0, 99, 0, 279, 55, 202, 0, 86, 99, 100, 74, 99, 28, 99, 0, 92, 0, 100, 99, 93, 7, 90, 239, 100, 173, 0, 44, 99, 99, 71, 100, 86, 86, 100, 100, 100, 44, 100, 87, 99, 100, 67, 90, 83, 7, 280, 99, 99, 0, 100, 99, 53, 101, 70, 128, 100, 92, 100, 99, 100, 100, 99, 69, 72, 102, 103, 113, 83, 99, 100, 167, 93, 76, 101, 100, 102, 100, 100, 100, 100, 89, 48, 101, 101, 101, 92, 101, 41, 99, 100, 100, 89, 71, 100, 102, 99, 100, 101, 100, 101, 101, 98, 100, 85, 101, 100, 102, 102, 99, 100, 101, 100, 102, 101, 91, 81, 100, 100, 101, 87, 99, 100, 101, 91, 83, 99, 89, 99, 99, 80, 88, 97]
theorem node88768 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 87 (insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88768 support demand code
    entries88768 ((insert 70 (insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 75 (insert 87 (insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node88765 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 87 (insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 75 (insert 87 (insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    70 node88767 node88768
def entries88766 : List (Fin 2295 × ℕ) := [(4, 68), (46, 61), (70, 53), (75, 60), (137, 81), (151, 78), (572, 64), (579, 32), (583, 6), (692, 8), (737, 65), (743, 40), (813, 7), (845, 81), (852, 7), (865, 29), (867, 28), (870, 20), (886, 37), (891, 47), (892, 65), (894, 148), (896, 55), (915, 117), (924, 16), (925, 72), (934, 37), (957, 38), (958, 30), (959, 1), (960, 13), (969, 20), (972, 51), (973, 108), (984, 86), (985, 27), (1009, 22), (1012, 16), (1025, 19), (1043, 30), (1073, 51), (1100, 24), (1114, 38), (1122, 14), (1123, 59), (1126, 24), (1128, 7), (1148, 8), (1149, 21), (1152, 21), (1153, 36), (1155, 21), (1162, 7), (1169, 62), (1174, 37), (1175, 40), (1188, 18), (1212, 40), (1223, 38), (1226, 67), (1235, 43), (1257, 13), (1261, 15), (1263, 70), (1275, 15), (1308, 2), (1354, 4), (1488, 39), (1500, 13), (1545, 50), (1591, 1), (1605, 17), (1622, 22), (1629, 80), (1667, 5), (1674, 4), (1785, 6), (1912, 2), (2169, 9)]
def cs88766 : List ℕ := [38, 149, 0, 0, 113, 0, 65, 126, 176, 0, 256, 58, 189, 0, 252, 0, 236, 234, 0, 142, 256, 629, 0, 257, 0, 698, 142, 582, 0, 184, 256, 256, 168, 256, 77, 257, 47, 137, 0, 256, 252, 257, 10, 256, 669, 186, 443, 0, 115, 256, 257, 256, 255, 255, 256, 256, 255, 256, 162, 256, 251, 215, 256, 87, 218, 233, 0, 761, 256, 257, 159, 256, 256, 135, 255, 43, 430, 256, 265, 255, 257, 257, 255, 257, 166, 84, 200, 287, 286, 256, 255, 237, 365, 257, 251, 255, 256, 256, 256, 255, 255, 278, 193, 257, 255, 256, 256, 230, 256, 91, 256, 256, 258, 255, 187, 225, 257, 256, 256, 255, 257, 256, 255, 256, 256, 221, 255, 255, 255, 256, 255, 255, 256, 255, 256, 256, 255, 185, 255, 256, 256, 212, 231, 256, 256, 207, 245, 255, 255, 256, 255, 224, 204, 184]
theorem node88766 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 87 (insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88766 support demand code
    entries88766 ((insert 75 (insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 87 (insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node88763 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 87 (insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 87 (insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    75 node88765 node88766
def entries88764 : List (Fin 2295 × ℕ) := [(1, 11), (4, 147), (46, 41), (70, 14), (75, 54), (137, 2), (151, 35), (572, 147), (583, 9), (585, 3), (731, 21), (785, 39), (797, 4), (813, 18), (845, 41), (865, 49), (867, 80), (886, 129), (892, 62), (894, 112), (896, 46), (917, 54), (920, 34), (922, 14), (924, 22), (925, 82), (934, 56), (938, 44), (957, 59), (958, 53), (971, 21), (972, 20), (973, 114), (981, 17), (984, 61), (1009, 42), (1012, 28), (1023, 10), (1025, 35), (1069, 19), (1070, 24), (1073, 37), (1108, 30), (1122, 3), (1123, 35), (1128, 14), (1148, 20), (1149, 18), (1155, 48), (1169, 52), (1174, 26), (1175, 44), (1179, 35), (1188, 30), (1212, 31), (1223, 15), (1226, 22), (1228, 9), (1230, 4), (1241, 12), (1261, 11), (1263, 27), (1273, 23), (1275, 2), (1308, 28), (1400, 31), (1471, 40), (1607, 37), (1622, 35), (1629, 59), (1667, 22), (1705, 14), (1991, 39), (2139, 8), (2169, 3)]
def cs88764 : List ℕ := [26, 188, 0, 0, 162, 0, 41, 67, 189, 0, 256, 15, 125, 0, 256, 0, 205, 240, 0, 182, 255, 480, 0, 191, 17, 699, 182, 590, 0, 146, 255, 256, 163, 255, 70, 255, 0, 225, 0, 256, 232, 256, 0, 196, 579, 230, 417, 0, 73, 256, 256, 256, 256, 256, 221, 256, 256, 256, 73, 255, 292, 255, 255, 11, 146, 256, 35, 729, 256, 256, 255, 256, 205, 113, 255, 176, 291, 256, 152, 255, 255, 256, 255, 256, 137, 213, 216, 0, 257, 199, 255, 232, 375, 256, 217, 256, 256, 256, 255, 255, 256, 278, 117, 237, 255, 256, 255, 255, 256, 134, 257, 256, 255, 177, 222, 217, 255, 255, 256, 256, 255, 226, 255, 214, 255, 256, 256, 256, 255, 255, 256, 256, 256, 256, 256, 188, 256, 221, 256, 256, 256, 256, 250, 256, 255, 244, 228, 256, 256, 233, 256, 195, 180, 251]
theorem node88764 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 87 (insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88764 support demand code
    entries88764 ((insert 87 (insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node88761 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 92 (insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    87 node88763 node88764
def entries88762 : List (Fin 2295 × ℕ) := [(4, 2438), (20, 257), (46, 320), (75, 4342), (137, 1424), (273, 421), (498, 592), (571, 1551), (730, 888), (731, 5146), (734, 1260), (743, 816), (778, 605), (844, 2615), (852, 1088), (865, 995), (867, 2666), (873, 1686), (886, 3661), (894, 5590), (896, 1395), (915, 2495), (917, 1693), (924, 675), (925, 2603), (933, 981), (938, 741), (945, 1019), (957, 2701), (958, 2637), (972, 114), (973, 3853), (984, 3026), (985, 2228), (1009, 990), (1012, 710), (1025, 601), (1045, 307), (1069, 1668), (1073, 519), (1100, 713), (1108, 683), (1114, 536), (1119, 114), (1122, 485), (1123, 728), (1139, 646), (1148, 554), (1149, 247), (1155, 2053), (1169, 2131), (1174, 1415), (1175, 2047), (1179, 2016), (1212, 1708), (1223, 1728), (1235, 1239), (1241, 183), (1248, 181), (1261, 422), (1263, 3818), (1297, 866), (1316, 788), (1322, 395), (1374, 2173), (1447, 40), (1546, 210), (1572, 169), (1623, 1170), (1629, 1997), (1667, 173), (1887, 1213), (1991, 734), (2001, 352), (2072, 124), (2169, 824)]
def cs88762 : List ℕ := [4343, 2438, 0, 257, 5254, 0, 320, 5431, 8833, 0, 10000, 1728, 8753, 1943, 7100, 0, 8810, 5630, 1686, 1551, 10001, 15465, 0, 10000, 0, 27523, 3237, 16461, 0, 4919, 10001, 10000, 5696, 10000, 3462, 8777, 0, 5658, 0, 8570, 7774, 9999, 0, 10000, 24252, 7677, 13619, 0, 8313, 10000, 10000, 8630, 10000, 10000, 7860, 9999, 10000, 10000, 9999, 10000, 13467, 8006, 10001, 1548, 7461, 10001, 2016, 32051, 10000, 9999, 10000, 10000, 9416, 6455, 10000, 10000, 11527, 10001, 8085, 10001, 8313, 9292, 10001, 10001, 7060, 7281, 9958, 10000, 9999, 8757, 10000, 10000, 0, 10001, 9143, 10000, 10000, 10002, 9999, 10000, 9999, 10000, 2353, 10001, 10000, 10001, 10001, 8516, 10000, 4626, 10000, 9999, 5896, 7856, 9961, 9999, 10001, 10001, 10000, 10000, 10000, 9999, 9578, 10000, 10001, 7775, 10000, 10000, 10000, 9999, 10000, 10000, 10000, 10000, 10001, 10000, 10000, 8985, 10000, 10000, 10001, 9999, 9295, 8953, 10000, 10000, 9618, 8929, 10000, 8798, 10000, 7960, 9578, 8663]
theorem node88762 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88762 support demand code
    entries88762 ((insert 92 (insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node88759 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    92 node88761 node88762
def entries88760 : List (Fin 2295 × ℕ) := [(4, 171), (46, 12), (75, 387), (137, 375), (273, 183), (479, 10), (572, 160), (583, 43), (585, 206), (617, 35), (618, 183), (730, 28), (731, 186), (737, 27), (741, 67), (743, 32), (817, 23), (844, 279), (852, 154), (865, 138), (867, 90), (869, 103), (885, 125), (888, 197), (891, 152), (892, 98), (894, 492), (896, 88), (917, 158), (921, 91), (934, 173), (938, 205), (957, 23), (966, 134), (971, 62), (972, 95), (973, 475), (984, 165), (985, 312), (1006, 10), (1009, 126), (1012, 8), (1025, 22), (1061, 40), (1073, 152), (1075, 11), (1099, 2), (1100, 65), (1107, 65), (1108, 32), (1114, 65), (1122, 77), (1123, 63), (1141, 24), (1143, 86), (1152, 24), (1155, 159), (1169, 234), (1174, 175), (1175, 116), (1179, 173), (1186, 27), (1188, 197), (1212, 225), (1223, 162), (1226, 9), (1261, 70), (1263, 281), (1308, 137), (1323, 8), (1354, 50), (1488, 46), (1500, 64), (1545, 250), (1572, 77), (1605, 124), (1623, 192), (1629, 330), (1675, 54), (1728, 7), (1773, 24), (1846, 60), (1887, 13), (2001, 38)]
def cs88760 : List ℕ := [441, 171, 0, 0, 497, 0, 36, 605, 614, 0, 999, 265, 722, 0, 648, 0, 992, 589, 0, 357, 999, 1837, 0, 999, 0, 2660, 392, 2101, 0, 477, 999, 981, 513, 1000, 291, 999, 152, 558, 0, 999, 999, 999, 78, 1000, 2238, 502, 1717, 0, 608, 641, 1000, 999, 999, 999, 999, 1000, 1000, 999, 760, 999, 0, 951, 999, 552, 879, 1000, 370, 2642, 999, 1000, 768, 1000, 565, 997, 999, 788, 1384, 1000, 626, 999, 1000, 1001, 999, 999, 765, 803, 999, 988, 999, 952, 999, 1000, 999, 1000, 759, 999, 1000, 998, 999, 999, 998, 1000, 621, 962, 998, 999, 1000, 791, 999, 582, 999, 1000, 1000, 590, 1000, 999, 999, 999, 1001, 999, 1001, 999, 998, 999, 999, 845, 999, 999, 999, 997, 999, 1000, 999, 999, 999, 999, 865, 953, 1000, 999, 998, 999, 999, 999, 1000, 967, 1000, 1000, 999, 999, 1000, 999, 913, 886]
theorem node88760 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88760 support demand code
    entries88760 ((insert 60 (insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node88758 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 66 (insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    60 node88759 node88760
theorem node88756 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    66 node88757 node88758
theorem node88754 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    18 node88755 node88756
theorem node88705 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 21 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    36 node88753 node88754
def entries88751 : List (Fin 2295 × ℕ) := [(4, 46), (37, 26), (130, 13), (137, 5), (179, 4), (342, 3), (397, 9), (469, 54), (471, 5), (474, 3), (527, 10), (542, 36), (552, 38), (572, 18), (622, 1), (625, 31), (632, 8), (675, 1), (780, 10), (813, 5), (844, 6), (847, 33), (849, 31), (855, 30), (859, 18), (869, 5), (870, 5), (873, 37), (874, 36), (886, 25), (888, 10), (895, 3), (907, 11), (908, 12), (915, 47), (916, 35), (917, 10), (918, 36), (920, 8), (922, 22), (925, 3), (944, 18), (952, 5), (958, 15), (959, 22), (960, 14), (966, 2), (969, 4), (971, 16), (973, 52), (984, 9), (985, 16), (994, 4), (1006, 16), (1011, 13), (1012, 1), (1025, 15), (1045, 2), (1056, 6), (1061, 9), (1073, 1), (1089, 2), (1090, 4), (1107, 6), (1122, 5), (1123, 8), (1130, 6), (1155, 2), (1169, 12), (1171, 14), (1174, 3), (1175, 9), (1178, 6), (1179, 17), (1186, 25), (1212, 7), (1232, 2), (1235, 2), (1261, 10), (1266, 4), (1273, 8), (1293, 11), (1310, 1), (1372, 4), (1469, 14), (1488, 3), (1517, 4), (1551, 23), (1629, 52), (1635, 11), (1641, 5), (1705, 14), (1732, 2), (1767, 3), (1870, 2), (1991, 6), (2206, 5)]
def cs88751 : List ℕ := [9, 100, 41, 37, 46, 56, 4, 101, 90, 0, 52, 71, 101, 100, 82, 38, 100, 100, 259, 54, 101, 3, 4, 100, 100, 290, 87, 226, 100, 12, 100, 256, 59, 100, 79, 101, 165, 94, 30, 353, 100, 100, 59, 92, 347, 100, 142, 0, 21, 100, 99, 100, 75, 100, 101, 142, 99, 77, 99, 101, 99, 100, 99, 99, 94, 100, 101, 249, 100, 100, 100, 100, 96, 98, 84, 100, 187, 99, 98, 100, 99, 206, 100, 99, 67, 83, 101, 99, 101, 81, 100, 100, 100, 100, 84, 101, 100, 99, 100, 100, 100, 100, 97, 99, 101, 100, 100, 100, 100, 79, 99, 101, 99, 85, 100, 100, 100, 100, 100, 101, 99, 100, 100, 100, 100, 100, 100, 101, 88, 101, 100, 76, 101, 101, 100, 100, 93, 100, 100, 101, 101, 101, 100, 101, 100, 99, 100, 100, 101, 101, 100, 101, 101, 96]
theorem node88751 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 18 (insert 81 (insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88751 support demand code
    entries88751 ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 31 (insert 18 (insert 81 (insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries88752 : List (Fin 2295 × ℕ) := [(4, 400), (37, 270), (92, 168), (179, 306), (472, 295), (475, 284), (507, 68), (527, 46), (542, 510), (550, 20), (552, 509), (622, 381), (625, 148), (630, 93), (632, 91), (639, 50), (675, 251), (743, 24), (780, 157), (814, 28), (843, 10), (847, 405), (849, 149), (852, 210), (855, 42), (858, 48), (859, 218), (870, 102), (873, 329), (874, 315), (883, 9), (886, 397), (907, 47), (908, 338), (918, 154), (924, 14), (925, 83), (944, 92), (951, 60), (957, 21), (958, 286), (959, 305), (960, 111), (966, 12), (969, 65), (973, 567), (984, 34), (985, 165), (1006, 191), (1009, 70), (1025, 19), (1041, 31), (1055, 76), (1056, 81), (1061, 19), (1073, 137), (1082, 34), (1108, 36), (1113, 4), (1114, 108), (1123, 66), (1130, 5), (1133, 51), (1143, 80), (1155, 30), (1169, 171), (1176, 100), (1177, 77), (1179, 108), (1183, 89), (1184, 27), (1185, 55), (1186, 215), (1212, 9), (1261, 92), (1286, 1), (1293, 39), (1400, 170), (1488, 47), (1517, 233), (1537, 90), (1560, 28), (1629, 209), (1641, 177), (1732, 74), (1845, 77), (1852, 99), (1887, 44), (1991, 128), (2169, 112), (2206, 13)]
def cs88752 : List ℕ := [0, 400, 790, 433, 610, 402, 281, 1000, 978, 68, 209, 619, 999, 902, 910, 529, 1000, 932, 1850, 270, 1000, 0, 306, 1000, 982, 2102, 1000, 1833, 1001, 490, 1000, 356, 911, 999, 554, 999, 2561, 1000, 576, 1463, 1001, 1000, 601, 827, 2301, 1000, 2487, 0, 380, 1000, 1000, 1000, 1001, 999, 1000, 1142, 1000, 1000, 1000, 864, 1000, 1000, 1000, 788, 1000, 772, 1000, 1377, 999, 1001, 886, 999, 553, 1001, 999, 1000, 1952, 1000, 136, 998, 1001, 1809, 1001, 1000, 472, 933, 1000, 1001, 1000, 692, 999, 785, 1000, 1000, 570, 999, 840, 1000, 999, 999, 999, 999, 1001, 1001, 1000, 1000, 1000, 998, 880, 442, 999, 999, 912, 1000, 1000, 998, 999, 1000, 1000, 1000, 582, 999, 763, 998, 999, 999, 999, 999, 884, 999, 999, 915, 999, 999, 998, 969, 763, 999, 999, 999, 999, 995, 999, 998, 999, 933, 999, 998, 999, 999, 999, 999, 998, 965]
theorem node88752 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 81 (insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88752 support demand code
    entries88752 ((insert 31 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 81 (insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node88749 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 81 (insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 18 (insert 81 (insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    31 node88751 node88752
def entries88750 : List (Fin 2295 × ℕ) := [(4, 311), (37, 72), (130, 245), (472, 285), (498, 295), (527, 35), (542, 148), (550, 113), (552, 602), (571, 309), (618, 50), (620, 74), (622, 35), (623, 22), (625, 227), (675, 202), (780, 33), (781, 62), (813, 90), (843, 9), (844, 144), (851, 110), (852, 88), (865, 176), (867, 127), (869, 85), (870, 43), (880, 163), (886, 323), (907, 241), (908, 340), (914, 243), (915, 115), (916, 106), (918, 344), (920, 27), (922, 19), (924, 39), (925, 197), (938, 5), (944, 64), (951, 1), (958, 277), (959, 186), (960, 158), (966, 195), (973, 544), (984, 94), (985, 274), (1009, 182), (1011, 7), (1021, 94), (1045, 6), (1060, 1), (1061, 62), (1073, 173), (1099, 52), (1100, 36), (1107, 62), (1123, 160), (1143, 8), (1152, 8), (1153, 32), (1155, 118), (1169, 180), (1174, 54), (1176, 126), (1177, 96), (1178, 68), (1179, 56), (1182, 8), (1183, 27), (1185, 34), (1186, 170), (1212, 106), (1258, 16), (1261, 123), (1293, 15), (1354, 29), (1400, 106), (1469, 6), (1517, 258), (1560, 54), (1625, 49), (1629, 147), (1641, 87), (1705, 64), (1739, 116), (1949, 167), (1991, 100), (2169, 143)]
def cs88750 : List ℕ := [144, 311, 285, 0, 676, 72, 258, 794, 678, 0, 450, 386, 747, 0, 459, 878, 1000, 841, 0, 381, 1000, 0, 0, 999, 1000, 2093, 871, 1816, 987, 292, 1000, 999, 754, 1000, 217, 1000, 2716, 1000, 72, 1287, 1000, 999, 666, 1000, 1535, 1000, 1909, 0, 122, 1000, 999, 999, 719, 1001, 1000, 999, 1000, 1000, 1000, 1000, 1000, 999, 1001, 692, 1000, 1000, 1000, 2216, 1000, 999, 999, 1000, 726, 1000, 871, 1000, 1715, 1000, 451, 999, 1000, 1789, 999, 1001, 122, 999, 920, 999, 999, 752, 999, 982, 999, 1000, 495, 1000, 759, 999, 999, 999, 1000, 1000, 1000, 999, 1000, 999, 999, 998, 999, 488, 980, 1000, 889, 852, 999, 999, 999, 999, 1000, 1000, 700, 999, 594, 921, 998, 1000, 999, 1001, 1000, 999, 998, 1000, 1000, 998, 1000, 998, 820, 854, 998, 1000, 998, 1000, 961, 1000, 998, 1001, 999, 1000, 999, 1000, 999, 1000, 986, 999]
theorem node88750 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88750 support demand code
    entries88750 ((insert 18 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node88747 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 81 (insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    18 node88749 node88750
def entries88748 : List (Fin 2295 × ℕ) := [(4, 157), (37, 164), (130, 38), (542, 282), (550, 262), (552, 463), (623, 382), (624, 361), (625, 35), (632, 262), (673, 37), (675, 178), (781, 20), (833, 7), (843, 113), (849, 401), (851, 240), (852, 281), (860, 142), (865, 43), (867, 131), (870, 218), (873, 195), (886, 238), (896, 171), (908, 195), (914, 126), (915, 173), (916, 225), (917, 118), (920, 170), (924, 254), (925, 60), (944, 78), (945, 80), (952, 162), (958, 149), (959, 77), (966, 110), (969, 117), (970, 24), (971, 61), (972, 14), (973, 488), (984, 95), (985, 317), (1009, 142), (1045, 86), (1056, 108), (1061, 100), (1073, 182), (1100, 44), (1107, 42), (1108, 49), (1123, 93), (1133, 25), (1143, 20), (1155, 67), (1169, 157), (1174, 14), (1176, 148), (1177, 143), (1178, 18), (1179, 169), (1183, 74), (1186, 200), (1189, 128), (1212, 107), (1223, 120), (1261, 132), (1276, 37), (1296, 52), (1297, 14), (1322, 25), (1400, 54), (1497, 50), (1517, 95), (1534, 33), (1537, 223), (1540, 44), (1629, 329), (1635, 11), (1641, 93), (1655, 32), (1950, 8), (1991, 92), (2072, 17), (2073, 22)]
def cs88748 : List ℕ := [120, 285, 351, 401, 926, 439, 95, 1000, 994, 0, 503, 433, 1000, 470, 567, 725, 1000, 999, 999, 164, 1000, 171, 0, 1000, 1000, 1797, 666, 2352, 973, 388, 1000, 999, 1000, 1233, 543, 880, 2477, 986, 164, 2132, 1001, 999, 541, 713, 2685, 999, 2339, 0, 80, 1000, 999, 983, 731, 999, 1000, 999, 999, 999, 1000, 1000, 1000, 754, 1000, 827, 991, 995, 999, 1905, 1001, 1000, 999, 999, 663, 1000, 1000, 999, 1254, 1000, 582, 1001, 1000, 110, 1000, 999, 387, 999, 999, 1000, 999, 968, 1001, 1000, 999, 1000, 794, 999, 912, 999, 999, 1001, 1000, 1001, 922, 999, 999, 1000, 998, 988, 1000, 569, 999, 1000, 924, 855, 999, 999, 1000, 1001, 1000, 1000, 526, 931, 902, 1000, 1000, 869, 999, 1000, 804, 1000, 1001, 1000, 999, 1001, 1000, 1001, 793, 1000, 1000, 1001, 1000, 973, 1001, 1001, 999, 1000, 997, 1001, 1001, 971, 1000, 1001, 1001, 987]
theorem node88748 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88748 support demand code
    entries88748 ((insert 81 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node88737 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    81 node88747 node88748
def entries88745 : List (Fin 2295 × ℕ) := [(4, 120), (37, 260), (83, 258), (177, 167), (472, 211), (475, 349), (479, 101), (496, 100), (498, 75), (542, 261), (552, 400), (620, 184), (622, 175), (625, 236), (675, 260), (741, 2), (742, 23), (743, 39), (780, 175), (842, 69), (843, 119), (844, 250), (851, 228), (852, 210), (867, 490), (870, 124), (873, 230), (874, 176), (886, 560), (895, 170), (902, 19), (907, 177), (908, 235), (918, 339), (923, 86), (925, 37), (936, 45), (946, 200), (952, 48), (957, 110), (958, 276), (959, 340), (960, 222), (966, 10), (973, 479), (978, 173), (985, 102), (1006, 163), (1009, 180), (1012, 103), (1040, 153), (1041, 26), (1043, 29), (1069, 63), (1073, 39), (1089, 4), (1099, 94), (1100, 70), (1108, 79), (1113, 3), (1114, 51), (1123, 137), (1153, 93), (1155, 128), (1169, 106), (1174, 150), (1176, 36), (1177, 229), (1179, 16), (1186, 119), (1212, 159), (1249, 58), (1258, 57), (1313, 67), (1335, 5), (1400, 161), (1534, 58), (1551, 178), (1552, 95), (1641, 70), (1668, 14), (1852, 198), (2047, 15), (2048, 72), (2052, 13), (2169, 24), (2204, 46)]
def cs88745 : List ℕ := [317, 120, 211, 416, 726, 327, 0, 1000, 622, 0, 490, 731, 1002, 584, 448, 400, 771, 992, 1000, 260, 1001, 170, 167, 1001, 611, 1955, 669, 1451, 1001, 262, 999, 1000, 472, 1000, 150, 1001, 2340, 1001, 427, 487, 1001, 1000, 400, 1001, 1813, 1001, 2394, 0, 367, 999, 867, 760, 1000, 1000, 1000, 1000, 1001, 1000, 1000, 1000, 1000, 1001, 1000, 686, 1000, 1001, 1001, 1889, 999, 1001, 1000, 1001, 859, 1001, 999, 1001, 2208, 1001, 10, 999, 1001, 2096, 999, 1001, 95, 1000, 945, 1001, 2363, 884, 998, 857, 1001, 1000, 524, 1001, 843, 1001, 1001, 999, 1000, 1000, 1001, 1001, 939, 1000, 977, 970, 767, 294, 1000, 999, 1001, 1001, 594, 1001, 1000, 1000, 1000, 1005, 894, 1001, 906, 758, 1001, 928, 1000, 999, 1001, 897, 1000, 1000, 1000, 999, 826, 1000, 986, 601, 1000, 999, 1001, 1000, 811, 1000, 1000, 835, 1000, 1000, 1000, 999, 999, 1000, 1000, 885]
theorem node88745 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 88 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88745 support demand code
    entries88745 ((insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 88 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries88746 : List (Fin 2295 × ℕ) := [(4, 2), (37, 52), (83, 53), (177, 49), (386, 28), (472, 71), (475, 54), (496, 56), (529, 75), (542, 21), (550, 45), (552, 57), (620, 9), (624, 49), (625, 47), (675, 21), (779, 5), (781, 14), (843, 54), (844, 54), (851, 44), (852, 62), (867, 98), (870, 42), (873, 96), (886, 111), (896, 75), (908, 86), (914, 5), (920, 19), (923, 18), (925, 36), (935, 7), (946, 59), (952, 39), (957, 32), (958, 55), (959, 39), (960, 15), (966, 7), (969, 26), (973, 138), (978, 30), (985, 39), (1009, 36), (1041, 13), (1061, 12), (1068, 26), (1072, 17), (1073, 6), (1090, 5), (1099, 7), (1100, 26), (1107, 31), (1108, 10), (1114, 25), (1123, 26), (1141, 1), (1142, 9), (1143, 20), (1149, 6), (1151, 6), (1153, 17), (1155, 14), (1169, 47), (1174, 29), (1175, 19), (1177, 24), (1179, 45), (1183, 38), (1186, 53), (1212, 3), (1253, 8), (1261, 22), (1266, 14), (1295, 25), (1313, 31), (1400, 45), (1445, 2), (1528, 11), (1535, 9), (1540, 4), (1641, 11), (1645, 23), (1657, 8), (1852, 28), (1864, 67), (2204, 34)]
def cs88746 : List ℕ := [101, 10, 71, 85, 164, 83, 67, 256, 157, 0, 98, 232, 256, 171, 129, 102, 198, 220, 256, 61, 256, 75, 49, 255, 173, 442, 228, 430, 214, 121, 257, 212, 220, 256, 48, 255, 471, 255, 101, 61, 255, 256, 57, 257, 435, 255, 623, 0, 108, 257, 255, 189, 256, 257, 257, 255, 256, 256, 257, 256, 255, 122, 255, 204, 258, 256, 255, 438, 257, 255, 256, 256, 205, 256, 257, 257, 444, 256, 45, 256, 256, 54, 239, 254, 92, 257, 258, 256, 451, 233, 257, 219, 255, 255, 189, 224, 212, 256, 255, 257, 257, 256, 256, 256, 257, 257, 255, 229, 234, 101, 256, 257, 242, 257, 187, 257, 256, 256, 257, 258, 203, 256, 239, 245, 256, 227, 257, 257, 257, 256, 256, 257, 256, 257, 229, 256, 227, 256, 257, 256, 257, 257, 257, 256, 256, 257, 257, 256, 258, 257, 256, 257, 256, 246]
theorem node88746 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88746 support demand code
    entries88746 ((insert 81 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 88 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node88739 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 88 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    81 node88745 node88746
def entries88741 : List (Fin 2295 × ℕ) := [(37, 78), (92, 6), (179, 58), (273, 24), (483, 8), (490, 57), (512, 64), (529, 1), (531, 90), (542, 144), (550, 10), (552, 126), (576, 20), (618, 70), (622, 8), (624, 63), (625, 35), (673, 2), (674, 20), (675, 41), (742, 18), (743, 9), (843, 17), (844, 72), (852, 72), (859, 23), (860, 20), (867, 135), (873, 112), (874, 46), (886, 72), (907, 21), (908, 99), (920, 11), (924, 27), (925, 61), (938, 10), (944, 12), (952, 49), (957, 13), (958, 68), (959, 17), (966, 6), (972, 38), (973, 131), (978, 28), (985, 47), (1009, 28), (1061, 17), (1073, 70), (1099, 1), (1100, 16), (1113, 25), (1114, 25), (1122, 7), (1123, 38), (1130, 9), (1133, 1), (1141, 19), (1169, 69), (1175, 13), (1178, 9), (1182, 24), (1185, 12), (1186, 56), (1235, 13), (1238, 112), (1241, 2), (1261, 4), (1323, 24), (1374, 11), (1400, 20), (1472, 7), (1516, 15), (1572, 13), (1581, 13), (1641, 37), (1645, 21), (1739, 8), (1845, 20), (1991, 51), (1994, 19), (2085, 27)]
def cs88741 : List ℕ := [184, 0, 112, 0, 72, 86, 57, 256, 233, 0, 199, 169, 255, 255, 144, 136, 256, 100, 255, 78, 604, 0, 58, 256, 256, 473, 255, 482, 255, 58, 256, 214, 243, 256, 13, 255, 647, 256, 136, 11, 255, 257, 138, 256, 400, 257, 720, 0, 66, 255, 257, 189, 252, 256, 254, 257, 256, 255, 256, 169, 257, 197, 255, 256, 256, 256, 256, 357, 256, 256, 256, 257, 130, 256, 256, 257, 406, 256, 30, 256, 256, 257, 256, 256, 104, 257, 256, 257, 54, 211, 256, 225, 257, 232, 221, 256, 186, 256, 258, 256, 256, 256, 233, 256, 256, 257, 256, 254, 256, 115, 256, 256, 181, 256, 239, 256, 256, 256, 256, 255, 177, 196, 253, 257, 256, 256, 255, 255, 251, 255, 256, 241, 256, 255, 256, 256, 157, 229, 256, 256, 256, 205, 238, 256, 256, 223, 246, 256, 256, 255, 227, 241, 211, 201]
theorem node88741 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88741 support demand code
    entries88741 ((insert 88 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 20 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries88743 : List (Fin 2295 × ℕ) := [(4, 58), (20, 13), (37, 62), (83, 65), (130, 22), (179, 93), (387, 1), (472, 78), (475, 160), (479, 41), (494, 14), (498, 70), (550, 73), (552, 105), (619, 5), (620, 22), (625, 40), (640, 2), (673, 54), (674, 52), (675, 3), (742, 12), (815, 8), (842, 2), (851, 35), (852, 89), (855, 18), (867, 14), (873, 45), (874, 5), (883, 13), (886, 126), (907, 67), (908, 52), (914, 22), (925, 23), (937, 24), (938, 7), (944, 50), (951, 7), (952, 20), (957, 29), (958, 91), (959, 3), (960, 19), (962, 18), (966, 13), (973, 125), (977, 17), (978, 28), (985, 38), (1006, 28), (1009, 28), (1041, 15), (1073, 5), (1100, 27), (1114, 12), (1123, 83), (1133, 25), (1141, 5), (1154, 11), (1169, 74), (1174, 14), (1176, 16), (1177, 27), (1178, 5), (1186, 57), (1235, 26), (1252, 1), (1258, 13), (1261, 9), (1293, 10), (1297, 20), (1323, 5), (1400, 9), (1481, 43), (1488, 43), (1551, 29), (1572, 6), (1641, 38), (1668, 4), (1732, 33), (1791, 8), (1846, 14), (1887, 38), (1991, 7), (2204, 62), (2206, 35), (2288, 6)]
def cs88743 : List ℕ := [0, 58, 78, 173, 223, 80, 0, 257, 203, 0, 14, 225, 257, 92, 58, 178, 256, 164, 257, 62, 14, 0, 93, 256, 256, 425, 158, 290, 256, 171, 220, 157, 256, 256, 14, 257, 694, 257, 155, 13, 256, 433, 155, 255, 290, 257, 645, 0, 126, 256, 257, 256, 257, 256, 257, 256, 257, 257, 256, 217, 255, 218, 247, 136, 257, 256, 256, 368, 256, 256, 256, 256, 256, 256, 256, 255, 357, 256, 13, 257, 255, 256, 255, 258, 169, 255, 255, 256, 79, 216, 255, 208, 255, 257, 196, 256, 255, 257, 257, 255, 256, 255, 256, 257, 255, 253, 256, 221, 256, 80, 255, 255, 124, 195, 256, 255, 256, 257, 255, 256, 140, 256, 255, 256, 257, 255, 255, 256, 241, 255, 256, 256, 256, 255, 256, 254, 188, 218, 254, 256, 256, 254, 220, 255, 256, 200, 236, 256, 255, 255, 229, 256, 249, 202]
theorem node88743 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 88 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88743 support demand code
    entries88743 ((insert 20 (insert 88 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 41 (insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries88744 : List (Fin 2295 × ℕ) := [(4, 156), (37, 55), (179, 62), (472, 82), (479, 54), (495, 37), (550, 61), (552, 113), (620, 10), (625, 37), (639, 32), (673, 7), (674, 24), (675, 3), (832, 18), (851, 10), (852, 36), (855, 94), (859, 6), (867, 57), (873, 74), (874, 88), (883, 45), (885, 3), (886, 120), (902, 9), (907, 65), (908, 108), (914, 71), (924, 45), (944, 39), (951, 19), (952, 9), (957, 7), (958, 76), (959, 12), (966, 4), (973, 144), (985, 42), (1006, 20), (1009, 54), (1041, 16), (1055, 19), (1056, 1), (1069, 4), (1072, 15), (1107, 2), (1108, 9), (1123, 59), (1131, 17), (1133, 30), (1169, 38), (1174, 30), (1183, 7), (1184, 26), (1185, 3), (1186, 65), (1235, 50), (1400, 78), (1469, 8), (1556, 7), (1560, 2), (1572, 17), (1591, 14), (1641, 56), (1791, 17), (1845, 17), (1846, 12), (1887, 20), (1991, 30), (2074, 27), (2085, 1), (2204, 46), (2206, 38)]
def cs88744 : List ℕ := [0, 156, 82, 0, 256, 149, 0, 182, 254, 0, 57, 0, 215, 162, 156, 174, 250, 156, 256, 55, 57, 0, 62, 256, 256, 610, 209, 365, 256, 133, 255, 91, 106, 255, 30, 256, 655, 222, 117, 48, 256, 0, 152, 256, 336, 256, 570, 0, 70, 255, 187, 129, 111, 256, 255, 365, 255, 205, 256, 255, 256, 138, 255, 103, 256, 256, 256, 349, 256, 256, 256, 256, 214, 196, 256, 257, 469, 255, 11, 255, 257, 256, 221, 255, 70, 257, 209, 256, 49, 146, 255, 186, 256, 222, 199, 256, 256, 256, 256, 256, 256, 256, 256, 255, 257, 216, 255, 226, 256, 96, 213, 256, 167, 190, 254, 256, 256, 255, 256, 256, 135, 226, 256, 257, 255, 256, 256, 257, 159, 257, 255, 212, 256, 256, 257, 231, 195, 230, 255, 256, 255, 256, 221, 257, 256, 178, 255, 256, 236, 256, 256, 256, 257, 219]
theorem node88744 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 41 (insert 20 (insert 88 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88744 support demand code
    entries88744 ((insert 41 (insert 20 (insert 88 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node88742 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 88 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 20 (insert 88 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    41 node88743 node88744
theorem node88740 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    20 node88741 node88742
theorem node88738 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    88 node88739 node88740
theorem node88707 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 36 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    39 node88737 node88738
def entries88735 : List (Fin 2295 × ℕ) := [(4, 306), (21, 11), (37, 26), (72, 521), (83, 232), (409, 242), (469, 332), (471, 156), (475, 229), (482, 228), (496, 82), (529, 1), (542, 173), (572, 26), (618, 363), (632, 170), (737, 212), (742, 15), (743, 110), (814, 8), (815, 95), (844, 240), (852, 65), (855, 3), (867, 380), (873, 397), (874, 249), (886, 410), (888, 393), (918, 34), (920, 54), (922, 43), (924, 192), (925, 234), (933, 188), (934, 39), (944, 196), (957, 142), (958, 283), (959, 33), (960, 87), (973, 512), (978, 18), (985, 178), (1006, 43), (1012, 14), (1025, 151), (1043, 48), (1045, 7), (1055, 143), (1061, 10), (1070, 10), (1072, 186), (1100, 83), (1114, 89), (1123, 99), (1143, 107), (1152, 70), (1153, 94), (1155, 229), (1169, 328), (1171, 61), (1174, 52), (1175, 52), (1188, 388), (1212, 151), (1261, 48), (1271, 83), (1293, 184), (1308, 45), (1324, 22), (1335, 9), (1372, 22), (1459, 82), (1488, 50), (1500, 31), (1516, 56), (1623, 152), (1705, 124), (1728, 9), (1846, 9), (1859, 206), (1887, 48), (2052, 32), (2130, 139), (2204, 132)]
def cs88735 : List ℕ := [446, 638, 156, 240, 371, 463, 206, 999, 414, 139, 901, 999, 999, 830, 1000, 0, 1000, 807, 1995, 606, 999, 0, 0, 999, 855, 2453, 999, 1797, 521, 170, 988, 1475, 1000, 1000, 104, 999, 0, 999, 547, 999, 496, 999, 196, 1000, 1448, 1001, 815, 0, 558, 1001, 1000, 735, 1000, 1001, 1001, 999, 1000, 1000, 999, 1001, 1001, 1000, 1001, 173, 928, 1001, 1001, 1694, 1001, 999, 1001, 2201, 840, 419, 856, 1001, 2351, 1001, 61, 1001, 999, 2078, 734, 1001, 589, 1000, 1001, 1001, 1000, 641, 1001, 732, 1957, 1001, 803, 1000, 855, 1001, 1001, 1000, 1001, 1001, 944, 1001, 1001, 1000, 1002, 800, 1001, 151, 973, 1000, 1000, 924, 988, 1001, 1001, 1001, 1000, 1001, 1001, 1002, 1001, 1001, 1001, 1000, 1001, 1002, 1002, 1000, 1000, 1000, 1001, 1000, 1002, 1000, 876, 999, 1001, 1000, 748, 919, 1000, 1001, 1001, 736, 1001, 1000, 815, 874, 926, 892, 814, 892]
theorem node88735 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 71 (insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88735 support demand code
    entries88735 ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 71 (insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries88736 : List (Fin 2295 × ℕ) := [(4, 48), (37, 19), (72, 110), (83, 72), (387, 2), (469, 32), (471, 84), (475, 106), (482, 38), (496, 37), (507, 30), (529, 27), (542, 54), (572, 49), (618, 60), (730, 14), (731, 64), (737, 32), (781, 22), (844, 73), (852, 41), (867, 83), (870, 23), (873, 98), (883, 17), (886, 115), (888, 79), (896, 61), (914, 39), (917, 36), (920, 24), (924, 36), (925, 53), (934, 73), (944, 23), (946, 50), (957, 37), (958, 55), (969, 39), (972, 29), (973, 118), (984, 14), (985, 40), (1009, 29), (1025, 11), (1041, 9), (1061, 28), (1072, 19), (1073, 31), (1090, 11), (1100, 47), (1108, 29), (1114, 6), (1123, 36), (1143, 25), (1149, 5), (1152, 2), (1155, 25), (1169, 84), (1171, 9), (1175, 43), (1179, 38), (1182, 25), (1212, 14), (1261, 27), (1266, 29), (1275, 5), (1281, 2), (1293, 32), (1323, 34), (1335, 15), (1481, 7), (1497, 10), (1528, 26), (1580, 23), (1710, 1), (1864, 11), (1991, 32), (2072, 8), (2073, 5), (2082, 10), (2085, 8), (2204, 25)]
def cs88736 : List ℕ := [75, 80, 86, 108, 112, 57, 21, 255, 104, 30, 193, 256, 256, 148, 256, 0, 256, 216, 440, 147, 256, 61, 0, 257, 186, 612, 256, 406, 110, 67, 255, 375, 246, 255, 43, 256, 0, 256, 129, 256, 182, 256, 23, 255, 416, 256, 322, 0, 128, 256, 256, 229, 256, 255, 256, 259, 256, 256, 256, 255, 256, 157, 255, 97, 171, 231, 256, 519, 256, 256, 211, 253, 234, 135, 253, 223, 358, 255, 35, 256, 256, 0, 247, 256, 138, 255, 255, 255, 255, 210, 256, 200, 285, 255, 237, 251, 255, 256, 256, 256, 256, 256, 255, 255, 256, 255, 256, 231, 256, 81, 255, 255, 255, 255, 256, 250, 256, 255, 255, 256, 255, 255, 256, 256, 256, 255, 254, 255, 255, 256, 256, 255, 255, 255, 256, 251, 212, 253, 256, 256, 240, 247, 256, 255, 236, 230, 255, 256, 255, 201, 256, 241, 210, 162]
theorem node88736 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88736 support demand code
    entries88736 ((insert 81 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 71 (insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node88729 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 71 (insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    81 node88735 node88736
def entries88731 : List (Fin 2295 × ℕ) := [(4, 103), (37, 50), (72, 44), (83, 34), (137, 3), (177, 27), (469, 39), (471, 106), (475, 162), (479, 6), (529, 59), (542, 110), (571, 13), (618, 15), (620, 16), (737, 46), (741, 15), (743, 30), (780, 7), (781, 40), (844, 73), (852, 32), (855, 20), (867, 74), (870, 20), (873, 79), (874, 66), (886, 146), (888, 79), (918, 74), (920, 17), (923, 8), (932, 14), (934, 49), (944, 25), (945, 58), (946, 119), (948, 17), (955, 11), (957, 42), (958, 53), (959, 4), (969, 32), (970, 21), (973, 134), (984, 16), (985, 60), (1005, 12), (1006, 40), (1009, 30), (1012, 12), (1025, 8), (1043, 13), (1049, 15), (1061, 9), (1073, 7), (1107, 2), (1108, 15), (1114, 1), (1133, 13), (1153, 8), (1155, 1), (1169, 48), (1174, 47), (1175, 27), (1179, 43), (1183, 23), (1186, 26), (1212, 14), (1228, 19), (1231, 3), (1235, 8), (1258, 6), (1261, 31), (1275, 3), (1293, 31), (1295, 29), (1323, 23), (1396, 38), (1400, 1), (1528, 9), (1534, 9), (1583, 9), (1636, 8), (1668, 16), (1698, 13), (1699, 52), (1903, 2), (2204, 17), (2288, 6)]
def cs88731 : List ℕ := [73, 142, 106, 162, 141, 70, 0, 256, 153, 52, 118, 255, 256, 256, 257, 0, 255, 230, 531, 194, 257, 0, 79, 256, 197, 637, 171, 306, 44, 79, 256, 387, 170, 256, 126, 256, 0, 256, 173, 256, 137, 255, 50, 255, 420, 256, 235, 0, 256, 255, 255, 186, 256, 255, 256, 256, 256, 256, 256, 256, 256, 78, 256, 113, 211, 255, 257, 373, 256, 256, 256, 100, 255, 132, 255, 257, 590, 255, 54, 256, 256, 256, 257, 240, 37, 256, 233, 256, 561, 199, 256, 256, 258, 256, 216, 256, 229, 256, 256, 256, 255, 255, 255, 256, 257, 256, 257, 212, 256, 94, 255, 257, 256, 233, 200, 255, 255, 256, 256, 291, 256, 257, 251, 254, 256, 252, 257, 257, 257, 256, 255, 256, 256, 256, 256, 255, 238, 242, 256, 256, 256, 257, 251, 256, 195, 240, 256, 256, 257, 250, 256, 256, 247, 238]
theorem node88731 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88731 support demand code
    entries88731 ((insert 71 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 88 (insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries88733 : List (Fin 2295 × ℕ) := [(4, 3778), (37, 3270), (72, 2122), (83, 1330), (179, 2843), (342, 86), (386, 1419), (469, 943), (471, 4904), (474, 910), (475, 6443), (479, 792), (529, 752), (542, 4100), (571, 1955), (572, 1600), (618, 887), (730, 1116), (731, 3772), (737, 1651), (739, 326), (743, 1376), (781, 2372), (844, 2646), (852, 715), (867, 3253), (870, 373), (873, 3244), (874, 986), (886, 5096), (888, 1644), (916, 218), (918, 625), (922, 2026), (924, 296), (925, 36), (934, 2926), (938, 1172), (944, 2193), (946, 311), (958, 2762), (969, 523), (972, 627), (973, 5161), (984, 522), (985, 2362), (1006, 887), (1009, 1012), (1025, 1386), (1043, 816), (1055, 443), (1073, 1366), (1100, 593), (1107, 567), (1123, 1597), (1141, 57), (1149, 78), (1153, 1137), (1155, 1832), (1169, 2861), (1174, 238), (1175, 1560), (1179, 1433), (1186, 1519), (1212, 459), (1231, 713), (1235, 187), (1261, 2575), (1269, 238), (1293, 998), (1395, 624), (1397, 1576), (1488, 1791), (1591, 78), (1625, 304), (1643, 26), (1646, 1530), (1705, 298), (1845, 101), (2204, 720)]
def cs88733 : List ℕ := [2646, 4721, 4904, 7353, 5285, 3270, 0, 10000, 7048, 0, 5375, 9999, 9999, 4982, 10000, 0, 10000, 8127, 18182, 9999, 9999, 0, 2843, 10000, 6757, 25910, 9999, 13817, 2122, 3147, 8835, 12500, 6775, 10000, 1798, 10000, 0, 10000, 8235, 9999, 7273, 10001, 2279, 9998, 13485, 10000, 9414, 0, 9598, 9999, 10000, 9699, 10001, 10000, 9999, 10000, 10001, 8963, 9999, 9999, 10000, 9999, 10000, 4186, 8365, 9999, 9999, 14387, 10000, 10000, 10001, 3576, 8708, 7357, 9475, 10000, 12312, 9999, 218, 10000, 9999, 10000, 10000, 7931, 10000, 10000, 7867, 9999, 3257, 7915, 10000, 8283, 14275, 10000, 8295, 10000, 9035, 10000, 10002, 10000, 10000, 9999, 9810, 10001, 9999, 7995, 14643, 7305, 8906, 4038, 9998, 9999, 10000, 9136, 10000, 10000, 10000, 10001, 9998, 10424, 10000, 9999, 10000, 9974, 10001, 9999, 9999, 10000, 8535, 10000, 10000, 9820, 9999, 10000, 9035, 7518, 9239, 9999, 9999, 10000, 10001, 8701, 9999, 8571, 10001, 9896, 7879, 10000, 10000, 8225, 10000, 8699, 9947, 9684]
theorem node88733 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 71 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 106 (insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88733 support demand code
    entries88733 ((insert 88 (insert 71 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 106 (insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries88734 : List (Fin 2295 × ℕ) := [(4, 30), (37, 46), (72, 24), (83, 10), (179, 18), (244, 6), (387, 18), (469, 15), (471, 37), (474, 21), (475, 51), (479, 14), (531, 18), (542, 45), (571, 5), (572, 26), (618, 24), (730, 32), (742, 10), (743, 3), (779, 18), (832, 6), (833, 23), (834, 1), (844, 22), (852, 11), (855, 5), (867, 32), (869, 1), (870, 1), (873, 34), (884, 19), (886, 42), (888, 8), (914, 6), (922, 23), (925, 7), (934, 39), (938, 22), (944, 21), (945, 14), (957, 11), (958, 12), (971, 17), (973, 51), (984, 2), (985, 19), (1006, 6), (1009, 6), (1025, 6), (1043, 8), (1045, 1), (1049, 1), (1055, 8), (1073, 23), (1075, 6), (1100, 4), (1108, 1), (1143, 1), (1155, 20), (1169, 33), (1171, 4), (1174, 12), (1175, 4), (1186, 13), (1212, 2), (1258, 14), (1266, 3), (1269, 14), (1281, 1), (1286, 13), (1395, 4), (1449, 3), (1528, 2), (1572, 7), (1591, 16), (1640, 4), (1646, 16), (1887, 4), (2204, 14), (2288, 4)]
def cs88734 : List ℕ := [23, 45, 38, 73, 55, 51, 0, 100, 76, 0, 56, 100, 100, 52, 99, 0, 99, 64, 182, 101, 100, 0, 18, 100, 74, 278, 93, 148, 24, 30, 100, 139, 58, 100, 16, 102, 0, 100, 88, 99, 84, 101, 21, 100, 123, 100, 112, 0, 84, 100, 100, 101, 100, 99, 100, 100, 101, 99, 100, 101, 96, 101, 100, 45, 59, 96, 99, 163, 100, 101, 101, 41, 100, 52, 92, 101, 115, 100, 36, 99, 100, 101, 100, 76, 100, 100, 83, 100, 30, 79, 100, 86, 121, 100, 66, 99, 100, 101, 101, 100, 100, 100, 101, 101, 99, 86, 0, 65, 100, 32, 100, 100, 93, 101, 100, 99, 101, 100, 101, 100, 73, 61, 101, 101, 100, 100, 101, 100, 47, 100, 99, 100, 101, 100, 100, 87, 94, 99, 101, 100, 87, 94, 100, 100, 53, 98, 100, 100, 101, 82, 80, 71, 98, 86]
theorem node88734 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 106 (insert 88 (insert 71 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88734 support demand code
    entries88734 ((insert 106 (insert 88 (insert 71 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node88732 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 71 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 71 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    106 node88733 node88734
theorem node88730 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    88 node88731 node88732
theorem node88725 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 92 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    71 node88729 node88730
def entries88727 : List (Fin 2295 × ℕ) := [(4, 21), (37, 28), (130, 14), (137, 6), (177, 39), (471, 17), (475, 68), (479, 19), (529, 5), (542, 31), (571, 1), (618, 16), (620, 8), (743, 12), (780, 23), (842, 9), (843, 17), (844, 31), (852, 26), (867, 31), (870, 2), (872, 13), (873, 45), (874, 2), (884, 1), (886, 60), (887, 26), (896, 10), (917, 39), (918, 30), (920, 11), (925, 11), (945, 24), (946, 37), (957, 11), (958, 21), (969, 6), (970, 21), (973, 50), (984, 22), (985, 13), (1006, 7), (1012, 4), (1023, 3), (1025, 6), (1034, 8), (1040, 4), (1041, 8), (1043, 3), (1045, 6), (1049, 9), (1061, 4), (1090, 11), (1099, 4), (1100, 17), (1123, 10), (1141, 6), (1153, 12), (1155, 9), (1169, 16), (1171, 6), (1174, 3), (1175, 29), (1176, 2), (1179, 16), (1181, 5), (1183, 3), (1186, 15), (1212, 2), (1231, 9), (1275, 4), (1313, 1), (1374, 5), (1580, 8), (1616, 1), (1636, 2), (1903, 7), (2204, 6), (2288, 10)]
def cs88727 : List ℕ := [32, 21, 17, 69, 75, 29, 0, 101, 50, 0, 31, 70, 100, 73, 61, 0, 98, 55, 159, 55, 101, 10, 39, 100, 17, 250, 72, 88, 0, 39, 100, 143, 79, 101, 32, 100, 0, 100, 67, 99, 34, 100, 0, 101, 224, 101, 124, 0, 100, 100, 99, 48, 87, 100, 99, 100, 101, 87, 106, 100, 100, 1, 75, 49, 63, 101, 100, 197, 100, 100, 99, 100, 94, 67, 99, 100, 184, 101, 15, 99, 61, 99, 99, 99, 2, 100, 99, 99, 249, 84, 100, 101, 0, 99, 54, 100, 77, 99, 100, 100, 99, 101, 50, 99, 74, 100, 100, 71, 98, 38, 101, 99, 81, 78, 86, 100, 100, 99, 100, 99, 87, 99, 88, 101, 100, 82, 100, 100, 100, 100, 101, 100, 101, 101, 90, 100, 99, 95, 101, 100, 100, 99, 82, 101, 101, 100, 100, 94, 100, 100, 101, 100, 100, 100]
theorem node88727 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88727 support demand code
    entries88727 ((insert 92 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 88 (insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries88728 : List (Fin 2295 × ℕ) := [(4, 258), (37, 345), (130, 171), (179, 121), (273, 79), (386, 32), (469, 424), (471, 189), (474, 137), (475, 396), (496, 214), (507, 3), (529, 219), (542, 316), (571, 119), (618, 287), (730, 384), (731, 50), (736, 143), (743, 60), (844, 212), (852, 133), (867, 431), (870, 2), (873, 562), (884, 96), (886, 502), (887, 315), (914, 131), (916, 70), (920, 124), (921, 12), (922, 22), (924, 65), (925, 243), (933, 126), (944, 54), (957, 209), (958, 237), (969, 68), (972, 71), (973, 525), (984, 112), (985, 133), (1009, 79), (1025, 48), (1043, 39), (1049, 43), (1056, 1), (1061, 46), (1073, 51), (1090, 37), (1100, 71), (1108, 117), (1114, 23), (1119, 23), (1123, 234), (1155, 147), (1169, 247), (1171, 149), (1174, 20), (1175, 208), (1179, 148), (1182, 63), (1186, 50), (1212, 25), (1232, 6), (1261, 143), (1293, 105), (1316, 42), (1322, 71), (1323, 143), (1374, 94), (1523, 24), (1528, 11), (1591, 69), (1623, 21), (1859, 42), (1991, 81), (1998, 99), (2074, 35), (2204, 47)]
def cs88728 : List ℕ := [254, 682, 189, 533, 391, 387, 42, 1000, 817, 3, 431, 1001, 1001, 781, 574, 0, 1000, 472, 1972, 779, 1001, 0, 121, 1001, 753, 2656, 999, 1557, 0, 252, 1000, 1603, 828, 999, 228, 1000, 0, 1000, 466, 1001, 459, 1001, 54, 999, 1498, 1001, 997, 0, 555, 999, 1001, 762, 1000, 1000, 999, 1182, 1001, 1000, 999, 999, 1000, 635, 1000, 316, 871, 1000, 1000, 1742, 1001, 999, 1000, 1000, 999, 581, 934, 901, 1304, 1000, 378, 1000, 434, 999, 999, 922, 668, 1000, 1000, 998, 380, 696, 999, 816, 0, 999, 931, 1000, 908, 999, 1001, 999, 1002, 1001, 387, 999, 717, 999, 1000, 922, 1001, 336, 1001, 1000, 1000, 877, 999, 1001, 1000, 1001, 999, 1001, 527, 938, 793, 1001, 1000, 1000, 1000, 1001, 878, 1000, 1001, 1000, 1001, 1001, 910, 1000, 1000, 920, 1000, 1002, 1001, 1001, 867, 948, 1001, 1001, 953, 1001, 1001, 935, 1001, 957, 853, 753]
theorem node88728 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 92 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88728 support demand code
    entries88728 ((insert 88 (insert 92 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node88726 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    88 node88727 node88728
theorem node88719 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 31 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    92 node88725 node88726
def entries88723 : List (Fin 2295 × ℕ) := [(4, 39), (37, 52), (72, 10), (98, 1), (179, 7), (342, 9), (475, 60), (498, 2), (542, 52), (632, 13), (694, 9), (695, 25), (731, 5), (737, 26), (742, 8), (780, 1), (844, 20), (846, 5), (847, 57), (849, 4), (852, 16), (856, 9), (867, 27), (869, 12), (870, 19), (872, 25), (873, 33), (884, 15), (886, 25), (887, 13), (888, 36), (896, 7), (902, 7), (920, 2), (944, 16), (952, 36), (958, 26), (960, 2), (970, 2), (973, 54), (984, 13), (985, 30), (1046, 1), (1047, 8), (1048, 6), (1055, 9), (1056, 7), (1061, 2), (1073, 11), (1075, 1), (1122, 8), (1130, 1), (1133, 6), (1153, 1), (1155, 4), (1169, 17), (1176, 12), (1177, 1), (1179, 11), (1182, 2), (1183, 12), (1186, 22), (1188, 26), (1212, 7), (1223, 1), (1226, 21), (1258, 2), (1261, 9), (1293, 21), (1323, 5), (1372, 3), (1381, 13), (1386, 1), (1400, 4), (1410, 3), (1472, 4), (1488, 9), (1497, 15), (1500, 5), (1605, 1), (1619, 7), (1689, 2), (1705, 7)]
def cs88723 : List ℕ := [21, 44, 57, 64, 56, 61, 0, 99, 94, 7, 37, 92, 100, 62, 101, 0, 41, 99, 195, 101, 100, 7, 7, 101, 7, 314, 101, 104, 10, 20, 99, 2, 67, 100, 66, 101, 0, 100, 69, 99, 34, 75, 25, 99, 171, 102, 80, 9, 72, 100, 99, 102, 100, 100, 100, 102, 100, 97, 101, 90, 101, 71, 100, 61, 78, 81, 257, 119, 100, 101, 101, 101, 69, 73, 53, 99, 219, 100, 29, 100, 101, 101, 100, 52, 87, 101, 71, 99, 101, 88, 101, 99, 203, 92, 47, 101, 63, 99, 101, 99, 102, 100, 100, 84, 102, 100, 99, 70, 100, 44, 100, 99, 99, 79, 97, 101, 98, 100, 99, 101, 100, 100, 102, 100, 98, 86, 100, 101, 101, 99, 99, 100, 99, 99, 101, 99, 73, 100, 98, 100, 95, 86, 99, 99, 95, 84, 99, 100, 99, 100, 98, 101, 99, 99]
theorem node88723 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 92 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88723 support demand code
    entries88723 ((insert 31 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 66 (insert 92 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries88724 : List (Fin 2295 × ℕ) := [(4, 63), (177, 22), (179, 86), (273, 13), (342, 11), (475, 78), (498, 43), (540, 40), (542, 91), (572, 109), (632, 63), (640, 2), (731, 3), (736, 14), (737, 27), (742, 6), (743, 14), (780, 38), (781, 55), (833, 1), (844, 46), (846, 29), (847, 104), (849, 32), (852, 77), (855, 57), (867, 59), (869, 54), (870, 32), (873, 109), (874, 27), (884, 3), (886, 99), (896, 19), (925, 16), (933, 26), (934, 82), (944, 20), (946, 13), (957, 31), (958, 60), (970, 26), (973, 119), (981, 5), (984, 18), (985, 63), (1006, 14), (1012, 6), (1023, 30), (1025, 39), (1045, 7), (1055, 36), (1072, 2), (1073, 53), (1090, 3), (1100, 20), (1108, 4), (1122, 11), (1143, 20), (1153, 32), (1155, 59), (1169, 70), (1174, 3), (1176, 41), (1179, 14), (1186, 8), (1188, 60), (1212, 41), (1226, 33), (1249, 10), (1261, 10), (1266, 5), (1269, 16), (1293, 71), (1398, 12), (1401, 19), (1449, 22), (1488, 50), (1497, 23), (1619, 38), (1887, 15)]
def cs88724 : List ℕ := [46, 92, 104, 110, 140, 57, 0, 256, 106, 38, 59, 164, 256, 136, 213, 0, 102, 256, 474, 109, 255, 19, 108, 256, 43, 582, 256, 243, 0, 171, 255, 0, 145, 256, 168, 256, 0, 257, 108, 256, 217, 256, 31, 255, 470, 255, 246, 0, 255, 256, 257, 224, 256, 256, 257, 318, 255, 256, 256, 247, 255, 256, 256, 102, 199, 256, 55, 329, 256, 256, 256, 256, 163, 168, 256, 256, 408, 256, 3, 255, 256, 256, 177, 197, 256, 211, 243, 256, 255, 224, 256, 227, 443, 255, 132, 255, 224, 256, 255, 256, 256, 256, 256, 256, 179, 256, 255, 205, 255, 63, 255, 256, 256, 197, 226, 255, 255, 256, 256, 272, 255, 256, 256, 254, 256, 256, 256, 256, 254, 255, 255, 256, 255, 256, 255, 243, 202, 246, 256, 256, 225, 256, 256, 255, 240, 201, 250, 255, 247, 212, 200, 188, 255, 227]
theorem node88724 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 31 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88724 support demand code
    entries88724 ((insert 66 (insert 31 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node88721 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 92 (insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    66 node88723 node88724
def entries88722 : List (Fin 2295 × ℕ) := [(4, 189), (72, 283), (137, 90), (179, 105), (307, 67), (475, 410), (498, 245), (507, 303), (527, 10), (540, 73), (542, 402), (571, 197), (632, 222), (639, 2), (731, 111), (743, 68), (780, 149), (844, 157), (846, 267), (847, 223), (849, 130), (852, 308), (867, 368), (869, 137), (870, 119), (873, 308), (884, 219), (886, 366), (887, 192), (921, 4), (924, 60), (925, 156), (933, 205), (945, 144), (946, 134), (957, 190), (958, 126), (969, 17), (970, 206), (972, 18), (973, 499), (984, 86), (985, 200), (1006, 153), (1025, 128), (1041, 10), (1049, 29), (1056, 33), (1061, 90), (1073, 131), (1090, 120), (1096, 16), (1107, 17), (1119, 29), (1122, 12), (1123, 171), (1143, 12), (1152, 54), (1153, 93), (1155, 69), (1169, 246), (1171, 100), (1176, 143), (1177, 113), (1179, 141), (1183, 112), (1186, 136), (1261, 41), (1269, 42), (1293, 195), (1316, 54), (1322, 31), (1323, 9), (1335, 35), (1374, 49), (1400, 48), (1488, 70), (1591, 100), (1616, 11), (1623, 120), (1635, 17), (1731, 19), (2288, 60)]
def cs88722 : List ℕ := [157, 456, 223, 540, 497, 0, 0, 955, 434, 303, 651, 666, 1000, 308, 947, 0, 675, 999, 1641, 389, 1000, 0, 105, 999, 303, 2527, 1000, 1036, 283, 327, 1000, 124, 929, 1000, 620, 1000, 0, 1000, 388, 1000, 559, 999, 0, 1002, 1606, 1001, 831, 0, 494, 1000, 999, 888, 1000, 1000, 1000, 1000, 1001, 1000, 1000, 769, 999, 611, 1000, 502, 615, 855, 1001, 1458, 999, 1000, 711, 1000, 876, 345, 1002, 1001, 1306, 1001, 431, 1001, 389, 999, 698, 1000, 527, 1002, 871, 1001, 1000, 924, 999, 917, 0, 1000, 684, 1001, 713, 1002, 1000, 1000, 1000, 1001, 571, 999, 820, 1002, 1000, 905, 1001, 349, 1001, 1001, 598, 845, 1000, 1001, 1000, 999, 1002, 1023, 787, 1001, 726, 1001, 1000, 998, 1001, 1000, 1000, 1001, 1001, 1001, 1001, 1000, 1000, 1001, 1002, 903, 1000, 1000, 999, 1001, 1001, 1000, 1000, 1000, 1001, 1001, 1000, 922, 1000, 823, 1000, 827]
theorem node88722 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 31 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88722 support demand code
    entries88722 ((insert 92 (insert 31 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node88720 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    92 node88721 node88722
theorem node88709 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    31 node88719 node88720
def entries88711 : List (Fin 2295 × ℕ) := [(4, 96), (35, 93), (72, 33), (83, 30), (130, 41), (137, 14), (342, 45), (479, 19), (542, 54), (572, 32), (620, 38), (731, 67), (781, 16), (844, 38), (860, 55), (865, 74), (867, 87), (869, 43), (870, 47), (873, 121), (884, 10), (886, 116), (888, 103), (890, 40), (892, 56), (912, 37), (913, 15), (914, 38), (915, 40), (916, 31), (917, 29), (918, 21), (920, 26), (921, 4), (934, 42), (937, 18), (938, 38), (952, 24), (957, 38), (958, 8), (969, 38), (973, 133), (984, 17), (985, 90), (1009, 34), (1090, 2), (1093, 13), (1107, 18), (1108, 23), (1119, 15), (1123, 25), (1133, 14), (1143, 14), (1155, 45), (1169, 65), (1174, 26), (1175, 29), (1176, 3), (1179, 52), (1186, 23), (1188, 38), (1212, 11), (1229, 2), (1232, 21), (1258, 1), (1261, 50), (1275, 5), (1293, 35), (1322, 16), (1323, 6), (1374, 31), (1400, 44), (1469, 16), (1552, 4), (1572, 17), (1591, 17), (1616, 15), (1623, 15), (1636, 6), (1657, 3), (1887, 24), (1903, 1), (2074, 13), (2283, 4), (2288, 16)]
def cs88711 : List ℕ := [41, 99, 0, 0, 118, 93, 0, 60, 247, 0, 194, 123, 140, 214, 186, 0, 184, 257, 121, 135, 256, 96, 0, 257, 0, 777, 256, 339, 49, 187, 257, 256, 0, 257, 55, 256, 16, 255, 33, 256, 123, 255, 45, 257, 592, 255, 325, 15, 121, 256, 255, 119, 253, 256, 255, 685, 256, 255, 257, 256, 255, 153, 256, 129, 207, 255, 255, 668, 256, 256, 254, 256, 253, 219, 256, 253, 452, 256, 81, 257, 256, 219, 206, 257, 189, 255, 255, 256, 255, 206, 256, 240, 255, 256, 239, 255, 190, 256, 255, 256, 256, 257, 256, 256, 254, 255, 255, 218, 257, 88, 256, 257, 256, 123, 255, 256, 255, 256, 256, 256, 257, 194, 247, 255, 257, 232, 255, 255, 185, 254, 256, 256, 255, 256, 255, 256, 208, 256, 255, 257, 256, 255, 256, 256, 252, 255, 227, 257, 228, 203, 255, 256, 246, 256]
theorem node88711 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88711 support demand code
    entries88711 ((insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 55 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries88717 : List (Fin 2295 × ℕ) := [(4, 100), (37, 27), (72, 94), (83, 41), (179, 11), (358, 7), (479, 35), (498, 17), (571, 118), (618, 89), (619, 26), (630, 5), (632, 45), (731, 71), (737, 29), (742, 3), (743, 11), (780, 13), (844, 81), (867, 58), (869, 21), (886, 99), (887, 64), (888, 21), (915, 37), (916, 24), (920, 31), (922, 44), (924, 20), (925, 53), (934, 48), (944, 49), (945, 69), (946, 21), (957, 37), (958, 36), (969, 3), (973, 124), (984, 13), (985, 45), (1006, 38), (1009, 16), (1012, 23), (1025, 49), (1043, 8), (1055, 50), (1073, 31), (1100, 14), (1107, 1), (1108, 7), (1143, 20), (1153, 21), (1155, 76), (1169, 52), (1171, 23), (1174, 24), (1175, 28), (1179, 28), (1188, 68), (1212, 56), (1258, 11), (1271, 18), (1293, 11), (1308, 39), (1344, 23), (1396, 5), (1400, 1), (1459, 8), (1488, 36), (1497, 3), (1556, 3), (1623, 43), (1625, 32), (1629, 55), (1705, 12), (1728, 17), (1845, 1), (1864, 62)]
def cs88717 : List ℕ := [81, 100, 0, 0, 135, 27, 62, 116, 144, 0, 207, 124, 99, 0, 256, 0, 154, 243, 0, 230, 256, 0, 11, 255, 0, 647, 203, 296, 94, 155, 256, 255, 190, 256, 52, 256, 0, 257, 132, 255, 201, 257, 49, 256, 299, 256, 218, 0, 247, 256, 257, 256, 258, 254, 257, 112, 255, 256, 236, 255, 256, 257, 256, 62, 253, 254, 257, 486, 257, 588, 255, 257, 257, 179, 242, 256, 361, 254, 84, 256, 257, 518, 193, 258, 257, 255, 233, 256, 256, 160, 257, 205, 257, 259, 134, 256, 226, 256, 256, 258, 256, 255, 196, 258, 212, 252, 257, 244, 257, 84, 255, 257, 258, 232, 255, 255, 258, 257, 256, 256, 258, 256, 256, 255, 257, 256, 255, 256, 256, 257, 256, 231, 256, 256, 257, 248, 256, 255, 255, 256, 227, 235, 233, 256, 233, 223, 254, 256, 255, 227, 221, 228, 240, 256]
theorem node88717 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88717 support demand code
    entries88717 ((insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries88718 : List (Fin 2295 × ℕ) := [(72, 40), (83, 1), (137, 33), (387, 4), (479, 37), (498, 9), (573, 6), (618, 30), (630, 33), (632, 6), (730, 9), (731, 44), (737, 4), (781, 5), (844, 39), (860, 27), (867, 10), (869, 7), (886, 23), (888, 27), (896, 26), (916, 10), (917, 29), (921, 22), (924, 28), (925, 14), (934, 21), (944, 13), (945, 5), (946, 11), (952, 7), (957, 14), (958, 22), (969, 2), (971, 15), (973, 48), (984, 8), (985, 18), (1009, 10), (1025, 3), (1041, 9), (1049, 2), (1061, 10), (1072, 3), (1073, 19), (1100, 19), (1108, 10), (1114, 9), (1123, 9), (1143, 14), (1155, 16), (1169, 34), (1174, 1), (1175, 15), (1179, 18), (1182, 10), (1212, 7), (1266, 22), (1293, 5), (1322, 3), (1323, 10), (1354, 8), (1398, 2), (1400, 1), (1502, 2), (1528, 8), (1540, 1), (1605, 5), (1629, 31), (1864, 20), (1991, 11)]
def cs88718 : List ℕ := [39, 0, 0, 0, 37, 0, 20, 76, 36, 0, 81, 28, 76, 0, 60, 0, 87, 47, 0, 33, 100, 26, 0, 100, 0, 236, 33, 118, 40, 59, 100, 99, 93, 100, 16, 101, 0, 100, 40, 99, 91, 100, 13, 100, 174, 100, 141, 0, 74, 99, 100, 89, 100, 99, 100, 52, 100, 99, 80, 100, 101, 58, 101, 62, 50, 91, 100, 198, 100, 159, 86, 99, 92, 93, 99, 100, 105, 100, 20, 99, 101, 0, 98, 99, 99, 99, 72, 100, 99, 69, 100, 84, 88, 100, 99, 100, 97, 99, 100, 100, 99, 100, 83, 96, 100, 99, 99, 73, 99, 40, 100, 99, 99, 99, 86, 94, 99, 99, 101, 99, 99, 99, 99, 98, 99, 92, 100, 99, 93, 99, 99, 100, 100, 99, 99, 91, 75, 100, 99, 100, 98, 96, 99, 99, 89, 100, 98, 99, 91, 75, 92, 94, 83, 71]
theorem node88718 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88718 support demand code
    entries88718 ((insert 81 (insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node88713 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    81 node88717 node88718
def entries88715 : List (Fin 2295 × ℕ) := [(4, 115), (37, 7), (72, 106), (83, 79), (86, 9), (135, 12), (137, 10), (179, 34), (387, 10), (490, 21), (512, 31), (542, 31), (572, 134), (618, 74), (620, 10), (737, 16), (743, 25), (779, 11), (781, 6), (844, 52), (867, 25), (885, 5), (886, 104), (888, 115), (915, 8), (916, 68), (917, 3), (918, 40), (920, 1), (924, 6), (925, 64), (934, 88), (938, 8), (944, 17), (957, 33), (958, 59), (959, 55), (960, 55), (969, 22), (972, 18), (973, 131), (984, 14), (985, 73), (1006, 18), (1009, 15), (1025, 20), (1055, 7), (1073, 60), (1100, 31), (1108, 1), (1122, 4), (1123, 26), (1141, 4), (1143, 38), (1153, 25), (1155, 60), (1169, 89), (1174, 33), (1179, 29), (1186, 16), (1212, 19), (1261, 35), (1266, 18), (1293, 33), (1323, 13), (1335, 17), (1354, 8), (1397, 15), (1400, 7), (1459, 25), (1488, 24), (1497, 4), (1517, 1), (1541, 12), (1623, 36), (1629, 94), (1991, 23), (2085, 12)]
def cs88715 : List ℕ := [52, 115, 0, 0, 115, 7, 22, 52, 122, 0, 256, 110, 59, 0, 252, 0, 256, 256, 0, 256, 255, 0, 34, 256, 0, 706, 249, 278, 106, 34, 256, 256, 217, 256, 33, 256, 0, 172, 147, 256, 232, 255, 17, 257, 293, 246, 137, 0, 34, 255, 255, 257, 245, 257, 256, 126, 256, 137, 0, 256, 257, 256, 256, 41, 189, 257, 257, 572, 256, 0, 258, 256, 200, 22, 186, 258, 359, 255, 76, 255, 249, 256, 232, 255, 52, 251, 147, 257, 256, 169, 255, 218, 550, 255, 185, 215, 257, 257, 257, 255, 255, 256, 256, 256, 257, 256, 258, 180, 255, 82, 257, 256, 257, 201, 257, 217, 256, 256, 257, 257, 221, 258, 248, 255, 256, 257, 257, 257, 258, 256, 256, 257, 257, 257, 256, 256, 184, 256, 257, 256, 256, 240, 256, 247, 257, 220, 231, 256, 230, 233, 222, 217, 237, 226]
theorem node88715 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88715 support demand code
    entries88715 ((insert 69 (insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries88716 : List (Fin 2295 × ℕ) := [(4, 17), (72, 127), (83, 54), (137, 22), (496, 32), (498, 100), (542, 31), (573, 14), (574, 11), (618, 63), (743, 38), (843, 2), (844, 81), (852, 84), (858, 15), (867, 65), (870, 23), (886, 88), (888, 30), (915, 29), (917, 28), (918, 14), (920, 9), (921, 1), (924, 53), (925, 40), (933, 29), (945, 5), (957, 35), (958, 54), (966, 1), (969, 23), (970, 1), (972, 25), (973, 129), (984, 45), (985, 56), (1009, 21), (1041, 1), (1045, 17), (1048, 8), (1049, 5), (1056, 5), (1061, 12), (1069, 4), (1073, 35), (1095, 3), (1096, 12), (1100, 23), (1107, 8), (1108, 1), (1114, 11), (1122, 10), (1123, 33), (1133, 13), (1153, 8), (1155, 20), (1169, 56), (1171, 18), (1174, 27), (1175, 44), (1179, 36), (1183, 5), (1186, 18), (1212, 53), (1258, 4), (1261, 26), (1273, 23), (1276, 9), (1293, 21), (1374, 38), (1488, 3), (1528, 6), (1572, 21), (1583, 8), (1623, 81), (1629, 64), (1855, 28), (2169, 8)]
def cs88716 : List ℕ := [81, 17, 0, 0, 101, 0, 15, 165, 149, 0, 256, 77, 213, 0, 175, 0, 174, 190, 0, 55, 256, 0, 0, 256, 0, 639, 55, 207, 127, 0, 256, 256, 157, 256, 71, 257, 0, 144, 127, 257, 83, 256, 0, 256, 402, 256, 210, 0, 33, 256, 256, 257, 174, 256, 257, 130, 256, 194, 47, 257, 256, 0, 256, 55, 232, 255, 257, 543, 256, 33, 256, 255, 154, 24, 256, 257, 230, 255, 53, 257, 63, 219, 104, 256, 48, 257, 185, 256, 256, 254, 257, 242, 30, 257, 251, 255, 134, 256, 256, 256, 257, 256, 73, 255, 257, 256, 255, 203, 255, 155, 256, 257, 155, 159, 211, 257, 255, 258, 257, 256, 126, 231, 223, 256, 256, 224, 257, 256, 206, 256, 256, 256, 256, 256, 253, 256, 257, 246, 257, 256, 257, 256, 256, 257, 257, 256, 256, 257, 257, 256, 256, 257, 257, 257]
theorem node88716 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 69 (insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs88716 support demand code
    entries88716 ((insert 92 (insert 69 (insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node88714 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    92 node88715 node88716
theorem node88712 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    69 node88713 node88714
theorem node88710 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    55 node88711 node88712
theorem node88708 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 36 (insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    18 node88709 node88710
theorem node88706 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 34 (insert 47 (insert 109 (insert 78 ∅))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    36 node88707 node88708
theorem node88571 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 47 (insert 109 (insert 78 ∅)))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 67 (insert 25 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    21 node88705 node88706
#print axioms node88571
end OmissionResidualCover31Fused
