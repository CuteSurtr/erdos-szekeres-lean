import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries76143 : List (Fin 2295 × ℕ) := [(475, 11), (482, 1), (507, 19), (583, 13), (587, 10), (588, 20), (617, 60), (618, 33), (631, 26), (731, 10), (741, 4), (742, 3), (743, 12), (779, 60), (781, 40), (784, 14), (785, 19), (852, 30), (858, 26), (859, 12), (873, 3), (892, 37), (894, 53), (896, 16), (901, 18), (902, 1), (925, 32), (933, 14), (934, 20), (938, 3), (944, 37), (958, 28), (960, 34), (966, 5), (973, 53), (977, 7), (978, 9), (981, 8), (1006, 4), (1009, 10), (1012, 11), (1061, 1), (1068, 5), (1070, 11), (1073, 12), (1107, 1), (1114, 22), (1122, 4), (1123, 20), (1128, 3), (1143, 4), (1154, 5), (1167, 28), (1175, 14), (1184, 1), (1186, 2), (1188, 8), (1212, 17), (1223, 10), (1226, 3), (1276, 8), (1279, 60), (1293, 12), (1449, 2), (1516, 5), (1517, 4), (1572, 3), (1622, 25), (1669, 10), (1705, 9), (1765, 4), (1773, 6), (1903, 1), (2016, 28), (2062, 1)]
def cs76143 : List ℕ := [10, 60, 0, 43, 40, 61, 64, 100, 55, 23, 0, 89, 99, 32, 34, 0, 78, 101, 99, 0, 100, 178, 58, 93, 92, 0, 99, 269, 0, 60, 100, 99, 100, 100, 14, 100, 12, 101, 28, 99, 34, 101, 73, 41, 239, 71, 217, 61, 49, 79, 101, 4, 101, 100, 100, 100, 101, 99, 99, 100, 205, 99, 101, 18, 86, 100, 1, 217, 96, 99, 219, 99, 81, 31, 101, 264, 111, 71, 58, 101, 81, 185, 100, 99, 95, 99, 100, 100, 100, 74, 100, 89, 246, 100, 101, 101, 100, 100, 100, 99, 100, 100, 99, 101, 100, 100, 100, 94, 99, 20, 100, 100, 89, 86, 101, 100, 99, 101, 99, 79, 67, 90, 99, 88, 100, 100, 99, 100, 101, 99, 101, 100, 100, 100, 90, 95, 70, 86, 100, 100, 66, 67, 100, 99, 85, 88, 90, 100, 98, 98, 100, 100, 86, 91]
theorem node76143 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 70 (insert 81 (insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76143 support demand code
    entries76143 ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 60 (insert 70 (insert 81 (insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries76144 : List (Fin 2295 × ℕ) := [(46, 1), (49, 12), (179, 1), (482, 12), (507, 18), (581, 11), (583, 24), (587, 33), (588, 25), (617, 56), (618, 14), (631, 9), (727, 17), (729, 10), (737, 16), (741, 30), (742, 9), (817, 6), (852, 25), (858, 6), (859, 1), (869, 4), (888, 3), (892, 47), (894, 32), (896, 30), (898, 3), (902, 1), (933, 9), (934, 32), (944, 27), (958, 24), (959, 6), (960, 36), (962, 17), (966, 4), (970, 2), (973, 50), (978, 5), (1012, 11), (1033, 5), (1040, 1), (1061, 21), (1070, 20), (1073, 8), (1100, 17), (1113, 7), (1114, 10), (1121, 11), (1123, 17), (1167, 31), (1175, 14), (1184, 8), (1186, 18), (1223, 17), (1226, 12), (1279, 53), (1286, 4), (1293, 9), (1308, 8), (1364, 3), (1375, 10), (1433, 3), (1517, 19), (1545, 6), (1591, 13), (1674, 3), (1773, 9), (1859, 5), (2016, 22), (2061, 13), (2288, 2)]
def cs76144 : List ℕ := [22, 53, 0, 22, 42, 70, 65, 100, 52, 18, 0, 98, 100, 22, 35, 0, 87, 100, 100, 3, 100, 179, 84, 76, 83, 0, 78, 265, 0, 45, 99, 100, 100, 100, 14, 101, 1, 100, 23, 100, 41, 66, 97, 49, 209, 37, 200, 100, 35, 58, 89, 0, 100, 89, 101, 100, 100, 100, 100, 100, 0, 100, 100, 29, 100, 100, 3, 189, 83, 100, 76, 100, 58, 47, 100, 144, 143, 100, 43, 99, 101, 210, 100, 99, 76, 78, 100, 100, 100, 92, 99, 92, 189, 99, 100, 100, 100, 98, 100, 99, 100, 99, 100, 100, 101, 99, 99, 98, 99, 43, 99, 98, 68, 98, 100, 99, 99, 100, 100, 72, 91, 100, 99, 80, 100, 94, 98, 99, 99, 99, 99, 95, 99, 99, 95, 92, 64, 81, 99, 99, 66, 78, 99, 99, 52, 85, 99, 99, 99, 88, 79, 82, 76, 68]
theorem node76144 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 81 (insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76144 support demand code
    entries76144 ((insert 60 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 70 (insert 81 (insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76141 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 81 (insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 70 (insert 81 (insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    60 node76143 node76144
def entries76142 : List (Fin 2295 × ℕ) := [(46, 7), (179, 24), (342, 2), (482, 13), (507, 25), (514, 2), (581, 10), (583, 19), (617, 45), (631, 39), (664, 8), (727, 18), (729, 4), (737, 27), (797, 7), (851, 6), (852, 14), (858, 11), (869, 13), (873, 6), (888, 10), (892, 42), (894, 49), (896, 22), (915, 22), (919, 18), (925, 26), (933, 13), (934, 12), (944, 36), (958, 24), (959, 10), (960, 20), (966, 2), (970, 18), (973, 35), (978, 21), (981, 1), (1007, 8), (1009, 1), (1011, 8), (1012, 24), (1049, 7), (1061, 11), (1069, 11), (1070, 10), (1100, 10), (1108, 3), (1113, 11), (1114, 9), (1123, 30), (1143, 9), (1149, 17), (1167, 41), (1175, 13), (1188, 13), (1212, 17), (1223, 31), (1247, 3), (1276, 6), (1279, 15), (1293, 5), (1297, 7), (1384, 10), (1417, 4), (1517, 7), (1590, 7), (1591, 5), (1622, 3), (1667, 8), (1705, 3), (1859, 34), (1991, 12), (2062, 7)]
def cs76142 : List ℕ := [65, 15, 0, 0, 51, 62, 59, 100, 38, 25, 2, 100, 100, 13, 7, 7, 95, 100, 100, 10, 100, 152, 24, 80, 61, 0, 99, 241, 0, 77, 100, 100, 100, 99, 13, 100, 13, 100, 24, 99, 25, 100, 47, 62, 283, 94, 190, 85, 47, 99, 88, 0, 100, 91, 99, 100, 100, 100, 100, 100, 82, 91, 100, 30, 99, 98, 28, 199, 100, 100, 0, 100, 94, 50, 100, 156, 118, 100, 73, 100, 100, 111, 101, 100, 88, 74, 100, 99, 99, 100, 100, 100, 137, 100, 100, 100, 101, 99, 101, 100, 99, 106, 90, 66, 100, 99, 100, 100, 100, 21, 100, 99, 64, 99, 100, 99, 99, 99, 100, 56, 76, 100, 100, 98, 99, 94, 99, 100, 100, 99, 98, 89, 99, 100, 82, 85, 76, 80, 99, 99, 92, 85, 100, 96, 77, 60, 100, 99, 99, 96, 96, 78, 62, 65]
theorem node76142 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76142 support demand code
    entries76142 ((insert 70 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76139 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    70 node76141 node76142
def entries76140 : List (Fin 2295 × ℕ) := [(43, 29), (46, 8), (179, 75), (482, 21), (484, 59), (583, 30), (588, 16), (617, 104), (618, 98), (631, 71), (727, 14), (730, 16), (737, 64), (779, 59), (781, 25), (785, 7), (843, 53), (851, 40), (852, 55), (858, 31), (869, 16), (873, 83), (888, 14), (892, 16), (894, 114), (896, 121), (917, 55), (919, 23), (925, 103), (934, 54), (944, 63), (946, 54), (957, 16), (958, 66), (966, 21), (970, 17), (973, 128), (977, 15), (978, 30), (985, 6), (1007, 19), (1043, 10), (1061, 18), (1070, 11), (1096, 10), (1100, 44), (1110, 25), (1114, 58), (1122, 18), (1123, 60), (1138, 20), (1143, 47), (1149, 2), (1167, 78), (1175, 10), (1178, 22), (1179, 28), (1185, 23), (1186, 50), (1223, 83), (1266, 25), (1276, 10), (1279, 78), (1293, 3), (1375, 1), (1393, 49), (1516, 19), (1517, 63), (1705, 9), (1903, 3), (1991, 19), (1997, 15)]
def cs76140 : List ℕ := [83, 78, 0, 15, 178, 158, 131, 256, 83, 15, 0, 255, 256, 83, 37, 49, 256, 255, 256, 14, 255, 367, 91, 161, 163, 6, 256, 621, 49, 198, 255, 256, 256, 256, 10, 256, 89, 255, 75, 256, 103, 237, 128, 114, 697, 257, 566, 165, 145, 251, 256, 0, 255, 254, 256, 256, 256, 256, 255, 256, 257, 31, 255, 100, 253, 256, 64, 568, 257, 256, 214, 256, 212, 82, 255, 437, 227, 218, 135, 256, 202, 16, 256, 257, 193, 256, 257, 256, 257, 199, 255, 197, 352, 256, 256, 183, 255, 258, 257, 255, 257, 255, 257, 141, 209, 256, 257, 254, 258, 123, 255, 254, 169, 254, 254, 256, 258, 256, 254, 138, 146, 256, 256, 256, 258, 227, 256, 256, 250, 257, 256, 235, 257, 255, 234, 222, 150, 256, 256, 256, 239, 210, 255, 257, 258, 207, 207, 256, 253, 242, 248, 257, 216, 214]
theorem node76140 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76140 support demand code
    entries76140 ((insert 81 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76133 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 75 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    81 node76139 node76140
def entries76137 : List (Fin 2295 × ℕ) := [(46, 46), (49, 21), (179, 34), (181, 12), (409, 10), (469, 85), (474, 7), (475, 41), (479, 8), (482, 67), (494, 43), (514, 37), (587, 45), (588, 96), (629, 54), (664, 12), (737, 92), (741, 32), (742, 4), (743, 22), (812, 43), (819, 14), (842, 41), (858, 99), (888, 120), (890, 33), (892, 93), (894, 161), (896, 86), (899, 73), (901, 30), (915, 20), (922, 5), (925, 62), (933, 7), (938, 84), (944, 63), (958, 57), (959, 54), (960, 48), (966, 11), (973, 139), (977, 33), (978, 64), (1009, 6), (1033, 14), (1043, 26), (1061, 2), (1072, 13), (1073, 26), (1110, 23), (1113, 11), (1114, 44), (1123, 36), (1128, 2), (1159, 12), (1167, 47), (1175, 44), (1185, 47), (1186, 70), (1223, 85), (1279, 35), (1308, 8), (1488, 24), (1497, 6), (1508, 16), (1560, 1), (1622, 16), (1688, 13), (1705, 14), (1791, 3), (1845, 20), (1852, 8), (1887, 27), (2292, 49)]
def cs76137 : List ℕ := [85, 120, 0, 48, 93, 102, 145, 256, 106, 0, 37, 253, 256, 0, 46, 0, 257, 256, 256, 120, 256, 448, 187, 231, 194, 0, 120, 753, 0, 196, 256, 256, 256, 256, 44, 256, 0, 446, 34, 256, 15, 257, 241, 160, 617, 120, 538, 256, 83, 255, 257, 0, 256, 225, 256, 257, 256, 256, 256, 256, 230, 194, 256, 24, 211, 175, 153, 689, 256, 257, 175, 257, 256, 156, 257, 0, 451, 256, 265, 256, 169, 459, 256, 256, 192, 92, 189, 249, 256, 256, 255, 252, 395, 256, 257, 256, 256, 255, 256, 255, 257, 256, 162, 257, 256, 257, 256, 256, 256, 118, 256, 256, 196, 236, 257, 256, 256, 256, 242, 249, 174, 255, 257, 257, 257, 198, 256, 255, 255, 255, 256, 236, 255, 256, 256, 253, 209, 206, 256, 255, 249, 219, 256, 256, 227, 250, 231, 256, 254, 255, 256, 256, 249, 256]
theorem node76137 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 81 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76137 support demand code
    entries76137 ((insert 75 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 81 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76138 : List (Fin 2295 × ℕ) := [(23, 11), (46, 36), (49, 11), (179, 23), (466, 1), (542, 10), (583, 23), (664, 15), (730, 12), (737, 52), (740, 12), (741, 16), (742, 4), (743, 14), (842, 2), (873, 35), (888, 35), (890, 15), (892, 6), (894, 44), (896, 29), (915, 19), (919, 16), (925, 28), (934, 3), (938, 11), (944, 29), (958, 20), (970, 18), (973, 46), (977, 10), (978, 21), (1033, 3), (1043, 4), (1073, 10), (1095, 7), (1096, 11), (1100, 18), (1110, 3), (1113, 8), (1114, 17), (1123, 25), (1143, 7), (1149, 5), (1167, 34), (1175, 17), (1185, 7), (1186, 21), (1188, 6), (1219, 1), (1223, 45), (1226, 20), (1261, 8), (1276, 3), (1279, 43), (1293, 4), (1335, 11), (1411, 8), (1488, 4), (1503, 2), (1545, 3), (1605, 17), (1674, 8), (1791, 4), (1845, 4), (1852, 2), (1887, 15), (2023, 4)]
def cs76138 : List ℕ := [46, 44, 0, 1, 56, 43, 44, 101, 56, 0, 0, 90, 101, 35, 54, 0, 100, 100, 101, 43, 100, 161, 23, 100, 43, 0, 78, 183, 0, 67, 100, 101, 43, 101, 18, 88, 0, 0, 31, 101, 11, 11, 37, 55, 283, 66, 172, 8, 88, 100, 100, 8, 100, 95, 100, 101, 99, 100, 100, 100, 88, 73, 60, 41, 73, 101, 50, 204, 100, 100, 72, 99, 100, 85, 100, 0, 154, 86, 63, 101, 100, 107, 100, 100, 88, 49, 95, 99, 98, 101, 101, 80, 126, 100, 77, 100, 100, 100, 99, 101, 100, 101, 91, 101, 99, 100, 99, 101, 100, 28, 101, 100, 85, 99, 100, 97, 100, 100, 87, 88, 87, 99, 99, 101, 100, 85, 100, 99, 98, 101, 95, 97, 99, 100, 99, 99, 72, 84, 99, 100, 99, 77, 101, 100, 100, 99, 99, 101, 94, 100, 93, 95, 96, 81]
theorem node76138 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 75 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76138 support demand code
    entries76138 ((insert 37 (insert 75 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 81 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76135 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 75 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    37 node76137 node76138
def entries76136 : List (Fin 2295 × ℕ) := [(23, 11), (46, 3), (179, 41), (496, 21), (583, 22), (585, 2), (631, 7), (664, 17), (730, 14), (737, 37), (817, 6), (842, 6), (843, 25), (852, 24), (858, 19), (873, 41), (888, 41), (890, 17), (894, 29), (896, 40), (899, 14), (901, 6), (914, 5), (915, 6), (917, 16), (925, 42), (934, 5), (944, 14), (945, 7), (946, 5), (957, 8), (958, 30), (966, 10), (972, 5), (973, 45), (977, 1), (978, 21), (981, 14), (1043, 1), (1061, 6), (1073, 10), (1096, 8), (1099, 1), (1100, 25), (1110, 12), (1114, 29), (1122, 11), (1123, 25), (1125, 1), (1128, 3), (1139, 6), (1143, 10), (1152, 4), (1153, 10), (1167, 35), (1175, 21), (1186, 13), (1212, 8), (1223, 10), (1276, 2), (1279, 28), (1481, 2), (1517, 23), (1528, 11), (1578, 3), (1605, 2), (1683, 8), (1852, 11), (1859, 18), (1991, 5), (2055, 9), (2287, 2), (2292, 15)]
def cs76136 : List ℕ := [28, 30, 0, 0, 48, 46, 66, 96, 31, 0, 3, 84, 77, 43, 6, 3, 60, 101, 100, 41, 101, 118, 41, 100, 47, 0, 82, 214, 0, 81, 100, 100, 100, 100, 21, 101, 3, 100, 41, 100, 29, 73, 17, 56, 252, 100, 170, 33, 92, 99, 100, 0, 100, 88, 101, 100, 100, 100, 99, 100, 100, 39, 99, 35, 70, 56, 60, 228, 100, 100, 19, 99, 99, 54, 102, 0, 134, 100, 59, 100, 92, 0, 99, 99, 94, 54, 100, 100, 100, 85, 100, 87, 83, 100, 98, 94, 101, 79, 99, 101, 100, 101, 69, 99, 101, 101, 100, 101, 100, 26, 101, 101, 99, 101, 96, 100, 100, 99, 102, 85, 74, 100, 101, 92, 100, 80, 101, 100, 100, 101, 101, 101, 101, 101, 100, 101, 78, 80, 101, 101, 100, 71, 101, 101, 101, 93, 78, 101, 101, 98, 84, 101, 78, 68]
theorem node76136 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 75 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76136 support demand code
    entries76136 ((insert 81 (insert 75 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76134 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 75 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    81 node76135 node76136
theorem node76127 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 21 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    75 node76133 node76134
def entries76131 : List (Fin 2295 × ℕ) := [(20, 43), (49, 15), (177, 36), (179, 26), (471, 22), (542, 65), (587, 5), (588, 81), (617, 95), (618, 25), (619, 30), (620, 24), (630, 26), (737, 39), (742, 2), (743, 39), (781, 16), (813, 24), (849, 8), (852, 74), (859, 32), (860, 29), (869, 55), (870, 10), (874, 51), (888, 7), (898, 21), (915, 30), (918, 23), (919, 21), (925, 63), (933, 31), (934, 59), (936, 21), (938, 35), (944, 87), (958, 73), (959, 18), (960, 65), (962, 23), (966, 17), (970, 11), (973, 127), (978, 3), (981, 43), (1006, 21), (1009, 3), (1012, 32), (1041, 2), (1055, 18), (1061, 51), (1073, 46), (1100, 35), (1110, 1), (1113, 49), (1114, 32), (1123, 33), (1143, 47), (1155, 23), (1167, 106), (1175, 23), (1182, 1), (1185, 22), (1186, 23), (1226, 57), (1266, 38), (1276, 8), (1279, 160), (1293, 24), (1354, 18), (1395, 18), (1397, 1), (1398, 25), (1433, 5), (1488, 58), (1517, 31), (1681, 8), (1682, 59), (1846, 6), (2292, 25)]
def cs76131 : List ℕ := [0, 160, 22, 51, 74, 160, 31, 256, 119, 0, 0, 256, 244, 94, 65, 0, 182, 256, 256, 7, 256, 0, 228, 225, 225, 0, 134, 334, 0, 223, 256, 256, 239, 256, 31, 256, 32, 256, 62, 418, 90, 248, 232, 130, 415, 221, 266, 204, 211, 255, 256, 0, 256, 256, 255, 256, 257, 256, 256, 255, 255, 255, 256, 84, 189, 256, 7, 393, 256, 256, 220, 255, 256, 227, 256, 255, 290, 257, 48, 255, 256, 424, 256, 257, 256, 199, 255, 256, 255, 256, 255, 256, 490, 254, 256, 256, 258, 255, 256, 255, 255, 257, 256, 256, 196, 256, 239, 257, 255, 68, 257, 257, 255, 248, 257, 255, 255, 257, 257, 196, 255, 255, 255, 241, 257, 257, 255, 256, 256, 255, 257, 256, 256, 258, 216, 258, 150, 257, 257, 256, 222, 210, 257, 256, 152, 196, 242, 256, 245, 182, 183, 220, 159, 203]
theorem node76131 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 81 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76131 support demand code
    entries76131 ((insert 21 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 39 (insert 81 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76132 : List (Fin 2295 × ℕ) := [(20, 4), (83, 47), (177, 56), (179, 29), (386, 25), (466, 51), (531, 37), (542, 14), (588, 26), (617, 85), (618, 42), (620, 51), (664, 10), (730, 10), (737, 62), (741, 7), (743, 23), (779, 1), (780, 18), (781, 30), (850, 30), (852, 61), (858, 47), (859, 30), (873, 47), (874, 48), (886, 12), (898, 12), (925, 73), (933, 42), (934, 42), (936, 11), (938, 17), (944, 65), (957, 19), (958, 89), (959, 12), (960, 36), (966, 17), (970, 16), (973, 111), (977, 47), (978, 29), (1005, 4), (1006, 10), (1012, 13), (1043, 18), (1055, 17), (1061, 50), (1073, 63), (1094, 4), (1113, 41), (1114, 44), (1123, 36), (1143, 22), (1149, 2), (1155, 3), (1167, 98), (1175, 36), (1188, 9), (1212, 47), (1223, 26), (1226, 64), (1254, 19), (1266, 30), (1275, 17), (1276, 2), (1293, 21), (1354, 14), (1398, 33), (1403, 6), (1488, 17), (1497, 7), (1502, 4), (1585, 2), (1591, 14), (1605, 11), (1618, 16), (1667, 7), (1681, 26), (1705, 27), (1842, 21), (1846, 17), (1859, 78), (2072, 12), (2292, 36)]
def cs76132 : List ℕ := [155, 40, 0, 34, 106, 78, 125, 256, 79, 16, 0, 242, 255, 136, 35, 0, 254, 255, 256, 0, 256, 0, 123, 256, 16, 12, 197, 218, 0, 151, 256, 86, 203, 255, 36, 257, 49, 255, 85, 2, 84, 256, 95, 146, 367, 227, 215, 100, 257, 256, 255, 0, 256, 256, 256, 255, 256, 190, 257, 256, 256, 257, 255, 43, 257, 255, 0, 391, 257, 257, 241, 257, 257, 228, 256, 256, 331, 255, 38, 255, 257, 346, 256, 256, 227, 194, 248, 256, 256, 255, 257, 254, 420, 254, 256, 256, 254, 254, 256, 257, 256, 255, 255, 255, 239, 254, 255, 256, 256, 47, 255, 257, 257, 255, 254, 256, 255, 256, 256, 210, 256, 256, 257, 255, 256, 228, 256, 256, 255, 256, 256, 256, 255, 258, 256, 257, 167, 255, 256, 257, 198, 167, 256, 256, 178, 251, 257, 256, 256, 211, 242, 233, 160, 180]
theorem node76132 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 21 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76132 support demand code
    entries76132 ((insert 39 (insert 21 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 81 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76129 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    39 node76131 node76132
def entries76130 : List (Fin 2295 × ℕ) := [(20, 8), (83, 6), (177, 9), (179, 30), (386, 3), (387, 3), (479, 15), (482, 26), (527, 4), (542, 5), (588, 1), (617, 22), (618, 29), (620, 11), (632, 9), (737, 20), (781, 12), (842, 4), (852, 27), (858, 13), (859, 12), (869, 7), (870, 5), (873, 31), (886, 5), (888, 16), (896, 14), (898, 3), (901, 2), (913, 2), (917, 24), (919, 3), (925, 38), (934, 21), (937, 6), (944, 19), (945, 9), (946, 11), (958, 33), (966, 16), (970, 17), (973, 45), (977, 11), (978, 8), (1012, 4), (1043, 2), (1055, 4), (1061, 21), (1073, 20), (1096, 6), (1099, 2), (1100, 21), (1110, 2), (1113, 19), (1114, 17), (1123, 23), (1143, 16), (1149, 5), (1167, 43), (1175, 8), (1177, 4), (1179, 4), (1182, 4), (1186, 6), (1212, 6), (1223, 15), (1266, 10), (1276, 5), (1279, 23), (1354, 6), (1398, 11), (1517, 10), (1585, 2), (1591, 5), (1605, 15), (1655, 4), (1859, 19), (1864, 14), (1991, 14), (2292, 27)]
def cs76130 : List ℕ := [34, 23, 0, 8, 57, 68, 56, 99, 35, 0, 0, 99, 99, 39, 19, 0, 99, 100, 99, 16, 99, 14, 43, 99, 49, 5, 81, 159, 0, 99, 99, 99, 82, 99, 8, 99, 12, 98, 39, 100, 36, 99, 20, 61, 179, 100, 130, 33, 101, 100, 99, 0, 100, 99, 99, 98, 101, 99, 99, 100, 100, 42, 93, 35, 64, 100, 24, 172, 100, 99, 68, 99, 77, 68, 99, 100, 103, 100, 20, 100, 100, 0, 100, 101, 96, 99, 99, 101, 100, 91, 99, 89, 112, 100, 100, 89, 100, 100, 98, 99, 100, 100, 101, 98, 93, 100, 100, 99, 99, 16, 100, 99, 86, 101, 99, 85, 100, 101, 101, 77, 94, 100, 99, 99, 100, 97, 100, 100, 99, 99, 99, 100, 100, 99, 94, 100, 64, 100, 100, 100, 89, 81, 100, 99, 83, 92, 100, 100, 91, 79, 82, 85, 70, 62]
theorem node76130 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 21 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76130 support demand code
    entries76130 ((insert 81 (insert 21 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76128 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    81 node76129 node76130
theorem node76107 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 67 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    21 node76127 node76128
def entries76123 : List (Fin 2295 × ℕ) := [(164, 1)]
def cs76123 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node76123 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 21 (insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76123 support demand code
    entries76123 ((insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 95 (insert 21 (insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries76125 : List (Fin 2295 × ℕ) := [(892, 1)]
def cs76125 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node76125 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 21 (insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76125 support demand code
    entries76125 ((insert 95 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 55 (insert 21 (insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries76126 : List (Fin 2295 × ℕ) := [(177, 22), (179, 82), (491, 25), (542, 44), (581, 132), (583, 78), (587, 62), (588, 43), (617, 111), (620, 9), (630, 87), (632, 13), (737, 46), (739, 10), (741, 106), (742, 11), (815, 50), (819, 5), (849, 47), (852, 91), (859, 44), (870, 22), (873, 13), (888, 8), (896, 46), (898, 1), (901, 47), (919, 46), (924, 18), (925, 34), (934, 63), (944, 111), (945, 23), (958, 7), (962, 11), (969, 18), (970, 31), (973, 129), (978, 46), (994, 29), (1006, 74), (1009, 6), (1012, 27), (1043, 5), (1075, 8), (1089, 8), (1090, 38), (1111, 6), (1114, 5), (1123, 20), (1132, 6), (1155, 1), (1175, 5), (1185, 12), (1186, 77), (1219, 120), (1223, 45), (1226, 35), (1266, 48), (1286, 5), (1364, 24), (1395, 23), (1398, 6), (1403, 42), (1435, 7), (1517, 22), (1556, 12), (1572, 22), (1618, 27), (1619, 49), (1632, 51), (1669, 27), (1705, 45), (1845, 14), (1849, 6), (1902, 24), (1998, 1), (2293, 2)]
def cs76126 : List ℕ := [45, 120, 0, 167, 136, 0, 47, 256, 89, 76, 0, 234, 256, 13, 44, 0, 165, 257, 256, 8, 256, 256, 210, 256, 76, 0, 252, 502, 0, 206, 257, 256, 255, 256, 172, 255, 44, 255, 104, 257, 63, 256, 241, 150, 463, 184, 468, 108, 240, 257, 256, 0, 256, 256, 256, 13, 256, 256, 255, 256, 241, 256, 229, 122, 222, 256, 8, 75, 256, 414, 256, 256, 257, 257, 255, 256, 171, 257, 80, 257, 255, 483, 257, 256, 255, 160, 225, 257, 256, 256, 256, 202, 506, 257, 255, 5, 256, 257, 255, 256, 257, 256, 257, 255, 157, 252, 256, 255, 256, 100, 257, 255, 257, 256, 257, 214, 256, 257, 256, 140, 256, 246, 256, 256, 257, 238, 257, 256, 139, 256, 257, 134, 257, 256, 257, 257, 161, 202, 257, 256, 189, 192, 206, 257, 220, 179, 256, 250, 257, 235, 225, 238, 230, 246]
theorem node76126 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 95 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76126 support demand code
    entries76126 ((insert 55 (insert 95 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 21 (insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76124 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 95 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 21 (insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    55 node76125 node76126
theorem node76121 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 21 (insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    95 node76123 node76124
def entries76122 : List (Fin 2295 × ℕ) := [(20, 31), (177, 7), (484, 2), (531, 5), (542, 6), (617, 26), (618, 4), (619, 7), (620, 10), (621, 14), (632, 11), (728, 12), (737, 10), (739, 7), (741, 1), (781, 9), (815, 19), (850, 13), (852, 25), (859, 11), (870, 13), (873, 2), (874, 30), (898, 24), (901, 6), (919, 17), (920, 3), (922, 13), (924, 3), (925, 16), (934, 20), (944, 54), (960, 16), (969, 8), (970, 9), (973, 57), (978, 6), (1006, 6), (1009, 12), (1012, 6), (1043, 1), (1073, 22), (1076, 2), (1100, 12), (1110, 4), (1111, 1), (1113, 5), (1114, 13), (1123, 14), (1155, 12), (1167, 24), (1175, 17), (1186, 17), (1188, 10), (1223, 14), (1226, 31), (1254, 12), (1266, 3), (1271, 13), (1276, 4), (1279, 41), (1308, 1), (1375, 8), (1397, 5), (1398, 20), (1403, 31), (1459, 1), (1585, 7), (1619, 1), (1669, 8), (1680, 12), (1705, 4), (1845, 4), (1850, 2), (1864, 16), (1902, 3), (1903, 1), (2082, 3), (2225, 4), (2247, 6), (2293, 19)]
def cs76122 : List ℕ := [20, 53, 6, 44, 51, 49, 19, 98, 68, 1, 0, 99, 99, 68, 25, 0, 75, 93, 100, 0, 98, 0, 43, 98, 48, 0, 52, 106, 0, 99, 99, 92, 53, 98, 17, 100, 23, 100, 7, 100, 20, 99, 66, 49, 187, 100, 104, 67, 80, 90, 100, 0, 67, 99, 99, 100, 88, 98, 99, 99, 100, 94, 100, 25, 84, 99, 0, 24, 100, 171, 99, 100, 100, 99, 99, 99, 129, 99, 0, 100, 99, 181, 99, 100, 99, 71, 101, 99, 99, 100, 101, 69, 192, 100, 100, 100, 99, 101, 99, 101, 100, 99, 92, 99, 86, 100, 99, 100, 99, 17, 99, 100, 99, 72, 81, 98, 100, 100, 100, 96, 100, 100, 100, 99, 99, 99, 99, 99, 89, 99, 88, 98, 99, 100, 100, 99, 75, 89, 99, 100, 71, 77, 99, 98, 71, 100, 98, 99, 82, 99, 83, 99, 81, 99]
theorem node76122 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76122 support demand code
    entries76122 ((insert 21 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76115 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    21 node76121 node76122
def entries76119 : List (Fin 2295 × ℕ) := [(20, 17), (177, 23), (179, 5), (181, 14), (409, 3), (514, 24), (583, 55), (587, 4), (588, 32), (617, 1), (618, 24), (629, 21), (737, 28), (741, 18), (742, 6), (743, 6), (785, 13), (797, 20), (815, 12), (842, 1), (849, 26), (852, 34), (870, 5), (873, 13), (888, 52), (892, 45), (898, 16), (901, 17), (919, 17), (925, 26), (933, 8), (934, 1), (944, 39), (959, 18), (960, 55), (962, 4), (966, 7), (970, 4), (973, 50), (978, 6), (981, 3), (994, 19), (1033, 8), (1043, 3), (1073, 24), (1076, 4), (1100, 6), (1113, 10), (1114, 7), (1123, 7), (1155, 18), (1167, 25), (1185, 4), (1186, 25), (1219, 11), (1223, 5), (1279, 21), (1400, 8), (1403, 1), (1433, 13), (1435, 8), (1488, 1), (1497, 6), (1517, 10), (1555, 3), (1556, 14), (1572, 18), (1585, 2), (1701, 5), (1705, 1), (1791, 12), (1809, 8), (1845, 10), (1849, 4), (1859, 28), (1902, 9), (2073, 6), (2225, 9), (2241, 6)]
def cs76119 : List ℕ := [33, 32, 0, 54, 39, 49, 38, 99, 22, 0, 24, 80, 99, 30, 0, 0, 89, 100, 99, 52, 99, 100, 94, 82, 24, 0, 66, 252, 0, 66, 99, 100, 100, 100, 37, 100, 0, 149, 28, 100, 9, 76, 99, 66, 183, 101, 171, 100, 28, 89, 100, 0, 100, 100, 100, 100, 101, 100, 100, 99, 100, 100, 99, 77, 59, 100, 52, 35, 99, 45, 100, 205, 100, 52, 100, 99, 248, 101, 10, 100, 66, 236, 100, 99, 49, 100, 99, 99, 100, 100, 101, 67, 242, 81, 100, 100, 83, 100, 101, 100, 100, 100, 99, 69, 98, 101, 101, 98, 99, 33, 100, 101, 89, 100, 87, 100, 99, 100, 100, 74, 100, 100, 100, 100, 99, 100, 100, 101, 102, 100, 101, 81, 101, 101, 100, 100, 71, 100, 101, 100, 81, 79, 102, 99, 86, 75, 87, 100, 74, 91, 87, 87, 84, 100]
theorem node76119 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 37 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76119 support demand code
    entries76119 ((insert 69 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 71 (insert 37 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries76120 : List (Fin 2295 × ℕ) := [(20, 58), (177, 12), (179, 26), (474, 39), (479, 29), (484, 45), (514, 42), (583, 92), (588, 103), (617, 102), (618, 28), (629, 66), (631, 7), (736, 29), (737, 42), (741, 40), (780, 9), (833, 3), (835, 16), (846, 6), (849, 29), (852, 90), (858, 20), (870, 52), (888, 36), (890, 64), (892, 82), (897, 14), (898, 66), (901, 69), (902, 2), (920, 2), (933, 5), (934, 58), (944, 80), (959, 28), (960, 64), (966, 1), (969, 16), (970, 25), (973, 131), (978, 36), (981, 47), (994, 49), (1012, 33), (1061, 9), (1073, 56), (1099, 10), (1100, 9), (1113, 3), (1122, 10), (1123, 26), (1154, 8), (1155, 35), (1167, 40), (1174, 9), (1175, 52), (1185, 18), (1186, 73), (1254, 6), (1266, 59), (1279, 66), (1307, 12), (1375, 26), (1396, 24), (1403, 28), (1488, 2), (1497, 15), (1502, 1), (1517, 2), (1610, 17), (1628, 31), (1704, 36), (1705, 3), (1845, 37), (1848, 5), (1859, 59), (1902, 17), (2225, 34)]
def cs76120 : List ℕ := [59, 78, 0, 138, 125, 182, 124, 256, 64, 0, 59, 255, 256, 58, 17, 0, 247, 255, 256, 36, 255, 255, 257, 248, 164, 0, 144, 613, 0, 205, 256, 257, 226, 256, 96, 257, 6, 484, 74, 255, 92, 254, 256, 171, 380, 257, 457, 256, 74, 256, 255, 0, 255, 255, 256, 256, 256, 256, 256, 257, 208, 92, 255, 110, 255, 256, 100, 62, 232, 82, 256, 92, 256, 155, 255, 256, 327, 255, 1, 256, 138, 309, 256, 256, 172, 221, 253, 255, 256, 256, 257, 256, 389, 158, 256, 255, 254, 257, 256, 257, 256, 256, 256, 101, 256, 255, 255, 228, 223, 91, 256, 256, 140, 228, 230, 256, 257, 256, 255, 248, 108, 176, 256, 256, 256, 235, 256, 256, 255, 257, 256, 248, 256, 257, 256, 255, 192, 242, 256, 256, 256, 158, 254, 256, 256, 242, 236, 244, 230, 256, 254, 256, 229, 257]
theorem node76120 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 69 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76120 support demand code
    entries76120 ((insert 71 (insert 69 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 37 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76117 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 37 (insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    71 node76119 node76120
def entries76118 : List (Fin 2295 × ℕ) := [(20, 148), (49, 73), (177, 132), (179, 375), (507, 177), (542, 98), (576, 11), (583, 642), (617, 443), (664, 26), (727, 36), (729, 214), (736, 45), (737, 180), (738, 11), (739, 74), (741, 311), (742, 100), (780, 76), (785, 56), (843, 40), (849, 35), (852, 109), (870, 98), (873, 195), (888, 88), (892, 358), (901, 11), (919, 358), (925, 126), (934, 222), (940, 53), (944, 421), (959, 95), (960, 407), (970, 241), (973, 564), (978, 38), (994, 105), (1009, 47), (1061, 23), (1073, 180), (1099, 15), (1100, 160), (1113, 4), (1114, 118), (1123, 122), (1141, 17), (1143, 121), (1155, 105), (1167, 246), (1175, 125), (1185, 44), (1186, 190), (1219, 435), (1223, 360), (1254, 97), (1293, 84), (1364, 135), (1375, 27), (1398, 107), (1403, 260), (1497, 8), (1502, 57), (1591, 17), (1660, 26), (1667, 57), (1705, 26), (1845, 33), (1991, 37), (2148, 72), (2225, 119)]
def cs76118 : List ℕ := [360, 532, 0, 618, 566, 0, 0, 1001, 678, 177, 0, 990, 1000, 343, 98, 0, 892, 1000, 915, 88, 1001, 1000, 507, 1001, 177, 0, 1000, 1543, 0, 727, 1001, 1000, 329, 1001, 595, 1000, 97, 72, 507, 999, 222, 273, 493, 408, 2438, 807, 1578, 322, 507, 998, 1000, 0, 812, 999, 1001, 1000, 1000, 1001, 444, 1001, 760, 679, 851, 740, 983, 1000, 88, 246, 1000, 358, 1000, 1000, 888, 445, 1000, 1000, 1448, 1000, 135, 1000, 781, 1742, 1000, 1001, 582, 607, 1000, 1001, 1000, 999, 1000, 625, 1672, 877, 846, 1000, 1001, 1000, 999, 999, 1001, 1000, 1001, 1000, 1000, 999, 1000, 846, 999, 234, 1001, 1000, 718, 871, 996, 999, 999, 1001, 1001, 869, 1001, 1001, 999, 999, 1001, 970, 999, 1001, 947, 1000, 731, 1000, 1001, 1001, 1000, 1000, 689, 988, 1000, 1000, 937, 915, 1000, 999, 800, 912, 993, 1000, 922, 973, 908, 1000, 754, 903]
theorem node76118 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 69 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76118 support demand code
    entries76118 ((insert 37 (insert 69 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node76116 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    37 node76117 node76118
theorem node76109 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    69 node76115 node76116
def entries76113 : List (Fin 2295 × ℕ) := [(20, 287), (177, 208), (179, 82), (469, 205), (474, 218), (484, 110), (496, 154), (512, 328), (514, 13), (530, 63), (583, 510), (585, 387), (588, 126), (617, 195), (618, 234), (632, 77), (677, 23), (729, 54), (730, 89), (737, 313), (781, 51), (797, 235), (852, 310), (858, 141), (870, 93), (873, 401), (888, 341), (896, 90), (901, 304), (919, 38), (921, 64), (924, 94), (925, 206), (934, 135), (944, 475), (945, 167), (946, 153), (969, 39), (970, 66), (972, 109), (973, 428), (977, 30), (978, 168), (994, 108), (1009, 18), (1012, 89), (1061, 2), (1073, 94), (1098, 106), (1100, 32), (1113, 70), (1114, 160), (1122, 44), (1123, 325), (1143, 135), (1149, 96), (1155, 20), (1167, 278), (1175, 214), (1186, 143), (1212, 81), (1235, 38), (1247, 59), (1257, 11), (1266, 133), (1276, 103), (1279, 350), (1293, 59), (1307, 34), (1316, 15), (1398, 144), (1497, 72), (1502, 8), (1572, 4), (1705, 81), (1846, 37), (1849, 42), (1852, 53), (1859, 135), (2023, 11), (2073, 20), (2204, 88), (2209, 14), (2225, 53)]
def cs76113 : List ℕ := [135, 555, 0, 539, 310, 629, 310, 1000, 441, 0, 341, 1001, 1001, 751, 0, 0, 1000, 1001, 1516, 341, 1001, 1001, 416, 943, 807, 0, 1000, 2747, 0, 654, 1000, 2037, 999, 1000, 214, 1000, 0, 1001, 290, 1002, 289, 1000, 614, 714, 1413, 1000, 1787, 180, 699, 884, 1000, 0, 1001, 1000, 1000, 1000, 1000, 1000, 999, 1000, 1000, 163, 957, 544, 794, 1000, 341, 509, 1000, 1000, 650, 839, 1000, 856, 1000, 1000, 1381, 1000, 0, 1001, 999, 11, 1000, 1000, 518, 954, 1001, 1000, 1001, 1000, 1001, 717, 1323, 1001, 1000, 666, 978, 1000, 1000, 1001, 1001, 1000, 1000, 640, 1000, 999, 1001, 1000, 1001, 348, 999, 1000, 838, 1000, 1000, 1001, 1000, 1001, 999, 736, 524, 1000, 1001, 1000, 1000, 1000, 1001, 1000, 1001, 1000, 922, 1000, 1000, 999, 1001, 1001, 742, 816, 1000, 1000, 1002, 722, 999, 977, 1000, 817, 856, 1000, 971, 967, 999, 1001, 781, 786]
theorem node76113 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 18 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76113 support demand code
    entries76113 ((insert 81 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 31 (insert 18 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries76114 : List (Fin 2295 × ℕ) := [(23, 6), (177, 60), (179, 55), (507, 46), (514, 45), (527, 47), (542, 78), (576, 7), (617, 50), (632, 4), (639, 32), (729, 25), (737, 60), (739, 6), (797, 41), (846, 34), (849, 89), (852, 96), (870, 46), (873, 97), (888, 64), (892, 52), (896, 67), (901, 59), (921, 19), (923, 23), (924, 22), (925, 48), (934, 63), (944, 97), (945, 14), (946, 30), (958, 8), (965, 10), (970, 18), (972, 35), (973, 129), (978, 26), (981, 26), (994, 37), (1009, 6), (1045, 10), (1073, 27), (1076, 7), (1100, 26), (1110, 20), (1111, 2), (1114, 36), (1122, 36), (1123, 24), (1141, 6), (1143, 27), (1155, 22), (1167, 59), (1175, 34), (1176, 9), (1179, 40), (1186, 42), (1212, 24), (1219, 3), (1235, 17), (1266, 62), (1293, 16), (1333, 6), (1398, 11), (1482, 19), (1497, 26), (1667, 5), (1683, 14), (1705, 21), (1845, 18), (1849, 17), (1859, 117), (1903, 4), (2021, 9), (2023, 2), (2292, 3), (2293, 52)]
def cs76114 : List ℕ := [117, 37, 0, 92, 102, 117, 117, 256, 0, 46, 45, 166, 256, 97, 78, 0, 165, 257, 392, 64, 256, 119, 115, 257, 72, 0, 257, 413, 0, 207, 257, 19, 256, 257, 160, 257, 0, 254, 115, 223, 63, 209, 142, 240, 562, 257, 306, 94, 228, 233, 256, 0, 223, 257, 257, 257, 257, 255, 256, 257, 257, 117, 256, 88, 176, 230, 113, 134, 257, 255, 165, 257, 254, 166, 258, 257, 369, 190, 10, 257, 252, 54, 256, 257, 182, 258, 257, 257, 257, 257, 256, 181, 324, 256, 258, 257, 245, 258, 258, 256, 257, 257, 258, 180, 235, 258, 258, 257, 257, 141, 257, 256, 257, 258, 243, 253, 258, 256, 258, 199, 135, 258, 256, 256, 257, 257, 256, 256, 258, 256, 245, 257, 257, 255, 257, 257, 172, 256, 257, 255, 257, 206, 256, 248, 257, 251, 227, 256, 255, 255, 256, 256, 235, 232]
theorem node76114 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 81 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76114 support demand code
    entries76114 ((insert 31 (insert 81 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 18 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76111 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    31 node76113 node76114
def entries76112 : List (Fin 2295 × ℕ) := [(20, 19), (177, 32), (179, 196), (181, 50), (342, 187), (466, 296), (479, 13), (512, 106), (583, 321), (585, 336), (587, 16), (588, 323), (617, 413), (618, 206), (620, 95), (731, 20), (737, 278), (797, 45), (798, 70), (833, 66), (843, 230), (852, 368), (857, 116), (870, 222), (873, 23), (888, 73), (890, 223), (892, 120), (919, 240), (920, 90), (924, 104), (925, 218), (934, 118), (944, 193), (945, 340), (946, 28), (965, 64), (966, 40), (969, 123), (970, 115), (973, 449), (978, 175), (981, 174), (1009, 68), (1033, 14), (1034, 40), (1061, 40), (1073, 206), (1075, 64), (1098, 44), (1099, 114), (1100, 3), (1113, 32), (1114, 174), (1123, 266), (1143, 150), (1155, 94), (1167, 309), (1175, 118), (1177, 124), (1179, 66), (1186, 24), (1212, 115), (1223, 133), (1247, 99), (1254, 190), (1257, 5), (1266, 171), (1276, 98), (1346, 20), (1488, 52), (1501, 74), (1506, 55), (1517, 159), (1655, 4), (1667, 25), (1681, 126), (1845, 76), (1846, 32), (1848, 23), (1852, 44), (1991, 7), (2220, 30)]
def cs76112 : List ℕ := [429, 190, 0, 19, 704, 0, 275, 1000, 342, 0, 106, 1000, 619, 42, 0, 0, 725, 1000, 23, 73, 1000, 1000, 691, 632, 174, 0, 699, 1712, 0, 403, 1000, 1000, 1000, 1000, 118, 1000, 190, 1000, 228, 885, 131, 440, 793, 488, 1882, 999, 1845, 589, 742, 1000, 999, 0, 1000, 1001, 1000, 1000, 999, 1001, 1000, 1000, 1001, 146, 689, 612, 999, 1000, 486, 468, 999, 1000, 710, 469, 957, 999, 1000, 1000, 1148, 1001, 104, 1000, 1000, 120, 1001, 1000, 956, 1000, 1000, 999, 998, 1000, 1001, 892, 1073, 973, 1000, 947, 917, 999, 1000, 1000, 999, 1001, 1000, 696, 1000, 938, 999, 1000, 999, 205, 1001, 1001, 1000, 998, 998, 999, 1000, 999, 999, 897, 661, 999, 999, 999, 1000, 830, 999, 1001, 998, 1000, 1000, 1000, 999, 1001, 999, 999, 691, 1000, 999, 1000, 998, 711, 1000, 1000, 999, 963, 712, 1001, 1000, 886, 1000, 980, 757, 780]
theorem node76112 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 81 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76112 support demand code
    entries76112 ((insert 18 (insert 81 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node76110 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    18 node76111 node76112
theorem node76108 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    81 node76109 node76110
theorem node76083 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    67 node76107 node76108
def entries76105 : List (Fin 2295 × ℕ) := [(46, 48), (49, 28), (179, 27), (471, 47), (474, 20), (531, 68), (588, 31), (617, 35), (630, 57), (728, 43), (731, 8), (737, 23), (740, 21), (741, 10), (742, 21), (858, 37), (873, 37), (874, 119), (888, 34), (900, 12), (901, 24), (902, 1), (918, 82), (924, 5), (925, 78), (933, 60), (934, 51), (944, 99), (958, 81), (966, 4), (970, 14), (973, 117), (978, 46), (1009, 46), (1011, 17), (1012, 13), (1043, 70), (1055, 1), (1061, 22), (1073, 31), (1093, 6), (1100, 18), (1114, 30), (1122, 67), (1123, 1), (1143, 6), (1161, 1), (1167, 93), (1175, 13), (1186, 40), (1188, 61), (1219, 4), (1226, 22), (1235, 36), (1248, 3), (1254, 98), (1260, 46), (1266, 48), (1275, 40), (1279, 38), (1297, 46), (1320, 2), (1398, 51), (1403, 11), (1517, 10), (1547, 24), (1618, 4), (1619, 48), (1625, 7), (1704, 11), (1705, 33), (1773, 18), (1859, 68), (2073, 17), (2292, 45)]
def cs76105 : List ℕ := [68, 140, 47, 24, 98, 106, 181, 255, 126, 52, 0, 238, 256, 224, 66, 0, 255, 256, 481, 34, 255, 66, 69, 245, 157, 0, 256, 252, 0, 213, 255, 255, 244, 256, 17, 256, 98, 255, 38, 256, 111, 255, 148, 139, 520, 151, 0, 119, 226, 256, 255, 0, 256, 257, 256, 256, 255, 152, 256, 256, 255, 256, 256, 21, 239, 256, 34, 389, 257, 482, 255, 255, 256, 225, 222, 256, 369, 256, 16, 257, 257, 607, 247, 256, 228, 190, 146, 256, 255, 257, 256, 215, 423, 536, 257, 256, 248, 256, 255, 256, 256, 303, 255, 257, 234, 257, 256, 256, 257, 40, 256, 256, 255, 256, 257, 257, 256, 256, 256, 178, 257, 255, 256, 231, 257, 256, 256, 256, 256, 255, 256, 223, 255, 256, 199, 249, 200, 229, 256, 256, 218, 169, 256, 227, 116, 195, 231, 250, 252, 233, 256, 217, 159, 243]
theorem node76105 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 18 (insert 93 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76105 support demand code
    entries76105 ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 18 (insert 93 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76106 : List (Fin 2295 × ℕ) := [(23, 5), (46, 52), (179, 9), (342, 17), (471, 25), (507, 2), (512, 24), (530, 5), (569, 54), (587, 4), (588, 77), (617, 28), (664, 39), (729, 84), (737, 47), (741, 1), (742, 8), (797, 53), (834, 33), (835, 24), (851, 19), (858, 25), (873, 103), (874, 12), (888, 56), (898, 46), (899, 11), (900, 30), (901, 8), (918, 78), (925, 51), (933, 86), (934, 13), (944, 41), (958, 100), (959, 5), (960, 73), (966, 2), (970, 47), (973, 121), (978, 14), (994, 33), (1006, 2), (1040, 1), (1043, 46), (1061, 45), (1073, 54), (1100, 36), (1113, 19), (1114, 30), (1122, 25), (1123, 39), (1152, 20), (1167, 99), (1175, 35), (1186, 24), (1223, 3), (1235, 18), (1254, 44), (1266, 42), (1275, 29), (1279, 100), (1297, 35), (1394, 49), (1403, 12), (1528, 37), (1541, 18), (1660, 19), (1667, 13), (1705, 13), (1773, 24), (1859, 60), (1903, 4), (2016, 42), (2073, 16), (2293, 21)]
def cs76106 : List ℕ := [63, 144, 25, 91, 71, 160, 203, 256, 89, 2, 24, 256, 256, 162, 118, 0, 256, 256, 415, 56, 256, 118, 178, 256, 176, 0, 257, 288, 0, 148, 256, 257, 257, 252, 35, 202, 63, 257, 51, 257, 99, 152, 163, 197, 398, 187, 3, 232, 72, 228, 256, 0, 256, 256, 256, 256, 256, 208, 258, 257, 151, 124, 255, 36, 256, 256, 56, 461, 241, 33, 257, 257, 184, 89, 255, 257, 356, 223, 43, 255, 189, 354, 256, 255, 182, 256, 257, 257, 256, 255, 256, 180, 282, 528, 256, 256, 256, 256, 257, 255, 256, 267, 256, 255, 256, 256, 257, 255, 255, 24, 255, 255, 253, 256, 256, 256, 256, 255, 255, 210, 209, 257, 256, 256, 255, 255, 256, 256, 257, 253, 256, 255, 257, 255, 210, 256, 239, 255, 256, 255, 257, 159, 255, 256, 109, 223, 240, 244, 238, 227, 253, 229, 145, 213]
theorem node76106 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 93 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76106 support demand code
    entries76106 ((insert 69 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 93 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76103 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 93 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 18 (insert 93 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    69 node76105 node76106
def entries76104 : List (Fin 2295 × ℕ) := [(43, 13), (46, 14), (179, 10), (466, 34), (527, 20), (588, 16), (632, 2), (664, 3), (731, 26), (737, 5), (742, 1), (743, 1), (781, 1), (797, 14), (813, 12), (835, 5), (852, 8), (858, 6), (874, 2), (888, 9), (897, 5), (898, 6), (901, 6), (915, 13), (916, 15), (918, 47), (919, 8), (922, 2), (925, 43), (933, 22), (938, 20), (944, 32), (946, 1), (958, 34), (960, 24), (966, 13), (970, 11), (973, 47), (978, 12), (1009, 12), (1012, 12), (1034, 13), (1041, 2), (1043, 20), (1061, 12), (1073, 18), (1100, 12), (1113, 8), (1114, 18), (1122, 15), (1143, 13), (1152, 3), (1155, 1), (1167, 40), (1175, 12), (1179, 7), (1186, 9), (1254, 46), (1261, 1), (1266, 11), (1275, 15), (1297, 12), (1308, 3), (1354, 11), (1398, 14), (1406, 3), (1433, 18), (1517, 15), (1528, 1), (1625, 17), (1643, 10), (1665, 6), (2292, 7), (2293, 26)]
def cs76104 : List ℕ := [34, 46, 0, 0, 54, 0, 48, 88, 46, 0, 0, 95, 100, 2, 27, 0, 80, 100, 2, 12, 101, 27, 37, 86, 0, 0, 74, 21, 0, 89, 101, 85, 77, 100, 12, 58, 46, 100, 10, 100, 22, 100, 48, 72, 205, 99, 8, 78, 83, 100, 100, 0, 100, 76, 100, 99, 101, 90, 100, 99, 99, 96, 101, 15, 100, 93, 19, 221, 99, 100, 100, 100, 99, 100, 99, 99, 76, 100, 41, 99, 100, 188, 100, 100, 100, 99, 99, 99, 100, 89, 99, 96, 110, 201, 99, 99, 94, 99, 100, 98, 99, 111, 94, 100, 100, 99, 99, 99, 99, 16, 99, 99, 99, 99, 99, 99, 99, 100, 100, 77, 101, 71, 99, 100, 99, 99, 99, 99, 89, 99, 99, 99, 99, 98, 80, 99, 86, 94, 99, 99, 85, 69, 99, 99, 43, 84, 81, 96, 86, 86, 81, 99, 63, 84]
theorem node76104 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76104 support demand code
    entries76104 ((insert 18 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 93 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76099 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 93 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    18 node76103 node76104
def entries76101 : List (Fin 2295 × ℕ) := [(23, 21), (46, 22), (177, 13), (179, 1), (342, 16), (474, 1), (482, 32), (531, 21), (569, 4), (588, 20), (617, 5), (664, 17), (729, 1), (737, 44), (741, 1), (743, 20), (781, 29), (785, 2), (817, 2), (851, 12), (858, 33), (873, 24), (874, 28), (888, 34), (895, 5), (900, 19), (901, 13), (925, 27), (934, 25), (938, 18), (944, 6), (957, 32), (960, 28), (971, 13), (973, 37), (977, 1), (978, 14), (985, 3), (1006, 18), (1009, 6), (1012, 29), (1040, 3), (1041, 20), (1055, 1), (1061, 11), (1070, 12), (1072, 4), (1073, 6), (1100, 6), (1113, 2), (1114, 11), (1119, 1), (1123, 8), (1128, 1), (1141, 1), (1149, 8), (1159, 7), (1167, 30), (1175, 24), (1182, 9), (1186, 11), (1212, 12), (1226, 9), (1247, 8), (1254, 4), (1271, 5), (1275, 5), (1279, 46), (1316, 1), (1353, 1), (1488, 12), (1617, 8), (1618, 4), (1619, 9), (1636, 10), (1681, 30), (1705, 4), (1859, 17), (1902, 5)]
def cs76101 : List ℕ := [17, 50, 0, 1, 37, 95, 72, 100, 4, 13, 0, 68, 100, 73, 22, 0, 100, 99, 207, 34, 100, 27, 34, 99, 92, 3, 100, 155, 0, 66, 100, 100, 94, 99, 24, 100, 21, 100, 14, 100, 25, 86, 42, 65, 154, 87, 0, 51, 66, 99, 100, 0, 100, 99, 99, 100, 100, 35, 101, 88, 95, 101, 71, 39, 100, 98, 34, 179, 100, 101, 99, 101, 100, 68, 86, 99, 170, 98, 28, 98, 100, 144, 50, 100, 100, 78, 100, 100, 101, 98, 99, 95, 203, 0, 82, 100, 99, 99, 100, 99, 99, 98, 100, 99, 93, 99, 99, 99, 99, 37, 99, 99, 100, 100, 98, 99, 98, 100, 94, 71, 100, 100, 100, 98, 99, 99, 100, 98, 100, 94, 98, 99, 99, 98, 67, 84, 69, 78, 99, 98, 99, 76, 98, 99, 62, 71, 99, 98, 99, 94, 85, 89, 82, 65]
theorem node76101 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76101 support demand code
    entries76101 ((insert 93 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries76102 : List (Fin 2295 × ℕ) := [(43, 1), (46, 1), (177, 7), (342, 2), (466, 12), (514, 2), (527, 7), (588, 5), (617, 4), (632, 2), (728, 3), (737, 8), (781, 3), (812, 5), (817, 1), (843, 1), (851, 6), (862, 4), (869, 2), (874, 1), (888, 4), (913, 3), (915, 4), (916, 9), (919, 8), (925, 12), (934, 6), (938, 9), (944, 8), (946, 1), (957, 1), (958, 3), (960, 7), (966, 4), (973, 11), (978, 5), (1006, 2), (1007, 4), (1012, 6), (1034, 1), (1040, 5), (1061, 3), (1072, 2), (1073, 5), (1100, 6), (1110, 1), (1113, 5), (1114, 1), (1123, 2), (1128, 2), (1143, 3), (1149, 4), (1153, 4), (1155, 5), (1167, 14), (1175, 7), (1182, 2), (1186, 3), (1212, 4), (1223, 9), (1226, 8), (1488, 2), (1517, 9), (1572, 1), (1591, 6), (1605, 2), (1640, 1), (1681, 11), (2128, 1), (2290, 1)]
def cs76102 : List ℕ := [21, 0, 0, 0, 15, 0, 11, 27, 13, 0, 2, 32, 32, 1, 2, 0, 23, 32, 1, 5, 32, 2, 12, 21, 0, 0, 17, 11, 0, 25, 32, 21, 26, 33, 7, 32, 6, 32, 7, 32, 6, 32, 17, 28, 62, 26, 9, 22, 31, 32, 32, 0, 22, 30, 33, 32, 32, 27, 32, 32, 27, 30, 25, 11, 31, 32, 9, 57, 32, 31, 32, 32, 31, 32, 32, 30, 36, 33, 19, 33, 32, 33, 22, 32, 32, 29, 31, 32, 32, 29, 32, 26, 47, 3, 21, 32, 33, 32, 32, 32, 32, 34, 24, 32, 26, 32, 31, 32, 32, 7, 32, 31, 30, 32, 32, 32, 31, 32, 31, 25, 32, 32, 32, 32, 31, 31, 31, 31, 32, 32, 32, 32, 31, 31, 32, 32, 23, 25, 32, 31, 32, 26, 32, 30, 24, 29, 32, 32, 32, 25, 19, 28, 24, 23]
theorem node76102 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 93 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76102 support demand code
    entries76102 ((insert 18 (insert 93 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
theorem node76100 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 93 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    18 node76101 node76102
theorem node76095 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    93 node76099 node76100
def entries76097 : List (Fin 2295 × ℕ) := [(43, 15), (177, 8), (179, 5), (342, 2), (466, 10), (527, 19), (588, 6), (617, 13), (729, 18), (731, 35), (737, 22), (781, 5), (797, 13), (851, 25), (857, 19), (858, 2), (861, 5), (862, 13), (873, 38), (874, 12), (888, 19), (901, 3), (902, 13), (911, 7), (912, 17), (914, 22), (916, 22), (919, 8), (925, 24), (934, 37), (935, 7), (937, 32), (938, 3), (944, 40), (946, 3), (958, 29), (970, 18), (973, 43), (977, 1), (978, 9), (1006, 8), (1007, 8), (1033, 2), (1034, 3), (1061, 24), (1070, 7), (1073, 19), (1099, 13), (1100, 10), (1111, 9), (1113, 17), (1114, 4), (1123, 15), (1143, 11), (1149, 9), (1167, 39), (1175, 17), (1179, 13), (1182, 8), (1186, 4), (1223, 2), (1266, 11), (1269, 6), (1275, 2), (1279, 51), (1293, 4), (1517, 16), (1523, 11), (1585, 4), (1591, 7), (1669, 3), (1702, 16), (1902, 6), (2073, 4), (2240, 3), (2292, 11)]
def cs76097 : List ℕ := [12, 51, 0, 0, 27, 51, 52, 88, 20, 0, 0, 79, 100, 50, 15, 16, 64, 100, 101, 19, 100, 31, 35, 79, 67, 0, 100, 88, 16, 101, 100, 101, 46, 100, 33, 78, 25, 100, 29, 101, 53, 84, 48, 79, 175, 100, 2, 47, 78, 100, 101, 0, 42, 73, 100, 242, 102, 100, 100, 100, 100, 62, 100, 9, 85, 99, 50, 204, 100, 100, 90, 101, 74, 90, 66, 99, 137, 92, 30, 100, 99, 15, 99, 100, 66, 99, 100, 100, 101, 99, 99, 88, 107, 99, 100, 100, 100, 99, 101, 98, 100, 99, 99, 78, 88, 99, 100, 98, 99, 17, 99, 98, 45, 99, 100, 89, 97, 101, 99, 79, 78, 100, 99, 98, 100, 99, 98, 99, 93, 98, 100, 99, 98, 99, 97, 58, 69, 99, 99, 99, 87, 99, 99, 99, 55, 99, 100, 95, 98, 66, 94, 80, 80, 52]
theorem node76097 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76097 support demand code
    entries76097 ((insert 81 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 55 (insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries76098 : List (Fin 2295 × ℕ) := [(46, 6), (179, 227), (490, 43), (527, 256), (530, 145), (569, 18), (617, 190), (631, 34), (632, 105), (664, 192), (731, 6), (737, 333), (781, 35), (843, 157), (851, 224), (852, 189), (858, 224), (873, 147), (888, 136), (896, 169), (900, 110), (902, 61), (916, 78), (917, 173), (924, 154), (925, 382), (934, 174), (944, 87), (945, 151), (946, 104), (957, 56), (958, 334), (966, 141), (970, 124), (971, 15), (973, 404), (977, 96), (978, 162), (1006, 64), (1009, 72), (1012, 46), (1021, 6), (1043, 29), (1068, 21), (1070, 24), (1072, 5), (1073, 264), (1095, 113), (1097, 105), (1100, 143), (1111, 4), (1113, 81), (1114, 224), (1123, 281), (1143, 146), (1149, 92), (1152, 52), (1153, 2), (1167, 362), (1174, 2), (1175, 221), (1183, 55), (1186, 97), (1223, 55), (1258, 64), (1266, 138), (1269, 153), (1275, 81), (1279, 448), (1335, 26), (1354, 83), (1384, 101), (1398, 4), (1402, 156), (1481, 52), (1502, 11), (1517, 145), (1674, 12), (1681, 77), (1728, 3), (1773, 90), (1859, 85), (1991, 74), (2292, 235)]
def cs76098 : List ℕ := [140, 448, 0, 0, 468, 689, 605, 1001, 55, 0, 0, 776, 1000, 292, 108, 0, 840, 1001, 999, 136, 1000, 277, 227, 759, 604, 0, 842, 1270, 0, 838, 1000, 1000, 1001, 1001, 223, 1000, 224, 1000, 227, 1000, 174, 921, 189, 1000, 1692, 1001, 413, 447, 901, 1000, 1001, 0, 1001, 999, 1001, 509, 1000, 1000, 1000, 1000, 1001, 564, 1000, 141, 999, 1000, 136, 1814, 1001, 1000, 856, 1001, 898, 595, 1000, 1000, 1030, 1000, 384, 1000, 1000, 0, 1000, 1001, 852, 994, 999, 1000, 999, 829, 1000, 861, 1010, 1000, 1000, 999, 999, 1000, 999, 1001, 1000, 1000, 1000, 1001, 999, 999, 1001, 1000, 1001, 112, 1001, 999, 898, 999, 999, 846, 1002, 999, 999, 896, 878, 999, 1000, 1000, 1000, 1000, 1000, 1000, 999, 1001, 1000, 1000, 1001, 1000, 1001, 1000, 748, 892, 1000, 1000, 929, 729, 1000, 1002, 897, 889, 956, 870, 997, 845, 1000, 1001, 746, 637]
theorem node76098 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 81 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76098 support demand code
    entries76098 ((insert 55 (insert 81 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node76096 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    55 node76097 node76098
theorem node76085 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    81 node76095 node76096
def entries76093 : List (Fin 2295 × ℕ) := [(86, 22), (177, 24), (179, 3), (342, 22), (512, 1), (514, 39), (531, 61), (587, 4), (617, 38), (630, 8), (632, 36), (639, 5), (728, 72), (738, 32), (739, 23), (741, 13), (850, 33), (851, 40), (860, 8), (870, 8), (873, 50), (874, 119), (888, 23), (901, 27), (919, 27), (920, 60), (922, 14), (924, 52), (925, 44), (934, 66), (944, 115), (966, 4), (970, 17), (973, 131), (978, 57), (994, 71), (1012, 22), (1040, 7), (1043, 10), (1049, 12), (1070, 12), (1073, 12), (1100, 34), (1123, 64), (1143, 9), (1155, 53), (1159, 11), (1160, 14), (1167, 53), (1175, 71), (1186, 44), (1219, 75), (1223, 7), (1226, 40), (1247, 27), (1254, 41), (1266, 69), (1276, 7), (1279, 64), (1364, 7), (1398, 30), (1403, 78), (1481, 16), (1501, 6), (1618, 23), (1619, 41), (1682, 34), (1703, 35), (1705, 2), (1753, 6), (1845, 11), (1848, 21), (1859, 21), (1902, 6), (2225, 14), (2244, 8), (2292, 28), (2294, 30)]
def cs76093 : List ℕ := [28, 188, 0, 116, 88, 85, 21, 256, 56, 64, 40, 246, 257, 230, 0, 0, 248, 256, 495, 23, 256, 0, 136, 257, 136, 0, 256, 208, 0, 214, 256, 256, 256, 255, 146, 256, 81, 256, 62, 256, 66, 257, 250, 194, 565, 219, 15, 174, 258, 256, 256, 0, 235, 256, 256, 255, 257, 224, 256, 215, 255, 257, 256, 33, 255, 256, 35, 53, 255, 508, 255, 256, 255, 258, 220, 255, 379, 236, 11, 255, 257, 421, 245, 255, 257, 178, 193, 255, 257, 256, 255, 210, 353, 258, 238, 255, 252, 256, 258, 255, 256, 312, 257, 256, 208, 256, 257, 255, 256, 44, 255, 255, 220, 255, 256, 256, 256, 255, 255, 214, 168, 256, 256, 256, 256, 255, 256, 255, 257, 255, 256, 255, 256, 255, 171, 226, 212, 215, 257, 255, 238, 220, 219, 255, 253, 216, 185, 255, 228, 208, 243, 255, 205, 255]
theorem node76093 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 18 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76093 support demand code
    entries76093 ((insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 69 (insert 81 (insert 18 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76094 : List (Fin 2295 × ℕ) := [(43, 77), (49, 22), (86, 37), (177, 8), (179, 106), (350, 3), (469, 27), (474, 29), (507, 37), (512, 50), (514, 37), (587, 70), (588, 7), (617, 59), (631, 33), (664, 6), (729, 98), (737, 42), (738, 47), (739, 9), (741, 70), (785, 7), (797, 18), (849, 15), (851, 21), (852, 40), (873, 66), (874, 63), (888, 66), (901, 46), (902, 41), (925, 28), (934, 67), (944, 111), (958, 12), (959, 31), (960, 94), (970, 31), (972, 9), (973, 137), (978, 40), (1006, 26), (1009, 43), (1061, 6), (1068, 13), (1073, 52), (1099, 20), (1100, 13), (1123, 17), (1143, 8), (1155, 25), (1167, 50), (1174, 18), (1175, 44), (1186, 65), (1212, 3), (1235, 14), (1247, 1), (1258, 24), (1266, 35), (1271, 7), (1279, 106), (1335, 19), (1375, 5), (1394, 21), (1403, 74), (1617, 7), (1683, 1), (1705, 19), (1731, 9), (1848, 9), (1849, 22), (1859, 27), (1903, 8), (2073, 42), (2135, 31), (2225, 3), (2240, 8), (2247, 37)]
def cs76094 : List ℕ := [64, 133, 37, 65, 61, 170, 104, 258, 22, 37, 87, 247, 257, 129, 77, 0, 257, 256, 450, 66, 257, 77, 222, 257, 257, 0, 256, 371, 0, 256, 257, 257, 256, 257, 77, 256, 21, 256, 145, 257, 67, 256, 256, 174, 385, 256, 40, 240, 146, 241, 255, 0, 151, 256, 256, 256, 256, 120, 245, 255, 129, 163, 252, 50, 256, 255, 66, 62, 256, 64, 255, 256, 255, 141, 240, 256, 434, 255, 0, 257, 231, 395, 237, 255, 237, 172, 255, 255, 257, 256, 256, 183, 424, 255, 255, 256, 198, 255, 257, 256, 256, 270, 255, 255, 255, 255, 256, 256, 256, 77, 256, 255, 252, 231, 210, 256, 256, 256, 256, 251, 198, 256, 256, 256, 256, 256, 256, 256, 257, 255, 227, 256, 256, 256, 240, 214, 208, 245, 257, 256, 244, 223, 256, 257, 182, 252, 256, 256, 257, 256, 257, 257, 248, 238]
theorem node76094 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 18 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76094 support demand code
    entries76094 ((insert 69 (insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 81 (insert 18 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76091 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 18 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 81 (insert 18 (insert 27 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    69 node76093 node76094
def entries76092 : List (Fin 2295 × ℕ) := [(43, 17), (86, 10), (177, 8), (179, 7), (469, 37), (474, 7), (512, 27), (514, 20), (527, 30), (569, 15), (617, 5), (639, 12), (726, 8), (728, 3), (731, 7), (737, 41), (739, 8), (785, 16), (797, 5), (849, 10), (851, 13), (852, 4), (872, 1), (873, 43), (874, 5), (888, 39), (901, 20), (902, 22), (919, 4), (923, 6), (924, 31), (925, 20), (934, 12), (944, 47), (945, 20), (946, 14), (965, 8), (969, 8), (970, 13), (973, 43), (978, 18), (994, 12), (1006, 2), (1012, 4), (1038, 5), (1061, 5), (1068, 1), (1070, 8), (1073, 14), (1076, 11), (1099, 7), (1111, 4), (1113, 6), (1114, 7), (1123, 28), (1143, 14), (1149, 16), (1155, 6), (1160, 3), (1167, 26), (1174, 4), (1175, 26), (1186, 7), (1212, 10), (1223, 2), (1235, 3), (1276, 8), (1279, 35), (1307, 7), (1381, 4), (1384, 7), (1481, 28), (1528, 4), (1667, 3), (1705, 9), (1753, 6), (1848, 9), (1859, 9), (2072, 6), (2293, 2), (2294, 7)]
def cs76092 : List ℕ := [11, 72, 0, 24, 19, 51, 33, 100, 2, 0, 47, 100, 100, 49, 17, 0, 100, 88, 169, 39, 100, 17, 22, 98, 86, 0, 100, 152, 0, 69, 100, 100, 100, 99, 40, 101, 13, 100, 15, 100, 12, 100, 74, 100, 138, 100, 6, 27, 72, 98, 100, 0, 67, 99, 100, 99, 99, 101, 100, 101, 101, 23, 100, 19, 101, 100, 40, 26, 99, 101, 100, 100, 100, 80, 80, 101, 165, 100, 8, 99, 101, 5, 96, 100, 64, 95, 100, 101, 99, 99, 100, 70, 125, 100, 99, 80, 89, 100, 100, 100, 100, 99, 100, 72, 100, 99, 101, 99, 100, 17, 100, 99, 82, 100, 100, 91, 99, 99, 99, 87, 46, 100, 101, 99, 98, 99, 100, 100, 100, 99, 98, 99, 99, 99, 100, 80, 93, 87, 99, 98, 99, 91, 99, 99, 86, 92, 94, 90, 99, 90, 99, 100, 74, 83]
theorem node76092 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76092 support demand code
    entries76092 ((insert 81 (insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 18 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76087 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    81 node76091 node76092
def entries76089 : List (Fin 2295 × ℕ) := [(43, 319), (177, 58), (342, 162), (466, 533), (514, 220), (588, 45), (617, 209), (632, 209), (639, 96), (643, 28), (644, 136), (737, 137), (739, 4), (851, 267), (857, 84), (861, 121), (862, 221), (869, 36), (870, 159), (874, 124), (888, 124), (891, 288), (919, 325), (920, 106), (922, 19), (924, 160), (925, 163), (934, 224), (940, 30), (944, 369), (945, 97), (959, 121), (960, 241), (970, 172), (973, 475), (977, 13), (978, 98), (1006, 79), (1007, 6), (1009, 155), (1033, 55), (1040, 75), (1043, 116), (1070, 57), (1076, 82), (1099, 30), (1100, 35), (1111, 37), (1113, 63), (1114, 40), (1123, 166), (1128, 50), (1143, 31), (1149, 26), (1155, 165), (1160, 92), (1167, 265), (1175, 260), (1178, 78), (1179, 137), (1186, 30), (1212, 64), (1223, 125), (1247, 110), (1266, 217), (1269, 53), (1276, 56), (1293, 133), (1295, 14), (1384, 167), (1403, 177), (1517, 38), (1547, 152), (1572, 8), (1616, 38), (1681, 125), (1845, 44), (1848, 60), (2292, 277), (2294, 1)]
def cs76089 : List ℕ := [658, 0, 0, 0, 392, 0, 441, 925, 467, 0, 220, 891, 1000, 124, 319, 0, 891, 999, 124, 124, 1000, 607, 104, 658, 0, 0, 721, 630, 0, 989, 1000, 614, 407, 999, 260, 803, 555, 999, 58, 999, 224, 999, 797, 538, 2104, 999, 125, 736, 725, 998, 999, 0, 994, 936, 1000, 1831, 878, 1000, 1000, 999, 999, 932, 999, 237, 999, 991, 681, 339, 1000, 1000, 999, 1001, 999, 1000, 1000, 1000, 1634, 999, 0, 998, 1000, 1000, 823, 1000, 1000, 1000, 1000, 999, 1001, 998, 999, 694, 1277, 999, 999, 1000, 998, 1001, 1000, 999, 1000, 999, 1000, 825, 989, 910, 1000, 999, 1000, 309, 999, 1000, 863, 921, 999, 998, 1000, 1000, 999, 749, 1000, 1000, 1000, 998, 1000, 1000, 1000, 1000, 1000, 1000, 999, 1000, 1000, 1000, 803, 920, 885, 999, 999, 1000, 1000, 946, 999, 999, 985, 964, 760, 981, 1000, 795, 999, 938, 815, 920]
theorem node76089 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76089 support demand code
    entries76089 ((insert 18 (insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 55 (insert 27 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries76090 : List (Fin 2295 × ℕ) := [(177, 16), (179, 5), (342, 35), (466, 130), (490, 14), (512, 17), (514, 21), (527, 64), (617, 32), (630, 14), (632, 36), (690, 33), (727, 4), (728, 5), (737, 22), (739, 30), (797, 32), (844, 14), (851, 64), (870, 52), (888, 21), (898, 66), (919, 71), (920, 36), (922, 43), (923, 3), (924, 30), (925, 78), (934, 53), (944, 89), (945, 11), (959, 12), (960, 64), (966, 8), (970, 11), (973, 122), (978, 67), (994, 44), (1006, 13), (1009, 23), (1012, 22), (1043, 1), (1072, 50), (1073, 62), (1098, 3), (1100, 16), (1111, 27), (1113, 27), (1128, 5), (1143, 32), (1153, 43), (1155, 92), (1167, 54), (1174, 2), (1175, 69), (1223, 31), (1226, 68), (1248, 9), (1254, 16), (1257, 11), (1266, 65), (1269, 2), (1276, 7), (1293, 20), (1297, 2), (1354, 3), (1384, 35), (1403, 49), (1517, 12), (1555, 21), (1617, 9), (1665, 11), (1667, 14), (1681, 41), (1845, 30), (1848, 32), (1903, 10), (2292, 35)]
def cs76090 : List ℕ := [175, 16, 0, 0, 111, 0, 26, 255, 47, 0, 38, 255, 255, 0, 0, 0, 215, 199, 0, 21, 255, 0, 87, 177, 0, 14, 153, 64, 0, 147, 255, 150, 154, 223, 71, 168, 80, 256, 21, 256, 53, 169, 145, 256, 409, 220, 31, 186, 211, 256, 255, 0, 182, 257, 256, 54, 256, 234, 256, 257, 256, 255, 255, 64, 256, 256, 21, 66, 256, 256, 256, 255, 257, 255, 257, 256, 359, 256, 29, 256, 256, 256, 256, 256, 255, 218, 257, 257, 256, 256, 256, 213, 376, 251, 257, 257, 257, 257, 256, 257, 256, 310, 251, 256, 257, 257, 257, 256, 257, 0, 256, 256, 257, 252, 159, 257, 257, 256, 256, 305, 256, 256, 256, 256, 258, 256, 256, 256, 257, 257, 257, 256, 256, 256, 257, 257, 205, 206, 256, 256, 256, 206, 226, 256, 258, 253, 212, 214, 223, 155, 199, 223, 185, 254]
theorem node76090 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 18 (insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76090 support demand code
    entries76090 ((insert 55 (insert 18 (insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))))) : Finset (Fin 154)) ((insert 27 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76088 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 27 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    55 node76089 node76090
theorem node76086 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 27 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    18 node76087 node76088
theorem node76084 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    67 node76085 node76086
theorem node76067 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 27 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    46 node76083 node76084
def entries76079 : List (Fin 2295 × ℕ) := [(43, 39), (46, 51), (181, 3), (466, 38), (479, 5), (484, 39), (531, 18), (542, 33), (577, 1), (588, 54), (617, 19), (630, 80), (632, 80), (690, 17), (728, 17), (737, 7), (814, 24), (815, 2), (869, 34), (870, 5), (873, 19), (874, 122), (888, 17), (916, 36), (918, 23), (919, 67), (920, 12), (924, 39), (925, 66), (934, 19), (944, 132), (958, 11), (962, 23), (965, 10), (966, 20), (973, 129), (978, 50), (1009, 39), (1012, 51), (1043, 26), (1049, 9), (1073, 29), (1100, 42), (1110, 15), (1113, 7), (1114, 10), (1123, 37), (1155, 32), (1167, 77), (1173, 11), (1175, 29), (1186, 50), (1188, 77), (1223, 74), (1226, 45), (1253, 105), (1271, 24), (1276, 26), (1278, 4), (1297, 18), (1335, 16), (1375, 1), (1398, 21), (1403, 74), (1433, 40), (1459, 37), (1572, 19), (1591, 2), (1618, 24), (1619, 34), (1623, 24), (1668, 12), (1701, 34), (1791, 35), (1845, 8), (1902, 3), (2236, 3)]
def cs76079 : List ℕ := [217, 0, 0, 0, 184, 39, 90, 222, 179, 58, 0, 256, 256, 159, 123, 0, 256, 256, 256, 17, 255, 90, 57, 255, 58, 0, 218, 0, 0, 250, 256, 219, 256, 256, 40, 255, 105, 256, 0, 256, 24, 256, 186, 132, 672, 198, 117, 114, 180, 256, 257, 0, 255, 227, 255, 257, 256, 255, 256, 255, 257, 256, 256, 63, 255, 256, 37, 256, 253, 497, 228, 529, 256, 202, 256, 255, 457, 257, 77, 256, 256, 663, 245, 256, 256, 180, 256, 256, 256, 256, 256, 230, 451, 256, 225, 257, 256, 256, 256, 256, 256, 295, 206, 256, 180, 256, 256, 256, 256, 73, 256, 255, 257, 245, 203, 256, 256, 255, 256, 187, 256, 256, 256, 256, 255, 256, 256, 255, 256, 256, 237, 235, 256, 255, 211, 256, 214, 214, 256, 255, 189, 189, 256, 256, 168, 189, 244, 256, 223, 238, 208, 255, 236, 255]
theorem node76079 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 81 (insert 69 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76079 support demand code
    entries76079 ((insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 71 (insert 81 (insert 69 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76081 : List (Fin 2295 × ℕ) := [(46, 28), (179, 27), (353, 14), (475, 7), (484, 75), (531, 72), (542, 81), (588, 24), (617, 31), (632, 30), (639, 7), (728, 8), (730, 88), (731, 46), (737, 35), (741, 4), (743, 14), (781, 57), (817, 4), (869, 75), (874, 102), (878, 1), (898, 7), (902, 1), (914, 41), (915, 8), (916, 5), (918, 82), (919, 74), (920, 9), (922, 4), (925, 31), (934, 40), (944, 111), (946, 58), (958, 36), (966, 7), (970, 50), (973, 109), (978, 64), (1009, 38), (1011, 11), (1012, 49), (1040, 8), (1043, 19), (1073, 7), (1100, 46), (1110, 9), (1114, 13), (1123, 82), (1143, 1), (1149, 26), (1167, 81), (1175, 66), (1186, 52), (1223, 51), (1241, 17), (1247, 14), (1253, 99), (1266, 26), (1272, 3), (1276, 35), (1293, 23), (1297, 24), (1353, 6), (1375, 13), (1398, 54), (1403, 19), (1481, 7), (1625, 32), (1669, 10), (1674, 9), (1683, 33), (1705, 8), (1842, 23), (1870, 2), (1903, 4), (1991, 1)]
def cs76081 : List ℕ := [150, 23, 0, 7, 150, 75, 37, 173, 150, 0, 0, 255, 255, 174, 142, 0, 248, 257, 256, 0, 255, 37, 58, 255, 0, 0, 130, 0, 0, 207, 256, 254, 137, 256, 66, 256, 99, 256, 27, 257, 40, 256, 144, 154, 619, 139, 156, 72, 252, 256, 257, 0, 256, 249, 256, 256, 257, 256, 256, 257, 256, 239, 257, 96, 250, 256, 0, 421, 225, 517, 257, 31, 256, 256, 257, 256, 233, 257, 44, 257, 256, 335, 243, 257, 255, 175, 178, 256, 256, 256, 256, 250, 249, 256, 178, 256, 257, 257, 256, 255, 257, 292, 256, 257, 177, 257, 257, 256, 256, 52, 256, 254, 256, 257, 257, 256, 256, 256, 256, 193, 181, 256, 256, 256, 256, 256, 256, 255, 222, 256, 256, 256, 256, 254, 207, 254, 220, 190, 256, 255, 222, 198, 255, 255, 215, 190, 255, 256, 256, 255, 240, 238, 196, 251]
theorem node76081 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 69 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76081 support demand code
    entries76081 ((insert 71 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 69 (insert 92 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76082 : List (Fin 2295 × ℕ) := [(43, 16), (179, 11), (342, 15), (466, 35), (484, 14), (531, 78), (542, 75), (617, 27), (630, 31), (632, 117), (693, 6), (728, 27), (729, 5), (730, 100), (731, 13), (737, 24), (739, 23), (742, 17), (743, 7), (781, 29), (850, 61), (869, 43), (870, 32), (871, 6), (874, 97), (898, 32), (919, 72), (920, 39), (922, 22), (925, 33), (934, 46), (944, 133), (945, 40), (946, 72), (970, 59), (973, 132), (978, 43), (994, 16), (1006, 2), (1009, 40), (1012, 4), (1043, 20), (1070, 26), (1073, 19), (1098, 22), (1100, 33), (1111, 15), (1114, 25), (1122, 3), (1123, 83), (1143, 19), (1149, 1), (1153, 9), (1154, 17), (1159, 4), (1167, 60), (1175, 64), (1178, 10), (1179, 5), (1186, 31), (1223, 54), (1241, 11), (1247, 18), (1248, 43), (1253, 92), (1266, 26), (1271, 26), (1276, 30), (1293, 30), (1297, 6), (1375, 4), (1398, 22), (1403, 48), (1702, 21), (2225, 19)]
def cs76082 : List ℕ := [181, 0, 0, 61, 146, 14, 16, 181, 146, 0, 0, 256, 256, 181, 91, 21, 195, 255, 256, 0, 256, 37, 64, 256, 21, 0, 125, 0, 21, 196, 256, 232, 47, 222, 85, 256, 92, 255, 32, 257, 67, 256, 148, 121, 546, 193, 129, 70, 257, 257, 255, 0, 238, 256, 256, 255, 255, 255, 257, 257, 257, 212, 256, 90, 250, 255, 21, 103, 255, 575, 257, 33, 257, 239, 256, 256, 328, 256, 0, 256, 257, 344, 257, 255, 256, 181, 129, 257, 256, 255, 256, 190, 223, 256, 195, 255, 257, 257, 256, 257, 255, 291, 256, 255, 193, 256, 254, 256, 256, 46, 256, 257, 256, 189, 255, 256, 256, 255, 258, 215, 174, 256, 256, 256, 256, 251, 257, 256, 256, 257, 220, 256, 257, 256, 236, 198, 217, 226, 257, 256, 237, 196, 254, 258, 228, 230, 187, 256, 256, 217, 256, 256, 228, 210]
theorem node76082 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 71 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76082 support demand code
    entries76082 ((insert 67 (insert 71 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76080 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    67 node76081 node76082
theorem node76075 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    71 node76079 node76080
def entries76077 : List (Fin 2295 × ℕ) := [(46, 31), (179, 30), (466, 41), (479, 56), (484, 69), (542, 13), (569, 7), (576, 42), (577, 12), (617, 62), (630, 71), (632, 73), (731, 109), (737, 8), (843, 24), (869, 69), (873, 65), (874, 27), (888, 10), (896, 38), (898, 8), (914, 26), (915, 52), (916, 22), (917, 73), (919, 17), (920, 24), (924, 39), (925, 79), (934, 54), (944, 73), (945, 32), (946, 29), (958, 59), (966, 39), (970, 30), (973, 100), (978, 46), (985, 13), (1012, 23), (1041, 9), (1043, 7), (1061, 20), (1073, 26), (1096, 7), (1099, 1), (1100, 49), (1110, 14), (1113, 20), (1114, 42), (1121, 28), (1123, 59), (1143, 40), (1149, 23), (1153, 3), (1167, 110), (1175, 46), (1178, 11), (1179, 15), (1182, 7), (1186, 46), (1223, 93), (1241, 25), (1253, 53), (1266, 19), (1275, 13), (1276, 7), (1286, 3), (1333, 2), (1354, 28), (1357, 13), (1398, 49), (1481, 10), (1488, 27), (1605, 13), (1852, 1), (2073, 19)]
def cs76077 : List ℕ := [187, 0, 0, 0, 202, 82, 31, 243, 159, 0, 0, 256, 256, 105, 44, 0, 256, 256, 168, 10, 256, 82, 38, 256, 0, 26, 190, 38, 0, 241, 256, 257, 187, 256, 59, 255, 53, 257, 30, 257, 110, 223, 73, 238, 633, 205, 256, 8, 213, 257, 256, 0, 257, 222, 256, 254, 257, 256, 256, 257, 257, 122, 211, 80, 202, 256, 36, 487, 243, 428, 165, 256, 256, 234, 256, 256, 261, 256, 123, 256, 255, 27, 256, 256, 257, 236, 255, 256, 256, 257, 256, 240, 204, 256, 208, 242, 255, 257, 256, 257, 256, 256, 256, 256, 233, 256, 257, 256, 256, 72, 256, 256, 189, 244, 255, 256, 258, 255, 255, 172, 256, 255, 255, 257, 257, 233, 255, 256, 255, 256, 256, 256, 256, 256, 214, 255, 176, 255, 256, 256, 256, 229, 256, 254, 215, 205, 255, 256, 251, 211, 241, 256, 178, 191]
theorem node76077 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 69 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76077 support demand code
    entries76077 ((insert 81 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 69 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76078 : List (Fin 2295 × ℕ) := [(43, 10), (177, 9), (179, 9), (342, 13), (479, 13), (484, 19), (507, 20), (542, 16), (617, 27), (630, 26), (632, 41), (690, 4), (731, 25), (737, 16), (797, 20), (843, 12), (850, 10), (852, 4), (869, 9), (870, 20), (873, 20), (874, 19), (919, 26), (920, 10), (921, 11), (924, 21), (925, 21), (934, 2), (944, 37), (945, 24), (946, 9), (966, 10), (969, 4), (970, 4), (973, 40), (978, 27), (1006, 1), (1009, 8), (1012, 3), (1033, 1), (1045, 5), (1073, 10), (1076, 1), (1098, 23), (1100, 2), (1111, 6), (1113, 1), (1114, 27), (1123, 32), (1143, 16), (1153, 5), (1155, 8), (1167, 25), (1175, 23), (1177, 12), (1179, 5), (1186, 8), (1223, 37), (1241, 1), (1253, 34), (1257, 10), (1266, 17), (1276, 9), (1278, 13), (1293, 5), (1370, 1), (1398, 14), (1572, 8), (1616, 6), (1655, 1), (1667, 3), (1845, 7), (1848, 1), (1852, 9), (2021, 1), (2072, 4), (2073, 4), (2292, 3)]
def cs76078 : List ℕ := [71, 0, 0, 10, 88, 19, 10, 88, 71, 20, 0, 100, 100, 39, 26, 0, 90, 101, 88, 0, 100, 10, 18, 100, 20, 0, 101, 0, 0, 98, 100, 60, 81, 100, 23, 100, 34, 99, 18, 93, 15, 99, 50, 67, 217, 100, 83, 3, 79, 89, 100, 0, 99, 100, 100, 101, 99, 99, 101, 99, 99, 48, 86, 47, 100, 101, 17, 34, 100, 147, 58, 93, 99, 99, 99, 99, 122, 100, 10, 100, 88, 19, 99, 100, 99, 92, 100, 100, 100, 101, 100, 72, 76, 89, 100, 100, 100, 99, 100, 100, 100, 100, 99, 100, 99, 101, 101, 100, 100, 13, 100, 100, 100, 100, 101, 100, 100, 99, 100, 85, 86, 94, 100, 101, 100, 75, 99, 99, 100, 99, 99, 100, 100, 100, 96, 100, 83, 91, 101, 100, 99, 68, 101, 89, 100, 90, 69, 89, 100, 78, 100, 99, 77, 73]
theorem node76078 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76078 support demand code
    entries76078 ((insert 67 (insert 81 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 69 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76076 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 69 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    67 node76077 node76078
theorem node76069 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    81 node76075 node76076
def entries76073 : List (Fin 2295 × ℕ) := [(43, 27), (177, 22), (179, 2), (342, 17), (466, 13), (484, 12), (527, 9), (542, 32), (717, 2), (727, 15), (729, 8), (779, 4), (797, 6), (798, 5), (850, 5), (861, 6), (869, 17), (871, 21), (873, 50), (874, 13), (888, 24), (911, 12), (913, 38), (915, 29), (916, 14), (917, 12), (918, 3), (919, 18), (920, 3), (925, 10), (934, 30), (936, 25), (938, 31), (944, 37), (958, 34), (961, 11), (970, 9), (973, 44), (977, 7), (978, 12), (1006, 5), (1009, 4), (1012, 1), (1033, 3), (1034, 1), (1040, 2), (1043, 6), (1055, 1), (1061, 16), (1072, 7), (1073, 8), (1093, 6), (1099, 17), (1100, 21), (1110, 2), (1111, 14), (1113, 19), (1114, 6), (1123, 12), (1149, 1), (1167, 39), (1177, 17), (1179, 17), (1186, 3), (1223, 46), (1241, 15), (1266, 2), (1275, 4), (1293, 19), (1415, 9), (1523, 13), (1585, 4), (1591, 2), (1791, 18)]
def cs76073 : List ℕ := [59, 9, 0, 5, 46, 12, 27, 68, 61, 0, 0, 85, 100, 84, 68, 0, 87, 100, 101, 24, 100, 27, 24, 100, 0, 0, 101, 0, 0, 101, 96, 83, 22, 100, 0, 101, 0, 67, 24, 100, 30, 95, 56, 69, 256, 101, 87, 100, 24, 100, 100, 0, 83, 55, 100, 310, 101, 73, 100, 100, 101, 29, 101, 51, 6, 100, 94, 255, 100, 13, 101, 101, 101, 48, 100, 100, 165, 84, 43, 101, 47, 101, 102, 101, 25, 100, 100, 100, 100, 100, 99, 99, 89, 101, 100, 101, 101, 100, 100, 99, 100, 100, 99, 101, 79, 100, 99, 99, 100, 31, 100, 99, 48, 97, 100, 93, 101, 100, 101, 76, 52, 95, 99, 101, 100, 93, 100, 101, 69, 101, 101, 100, 101, 99, 101, 72, 68, 101, 100, 99, 66, 101, 100, 100, 55, 88, 100, 100, 97, 54, 92, 86, 64, 66]
theorem node76073 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 67 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76073 support demand code
    entries76073 ((insert 69 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 55 (insert 67 (insert 92 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries76074 : List (Fin 2295 × ℕ) := [(46, 14), (179, 46), (475, 26), (479, 1), (484, 68), (507, 3), (530, 70), (542, 93), (569, 66), (576, 1), (587, 44), (588, 90), (617, 54), (629, 13), (727, 23), (741, 25), (797, 24), (843, 33), (851, 16), (869, 68), (873, 22), (888, 17), (898, 14), (915, 109), (918, 39), (919, 36), (925, 25), (933, 10), (934, 49), (944, 58), (958, 80), (959, 61), (960, 49), (970, 55), (972, 1), (973, 115), (977, 26), (978, 40), (981, 3), (1009, 6), (1012, 21), (1043, 2), (1045, 12), (1055, 19), (1061, 15), (1073, 72), (1100, 44), (1110, 22), (1113, 49), (1114, 21), (1123, 29), (1143, 11), (1149, 6), (1167, 78), (1175, 52), (1186, 61), (1223, 106), (1241, 36), (1247, 2), (1254, 6), (1266, 8), (1275, 7), (1293, 45), (1375, 6), (1398, 48), (1403, 2), (1433, 24), (1488, 50), (1579, 11), (1591, 4), (1674, 14), (1791, 4), (1842, 50), (2016, 42)]
def cs76074 : List ℕ := [106, 56, 0, 68, 129, 68, 70, 179, 154, 3, 0, 256, 256, 134, 213, 0, 256, 256, 255, 17, 256, 70, 236, 256, 6, 0, 199, 0, 0, 129, 256, 255, 256, 256, 52, 255, 22, 255, 88, 255, 60, 219, 206, 119, 470, 148, 251, 208, 88, 255, 256, 0, 256, 253, 256, 142, 256, 257, 256, 255, 255, 187, 246, 93, 141, 256, 17, 513, 195, 0, 242, 258, 254, 112, 255, 256, 277, 256, 159, 255, 129, 256, 257, 254, 179, 222, 256, 256, 256, 256, 256, 256, 325, 255, 255, 225, 256, 256, 256, 256, 256, 258, 256, 252, 256, 255, 255, 256, 257, 62, 256, 256, 172, 255, 255, 257, 256, 255, 255, 239, 187, 256, 257, 237, 255, 216, 257, 256, 256, 256, 256, 256, 257, 257, 256, 235, 175, 224, 256, 256, 244, 219, 257, 257, 176, 243, 256, 256, 257, 211, 187, 250, 176, 219]
theorem node76074 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 69 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76074 support demand code
    entries76074 ((insert 55 (insert 69 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 67 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76071 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 92 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    55 node76073 node76074
def entries76072 : List (Fin 2295 × ℕ) := [(20, 406), (43, 15), (177, 61), (179, 314), (342, 166), (479, 28), (484, 406), (507, 54), (530, 2), (542, 377), (569, 188), (577, 28), (587, 31), (588, 348), (617, 134), (639, 23), (691, 21), (727, 124), (729, 282), (737, 47), (739, 58), (741, 173), (797, 200), (843, 65), (851, 177), (870, 78), (873, 350), (888, 158), (898, 43), (919, 437), (920, 35), (922, 111), (925, 161), (934, 48), (944, 243), (959, 206), (960, 227), (969, 121), (970, 93), (973, 515), (977, 54), (978, 54), (1009, 201), (1033, 1), (1045, 119), (1073, 274), (1098, 104), (1113, 78), (1114, 110), (1123, 209), (1143, 71), (1155, 153), (1167, 229), (1174, 31), (1175, 210), (1186, 175), (1223, 274), (1241, 6), (1247, 3), (1248, 61), (1254, 103), (1261, 68), (1271, 18), (1276, 24), (1293, 62), (1297, 38), (1398, 192), (1403, 182), (1497, 14), (1585, 76), (1616, 50), (1655, 37), (1664, 4), (1668, 28), (1848, 79), (1902, 127), (2148, 172), (2225, 28), (2249, 217)]
def cs76072 : List ℕ := [491, 103, 0, 406, 799, 406, 15, 799, 1000, 54, 0, 455, 1000, 758, 392, 0, 837, 999, 1000, 158, 999, 15, 797, 999, 54, 0, 978, 0, 0, 968, 825, 906, 1000, 1000, 241, 999, 280, 1000, 375, 819, 293, 1001, 960, 678, 2234, 1000, 924, 1000, 375, 1000, 1000, 0, 715, 999, 1001, 1000, 1000, 999, 1000, 999, 999, 489, 875, 543, 774, 1000, 158, 229, 1001, 0, 948, 1000, 1000, 694, 1000, 999, 1456, 1000, 0, 1141, 698, 999, 1000, 1001, 1000, 984, 999, 1000, 999, 1000, 1000, 630, 1088, 969, 1001, 918, 1000, 999, 999, 999, 1000, 999, 881, 768, 999, 1000, 1000, 1000, 1000, 175, 1000, 999, 872, 683, 1000, 999, 1001, 1001, 999, 1030, 565, 999, 977, 1001, 1001, 1000, 999, 999, 999, 999, 1000, 999, 999, 999, 999, 1000, 756, 932, 999, 1000, 999, 817, 999, 999, 1000, 999, 696, 922, 920, 999, 875, 999, 869, 961]
theorem node76072 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 69 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 76 (insert 44 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76072 support demand code
    entries76072 ((insert 67 (insert 69 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 92 (insert 76 (insert 44 ∅))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node76070 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 76 (insert 44 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 92 (insert 76 (insert 44 ∅))) : Finset (Fin 154))
    67 node76071 node76072
theorem node76068 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 76 (insert 44 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 76 (insert 44 ∅))) : Finset (Fin 154))
    69 node76069 node76070
theorem node76049 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 76 (insert 44 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 76 (insert 44 ∅))) : Finset (Fin 154))
    27 node76067 node76068
def entries76065 : List (Fin 2295 × ℕ) := [(23, 8), (46, 26), (490, 29), (512, 20), (514, 10), (531, 9), (542, 23), (569, 21), (632, 105), (639, 23), (664, 2), (727, 51), (728, 16), (730, 133), (817, 33), (819, 8), (852, 13), (858, 92), (873, 51), (874, 96), (894, 10), (896, 97), (899, 6), (915, 35), (916, 65), (917, 19), (919, 27), (924, 72), (925, 114), (933, 42), (938, 19), (944, 63), (946, 72), (957, 27), (958, 39), (966, 15), (972, 11), (973, 118), (978, 72), (1009, 21), (1012, 53), (1025, 5), (1041, 8), (1043, 2), (1061, 4), (1069, 23), (1100, 64), (1110, 32), (1114, 35), (1123, 63), (1143, 17), (1152, 21), (1153, 3), (1167, 65), (1173, 4), (1175, 27), (1179, 16), (1182, 3), (1186, 72), (1223, 37), (1254, 127), (1276, 20), (1279, 63), (1293, 7), (1297, 2), (1335, 24), (1354, 1), (1400, 29), (1545, 11), (1622, 38), (1665, 43), (1778, 8), (1991, 25), (2073, 6), (2283, 14)]
def cs76065 : List ℕ := [37, 190, 0, 0, 185, 63, 147, 256, 164, 0, 30, 256, 256, 164, 49, 0, 257, 255, 256, 0, 401, 179, 0, 256, 63, 0, 221, 404, 0, 131, 256, 256, 237, 256, 31, 256, 127, 256, 0, 255, 42, 220, 73, 197, 748, 257, 255, 67, 205, 256, 256, 0, 255, 255, 255, 255, 256, 255, 256, 255, 256, 180, 256, 52, 245, 256, 20, 566, 255, 617, 157, 256, 256, 133, 254, 256, 270, 255, 138, 255, 256, 255, 256, 255, 255, 222, 190, 255, 256, 213, 255, 247, 0, 255, 237, 255, 255, 146, 256, 255, 255, 276, 143, 254, 120, 255, 256, 255, 255, 99, 255, 255, 247, 247, 207, 255, 255, 255, 254, 150, 136, 175, 254, 255, 255, 208, 255, 256, 206, 255, 256, 210, 256, 256, 208, 255, 222, 205, 256, 255, 199, 163, 244, 255, 221, 161, 229, 255, 219, 255, 232, 255, 256, 212]
theorem node76065 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 27 (insert 20 (insert 69 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76065 support demand code
    entries76065 ((insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 27 (insert 20 (insert 69 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76066 : List (Fin 2295 × ℕ) := [(342, 19), (490, 6), (491, 59), (514, 65), (527, 9), (542, 36), (576, 11), (581, 49), (616, 12), (630, 51), (632, 27), (639, 64), (727, 34), (728, 70), (730, 135), (797, 8), (817, 14), (833, 19), (846, 64), (851, 1), (857, 47), (858, 2), (859, 38), (873, 34), (874, 112), (892, 23), (919, 79), (920, 38), (923, 37), (924, 95), (925, 42), (933, 5), (944, 94), (946, 87), (970, 38), (973, 99), (978, 78), (981, 3), (994, 32), (1006, 4), (1009, 7), (1012, 26), (1061, 12), (1069, 4), (1100, 73), (1111, 30), (1113, 4), (1114, 10), (1123, 64), (1143, 3), (1154, 15), (1160, 12), (1167, 40), (1175, 67), (1186, 87), (1223, 105), (1241, 3), (1254, 40), (1262, 18), (1276, 24), (1279, 46), (1375, 4), (1403, 28), (1502, 2), (1517, 1), (1572, 71), (1616, 4), (1622, 13), (1701, 13), (1703, 9), (1902, 6), (2072, 12), (2073, 55), (2225, 35)]
def cs76066 : List ℕ := [105, 150, 0, 0, 146, 46, 115, 256, 201, 0, 65, 257, 256, 146, 36, 0, 256, 232, 256, 0, 436, 85, 9, 245, 49, 0, 125, 375, 0, 87, 256, 256, 181, 256, 131, 256, 79, 258, 9, 257, 23, 147, 237, 256, 674, 256, 255, 104, 231, 179, 256, 0, 257, 256, 256, 256, 257, 256, 256, 256, 256, 197, 257, 122, 171, 257, 0, 56, 257, 579, 168, 221, 257, 256, 255, 257, 323, 256, 0, 257, 256, 255, 255, 256, 257, 198, 141, 255, 255, 256, 257, 221, 0, 255, 256, 256, 255, 256, 255, 256, 256, 256, 185, 200, 144, 256, 255, 256, 256, 87, 256, 256, 220, 249, 209, 257, 256, 257, 256, 166, 224, 210, 256, 256, 257, 182, 256, 256, 227, 257, 257, 208, 257, 256, 241, 239, 241, 241, 256, 256, 256, 172, 181, 254, 247, 166, 250, 256, 211, 206, 256, 256, 231, 229]
theorem node76066 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 20 (insert 69 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76066 support demand code
    entries76066 ((insert 67 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 27 (insert 20 (insert 69 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76063 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 20 (insert 69 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 20 (insert 69 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    67 node76065 node76066
def entries76064 : List (Fin 2295 × ℕ) := [(46, 38), (342, 3), (466, 8), (479, 15), (484, 36), (531, 71), (542, 43), (576, 15), (630, 37), (632, 78), (639, 5), (690, 20), (727, 49), (730, 86), (736, 3), (780, 23), (850, 22), (869, 51), (870, 2), (873, 56), (874, 71), (916, 17), (919, 60), (920, 22), (922, 17), (924, 68), (925, 78), (944, 89), (945, 5), (946, 94), (958, 22), (966, 31), (972, 17), (973, 113), (978, 78), (981, 11), (1009, 25), (1012, 35), (1069, 20), (1070, 10), (1100, 56), (1110, 19), (1111, 11), (1114, 15), (1123, 34), (1153, 9), (1155, 1), (1159, 12), (1167, 66), (1175, 66), (1177, 11), (1179, 30), (1182, 8), (1186, 67), (1223, 100), (1235, 17), (1241, 18), (1248, 2), (1254, 91), (1297, 31), (1305, 15), (1370, 20), (1481, 26), (1572, 46), (1605, 6), (1616, 18), (1623, 54), (1887, 13), (2072, 8), (2073, 22), (2241, 1), (2293, 8)]
def cs76064 : List ℕ := [108, 91, 0, 22, 206, 36, 38, 214, 191, 0, 0, 252, 257, 198, 81, 0, 235, 257, 256, 0, 257, 38, 0, 257, 11, 0, 147, 0, 0, 187, 257, 256, 182, 257, 66, 257, 91, 207, 0, 256, 15, 256, 92, 164, 645, 244, 173, 57, 199, 219, 257, 0, 255, 257, 257, 256, 257, 256, 255, 255, 257, 171, 190, 108, 214, 257, 41, 256, 257, 482, 119, 256, 257, 184, 257, 256, 346, 256, 56, 256, 248, 256, 254, 256, 255, 223, 211, 255, 256, 257, 256, 255, 0, 255, 256, 257, 199, 256, 256, 256, 257, 282, 181, 255, 196, 256, 256, 256, 257, 114, 257, 256, 254, 256, 176, 257, 256, 256, 256, 203, 203, 202, 256, 256, 256, 204, 256, 256, 256, 256, 244, 256, 256, 255, 213, 256, 256, 239, 256, 256, 200, 213, 256, 250, 235, 233, 256, 257, 256, 226, 256, 257, 252, 248]
theorem node76064 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 69 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76064 support demand code
    entries76064 ((insert 27 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 20 (insert 69 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node76057 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 69 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 20 (insert 69 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    27 node76063 node76064
def entries76061 : List (Fin 2295 × ℕ) := [(20, 25), (181, 17), (471, 79), (479, 29), (482, 40), (484, 40), (527, 79), (632, 83), (639, 59), (727, 37), (730, 112), (780, 23), (817, 26), (833, 6), (849, 30), (850, 19), (852, 132), (859, 34), (869, 31), (870, 6), (873, 18), (892, 139), (896, 64), (901, 57), (902, 1), (917, 30), (921, 19), (924, 78), (925, 68), (933, 28), (944, 110), (945, 7), (946, 87), (958, 53), (966, 8), (973, 116), (977, 12), (978, 77), (1009, 31), (1012, 42), (1069, 16), (1099, 5), (1100, 69), (1108, 31), (1110, 17), (1111, 6), (1114, 38), (1123, 84), (1153, 5), (1155, 2), (1167, 32), (1175, 62), (1177, 7), (1186, 71), (1235, 12), (1276, 33), (1297, 22), (1447, 12), (1481, 32), (1572, 39), (1585, 6), (1984, 37), (1991, 16), (1997, 14), (2073, 14), (2219, 24), (2283, 11), (2286, 16)]
def cs76061 : List ℕ := [0, 16, 79, 88, 161, 80, 37, 256, 59, 14, 0, 104, 256, 59, 37, 0, 171, 257, 256, 0, 0, 256, 17, 124, 149, 0, 66, 429, 0, 215, 172, 256, 200, 256, 92, 256, 34, 229, 0, 257, 57, 255, 110, 253, 613, 256, 441, 68, 206, 186, 256, 0, 254, 256, 256, 256, 256, 255, 255, 255, 256, 163, 243, 22, 96, 256, 7, 258, 255, 601, 180, 244, 256, 168, 257, 255, 353, 255, 8, 256, 243, 255, 246, 256, 255, 204, 146, 255, 257, 255, 254, 247, 0, 256, 255, 256, 220, 256, 256, 255, 255, 256, 114, 256, 124, 256, 255, 255, 256, 71, 256, 256, 195, 251, 155, 254, 255, 255, 257, 185, 146, 220, 255, 255, 255, 179, 256, 256, 256, 255, 256, 217, 256, 255, 212, 255, 240, 162, 256, 255, 214, 176, 187, 256, 211, 185, 221, 256, 256, 247, 236, 256, 225, 244]
theorem node76061 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 46 (insert 69 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76061 support demand code
    entries76061 ((insert 20 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 27 (insert 46 (insert 69 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76062 : List (Fin 2295 × ℕ) := [(100, 10), (179, 21), (479, 29), (484, 12), (531, 9), (630, 40), (632, 36), (639, 6), (727, 21), (730, 32), (780, 14), (843, 10), (850, 9), (852, 25), (859, 42), (869, 32), (870, 2), (873, 33), (874, 26), (901, 5), (916, 7), (919, 22), (920, 1), (922, 2), (924, 11), (925, 30), (944, 36), (946, 35), (958, 13), (966, 14), (970, 8), (973, 40), (977, 2), (978, 34), (994, 5), (1006, 3), (1009, 11), (1012, 20), (1061, 4), (1069, 6), (1070, 3), (1100, 20), (1110, 7), (1111, 4), (1123, 24), (1148, 4), (1149, 4), (1153, 7), (1155, 1), (1160, 12), (1167, 23), (1175, 33), (1179, 8), (1186, 21), (1212, 7), (1247, 1), (1261, 1), (1276, 5), (1286, 3), (1297, 13), (1305, 11), (1403, 3), (1481, 3), (1572, 17), (1585, 4), (1623, 25), (1902, 3), (2073, 5)]
def cs76062 : List ℕ := [0, 0, 0, 9, 54, 12, 0, 54, 42, 0, 0, 34, 63, 78, 0, 0, 14, 100, 99, 0, 0, 0, 21, 34, 0, 0, 75, 0, 0, 100, 51, 99, 53, 100, 33, 99, 42, 100, 21, 95, 29, 100, 36, 75, 264, 99, 54, 21, 88, 100, 99, 0, 92, 101, 100, 99, 100, 100, 100, 99, 99, 41, 89, 19, 100, 97, 8, 100, 100, 191, 46, 99, 99, 83, 100, 100, 145, 101, 24, 100, 88, 100, 67, 100, 100, 76, 94, 100, 101, 101, 99, 100, 0, 100, 66, 100, 78, 100, 99, 99, 101, 113, 60, 99, 67, 101, 99, 100, 100, 36, 100, 99, 76, 100, 80, 101, 100, 100, 99, 73, 62, 75, 101, 100, 100, 90, 100, 100, 100, 100, 97, 100, 100, 100, 84, 100, 100, 80, 100, 99, 91, 75, 94, 100, 98, 81, 92, 100, 101, 89, 100, 101, 91, 99]
theorem node76062 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 20 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 69 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76062 support demand code
    entries76062 ((insert 27 (insert 20 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 46 (insert 69 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76059 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 69 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 20 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 69 (insert 76 (insert 44 ∅)))) : Finset (Fin 154))
    27 node76061 node76062
def entries76060 : List (Fin 2295 × ℕ) := [(43, 86), (46, 106), (471, 316), (527, 160), (531, 177), (588, 164), (616, 37), (630, 253), (632, 483), (639, 325), (643, 40), (727, 104), (730, 317), (743, 43), (850, 66), (852, 219), (859, 305), (869, 220), (870, 84), (873, 152), (874, 262), (900, 37), (901, 182), (902, 16), (917, 38), (924, 335), (925, 235), (933, 127), (944, 339), (946, 367), (958, 158), (966, 111), (970, 89), (973, 451), (977, 33), (978, 197), (1007, 16), (1009, 95), (1012, 125), (1021, 84), (1040, 52), (1041, 33), (1043, 12), (1049, 39), (1100, 175), (1110, 31), (1111, 36), (1113, 10), (1123, 146), (1153, 59), (1155, 61), (1160, 132), (1167, 242), (1173, 43), (1175, 307), (1179, 152), (1186, 237), (1212, 5), (1235, 99), (1241, 100), (1279, 26), (1297, 14), (1305, 116), (1335, 97), (1375, 16), (1403, 17), (1447, 22), (1572, 187), (1585, 77), (1623, 199), (1991, 26), (2240, 36)]
def cs76060 : List ℕ := [0, 26, 316, 66, 219, 26, 192, 561, 305, 0, 0, 330, 557, 591, 192, 0, 375, 1001, 999, 0, 26, 192, 164, 261, 342, 0, 494, 342, 0, 928, 1000, 873, 734, 1001, 350, 855, 305, 966, 0, 1000, 127, 999, 503, 1001, 1995, 999, 219, 268, 684, 1001, 1000, 0, 1000, 984, 1001, 1000, 1000, 1000, 1000, 1000, 1000, 494, 818, 232, 919, 1002, 234, 1000, 1000, 1896, 813, 999, 1001, 659, 1002, 1001, 1280, 1001, 191, 1001, 788, 1000, 1000, 999, 1000, 1002, 813, 1000, 1000, 1002, 1002, 906, 0, 1000, 999, 1000, 1001, 999, 1000, 1002, 1000, 1001, 640, 1000, 740, 1000, 999, 1003, 999, 394, 974, 1002, 790, 854, 682, 1001, 1001, 1000, 1001, 758, 617, 768, 928, 1002, 999, 915, 999, 1001, 998, 1001, 918, 1000, 1000, 1000, 885, 1000, 1000, 845, 1000, 1001, 956, 986, 992, 1000, 818, 910, 944, 971, 1000, 863, 1001, 1000, 1001, 1000]
theorem node76060 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 20 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 76 (insert 44 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76060 support demand code
    entries76060 ((insert 46 (insert 20 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 69 (insert 76 (insert 44 ∅))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node76058 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 76 (insert 44 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 20 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 69 (insert 76 (insert 44 ∅))) : Finset (Fin 154))
    46 node76059 node76060
theorem node76051 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 76 (insert 44 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 76 (insert 44 ∅))) : Finset (Fin 154))
    20 node76057 node76058
def entries76055 : List (Fin 2295 × ℕ) := [(46, 25), (179, 60), (181, 37), (342, 2), (479, 37), (507, 69), (514, 3), (527, 38), (569, 2), (631, 78), (727, 53), (729, 37), (843, 43), (852, 35), (858, 31), (873, 71), (886, 16), (894, 63), (915, 10), (917, 74), (918, 31), (919, 6), (924, 18), (925, 96), (933, 53), (938, 14), (944, 46), (957, 6), (958, 98), (959, 24), (960, 12), (966, 27), (970, 20), (973, 116), (977, 34), (978, 44), (1009, 1), (1012, 8), (1040, 1), (1061, 22), (1069, 31), (1073, 81), (1099, 27), (1100, 35), (1113, 61), (1114, 43), (1123, 35), (1143, 20), (1153, 15), (1167, 96), (1175, 44), (1179, 13), (1183, 13), (1186, 44), (1223, 80), (1241, 30), (1253, 45), (1276, 5), (1279, 17), (1354, 27), (1374, 18), (1394, 14), (1402, 28), (1403, 14), (1517, 37), (1523, 13), (1534, 9), (1541, 15), (1572, 13), (1585, 6), (1623, 14), (1628, 21), (1766, 13), (1859, 22), (1991, 19), (2001, 3), (2016, 23), (2286, 20)]
def cs76055 : List ℕ := [147, 37, 0, 37, 197, 80, 159, 256, 161, 82, 3, 256, 257, 114, 48, 0, 258, 256, 256, 0, 256, 131, 120, 214, 161, 16, 198, 256, 0, 186, 257, 257, 255, 256, 44, 254, 45, 242, 83, 257, 90, 205, 72, 247, 596, 255, 256, 218, 83, 258, 255, 13, 256, 250, 257, 255, 255, 256, 255, 256, 217, 129, 256, 30, 103, 257, 13, 553, 256, 20, 157, 457, 179, 22, 256, 255, 329, 256, 113, 256, 90, 247, 257, 256, 163, 236, 257, 255, 256, 256, 256, 254, 60, 257, 255, 257, 256, 257, 254, 255, 257, 257, 128, 256, 185, 257, 255, 251, 256, 57, 256, 256, 202, 248, 255, 257, 256, 256, 256, 244, 145, 256, 256, 249, 255, 213, 256, 257, 257, 256, 256, 256, 256, 255, 257, 255, 204, 225, 255, 255, 196, 205, 255, 255, 223, 257, 255, 256, 255, 203, 216, 227, 193, 208]
theorem node76055 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 67 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76055 support demand code
    entries76055 ((insert 69 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 71 (insert 67 (insert 76 (insert 44 ∅)))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries76056 : List (Fin 2295 × ℕ) := [(23, 2), (46, 8), (179, 15), (386, 1), (475, 14), (479, 10), (484, 2), (514, 21), (569, 11), (587, 10), (588, 37), (631, 13), (664, 7), (727, 16), (729, 23), (734, 19), (738, 5), (741, 7), (843, 4), (852, 11), (873, 20), (874, 15), (894, 43), (899, 10), (915, 15), (918, 15), (919, 13), (920, 4), (925, 21), (933, 8), (938, 6), (944, 18), (958, 19), (970, 21), (973, 47), (978, 27), (981, 6), (1009, 1), (1012, 12), (1034, 3), (1041, 11), (1061, 2), (1069, 16), (1070, 3), (1072, 6), (1073, 11), (1100, 17), (1108, 1), (1110, 7), (1113, 2), (1114, 21), (1123, 9), (1139, 3), (1153, 3), (1167, 25), (1174, 1), (1175, 27), (1179, 2), (1182, 8), (1183, 6), (1186, 22), (1223, 35), (1233, 5), (1241, 2), (1253, 17), (1261, 6), (1275, 3), (1276, 4), (1279, 25), (1293, 13), (1305, 2), (1394, 7), (1403, 9), (1517, 2), (1572, 9), (1585, 12), (1667, 2), (1703, 2), (1773, 6), (1887, 13), (2016, 32)]
def cs76056 : List ℕ := [52, 25, 0, 53, 75, 27, 48, 100, 84, 0, 21, 100, 100, 67, 46, 0, 100, 100, 96, 0, 100, 89, 96, 97, 38, 0, 37, 100, 0, 76, 101, 101, 93, 100, 28, 89, 17, 99, 49, 101, 18, 69, 92, 71, 256, 91, 99, 99, 68, 86, 100, 0, 100, 101, 99, 100, 100, 100, 99, 100, 86, 0, 76, 11, 50, 100, 2, 196, 78, 15, 90, 41, 101, 33, 100, 101, 114, 87, 82, 101, 58, 99, 100, 100, 99, 74, 92, 100, 99, 100, 101, 99, 0, 100, 100, 100, 100, 100, 100, 102, 100, 100, 73, 100, 88, 100, 101, 102, 101, 24, 100, 100, 61, 100, 100, 101, 99, 100, 100, 105, 67, 100, 100, 96, 99, 73, 100, 100, 100, 99, 100, 100, 99, 100, 100, 99, 100, 74, 98, 99, 99, 81, 100, 99, 90, 100, 99, 100, 99, 93, 85, 99, 99, 89]
theorem node76056 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 69 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 76 (insert 44 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76056 support demand code
    entries76056 ((insert 71 (insert 69 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 67 (insert 76 (insert 44 ∅))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node76053 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 76 (insert 44 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 76 (insert 44 ∅))) : Finset (Fin 154))
    71 node76055 node76056
def entries76054 : List (Fin 2295 × ℕ) := [(43, 161), (177, 67), (179, 241), (342, 90), (475, 69), (479, 165), (484, 52), (496, 67), (507, 116), (514, 354), (527, 223), (583, 317), (588, 265), (631, 175), (639, 133), (727, 293), (729, 75), (736, 15), (738, 101), (741, 123), (780, 202), (833, 27), (843, 155), (846, 157), (852, 57), (870, 218), (873, 444), (874, 75), (901, 49), (919, 242), (920, 89), (924, 92), (925, 210), (933, 84), (944, 260), (959, 138), (965, 68), (966, 69), (969, 23), (970, 199), (973, 442), (978, 183), (981, 185), (994, 72), (1009, 43), (1073, 228), (1099, 49), (1100, 55), (1111, 15), (1114, 117), (1123, 299), (1143, 1), (1155, 105), (1167, 261), (1175, 297), (1186, 123), (1212, 17), (1223, 270), (1235, 6), (1241, 82), (1247, 72), (1253, 291), (1275, 68), (1276, 136), (1297, 26), (1322, 108), (1375, 28), (1394, 28), (1403, 116), (1447, 19), (1517, 21), (1572, 160), (1610, 33), (1628, 32), (1660, 49), (1703, 145), (1704, 84), (1852, 47), (1887, 30), (1998, 18), (2225, 65), (2286, 60)]
def cs76054 : List ℕ := [561, 217, 0, 97, 783, 52, 214, 1000, 628, 116, 387, 989, 1000, 579, 194, 0, 1000, 1001, 1001, 0, 1001, 571, 802, 875, 389, 0, 851, 1002, 0, 873, 1000, 1001, 858, 1000, 454, 945, 291, 1001, 537, 1000, 316, 511, 1001, 950, 2286, 1000, 1001, 808, 537, 985, 1001, 0, 1001, 1001, 999, 1001, 1000, 1001, 1000, 999, 999, 254, 1001, 577, 722, 1001, 0, 282, 1000, 135, 1000, 1000, 1000, 655, 1000, 1000, 1272, 1001, 137, 999, 368, 1000, 1002, 1001, 1000, 836, 999, 999, 1000, 1000, 999, 892, 138, 1001, 1000, 1000, 885, 1000, 999, 999, 1000, 1001, 1001, 736, 715, 1000, 999, 971, 964, 140, 1000, 1000, 705, 962, 999, 999, 999, 1001, 999, 997, 579, 998, 949, 999, 999, 818, 1000, 999, 999, 999, 958, 1000, 999, 999, 998, 1000, 899, 817, 999, 999, 999, 681, 921, 999, 998, 997, 758, 930, 1000, 825, 999, 948, 748, 999]
theorem node76054 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 69 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 76 (insert 44 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs76054 support demand code
    entries76054 ((insert 67 (insert 69 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 76 (insert 44 ∅)) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node76052 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 76 (insert 44 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 76 (insert 44 ∅)) : Finset (Fin 154))
    67 node76053 node76054
theorem node76050 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 76 (insert 44 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 76 (insert 44 ∅)) : Finset (Fin 154))
    69 node76051 node76052
theorem node76048 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 76 (insert 44 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 34 (insert 51 (insert 36 (insert 109 (insert 66 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 76 (insert 44 ∅)) : Finset (Fin 154))
    92 node76049 node76050
#print axioms node76048
end OmissionResidualCover31Fused
