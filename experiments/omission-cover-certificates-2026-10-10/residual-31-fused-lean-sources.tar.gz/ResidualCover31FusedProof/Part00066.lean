import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries95571 : List (Fin 2295 × ℕ) := [(375, 1)]
def cs95571 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node95571 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 105 (insert 93 (insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95571 support demand code
    entries95571 ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 105 (insert 93 (insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries95573 : List (Fin 2295 × ℕ) := [(947, 1)]
def cs95573 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node95573 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 93 (insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95573 support demand code
    entries95573 ((insert 105 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 66 (insert 93 (insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries95574 : List (Fin 2295 × ℕ) := [(4, 23), (20, 11), (77, 55), (177, 108), (472, 153), (483, 13), (498, 55), (529, 48), (540, 141), (571, 12), (577, 3), (622, 4), (627, 13), (690, 57), (741, 70), (780, 49), (782, 49), (784, 15), (816, 10), (845, 103), (860, 48), (870, 62), (873, 79), (874, 93), (884, 2), (885, 58), (886, 31), (897, 17), (910, 109), (915, 58), (916, 42), (922, 24), (923, 25), (925, 5), (944, 49), (946, 73), (959, 93), (960, 38), (965, 49), (970, 74), (973, 129), (984, 86), (985, 2), (1006, 8), (1009, 42), (1011, 7), (1012, 9), (1021, 31), (1043, 41), (1045, 3), (1072, 33), (1073, 36), (1081, 1), (1082, 19), (1096, 4), (1139, 3), (1143, 10), (1153, 1), (1154, 26), (1155, 31), (1171, 45), (1175, 41), (1179, 36), (1212, 28), (1229, 1), (1241, 23), (1247, 19), (1258, 2), (1275, 11), (1276, 32), (1293, 42), (1313, 36), (1330, 3), (1332, 8), (1348, 60), (1449, 32), (1534, 16), (1559, 4), (1576, 11), (1669, 2), (2048, 10), (2116, 55), (2169, 29)]
def cs95574 : List ℕ := [36, 126, 153, 47, 59, 49, 0, 256, 173, 0, 55, 62, 255, 231, 255, 0, 257, 235, 256, 12, 255, 0, 125, 255, 166, 441, 257, 0, 256, 119, 256, 256, 30, 255, 41, 256, 367, 53, 163, 385, 257, 255, 49, 255, 511, 254, 388, 17, 256, 257, 256, 364, 0, 257, 256, 255, 256, 255, 257, 255, 306, 238, 169, 234, 129, 255, 81, 100, 256, 257, 653, 256, 257, 257, 256, 255, 548, 224, 448, 256, 257, 558, 256, 257, 75, 173, 255, 257, 607, 257, 256, 256, 257, 442, 102, 256, 256, 177, 256, 257, 256, 257, 257, 257, 246, 41, 257, 257, 258, 65, 257, 257, 257, 256, 198, 257, 256, 257, 256, 256, 258, 256, 218, 161, 257, 255, 253, 255, 257, 256, 200, 170, 256, 257, 256, 257, 256, 168, 257, 257, 257, 254, 181, 257, 252, 256, 247, 176, 256, 221, 257, 221, 255, 257]
theorem node95574 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 105 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95574 support demand code
    entries95574 ((insert 66 (insert 105 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node95572 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 105 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    66 node95573 node95574
theorem node95569 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    105 node95571 node95572
def entries95570 : List (Fin 2295 × ℕ) := [(4, 13), (20, 93), (37, 104), (77, 221), (177, 139), (472, 434), (484, 44), (498, 221), (529, 153), (540, 489), (542, 69), (576, 68), (622, 30), (623, 196), (627, 64), (692, 43), (741, 170), (780, 304), (784, 151), (785, 2), (843, 67), (845, 375), (852, 192), (859, 33), (860, 120), (870, 103), (873, 281), (874, 314), (884, 332), (885, 190), (910, 149), (916, 421), (919, 201), (920, 224), (923, 83), (925, 202), (944, 225), (946, 316), (947, 256), (948, 238), (949, 91), (950, 124), (959, 205), (960, 86), (966, 236), (970, 31), (973, 464), (984, 382), (985, 85), (1006, 30), (1009, 152), (1012, 69), (1021, 37), (1043, 24), (1049, 26), (1070, 128), (1073, 164), (1077, 119), (1081, 77), (1123, 36), (1125, 28), (1126, 145), (1142, 25), (1153, 111), (1155, 228), (1167, 2), (1170, 34), (1171, 25), (1174, 129), (1175, 256), (1176, 102), (1186, 53), (1212, 227), (1229, 28), (1313, 208), (1362, 6), (1469, 140), (1534, 142), (1633, 17), (1732, 22), (1739, 178), (2225, 86)]
def cs95570 : List ℕ := [208, 388, 434, 301, 413, 356, 0, 1001, 792, 0, 221, 103, 1001, 841, 1000, 0, 1000, 794, 1000, 104, 1001, 0, 139, 1000, 434, 1969, 748, 0, 1000, 232, 1000, 999, 329, 1002, 385, 1000, 1246, 252, 464, 1182, 1000, 1000, 225, 1001, 2325, 1000, 1653, 0, 795, 1000, 1000, 2242, 69, 1001, 1002, 1000, 1000, 1000, 1001, 1000, 1990, 999, 518, 866, 586, 1001, 1000, 423, 1000, 1000, 2961, 999, 1000, 510, 1001, 1000, 1995, 640, 2404, 1000, 1001, 2089, 999, 605, 357, 604, 1001, 999, 2196, 1000, 1000, 1000, 999, 287, 509, 1001, 1000, 634, 1000, 1000, 1000, 1000, 1000, 1000, 854, 1001, 994, 1000, 1000, 308, 1001, 999, 999, 1000, 1001, 1001, 1000, 1000, 1000, 1115, 999, 1000, 847, 1001, 1000, 744, 1000, 1000, 1000, 1000, 820, 987, 1000, 1000, 950, 1000, 1000, 722, 1000, 1000, 998, 951, 886, 1000, 1000, 884, 975, 925, 1000, 1000, 1000, 1000, 883, 1000]
theorem node95570 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95570 support demand code
    entries95570 ((insert 93 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node95551 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 88 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    93 node95569 node95570
def entries95567 : List (Fin 2295 × ℕ) := [(4, 142), (37, 39), (77, 288), (92, 155), (472, 357), (540, 453), (622, 226), (630, 327), (632, 220), (691, 369), (693, 10), (731, 80), (781, 61), (783, 62), (784, 194), (785, 93), (813, 140), (843, 84), (845, 198), (850, 387), (852, 85), (864, 21), (870, 159), (873, 205), (874, 640), (884, 294), (909, 25), (910, 44), (916, 419), (920, 249), (921, 98), (922, 234), (924, 78), (925, 320), (944, 340), (949, 361), (950, 325), (966, 296), (973, 443), (984, 459), (1009, 19), (1012, 98), (1025, 75), (1043, 122), (1073, 315), (1077, 44), (1078, 142), (1089, 14), (1123, 98), (1126, 161), (1133, 77), (1143, 126), (1153, 18), (1155, 184), (1170, 6), (1171, 268), (1175, 39), (1186, 180), (1223, 51), (1228, 65), (1232, 52), (1254, 240), (1276, 72), (1313, 56), (1469, 416), (1488, 247), (1546, 36), (1591, 23), (1605, 139), (1619, 138), (1633, 2), (1641, 182), (1657, 58), (1950, 11), (2225, 99)]
def cs95567 : List ℕ := [165, 638, 357, 443, 632, 95, 0, 1000, 597, 159, 288, 508, 1001, 1000, 997, 0, 1000, 1000, 1602, 39, 1000, 0, 0, 1000, 495, 1808, 972, 0, 999, 547, 1000, 1000, 536, 1115, 60, 1000, 1501, 990, 327, 1574, 999, 1000, 340, 1000, 2445, 999, 1706, 0, 773, 1000, 1000, 1820, 547, 1001, 999, 1288, 1000, 1000, 999, 1677, 2006, 999, 499, 1000, 1001, 1000, 999, 419, 999, 2211, 2435, 1000, 930, 962, 889, 1000, 1358, 927, 2514, 999, 999, 2764, 1000, 758, 857, 293, 1000, 999, 246, 923, 999, 1000, 1001, 1001, 643, 1000, 999, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1001, 996, 945, 998, 1000, 180, 1001, 999, 1000, 1000, 999, 1000, 1000, 1000, 1000, 1001, 999, 999, 1001, 878, 999, 736, 1000, 1000, 1000, 1000, 925, 488, 1000, 1000, 1001, 1000, 947, 594, 1001, 1001, 1000, 958, 823, 1000, 874, 820, 828, 855, 941, 891, 759, 917, 713, 996]
theorem node95567 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 18 (insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95567 support demand code
    entries95567 ((insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 59 (insert 18 (insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries95568 : List (Fin 2295 × ℕ) := [(4, 55), (77, 50), (132, 33), (221, 10), (222, 18), (472, 88), (475, 8), (507, 39), (529, 2), (531, 63), (540, 35), (542, 13), (571, 1), (630, 60), (632, 33), (674, 38), (731, 27), (741, 6), (784, 14), (785, 7), (813, 15), (845, 111), (850, 16), (864, 69), (870, 9), (873, 1), (874, 184), (884, 3), (885, 76), (908, 32), (909, 49), (919, 54), (921, 54), (924, 49), (925, 27), (944, 121), (949, 97), (950, 56), (966, 69), (973, 122), (984, 99), (1009, 35), (1011, 2), (1012, 28), (1025, 1), (1043, 3), (1073, 16), (1123, 53), (1126, 62), (1131, 3), (1133, 43), (1147, 9), (1153, 11), (1155, 44), (1157, 4), (1159, 9), (1171, 5), (1173, 65), (1175, 56), (1186, 22), (1232, 10), (1238, 36), (1254, 20), (1266, 8), (1276, 11), (1313, 64), (1333, 40), (1449, 19), (1469, 92), (1481, 50), (1488, 26), (1551, 6), (1591, 14), (1605, 27), (1633, 28), (1641, 68), (1669, 3), (1705, 8), (1903, 17), (1991, 1), (2169, 40), (2225, 35)]
def cs95568 : List ℕ := [100, 186, 124, 88, 139, 64, 0, 255, 175, 108, 50, 73, 255, 256, 217, 0, 256, 255, 452, 1, 255, 0, 0, 256, 163, 496, 254, 0, 257, 143, 255, 255, 123, 255, 190, 256, 457, 231, 50, 233, 256, 257, 121, 255, 509, 255, 401, 0, 146, 255, 255, 362, 156, 255, 256, 265, 256, 257, 255, 40, 482, 255, 256, 257, 256, 255, 255, 0, 255, 630, 398, 254, 255, 256, 165, 256, 368, 230, 473, 255, 256, 518, 238, 221, 257, 145, 255, 255, 105, 256, 255, 251, 255, 256, 226, 256, 226, 255, 255, 256, 255, 256, 256, 256, 256, 255, 253, 229, 256, 31, 256, 256, 255, 255, 254, 256, 256, 256, 257, 257, 190, 254, 247, 257, 255, 227, 256, 256, 189, 256, 231, 182, 256, 257, 256, 256, 256, 185, 256, 257, 256, 223, 195, 257, 250, 216, 217, 206, 257, 238, 256, 256, 184, 229]
theorem node95568 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95568 support demand code
    entries95568 ((insert 59 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 18 (insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node95563 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    59 node95567 node95568
def entries95565 : List (Fin 2295 × ℕ) := [(35, 44), (77, 29), (468, 4), (472, 30), (498, 4), (540, 18), (542, 18), (571, 37), (622, 5), (630, 25), (632, 6), (643, 5), (677, 26), (731, 16), (740, 9), (784, 22), (785, 2), (813, 5), (845, 13), (850, 10), (857, 5), (865, 2), (870, 33), (873, 17), (874, 10), (884, 9), (890, 1), (891, 25), (892, 75), (908, 6), (909, 36), (915, 11), (916, 33), (919, 7), (921, 22), (924, 16), (925, 8), (944, 42), (949, 25), (950, 41), (966, 29), (973, 55), (984, 30), (990, 1), (1004, 2), (1009, 12), (1021, 2), (1033, 4), (1073, 10), (1077, 12), (1108, 5), (1123, 18), (1126, 13), (1132, 15), (1133, 16), (1155, 12), (1167, 3), (1171, 20), (1173, 8), (1175, 3), (1186, 17), (1223, 15), (1237, 4), (1275, 1), (1313, 15), (1449, 10), (1469, 24), (1482, 2), (1488, 7), (1572, 2), (1591, 21), (1605, 18), (1641, 36), (1657, 21), (1669, 8), (1705, 4), (1949, 12), (2157, 1), (2169, 18), (2225, 5)]
def cs95565 : List ℕ := [51, 42, 30, 25, 67, 63, 5, 99, 100, 0, 31, 77, 99, 71, 101, 0, 83, 100, 52, 37, 100, 101, 0, 100, 34, 183, 100, 108, 100, 77, 99, 100, 25, 99, 11, 100, 178, 92, 29, 129, 100, 100, 44, 99, 277, 100, 267, 0, 58, 100, 100, 173, 51, 91, 100, 212, 100, 101, 100, 99, 206, 100, 79, 100, 100, 101, 101, 47, 100, 281, 220, 99, 100, 85, 96, 100, 151, 80, 253, 100, 100, 231, 100, 85, 66, 48, 101, 100, 39, 90, 99, 92, 100, 100, 78, 101, 95, 101, 100, 99, 99, 100, 99, 100, 85, 102, 99, 98, 99, 17, 100, 107, 100, 101, 101, 98, 100, 100, 100, 100, 63, 100, 99, 99, 100, 100, 101, 101, 68, 101, 66, 61, 101, 100, 100, 99, 88, 75, 101, 100, 100, 92, 63, 99, 83, 93, 95, 93, 101, 100, 83, 100, 72, 93]
theorem node95565 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95565 support demand code
    entries95565 ((insert 18 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 55 (insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries95566 : List (Fin 2295 × ℕ) := [(4, 8), (77, 20), (220, 16), (472, 14), (483, 8), (498, 31), (540, 39), (571, 13), (630, 13), (632, 13), (677, 3), (741, 22), (782, 8), (784, 9), (813, 9), (845, 42), (851, 25), (852, 1), (870, 8), (884, 31), (887, 27), (916, 33), (919, 18), (920, 20), (921, 5), (922, 18), (924, 14), (925, 34), (944, 35), (946, 4), (949, 28), (950, 33), (966, 16), (973, 44), (984, 40), (1009, 12), (1010, 2), (1012, 11), (1025, 4), (1043, 13), (1073, 37), (1077, 5), (1078, 10), (1081, 3), (1082, 4), (1108, 4), (1123, 1), (1126, 12), (1143, 4), (1153, 1), (1155, 27), (1167, 3), (1173, 18), (1175, 7), (1186, 15), (1188, 20), (1198, 3), (1212, 7), (1223, 3), (1248, 2), (1251, 8), (1258, 4), (1275, 8), (1403, 22), (1449, 11), (1469, 64), (1488, 19), (1546, 1), (1556, 18), (1572, 3), (1605, 2), (1641, 9), (1657, 15), (1665, 9), (1944, 1), (2169, 7), (2225, 10)]
def cs95566 : List ℕ := [21, 65, 14, 3, 55, 8, 0, 100, 60, 0, 23, 26, 99, 3, 85, 0, 71, 79, 0, 40, 99, 3, 0, 99, 22, 159, 96, 0, 100, 29, 99, 101, 48, 100, 25, 99, 136, 29, 20, 112, 99, 99, 35, 100, 172, 62, 147, 0, 90, 101, 100, 215, 26, 100, 101, 6, 100, 99, 90, 100, 223, 99, 65, 100, 100, 101, 106, 36, 99, 184, 293, 100, 100, 99, 87, 99, 111, 102, 201, 101, 99, 293, 101, 85, 99, 45, 100, 100, 31, 100, 101, 95, 100, 100, 51, 101, 100, 100, 100, 100, 101, 101, 100, 99, 100, 101, 99, 100, 100, 22, 101, 100, 100, 89, 101, 97, 100, 100, 100, 102, 99, 99, 100, 101, 99, 77, 99, 101, 97, 100, 101, 56, 100, 101, 101, 100, 98, 62, 101, 101, 100, 87, 82, 100, 76, 88, 82, 86, 89, 84, 78, 93, 80, 101]
theorem node95566 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 18 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95566 support demand code
    entries95566 ((insert 55 (insert 18 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95564 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    55 node95565 node95566
theorem node95553 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    18 node95563 node95564
def entries95561 : List (Fin 2295 × ℕ) := [(35, 301), (70, 343), (77, 57), (132, 50), (342, 131), (472, 124), (494, 60), (498, 350), (540, 526), (576, 50), (623, 423), (625, 275), (644, 318), (740, 115), (784, 139), (845, 350), (851, 449), (855, 301), (870, 289), (873, 427), (874, 273), (883, 13), (884, 349), (891, 251), (910, 117), (916, 260), (921, 78), (925, 56), (944, 347), (949, 396), (950, 362), (965, 89), (966, 215), (973, 526), (984, 339), (1009, 14), (1021, 14), (1033, 3), (1061, 86), (1069, 62), (1073, 156), (1120, 70), (1123, 191), (1126, 15), (1133, 166), (1153, 30), (1155, 77), (1160, 32), (1167, 121), (1170, 23), (1171, 58), (1173, 244), (1175, 109), (1182, 51), (1186, 90), (1247, 11), (1248, 92), (1251, 31), (1258, 73), (1261, 26), (1275, 66), (1293, 1), (1323, 12), (1403, 75), (1440, 74), (1449, 122), (1488, 83), (1549, 152), (1591, 127), (1633, 124), (1641, 57), (1666, 58), (1705, 11), (1732, 92), (2169, 269), (2206, 36)]
def cs95561 : List ℕ := [0, 350, 124, 0, 449, 602, 0, 983, 651, 0, 474, 289, 1001, 1001, 1000, 0, 610, 760, 1001, 0, 1000, 668, 0, 1000, 124, 2184, 1000, 325, 1000, 644, 1001, 999, 56, 1001, 353, 683, 1824, 375, 57, 1319, 1000, 1746, 552, 1001, 2813, 1001, 1710, 0, 92, 1000, 1001, 2578, 205, 993, 1000, 2487, 1001, 1000, 770, 999, 1994, 551, 798, 945, 1000, 1001, 1083, 445, 999, 365, 3039, 1000, 1000, 534, 643, 999, 1570, 809, 2395, 999, 1000, 1957, 1000, 840, 347, 586, 1000, 1001, 277, 1000, 999, 954, 1000, 999, 648, 1000, 1001, 1000, 1000, 998, 999, 1000, 999, 1000, 686, 1001, 516, 917, 998, 90, 1000, 1000, 1000, 989, 1000, 999, 1000, 1000, 1000, 1000, 301, 1000, 999, 906, 999, 1000, 999, 1000, 798, 1000, 772, 779, 1001, 1000, 1000, 999, 999, 794, 1000, 999, 1001, 911, 876, 999, 772, 999, 921, 786, 1000, 999, 1000, 1000, 801, 791]
theorem node95561 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 55 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95561 support demand code
    entries95561 ((insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 41 (insert 55 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries95562 : List (Fin 2295 × ℕ) := [(77, 17), (179, 1), (221, 13), (222, 6), (472, 24), (527, 1), (542, 45), (572, 24), (623, 23), (625, 14), (644, 40), (778, 32), (784, 26), (845, 5), (851, 21), (855, 44), (870, 20), (872, 42), (873, 14), (884, 25), (891, 50), (910, 27), (919, 12), (922, 2), (924, 16), (925, 21), (944, 38), (949, 33), (950, 35), (965, 2), (966, 21), (970, 7), (973, 55), (984, 23), (985, 4), (1005, 1), (1009, 3), (1010, 1), (1025, 1), (1033, 2), (1043, 9), (1073, 16), (1081, 3), (1082, 3), (1123, 6), (1126, 3), (1133, 7), (1139, 5), (1153, 9), (1155, 11), (1160, 3), (1167, 22), (1171, 13), (1173, 7), (1175, 10), (1177, 3), (1179, 7), (1186, 14), (1201, 5), (1212, 5), (1238, 15), (1251, 6), (1254, 3), (1261, 11), (1269, 3), (1293, 8), (1316, 1), (1328, 1), (1364, 2), (1449, 5), (1488, 12), (1572, 1), (1591, 3), (1632, 1), (1633, 8), (1657, 33), (1666, 6), (1705, 5), (1913, 1), (2169, 25)]
def cs95562 : List ℕ := [48, 46, 39, 0, 62, 49, 0, 101, 56, 0, 17, 71, 101, 61, 100, 0, 100, 85, 100, 24, 101, 55, 1, 101, 39, 169, 101, 50, 100, 1, 101, 99, 37, 102, 22, 100, 196, 44, 18, 99, 100, 0, 39, 101, 257, 92, 161, 0, 1, 100, 101, 140, 45, 99, 101, 222, 99, 94, 64, 100, 230, 47, 59, 99, 101, 100, 140, 22, 101, 0, 199, 101, 99, 21, 99, 99, 153, 47, 203, 100, 101, 158, 99, 98, 13, 99, 100, 100, 47, 87, 99, 88, 100, 99, 93, 99, 68, 99, 99, 100, 100, 104, 100, 99, 80, 98, 79, 100, 101, 27, 100, 100, 99, 99, 99, 99, 100, 99, 100, 99, 45, 99, 89, 99, 101, 100, 99, 100, 67, 100, 71, 91, 99, 101, 100, 101, 99, 93, 101, 101, 100, 100, 100, 100, 81, 99, 101, 100, 100, 100, 100, 100, 100, 88]
theorem node95562 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 41 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95562 support demand code
    entries95562 ((insert 41 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 55 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95555 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 55 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    41 node95561 node95562
def entries95557 : List (Fin 2295 × ℕ) := [(21, 356), (77, 262), (472, 346), (475, 36), (498, 226), (507, 581), (540, 738), (572, 20), (576, 36), (623, 152), (625, 235), (673, 173), (691, 412), (739, 7), (784, 174), (833, 17), (843, 27), (845, 190), (851, 26), (852, 403), (860, 156), (870, 221), (873, 27), (884, 553), (910, 104), (916, 539), (920, 134), (922, 317), (924, 54), (925, 329), (944, 131), (949, 430), (950, 464), (965, 114), (966, 202), (973, 445), (984, 421), (985, 108), (1009, 134), (1012, 26), (1045, 49), (1069, 78), (1071, 52), (1073, 468), (1082, 82), (1108, 29), (1126, 47), (1153, 28), (1154, 136), (1155, 99), (1170, 149), (1171, 40), (1175, 26), (1179, 52), (1186, 120), (1212, 198), (1223, 36), (1247, 2), (1258, 11), (1261, 20), (1275, 26), (1375, 40), (1403, 4), (1449, 56), (1488, 319), (1497, 56), (1499, 60), (1546, 7), (1572, 33), (1641, 68), (1666, 44), (1701, 9), (1732, 187), (1887, 9)]
def cs95557 : List ℕ := [36, 190, 346, 392, 465, 0, 0, 1001, 418, 581, 262, 293, 1000, 27, 1000, 0, 935, 767, 1000, 20, 1000, 0, 0, 1000, 927, 1723, 1000, 0, 1000, 0, 1000, 999, 1000, 1000, 26, 841, 1351, 392, 262, 1639, 1000, 1000, 131, 1000, 1807, 817, 2348, 0, 187, 1001, 1000, 2277, 0, 1000, 1000, 79, 1000, 1000, 795, 2080, 2135, 1000, 356, 1000, 662, 1000, 1135, 539, 999, 187, 2876, 1000, 1000, 422, 1000, 1000, 634, 837, 2999, 999, 999, 1540, 1000, 606, 187, 627, 901, 1000, 190, 1000, 999, 1000, 1000, 1000, 463, 861, 1000, 999, 1000, 1001, 999, 1000, 1000, 1000, 999, 999, 729, 1000, 875, 370, 1000, 1000, 1000, 862, 999, 1000, 999, 1000, 1000, 1000, 295, 999, 696, 938, 999, 824, 999, 1000, 874, 998, 971, 676, 998, 1000, 999, 1000, 674, 695, 999, 1000, 999, 898, 832, 999, 937, 1000, 805, 990, 999, 889, 721, 815, 999, 888]
theorem node95557 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95557 support demand code
    entries95557 ((insert 55 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 59 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries95559 : List (Fin 2295 × ℕ) := [(21, 75), (77, 209), (86, 86), (132, 181), (221, 118), (273, 119), (472, 301), (475, 3), (498, 183), (507, 423), (529, 378), (540, 231), (542, 207), (572, 30), (623, 340), (625, 116), (741, 277), (781, 80), (782, 48), (783, 145), (797, 242), (813, 222), (845, 509), (851, 138), (855, 63), (859, 56), (870, 242), (884, 197), (910, 185), (915, 18), (919, 237), (921, 1), (924, 120), (925, 146), (944, 294), (949, 302), (950, 578), (962, 55), (965, 164), (966, 91), (973, 453), (984, 305), (1009, 148), (1010, 11), (1012, 53), (1073, 253), (1077, 224), (1081, 17), (1128, 49), (1153, 170), (1154, 160), (1155, 220), (1159, 57), (1167, 29), (1171, 157), (1175, 294), (1212, 71), (1228, 53), (1254, 52), (1258, 46), (1269, 42), (1275, 110), (1313, 59), (1403, 15), (1449, 251), (1488, 39), (1516, 88), (1543, 124), (1641, 179), (1791, 1), (1845, 37), (1846, 1), (1848, 90), (2169, 280), (2206, 32)]
def cs95559 : List ℕ := [59, 561, 301, 137, 249, 122, 0, 1000, 350, 423, 209, 383, 1000, 378, 706, 0, 731, 1000, 1001, 30, 999, 0, 0, 999, 724, 1680, 1000, 0, 1000, 0, 1000, 1000, 811, 1000, 294, 591, 1517, 200, 209, 778, 1000, 1000, 294, 1000, 1264, 635, 1408, 0, 0, 1000, 1000, 2654, 293, 999, 1000, 151, 1001, 999, 423, 280, 2581, 1000, 793, 1000, 1000, 1000, 1037, 47, 1000, 0, 2947, 1000, 1001, 267, 851, 1001, 753, 868, 2323, 999, 1000, 1232, 999, 692, 0, 546, 1001, 1000, 479, 999, 1000, 853, 2031, 1000, 414, 799, 915, 1000, 1000, 1000, 999, 999, 1000, 1000, 1001, 952, 919, 999, 999, 126, 999, 999, 1000, 999, 999, 999, 1000, 1000, 999, 1011, 278, 999, 1000, 998, 1000, 999, 999, 1000, 936, 1000, 1000, 999, 999, 999, 1000, 999, 904, 744, 999, 999, 999, 756, 738, 999, 961, 1000, 814, 606, 999, 730, 856, 929, 999, 907]
theorem node95559 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 55 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95559 support demand code
    entries95559 ((insert 59 (insert 55 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries95560 : List (Fin 2295 × ℕ) := [(4, 4), (37, 3), (77, 18), (132, 2), (273, 2), (468, 5), (472, 35), (498, 23), (507, 44), (529, 45), (540, 30), (542, 2), (625, 13), (675, 13), (778, 23), (797, 3), (845, 39), (868, 2), (870, 24), (884, 11), (910, 20), (919, 25), (921, 8), (922, 12), (924, 32), (925, 16), (944, 35), (949, 52), (965, 15), (973, 42), (984, 37), (1009, 21), (1011, 3), (1012, 17), (1021, 8), (1043, 7), (1072, 13), (1073, 5), (1076, 7), (1082, 8), (1095, 2), (1100, 3), (1126, 2), (1128, 1), (1139, 9), (1143, 6), (1153, 2), (1154, 6), (1155, 22), (1160, 4), (1170, 9), (1171, 16), (1173, 5), (1175, 30), (1179, 16), (1186, 1), (1212, 20), (1238, 1), (1241, 1), (1254, 21), (1305, 1), (1313, 11), (1328, 4), (1403, 14), (1447, 12), (1469, 49), (1660, 2), (1667, 4), (1887, 6), (1902, 6), (2169, 10), (2225, 3)]
def cs95560 : List ℕ := [12, 69, 36, 11, 36, 14, 0, 101, 63, 44, 20, 51, 100, 45, 65, 0, 75, 78, 100, 3, 100, 0, 0, 99, 80, 152, 101, 0, 100, 0, 101, 101, 94, 100, 35, 68, 154, 11, 21, 79, 100, 100, 35, 101, 132, 100, 127, 2, 49, 101, 99, 216, 2, 101, 101, 27, 100, 100, 93, 22, 182, 95, 76, 99, 101, 100, 101, 0, 99, 49, 212, 100, 101, 64, 96, 102, 70, 66, 158, 100, 95, 175, 57, 63, 49, 77, 92, 103, 50, 100, 101, 100, 0, 95, 71, 83, 82, 101, 100, 101, 99, 100, 100, 101, 100, 100, 79, 101, 99, 37, 99, 101, 5, 102, 99, 100, 100, 99, 101, 99, 53, 78, 100, 95, 99, 101, 100, 99, 66, 100, 99, 81, 99, 99, 99, 100, 100, 72, 99, 92, 99, 100, 82, 99, 95, 99, 99, 78, 99, 95, 91, 99, 99, 90]
theorem node95560 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 59 (insert 55 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95560 support demand code
    entries95560 ((insert 92 (insert 59 (insert 55 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95558 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 55 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 59 (insert 55 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    92 node95559 node95560
theorem node95556 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    59 node95557 node95558
theorem node95554 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    55 node95555 node95556
theorem node95552 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    69 node95553 node95554
theorem node95529 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 46 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    88 node95551 node95552
def entries95547 : List (Fin 2295 × ℕ) := [(375, 1)]
def cs95547 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node95547 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 105 (insert 93 (insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95547 support demand code
    entries95547 ((insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 105 (insert 93 (insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries95549 : List (Fin 2295 × ℕ) := [(947, 1)]
def cs95549 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node95549 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 93 (insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95549 support demand code
    entries95549 ((insert 105 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 66 (insert 93 (insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries95550 : List (Fin 2295 × ℕ) := [(4, 1), (77, 17), (137, 2), (177, 11), (472, 17), (498, 12), (529, 5), (569, 1), (572, 5), (627, 9), (630, 10), (690, 5), (741, 5), (780, 11), (782, 4), (833, 2), (845, 12), (851, 1), (870, 6), (873, 9), (874, 8), (885, 9), (886, 5), (910, 6), (915, 5), (916, 5), (920, 2), (922, 8), (923, 2), (926, 2), (931, 4), (944, 2), (945, 2), (946, 11), (948, 4), (959, 15), (965, 9), (970, 10), (973, 13), (984, 10), (1006, 5), (1009, 9), (1012, 3), (1043, 7), (1045, 4), (1073, 12), (1081, 2), (1082, 1), (1153, 3), (1155, 11), (1171, 5), (1174, 2), (1175, 4), (1179, 1), (1199, 5), (1247, 1), (1269, 6), (1275, 4), (1293, 2), (1297, 1), (1305, 1), (1313, 8), (1328, 1), (1370, 2), (1449, 5), (1534, 3), (1546, 1), (1605, 1), (1902, 3), (2116, 4), (2169, 3)]
def cs95550 : List ℕ := [8, 18, 17, 8, 15, 13, 5, 30, 26, 0, 17, 6, 32, 27, 31, 0, 33, 32, 31, 5, 12, 5, 11, 28, 17, 74, 32, 0, 32, 26, 32, 32, 4, 32, 6, 31, 33, 18, 28, 48, 28, 32, 2, 32, 60, 32, 6, 0, 25, 32, 32, 31, 10, 32, 31, 31, 32, 28, 32, 32, 43, 24, 17, 32, 19, 32, 10, 10, 32, 32, 68, 31, 28, 32, 32, 32, 67, 20, 71, 32, 25, 67, 32, 32, 1, 25, 31, 32, 83, 32, 32, 32, 32, 64, 9, 31, 32, 26, 32, 32, 31, 32, 32, 31, 31, 10, 29, 32, 31, 3, 32, 32, 31, 31, 25, 31, 32, 32, 31, 31, 31, 31, 29, 15, 31, 32, 31, 31, 31, 31, 31, 19, 31, 32, 31, 31, 31, 18, 31, 32, 32, 23, 20, 31, 30, 30, 29, 15, 27, 25, 28, 21, 26, 29]
theorem node95550 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 105 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95550 support demand code
    entries95550 ((insert 66 (insert 105 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
theorem node95548 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 105 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    66 node95549 node95550
theorem node95545 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    105 node95547 node95548
def entries95546 : List (Fin 2295 × ℕ) := [(35, 1), (37, 9), (77, 55), (472, 61), (498, 35), (529, 22), (569, 7), (571, 13), (627, 36), (632, 23), (639, 2), (741, 12), (780, 28), (784, 12), (817, 7), (842, 5), (843, 17), (845, 35), (870, 20), (872, 1), (873, 22), (874, 22), (884, 19), (885, 14), (886, 2), (916, 37), (919, 10), (920, 27), (923, 6), (925, 22), (944, 19), (946, 41), (947, 17), (948, 49), (957, 1), (959, 42), (960, 2), (966, 19), (970, 13), (973, 49), (984, 38), (985, 4), (1006, 1), (1009, 12), (1012, 8), (1070, 11), (1073, 14), (1076, 3), (1077, 16), (1078, 3), (1125, 1), (1126, 16), (1139, 1), (1143, 4), (1153, 1), (1155, 26), (1162, 1), (1170, 8), (1171, 8), (1174, 19), (1175, 24), (1179, 9), (1199, 19), (1212, 22), (1254, 4), (1258, 2), (1269, 1), (1305, 2), (1313, 26), (1362, 2), (1534, 5), (1584, 2), (1585, 4), (1669, 2), (1902, 3), (2048, 3), (2225, 10)]
def cs95546 : List ℕ := [26, 58, 61, 26, 49, 55, 19, 100, 94, 0, 55, 24, 100, 87, 100, 0, 100, 100, 100, 22, 39, 19, 0, 84, 61, 238, 100, 0, 91, 43, 100, 100, 28, 100, 43, 100, 101, 49, 64, 112, 74, 100, 19, 100, 182, 100, 0, 0, 41, 100, 100, 145, 24, 100, 99, 100, 99, 88, 99, 70, 173, 62, 54, 74, 67, 100, 101, 38, 100, 99, 257, 99, 85, 13, 72, 99, 203, 65, 267, 100, 41, 155, 100, 97, 23, 57, 99, 99, 254, 101, 100, 100, 100, 30, 42, 99, 100, 85, 99, 101, 100, 101, 92, 99, 88, 100, 92, 101, 101, 31, 101, 100, 99, 100, 100, 101, 100, 100, 100, 109, 83, 100, 84, 101, 100, 78, 101, 100, 99, 101, 98, 100, 100, 101, 94, 101, 100, 93, 102, 101, 101, 100, 97, 102, 101, 100, 101, 97, 101, 101, 101, 101, 88, 99]
theorem node95546 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95546 support demand code
    entries95546 ((insert 93 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95531 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 88 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    93 node95545 node95546
def entries95543 : List (Fin 2295 × ℕ) := [(70, 44), (77, 28), (132, 38), (236, 5), (468, 8), (472, 15), (571, 33), (630, 33), (632, 18), (643, 12), (677, 7), (731, 49), (740, 5), (741, 5), (779, 19), (783, 23), (784, 8), (806, 3), (813, 7), (845, 30), (855, 8), (865, 9), (870, 28), (873, 5), (874, 67), (891, 28), (915, 26), (916, 50), (920, 16), (922, 31), (925, 19), (944, 33), (949, 43), (950, 28), (966, 31), (973, 48), (984, 46), (990, 1), (1004, 3), (1006, 6), (1008, 2), (1009, 4), (1025, 9), (1073, 11), (1077, 8), (1121, 2), (1123, 29), (1126, 15), (1133, 6), (1153, 7), (1155, 16), (1157, 5), (1170, 4), (1173, 25), (1175, 12), (1186, 18), (1213, 12), (1232, 5), (1241, 2), (1254, 34), (1275, 10), (1313, 1), (1344, 8), (1488, 1), (1511, 19), (1549, 5), (1556, 15), (1591, 28), (1605, 18), (1848, 1), (2169, 4), (2225, 1)]
def cs95543 : List ℕ := [1, 91, 27, 20, 66, 28, 19, 99, 54, 0, 100, 89, 100, 84, 92, 0, 95, 78, 100, 33, 100, 84, 0, 100, 34, 239, 99, 56, 28, 100, 100, 170, 20, 100, 49, 100, 89, 100, 28, 186, 86, 100, 36, 86, 328, 100, 0, 0, 67, 99, 100, 146, 51, 89, 96, 203, 99, 63, 100, 101, 191, 100, 64, 100, 98, 100, 100, 76, 100, 230, 221, 100, 96, 100, 60, 99, 140, 64, 284, 102, 67, 236, 101, 72, 85, 39, 100, 98, 12, 94, 101, 100, 100, 101, 57, 99, 99, 99, 100, 100, 100, 100, 81, 99, 57, 77, 91, 92, 100, 18, 101, 98, 100, 97, 99, 100, 100, 101, 99, 99, 82, 99, 98, 99, 100, 87, 99, 99, 99, 99, 65, 69, 99, 100, 98, 100, 99, 61, 98, 100, 98, 80, 61, 100, 100, 99, 85, 85, 98, 96, 96, 99, 73, 99]
theorem node95543 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 55 (insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95543 support demand code
    entries95543 ((insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 55 (insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries95544 : List (Fin 2295 × ℕ) := [(28, 2), (35, 12), (70, 59), (77, 29), (132, 34), (137, 4), (409, 8), (468, 8), (472, 28), (498, 22), (572, 6), (644, 33), (740, 31), (778, 2), (781, 15), (783, 8), (784, 30), (845, 30), (851, 11), (855, 7), (870, 41), (872, 58), (873, 21), (874, 2), (888, 11), (891, 41), (915, 30), (916, 35), (921, 9), (925, 4), (944, 37), (949, 52), (950, 26), (960, 12), (965, 5), (966, 28), (973, 49), (984, 40), (1004, 1), (1043, 11), (1073, 14), (1081, 22), (1121, 4), (1123, 10), (1126, 4), (1133, 5), (1139, 3), (1153, 18), (1155, 25), (1162, 4), (1167, 11), (1170, 15), (1173, 15), (1175, 25), (1212, 1), (1241, 7), (1251, 7), (1254, 21), (1261, 4), (1275, 13), (1293, 4), (1449, 14), (1488, 3), (1511, 11), (1591, 4), (1616, 3), (1667, 5), (1705, 4), (1848, 1), (1882, 7), (2169, 32)]
def cs95544 : List ℕ := [0, 70, 28, 18, 45, 30, 11, 100, 73, 0, 99, 81, 99, 100, 99, 0, 95, 100, 99, 17, 70, 100, 0, 100, 39, 241, 100, 52, 29, 78, 100, 150, 11, 99, 40, 99, 103, 18, 29, 191, 72, 100, 38, 96, 346, 100, 0, 0, 0, 101, 101, 176, 0, 91, 100, 262, 100, 80, 62, 100, 220, 26, 79, 100, 100, 100, 177, 76, 101, 2, 325, 102, 101, 3, 77, 99, 167, 82, 291, 101, 17, 202, 100, 88, 0, 99, 101, 100, 40, 100, 100, 97, 100, 100, 51, 100, 99, 100, 100, 99, 101, 100, 74, 100, 76, 100, 49, 83, 100, 1, 100, 101, 99, 89, 99, 100, 100, 99, 100, 100, 28, 99, 99, 96, 99, 90, 100, 100, 80, 100, 78, 100, 100, 99, 100, 98, 100, 79, 99, 98, 99, 94, 91, 100, 82, 100, 83, 80, 100, 70, 99, 100, 79, 98]
theorem node95544 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95544 support demand code
    entries95544 ((insert 69 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 55 (insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95539 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 55 (insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    69 node95543 node95544
def entries95541 : List (Fin 2295 × ℕ) := [(4, 37), (21, 13), (77, 63), (100, 32), (132, 12), (468, 6), (472, 13), (529, 32), (571, 20), (630, 29), (632, 29), (691, 8), (731, 62), (741, 9), (777, 2), (779, 3), (783, 12), (784, 6), (813, 3), (845, 30), (855, 7), (870, 20), (888, 7), (915, 31), (916, 50), (919, 12), (920, 18), (922, 24), (924, 6), (925, 43), (944, 18), (946, 11), (949, 45), (950, 23), (957, 8), (966, 25), (973, 36), (984, 51), (1009, 12), (1012, 12), (1025, 19), (1043, 19), (1061, 1), (1073, 24), (1077, 1), (1081, 4), (1090, 1), (1108, 8), (1123, 6), (1126, 10), (1128, 1), (1153, 6), (1155, 32), (1162, 3), (1170, 18), (1171, 1), (1173, 9), (1175, 16), (1211, 8), (1212, 17), (1229, 1), (1238, 31), (1254, 13), (1266, 6), (1275, 14), (1308, 4), (1403, 1), (1449, 6), (1462, 7), (1488, 19), (1543, 5), (1556, 27), (1584, 1), (1591, 3), (1605, 9), (1705, 2), (1887, 5), (2131, 9)]
def cs95541 : List ℕ := [31, 93, 44, 13, 50, 7, 0, 100, 81, 16, 63, 77, 100, 73, 100, 7, 75, 100, 100, 36, 80, 0, 0, 99, 60, 219, 100, 7, 63, 58, 100, 214, 58, 99, 32, 100, 64, 78, 63, 170, 85, 99, 18, 100, 217, 88, 0, 0, 91, 100, 99, 141, 66, 101, 83, 7, 99, 99, 100, 100, 220, 100, 47, 100, 100, 98, 103, 89, 99, 203, 247, 99, 100, 100, 99, 100, 111, 69, 282, 101, 100, 188, 100, 79, 100, 45, 100, 100, 36, 100, 100, 100, 100, 99, 41, 100, 100, 100, 100, 100, 100, 101, 56, 99, 100, 100, 99, 101, 100, 26, 100, 100, 100, 101, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 81, 100, 100, 100, 100, 101, 75, 100, 100, 100, 101, 100, 58, 100, 100, 101, 77, 80, 99, 100, 89, 74, 91, 100, 64, 87, 83, 76, 100]
theorem node95541 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95541 support demand code
    entries95541 ((insert 55 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries95542 : List (Fin 2295 × ℕ) := [(4, 300), (77, 700), (132, 25), (421, 2), (472, 233), (498, 270), (507, 244), (529, 613), (740, 309), (741, 49), (783, 169), (784, 256), (813, 73), (845, 324), (870, 270), (915, 373), (916, 377), (919, 14), (920, 276), (922, 347), (924, 6), (925, 352), (944, 269), (949, 554), (950, 438), (957, 11), (965, 2), (966, 232), (973, 389), (984, 472), (1009, 129), (1012, 104), (1043, 225), (1072, 5), (1073, 384), (1081, 117), (1108, 126), (1121, 30), (1128, 9), (1139, 74), (1153, 214), (1155, 373), (1160, 12), (1163, 119), (1170, 204), (1172, 1), (1173, 159), (1175, 226), (1212, 74), (1238, 208), (1241, 11), (1249, 9), (1254, 173), (1261, 28), (1269, 23), (1275, 101), (1324, 117), (1344, 95), (1370, 59), (1403, 14), (1449, 21), (1488, 117), (1520, 26), (1543, 12), (1555, 39), (1556, 87)]
def cs95542 : List ℕ := [234, 797, 467, 26, 473, 0, 0, 964, 951, 270, 700, 677, 1001, 730, 1000, 26, 665, 894, 1000, 117, 731, 0, 0, 1002, 711, 2025, 1001, 26, 700, 0, 1001, 2351, 602, 1001, 412, 1000, 640, 0, 700, 1683, 583, 1000, 269, 1000, 2075, 488, 0, 0, 0, 1001, 1000, 2017, 11, 999, 763, 0, 1000, 1000, 387, 1000, 2270, 361, 564, 1000, 1000, 960, 1356, 761, 999, 0, 3550, 1000, 1001, 0, 956, 1001, 641, 844, 3223, 1001, 117, 1784, 1001, 776, 0, 505, 1000, 1000, 226, 999, 1001, 999, 1000, 1001, 373, 832, 999, 1000, 1000, 1000, 999, 999, 645, 1001, 999, 1000, 692, 999, 999, 74, 999, 999, 1001, 874, 999, 999, 1000, 1000, 999, 1004, 255, 999, 883, 999, 1000, 894, 999, 999, 999, 999, 1000, 832, 999, 998, 999, 999, 999, 594, 998, 998, 1000, 787, 830, 998, 946, 999, 784, 803, 998, 631, 800, 790, 828, 999]
theorem node95542 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 55 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95542 support demand code
    entries95542 ((insert 69 (insert 55 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node95540 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    69 node95541 node95542
theorem node95533 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 31 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    55 node95539 node95540
def entries95537 : List (Fin 2295 × ℕ) := [(4, 11), (77, 170), (91, 9), (302, 22), (409, 54), (472, 157), (475, 11), (498, 170), (569, 24), (630, 1), (731, 181), (738, 7), (741, 49), (782, 22), (783, 1), (784, 65), (813, 24), (845, 72), (851, 27), (855, 4), (870, 86), (873, 63), (874, 63), (884, 68), (886, 31), (924, 11), (925, 96), (931, 19), (932, 48), (944, 8), (949, 91), (950, 101), (957, 63), (966, 76), (973, 118), (984, 84), (985, 5), (1009, 27), (1012, 19), (1025, 35), (1069, 30), (1072, 5), (1073, 70), (1076, 1), (1108, 24), (1126, 5), (1143, 14), (1153, 2), (1154, 26), (1155, 47), (1170, 26), (1171, 45), (1175, 16), (1177, 9), (1179, 42), (1199, 75), (1212, 36), (1228, 27), (1232, 2), (1248, 106), (1261, 39), (1275, 26), (1449, 11), (1488, 42), (1497, 25), (1499, 10), (1556, 6), (1572, 3), (1605, 11), (1701, 2), (1831, 10), (2169, 42), (2225, 5)]
def cs95537 : List ℕ := [0, 158, 157, 11, 113, 79, 75, 256, 256, 0, 170, 97, 257, 210, 256, 0, 256, 244, 174, 0, 72, 75, 0, 256, 157, 591, 256, 0, 180, 76, 257, 44, 118, 256, 16, 257, 203, 16, 180, 236, 256, 257, 8, 257, 249, 256, 10, 10, 192, 400, 257, 424, 64, 257, 257, 256, 257, 205, 255, 256, 651, 256, 157, 256, 197, 256, 314, 63, 257, 256, 710, 256, 256, 203, 174, 414, 322, 245, 686, 256, 212, 550, 256, 219, 192, 231, 254, 256, 102, 257, 256, 226, 255, 255, 132, 256, 257, 256, 255, 256, 257, 256, 249, 255, 255, 258, 243, 257, 255, 78, 257, 256, 254, 238, 256, 257, 256, 256, 257, 255, 255, 254, 256, 258, 256, 241, 257, 254, 203, 256, 223, 194, 257, 256, 222, 256, 256, 191, 257, 256, 257, 255, 215, 225, 195, 255, 228, 236, 250, 199, 256, 221, 224, 256]
theorem node95537 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 49 (insert 75 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95537 support demand code
    entries95537 ((insert 31 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 49 (insert 75 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries95538 : List (Fin 2295 × ℕ) := [(20, 2), (77, 71), (132, 3), (397, 15), (448, 7), (468, 30), (498, 36), (507, 35), (569, 5), (572, 28), (630, 23), (632, 15), (731, 36), (741, 18), (783, 11), (784, 20), (843, 2), (845, 27), (870, 41), (873, 29), (874, 26), (888, 5), (924, 4), (925, 31), (944, 23), (949, 29), (950, 43), (957, 20), (966, 23), (973, 50), (984, 30), (1011, 7), (1012, 13), (1023, 7), (1025, 2), (1044, 6), (1072, 2), (1073, 14), (1108, 4), (1123, 8), (1133, 3), (1143, 6), (1153, 10), (1155, 22), (1159, 14), (1170, 15), (1171, 26), (1175, 22), (1179, 13), (1186, 4), (1199, 24), (1212, 1), (1228, 19), (1248, 43), (1254, 3), (1261, 5), (1266, 12), (1275, 1), (1305, 4), (1313, 5), (1488, 5), (1497, 2), (1667, 7), (1668, 2), (1791, 1), (1831, 3), (2169, 15), (2225, 8)]
def cs95538 : List ℕ := [5, 84, 0, 7, 32, 29, 24, 60, 70, 35, 71, 74, 101, 81, 100, 0, 36, 99, 100, 33, 60, 24, 0, 101, 35, 201, 100, 0, 71, 64, 101, 15, 70, 100, 22, 100, 3, 43, 74, 99, 31, 100, 23, 100, 95, 99, 0, 3, 36, 3, 99, 157, 58, 100, 95, 99, 101, 82, 100, 58, 212, 100, 84, 100, 92, 99, 131, 20, 100, 100, 236, 100, 85, 69, 89, 169, 112, 99, 213, 100, 72, 156, 100, 93, 51, 74, 100, 100, 22, 99, 99, 100, 100, 100, 61, 100, 101, 101, 100, 100, 99, 99, 73, 100, 99, 101, 79, 100, 100, 18, 100, 100, 99, 82, 100, 100, 100, 100, 100, 100, 58, 100, 100, 99, 101, 100, 101, 100, 62, 100, 90, 95, 100, 100, 92, 100, 100, 86, 100, 99, 100, 96, 93, 100, 85, 99, 98, 93, 97, 88, 100, 90, 94, 97]
theorem node95538 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 49 (insert 31 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95538 support demand code
    entries95538 ((insert 49 (insert 31 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 75 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95535 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 75 (insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    49 node95537 node95538
def entries95536 : List (Fin 2295 × ℕ) := [(20, 1), (37, 11), (77, 153), (132, 12), (273, 10), (302, 30), (472, 52), (498, 132), (507, 27), (572, 63), (630, 11), (639, 41), (691, 83), (731, 131), (740, 19), (813, 40), (842, 4), (845, 68), (851, 31), (855, 18), (870, 77), (873, 73), (874, 61), (884, 47), (886, 14), (924, 37), (925, 76), (931, 4), (932, 64), (934, 6), (944, 7), (949, 119), (950, 81), (957, 23), (966, 90), (973, 116), (984, 78), (1004, 10), (1009, 32), (1025, 5), (1043, 47), (1045, 12), (1073, 44), (1078, 12), (1081, 34), (1082, 12), (1123, 19), (1126, 19), (1138, 5), (1139, 36), (1153, 3), (1155, 39), (1170, 20), (1171, 25), (1175, 63), (1186, 43), (1199, 73), (1212, 28), (1228, 29), (1254, 9), (1258, 8), (1261, 38), (1272, 5), (1298, 6), (1308, 3), (1313, 29), (1483, 29), (1488, 6), (1497, 24), (1545, 26), (1605, 25), (1667, 5), (1887, 28), (2001, 6), (2169, 29), (2225, 26)]
def cs95536 : List ℕ := [29, 150, 52, 30, 142, 131, 73, 160, 255, 27, 153, 86, 256, 208, 255, 0, 134, 248, 208, 74, 77, 73, 0, 255, 79, 548, 255, 0, 153, 114, 256, 29, 150, 255, 63, 256, 92, 87, 164, 189, 231, 256, 17, 256, 298, 255, 0, 0, 156, 257, 256, 457, 89, 256, 257, 255, 256, 172, 256, 257, 403, 256, 143, 255, 224, 180, 256, 49, 255, 257, 451, 256, 257, 206, 216, 45, 275, 247, 703, 255, 219, 358, 256, 188, 185, 113, 257, 257, 131, 255, 255, 204, 257, 258, 186, 258, 256, 257, 256, 220, 255, 255, 217, 257, 218, 257, 229, 254, 256, 71, 256, 256, 257, 256, 255, 255, 257, 256, 256, 262, 257, 255, 222, 256, 257, 217, 256, 257, 247, 256, 256, 223, 256, 255, 257, 255, 256, 174, 254, 255, 256, 215, 231, 256, 255, 257, 210, 255, 255, 217, 254, 256, 226, 255]
theorem node95536 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 31 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95536 support demand code
    entries95536 ((insert 75 (insert 31 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node95534 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    75 node95535 node95536
theorem node95532 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    31 node95533 node95534
theorem node95530 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    88 node95531 node95532
theorem node95503 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 60 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    46 node95529 node95530
def entries95527 : List (Fin 2295 × ℕ) := [(4, 60), (36, 15), (37, 137), (77, 94), (132, 7), (179, 25), (216, 20), (409, 22), (468, 4), (472, 91), (475, 47), (484, 24), (531, 5), (540, 15), (542, 51), (569, 25), (622, 58), (630, 95), (632, 70), (673, 28), (690, 8), (691, 67), (730, 23), (731, 11), (737, 18), (741, 65), (797, 1), (816, 13), (845, 47), (864, 19), (868, 25), (870, 91), (873, 25), (874, 227), (908, 13), (909, 70), (916, 54), (920, 5), (921, 24), (922, 94), (932, 6), (944, 103), (946, 44), (965, 63), (966, 22), (973, 119), (984, 82), (1008, 24), (1009, 31), (1011, 37), (1012, 16), (1069, 23), (1073, 3), (1077, 35), (1108, 31), (1122, 5), (1123, 66), (1126, 6), (1133, 18), (1153, 9), (1155, 28), (1161, 12), (1165, 2), (1170, 9), (1171, 96), (1175, 17), (1186, 41), (1188, 86), (1222, 2), (1226, 22), (1232, 38), (1237, 73), (1254, 39), (1258, 37), (1261, 5), (1275, 11), (1298, 8), (1308, 50), (1310, 19), (1313, 5), (1354, 22), (1403, 9), (1488, 17), (1499, 2), (1591, 10), (1619, 8), (2116, 1), (2225, 22)]
def cs95527 : List ℕ := [5, 225, 93, 52, 177, 256, 0, 256, 241, 27, 119, 256, 256, 257, 225, 0, 240, 205, 400, 137, 256, 0, 25, 256, 172, 601, 257, 0, 256, 190, 256, 256, 79, 256, 40, 257, 420, 256, 256, 344, 256, 256, 103, 256, 541, 256, 256, 25, 238, 255, 256, 238, 216, 256, 254, 257, 256, 256, 257, 255, 0, 256, 204, 257, 255, 256, 255, 54, 257, 738, 182, 256, 257, 256, 153, 256, 486, 256, 484, 256, 256, 733, 257, 182, 256, 184, 221, 256, 255, 257, 257, 256, 255, 498, 138, 256, 255, 256, 256, 217, 255, 256, 174, 256, 180, 256, 256, 220, 256, 41, 256, 290, 257, 189, 219, 255, 256, 257, 255, 256, 256, 256, 255, 256, 257, 255, 249, 256, 256, 256, 256, 145, 255, 256, 256, 257, 255, 197, 256, 256, 235, 244, 188, 256, 236, 161, 253, 206, 255, 256, 256, 256, 206, 237]
theorem node95527 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 69 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95527 support demand code
    entries95527 ((insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 69 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries95528 : List (Fin 2295 × ℕ) := [(4, 6), (37, 56), (72, 4), (77, 40), (91, 1), (92, 2), (344, 5), (421, 3), (472, 36), (475, 17), (529, 17), (540, 16), (542, 5), (569, 3), (622, 25), (632, 47), (673, 2), (675, 1), (677, 9), (690, 6), (692, 5), (737, 22), (741, 19), (813, 1), (817, 3), (842, 6), (845, 30), (851, 1), (868, 16), (870, 40), (873, 20), (874, 56), (888, 4), (908, 10), (910, 3), (916, 23), (920, 21), (921, 22), (934, 3), (944, 40), (946, 6), (962, 1), (966, 34), (973, 42), (984, 34), (985, 10), (1008, 1), (1009, 14), (1012, 12), (1061, 3), (1076, 7), (1077, 16), (1123, 31), (1126, 17), (1133, 2), (1137, 9), (1153, 13), (1155, 8), (1159, 3), (1170, 8), (1171, 17), (1174, 16), (1175, 20), (1186, 17), (1188, 6), (1223, 14), (1226, 28), (1232, 20), (1237, 15), (1258, 4), (1313, 24), (1316, 1), (1560, 1), (1572, 6), (1580, 3), (1591, 15), (1619, 21), (1732, 14), (1739, 4), (2225, 8)]
def cs95528 : List ℕ := [38, 51, 36, 41, 63, 95, 0, 99, 100, 21, 60, 86, 100, 99, 98, 0, 65, 100, 164, 60, 99, 0, 0, 83, 72, 245, 98, 0, 100, 47, 99, 101, 38, 100, 36, 99, 128, 97, 100, 117, 100, 100, 45, 99, 211, 96, 99, 16, 79, 100, 100, 139, 52, 99, 99, 100, 101, 100, 99, 99, 0, 100, 85, 100, 99, 101, 99, 23, 100, 216, 113, 100, 101, 52, 91, 58, 189, 83, 160, 100, 99, 176, 100, 67, 100, 48, 72, 99, 100, 99, 100, 101, 99, 0, 70, 100, 99, 82, 101, 80, 102, 100, 87, 100, 75, 96, 101, 99, 101, 20, 100, 107, 100, 100, 98, 100, 100, 100, 100, 101, 89, 101, 101, 99, 100, 90, 100, 101, 100, 100, 73, 95, 101, 101, 101, 100, 101, 83, 100, 101, 100, 81, 94, 101, 100, 77, 95, 93, 101, 92, 101, 101, 81, 87]
theorem node95528 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95528 support demand code
    entries95528 ((insert 93 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95515 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    93 node95527 node95528
def entries95525 : List (Fin 2295 × ℕ) := [(37, 428), (43, 13), (77, 269), (132, 97), (179, 188), (472, 502), (475, 192), (483, 54), (498, 4), (529, 289), (540, 486), (569, 205), (623, 95), (625, 51), (673, 87), (675, 182), (691, 127), (741, 163), (797, 42), (812, 214), (816, 80), (842, 34), (845, 262), (850, 91), (870, 393), (873, 444), (874, 266), (884, 93), (906, 22), (908, 207), (910, 177), (916, 323), (920, 58), (921, 89), (943, 18), (944, 328), (959, 180), (960, 524), (965, 252), (966, 130), (973, 531), (984, 326), (1010, 143), (1012, 23), (1033, 6), (1044, 6), (1069, 79), (1072, 42), (1073, 56), (1123, 108), (1133, 71), (1143, 22), (1153, 126), (1155, 71), (1159, 39), (1160, 9), (1170, 91), (1171, 250), (1175, 95), (1177, 24), (1186, 220), (1223, 181), (1232, 37), (1235, 32), (1241, 20), (1258, 33), (1272, 85), (1293, 115), (1308, 13), (1313, 161), (1368, 51), (1370, 14), (1401, 16), (1488, 177), (1516, 49), (1632, 33), (1633, 150), (1657, 55), (1701, 240), (1705, 16), (2206, 202), (2225, 88)]
def cs95525 : List ℕ := [397, 317, 502, 444, 397, 643, 13, 1000, 829, 0, 269, 821, 1000, 999, 1000, 0, 982, 975, 1648, 428, 1000, 13, 188, 1000, 578, 2032, 1000, 0, 1001, 201, 1000, 999, 192, 1000, 117, 1000, 1557, 444, 885, 1252, 1001, 1000, 346, 1000, 1839, 928, 1739, 0, 188, 1000, 1000, 1617, 0, 1000, 1001, 999, 999, 1000, 444, 1000, 93, 1001, 781, 1001, 1000, 999, 1000, 323, 1001, 266, 1544, 1928, 1000, 253, 864, 808, 2040, 768, 1865, 1000, 1001, 1929, 1000, 857, 371, 704, 998, 1000, 1000, 1001, 1001, 906, 1522, 1000, 809, 772, 1000, 1001, 1000, 1000, 1000, 1000, 1001, 1000, 840, 999, 1000, 668, 1000, 289, 1000, 1055, 1000, 1000, 826, 998, 1000, 1001, 1000, 999, 1000, 1000, 1000, 999, 1000, 921, 999, 1000, 1000, 1001, 1000, 939, 1000, 1001, 999, 1000, 979, 893, 1001, 1001, 1000, 1000, 1001, 1000, 890, 722, 905, 842, 1001, 1001, 1001, 1000, 1000, 939]
theorem node95525 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 46 (insert 71 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95525 support demand code
    entries95525 ((insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 92 (insert 46 (insert 71 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries95526 : List (Fin 2295 × ℕ) := [(4, 14), (37, 43), (179, 24), (222, 4), (273, 10), (466, 10), (472, 2), (475, 34), (498, 5), (507, 56), (540, 28), (569, 29), (625, 67), (675, 7), (736, 11), (741, 12), (797, 13), (816, 14), (842, 15), (843, 9), (845, 31), (870, 37), (872, 11), (873, 42), (874, 24), (884, 15), (906, 9), (910, 23), (916, 24), (917, 4), (920, 10), (921, 22), (931, 4), (933, 3), (944, 37), (959, 13), (960, 4), (965, 26), (969, 2), (973, 50), (984, 31), (1005, 3), (1009, 7), (1033, 1), (1072, 2), (1073, 19), (1076, 10), (1090, 5), (1108, 1), (1114, 18), (1122, 1), (1123, 18), (1126, 3), (1127, 6), (1133, 3), (1137, 5), (1143, 14), (1153, 22), (1155, 10), (1170, 16), (1171, 19), (1174, 6), (1175, 21), (1178, 4), (1179, 6), (1182, 12), (1183, 5), (1186, 7), (1223, 5), (1228, 1), (1258, 3), (1313, 12), (1403, 5), (1488, 3), (1516, 3), (1534, 7), (1572, 4), (1580, 23), (1657, 3), (1701, 17), (1739, 2), (1750, 5)]
def cs95526 : List ℕ := [30, 48, 2, 46, 57, 55, 0, 74, 82, 56, 5, 89, 100, 100, 85, 0, 35, 97, 231, 43, 100, 0, 24, 100, 67, 189, 100, 0, 101, 24, 101, 100, 100, 100, 36, 100, 105, 46, 72, 123, 101, 100, 45, 100, 193, 99, 162, 0, 26, 87, 100, 111, 0, 100, 101, 99, 99, 100, 100, 100, 15, 92, 100, 100, 100, 99, 99, 45, 100, 26, 147, 174, 100, 81, 80, 81, 148, 89, 153, 99, 99, 102, 101, 99, 26, 99, 100, 100, 101, 100, 99, 85, 24, 100, 71, 101, 100, 79, 99, 100, 100, 99, 101, 101, 81, 100, 100, 96, 99, 17, 100, 110, 48, 100, 99, 100, 101, 99, 101, 101, 37, 100, 98, 100, 100, 100, 101, 101, 100, 100, 99, 101, 100, 100, 99, 88, 100, 81, 100, 99, 100, 94, 99, 100, 99, 100, 99, 88, 100, 100, 99, 99, 100, 73]
theorem node95526 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 71 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95526 support demand code
    entries95526 ((insert 92 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 71 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95523 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 71 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 71 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    92 node95525 node95526
def entries95524 : List (Fin 2295 × ℕ) := [(37, 84), (43, 26), (77, 125), (137, 23), (179, 35), (273, 18), (302, 6), (409, 37), (468, 65), (472, 101), (475, 3), (498, 79), (507, 47), (529, 131), (569, 29), (690, 42), (691, 35), (741, 54), (816, 40), (843, 20), (845, 51), (868, 19), (870, 90), (872, 18), (873, 108), (885, 44), (891, 12), (916, 37), (920, 6), (921, 18), (932, 65), (944, 72), (959, 24), (960, 69), (962, 28), (965, 35), (966, 73), (972, 1), (973, 130), (975, 6), (984, 48), (985, 7), (1009, 5), (1033, 5), (1072, 11), (1073, 25), (1076, 16), (1090, 24), (1119, 31), (1123, 42), (1133, 24), (1137, 2), (1143, 9), (1153, 44), (1154, 38), (1155, 20), (1170, 59), (1171, 60), (1175, 65), (1179, 35), (1193, 31), (1226, 33), (1241, 9), (1249, 10), (1261, 63), (1273, 17), (1293, 2), (1313, 58), (1354, 15), (1370, 1), (1488, 20), (1632, 8), (1701, 65), (2225, 23)]
def cs95524 : List ℕ := [89, 116, 101, 61, 89, 142, 26, 217, 252, 47, 144, 164, 256, 257, 240, 0, 233, 256, 394, 84, 135, 38, 35, 256, 148, 609, 256, 12, 125, 61, 256, 257, 68, 259, 65, 257, 132, 61, 244, 343, 195, 257, 72, 256, 334, 256, 0, 19, 68, 255, 255, 335, 0, 255, 255, 257, 256, 257, 200, 256, 0, 256, 212, 256, 256, 255, 256, 37, 256, 33, 402, 441, 255, 51, 189, 190, 447, 254, 487, 257, 33, 345, 255, 220, 94, 206, 256, 256, 256, 256, 256, 236, 256, 256, 199, 195, 256, 221, 256, 256, 255, 256, 256, 256, 196, 257, 257, 164, 255, 81, 256, 269, 257, 241, 257, 256, 257, 256, 256, 255, 257, 256, 195, 258, 257, 256, 255, 256, 256, 257, 251, 256, 257, 257, 255, 256, 255, 257, 256, 257, 256, 256, 257, 209, 258, 255, 240, 225, 242, 190, 249, 228, 257, 176]
theorem node95524 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95524 support demand code
    entries95524 ((insert 46 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 71 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node95517 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 71 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    46 node95523 node95524
def entries95521 : List (Fin 2295 × ℕ) := [(4, 528), (37, 3359), (77, 4354), (132, 148), (179, 132), (273, 1813), (344, 198), (421, 2018), (472, 5079), (475, 2931), (484, 968), (498, 171), (529, 5327), (540, 4082), (569, 420), (572, 716), (623, 2635), (673, 3008), (675, 465), (690, 1961), (691, 1538), (741, 866), (833, 172), (843, 910), (845, 2024), (868, 1025), (870, 4199), (873, 1769), (874, 2904), (884, 907), (908, 69), (910, 1549), (916, 249), (920, 2292), (922, 2104), (944, 2147), (946, 165), (960, 1731), (965, 2632), (966, 848), (970, 663), (972, 1171), (973, 5125), (984, 3357), (1005, 225), (1006, 297), (1009, 887), (1033, 139), (1034, 87), (1061, 1067), (1076, 559), (1123, 1378), (1133, 203), (1153, 202), (1155, 712), (1157, 29), (1167, 630), (1170, 1212), (1171, 1700), (1175, 1207), (1176, 362), (1177, 1435), (1179, 1863), (1182, 863), (1186, 747), (1223, 462), (1247, 569), (1254, 2408), (1261, 729), (1273, 34), (1293, 592), (1313, 1036), (1323, 1283), (1328, 248), (1499, 1394), (1534, 448), (1591, 13), (1616, 184), (1632, 816), (1633, 323), (1655, 30), (1667, 185), (1780, 471), (1795, 27), (1887, 356), (1912, 1202), (1991, 541)]
def cs95521 : List ℕ := [1498, 4960, 5106, 3967, 4461, 5363, 0, 10000, 7964, 0, 5379, 10000, 10000, 10000, 10000, 0, 9999, 8417, 15355, 4075, 10001, 0, 132, 8862, 5106, 19677, 9999, 0, 10001, 132, 10000, 9999, 5712, 10000, 1207, 10000, 17659, 4935, 7845, 12343, 9999, 15319, 2570, 9250, 14912, 10000, 13664, 1025, 297, 9815, 10000, 19645, 27, 10000, 10001, 9999, 10000, 10000, 1934, 10000, 907, 8737, 6769, 10000, 10000, 9999, 10000, 1742, 10000, 3069, 15368, 3948, 10000, 2660, 6425, 10000, 12309, 10000, 20509, 9999, 10001, 9591, 10000, 6297, 2476, 8836, 10000, 9999, 10001, 10000, 10000, 10000, 10001, 10001, 9073, 9999, 9998, 10001, 10001, 6930, 10001, 9999, 10001, 10001, 10000, 10000, 10001, 9999, 10001, 3815, 9998, 11103, 10001, 10000, 10000, 10000, 10001, 10001, 9999, 10000, 9866, 10000, 9141, 8833, 10000, 9881, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10001, 10000, 9858, 9999, 10000, 9735, 10001, 9976, 9999, 10000, 10001, 9999, 10000, 8531, 10000, 10000, 10000, 10000, 9156, 6802]
theorem node95521 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 41 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95521 support demand code
    entries95521 ((insert 71 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 41 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries95522 : List (Fin 2295 × ℕ) := [(4, 38), (35, 27), (43, 5), (77, 54), (273, 22), (421, 10), (466, 17), (472, 53), (475, 31), (484, 5), (498, 14), (529, 41), (572, 21), (639, 4), (690, 12), (737, 6), (739, 9), (740, 5), (741, 7), (843, 11), (845, 16), (868, 22), (870, 38), (872, 22), (873, 10), (885, 11), (888, 2), (916, 7), (920, 25), (922, 19), (944, 25), (949, 3), (950, 4), (960, 27), (965, 25), (966, 11), (972, 12), (973, 39), (984, 39), (985, 3), (1005, 2), (1008, 2), (1009, 7), (1010, 1), (1012, 12), (1031, 3), (1061, 4), (1072, 9), (1075, 13), (1076, 8), (1121, 1), (1123, 10), (1126, 2), (1133, 7), (1143, 1), (1153, 8), (1155, 13), (1163, 17), (1170, 18), (1171, 19), (1174, 3), (1175, 35), (1176, 4), (1179, 26), (1238, 8), (1247, 3), (1249, 8), (1254, 6), (1261, 10), (1273, 4), (1293, 4), (1313, 3), (1483, 5), (1499, 18), (1616, 10), (1634, 3), (1663, 1), (1667, 18), (1780, 11)]
def cs95522 : List ℕ := [28, 60, 61, 34, 47, 35, 5, 100, 96, 0, 76, 100, 100, 100, 100, 0, 100, 100, 112, 23, 69, 5, 0, 86, 61, 250, 100, 0, 72, 37, 100, 100, 58, 100, 38, 100, 107, 44, 57, 112, 100, 150, 27, 100, 137, 99, 18, 25, 0, 100, 100, 123, 5, 99, 101, 100, 101, 85, 10, 100, 7, 88, 76, 100, 101, 99, 101, 7, 100, 5, 144, 37, 100, 40, 84, 83, 116, 89, 205, 101, 44, 61, 99, 72, 21, 100, 101, 100, 100, 100, 101, 99, 87, 99, 86, 100, 100, 99, 99, 81, 100, 99, 99, 99, 98, 100, 98, 101, 100, 42, 100, 100, 97, 100, 100, 101, 98, 100, 100, 100, 96, 99, 99, 87, 99, 84, 99, 99, 99, 100, 102, 100, 99, 100, 99, 100, 100, 100, 100, 91, 99, 100, 101, 89, 98, 100, 101, 70, 100, 86, 100, 82, 98, 66]
theorem node95522 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 71 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95522 support demand code
    entries95522 ((insert 46 (insert 71 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 41 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95519 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 41 (insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    46 node95521 node95522
def entries95520 : List (Fin 2295 × ℕ) := [(4, 20), (37, 40), (77, 35), (92, 7), (179, 15), (216, 9), (421, 8), (472, 38), (478, 5), (542, 9), (569, 16), (572, 9), (576, 1), (577, 6), (623, 4), (673, 26), (691, 6), (741, 15), (845, 29), (850, 7), (868, 26), (870, 8), (872, 38), (873, 6), (874, 13), (885, 34), (908, 8), (910, 19), (916, 28), (920, 1), (921, 1), (922, 32), (944, 15), (959, 8), (960, 11), (965, 21), (966, 19), (970, 2), (972, 17), (973, 52), (984, 24), (985, 2), (1005, 4), (1009, 17), (1010, 4), (1012, 2), (1061, 17), (1073, 1), (1114, 12), (1123, 31), (1137, 3), (1170, 8), (1171, 6), (1174, 9), (1175, 23), (1182, 8), (1186, 17), (1223, 2), (1235, 9), (1237, 24), (1238, 3), (1261, 6), (1313, 35), (1499, 18), (1591, 4), (1632, 2), (1633, 1), (1640, 16), (1663, 14), (1667, 4), (1780, 1), (1887, 8), (1912, 14), (1991, 11), (2001, 2), (2116, 6), (2225, 7)]
def cs95520 : List ℕ := [40, 73, 41, 42, 86, 99, 0, 101, 100, 0, 61, 37, 100, 64, 99, 0, 101, 99, 122, 49, 100, 0, 15, 98, 65, 268, 101, 0, 84, 15, 100, 100, 0, 100, 32, 101, 171, 42, 90, 116, 101, 0, 19, 99, 187, 99, 100, 26, 31, 89, 99, 71, 9, 99, 100, 99, 99, 70, 22, 100, 0, 66, 61, 98, 99, 100, 100, 36, 100, 29, 105, 26, 99, 18, 90, 100, 89, 80, 206, 99, 100, 107, 98, 55, 51, 100, 93, 69, 98, 100, 99, 101, 100, 100, 83, 98, 98, 95, 98, 89, 90, 100, 99, 100, 99, 98, 100, 99, 100, 34, 100, 101, 99, 99, 98, 99, 101, 99, 100, 99, 93, 92, 85, 74, 101, 100, 100, 99, 99, 100, 65, 99, 100, 99, 100, 99, 90, 87, 101, 101, 100, 88, 82, 100, 99, 90, 90, 80, 100, 100, 99, 94, 85, 69]
theorem node95520 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 41 (insert 71 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95520 support demand code
    entries95520 ((insert 41 (insert 71 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95518 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    41 node95519 node95520
theorem node95516 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    71 node95517 node95518
theorem node95505 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    69 node95515 node95516
def entries95511 : List (Fin 2295 × ℕ) := [(37, 25), (77, 46), (273, 6), (472, 46), (483, 72), (498, 46), (540, 61), (617, 47), (625, 45), (630, 32), (632, 96), (673, 5), (691, 64), (692, 1), (740, 8), (741, 66), (845, 103), (851, 65), (852, 42), (859, 18), (862, 18), (868, 92), (883, 1), (885, 117), (888, 9), (891, 14), (910, 9), (916, 114), (920, 24), (921, 55), (944, 78), (945, 7), (959, 26), (960, 90), (965, 21), (966, 40), (970, 17), (973, 127), (975, 35), (984, 49), (1008, 8), (1009, 25), (1010, 12), (1022, 25), (1033, 26), (1034, 13), (1045, 4), (1061, 6), (1071, 16), (1073, 10), (1108, 11), (1122, 7), (1123, 25), (1133, 35), (1155, 33), (1170, 44), (1171, 60), (1174, 3), (1175, 6), (1177, 39), (1179, 60), (1186, 5), (1199, 124), (1201, 25), (1212, 44), (1226, 41), (1247, 7), (1258, 15), (1261, 9), (1308, 14), (1310, 25), (1328, 15), (1348, 9), (1370, 10), (1403, 25), (1469, 32), (1483, 4), (1591, 13), (1616, 18), (1660, 5), (1667, 10), (1732, 11), (1780, 7), (1991, 5), (2116, 11), (2206, 16)]
def cs95511 : List ℕ := [0, 252, 46, 0, 256, 246, 124, 256, 256, 0, 138, 35, 257, 149, 256, 0, 236, 252, 0, 34, 256, 163, 0, 256, 118, 686, 257, 14, 193, 256, 256, 229, 6, 499, 34, 162, 459, 132, 71, 422, 256, 369, 78, 256, 422, 254, 255, 92, 125, 256, 257, 231, 132, 193, 256, 255, 256, 257, 139, 256, 0, 256, 256, 256, 256, 256, 255, 115, 256, 257, 379, 256, 256, 256, 217, 255, 337, 257, 444, 256, 256, 434, 250, 201, 218, 255, 222, 256, 256, 258, 256, 256, 257, 257, 123, 224, 255, 255, 256, 206, 255, 256, 256, 257, 255, 256, 256, 257, 256, 109, 256, 270, 225, 158, 223, 257, 257, 256, 256, 256, 257, 255, 256, 257, 257, 256, 255, 255, 255, 256, 230, 256, 255, 256, 256, 257, 251, 240, 257, 257, 256, 255, 222, 258, 226, 255, 256, 253, 256, 256, 256, 256, 251, 227]
theorem node95511 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 41 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95511 support demand code
    entries95511 ((insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 33 (insert 41 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries95513 : List (Fin 2295 × ℕ) := [(35, 56), (43, 24), (77, 52), (216, 2), (344, 6), (472, 46), (483, 2), (498, 40), (540, 20), (576, 15), (632, 3), (644, 12), (673, 4), (675, 8), (691, 18), (731, 8), (737, 3), (739, 12), (741, 27), (845, 18), (868, 6), (870, 46), (872, 1), (874, 40), (888, 15), (891, 58), (908, 22), (910, 11), (916, 38), (920, 12), (921, 1), (938, 2), (940, 24), (944, 34), (945, 7), (950, 3), (959, 16), (960, 25), (965, 10), (966, 20), (973, 49), (984, 33), (985, 12), (1004, 3), (1008, 5), (1028, 2), (1061, 4), (1075, 3), (1076, 4), (1120, 4), (1123, 27), (1133, 22), (1137, 10), (1153, 14), (1155, 1), (1160, 2), (1167, 2), (1170, 13), (1171, 2), (1173, 25), (1174, 10), (1175, 3), (1177, 12), (1179, 8), (1182, 2), (1186, 5), (1212, 9), (1237, 36), (1261, 9), (1293, 4), (1316, 3), (1469, 15), (1483, 17), (1485, 3), (1591, 18), (1605, 9), (1616, 14), (1632, 7), (1633, 4), (1794, 4)]
def cs95513 : List ℕ := [0, 54, 46, 0, 36, 94, 24, 100, 100, 0, 58, 82, 100, 97, 100, 0, 84, 90, 41, 15, 99, 82, 0, 100, 84, 194, 99, 58, 100, 100, 100, 99, 0, 35, 38, 100, 208, 20, 52, 127, 99, 190, 43, 101, 207, 100, 99, 6, 39, 100, 99, 82, 20, 100, 101, 241, 100, 100, 97, 99, 3, 73, 89, 100, 103, 99, 101, 44, 100, 99, 186, 100, 99, 63, 59, 95, 228, 89, 196, 99, 99, 179, 100, 74, 66, 78, 102, 101, 100, 99, 101, 101, 100, 99, 79, 100, 100, 99, 99, 101, 100, 101, 99, 98, 101, 100, 94, 68, 99, 25, 101, 112, 99, 98, 99, 100, 99, 101, 101, 101, 98, 100, 100, 100, 99, 101, 101, 100, 99, 100, 79, 99, 101, 99, 99, 100, 101, 96, 101, 100, 100, 94, 100, 100, 98, 94, 97, 88, 100, 100, 99, 100, 90, 80]
theorem node95513 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 33 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 41 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95513 support demand code
    entries95513 ((insert 33 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 55 (insert 41 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries95514 : List (Fin 2295 × ℕ) := [(37, 443), (77, 475), (179, 82), (273, 57), (409, 108), (472, 534), (483, 71), (498, 357), (540, 280), (616, 24), (617, 65), (630, 8), (632, 36), (672, 110), (675, 17), (691, 209), (737, 12), (740, 2), (741, 422), (817, 12), (845, 209), (868, 149), (870, 454), (888, 72), (910, 238), (916, 416), (920, 28), (921, 181), (922, 174), (944, 294), (959, 107), (960, 120), (965, 123), (966, 192), (972, 61), (973, 456), (975, 80), (984, 303), (1009, 113), (1010, 9), (1011, 34), (1012, 95), (1072, 33), (1073, 151), (1076, 22), (1077, 16), (1108, 48), (1123, 146), (1133, 65), (1137, 39), (1153, 53), (1155, 150), (1160, 149), (1170, 235), (1171, 147), (1174, 14), (1175, 237), (1179, 102), (1186, 16), (1188, 184), (1212, 147), (1223, 56), (1226, 198), (1237, 201), (1241, 32), (1247, 26), (1261, 104), (1275, 48), (1308, 101), (1335, 69), (1469, 193), (1483, 213), (1485, 17), (1488, 6), (1516, 10), (1572, 145), (1591, 53), (1640, 14), (1659, 18), (1660, 42), (1666, 6), (1668, 19), (1794, 106)]
def cs95514 : List ℕ := [56, 410, 534, 0, 257, 715, 0, 1000, 962, 0, 624, 791, 1000, 0, 861, 0, 862, 663, 0, 515, 1001, 0, 82, 1000, 806, 1961, 999, 0, 906, 339, 1000, 1000, 57, 647, 251, 712, 1513, 257, 1000, 1542, 999, 1057, 294, 1000, 1228, 813, 1000, 149, 689, 999, 1000, 1436, 257, 1001, 999, 102, 1000, 1000, 607, 1001, 0, 999, 828, 1000, 999, 1000, 999, 416, 1000, 998, 1653, 999, 1000, 885, 927, 999, 1326, 1000, 2008, 1000, 999, 2026, 1001, 703, 999, 794, 998, 801, 1098, 1000, 1000, 1000, 999, 999, 483, 999, 1001, 999, 1000, 903, 999, 1000, 1000, 1000, 998, 1000, 1000, 845, 999, 326, 1000, 1062, 1000, 869, 991, 1000, 1000, 1000, 999, 999, 999, 999, 999, 999, 1000, 1000, 1000, 999, 999, 1000, 1000, 1000, 1000, 1000, 998, 1000, 999, 890, 1001, 1000, 1000, 903, 1000, 1000, 915, 999, 884, 967, 1000, 881, 1000, 988, 862, 998]
theorem node95514 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 33 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95514 support demand code
    entries95514 ((insert 55 (insert 33 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 41 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node95512 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 33 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 33 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 41 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    55 node95513 node95514
theorem node95507 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 41 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    33 node95511 node95512
def entries95509 : List (Fin 2295 × ℕ) := [(4, 125), (37, 104), (72, 6), (77, 101), (179, 25), (236, 28), (409, 23), (472, 85), (483, 11), (527, 93), (542, 19), (571, 32), (577, 21), (622, 13), (675, 36), (691, 62), (741, 90), (797, 1), (813, 6), (816, 13), (845, 40), (852, 19), (868, 64), (870, 86), (874, 44), (885, 18), (891, 117), (908, 39), (910, 54), (916, 68), (920, 16), (921, 21), (922, 20), (925, 21), (944, 62), (959, 7), (960, 55), (965, 54), (966, 54), (973, 143), (982, 8), (984, 45), (985, 5), (1009, 33), (1010, 35), (1011, 2), (1033, 5), (1061, 19), (1069, 8), (1073, 22), (1075, 2), (1108, 36), (1123, 46), (1126, 3), (1133, 5), (1155, 37), (1171, 46), (1172, 18), (1173, 16), (1175, 42), (1179, 26), (1186, 44), (1188, 14), (1212, 6), (1223, 21), (1226, 84), (1237, 86), (1257, 2), (1258, 5), (1261, 20), (1272, 10), (1293, 14), (1372, 42), (1591, 23), (1632, 12), (1633, 2), (1657, 5), (1701, 46), (1780, 8), (1912, 17), (1991, 23), (2206, 29), (2225, 30)]
def cs95509 : List ℕ := [26, 256, 85, 0, 256, 201, 0, 256, 255, 0, 171, 198, 256, 86, 256, 0, 226, 256, 86, 136, 256, 117, 25, 256, 190, 559, 256, 117, 242, 53, 256, 257, 21, 256, 76, 256, 534, 28, 236, 345, 256, 0, 62, 255, 558, 184, 256, 64, 123, 257, 215, 184, 19, 256, 255, 257, 257, 161, 257, 257, 21, 257, 167, 257, 256, 256, 255, 68, 256, 257, 267, 473, 257, 127, 235, 256, 572, 256, 497, 257, 256, 595, 256, 209, 137, 240, 257, 256, 256, 255, 256, 227, 257, 257, 160, 257, 256, 258, 257, 245, 257, 256, 257, 256, 199, 257, 257, 237, 257, 76, 256, 285, 257, 256, 257, 257, 256, 257, 256, 257, 257, 256, 236, 256, 257, 256, 257, 256, 257, 256, 257, 238, 257, 256, 257, 257, 255, 233, 257, 256, 232, 254, 221, 256, 231, 256, 238, 252, 256, 255, 255, 240, 226, 230]
theorem node95509 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 41 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95509 support demand code
    entries95509 ((insert 41 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 71 (insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries95510 : List (Fin 2295 × ℕ) := [(4, 127), (37, 81), (72, 7), (77, 106), (179, 28), (216, 8), (472, 45), (483, 19), (527, 44), (542, 16), (577, 33), (644, 19), (691, 45), (741, 6), (852, 6), (855, 41), (862, 8), (865, 33), (868, 61), (870, 129), (872, 27), (874, 23), (885, 13), (910, 60), (914, 38), (916, 55), (920, 55), (922, 33), (944, 57), (945, 18), (946, 29), (965, 50), (966, 22), (969, 31), (970, 28), (972, 15), (973, 117), (984, 65), (985, 11), (1005, 40), (1009, 42), (1061, 23), (1075, 25), (1076, 16), (1119, 22), (1123, 70), (1126, 41), (1131, 6), (1133, 35), (1137, 32), (1139, 2), (1153, 4), (1170, 12), (1171, 53), (1174, 19), (1175, 55), (1177, 12), (1179, 55), (1182, 3), (1186, 25), (1223, 13), (1232, 4), (1237, 94), (1254, 7), (1257, 5), (1258, 15), (1261, 19), (1293, 3), (1310, 22), (1323, 8), (1485, 24), (1488, 12), (1591, 18), (1604, 1), (1605, 49), (1632, 15), (1667, 22), (1732, 14), (1780, 2), (1949, 10), (1950, 20), (2279, 61)]
def cs95510 : List ℕ := [13, 228, 107, 0, 257, 235, 0, 257, 256, 0, 207, 243, 256, 50, 256, 0, 253, 256, 91, 82, 257, 0, 28, 257, 220, 618, 257, 33, 210, 66, 256, 256, 0, 256, 74, 213, 414, 112, 222, 349, 256, 0, 97, 256, 384, 257, 256, 61, 221, 257, 222, 124, 16, 256, 256, 256, 255, 166, 193, 256, 0, 146, 239, 254, 256, 256, 256, 96, 255, 254, 195, 0, 254, 205, 230, 256, 231, 193, 463, 255, 254, 223, 255, 224, 204, 253, 202, 198, 255, 255, 254, 256, 62, 255, 234, 256, 256, 256, 256, 200, 256, 256, 245, 255, 256, 256, 255, 255, 255, 95, 255, 257, 254, 256, 256, 255, 255, 255, 256, 256, 255, 256, 239, 223, 254, 256, 257, 257, 256, 256, 208, 247, 256, 256, 256, 255, 256, 256, 256, 255, 256, 256, 206, 255, 255, 257, 225, 232, 256, 250, 256, 256, 224, 146]
theorem node95510 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 41 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95510 support demand code
    entries95510 ((insert 71 (insert 41 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node95508 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 41 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 41 (insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    71 node95509 node95510
theorem node95506 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    41 node95507 node95508
theorem node95504 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    18 node95505 node95506
theorem node95471 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 51 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    60 node95503 node95504
def entries95497 : List (Fin 2295 × ℕ) := [(4, 530), (77, 265), (179, 54), (472, 235), (475, 307), (483, 63), (507, 17), (531, 62), (542, 31), (625, 531), (632, 492), (691, 361), (692, 35), (741, 227), (743, 47), (781, 20), (784, 64), (785, 16), (842, 92), (845, 298), (851, 14), (852, 284), (860, 128), (872, 323), (873, 257), (884, 318), (885, 215), (898, 27), (915, 201), (916, 503), (918, 81), (920, 259), (922, 284), (925, 171), (944, 308), (945, 33), (960, 237), (966, 172), (970, 56), (971, 35), (972, 7), (973, 540), (984, 375), (1008, 35), (1009, 49), (1012, 21), (1043, 67), (1045, 53), (1061, 64), (1072, 70), (1073, 107), (1078, 3), (1108, 22), (1123, 120), (1127, 17), (1143, 4), (1153, 3), (1155, 154), (1170, 182), (1171, 145), (1175, 145), (1176, 37), (1177, 66), (1179, 142), (1183, 27), (1186, 167), (1198, 139), (1212, 75), (1226, 169), (1238, 168), (1244, 2), (1258, 73), (1275, 3), (1328, 13), (1399, 5), (1449, 187), (1500, 45), (1511, 33), (1534, 38), (1541, 67), (1640, 97), (1641, 23), (1646, 102), (1667, 31), (1780, 80), (1991, 7), (2225, 10)]
def cs95497 : List ℕ := [307, 861, 403, 479, 1000, 96, 33, 999, 1000, 17, 437, 508, 999, 781, 1000, 0, 999, 1000, 999, 102, 532, 139, 81, 903, 516, 2500, 953, 33, 796, 685, 999, 1593, 495, 1755, 145, 998, 1034, 859, 319, 1972, 999, 1000, 308, 1000, 2563, 690, 999, 27, 500, 999, 1000, 0, 523, 1000, 1000, 999, 999, 848, 747, 1937, 1000, 834, 523, 999, 708, 1001, 999, 812, 1000, 1000, 1706, 1001, 999, 1000, 1000, 1000, 1515, 1000, 1896, 1000, 1000, 1881, 1000, 753, 1001, 999, 1000, 999, 1001, 1000, 1000, 1000, 1001, 1000, 507, 1001, 999, 999, 1001, 1001, 1001, 999, 1000, 1002, 1001, 999, 864, 1000, 1000, 426, 1000, 999, 919, 597, 1001, 1000, 1002, 1001, 1000, 1000, 983, 1000, 959, 866, 1001, 916, 999, 1000, 1001, 1001, 814, 970, 1002, 999, 833, 999, 1000, 927, 1000, 1000, 1002, 941, 922, 1000, 871, 1000, 934, 999, 1000, 1000, 1000, 1000, 1000, 966]
theorem node95497 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95497 support demand code
    entries95497 ((insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 33 (insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries95501 : List (Fin 2295 × ℕ) := [(20, 2467), (77, 6928), (92, 450), (475, 3473), (479, 2779), (527, 752), (530, 468), (531, 243), (576, 1598), (632, 2216), (691, 3635), (731, 1884), (741, 804), (780, 1700), (781, 480), (783, 1050), (784, 2289), (806, 82), (866, 2628), (872, 1487), (873, 1395), (874, 1463), (885, 3605), (886, 421), (910, 3072), (915, 3605), (916, 5599), (920, 1580), (922, 3963), (925, 2118), (934, 232), (944, 2872), (945, 28), (960, 2560), (966, 2821), (973, 5188), (984, 4059), (1009, 405), (1011, 557), (1012, 64), (1025, 395), (1043, 1220), (1061, 133), (1073, 1024), (1076, 405), (1114, 90), (1119, 10), (1122, 43), (1123, 925), (1133, 934), (1137, 349), (1153, 1154), (1155, 2124), (1170, 2297), (1171, 1295), (1174, 281), (1175, 1621), (1179, 2166), (1212, 852), (1223, 232), (1226, 2438), (1238, 5543), (1247, 52), (1258, 358), (1261, 1160), (1273, 968), (1277, 589), (1297, 279), (1316, 281), (1327, 200), (1372, 1021), (1449, 1243), (1488, 1070), (1605, 581), (1641, 424), (1646, 127), (1777, 1447)]
def cs95501 : List ℕ := [5775, 0, 5543, 5940, 4458, 200, 0, 10001, 8442, 0, 9556, 9248, 10000, 9194, 6928, 0, 10001, 2467, 10000, 127, 10001, 200, 0, 10001, 5743, 21433, 10001, 0, 10000, 4683, 10001, 25427, 5591, 3824, 2102, 10001, 13114, 5689, 6928, 22187, 10001, 8867, 2872, 10001, 23302, 10000, 10002, 2628, 5058, 10001, 10000, 0, 2216, 10001, 10002, 9999, 10000, 6053, 7942, 19917, 16158, 8301, 6477, 9831, 10001, 10000, 10000, 9204, 10001, 10001, 19006, 10000, 10001, 5030, 8196, 21011, 14124, 8903, 25899, 10000, 10001, 20243, 10000, 7475, 8495, 10000, 10000, 10001, 10000, 8649, 10001, 10001, 10001, 10001, 5944, 10000, 10001, 10001, 9998, 10001, 10001, 10001, 10002, 9999, 10000, 9319, 9582, 6850, 10001, 4267, 10001, 10001, 10000, 9388, 9999, 10000, 10000, 10000, 10000, 10000, 9999, 9325, 9544, 9168, 10000, 9534, 9999, 9999, 9998, 10000, 7926, 9736, 10000, 10000, 8109, 10000, 10000, 10000, 10000, 10001, 10000, 10000, 9370, 9575, 9998, 9999, 7905, 8738, 10000, 8037, 9999, 8595, 9999, 10000]
theorem node95501 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 33 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 75 (insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95501 support demand code
    entries95501 ((insert 33 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 75 (insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries95502 : List (Fin 2295 × ℕ) := [(20, 24), (77, 49), (216, 10), (475, 38), (479, 35), (530, 1), (531, 5), (542, 4), (576, 13), (625, 11), (632, 26), (673, 3), (691, 36), (730, 1), (736, 2), (737, 10), (739, 14), (741, 23), (852, 3), (868, 22), (872, 29), (873, 26), (885, 38), (910, 23), (916, 55), (921, 20), (922, 33), (944, 29), (960, 27), (965, 9), (966, 27), (970, 4), (971, 2), (973, 52), (984, 40), (985, 1), (1010, 1), (1011, 3), (1061, 5), (1069, 3), (1071, 10), (1072, 5), (1073, 3), (1076, 1), (1078, 3), (1122, 8), (1123, 11), (1133, 7), (1137, 7), (1153, 10), (1155, 8), (1170, 19), (1171, 14), (1174, 1), (1175, 19), (1179, 21), (1186, 7), (1212, 10), (1223, 5), (1226, 26), (1238, 53), (1273, 4), (1275, 6), (1406, 10), (1483, 5), (1488, 6), (1591, 5), (1605, 16), (1646, 6), (1657, 3), (1659, 3), (1667, 6), (1780, 8), (1911, 4), (1912, 5), (2279, 1)]
def cs95502 : List ℕ := [61, 3, 54, 62, 46, 0, 0, 100, 85, 0, 71, 99, 99, 85, 56, 0, 100, 27, 99, 16, 100, 0, 0, 100, 54, 196, 100, 0, 83, 55, 99, 202, 38, 44, 20, 100, 113, 69, 49, 182, 100, 99, 29, 100, 192, 48, 101, 22, 63, 100, 99, 0, 35, 100, 100, 100, 100, 77, 90, 196, 0, 96, 67, 100, 100, 100, 99, 55, 99, 99, 120, 100, 92, 83, 65, 91, 154, 100, 229, 108, 100, 172, 100, 64, 100, 99, 95, 94, 100, 100, 100, 101, 100, 100, 65, 99, 100, 101, 99, 100, 101, 100, 100, 99, 99, 101, 99, 65, 101, 44, 100, 101, 100, 99, 100, 101, 99, 100, 100, 101, 100, 100, 100, 87, 99, 92, 101, 100, 100, 100, 79, 99, 100, 100, 99, 100, 99, 99, 101, 100, 97, 99, 100, 100, 96, 100, 94, 99, 100, 94, 100, 101, 100, 87]
theorem node95502 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 33 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95502 support demand code
    entries95502 ((insert 60 (insert 33 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 75 (insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95499 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 33 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 33 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 75 (insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    60 node95501 node95502
def entries95500 : List (Fin 2295 × ℕ) := [(20, 2449), (77, 4974), (179, 1208), (466, 828), (475, 2449), (479, 2151), (496, 96), (542, 1062), (625, 2495), (630, 1527), (632, 3574), (675, 1060), (691, 1467), (739, 539), (741, 2785), (743, 213), (832, 327), (833, 639), (845, 1158), (872, 3837), (873, 2770), (885, 2494), (886, 996), (898, 781), (907, 492), (908, 33), (910, 667), (915, 4546), (916, 5207), (920, 2262), (922, 3236), (925, 1114), (944, 2989), (959, 1840), (960, 1370), (966, 1469), (972, 811), (973, 4714), (984, 4886), (1009, 399), (1043, 893), (1061, 399), (1072, 645), (1077, 1397), (1078, 224), (1123, 1509), (1128, 71), (1155, 1941), (1170, 1850), (1171, 477), (1174, 719), (1175, 2187), (1182, 47), (1186, 1381), (1212, 627), (1223, 263), (1226, 768), (1238, 3919), (1297, 938), (1306, 945), (1308, 473), (1358, 341), (1406, 31), (1488, 123), (1500, 1666), (1535, 1339), (1591, 1363), (1646, 1657), (1655, 399), (1667, 1073), (1852, 736), (1887, 1735), (1912, 522), (2290, 285)]
def cs95500 : List ℕ := [5351, 1158, 3919, 4898, 3753, 945, 0, 9999, 6727, 0, 5919, 7800, 9999, 9056, 6036, 0, 9786, 3607, 10001, 3312, 8516, 0, 1989, 9999, 4864, 17780, 10001, 945, 10000, 8758, 9999, 23701, 3563, 3748, 2906, 10000, 10005, 9276, 6182, 20157, 10000, 9999, 2989, 9111, 25426, 6497, 9999, 781, 5615, 10000, 10000, 0, 6163, 9999, 10000, 10001, 9999, 10000, 7958, 16901, 6656, 7617, 5483, 10000, 8066, 9228, 10001, 9800, 10000, 10000, 14304, 10001, 10000, 9165, 7528, 2327, 17537, 9185, 20858, 10000, 10001, 16283, 10000, 7873, 10000, 6962, 8529, 10000, 10000, 10000, 10000, 9999, 10001, 10000, 7197, 10000, 10000, 10000, 10000, 8873, 10000, 9999, 10000, 9999, 10001, 9776, 10000, 9999, 10000, 2819, 9999, 9999, 10001, 7536, 10000, 10000, 9773, 10001, 9999, 10000, 10000, 10002, 9427, 8965, 10000, 7839, 9999, 10000, 10000, 10001, 6070, 9470, 10000, 10000, 10000, 10001, 8990, 8360, 10000, 10000, 10000, 8413, 8400, 10000, 10002, 9999, 8044, 8572, 9999, 10000, 9501, 8909, 8504, 9601]
theorem node95500 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 33 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95500 support demand code
    entries95500 ((insert 75 (insert 33 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node95498 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 33 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 33 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    75 node95499 node95500
theorem node95485 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 59 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    33 node95497 node95498
def entries95493 : List (Fin 2295 × ℕ) := [(4, 23), (20, 14), (77, 37), (135, 6), (409, 6), (472, 18), (483, 3), (527, 7), (531, 19), (624, 12), (632, 37), (674, 26), (677, 13), (797, 8), (798, 3), (843, 1), (845, 44), (872, 18), (873, 19), (874, 27), (885, 25), (887, 19), (907, 11), (908, 2), (909, 5), (910, 1), (919, 23), (920, 4), (921, 18), (922, 8), (923, 5), (924, 19), (925, 22), (944, 39), (946, 15), (960, 7), (965, 3), (966, 23), (973, 44), (984, 31), (990, 5), (1009, 17), (1011, 2), (1012, 18), (1073, 17), (1077, 7), (1081, 2), (1090, 8), (1108, 7), (1123, 10), (1126, 17), (1133, 2), (1143, 10), (1153, 3), (1155, 27), (1160, 1), (1171, 19), (1172, 2), (1173, 18), (1175, 16), (1177, 3), (1179, 1), (1188, 9), (1212, 9), (1226, 38), (1232, 11), (1238, 32), (1258, 3), (1266, 6), (1313, 15), (1372, 3), (1403, 9), (1459, 2), (1488, 12), (1604, 7), (1605, 16), (1641, 12), (1791, 5), (1902, 2), (2215, 25), (2225, 19), (2236, 7)]
def cs95493 : List ℕ := [47, 67, 57, 29, 38, 18, 0, 101, 84, 0, 37, 32, 101, 100, 100, 0, 91, 96, 101, 26, 101, 0, 0, 101, 60, 200, 101, 0, 100, 76, 101, 110, 51, 101, 36, 100, 154, 90, 37, 78, 97, 101, 39, 101, 173, 99, 101, 0, 78, 101, 100, 0, 68, 84, 100, 100, 100, 100, 100, 12, 101, 100, 84, 100, 96, 99, 100, 0, 101, 275, 65, 165, 101, 100, 72, 100, 205, 83, 117, 101, 100, 170, 88, 89, 100, 85, 100, 101, 99, 100, 101, 100, 101, 99, 75, 99, 84, 100, 99, 101, 100, 100, 62, 99, 95, 99, 99, 101, 100, 10, 101, 109, 100, 98, 73, 100, 100, 101, 100, 100, 100, 100, 101, 100, 101, 100, 99, 99, 99, 101, 101, 65, 100, 101, 101, 102, 100, 73, 101, 101, 101, 96, 85, 101, 92, 81, 101, 87, 100, 92, 94, 100, 62, 92]
theorem node95493 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 71 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95493 support demand code
    entries95493 ((insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 71 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries95495 : List (Fin 2295 × ℕ) := [(20, 8), (43, 59), (77, 45), (135, 46), (222, 2), (409, 34), (466, 27), (475, 42), (542, 42), (569, 82), (625, 63), (675, 49), (741, 42), (797, 72), (813, 40), (843, 14), (845, 111), (864, 8), (872, 39), (873, 86), (885, 29), (888, 44), (908, 43), (910, 15), (919, 56), (920, 3), (921, 68), (922, 5), (924, 64), (925, 45), (944, 88), (959, 85), (960, 94), (962, 2), (965, 40), (966, 20), (973, 132), (984, 65), (1004, 9), (1009, 16), (1010, 44), (1012, 8), (1045, 4), (1073, 55), (1133, 3), (1143, 51), (1155, 60), (1162, 13), (1170, 30), (1171, 50), (1172, 8), (1175, 22), (1186, 23), (1199, 65), (1212, 25), (1232, 1), (1238, 77), (1258, 10), (1266, 23), (1286, 39), (1327, 13), (1354, 4), (1370, 2), (1386, 27), (1403, 29), (1449, 18), (1482, 14), (1488, 22), (1541, 14), (1543, 20), (1556, 37), (1604, 42), (1637, 46), (1660, 7), (1705, 9), (2139, 16), (2225, 28)]
def cs95495 : List ℕ := [104, 176, 165, 50, 111, 78, 124, 257, 163, 8, 91, 146, 257, 257, 257, 46, 234, 243, 257, 86, 257, 183, 0, 257, 132, 500, 257, 0, 256, 146, 257, 314, 151, 256, 97, 207, 291, 56, 91, 174, 182, 234, 97, 256, 406, 257, 256, 0, 0, 256, 258, 0, 102, 257, 256, 257, 256, 179, 94, 8, 256, 256, 241, 256, 179, 257, 256, 0, 256, 14, 280, 604, 255, 104, 190, 256, 556, 257, 308, 255, 256, 416, 251, 255, 53, 256, 256, 255, 257, 257, 255, 214, 503, 255, 220, 190, 200, 256, 257, 255, 255, 257, 255, 256, 256, 256, 256, 191, 256, 77, 256, 275, 256, 256, 164, 248, 256, 256, 256, 257, 236, 256, 243, 256, 256, 256, 256, 256, 256, 256, 256, 256, 256, 257, 256, 256, 204, 222, 257, 257, 247, 256, 240, 257, 191, 231, 256, 218, 226, 246, 247, 257, 203, 257]
theorem node95495 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 71 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95495 support demand code
    entries95495 ((insert 69 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 71 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries95496 : List (Fin 2295 × ℕ) := [(4, 15), (43, 17), (70, 1), (135, 16), (222, 9), (420, 1), (472, 12), (475, 12), (507, 32), (542, 11), (569, 4), (625, 39), (675, 18), (741, 1), (780, 27), (798, 1), (845, 49), (868, 1), (872, 35), (873, 17), (885, 9), (886, 2), (910, 22), (915, 4), (919, 22), (921, 20), (922, 14), (924, 22), (925, 16), (930, 15), (943, 4), (944, 39), (959, 5), (960, 20), (965, 19), (973, 45), (984, 34), (1009, 5), (1010, 1), (1012, 10), (1061, 1), (1072, 10), (1073, 14), (1076, 3), (1082, 5), (1090, 6), (1095, 8), (1123, 10), (1128, 5), (1133, 1), (1137, 7), (1143, 11), (1153, 1), (1155, 22), (1171, 17), (1172, 14), (1173, 9), (1175, 30), (1179, 11), (1199, 19), (1212, 11), (1238, 39), (1249, 1), (1258, 7), (1297, 6), (1403, 37), (1447, 5), (1500, 5), (1516, 3), (1534, 6), (1616, 8), (1637, 29), (1660, 2), (1667, 7), (1668, 3), (1703, 4), (2225, 5)]
def cs95496 : List ℕ := [39, 83, 80, 12, 63, 19, 36, 100, 73, 32, 31, 51, 100, 100, 92, 29, 78, 100, 100, 0, 100, 66, 4, 100, 83, 192, 100, 0, 99, 41, 99, 144, 82, 100, 82, 39, 140, 12, 48, 69, 90, 65, 43, 100, 200, 100, 99, 16, 9, 99, 99, 0, 27, 100, 101, 100, 99, 74, 54, 14, 98, 68, 90, 99, 88, 99, 101, 4, 98, 5, 111, 143, 97, 56, 79, 100, 118, 83, 145, 99, 99, 122, 83, 98, 9, 100, 100, 100, 100, 100, 100, 90, 36, 98, 72, 93, 72, 99, 99, 99, 100, 99, 98, 98, 99, 100, 99, 84, 100, 26, 99, 101, 46, 101, 85, 95, 99, 99, 100, 101, 50, 101, 100, 100, 99, 100, 100, 100, 100, 100, 100, 100, 100, 100, 101, 100, 101, 84, 100, 100, 100, 100, 92, 99, 89, 100, 97, 84, 100, 100, 100, 101, 79, 92]
theorem node95496 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 69 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95496 support demand code
    entries95496 ((insert 92 (insert 69 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 71 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95494 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 71 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    92 node95495 node95496
theorem node95487 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 71 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    69 node95493 node95494
def entries95489 : List (Fin 2295 × ℕ) := [(4, 47), (177, 13), (179, 46), (351, 5), (472, 30), (531, 20), (542, 2), (625, 45), (632, 14), (741, 17), (781, 27), (782, 2), (845, 40), (851, 21), (859, 4), (866, 2), (872, 13), (873, 4), (874, 16), (878, 26), (884, 13), (885, 22), (888, 1), (908, 1), (920, 3), (922, 5), (925, 3), (944, 26), (945, 8), (946, 14), (960, 15), (965, 20), (966, 6), (970, 8), (973, 51), (984, 29), (1009, 9), (1012, 10), (1021, 5), (1061, 9), (1073, 9), (1077, 1), (1082, 5), (1123, 5), (1126, 4), (1127, 7), (1128, 3), (1153, 3), (1155, 16), (1169, 11), (1170, 4), (1171, 15), (1174, 8), (1175, 26), (1179, 9), (1183, 1), (1186, 16), (1212, 2), (1237, 4), (1251, 6), (1253, 2), (1258, 1), (1292, 4), (1293, 4), (1313, 4), (1403, 11), (1449, 12), (1511, 9), (1534, 2), (1616, 6), (1633, 15), (1641, 14), (1646, 17), (1667, 5), (1705, 1), (1729, 19), (1795, 2), (1845, 4), (1946, 34), (1991, 14), (2116, 16), (2215, 12), (2225, 4)]
def cs95489 : List ℕ := [6, 100, 32, 47, 89, 21, 9, 99, 100, 0, 15, 49, 101, 87, 100, 0, 96, 100, 100, 18, 101, 0, 59, 101, 49, 221, 89, 9, 58, 85, 100, 78, 37, 236, 34, 101, 141, 73, 59, 55, 97, 101, 26, 99, 177, 100, 100, 6, 98, 99, 100, 0, 49, 93, 99, 100, 99, 101, 43, 24, 96, 54, 59, 101, 99, 100, 100, 38, 99, 101, 149, 24, 100, 101, 78, 99, 130, 73, 122, 101, 100, 121, 96, 64, 92, 100, 85, 99, 101, 100, 101, 99, 89, 101, 64, 100, 100, 101, 100, 98, 101, 100, 100, 100, 100, 100, 99, 100, 98, 27, 100, 100, 99, 88, 88, 100, 100, 101, 98, 100, 100, 99, 100, 99, 100, 95, 100, 100, 100, 99, 100, 100, 99, 101, 100, 100, 100, 99, 99, 100, 101, 97, 94, 100, 88, 96, 100, 88, 101, 100, 100, 101, 88, 92]
theorem node95489 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95489 support demand code
    entries95489 ((insert 71 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 33 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries95491 : List (Fin 2295 × ℕ) := [(43, 22), (77, 46), (177, 34), (472, 12), (475, 30), (478, 5), (527, 3), (531, 3), (542, 16), (577, 16), (627, 7), (632, 5), (741, 35), (780, 6), (781, 1), (845, 12), (855, 5), (856, 4), (870, 24), (872, 43), (874, 19), (885, 6), (886, 12), (910, 26), (919, 7), (920, 16), (944, 11), (945, 39), (946, 7), (947, 14), (960, 41), (965, 14), (970, 18), (973, 47), (984, 38), (1005, 6), (1006, 15), (1009, 15), (1012, 8), (1043, 1), (1061, 1), (1073, 5), (1077, 20), (1078, 5), (1097, 2), (1098, 4), (1126, 8), (1139, 5), (1153, 8), (1155, 20), (1162, 8), (1170, 7), (1171, 6), (1174, 19), (1175, 27), (1179, 11), (1212, 23), (1237, 40), (1247, 1), (1258, 3), (1275, 2), (1293, 3), (1328, 2), (1449, 14), (1458, 7), (1482, 8), (1485, 2), (1529, 2), (1534, 2), (1641, 19), (1667, 4), (1669, 1), (1702, 10), (1795, 23), (1912, 2), (2048, 2), (2127, 13), (2215, 9), (2279, 2), (2282, 12), (2290, 8)]
def cs95491 : List ℕ := [0, 59, 37, 30, 68, 56, 22, 101, 0, 0, 53, 101, 101, 65, 93, 10, 102, 58, 100, 8, 100, 32, 44, 100, 87, 166, 101, 0, 98, 88, 101, 104, 30, 25, 56, 78, 150, 57, 90, 53, 101, 100, 17, 97, 146, 101, 88, 11, 100, 101, 100, 14, 61, 99, 100, 100, 101, 100, 63, 16, 97, 66, 55, 99, 81, 100, 100, 0, 100, 100, 164, 43, 64, 101, 90, 101, 190, 97, 159, 99, 101, 143, 93, 79, 23, 100, 93, 101, 256, 100, 100, 100, 100, 100, 47, 100, 92, 99, 100, 100, 99, 100, 100, 100, 100, 100, 100, 99, 99, 34, 100, 101, 100, 100, 101, 100, 100, 100, 100, 100, 100, 100, 100, 100, 101, 90, 100, 101, 100, 100, 102, 100, 100, 101, 91, 100, 100, 95, 101, 100, 100, 95, 88, 100, 101, 100, 100, 88, 100, 100, 100, 100, 100, 93]
theorem node95491 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 33 (insert 71 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95491 support demand code
    entries95491 ((insert 33 (insert 71 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 88 (insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries95492 : List (Fin 2295 × ℕ) := [(43, 280), (77, 265), (179, 502), (222, 101), (351, 14), (421, 16), (466, 15), (475, 203), (527, 16), (531, 113), (542, 144), (569, 38), (577, 133), (625, 166), (630, 214), (731, 265), (741, 260), (783, 88), (785, 70), (843, 100), (845, 51), (855, 112), (870, 179), (872, 297), (874, 238), (885, 152), (910, 81), (915, 7), (919, 160), (922, 130), (925, 33), (944, 233), (950, 168), (965, 275), (966, 134), (969, 43), (973, 477), (984, 387), (985, 2), (1005, 97), (1006, 67), (1009, 136), (1021, 69), (1077, 72), (1097, 17), (1098, 3), (1120, 57), (1123, 242), (1131, 8), (1133, 159), (1153, 5), (1155, 65), (1162, 75), (1170, 167), (1171, 84), (1174, 171), (1175, 185), (1179, 73), (1186, 160), (1212, 20), (1237, 603), (1241, 37), (1258, 152), (1260, 78), (1333, 54), (1403, 61), (1449, 45), (1482, 4), (1591, 40), (1604, 44), (1616, 70), (1632, 20), (1633, 43), (1641, 277), (1646, 166), (1667, 80), (1795, 186), (1845, 13), (1848, 22), (1991, 70), (2127, 10)]
def cs95492 : List ℕ := [15, 654, 230, 203, 789, 715, 280, 899, 0, 0, 265, 1000, 1000, 648, 689, 0, 1000, 510, 1001, 210, 1000, 280, 502, 948, 833, 1406, 999, 0, 657, 1000, 1000, 1199, 236, 302, 356, 912, 1458, 533, 767, 628, 999, 1000, 330, 961, 1338, 1000, 1000, 0, 933, 1000, 1000, 168, 548, 1000, 999, 1000, 1000, 1001, 431, 130, 990, 544, 726, 1000, 900, 1001, 999, 7, 1000, 1000, 1462, 33, 1000, 928, 879, 1002, 877, 899, 1433, 1001, 999, 1056, 1000, 601, 1000, 1001, 720, 1002, 550, 1000, 1000, 1000, 1000, 1000, 653, 1000, 1001, 1000, 1001, 1001, 993, 1000, 1000, 1001, 1000, 941, 1002, 783, 1000, 253, 1000, 1001, 1001, 1000, 1002, 1000, 1001, 1000, 1001, 1000, 824, 1001, 1000, 1001, 1001, 1000, 1000, 1002, 702, 1000, 1001, 1000, 1001, 1001, 1001, 1000, 917, 957, 1001, 1001, 1001, 972, 789, 1001, 1002, 907, 802, 824, 1001, 1000, 1002, 1001, 962, 829]
theorem node95492 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 33 (insert 71 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95492 support demand code
    entries95492 ((insert 88 (insert 33 (insert 71 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))))) : Finset (Fin 154)) ((insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node95490 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 33 (insert 71 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 33 (insert 71 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    88 node95491 node95492
theorem node95488 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    33 node95489 node95490
theorem node95486 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 59 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    71 node95487 node95488
theorem node95473 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 31 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    59 node95485 node95486
def entries95483 : List (Fin 2295 × ℕ) := [(4, 254), (35, 206), (77, 159), (179, 189), (344, 46), (472, 336), (475, 215), (483, 68), (484, 193), (507, 59), (542, 316), (576, 144), (625, 251), (630, 137), (632, 245), (741, 138), (780, 30), (782, 14), (784, 208), (868, 11), (870, 361), (872, 145), (873, 197), (874, 191), (884, 215), (908, 82), (910, 244), (920, 141), (922, 124), (925, 94), (944, 367), (959, 217), (960, 118), (962, 33), (965, 87), (966, 182), (970, 78), (973, 500), (984, 306), (1004, 18), (1005, 24), (1009, 39), (1011, 107), (1012, 44), (1043, 12), (1073, 86), (1075, 55), (1076, 139), (1082, 19), (1090, 63), (1123, 170), (1126, 9), (1133, 73), (1143, 15), (1155, 93), (1160, 27), (1170, 67), (1171, 255), (1172, 91), (1175, 66), (1177, 167), (1179, 93), (1183, 14), (1186, 178), (1188, 83), (1223, 195), (1228, 92), (1248, 269), (1261, 60), (1286, 30), (1292, 100), (1293, 47), (1320, 59), (1449, 70), (1488, 102), (1500, 12), (1560, 145), (1605, 88), (1657, 229), (1666, 44), (1667, 22), (1701, 42), (1705, 30), (2215, 5), (2279, 239)]
def cs95483 : List ℕ := [424, 483, 575, 215, 678, 567, 0, 999, 884, 59, 270, 1000, 1000, 739, 963, 0, 1575, 844, 1000, 0, 1000, 0, 189, 999, 802, 1802, 999, 0, 741, 782, 1000, 307, 561, 1000, 157, 999, 1336, 795, 348, 937, 999, 1001, 455, 1001, 1231, 1000, 1705, 111, 611, 1000, 1001, 0, 703, 1000, 1000, 999, 1001, 992, 678, 1000, 1000, 994, 816, 1000, 1001, 999, 1000, 14, 1000, 1000, 1159, 1000, 950, 893, 954, 1898, 1490, 921, 1374, 1001, 999, 1863, 1000, 912, 886, 1001, 999, 1001, 999, 1000, 1001, 999, 999, 999, 746, 1000, 978, 998, 1001, 1000, 1000, 1000, 998, 999, 1000, 1000, 999, 1001, 999, 449, 1000, 1001, 1000, 939, 1000, 1001, 999, 999, 1000, 999, 999, 1001, 902, 1001, 999, 952, 999, 1000, 1000, 999, 919, 891, 999, 1001, 999, 1000, 1000, 806, 999, 999, 998, 980, 903, 999, 1000, 942, 940, 1000, 1000, 999, 1000, 999, 975, 904]
theorem node95483 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 75 (insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95483 support demand code
    entries95483 ((insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 75 (insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries95484 : List (Fin 2295 × ℕ) := [(4, 52), (35, 34), (77, 46), (179, 7), (344, 1), (409, 10), (421, 17), (466, 36), (472, 52), (475, 28), (484, 6), (507, 18), (527, 18), (617, 12), (632, 9), (690, 3), (731, 28), (741, 18), (780, 9), (784, 24), (845, 12), (866, 19), (870, 36), (872, 22), (873, 3), (874, 14), (884, 9), (885, 7), (888, 6), (920, 9), (922, 7), (925, 5), (932, 26), (934, 2), (944, 35), (962, 5), (965, 16), (966, 16), (973, 50), (984, 29), (985, 3), (1005, 1), (1009, 5), (1011, 9), (1012, 9), (1072, 1), (1073, 6), (1075, 2), (1076, 12), (1082, 4), (1095, 5), (1123, 17), (1133, 6), (1137, 5), (1153, 7), (1155, 10), (1159, 3), (1160, 3), (1170, 15), (1171, 21), (1174, 2), (1175, 27), (1179, 17), (1186, 12), (1188, 29), (1212, 4), (1226, 10), (1228, 11), (1247, 1), (1248, 34), (1261, 11), (1276, 4), (1293, 2), (1372, 10), (1488, 4), (1616, 6), (1663, 2), (1666, 9), (1668, 1), (1701, 10), (1750, 2), (1780, 1), (2116, 3)]
def cs95484 : List ℕ := [36, 64, 52, 28, 52, 40, 0, 100, 86, 18, 67, 100, 100, 83, 100, 0, 110, 100, 101, 6, 67, 0, 7, 88, 70, 249, 101, 0, 48, 50, 100, 29, 57, 100, 29, 82, 71, 43, 55, 109, 80, 77, 39, 100, 112, 100, 0, 19, 74, 99, 100, 0, 9, 100, 99, 100, 100, 49, 98, 94, 100, 100, 82, 100, 100, 100, 100, 0, 99, 100, 140, 100, 100, 73, 72, 202, 140, 100, 176, 99, 85, 183, 100, 82, 83, 100, 101, 99, 100, 99, 99, 101, 100, 100, 61, 99, 99, 99, 100, 99, 99, 100, 99, 100, 97, 99, 99, 92, 99, 38, 100, 100, 100, 85, 99, 99, 99, 99, 100, 101, 100, 99, 95, 99, 100, 98, 100, 100, 100, 99, 99, 99, 100, 98, 100, 99, 100, 91, 100, 99, 100, 100, 98, 100, 95, 100, 94, 98, 100, 99, 99, 100, 98, 100]
theorem node95484 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95484 support demand code
    entries95484 ((insert 46 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 75 (insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95479 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 75 (insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    46 node95483 node95484
def entries95481 : List (Fin 2295 × ℕ) := [(4, 315), (35, 122), (77, 305), (179, 326), (409, 12), (472, 477), (475, 129), (483, 191), (625, 15), (630, 149), (675, 87), (691, 384), (739, 66), (741, 251), (845, 305), (855, 157), (870, 220), (872, 536), (873, 43), (874, 46), (884, 204), (886, 53), (888, 42), (908, 67), (910, 298), (920, 59), (922, 265), (925, 194), (931, 2), (944, 165), (949, 41), (959, 60), (960, 151), (965, 316), (966, 49), (970, 31), (973, 508), (984, 294), (1009, 127), (1043, 69), (1072, 24), (1073, 306), (1077, 36), (1078, 40), (1082, 134), (1090, 42), (1123, 89), (1128, 22), (1155, 60), (1167, 7), (1170, 53), (1171, 102), (1175, 124), (1186, 220), (1212, 147), (1223, 153), (1226, 206), (1249, 22), (1261, 131), (1272, 107), (1276, 64), (1308, 60), (1344, 51), (1354, 94), (1403, 48), (1406, 116), (1488, 92), (1497, 113), (1500, 126), (1528, 70), (1545, 11), (1591, 24), (1646, 42), (1655, 62), (1657, 65), (1701, 7), (1887, 37), (2008, 88), (2215, 315), (2225, 16)]
def cs95481 : List ℕ := [218, 685, 477, 217, 533, 470, 0, 1000, 743, 88, 305, 567, 1000, 835, 1000, 0, 1143, 1000, 999, 200, 838, 0, 326, 848, 668, 1975, 999, 0, 1000, 1000, 1000, 331, 323, 1000, 212, 1000, 1450, 750, 631, 935, 1000, 803, 165, 1001, 1455, 887, 1000, 0, 816, 1000, 999, 41, 475, 1001, 999, 999, 1000, 1000, 621, 1001, 492, 713, 444, 1000, 756, 932, 999, 18, 999, 1000, 935, 998, 999, 1000, 945, 155, 1490, 1000, 1580, 1000, 999, 1868, 999, 650, 816, 1000, 803, 1000, 998, 1000, 999, 802, 999, 1971, 508, 1000, 760, 1001, 999, 882, 1000, 1000, 1001, 999, 999, 1001, 1001, 976, 1000, 367, 1000, 1000, 1000, 1000, 813, 1000, 999, 999, 999, 999, 999, 1000, 832, 979, 999, 972, 1000, 1000, 1000, 1000, 998, 805, 999, 1000, 998, 999, 873, 682, 999, 999, 1000, 833, 793, 998, 853, 999, 913, 999, 981, 999, 908, 999, 998, 999]
theorem node95481 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95481 support demand code
    entries95481 ((insert 75 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 93 (insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries95482 : List (Fin 2295 × ℕ) := [(4, 34), (21, 3), (35, 20), (77, 20), (179, 17), (351, 5), (352, 2), (409, 11), (466, 9), (472, 44), (475, 18), (483, 23), (542, 28), (625, 15), (632, 29), (675, 2), (690, 13), (731, 5), (739, 13), (741, 29), (842, 20), (845, 22), (870, 23), (872, 43), (873, 19), (874, 17), (884, 17), (886, 3), (898, 7), (908, 18), (910, 10), (920, 17), (925, 26), (944, 22), (949, 5), (960, 18), (966, 36), (973, 48), (984, 32), (1004, 8), (1005, 8), (1043, 4), (1072, 1), (1073, 5), (1078, 13), (1081, 13), (1082, 2), (1090, 17), (1123, 10), (1125, 5), (1126, 2), (1133, 1), (1149, 5), (1153, 4), (1154, 1), (1170, 6), (1171, 13), (1174, 5), (1175, 26), (1179, 1), (1183, 15), (1186, 25), (1223, 8), (1226, 22), (1228, 3), (1488, 1), (1497, 10), (1591, 7), (1605, 12), (1646, 14), (1657, 18), (1751, 5), (1887, 13), (2120, 4), (2225, 10)]
def cs95482 : List ℕ := [35, 74, 44, 21, 60, 43, 0, 101, 80, 0, 20, 76, 101, 99, 100, 0, 122, 100, 100, 14, 85, 0, 24, 97, 67, 185, 100, 0, 63, 66, 100, 17, 44, 101, 31, 100, 112, 57, 37, 53, 82, 67, 38, 101, 142, 74, 99, 7, 70, 100, 99, 5, 57, 101, 100, 100, 98, 100, 79, 69, 51, 86, 61, 99, 102, 75, 100, 15, 99, 99, 107, 100, 99, 68, 92, 20, 174, 99, 150, 92, 98, 120, 99, 64, 99, 73, 75, 99, 100, 100, 100, 96, 100, 0, 81, 100, 100, 61, 99, 76, 101, 100, 92, 99, 100, 100, 99, 102, 101, 26, 100, 100, 99, 98, 99, 102, 101, 99, 102, 99, 95, 100, 102, 102, 99, 82, 101, 99, 100, 102, 101, 95, 101, 100, 101, 101, 101, 70, 101, 100, 100, 100, 100, 101, 100, 100, 91, 101, 100, 100, 91, 100, 97, 95]
theorem node95482 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 75 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95482 support demand code
    entries95482 ((insert 93 (insert 75 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95480 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 75 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    93 node95481 node95482
theorem node95475 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 16 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    75 node95479 node95480
def entries95477 : List (Fin 2295 × ℕ) := [(35, 60), (77, 68), (179, 28), (344, 12), (475, 102), (494, 11), (507, 84), (527, 4), (542, 77), (617, 24), (625, 74), (632, 92), (741, 33), (780, 12), (781, 17), (782, 26), (784, 53), (845, 139), (851, 42), (852, 53), (866, 17), (868, 24), (870, 117), (872, 27), (873, 8), (903, 13), (908, 4), (910, 27), (919, 8), (920, 61), (933, 22), (934, 13), (944, 97), (960, 20), (962, 11), (965, 10), (966, 28), (969, 1), (970, 23), (973, 136), (984, 72), (1004, 9), (1005, 17), (1009, 19), (1011, 22), (1043, 13), (1076, 32), (1082, 19), (1090, 29), (1122, 2), (1123, 46), (1131, 10), (1133, 20), (1137, 1), (1155, 20), (1171, 11), (1172, 35), (1173, 27), (1176, 5), (1177, 63), (1179, 57), (1183, 11), (1186, 37), (1188, 43), (1226, 33), (1247, 3), (1248, 81), (1276, 13), (1293, 9), (1364, 7), (1372, 36), (1449, 26), (1488, 13), (1560, 13), (1616, 28), (1640, 17), (1643, 9), (1646, 10), (1659, 15), (1663, 8), (1667, 26), (1701, 4), (1715, 4), (1949, 11), (2225, 7)]
def cs95477 : List ℕ := [0, 139, 0, 102, 106, 60, 0, 256, 60, 84, 109, 219, 256, 131, 145, 0, 0, 256, 257, 10, 257, 0, 28, 77, 97, 391, 256, 0, 173, 180, 256, 73, 190, 256, 75, 217, 199, 194, 96, 284, 109, 254, 139, 256, 331, 256, 257, 41, 155, 113, 256, 0, 169, 256, 255, 256, 257, 200, 255, 256, 257, 255, 256, 257, 255, 256, 256, 11, 255, 255, 340, 256, 222, 253, 188, 565, 303, 244, 280, 256, 256, 438, 257, 256, 254, 256, 256, 257, 254, 255, 255, 256, 255, 256, 196, 255, 257, 256, 256, 256, 254, 257, 255, 257, 255, 255, 257, 256, 255, 118, 256, 257, 255, 196, 256, 254, 256, 255, 256, 256, 255, 248, 254, 255, 256, 237, 255, 257, 255, 255, 225, 240, 256, 258, 256, 255, 255, 244, 257, 256, 256, 256, 222, 256, 256, 256, 216, 241, 245, 255, 257, 256, 256, 245]
theorem node95477 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 16 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95477 support demand code
    entries95477 ((insert 16 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 75 (insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries95478 : List (Fin 2295 × ℕ) := [(4, 3), (35, 11), (77, 29), (179, 20), (475, 19), (507, 2), (542, 6), (625, 11), (632, 19), (675, 26), (690, 23), (691, 3), (692, 2), (738, 1), (739, 14), (741, 18), (845, 68), (851, 8), (852, 6), (870, 30), (872, 49), (873, 29), (901, 3), (903, 18), (905, 1), (907, 2), (908, 5), (919, 20), (922, 7), (925, 19), (931, 7), (933, 13), (944, 23), (949, 2), (959, 27), (960, 17), (965, 4), (966, 25), (970, 10), (973, 50), (981, 2), (984, 14), (1005, 5), (1009, 23), (1042, 2), (1043, 12), (1045, 15), (1072, 10), (1073, 16), (1078, 2), (1082, 9), (1090, 13), (1111, 1), (1114, 7), (1123, 17), (1126, 8), (1127, 1), (1155, 1), (1175, 15), (1176, 1), (1177, 8), (1179, 1), (1183, 10), (1186, 27), (1226, 5), (1364, 4), (1403, 15), (1488, 9), (1536, 5), (1543, 3), (1605, 22), (1632, 1), (1646, 24), (1667, 14), (1848, 3), (1849, 3), (1949, 13), (2215, 26), (2225, 18), (2289, 2)]
def cs95478 : List ℕ := [0, 71, 0, 19, 30, 11, 0, 100, 14, 2, 29, 49, 100, 89, 64, 0, 0, 101, 99, 31, 100, 0, 20, 38, 23, 125, 83, 0, 78, 76, 101, 27, 40, 101, 34, 99, 96, 64, 49, 106, 57, 75, 28, 100, 170, 60, 100, 0, 73, 100, 101, 2, 51, 101, 100, 99, 100, 100, 84, 94, 65, 99, 73, 101, 99, 75, 99, 10, 100, 100, 109, 99, 101, 100, 79, 10, 167, 101, 111, 100, 100, 143, 101, 71, 97, 100, 80, 99, 100, 101, 101, 71, 99, 100, 71, 99, 99, 101, 99, 99, 100, 100, 100, 101, 99, 100, 99, 99, 99, 28, 100, 99, 100, 100, 99, 99, 99, 100, 98, 100, 99, 99, 99, 99, 99, 76, 100, 99, 99, 98, 91, 79, 99, 99, 99, 99, 86, 85, 99, 99, 99, 81, 87, 99, 99, 90, 75, 99, 100, 99, 99, 100, 78, 88]
theorem node95478 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 16 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs95478 support demand code
    entries95478 ((insert 75 (insert 16 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node95476 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 16 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 16 (insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    75 node95477 node95478
theorem node95474 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    16 node95475 node95476
theorem node95472 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    31 node95473 node95474
theorem node95470 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 34 (insert 67 (insert 27 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 81 (insert 39 (insert 70 (insert 36 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    51 node95471 node95472
#print axioms node95470
end OmissionResidualCover31Fused
