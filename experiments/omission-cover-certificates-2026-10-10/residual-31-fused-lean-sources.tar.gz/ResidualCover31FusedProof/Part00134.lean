import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries89811 : List (Fin 2295 × ℕ) := [(4, 372), (37, 65), (177, 489), (404, 37), (469, 370), (479, 171), (490, 129), (491, 284), (581, 262), (583, 554), (588, 288), (631, 148), (679, 103), (681, 240), (737, 69), (741, 446), (780, 238), (815, 45), (833, 30), (843, 61), (844, 317), (856, 149), (870, 35), (885, 138), (886, 319), (887, 168), (888, 195), (918, 200), (919, 328), (920, 215), (922, 38), (932, 61), (944, 326), (946, 372), (959, 428), (960, 165), (969, 138), (970, 151), (973, 421), (985, 110), (1006, 263), (1009, 161), (1012, 81), (1033, 24), (1034, 10), (1047, 168), (1049, 106), (1073, 89), (1094, 75), (1098, 4), (1099, 66), (1100, 47), (1108, 36), (1143, 13), (1147, 2), (1151, 48), (1153, 180), (1155, 253), (1171, 35), (1174, 228), (1175, 313), (1179, 35), (1186, 83), (1193, 275), (1212, 19), (1241, 79), (1249, 143), (1268, 96), (1275, 113), (1279, 141), (1322, 27), (1329, 40), (1419, 80), (1501, 102), (1547, 23), (1616, 31), (1623, 223), (1629, 49), (1651, 353), (1848, 27), (1850, 78), (1881, 89), (1902, 25), (1995, 13), (2225, 5)]
def cs89811 : List ℕ := [592, 883, 0, 40, 818, 788, 413, 999, 832, 353, 129, 999, 1000, 216, 647, 80, 1000, 999, 1000, 524, 1000, 909, 879, 999, 904, 1909, 1001, 2275, 0, 637, 999, 3084, 921, 999, 621, 630, 80, 1000, 999, 2153, 328, 737, 1000, 1000, 1786, 1001, 1000, 1701, 950, 1000, 1000, 999, 999, 1000, 1000, 35, 1000, 999, 999, 1000, 1705, 1001, 999, 999, 978, 938, 1001, 472, 999, 1000, 1000, 1000, 1000, 1001, 1000, 1002, 2119, 999, 96, 999, 999, 2460, 999, 1001, 955, 768, 791, 903, 3027, 998, 999, 1000, 1000, 1001, 1000, 1001, 658, 999, 1000, 1000, 1001, 1000, 736, 1000, 1001, 1000, 1000, 982, 936, 139, 1000, 1001, 1000, 999, 1001, 999, 999, 1001, 1000, 1051, 930, 999, 743, 999, 1000, 880, 1000, 1001, 1001, 999, 739, 962, 1000, 1000, 1000, 999, 997, 629, 999, 1000, 1001, 918, 698, 1000, 882, 858, 999, 702, 1000, 811, 965, 962, 908, 999]
theorem node89811 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89811 support demand code
    entries89811 ((insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 88 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries89831 : List (Fin 2295 × ℕ) := [(4, 4), (37, 32), (72, 5), (181, 14), (342, 4), (469, 49), (491, 47), (581, 44), (585, 4), (588, 2), (631, 8), (680, 22), (681, 9), (742, 13), (743, 36), (778, 13), (844, 47), (856, 3), (884, 1), (886, 47), (887, 45), (888, 16), (892, 16), (919, 3), (921, 33), (924, 43), (925, 3), (944, 47), (946, 20), (966, 2), (973, 40), (1009, 14), (1012, 1), (1014, 8), (1023, 18), (1025, 21), (1043, 24), (1073, 23), (1128, 19), (1141, 14), (1143, 6), (1154, 45), (1155, 2), (1174, 1), (1188, 10), (1193, 49), (1226, 26), (1227, 14), (1230, 13), (1234, 19), (1248, 36), (1268, 1), (1275, 5), (1285, 4), (1296, 11), (1435, 21), (1449, 2), (1459, 1), (1556, 11), (1591, 7), (1607, 22), (1629, 6), (1651, 36), (1701, 16), (1705, 8), (1848, 14), (1849, 1), (1870, 2), (1887, 15), (1903, 1), (2132, 13), (2169, 47), (2225, 9)]
def cs89831 : List ℕ := [96, 53, 0, 4, 53, 82, 47, 96, 100, 36, 11, 100, 101, 16, 58, 0, 101, 100, 101, 94, 100, 100, 16, 68, 100, 194, 101, 253, 5, 30, 101, 284, 90, 100, 1, 77, 0, 99, 101, 241, 1, 96, 100, 98, 130, 101, 100, 128, 75, 100, 101, 230, 99, 100, 101, 16, 101, 101, 99, 99, 289, 100, 100, 70, 80, 99, 101, 6, 101, 243, 238, 191, 100, 99, 80, 101, 186, 100, 3, 99, 100, 357, 99, 101, 100, 34, 100, 100, 57, 100, 99, 90, 100, 197, 100, 100, 94, 100, 99, 100, 100, 103, 39, 101, 100, 100, 100, 100, 102, 13, 100, 101, 100, 100, 54, 100, 101, 100, 100, 100, 70, 99, 101, 100, 100, 74, 101, 100, 99, 101, 79, 41, 100, 100, 100, 99, 86, 57, 100, 100, 80, 71, 79, 100, 99, 93, 64, 40, 62, 75, 89, 64, 100, 61]
theorem node89831 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 93 (insert 70 (insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89831 support demand code
    entries89831 ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 71 (insert 93 (insert 70 (insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89832 : List (Fin 2295 × ℕ) := [(4, 11), (37, 24), (72, 19), (135, 3), (137, 5), (271, 25), (469, 48), (490, 18), (491, 30), (571, 31), (581, 8), (585, 34), (588, 15), (680, 10), (736, 4), (739, 8), (741, 21), (743, 35), (780, 12), (781, 16), (833, 4), (844, 52), (884, 12), (885, 19), (886, 18), (887, 8), (888, 33), (892, 25), (898, 18), (919, 21), (922, 10), (925, 7), (944, 46), (946, 34), (971, 15), (973, 57), (981, 2), (985, 1), (1009, 6), (1023, 32), (1043, 1), (1061, 3), (1072, 14), (1073, 19), (1123, 1), (1128, 14), (1143, 6), (1154, 32), (1155, 8), (1160, 5), (1174, 14), (1175, 13), (1179, 7), (1193, 37), (1227, 14), (1234, 27), (1248, 30), (1268, 4), (1276, 4), (1285, 4), (1296, 20), (1449, 35), (1607, 19), (1651, 24), (1689, 9), (1690, 5), (1845, 14), (1846, 7), (1848, 5), (1903, 2), (2072, 2), (2169, 48), (2225, 6)]
def cs89832 : List ℕ := [89, 59, 0, 4, 48, 68, 48, 100, 96, 24, 19, 100, 100, 28, 67, 0, 101, 100, 100, 100, 100, 100, 33, 80, 98, 201, 100, 244, 19, 19, 101, 257, 89, 100, 27, 100, 0, 100, 99, 226, 40, 101, 91, 90, 137, 100, 100, 117, 66, 65, 100, 288, 100, 100, 100, 32, 101, 99, 99, 100, 238, 100, 100, 63, 73, 100, 100, 0, 101, 219, 249, 7, 101, 99, 66, 101, 167, 99, 12, 101, 99, 245, 99, 92, 99, 45, 67, 101, 61, 99, 101, 100, 101, 241, 96, 100, 100, 100, 100, 100, 101, 100, 63, 100, 101, 93, 101, 100, 101, 22, 100, 100, 100, 54, 73, 102, 99, 101, 101, 117, 55, 78, 102, 78, 100, 95, 102, 100, 100, 101, 62, 84, 100, 100, 70, 100, 85, 93, 100, 100, 101, 97, 68, 100, 84, 96, 94, 57, 85, 87, 90, 85, 100, 76]
theorem node89832 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 70 (insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89832 support demand code
    entries89832 ((insert 71 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 93 (insert 70 (insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89829 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 70 (insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 70 (insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154))
    71 node89831 node89832
def entries89830 : List (Fin 2295 × ℕ) := [(4, 8), (37, 18), (44, 1), (72, 21), (342, 13), (469, 42), (479, 14), (491, 42), (571, 8), (581, 27), (583, 19), (587, 7), (629, 1), (631, 13), (679, 11), (681, 4), (690, 1), (741, 19), (743, 27), (779, 27), (813, 3), (844, 29), (852, 9), (865, 3), (866, 1), (870, 3), (886, 38), (887, 16), (888, 21), (892, 8), (898, 2), (920, 41), (921, 41), (924, 29), (934, 5), (944, 38), (945, 8), (973, 46), (985, 26), (1009, 28), (1012, 1), (1073, 8), (1098, 5), (1122, 14), (1123, 1), (1126, 2), (1128, 2), (1143, 5), (1154, 17), (1155, 22), (1162, 4), (1174, 26), (1175, 19), (1179, 20), (1186, 8), (1188, 21), (1193, 26), (1201, 26), (1223, 3), (1263, 20), (1266, 17), (1268, 9), (1273, 2), (1275, 8), (1281, 3), (1342, 35), (1360, 2), (1417, 3), (1459, 5), (1517, 8), (1585, 7), (1629, 10), (1651, 46), (1712, 12), (1845, 3), (1863, 13), (1993, 3), (2225, 15)]
def cs89830 : List ℕ := [61, 76, 3, 3, 86, 90, 51, 100, 101, 46, 35, 101, 101, 35, 81, 0, 100, 101, 100, 72, 100, 100, 9, 100, 91, 206, 100, 229, 21, 26, 101, 295, 100, 101, 71, 100, 1, 99, 101, 202, 56, 100, 100, 101, 208, 99, 100, 141, 64, 91, 100, 184, 100, 100, 99, 34, 100, 101, 99, 100, 179, 100, 101, 94, 74, 100, 100, 18, 100, 144, 164, 99, 100, 100, 101, 100, 150, 79, 0, 100, 100, 143, 85, 99, 100, 64, 85, 100, 74, 84, 99, 99, 99, 0, 84, 100, 68, 100, 100, 100, 99, 100, 100, 100, 100, 84, 100, 101, 99, 35, 100, 100, 52, 100, 101, 73, 101, 100, 100, 99, 66, 78, 68, 101, 100, 87, 99, 99, 97, 101, 100, 91, 100, 100, 88, 96, 94, 91, 100, 99, 100, 99, 82, 78, 101, 100, 78, 56, 82, 82, 100, 91, 100, 88]
theorem node89830 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89830 support demand code
    entries89830 ((insert 93 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 70 (insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89827 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 70 (insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    93 node89829 node89830
def entries89828 : List (Fin 2295 × ℕ) := [(4, 8), (137, 3), (469, 28), (474, 1), (479, 32), (482, 16), (490, 6), (491, 14), (581, 12), (588, 4), (631, 6), (680, 18), (681, 12), (691, 9), (737, 23), (817, 10), (844, 21), (856, 41), (870, 23), (884, 9), (886, 19), (887, 8), (888, 16), (892, 21), (898, 10), (919, 20), (921, 19), (922, 25), (924, 30), (934, 10), (944, 42), (945, 8), (946, 4), (959, 2), (972, 8), (973, 43), (985, 2), (1009, 19), (1012, 17), (1072, 7), (1073, 7), (1076, 2), (1098, 14), (1108, 3), (1123, 10), (1141, 6), (1143, 5), (1154, 20), (1155, 17), (1162, 4), (1170, 9), (1171, 24), (1174, 6), (1175, 27), (1179, 2), (1186, 3), (1188, 17), (1193, 39), (1212, 10), (1227, 32), (1247, 3), (1268, 33), (1281, 19), (1308, 21), (1342, 13), (1433, 3), (1488, 4), (1493, 17), (1504, 32), (1517, 8), (1591, 6), (1651, 2), (1663, 2), (1670, 8), (1688, 3), (1690, 12), (1845, 3), (1863, 3), (1887, 10), (2225, 8)]
def cs89828 : List ℕ := [79, 36, 19, 20, 79, 59, 28, 100, 47, 2, 32, 99, 100, 33, 47, 17, 100, 99, 99, 57, 100, 100, 31, 101, 83, 175, 100, 211, 0, 9, 99, 274, 99, 101, 33, 89, 49, 100, 95, 170, 78, 100, 77, 100, 137, 100, 100, 243, 62, 100, 99, 182, 55, 100, 100, 23, 99, 101, 99, 99, 203, 100, 99, 101, 91, 58, 100, 8, 100, 189, 0, 100, 100, 99, 90, 100, 143, 80, 42, 100, 93, 162, 57, 99, 101, 59, 100, 100, 72, 93, 101, 101, 100, 99, 100, 99, 84, 99, 99, 100, 100, 101, 100, 62, 99, 93, 100, 76, 100, 23, 100, 100, 101, 96, 57, 100, 99, 100, 100, 100, 71, 100, 94, 74, 100, 100, 100, 100, 98, 99, 100, 85, 99, 100, 99, 100, 100, 71, 101, 100, 100, 100, 89, 91, 99, 99, 86, 71, 90, 95, 80, 88, 100, 81]
theorem node89828 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89828 support demand code
    entries89828 ((insert 70 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89819 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    70 node89827 node89828
def entries89825 : List (Fin 2295 × ℕ) := [(4, 17), (72, 28), (342, 33), (469, 228), (474, 57), (479, 342), (491, 14), (572, 197), (583, 342), (629, 410), (631, 201), (679, 54), (681, 570), (693, 42), (737, 167), (739, 296), (743, 207), (780, 135), (815, 54), (844, 142), (852, 197), (860, 86), (866, 174), (870, 226), (886, 259), (888, 178), (898, 93), (920, 316), (922, 458), (924, 199), (934, 278), (944, 392), (960, 431), (971, 57), (972, 57), (973, 406), (985, 162), (1009, 285), (1072, 356), (1073, 80), (1076, 73), (1098, 82), (1100, 13), (1108, 41), (1119, 18), (1141, 115), (1152, 37), (1154, 272), (1155, 188), (1170, 34), (1171, 80), (1175, 147), (1179, 158), (1193, 309), (1201, 135), (1231, 11), (1241, 90), (1248, 217), (1276, 57), (1281, 90), (1297, 33), (1308, 198), (1328, 40), (1329, 107), (1332, 33), (1403, 85), (1497, 113), (1517, 171), (1541, 4), (1560, 107), (1594, 347), (1629, 112), (1651, 518), (1655, 58), (1705, 161), (1846, 12), (2236, 6)]
def cs89825 : List ℕ := [541, 380, 90, 254, 1000, 1000, 185, 999, 1001, 518, 314, 893, 1000, 589, 489, 347, 979, 1000, 1000, 722, 736, 824, 93, 1000, 1000, 1799, 1000, 1639, 375, 611, 1000, 2940, 1000, 1000, 629, 1000, 174, 1001, 999, 2542, 817, 1001, 439, 931, 1971, 999, 1000, 2127, 0, 1000, 1000, 1821, 1000, 1000, 1000, 158, 1000, 999, 704, 2399, 1648, 739, 1000, 999, 999, 963, 999, 283, 1000, 0, 999, 999, 657, 497, 1000, 999, 1461, 1000, 114, 1000, 999, 1977, 999, 1000, 918, 761, 999, 999, 582, 1000, 1000, 967, 1916, 1000, 999, 946, 1000, 999, 999, 1000, 1001, 1000, 999, 580, 999, 1000, 999, 1000, 993, 379, 1000, 1000, 999, 604, 756, 1001, 999, 999, 1000, 1000, 914, 1000, 1000, 842, 999, 976, 1000, 1000, 999, 1000, 787, 700, 1000, 1000, 999, 1000, 633, 668, 1000, 1000, 774, 1000, 729, 893, 1000, 952, 864, 521, 760, 645, 859, 590, 1000, 785]
theorem node89825 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 59 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89825 support demand code
    entries89825 ((insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 59 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries89826 : List (Fin 2295 × ℕ) := [(37, 2), (181, 3), (342, 1), (479, 14), (491, 16), (528, 6), (583, 6), (629, 8), (631, 1), (679, 13), (681, 8), (694, 6), (741, 3), (743, 5), (833, 6), (844, 7), (852, 10), (870, 1), (873, 1), (884, 5), (886, 14), (898, 1), (920, 8), (921, 7), (922, 16), (924, 13), (925, 3), (944, 8), (971, 2), (972, 6), (973, 13), (978, 8), (1009, 6), (1011, 1), (1045, 2), (1047, 1), (1061, 2), (1073, 9), (1098, 5), (1108, 4), (1123, 3), (1141, 3), (1154, 10), (1155, 3), (1170, 2), (1171, 8), (1175, 6), (1179, 4), (1193, 5), (1241, 3), (1246, 2), (1248, 7), (1276, 4), (1305, 3), (1316, 1), (1322, 1), (1323, 1), (1329, 11), (1332, 1), (1345, 1), (1401, 1), (1403, 3), (1488, 4), (1517, 4), (1572, 3), (1591, 1), (1594, 6), (1647, 1), (1651, 12), (2208, 2)]
def cs89826 : List ℕ := [12, 0, 0, 11, 29, 21, 20, 31, 25, 12, 0, 32, 31, 25, 6, 6, 32, 25, 31, 8, 29, 12, 4, 32, 24, 49, 31, 50, 6, 9, 32, 87, 32, 32, 12, 24, 0, 33, 32, 67, 20, 32, 25, 32, 60, 33, 32, 67, 2, 32, 32, 63, 32, 32, 32, 5, 32, 32, 16, 62, 77, 2, 32, 31, 16, 32, 32, 4, 32, 2, 32, 27, 31, 24, 32, 32, 31, 32, 16, 32, 24, 45, 30, 32, 22, 29, 26, 33, 6, 31, 32, 32, 0, 32, 32, 32, 31, 31, 31, 33, 33, 32, 25, 27, 32, 31, 32, 29, 32, 13, 32, 32, 24, 25, 31, 32, 33, 31, 32, 32, 15, 24, 24, 32, 31, 29, 31, 32, 27, 32, 29, 21, 32, 32, 31, 31, 32, 24, 32, 32, 32, 32, 23, 31, 31, 33, 25, 19, 31, 25, 23, 20, 32, 23]
theorem node89826 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89826 support demand code
    entries89826 ((insert 92 (insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 59 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
theorem node89821 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 59 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    92 node89825 node89826
def entries89823 : List (Fin 2295 × ℕ) := [(4, 97), (72, 8), (137, 5), (179, 111), (342, 5), (469, 67), (490, 57), (514, 5), (572, 108), (579, 7), (583, 179), (587, 8), (588, 111), (629, 65), (679, 61), (741, 57), (779, 33), (780, 12), (781, 36), (797, 2), (844, 67), (885, 65), (888, 81), (898, 4), (919, 129), (921, 21), (924, 6), (925, 14), (944, 124), (952, 10), (960, 82), (972, 7), (973, 100), (978, 70), (985, 7), (1006, 11), (1009, 64), (1012, 35), (1023, 5), (1047, 10), (1072, 22), (1076, 3), (1100, 53), (1108, 2), (1122, 9), (1123, 18), (1128, 8), (1147, 2), (1153, 8), (1155, 79), (1162, 24), (1170, 49), (1171, 21), (1174, 36), (1175, 65), (1179, 8), (1186, 5), (1193, 22), (1212, 36), (1232, 4), (1252, 5), (1281, 122), (1320, 3), (1329, 10), (1344, 22), (1403, 55), (1435, 26), (1459, 16), (1497, 6), (1539, 3), (1560, 14), (1594, 67), (1596, 3), (1629, 3), (1651, 57), (1670, 6), (1791, 46), (1887, 24), (1902, 3), (2148, 3), (2225, 42)]
def cs89823 : List ℕ := [211, 164, 125, 132, 122, 124, 57, 256, 196, 57, 19, 256, 256, 80, 130, 70, 257, 256, 256, 256, 257, 256, 234, 256, 256, 414, 256, 507, 78, 179, 257, 662, 256, 256, 171, 189, 0, 256, 256, 474, 113, 145, 256, 256, 385, 256, 189, 325, 117, 150, 257, 342, 257, 257, 257, 8, 256, 256, 197, 0, 352, 256, 257, 256, 189, 256, 257, 3, 257, 6, 255, 256, 256, 148, 257, 256, 384, 257, 70, 256, 256, 339, 239, 257, 243, 177, 257, 256, 189, 257, 255, 234, 483, 79, 255, 220, 257, 256, 254, 255, 256, 256, 223, 184, 257, 256, 255, 207, 257, 72, 256, 256, 111, 253, 256, 257, 256, 256, 255, 256, 196, 256, 239, 257, 256, 256, 256, 255, 256, 256, 228, 256, 255, 254, 257, 255, 222, 233, 255, 255, 256, 235, 239, 255, 255, 221, 255, 192, 225, 214, 240, 256, 238, 230]
theorem node89823 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89823 support demand code
    entries89823 ((insert 59 (insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries89824 : List (Fin 2295 × ℕ) := [(4, 23), (135, 1), (137, 3), (179, 19), (342, 13), (469, 36), (490, 15), (491, 24), (573, 23), (574, 1), (583, 24), (588, 13), (629, 28), (631, 11), (679, 32), (740, 9), (778, 23), (780, 20), (833, 14), (844, 39), (847, 4), (870, 7), (885, 7), (886, 36), (888, 15), (919, 27), (921, 37), (924, 37), (944, 21), (951, 5), (965, 1), (971, 13), (972, 5), (973, 47), (985, 3), (1009, 23), (1023, 16), (1043, 8), (1047, 4), (1068, 1), (1072, 12), (1073, 5), (1100, 12), (1108, 13), (1123, 4), (1152, 3), (1153, 6), (1155, 35), (1161, 4), (1170, 7), (1174, 14), (1175, 23), (1179, 22), (1193, 31), (1211, 3), (1212, 11), (1246, 8), (1258, 12), (1275, 2), (1322, 13), (1329, 18), (1332, 12), (1345, 17), (1396, 6), (1403, 12), (1447, 2), (1497, 7), (1528, 2), (1594, 11), (1596, 12), (1629, 10), (1630, 18), (1651, 25), (1660, 2), (2169, 9)]
def cs89824 : List ℕ := [70, 59, 16, 18, 66, 53, 39, 79, 100, 25, 22, 100, 99, 58, 66, 23, 99, 100, 100, 50, 100, 47, 32, 93, 96, 187, 99, 179, 23, 58, 99, 217, 100, 100, 64, 16, 0, 101, 100, 197, 3, 100, 71, 99, 160, 101, 42, 170, 45, 100, 99, 158, 101, 101, 99, 22, 100, 100, 101, 9, 237, 26, 99, 99, 80, 101, 100, 10, 99, 26, 100, 97, 100, 99, 100, 100, 115, 100, 8, 99, 73, 101, 97, 100, 100, 100, 101, 100, 37, 99, 99, 81, 15, 95, 100, 100, 100, 99, 100, 99, 99, 101, 85, 97, 101, 99, 101, 99, 99, 54, 100, 100, 57, 72, 78, 89, 100, 99, 100, 101, 32, 79, 71, 100, 99, 100, 101, 101, 54, 100, 99, 98, 101, 100, 101, 99, 94, 87, 100, 100, 99, 101, 68, 94, 100, 101, 100, 78, 100, 72, 89, 90, 101, 95]
theorem node89824 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 59 (insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89824 support demand code
    entries89824 ((insert 92 (insert 59 (insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89822 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 59 (insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    92 node89823 node89824
theorem node89820 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    59 node89821 node89822
theorem node89813 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 51 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    69 node89819 node89820
def entries89815 : List (Fin 2295 × ℕ) := [(4, 467), (179, 258), (469, 532), (471, 195), (474, 137), (491, 195), (530, 191), (531, 479), (576, 42), (583, 799), (587, 214), (588, 232), (727, 18), (730, 4), (736, 263), (741, 80), (743, 282), (780, 113), (832, 44), (853, 138), (856, 452), (872, 57), (873, 70), (874, 176), (885, 112), (886, 233), (888, 287), (892, 80), (898, 30), (919, 279), (920, 54), (922, 458), (924, 29), (925, 164), (934, 166), (944, 360), (971, 155), (972, 91), (973, 448), (1009, 145), (1023, 226), (1061, 34), (1072, 70), (1073, 299), (1090, 10), (1098, 61), (1123, 116), (1128, 19), (1143, 214), (1155, 366), (1170, 62), (1171, 75), (1174, 181), (1175, 3), (1179, 67), (1186, 28), (1193, 397), (1226, 254), (1247, 44), (1258, 45), (1269, 69), (1281, 137), (1308, 44), (1344, 77), (1403, 10), (1459, 93), (1528, 19), (1539, 79), (1585, 58), (1591, 91), (1629, 324), (1655, 44), (1667, 98), (1767, 137), (1845, 144), (1848, 31), (2225, 111), (2292, 6)]
def cs89815 : List ℕ := [671, 999, 469, 411, 864, 590, 195, 1001, 864, 0, 324, 1001, 1001, 973, 864, 0, 1001, 1001, 2249, 287, 914, 879, 734, 1001, 1001, 2397, 1000, 2674, 0, 264, 1001, 3319, 963, 1001, 459, 999, 0, 1001, 258, 2561, 166, 1000, 1001, 894, 1836, 1000, 1000, 952, 522, 999, 1001, 0, 1000, 1001, 1000, 450, 1001, 1001, 1001, 999, 1500, 934, 1001, 799, 829, 1001, 1000, 324, 1000, 999, 868, 1001, 930, 478, 755, 1001, 1487, 1001, 137, 999, 569, 2488, 1000, 1001, 1000, 797, 1002, 1002, 438, 1000, 999, 948, 1000, 1000, 1001, 1001, 997, 1001, 1000, 999, 1000, 1000, 619, 1001, 1001, 1001, 1001, 863, 1000, 341, 1000, 1000, 767, 734, 1001, 1000, 1000, 1000, 1001, 1001, 897, 1001, 847, 938, 1000, 1000, 1000, 1000, 1000, 1000, 758, 694, 1000, 999, 1000, 1000, 726, 876, 1000, 999, 1000, 891, 782, 999, 999, 908, 917, 592, 656, 893, 986, 693, 657, 842]
theorem node89815 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89815 support demand code
    entries89815 ((insert 51 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 18 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries89817 : List (Fin 2295 × ℕ) := [(4, 13), (179, 20), (479, 43), (491, 15), (542, 15), (576, 6), (581, 23), (583, 55), (587, 36), (588, 12), (620, 9), (730, 16), (736, 14), (741, 10), (743, 20), (815, 5), (833, 2), (844, 43), (852, 15), (856, 57), (870, 6), (886, 30), (887, 3), (888, 39), (892, 22), (919, 32), (920, 1), (921, 17), (922, 21), (924, 19), (925, 3), (933, 7), (944, 37), (971, 16), (973, 48), (985, 8), (1009, 31), (1023, 7), (1033, 1), (1072, 3), (1073, 25), (1098, 2), (1100, 8), (1114, 1), (1123, 24), (1143, 8), (1155, 23), (1174, 23), (1175, 6), (1186, 18), (1193, 30), (1212, 6), (1226, 21), (1247, 4), (1258, 10), (1275, 4), (1308, 1), (1403, 20), (1459, 29), (1497, 5), (1508, 4), (1517, 9), (1528, 4), (1629, 13), (1655, 9), (1669, 2), (1848, 5), (1849, 7), (2225, 8), (2292, 15)]
def cs89817 : List ℕ := [73, 13, 0, 0, 101, 57, 24, 101, 43, 0, 13, 30, 100, 0, 58, 0, 43, 101, 0, 42, 101, 100, 68, 101, 0, 194, 99, 146, 0, 35, 101, 192, 92, 101, 29, 100, 0, 100, 20, 99, 50, 60, 100, 101, 168, 99, 188, 120, 72, 100, 100, 0, 100, 99, 100, 22, 99, 100, 100, 101, 170, 75, 100, 70, 67, 100, 99, 22, 100, 100, 86, 99, 99, 88, 100, 100, 142, 100, 0, 101, 91, 200, 100, 100, 100, 58, 100, 100, 50, 100, 99, 87, 99, 84, 99, 100, 99, 100, 100, 99, 101, 109, 36, 95, 100, 99, 100, 82, 99, 40, 100, 99, 58, 86, 94, 100, 99, 100, 100, 105, 93, 100, 72, 99, 100, 100, 100, 101, 100, 99, 89, 82, 100, 101, 99, 99, 81, 65, 100, 100, 100, 94, 76, 100, 100, 79, 87, 76, 77, 100, 95, 92, 82, 101]
theorem node89817 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89817 support demand code
    entries89817 ((insert 18 (insert 51 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89818 : List (Fin 2295 × ℕ) := [(179, 39), (342, 20), (491, 57), (512, 32), (587, 47), (588, 3), (737, 37), (739, 20), (741, 12), (743, 12), (844, 72), (856, 112), (886, 112), (887, 67), (888, 67), (898, 17), (919, 6), (920, 81), (921, 64), (922, 76), (924, 87), (925, 1), (934, 18), (944, 94), (959, 3), (960, 53), (966, 10), (972, 5), (973, 106), (985, 54), (1006, 27), (1009, 70), (1012, 1), (1023, 26), (1072, 5), (1073, 78), (1123, 25), (1141, 9), (1143, 57), (1155, 98), (1162, 23), (1174, 51), (1175, 17), (1186, 2), (1193, 93), (1204, 91), (1212, 27), (1226, 28), (1248, 18), (1258, 35), (1281, 72), (1322, 14), (1384, 50), (1403, 105), (1406, 11), (1488, 7), (1528, 8), (1547, 7), (1682, 36), (1683, 14), (1848, 24), (1849, 13), (1870, 10), (1887, 19), (2225, 20), (2236, 21), (2292, 50)]
def cs89818 : List ℕ := [237, 91, 163, 163, 184, 112, 57, 144, 184, 0, 32, 129, 256, 91, 184, 0, 216, 256, 72, 145, 233, 91, 142, 256, 72, 534, 257, 161, 0, 139, 256, 390, 206, 256, 159, 145, 0, 256, 39, 324, 18, 132, 257, 256, 456, 257, 0, 329, 228, 257, 256, 0, 177, 256, 257, 0, 257, 150, 256, 257, 357, 245, 256, 30, 213, 230, 257, 0, 256, 256, 256, 257, 257, 256, 209, 256, 399, 255, 10, 256, 256, 413, 256, 256, 256, 133, 200, 256, 152, 256, 256, 254, 258, 256, 256, 256, 237, 256, 257, 256, 256, 269, 120, 255, 256, 255, 257, 257, 255, 34, 256, 256, 192, 202, 172, 256, 256, 256, 256, 276, 157, 257, 223, 251, 256, 239, 255, 257, 257, 255, 229, 174, 256, 256, 255, 256, 182, 149, 256, 256, 256, 256, 200, 255, 255, 243, 208, 135, 205, 195, 225, 209, 212, 233]
theorem node89818 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 18 (insert 51 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89818 support demand code
    entries89818 ((insert 46 (insert 18 (insert 51 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node89816 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 51 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 51 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    46 node89817 node89818
theorem node89814 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    18 node89815 node89816
theorem node89812 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    51 node89813 node89814
theorem node89787 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 27 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    88 node89811 node89812
def entries89799 : List (Fin 2295 × ℕ) := [(72, 29), (86, 9), (137, 3), (177, 22), (342, 5), (479, 22), (542, 42), (588, 26), (631, 3), (679, 35), (681, 10), (741, 7), (780, 47), (797, 20), (815, 8), (843, 13), (844, 50), (852, 16), (856, 9), (874, 12), (884, 1), (885, 22), (886, 27), (888, 3), (908, 11), (917, 6), (918, 30), (919, 37), (920, 10), (921, 3), (932, 9), (944, 28), (945, 36), (948, 16), (959, 10), (960, 44), (969, 11), (970, 15), (973, 44), (981, 7), (984, 4), (985, 3), (1006, 1), (1009, 22), (1033, 12), (1034, 2), (1047, 8), (1049, 4), (1072, 1), (1073, 15), (1098, 2), (1099, 14), (1108, 14), (1126, 5), (1128, 12), (1148, 2), (1153, 2), (1154, 24), (1155, 10), (1170, 4), (1171, 6), (1174, 19), (1175, 31), (1179, 10), (1193, 24), (1211, 7), (1228, 6), (1241, 5), (1251, 2), (1268, 47), (1276, 5), (1332, 9), (1501, 30), (1522, 41), (1616, 7), (1668, 6), (1881, 5), (2169, 12), (2225, 14)]
def cs89799 : List ℕ := [74, 0, 0, 0, 62, 50, 0, 88, 24, 0, 29, 9, 100, 100, 95, 0, 94, 83, 100, 50, 101, 0, 78, 100, 7, 182, 100, 0, 40, 25, 100, 217, 97, 100, 50, 100, 11, 100, 101, 127, 81, 100, 89, 101, 198, 100, 100, 206, 63, 90, 100, 198, 59, 100, 99, 22, 100, 101, 100, 99, 283, 101, 75, 100, 63, 54, 100, 36, 99, 100, 101, 101, 100, 100, 99, 100, 197, 97, 36, 99, 100, 226, 98, 100, 79, 64, 84, 100, 291, 100, 99, 101, 101, 100, 100, 100, 72, 100, 100, 99, 100, 100, 98, 101, 100, 100, 100, 92, 74, 17, 101, 100, 87, 100, 101, 99, 101, 100, 100, 112, 87, 100, 76, 100, 100, 79, 100, 101, 100, 100, 97, 100, 101, 100, 100, 100, 100, 82, 100, 100, 100, 98, 86, 100, 98, 100, 95, 75, 100, 81, 88, 83, 100, 77]
theorem node89799 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89799 support demand code
    entries89799 ((insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 88 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89809 : List (Fin 2295 × ℕ) := [(72, 11), (179, 15), (342, 1), (479, 32), (506, 21), (540, 21), (576, 5), (587, 28), (678, 4), (679, 32), (680, 3), (681, 30), (694, 8), (736, 5), (737, 13), (739, 1), (741, 7), (742, 5), (743, 1), (780, 10), (844, 40), (852, 6), (885, 10), (886, 28), (898, 34), (907, 14), (920, 42), (921, 9), (922, 17), (924, 3), (934, 17), (944, 37), (945, 3), (949, 33), (960, 24), (972, 16), (973, 44), (984, 4), (985, 18), (1009, 26), (1025, 5), (1043, 10), (1071, 1), (1072, 2), (1073, 24), (1100, 5), (1108, 10), (1122, 3), (1143, 16), (1154, 20), (1155, 20), (1171, 7), (1174, 17), (1175, 5), (1178, 14), (1179, 13), (1186, 1), (1188, 8), (1193, 25), (1212, 5), (1223, 21), (1226, 23), (1248, 22), (1258, 4), (1266, 7), (1268, 40), (1269, 8), (1322, 4), (1323, 2), (1328, 5), (1403, 25), (1522, 38), (1556, 2), (1670, 5), (1701, 16), (1715, 10), (1731, 3), (1846, 4), (2225, 16)]
def cs89809 : List ℕ := [86, 0, 0, 0, 84, 38, 0, 99, 46, 21, 11, 21, 99, 78, 57, 0, 97, 65, 99, 40, 87, 0, 77, 99, 21, 143, 99, 0, 25, 15, 99, 194, 100, 99, 22, 99, 14, 100, 100, 116, 97, 99, 76, 99, 159, 100, 99, 235, 54, 100, 99, 238, 1, 99, 100, 27, 100, 100, 101, 203, 214, 100, 82, 75, 100, 99, 100, 0, 100, 100, 180, 100, 86, 101, 100, 101, 161, 99, 40, 100, 101, 268, 100, 100, 101, 68, 81, 100, 85, 94, 100, 99, 100, 99, 100, 101, 87, 99, 204, 100, 99, 99, 79, 100, 101, 99, 100, 100, 100, 49, 99, 100, 98, 81, 100, 99, 100, 100, 100, 100, 76, 100, 99, 100, 100, 77, 100, 100, 100, 100, 86, 66, 100, 100, 100, 99, 92, 91, 100, 100, 99, 100, 73, 100, 100, 100, 99, 65, 87, 76, 86, 87, 100, 75]
theorem node89809 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 70 (insert 98 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89809 support demand code
    entries89809 ((insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 59 (insert 70 (insert 98 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89810 : List (Fin 2295 × ℕ) := [(4, 5), (72, 6), (135, 4), (137, 8), (179, 34), (468, 4), (498, 8), (542, 38), (587, 29), (588, 24), (629, 4), (679, 45), (681, 9), (740, 7), (778, 5), (779, 19), (780, 34), (798, 1), (844, 58), (852, 3), (885, 15), (886, 23), (888, 6), (898, 13), (919, 35), (921, 32), (924, 17), (944, 35), (945, 8), (949, 23), (950, 15), (951, 18), (959, 3), (960, 21), (972, 11), (973, 43), (985, 9), (1009, 24), (1012, 7), (1021, 9), (1023, 25), (1072, 7), (1073, 15), (1076, 3), (1098, 8), (1099, 3), (1100, 6), (1108, 4), (1122, 3), (1126, 10), (1128, 1), (1141, 5), (1143, 12), (1154, 14), (1155, 24), (1161, 3), (1174, 17), (1175, 17), (1178, 4), (1179, 18), (1188, 22), (1193, 33), (1212, 16), (1258, 10), (1268, 54), (1322, 7), (1403, 31), (1522, 30), (1528, 5), (1556, 4), (1604, 10), (2132, 1), (2225, 8), (2286, 16)]
def cs89810 : List ℕ := [91, 25, 10, 0, 41, 30, 0, 91, 46, 0, 6, 20, 100, 100, 82, 0, 94, 96, 100, 70, 100, 16, 100, 100, 26, 161, 100, 16, 16, 38, 100, 171, 100, 99, 34, 97, 10, 100, 94, 98, 72, 100, 88, 100, 144, 99, 67, 208, 64, 100, 100, 216, 46, 100, 78, 38, 99, 100, 100, 3, 278, 100, 82, 100, 73, 100, 100, 0, 101, 100, 165, 100, 100, 100, 100, 101, 164, 83, 38, 102, 100, 239, 77, 100, 100, 80, 95, 100, 88, 100, 100, 92, 101, 66, 100, 99, 98, 100, 192, 102, 100, 100, 72, 101, 99, 100, 100, 96, 100, 49, 100, 101, 79, 74, 101, 99, 102, 100, 101, 99, 55, 100, 81, 102, 100, 101, 99, 100, 100, 101, 98, 77, 101, 100, 101, 100, 82, 76, 101, 100, 100, 100, 78, 101, 101, 100, 89, 73, 96, 82, 85, 95, 101, 83]
theorem node89810 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 98 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89810 support demand code
    entries89810 ((insert 59 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 70 (insert 98 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89807 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 98 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 70 (insert 98 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    59 node89809 node89810
def entries89808 : List (Fin 2295 × ℕ) := [(72, 26), (137, 8), (179, 12), (342, 3), (479, 31), (542, 43), (587, 26), (629, 5), (631, 2), (679, 14), (681, 4), (727, 11), (736, 8), (737, 8), (797, 28), (844, 47), (852, 15), (869, 3), (870, 11), (874, 6), (884, 4), (885, 12), (886, 23), (888, 6), (898, 14), (908, 10), (919, 37), (921, 12), (922, 27), (924, 20), (934, 8), (944, 36), (946, 2), (960, 9), (972, 28), (973, 46), (984, 15), (1009, 21), (1033, 4), (1034, 2), (1047, 9), (1061, 6), (1069, 2), (1072, 2), (1076, 17), (1097, 2), (1098, 12), (1122, 11), (1128, 10), (1141, 5), (1152, 9), (1154, 6), (1155, 26), (1170, 12), (1171, 9), (1174, 13), (1175, 27), (1178, 2), (1179, 26), (1188, 10), (1193, 18), (1212, 1), (1226, 14), (1247, 3), (1248, 3), (1252, 8), (1268, 40), (1308, 20), (1323, 5), (1342, 3), (1522, 53), (1572, 3), (1630, 9), (1664, 4), (1670, 14), (1690, 1)]
def cs89808 : List ℕ := [65, 0, 0, 0, 64, 53, 0, 93, 18, 0, 26, 14, 100, 99, 87, 0, 100, 79, 99, 46, 90, 0, 52, 100, 0, 174, 99, 0, 36, 19, 100, 200, 99, 101, 40, 98, 10, 100, 83, 105, 87, 100, 65, 101, 158, 100, 99, 196, 65, 100, 99, 172, 53, 101, 100, 34, 98, 99, 100, 100, 180, 100, 100, 99, 77, 65, 100, 3, 100, 99, 3, 99, 100, 99, 101, 77, 141, 100, 25, 100, 98, 151, 84, 99, 100, 88, 90, 79, 89, 101, 101, 91, 99, 96, 100, 101, 80, 99, 162, 101, 101, 100, 88, 83, 100, 101, 99, 60, 100, 57, 100, 100, 100, 73, 95, 101, 102, 100, 100, 101, 100, 100, 94, 102, 100, 92, 99, 100, 101, 96, 100, 98, 101, 100, 90, 100, 100, 101, 100, 101, 101, 101, 96, 99, 101, 101, 77, 62, 95, 100, 81, 90, 101, 87]
theorem node89808 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89808 support demand code
    entries89808 ((insert 70 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 98 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89801 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 98 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    70 node89807 node89808
def entries89805 : List (Fin 2295 × ℕ) := [(72, 48), (342, 17), (409, 21), (479, 48), (485, 12), (506, 59), (529, 55), (540, 86), (542, 44), (587, 50), (588, 75), (630, 57), (679, 31), (681, 63), (739, 5), (741, 31), (781, 4), (844, 97), (852, 31), (856, 103), (874, 61), (884, 16), (885, 62), (886, 61), (888, 24), (898, 30), (908, 18), (919, 35), (920, 86), (921, 5), (924, 37), (925, 2), (934, 17), (944, 114), (973, 111), (984, 25), (1009, 65), (1014, 25), (1016, 4), (1033, 19), (1072, 12), (1073, 34), (1076, 17), (1100, 40), (1108, 34), (1139, 10), (1141, 16), (1154, 67), (1155, 58), (1170, 9), (1171, 40), (1174, 16), (1175, 80), (1193, 55), (1229, 20), (1234, 27), (1255, 2), (1268, 37), (1275, 17), (1313, 23), (1333, 29), (1342, 74), (1344, 18), (1388, 20), (1403, 80), (1433, 19), (1449, 5), (1459, 7), (1522, 21), (1543, 14), (1560, 27), (1594, 13), (1701, 61), (1791, 19), (1848, 26), (1849, 15), (1887, 31), (2132, 27), (2169, 7), (2236, 11)]
def cs89805 : List ℕ := [175, 0, 2, 23, 159, 192, 0, 176, 111, 59, 48, 0, 256, 189, 256, 13, 192, 175, 256, 94, 256, 15, 155, 256, 79, 574, 256, 0, 99, 57, 256, 370, 256, 257, 131, 256, 18, 256, 256, 276, 122, 256, 256, 257, 462, 256, 256, 601, 101, 220, 256, 562, 118, 257, 257, 84, 253, 485, 256, 255, 522, 205, 256, 256, 227, 257, 257, 0, 256, 256, 457, 254, 257, 256, 257, 256, 343, 256, 87, 256, 256, 451, 257, 255, 256, 159, 255, 257, 96, 256, 257, 210, 255, 255, 256, 257, 257, 255, 67, 256, 255, 256, 254, 255, 257, 257, 256, 257, 254, 47, 256, 256, 207, 256, 126, 256, 255, 256, 257, 284, 183, 244, 248, 256, 256, 241, 256, 256, 232, 256, 243, 230, 256, 256, 255, 256, 249, 145, 256, 256, 256, 257, 198, 255, 256, 256, 229, 154, 226, 185, 184, 227, 256, 206]
theorem node89805 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 70 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89805 support demand code
    entries89805 ((insert 98 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 57 (insert 70 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries89806 : List (Fin 2295 × ℕ) := [(37, 20), (72, 60), (137, 13), (342, 16), (409, 3), (466, 8), (479, 30), (506, 13), (587, 16), (588, 24), (631, 19), (731, 26), (741, 9), (780, 7), (781, 20), (783, 11), (844, 50), (874, 5), (883, 2), (884, 2), (885, 7), (886, 21), (888, 3), (907, 4), (908, 5), (919, 29), (921, 33), (924, 14), (934, 8), (944, 43), (973, 44), (1009, 24), (1023, 6), (1025, 20), (1045, 1), (1073, 29), (1100, 8), (1128, 6), (1141, 9), (1154, 29), (1155, 12), (1174, 8), (1175, 9), (1193, 32), (1201, 8), (1223, 10), (1229, 9), (1248, 8), (1268, 50), (1271, 1), (1275, 16), (1297, 6), (1398, 5), (1403, 36), (1435, 5), (1459, 24), (1497, 17), (1522, 32), (1543, 5), (1546, 13), (1594, 6), (1646, 2), (1690, 12), (1701, 8), (1791, 7), (1849, 15), (1887, 18), (2132, 2), (2169, 24), (2225, 1), (2236, 5)]
def cs89806 : List ℕ := [100, 8, 0, 0, 80, 66, 0, 98, 76, 13, 60, 18, 100, 101, 100, 6, 95, 90, 100, 81, 68, 14, 40, 101, 13, 221, 100, 0, 75, 19, 100, 220, 99, 100, 31, 100, 9, 91, 98, 124, 101, 101, 99, 99, 164, 100, 49, 166, 40, 101, 100, 230, 35, 99, 75, 5, 77, 12, 99, 101, 286, 100, 100, 41, 73, 100, 100, 2, 100, 99, 170, 101, 101, 72, 99, 101, 93, 100, 2, 101, 48, 213, 99, 100, 99, 58, 100, 100, 17, 100, 101, 76, 101, 101, 100, 98, 89, 100, 14, 102, 100, 100, 83, 101, 99, 99, 100, 101, 100, 9, 100, 100, 43, 99, 68, 100, 100, 100, 100, 128, 66, 79, 89, 100, 100, 96, 99, 100, 100, 99, 73, 83, 100, 100, 91, 94, 81, 46, 99, 100, 88, 90, 75, 100, 85, 100, 75, 44, 83, 73, 76, 76, 100, 87]
theorem node89806 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 98 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89806 support demand code
    entries89806 ((insert 57 (insert 98 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 70 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89803 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 98 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 70 (insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    57 node89805 node89806
def entries89804 : List (Fin 2295 × ℕ) := [(72, 15), (342, 10), (466, 11), (479, 38), (542, 13), (587, 8), (588, 22), (631, 5), (679, 21), (681, 10), (736, 11), (797, 30), (844, 33), (856, 3), (866, 36), (870, 14), (874, 5), (883, 5), (884, 7), (885, 11), (886, 13), (888, 2), (898, 12), (908, 10), (919, 39), (921, 6), (922, 21), (924, 6), (925, 11), (934, 14), (944, 41), (961, 5), (973, 38), (984, 5), (985, 2), (1009, 26), (1012, 10), (1033, 13), (1072, 3), (1073, 16), (1076, 17), (1108, 8), (1128, 2), (1141, 13), (1143, 6), (1154, 39), (1155, 11), (1170, 7), (1171, 22), (1173, 5), (1175, 33), (1193, 31), (1223, 7), (1226, 1), (1229, 11), (1234, 10), (1246, 36), (1268, 48), (1269, 1), (1308, 15), (1344, 4), (1433, 10), (1501, 7), (1522, 47), (1701, 9), (1845, 7), (1848, 14), (1849, 2), (1887, 9), (1902, 2), (1991, 7)]
def cs89804 : List ℕ := [82, 0, 0, 0, 76, 50, 0, 89, 38, 0, 51, 32, 101, 100, 59, 0, 101, 78, 100, 50, 100, 0, 49, 100, 0, 190, 100, 0, 25, 5, 101, 208, 101, 100, 38, 100, 46, 101, 92, 105, 100, 100, 88, 100, 151, 100, 68, 275, 47, 99, 101, 187, 28, 100, 100, 5, 101, 100, 101, 100, 217, 100, 101, 100, 89, 46, 100, 5, 101, 100, 0, 74, 100, 86, 100, 95, 84, 101, 41, 100, 100, 129, 43, 101, 101, 60, 100, 100, 41, 100, 100, 100, 61, 100, 100, 73, 100, 100, 19, 100, 99, 100, 100, 73, 100, 98, 100, 70, 100, 16, 99, 100, 98, 100, 54, 99, 100, 101, 99, 99, 27, 95, 97, 79, 101, 98, 99, 100, 92, 99, 100, 78, 100, 100, 99, 101, 98, 52, 99, 100, 100, 100, 90, 79, 100, 96, 84, 53, 94, 82, 71, 77, 100, 60]
theorem node89804 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 98 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89804 support demand code
    entries89804 ((insert 70 (insert 98 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89802 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 98 (insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    70 node89803 node89804
theorem node89800 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    98 node89801 node89802
theorem node89789 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 51 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    88 node89799 node89800
def entries89791 : List (Fin 2295 × ℕ) := [(177, 19), (479, 3), (484, 11), (531, 11), (542, 12), (588, 10), (631, 8), (632, 1), (737, 1), (741, 9), (743, 2), (780, 2), (814, 3), (815, 1), (833, 3), (843, 6), (844, 9), (852, 5), (856, 12), (870, 1), (871, 2), (874, 2), (885, 9), (886, 12), (887, 5), (888, 6), (897, 1), (917, 7), (918, 14), (919, 10), (920, 8), (922, 2), (928, 8), (944, 8), (946, 11), (959, 16), (960, 3), (969, 6), (970, 7), (973, 15), (981, 1), (985, 6), (1009, 10), (1033, 4), (1073, 9), (1098, 1), (1099, 7), (1107, 1), (1108, 9), (1154, 10), (1174, 8), (1175, 8), (1193, 6), (1204, 11), (1211, 4), (1212, 2), (1228, 1), (1275, 5), (1332, 11), (1528, 1), (1619, 1), (2138, 1), (2225, 1)]
def cs89791 : List ℕ := [15, 11, 11, 11, 25, 23, 0, 17, 17, 1, 0, 1, 32, 26, 29, 0, 32, 27, 27, 11, 32, 11, 30, 32, 2, 65, 26, 0, 0, 28, 31, 66, 22, 31, 27, 32, 0, 31, 27, 52, 3, 31, 18, 32, 87, 32, 31, 41, 31, 31, 32, 0, 21, 32, 32, 4, 32, 32, 31, 33, 50, 31, 18, 12, 24, 28, 33, 21, 32, 31, 32, 31, 31, 32, 32, 33, 69, 31, 8, 33, 26, 82, 31, 32, 19, 21, 30, 33, 109, 31, 32, 32, 31, 32, 32, 33, 31, 32, 31, 31, 33, 32, 25, 31, 32, 32, 32, 32, 25, 6, 32, 32, 31, 33, 24, 32, 31, 33, 32, 40, 32, 32, 20, 26, 32, 25, 32, 32, 32, 32, 31, 31, 33, 32, 33, 32, 32, 16, 31, 32, 33, 31, 26, 32, 29, 32, 30, 27, 30, 26, 28, 30, 32, 23]
theorem node89791 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89791 support demand code
    entries89791 ((insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 88 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
def entries89797 : List (Fin 2295 × ℕ) := [(4, 234), (342, 946), (479, 843), (484, 627), (531, 5508), (542, 5189), (576, 652), (587, 3311), (588, 2004), (616, 416), (630, 1314), (632, 2109), (780, 3061), (783, 718), (832, 1999), (844, 3865), (852, 1993), (856, 5508), (871, 2846), (874, 514), (883, 1431), (884, 139), (885, 1908), (886, 2657), (887, 21), (888, 705), (898, 193), (919, 3465), (920, 612), (921, 853), (922, 2684), (924, 3553), (934, 2885), (944, 3739), (972, 512), (973, 4082), (985, 1847), (1009, 3045), (1023, 852), (1069, 367), (1070, 12), (1072, 1301), (1073, 1989), (1098, 592), (1100, 1553), (1108, 1256), (1123, 504), (1141, 153), (1143, 1768), (1154, 4597), (1161, 301), (1171, 174), (1174, 1565), (1175, 1805), (1179, 747), (1186, 203), (1188, 2828), (1193, 2602), (1204, 1132), (1212, 4), (1226, 1160), (1228, 270), (1241, 543), (1248, 691), (1275, 915), (1332, 294), (1403, 2481), (1435, 1102), (1449, 98), (1481, 441), (1546, 291), (1572, 260), (1619, 505), (1663, 566), (1845, 547), (1887, 367), (2001, 709), (2225, 1494)]
def cs89797 : List ℕ := [6467, 1366, 1132, 1132, 6804, 6135, 0, 6701, 3968, 505, 0, 0, 10000, 10000, 9157, 0, 6762, 7833, 10000, 726, 10000, 1132, 5508, 10000, 505, 21497, 10001, 0, 0, 3864, 10000, 15097, 10000, 10000, 4502, 10000, 0, 9999, 0, 11935, 3728, 9999, 10000, 10000, 20514, 10001, 8971, 13862, 4493, 9999, 10000, 0, 9999, 9999, 10000, 4107, 10001, 9999, 10001, 9999, 24423, 10001, 10000, 6135, 6659, 6776, 10001, 1431, 10000, 14816, 10000, 10001, 10000, 10000, 10000, 19650, 14216, 10000, 313, 9999, 5198, 21556, 9999, 10000, 10000, 6969, 10001, 10000, 7863, 9999, 10000, 9074, 10001, 9999, 10001, 10000, 9808, 10001, 10002, 10000, 9999, 9999, 6802, 10000, 10001, 10001, 10001, 7273, 10000, 1466, 10000, 10000, 7699, 7373, 8907, 9999, 10001, 10001, 10000, 11818, 5005, 10001, 10000, 10000, 10001, 8719, 10000, 10000, 10001, 10001, 9331, 7452, 10000, 10000, 10001, 9711, 8253, 7737, 10000, 10000, 10001, 9518, 6985, 10000, 9890, 10000, 8738, 5815, 7005, 6181, 9106, 9787, 10000, 6017]
theorem node89797 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 69 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89797 support demand code
    entries89797 ((insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 75 (insert 69 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries89798 : List (Fin 2295 × ℕ) := [(181, 11), (466, 37), (479, 5), (531, 93), (542, 93), (587, 53), (630, 37), (632, 97), (639, 5), (731, 79), (737, 63), (739, 31), (741, 18), (776, 2), (815, 39), (844, 126), (855, 4), (856, 89), (884, 4), (886, 84), (887, 90), (888, 68), (898, 25), (919, 50), (920, 52), (921, 20), (922, 96), (924, 108), (925, 19), (944, 118), (946, 2), (970, 12), (971, 5), (973, 116), (978, 9), (1009, 84), (1023, 19), (1033, 1), (1072, 15), (1073, 42), (1081, 1), (1099, 3), (1100, 24), (1123, 61), (1128, 17), (1143, 12), (1152, 6), (1154, 79), (1171, 9), (1174, 16), (1175, 54), (1186, 34), (1188, 26), (1193, 93), (1204, 28), (1226, 19), (1247, 26), (1275, 13), (1276, 11), (1403, 107), (1528, 18), (1619, 9), (1655, 1), (1683, 29), (1701, 4), (1848, 33), (1849, 8), (1870, 13), (1993, 13), (2001, 20), (2225, 24)]
def cs89798 : List ℕ := [256, 28, 28, 28, 126, 93, 0, 168, 121, 9, 0, 37, 256, 121, 214, 0, 125, 256, 106, 158, 256, 28, 89, 256, 9, 437, 256, 0, 0, 163, 256, 348, 189, 256, 98, 256, 0, 256, 0, 222, 5, 256, 171, 256, 404, 256, 98, 207, 164, 256, 256, 0, 256, 256, 256, 4, 256, 256, 255, 256, 354, 255, 225, 93, 227, 232, 256, 0, 255, 483, 182, 255, 256, 255, 227, 98, 372, 257, 14, 256, 234, 501, 257, 255, 255, 126, 217, 196, 138, 256, 255, 219, 255, 256, 256, 256, 255, 256, 255, 255, 255, 302, 106, 256, 255, 256, 256, 255, 255, 39, 256, 255, 81, 255, 158, 255, 255, 248, 255, 263, 191, 255, 230, 255, 255, 242, 255, 256, 255, 254, 254, 186, 254, 256, 255, 255, 226, 141, 255, 255, 254, 239, 207, 255, 255, 232, 191, 176, 189, 218, 247, 255, 240, 174]
theorem node89798 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89798 support demand code
    entries89798 ((insert 75 (insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 69 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node89793 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    75 node89797 node89798
def entries89795 : List (Fin 2295 × ℕ) := [(179, 28), (342, 17), (479, 27), (484, 10), (507, 10), (542, 47), (569, 21), (587, 38), (588, 17), (631, 36), (727, 12), (729, 9), (742, 6), (780, 35), (797, 9), (814, 3), (833, 11), (844, 47), (852, 26), (856, 43), (871, 21), (883, 11), (885, 14), (886, 28), (888, 26), (919, 38), (921, 14), (922, 27), (924, 16), (925, 5), (933, 2), (934, 19), (944, 28), (959, 1), (960, 38), (965, 2), (972, 3), (973, 47), (978, 21), (985, 16), (1009, 32), (1045, 3), (1068, 3), (1072, 14), (1073, 24), (1108, 5), (1114, 3), (1123, 3), (1128, 2), (1143, 17), (1154, 33), (1155, 9), (1171, 1), (1174, 17), (1175, 9), (1178, 3), (1186, 3), (1204, 26), (1212, 5), (1275, 6), (1277, 3), (1322, 5), (1344, 3), (1403, 38), (1417, 5), (1433, 10), (1497, 3), (1663, 11), (1848, 12), (1902, 7), (2225, 10)]
def cs89795 : List ℕ := [47, 26, 26, 26, 79, 53, 0, 100, 26, 10, 0, 0, 100, 47, 73, 0, 63, 94, 62, 26, 94, 26, 83, 100, 10, 186, 100, 0, 0, 64, 100, 132, 96, 100, 52, 100, 0, 101, 28, 104, 48, 46, 100, 99, 210, 100, 100, 186, 28, 101, 100, 0, 100, 100, 100, 29, 100, 99, 101, 101, 186, 49, 100, 66, 46, 100, 99, 11, 100, 0, 100, 100, 101, 55, 99, 190, 137, 100, 3, 101, 57, 163, 101, 99, 101, 82, 88, 100, 65, 101, 101, 84, 100, 98, 100, 92, 74, 100, 100, 101, 101, 100, 60, 87, 99, 100, 99, 70, 100, 19, 100, 99, 34, 66, 88, 101, 101, 100, 100, 111, 55, 83, 88, 101, 99, 94, 100, 99, 100, 99, 100, 76, 100, 100, 100, 99, 74, 82, 100, 100, 100, 99, 74, 100, 99, 88, 75, 60, 79, 85, 91, 95, 100, 73]
theorem node89795 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89795 support demand code
    entries89795 ((insert 69 (insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 75 (insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89796 : List (Fin 2295 × ℕ) := [(179, 52), (181, 9), (342, 2), (479, 9), (484, 35), (507, 19), (530, 16), (542, 53), (577, 4), (587, 29), (588, 10), (631, 16), (690, 7), (737, 11), (741, 17), (743, 3), (797, 8), (814, 9), (844, 43), (852, 19), (856, 22), (872, 30), (884, 3), (885, 13), (886, 42), (888, 42), (919, 22), (920, 2), (921, 12), (922, 41), (924, 7), (930, 6), (934, 11), (944, 34), (971, 16), (972, 4), (973, 42), (978, 19), (1009, 35), (1023, 5), (1033, 3), (1045, 1), (1073, 34), (1081, 4), (1100, 8), (1108, 4), (1123, 9), (1128, 12), (1141, 4), (1154, 34), (1174, 9), (1175, 14), (1186, 2), (1193, 16), (1204, 21), (1212, 8), (1247, 14), (1276, 1), (1308, 23), (1320, 7), (1344, 1), (1403, 26), (1655, 18), (1701, 1), (1791, 3), (1848, 20), (1887, 1), (1991, 13)]
def cs89796 : List ℕ := [59, 21, 21, 21, 65, 57, 0, 71, 37, 19, 0, 0, 100, 67, 90, 0, 93, 99, 100, 42, 100, 21, 100, 99, 19, 160, 99, 0, 0, 68, 101, 124, 100, 99, 44, 100, 0, 99, 58, 98, 20, 67, 75, 100, 206, 90, 85, 92, 52, 102, 101, 0, 71, 100, 100, 30, 101, 93, 99, 101, 96, 38, 81, 55, 40, 100, 100, 0, 101, 0, 85, 100, 101, 31, 100, 22, 112, 100, 13, 101, 48, 124, 100, 100, 100, 89, 100, 78, 23, 99, 101, 80, 100, 100, 100, 77, 101, 100, 101, 101, 101, 112, 49, 87, 100, 100, 100, 100, 100, 30, 100, 100, 72, 79, 85, 100, 98, 100, 100, 100, 60, 100, 77, 99, 99, 100, 99, 100, 99, 98, 90, 65, 99, 100, 99, 99, 65, 61, 99, 100, 98, 89, 70, 98, 99, 91, 67, 70, 85, 91, 86, 69, 95, 53]
theorem node89796 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 69 (insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89796 support demand code
    entries89796 ((insert 75 (insert 69 (insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89794 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    75 node89795 node89796
theorem node89792 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    69 node89793 node89794
theorem node89790 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    88 node89791 node89792
theorem node89788 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    51 node89789 node89790
theorem node89713 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    27 node89787 node89788
def entries89783 : List (Fin 2295 × ℕ) := [(179, 270), (289, 301), (506, 459), (527, 331), (540, 83), (542, 571), (576, 25), (587, 352), (588, 122), (617, 194), (629, 147), (630, 92), (681, 144), (741, 332), (778, 3), (779, 405), (780, 116), (781, 30), (783, 354), (785, 65), (815, 30), (844, 321), (846, 26), (852, 306), (856, 347), (874, 169), (883, 82), (884, 130), (885, 426), (886, 26), (890, 105), (892, 522), (898, 163), (919, 81), (920, 33), (921, 27), (924, 68), (933, 479), (934, 49), (944, 287), (951, 29), (957, 66), (959, 229), (960, 586), (962, 15), (971, 247), (973, 539), (978, 67), (981, 51), (985, 81), (1006, 133), (1009, 302), (1011, 152), (1043, 93), (1069, 77), (1072, 47), (1073, 123), (1089, 31), (1090, 61), (1122, 153), (1123, 138), (1154, 61), (1155, 78), (1171, 26), (1174, 140), (1186, 261), (1189, 347), (1226, 45), (1234, 48), (1248, 118), (1258, 78), (1275, 61), (1276, 61), (1403, 93), (1447, 90), (1482, 1), (1585, 15), (1589, 191), (1681, 75), (1818, 46), (2225, 261), (2292, 2)]
def cs89783 : List ℕ := [321, 373, 347, 0, 653, 347, 0, 1000, 347, 459, 0, 0, 999, 169, 1001, 0, 664, 761, 1001, 0, 1000, 627, 907, 1001, 510, 1786, 1000, 1000, 0, 633, 1000, 156, 1001, 1000, 513, 1000, 0, 1000, 1000, 1206, 528, 446, 761, 999, 2073, 1000, 1612, 2397, 440, 858, 1001, 1000, 1000, 1000, 1000, 796, 1000, 2015, 1000, 1000, 2578, 1000, 1001, 1000, 534, 1000, 999, 148, 1000, 1000, 2418, 1000, 746, 999, 1000, 2414, 2177, 1000, 347, 1001, 1000, 2856, 967, 1000, 1000, 999, 686, 999, 1000, 1001, 999, 890, 2494, 1001, 1001, 1001, 840, 1001, 2090, 999, 1000, 1000, 999, 1000, 1001, 705, 1000, 862, 964, 523, 1000, 999, 999, 741, 1000, 1001, 1000, 1000, 1000, 1001, 1000, 999, 1000, 997, 1000, 1000, 1001, 1000, 1000, 1000, 1000, 679, 1000, 1000, 890, 766, 875, 800, 1000, 1000, 1000, 752, 831, 1000, 999, 662, 705, 861, 831, 966, 999, 861, 1000, 1000]
theorem node89783 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 92 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89783 support demand code
    entries89783 ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 98 (insert 92 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries89785 : List (Fin 2295 × ℕ) := [(177, 30), (289, 24), (475, 10), (506, 45), (527, 33), (540, 8), (542, 53), (576, 22), (588, 28), (617, 11), (629, 22), (630, 1), (631, 1), (679, 6), (681, 7), (741, 2), (743, 4), (779, 8), (780, 37), (781, 28), (782, 3), (783, 37), (784, 8), (785, 5), (815, 2), (844, 16), (852, 45), (856, 41), (874, 9), (883, 25), (885, 30), (886, 29), (892, 48), (896, 16), (897, 8), (920, 30), (933, 23), (944, 23), (957, 7), (960, 60), (969, 3), (970, 22), (973, 55), (978, 16), (981, 23), (1006, 11), (1009, 12), (1012, 3), (1049, 9), (1069, 10), (1070, 1), (1073, 8), (1089, 14), (1090, 1), (1103, 24), (1108, 1), (1154, 21), (1155, 6), (1174, 24), (1175, 8), (1176, 3), (1186, 13), (1189, 36), (1193, 2), (1212, 4), (1248, 2), (1258, 6), (1275, 19), (1403, 9), (1489, 23), (1501, 15), (1642, 2), (1850, 5), (1877, 10), (1887, 1), (1889, 24), (2225, 15), (2291, 2), (2292, 14)]
def cs89785 : List ℕ := [18, 36, 38, 10, 83, 41, 0, 99, 38, 45, 0, 10, 100, 9, 99, 0, 86, 70, 100, 0, 99, 64, 83, 99, 70, 179, 99, 100, 0, 70, 100, 30, 100, 99, 68, 100, 2, 101, 100, 146, 25, 58, 68, 100, 228, 100, 194, 246, 56, 77, 100, 99, 100, 100, 100, 60, 101, 203, 100, 100, 328, 100, 99, 99, 45, 99, 100, 48, 99, 100, 288, 101, 82, 100, 100, 287, 219, 76, 23, 99, 99, 236, 99, 100, 100, 101, 62, 99, 270, 99, 99, 99, 224, 100, 90, 101, 40, 101, 60, 99, 100, 100, 99, 99, 101, 101, 99, 86, 99, 17, 100, 99, 100, 100, 83, 99, 94, 99, 100, 123, 100, 100, 99, 100, 99, 78, 100, 100, 101, 100, 100, 90, 100, 100, 100, 99, 100, 70, 99, 100, 99, 93, 88, 99, 85, 96, 86, 74, 73, 99, 93, 99, 100, 97]
theorem node89785 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 92 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89785 support demand code
    entries89785 ((insert 98 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 88 (insert 92 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89786 : List (Fin 2295 × ℕ) := [(92, 2), (289, 18), (506, 49), (527, 47), (540, 74), (542, 65), (576, 117), (588, 74), (629, 40), (631, 42), (679, 93), (681, 40), (741, 54), (781, 23), (782, 8), (783, 59), (784, 78), (814, 25), (815, 14), (846, 30), (849, 6), (852, 109), (856, 203), (874, 52), (883, 60), (884, 85), (885, 110), (888, 4), (892, 103), (920, 19), (923, 25), (924, 3), (933, 85), (944, 82), (962, 97), (966, 58), (973, 140), (978, 10), (981, 30), (1006, 15), (1009, 40), (1012, 24), (1025, 15), (1043, 34), (1055, 2), (1072, 32), (1073, 57), (1075, 40), (1076, 44), (1089, 63), (1108, 6), (1141, 20), (1154, 26), (1155, 27), (1159, 27), (1171, 30), (1174, 3), (1175, 9), (1186, 63), (1189, 117), (1248, 41), (1261, 15), (1403, 3), (1449, 17), (1459, 14), (1488, 45), (1556, 62), (1572, 7), (1588, 16), (1681, 76), (2291, 24)]
def cs89786 : List ℕ := [0, 147, 117, 6, 226, 203, 0, 256, 117, 49, 0, 0, 256, 54, 256, 0, 255, 163, 256, 4, 256, 103, 98, 256, 79, 605, 256, 256, 0, 182, 255, 19, 175, 256, 165, 214, 0, 256, 151, 413, 85, 256, 180, 219, 490, 255, 470, 659, 100, 200, 255, 256, 247, 256, 257, 155, 255, 554, 256, 256, 697, 197, 255, 256, 91, 255, 255, 62, 255, 255, 616, 256, 255, 233, 257, 730, 375, 254, 173, 255, 255, 652, 186, 255, 256, 256, 256, 255, 37, 255, 255, 204, 349, 255, 256, 256, 212, 257, 3, 255, 257, 255, 256, 256, 209, 256, 256, 236, 249, 160, 255, 255, 256, 157, 199, 257, 255, 256, 256, 256, 256, 218, 257, 255, 256, 225, 258, 255, 125, 257, 256, 152, 256, 256, 256, 254, 238, 182, 256, 256, 212, 257, 247, 256, 159, 206, 173, 209, 194, 256, 140, 212, 256, 230]
theorem node89786 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 98 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89786 support demand code
    entries89786 ((insert 88 (insert 98 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node89784 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 98 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    88 node89785 node89786
theorem node89779 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 92 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    98 node89783 node89784
def entries89781 : List (Fin 2295 × ℕ) := [(181, 140), (307, 168), (506, 464), (514, 126), (527, 344), (540, 713), (576, 41), (587, 20), (588, 250), (629, 37), (632, 89), (679, 545), (681, 172), (741, 126), (778, 42), (780, 120), (782, 134), (784, 120), (833, 27), (844, 120), (846, 127), (852, 534), (856, 468), (872, 115), (874, 7), (883, 143), (884, 235), (885, 328), (886, 106), (892, 529), (898, 61), (920, 132), (921, 191), (924, 81), (944, 334), (945, 92), (951, 235), (959, 163), (960, 258), (969, 72), (970, 43), (971, 21), (973, 497), (978, 218), (981, 126), (985, 82), (1009, 168), (1011, 39), (1012, 39), (1073, 159), (1076, 82), (1089, 47), (1090, 70), (1108, 36), (1123, 158), (1143, 19), (1154, 126), (1155, 75), (1171, 127), (1175, 171), (1176, 47), (1177, 9), (1183, 29), (1186, 233), (1189, 219), (1234, 145), (1235, 68), (1248, 98), (1305, 180), (1316, 68), (1320, 69), (1322, 19), (1342, 46), (1403, 69), (1501, 116), (1572, 149), (1705, 69), (1712, 92), (1765, 68), (1887, 8), (1998, 68), (2001, 71), (2225, 167)]
def cs89781 : List ℕ := [120, 346, 219, 68, 753, 468, 0, 1000, 287, 532, 126, 68, 1000, 122, 932, 0, 938, 684, 1000, 0, 1000, 529, 587, 1000, 658, 1828, 1000, 1001, 0, 218, 1000, 323, 999, 1000, 517, 1000, 0, 999, 1000, 1364, 168, 999, 846, 1000, 2193, 1000, 1817, 2624, 283, 894, 999, 2480, 344, 1001, 1000, 707, 999, 2302, 999, 1000, 2593, 612, 1000, 1000, 448, 1000, 1001, 172, 1001, 1000, 2705, 949, 1000, 1000, 1000, 2039, 1654, 1000, 391, 1001, 1000, 2149, 734, 1000, 999, 1000, 683, 1000, 1000, 1001, 1001, 1001, 421, 1001, 999, 1001, 758, 1001, 1000, 1001, 1001, 1000, 1000, 999, 741, 1000, 1000, 1000, 938, 322, 1000, 1000, 1000, 620, 1000, 1001, 1001, 1001, 1000, 1001, 531, 1001, 774, 1001, 1002, 792, 1000, 1001, 1001, 1001, 1002, 724, 1000, 1001, 1001, 1002, 1000, 664, 1000, 1001, 1002, 899, 822, 1001, 1002, 984, 788, 836, 775, 904, 989, 1000, 1001, 834]
theorem node89781 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89781 support demand code
    entries89781 ((insert 92 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 51 (insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries89782 : List (Fin 2295 × ℕ) := [(92, 7), (179, 9), (475, 4), (527, 27), (542, 57), (576, 31), (587, 5), (588, 37), (727, 37), (729, 18), (741, 8), (780, 21), (782, 20), (784, 27), (833, 1), (835, 3), (846, 7), (852, 54), (856, 70), (871, 14), (872, 1), (873, 16), (874, 12), (883, 24), (884, 16), (885, 30), (886, 18), (892, 42), (920, 25), (921, 7), (924, 16), (930, 3), (933, 14), (944, 24), (946, 3), (959, 23), (960, 23), (966, 7), (969, 19), (970, 3), (973, 54), (978, 21), (981, 24), (1009, 14), (1073, 21), (1089, 7), (1090, 3), (1122, 3), (1123, 15), (1154, 8), (1155, 6), (1171, 7), (1174, 1), (1175, 18), (1176, 6), (1186, 28), (1189, 39), (1258, 4), (1261, 9), (1320, 6), (1403, 7), (1482, 4), (1488, 4), (1517, 12), (1572, 14), (1616, 5), (1680, 23), (1683, 1), (1903, 4), (2225, 24), (2293, 15)]
def cs89782 : List ℕ := [0, 46, 39, 4, 93, 70, 12, 100, 39, 0, 0, 16, 101, 50, 96, 0, 88, 79, 100, 0, 100, 42, 74, 96, 24, 204, 100, 100, 0, 52, 100, 32, 97, 100, 65, 101, 0, 101, 12, 168, 14, 59, 89, 86, 257, 101, 191, 223, 51, 79, 101, 0, 100, 100, 101, 91, 101, 217, 100, 100, 226, 85, 101, 64, 26, 100, 101, 36, 100, 100, 167, 85, 89, 75, 101, 292, 165, 100, 33, 100, 100, 197, 100, 100, 89, 100, 62, 99, 101, 100, 99, 99, 46, 100, 101, 100, 45, 100, 101, 100, 101, 99, 84, 100, 67, 74, 100, 84, 97, 28, 99, 99, 100, 87, 81, 101, 100, 100, 99, 100, 70, 100, 78, 100, 101, 75, 101, 99, 93, 101, 99, 79, 100, 99, 100, 101, 100, 78, 101, 99, 101, 86, 85, 101, 100, 93, 68, 85, 93, 100, 99, 100, 100, 97]
theorem node89782 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 92 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89782 support demand code
    entries89782 ((insert 51 (insert 92 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89780 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    51 node89781 node89782
theorem node89775 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 70 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    92 node89779 node89780
def entries89777 : List (Fin 2295 × ℕ) := [(177, 18), (485, 25), (506, 14), (542, 62), (577, 17), (588, 8), (617, 14), (631, 3), (679, 6), (681, 6), (729, 8), (736, 21), (844, 5), (846, 5), (847, 36), (852, 38), (856, 24), (860, 23), (870, 26), (874, 6), (883, 19), (885, 1), (886, 32), (892, 27), (897, 9), (919, 24), (928, 20), (931, 6), (933, 12), (944, 24), (945, 5), (958, 8), (959, 31), (960, 52), (969, 3), (970, 14), (973, 48), (978, 26), (981, 5), (985, 12), (1006, 8), (1009, 3), (1012, 9), (1047, 4), (1049, 13), (1069, 9), (1073, 13), (1090, 7), (1103, 4), (1108, 1), (1123, 9), (1153, 17), (1155, 15), (1167, 5), (1170, 9), (1171, 4), (1175, 9), (1176, 17), (1177, 9), (1189, 16), (1212, 17), (1228, 2), (1247, 3), (1249, 8), (1261, 3), (1270, 21), (1275, 5), (1276, 6), (1293, 9), (1384, 8), (1497, 1), (1501, 14), (1517, 16), (1572, 5), (1670, 3), (1683, 6), (1766, 23), (1843, 18), (1852, 11), (1869, 8), (1881, 5), (2225, 10)]
def cs89777 : List ℕ := [5, 21, 52, 0, 54, 72, 16, 100, 62, 37, 0, 42, 100, 6, 78, 0, 100, 99, 100, 0, 100, 27, 49, 101, 42, 158, 100, 100, 0, 48, 99, 24, 100, 100, 66, 81, 0, 100, 76, 148, 18, 69, 46, 87, 192, 100, 167, 221, 63, 100, 99, 100, 100, 100, 101, 64, 100, 180, 100, 100, 161, 100, 99, 100, 70, 67, 100, 48, 100, 99, 0, 100, 85, 100, 100, 166, 195, 98, 39, 98, 99, 158, 92, 101, 92, 87, 71, 100, 256, 98, 101, 100, 100, 100, 101, 100, 57, 100, 100, 101, 100, 99, 100, 100, 93, 96, 86, 68, 67, 17, 99, 101, 101, 100, 66, 100, 100, 100, 101, 100, 100, 100, 73, 99, 101, 78, 101, 100, 99, 100, 99, 98, 100, 99, 99, 101, 101, 76, 99, 100, 100, 87, 99, 100, 99, 83, 96, 100, 99, 89, 99, 88, 99, 96]
theorem node89777 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89777 support demand code
    entries89777 ((insert 70 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 88 (insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89778 : List (Fin 2295 × ℕ) := [(344, 299), (409, 892), (506, 2019), (542, 4897), (577, 2164), (587, 1462), (617, 252), (629, 773), (631, 1792), (679, 296), (738, 24), (797, 307), (815, 331), (844, 461), (846, 1798), (852, 4436), (856, 4851), (860, 732), (870, 416), (883, 751), (884, 2317), (885, 2314), (886, 1263), (892, 3497), (919, 1321), (924, 2242), (933, 2818), (934, 881), (944, 2990), (958, 842), (960, 318), (962, 423), (972, 934), (973, 4893), (978, 1175), (985, 2565), (1006, 329), (1009, 1842), (1011, 769), (1012, 24), (1073, 1973), (1075, 1045), (1076, 374), (1090, 644), (1122, 991), (1123, 1025), (1154, 573), (1155, 872), (1167, 1445), (1171, 700), (1175, 433), (1176, 261), (1177, 1215), (1179, 281), (1186, 1372), (1189, 2226), (1212, 1646), (1234, 1438), (1261, 729), (1273, 770), (1293, 243), (1308, 162), (1338, 1109), (1342, 2241), (1344, 1646), (1417, 357), (1433, 1144), (1477, 530), (1488, 465), (1497, 82), (1517, 1400), (1572, 1432), (1670, 448), (1681, 1696), (1690, 150), (1705, 392), (1766, 2877), (1770, 1079), (1791, 59), (1887, 431), (1983, 2335), (2001, 25), (2225, 656)]
def cs89778 : List ℕ := [1540, 5103, 2226, 0, 6662, 8807, 1400, 10000, 5835, 4896, 0, 1816, 10000, 0, 7123, 0, 9522, 10000, 9999, 0, 10001, 3497, 1462, 10000, 4896, 18527, 9999, 10000, 0, 4261, 10001, 1321, 10000, 10000, 5536, 5420, 0, 10000, 7438, 11305, 3699, 8538, 4751, 10000, 18809, 10000, 15726, 24052, 5973, 9733, 10000, 9999, 10000, 9998, 10000, 7056, 9999, 17339, 10000, 10000, 16890, 10000, 9999, 10000, 5165, 5609, 10000, 4438, 10001, 10000, 0, 10000, 9299, 9034, 9999, 13851, 12948, 9997, 3017, 10000, 10000, 14097, 9999, 10000, 9999, 7944, 9304, 9999, 2675, 9999, 10001, 9426, 10000, 9998, 9999, 10000, 8637, 10000, 10000, 10000, 10000, 9999, 10000, 9999, 9695, 7800, 10000, 8060, 9999, 5783, 9999, 10000, 9999, 7151, 7031, 9999, 9999, 9999, 10001, 10000, 10000, 10001, 10000, 9998, 10000, 9291, 10001, 10000, 10000, 10001, 9999, 8329, 10001, 10000, 9999, 7634, 8934, 8677, 10001, 10000, 9955, 8845, 9014, 10001, 10000, 10000, 7892, 10000, 10000, 8872, 9250, 10000, 10001, 10001]
theorem node89778 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 70 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89778 support demand code
    entries89778 ((insert 88 (insert 70 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node89776 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 70 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    88 node89777 node89778
theorem node89769 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    70 node89775 node89776
def entries89773 : List (Fin 2295 × ℕ) := [(4, 4371), (490, 2468), (491, 60), (498, 4486), (506, 6358), (514, 2735), (527, 777), (629, 2258), (631, 788), (679, 788), (681, 3949), (694, 64), (741, 2404), (742, 442), (743, 691), (780, 156), (784, 1548), (815, 967), (844, 2735), (856, 2002), (866, 2002), (874, 3097), (884, 2751), (885, 2821), (886, 1694), (887, 1640), (898, 1691), (920, 2336), (921, 122), (924, 1174), (933, 1455), (934, 1663), (944, 4385), (959, 2637), (960, 2100), (970, 1691), (973, 4350), (978, 1751), (981, 314), (985, 875), (1006, 1512), (1009, 705), (1011, 987), (1012, 1124), (1025, 484), (1043, 46), (1049, 1521), (1070, 573), (1073, 1236), (1076, 1789), (1089, 870), (1090, 1620), (1123, 750), (1141, 329), (1143, 109), (1153, 482), (1154, 1251), (1155, 1573), (1171, 1751), (1174, 359), (1175, 2584), (1179, 1020), (1189, 545), (1193, 599), (1212, 1101), (1234, 1410), (1248, 3457), (1249, 107), (1258, 1063), (1266, 138), (1342, 3225), (1449, 520), (1572, 426), (1670, 629), (1701, 1025), (1705, 810), (1845, 153), (2132, 629), (2236, 718)]
def cs89773 : List ℕ := [3334, 4916, 545, 0, 5515, 2002, 2528, 3280, 10001, 6358, 4737, 2528, 10000, 3097, 5515, 0, 10001, 10001, 10000, 1640, 10000, 0, 1691, 10001, 6672, 22146, 10000, 5808, 0, 3046, 10001, 3483, 10000, 10001, 3488, 10000, 2002, 10000, 10001, 10620, 3182, 10000, 7180, 10000, 10773, 10000, 0, 25100, 5264, 9088, 10000, 20845, 5841, 10000, 10000, 4117, 10001, 15264, 10001, 10000, 23461, 10001, 10001, 10001, 7124, 9795, 10000, 0, 10001, 10001, 18302, 10001, 10000, 10001, 7441, 20224, 15366, 10000, 4502, 10002, 10001, 23659, 6649, 10001, 10001, 8285, 9624, 9999, 10000, 10002, 10000, 10000, 10001, 10000, 8038, 10000, 9367, 9999, 10001, 9999, 10000, 10002, 10001, 10000, 10000, 9578, 10000, 10002, 9174, 2121, 10001, 10000, 10001, 7469, 7800, 10001, 10001, 10001, 10000, 10000, 9959, 10000, 10001, 10002, 10002, 8318, 10000, 10001, 10000, 10001, 10003, 7293, 10001, 10002, 10001, 9019, 10000, 5523, 10002, 10002, 10001, 10000, 8217, 8063, 8832, 10000, 8631, 7178, 9205, 7890, 8291, 8144, 10003, 7653]
theorem node89773 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 51 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89773 support demand code
    entries89773 ((insert 46 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 70 (insert 51 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries89774 : List (Fin 2295 × ℕ) := [(4, 15), (468, 22), (490, 27), (497, 14), (506, 27), (514, 5), (629, 24), (631, 8), (679, 8), (681, 36), (694, 1), (728, 12), (736, 24), (739, 2), (814, 10), (815, 8), (816, 17), (844, 19), (846, 4), (856, 37), (874, 23), (884, 6), (885, 27), (886, 11), (887, 5), (888, 5), (898, 8), (919, 13), (924, 23), (933, 14), (934, 21), (944, 44), (958, 8), (959, 24), (960, 23), (970, 13), (973, 42), (978, 21), (985, 13), (1006, 8), (1009, 4), (1011, 11), (1012, 9), (1033, 4), (1049, 17), (1055, 1), (1073, 12), (1076, 17), (1089, 11), (1090, 18), (1123, 7), (1153, 9), (1154, 15), (1155, 3), (1171, 24), (1175, 30), (1176, 3), (1179, 7), (1189, 42), (1212, 18), (1234, 9), (1249, 4), (1261, 6), (1293, 8), (1338, 1), (1342, 37), (1372, 4), (1488, 5), (1614, 7), (1629, 15), (1663, 13), (1670, 4), (1690, 1), (1701, 1), (1705, 8), (1712, 5), (1887, 1), (2022, 3)]
def cs89774 : List ℕ := [19, 83, 42, 0, 57, 44, 34, 87, 78, 27, 20, 56, 99, 27, 64, 7, 93, 101, 100, 10, 95, 0, 8, 100, 34, 209, 99, 100, 0, 37, 100, 14, 99, 100, 76, 37, 7, 99, 100, 102, 43, 100, 49, 98, 121, 98, 0, 237, 51, 101, 99, 148, 50, 101, 100, 37, 100, 112, 100, 64, 138, 101, 100, 100, 99, 51, 99, 24, 100, 100, 0, 100, 92, 101, 79, 150, 145, 72, 30, 100, 100, 144, 27, 101, 100, 76, 95, 101, 100, 100, 101, 100, 101, 102, 100, 99, 67, 100, 99, 100, 100, 101, 101, 102, 99, 101, 100, 100, 98, 25, 101, 100, 101, 71, 73, 99, 102, 101, 100, 99, 102, 99, 99, 101, 101, 91, 99, 100, 100, 100, 101, 75, 101, 100, 101, 86, 99, 63, 101, 100, 97, 99, 92, 77, 83, 100, 99, 82, 99, 87, 89, 90, 100, 70]
theorem node89774 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 46 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89774 support demand code
    entries89774 ((insert 70 (insert 46 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 51 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89771 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 51 (insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    70 node89773 node89774
def entries89772 : List (Fin 2295 × ℕ) := [(4, 228), (179, 39), (342, 29), (490, 51), (527, 380), (631, 240), (727, 255), (729, 19), (739, 110), (741, 127), (815, 95), (856, 620), (874, 240), (884, 96), (885, 295), (886, 181), (888, 173), (920, 219), (924, 131), (931, 28), (933, 270), (934, 55), (944, 309), (959, 144), (960, 303), (969, 252), (970, 37), (973, 498), (985, 210), (1006, 44), (1009, 15), (1011, 53), (1012, 7), (1023, 162), (1025, 59), (1072, 34), (1073, 94), (1076, 223), (1089, 97), (1090, 135), (1123, 158), (1141, 75), (1155, 145), (1160, 40), (1171, 57), (1175, 195), (1177, 5), (1179, 145), (1186, 121), (1188, 36), (1189, 553), (1193, 219), (1212, 65), (1228, 37), (1235, 39), (1248, 18), (1261, 144), (1276, 94), (1305, 25), (1316, 43), (1372, 207), (1384, 203), (1447, 117), (1572, 175), (1585, 31), (1629, 396), (1663, 17), (1680, 219), (1887, 34), (2001, 30), (2132, 83), (2293, 94)]
def cs89772 : List ℕ := [219, 781, 553, 0, 1000, 620, 51, 553, 1000, 0, 396, 51, 1000, 447, 1000, 0, 968, 1000, 1000, 173, 447, 0, 258, 1000, 0, 2855, 1000, 1000, 0, 592, 999, 250, 797, 1057, 748, 1000, 0, 1000, 39, 1512, 353, 1000, 557, 958, 1460, 1000, 0, 1650, 591, 771, 1000, 0, 582, 1000, 999, 597, 1000, 1170, 999, 731, 1302, 999, 1000, 29, 1000, 936, 1000, 396, 1000, 999, 1000, 999, 759, 870, 549, 2596, 1640, 1000, 181, 1000, 999, 1693, 410, 1000, 903, 1000, 982, 1000, 1000, 1000, 999, 987, 999, 999, 1000, 1001, 536, 1001, 999, 1000, 1000, 1001, 1000, 1000, 1001, 778, 998, 1000, 985, 374, 1001, 1001, 999, 746, 898, 1000, 999, 1001, 1001, 1002, 999, 999, 1000, 1000, 1000, 793, 1001, 1000, 1000, 999, 1000, 698, 1000, 1000, 1000, 931, 989, 660, 1000, 1001, 958, 973, 920, 1000, 845, 1001, 657, 856, 894, 816, 903, 914, 1000, 1000]
theorem node89772 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 46 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89772 support demand code
    entries89772 ((insert 51 (insert 46 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node89770 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    51 node89771 node89772
theorem node89745 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 57 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    46 node89769 node89770
def entries89767 : List (Fin 2295 × ℕ) := [(4, 2750), (179, 1081), (491, 4564), (497, 2345), (506, 1756), (571, 1934), (617, 22), (629, 2940), (736, 807), (780, 1454), (815, 187), (833, 394), (847, 757), (852, 3807), (856, 1618), (874, 1450), (884, 435), (885, 2310), (886, 1819), (888, 1725), (892, 6193), (921, 3355), (924, 5194), (933, 3486), (944, 3126), (946, 1618), (949, 3365), (959, 1944), (960, 679), (965, 35), (966, 934), (971, 1680), (973, 4608), (985, 978), (1006, 1332), (1009, 1439), (1011, 1042), (1012, 748), (1033, 163), (1048, 1994), (1069, 75), (1073, 2040), (1089, 326), (1090, 1167), (1120, 71), (1122, 913), (1123, 1527), (1154, 1481), (1171, 982), (1177, 316), (1186, 1599), (1188, 2835), (1193, 2461), (1212, 1145), (1219, 542), (1226, 2607), (1248, 1802), (1258, 785), (1447, 3379), (1572, 2026), (1668, 382), (1701, 98), (1765, 601), (1767, 2999), (1861, 647), (1866, 1248), (1903, 1481), (2225, 1599)]
def cs89767 : List ℕ := [7355, 3292, 3756, 6037, 9018, 1618, 5812, 10000, 8157, 2357, 647, 7602, 10000, 1450, 5211, 0, 5753, 10000, 10000, 3659, 10000, 6193, 1081, 9346, 2357, 18357, 10001, 16950, 0, 4021, 10000, 3453, 9446, 10000, 4298, 8938, 0, 10000, 1081, 11863, 5420, 7781, 7690, 10000, 20640, 9999, 10000, 9260, 8141, 10000, 10000, 10001, 7504, 10000, 10000, 7959, 9999, 0, 10000, 10000, 23768, 9999, 10000, 969, 2887, 4567, 10000, 0, 9999, 16637, 10000, 16899, 9728, 8382, 7560, 16436, 21407, 6025, 5751, 10000, 8807, 32220, 6150, 9913, 8203, 8164, 4355, 10000, 9999, 9008, 10000, 10000, 9999, 10001, 10000, 9999, 7154, 10000, 23443, 10000, 9999, 10001, 1328, 9913, 9180, 10000, 9999, 7990, 9999, 4424, 10000, 10001, 10000, 5464, 8858, 10000, 9999, 10000, 10001, 10000, 10000, 9999, 10000, 10000, 9999, 8361, 10001, 9999, 9999, 9999, 10000, 4924, 10000, 10000, 9999, 8789, 10001, 6207, 10000, 10000, 9782, 7616, 7678, 10000, 9999, 7035, 7117, 8519, 9248, 9815, 8879, 8050, 10000, 8833]
theorem node89767 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 98 (insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89767 support demand code
    entries89767 ((insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 71 (insert 98 (insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries89768 : List (Fin 2295 × ℕ) := [(4, 159), (179, 67), (271, 56), (342, 6), (475, 26), (490, 16), (491, 22), (512, 72), (571, 124), (587, 23), (588, 10), (629, 33), (737, 5), (738, 47), (739, 5), (779, 12), (780, 68), (798, 18), (844, 1), (847, 82), (852, 29), (856, 65), (874, 4), (885, 89), (886, 22), (888, 67), (892, 227), (898, 1), (922, 7), (934, 98), (944, 99), (945, 59), (946, 130), (949, 23), (959, 10), (969, 26), (970, 7), (971, 77), (972, 1), (973, 140), (985, 29), (1006, 45), (1009, 8), (1011, 62), (1048, 29), (1049, 8), (1089, 8), (1090, 75), (1122, 50), (1123, 58), (1171, 42), (1174, 18), (1175, 2), (1177, 5), (1186, 41), (1193, 25), (1217, 21), (1248, 30), (1258, 58), (1266, 43), (1293, 40), (1447, 28), (1675, 28), (1689, 17), (1705, 12), (1767, 71), (1861, 52), (2169, 36), (2225, 46)]
def cs89768 : List ℕ := [170, 159, 174, 149, 213, 86, 38, 256, 184, 0, 152, 137, 236, 4, 212, 0, 256, 256, 256, 191, 255, 255, 101, 257, 0, 634, 256, 563, 0, 128, 256, 43, 255, 256, 194, 224, 0, 255, 67, 336, 222, 255, 188, 213, 505, 256, 256, 132, 256, 177, 255, 256, 89, 257, 256, 236, 257, 0, 256, 257, 344, 190, 256, 6, 148, 92, 256, 28, 257, 544, 257, 10, 220, 95, 144, 421, 522, 119, 65, 256, 256, 621, 155, 256, 217, 137, 87, 257, 257, 256, 256, 256, 257, 256, 256, 256, 171, 257, 560, 257, 257, 256, 253, 255, 171, 141, 257, 255, 237, 119, 256, 256, 256, 168, 257, 256, 256, 257, 256, 256, 255, 257, 257, 256, 256, 235, 256, 256, 257, 256, 246, 165, 256, 256, 221, 237, 236, 186, 256, 256, 257, 208, 194, 256, 256, 159, 212, 256, 255, 241, 256, 205, 239, 181]
theorem node89768 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89768 support demand code
    entries89768 ((insert 71 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 98 (insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node89763 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 98 (insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    71 node89767 node89768
def entries89765 : List (Fin 2295 × ℕ) := [(4, 30), (137, 5), (177, 12), (269, 10), (355, 29), (356, 2), (485, 14), (491, 28), (497, 3), (512, 24), (571, 27), (631, 12), (738, 4), (739, 5), (741, 2), (743, 6), (780, 53), (797, 9), (847, 22), (852, 44), (856, 27), (870, 20), (874, 22), (886, 41), (888, 7), (892, 26), (896, 30), (904, 5), (919, 16), (920, 23), (923, 20), (931, 11), (932, 8), (934, 5), (944, 29), (946, 18), (966, 1), (969, 22), (970, 7), (973, 42), (985, 20), (1006, 31), (1012, 3), (1033, 13), (1049, 34), (1069, 4), (1089, 8), (1090, 2), (1103, 6), (1108, 1), (1143, 3), (1153, 19), (1155, 25), (1171, 4), (1174, 16), (1175, 5), (1177, 28), (1186, 6), (1188, 23), (1193, 23), (1217, 6), (1219, 5), (1226, 12), (1249, 24), (1275, 14), (1500, 4), (1577, 8), (1616, 11), (1629, 6), (1652, 1), (1669, 1), (1765, 22), (1767, 23), (1858, 14), (1887, 2), (1889, 11), (2132, 5), (2167, 6), (2225, 3)]
def cs89765 : List ℕ := [52, 35, 51, 50, 97, 47, 36, 100, 78, 22, 30, 89, 100, 22, 61, 8, 101, 101, 100, 34, 100, 56, 12, 102, 41, 207, 100, 178, 0, 24, 101, 39, 96, 101, 82, 100, 8, 100, 12, 132, 56, 77, 65, 101, 238, 100, 100, 86, 100, 101, 100, 81, 48, 100, 100, 76, 101, 0, 100, 100, 212, 101, 101, 14, 54, 62, 100, 36, 101, 193, 100, 101, 95, 101, 100, 189, 219, 57, 24, 99, 95, 227, 34, 101, 51, 101, 66, 101, 310, 100, 101, 101, 101, 101, 56, 99, 38, 100, 71, 101, 100, 99, 100, 101, 100, 99, 101, 99, 80, 6, 100, 100, 101, 100, 73, 98, 101, 101, 101, 99, 101, 100, 82, 99, 101, 77, 99, 100, 100, 99, 96, 91, 100, 99, 99, 100, 99, 45, 99, 99, 100, 98, 77, 99, 100, 83, 87, 75, 99, 68, 87, 99, 93, 99]
theorem node89765 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89765 support demand code
    entries89765 ((insert 98 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 88 (insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89766 : List (Fin 2295 × ℕ) := [(4, 3832), (29, 1238), (72, 1767), (342, 163), (485, 237), (506, 36), (512, 1850), (571, 1735), (629, 1571), (631, 163), (730, 4247), (731, 3601), (780, 520), (797, 118), (847, 2701), (852, 2555), (856, 4486), (870, 56), (874, 1986), (884, 761), (886, 1033), (888, 1735), (892, 6206), (921, 531), (924, 366), (925, 1095), (933, 450), (934, 1379), (944, 4066), (958, 418), (965, 469), (966, 824), (973, 5175), (982, 164), (985, 1), (1006, 1150), (1011, 1450), (1012, 836), (1025, 1404), (1043, 2014), (1049, 774), (1070, 253), (1073, 1808), (1089, 1686), (1154, 474), (1171, 1238), (1186, 3094), (1193, 2374), (1212, 493), (1248, 864), (1249, 765), (1271, 979), (1275, 1238), (1293, 573), (1403, 217), (1459, 4147), (1515, 460), (1546, 555), (1556, 1028), (1572, 169), (1629, 4644), (1652, 63), (1690, 418), (1701, 1937), (1705, 1028), (1765, 1771), (1767, 3506), (2072, 828), (2132, 209), (2169, 1020), (2225, 1301), (2241, 580)]
def cs89766 : List ℕ := [5880, 3832, 6207, 5277, 9999, 4723, 0, 10000, 7977, 1807, 8261, 1827, 10000, 1986, 7973, 0, 8525, 9768, 10000, 3470, 10000, 6206, 0, 7977, 1971, 26343, 10000, 18907, 1767, 1734, 10000, 3488, 9999, 9999, 6207, 9249, 0, 9999, 2185, 15978, 3564, 9999, 4229, 8269, 21680, 10000, 9999, 8682, 8266, 6255, 9999, 6984, 2315, 10000, 9999, 8192, 10000, 418, 10000, 9998, 19567, 10001, 10000, 3282, 6594, 4877, 10000, 5062, 10000, 18193, 9999, 10000, 10000, 10000, 9599, 17969, 11735, 9999, 3292, 10000, 10001, 22376, 7813, 10000, 10000, 3584, 10001, 9998, 0, 9839, 10000, 10000, 10000, 9998, 6639, 10000, 4553, 9999, 366, 9999, 9999, 10000, 10000, 9999, 9395, 5067, 10000, 10001, 10000, 3587, 10000, 10000, 10000, 10000, 7975, 10000, 9999, 10001, 10000, 10001, 10001, 5013, 10000, 9999, 10001, 7563, 10000, 10001, 6983, 9999, 10001, 5175, 10000, 10001, 9807, 8962, 10000, 7304, 10000, 10001, 5299, 8189, 10000, 10000, 8264, 8011, 9527, 9527, 7841, 10000, 10000, 10000, 10001, 10000]
theorem node89766 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 98 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89766 support demand code
    entries89766 ((insert 88 (insert 98 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node89764 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 98 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    88 node89765 node89766
theorem node89753 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    98 node89763 node89764
def entries89761 : List (Fin 2295 × ℕ) := [(4, 469), (92, 40), (137, 146), (177, 63), (179, 390), (342, 72), (506, 305), (572, 287), (588, 453), (617, 94), (629, 475), (631, 72), (741, 331), (742, 120), (743, 8), (780, 231), (781, 275), (783, 277), (785, 275), (815, 124), (852, 244), (856, 163), (860, 81), (866, 244), (885, 244), (888, 151), (919, 54), (920, 165), (934, 244), (944, 475), (958, 73), (959, 54), (960, 556), (962, 103), (965, 66), (970, 49), (973, 539), (981, 124), (985, 69), (1009, 103), (1049, 136), (1073, 297), (1089, 57), (1090, 57), (1095, 17), (1155, 202), (1159, 200), (1169, 24), (1174, 138), (1176, 21), (1177, 118), (1193, 80), (1212, 63), (1217, 204), (1223, 102), (1249, 138), (1258, 60), (1266, 262), (1403, 208), (1459, 29), (1556, 133), (1583, 28), (1660, 89), (1663, 267), (1689, 138), (1767, 451), (2169, 124)]
def cs89761 : List ℕ := [837, 469, 655, 451, 895, 367, 0, 1001, 732, 305, 244, 306, 1001, 40, 549, 0, 696, 1000, 1000, 438, 1001, 0, 906, 1001, 429, 2094, 1000, 655, 0, 1000, 1001, 343, 758, 1000, 793, 999, 244, 1000, 453, 1366, 677, 547, 1000, 891, 1730, 999, 467, 1712, 453, 422, 1000, 1000, 692, 1000, 1000, 163, 1000, 0, 1000, 1000, 2634, 1000, 1000, 284, 301, 999, 999, 97, 1000, 0, 2665, 999, 981, 659, 999, 2622, 1438, 999, 66, 999, 532, 2248, 898, 999, 987, 786, 999, 999, 999, 999, 1000, 812, 3002, 1000, 1000, 999, 483, 998, 1000, 1000, 998, 998, 999, 946, 1000, 998, 999, 998, 999, 166, 999, 999, 999, 568, 999, 998, 1000, 1000, 999, 1113, 861, 802, 999, 999, 1000, 933, 999, 1000, 1000, 1000, 940, 840, 1000, 999, 903, 684, 816, 947, 1000, 999, 830, 879, 821, 1000, 525, 954, 899, 821, 918, 761, 740, 858, 1000, 804]
theorem node89761 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 92 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89761 support demand code
    entries89761 ((insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 70 (insert 92 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries89762 : List (Fin 2295 × ℕ) := [(4, 34), (72, 4), (92, 1), (137, 51), (342, 27), (490, 27), (506, 57), (512, 65), (514, 1), (572, 96), (629, 50), (631, 59), (736, 43), (737, 7), (797, 27), (798, 29), (817, 28), (849, 14), (852, 121), (856, 49), (860, 9), (870, 57), (884, 35), (888, 29), (919, 76), (924, 53), (933, 10), (934, 64), (944, 92), (958, 22), (959, 89), (960, 33), (966, 3), (969, 30), (973, 105), (985, 89), (1009, 38), (1033, 20), (1047, 3), (1072, 11), (1073, 46), (1075, 16), (1076, 49), (1123, 14), (1143, 21), (1155, 53), (1169, 4), (1170, 2), (1171, 20), (1176, 48), (1177, 46), (1178, 3), (1179, 53), (1186, 14), (1191, 25), (1193, 42), (1212, 16), (1217, 79), (1249, 68), (1261, 12), (1272, 10), (1293, 29), (1344, 43), (1488, 8), (1503, 10), (1517, 29), (1663, 40), (1766, 25), (1767, 56), (1791, 28), (1987, 1)]
def cs89762 : List ℕ := [202, 34, 135, 95, 222, 178, 56, 256, 135, 82, 70, 192, 257, 1, 105, 0, 256, 257, 257, 125, 257, 0, 0, 256, 82, 490, 256, 296, 4, 109, 256, 76, 256, 257, 174, 256, 0, 256, 5, 336, 221, 255, 120, 253, 423, 256, 131, 241, 10, 235, 256, 234, 159, 258, 256, 154, 256, 1, 119, 255, 295, 256, 257, 82, 161, 196, 257, 55, 257, 10, 0, 256, 245, 118, 235, 353, 396, 256, 60, 257, 136, 256, 120, 256, 97, 257, 250, 255, 256, 257, 256, 256, 399, 255, 255, 256, 169, 256, 255, 256, 256, 257, 255, 129, 256, 256, 255, 202, 257, 86, 256, 257, 255, 129, 202, 257, 255, 257, 256, 256, 165, 256, 257, 256, 256, 209, 256, 255, 256, 256, 257, 205, 255, 256, 256, 224, 219, 226, 256, 256, 221, 248, 244, 184, 179, 253, 257, 209, 256, 203, 256, 233, 256, 188]
theorem node89762 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89762 support demand code
    entries89762 ((insert 70 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 92 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node89755 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    70 node89761 node89762
def entries89757 : List (Fin 2295 × ℕ) := [(4, 5), (137, 19), (177, 28), (485, 23), (490, 5), (491, 34), (497, 11), (506, 40), (631, 51), (694, 5), (738, 4), (741, 30), (780, 44), (843, 12), (849, 2), (852, 50), (856, 18), (870, 21), (873, 5), (885, 8), (886, 20), (904, 10), (919, 30), (920, 7), (923, 22), (931, 22), (933, 1), (944, 26), (945, 41), (951, 7), (959, 9), (960, 50), (969, 19), (970, 11), (973, 41), (985, 20), (1006, 10), (1033, 7), (1047, 11), (1049, 18), (1069, 1), (1073, 22), (1089, 1), (1090, 1), (1143, 8), (1153, 21), (1155, 25), (1171, 10), (1175, 12), (1176, 17), (1177, 15), (1189, 4), (1193, 31), (1212, 7), (1217, 31), (1228, 4), (1248, 5), (1249, 21), (1275, 10), (1370, 7), (1403, 5), (1447, 2), (1497, 2), (1517, 6), (1616, 12), (1663, 11), (1731, 5), (1767, 15), (1887, 1), (2002, 4), (2225, 4)]
def cs89757 : List ℕ := [77, 9, 50, 17, 90, 72, 49, 100, 51, 44, 0, 101, 100, 5, 40, 0, 101, 84, 101, 0, 95, 0, 28, 101, 54, 181, 101, 101, 0, 83, 101, 37, 100, 100, 74, 50, 0, 100, 28, 139, 47, 77, 60, 99, 156, 100, 50, 147, 69, 97, 101, 100, 89, 100, 100, 37, 99, 0, 101, 99, 222, 63, 100, 19, 53, 100, 101, 6, 101, 41, 100, 100, 85, 70, 100, 177, 177, 99, 32, 100, 41, 189, 26, 100, 55, 100, 77, 100, 268, 99, 101, 99, 59, 100, 100, 101, 47, 100, 100, 100, 101, 99, 49, 100, 101, 100, 100, 74, 63, 7, 99, 100, 100, 60, 100, 100, 76, 100, 100, 108, 92, 101, 75, 99, 99, 74, 101, 100, 100, 100, 92, 87, 100, 99, 100, 100, 101, 67, 99, 99, 100, 92, 78, 100, 99, 91, 100, 74, 100, 75, 87, 93, 91, 99]
theorem node89757 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89757 support demand code
    entries89757 ((insert 92 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 88 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89759 : List (Fin 2295 × ℕ) := [(137, 1), (342, 32), (491, 108), (497, 105), (506, 86), (587, 12), (629, 87), (631, 5), (694, 49), (741, 36), (778, 23), (780, 74), (849, 15), (852, 132), (856, 12), (873, 53), (885, 57), (886, 52), (898, 21), (921, 68), (924, 135), (933, 28), (944, 39), (951, 39), (958, 24), (966, 42), (973, 112), (981, 2), (984, 4), (985, 49), (1009, 25), (1034, 5), (1048, 49), (1069, 2), (1073, 37), (1076, 13), (1090, 31), (1096, 11), (1123, 22), (1143, 7), (1154, 6), (1155, 31), (1160, 9), (1171, 19), (1174, 7), (1176, 5), (1177, 32), (1178, 8), (1179, 37), (1186, 18), (1193, 84), (1212, 58), (1217, 45), (1223, 22), (1248, 18), (1261, 29), (1277, 21), (1293, 22), (1316, 6), (1403, 5), (1417, 5), (1447, 61), (1488, 19), (1497, 24), (1572, 22), (1629, 24), (1663, 20), (1669, 7), (1731, 8), (1767, 57), (1887, 13)]
def cs89759 : List ℕ := [208, 0, 102, 72, 238, 57, 108, 256, 211, 86, 24, 175, 256, 53, 84, 0, 201, 156, 256, 0, 256, 0, 33, 257, 88, 404, 256, 249, 0, 92, 257, 68, 257, 257, 124, 154, 0, 257, 0, 286, 78, 221, 191, 257, 424, 255, 154, 328, 0, 207, 257, 231, 256, 255, 257, 140, 256, 0, 178, 257, 607, 0, 257, 75, 107, 240, 255, 48, 257, 0, 256, 256, 196, 131, 257, 444, 246, 209, 61, 256, 0, 341, 150, 257, 43, 256, 216, 257, 44, 257, 257, 256, 0, 257, 257, 256, 127, 256, 255, 257, 255, 256, 93, 257, 255, 257, 434, 195, 253, 132, 257, 256, 99, 163, 255, 256, 256, 256, 258, 255, 57, 186, 234, 256, 256, 200, 256, 255, 205, 255, 229, 180, 255, 255, 255, 256, 256, 182, 255, 256, 256, 255, 183, 256, 255, 255, 208, 219, 255, 219, 255, 247, 255, 256]
theorem node89759 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 92 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 106 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89759 support demand code
    entries89759 ((insert 88 (insert 92 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)) ((insert 106 (insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries89760 : List (Fin 2295 × ℕ) := [(137, 27), (179, 48), (490, 16), (497, 13), (506, 17), (507, 12), (588, 7), (629, 22), (631, 29), (817, 22), (833, 11), (852, 42), (856, 25), (873, 25), (885, 26), (921, 36), (924, 6), (933, 18), (944, 31), (949, 30), (958, 2), (966, 8), (972, 2), (973, 47), (984, 10), (985, 15), (991, 11), (1009, 14), (1023, 1), (1045, 19), (1072, 11), (1073, 28), (1143, 8), (1154, 7), (1155, 20), (1169, 1), (1171, 23), (1177, 22), (1193, 18), (1212, 16), (1217, 11), (1223, 16), (1228, 10), (1248, 16), (1275, 5), (1316, 14), (1372, 4), (1403, 19), (1447, 24), (1497, 3), (1502, 6), (1572, 6), (1577, 6), (1614, 4), (1629, 15), (1660, 2), (1669, 2), (1767, 31), (1887, 3), (1902, 5), (2169, 8), (2225, 1)]
def cs89760 : List ℕ := [76, 0, 42, 31, 76, 40, 26, 100, 51, 29, 15, 53, 100, 29, 28, 10, 99, 49, 100, 0, 99, 0, 55, 95, 39, 202, 100, 83, 0, 99, 99, 44, 88, 100, 42, 62, 10, 99, 48, 143, 49, 99, 44, 101, 188, 101, 58, 123, 48, 58, 99, 99, 59, 101, 100, 52, 100, 0, 99, 100, 154, 12, 99, 41, 46, 94, 100, 18, 100, 4, 99, 94, 91, 22, 100, 141, 93, 82, 61, 99, 0, 121, 99, 100, 100, 97, 99, 100, 22, 100, 100, 101, 0, 100, 100, 99, 61, 100, 100, 100, 100, 100, 41, 91, 99, 100, 6, 76, 100, 32, 101, 100, 46, 51, 53, 99, 101, 100, 100, 111, 27, 49, 82, 100, 100, 89, 99, 100, 53, 100, 83, 79, 100, 100, 101, 100, 98, 70, 100, 100, 99, 96, 75, 100, 75, 100, 98, 74, 100, 91, 79, 100, 92, 100]
theorem node89760 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 106 (insert 88 (insert 92 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89760 support demand code
    entries89760 ((insert 106 (insert 88 (insert 92 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))))) : Finset (Fin 154)) ((insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89758 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 92 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 92 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)) ((insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    106 node89759 node89760
theorem node89756 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    88 node89757 node89758
theorem node89754 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    92 node89755 node89756
theorem node89747 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 27 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    69 node89753 node89754
def entries89749 : List (Fin 2295 × ℕ) := [(4, 23), (179, 70), (506, 26), (571, 26), (629, 92), (631, 11), (730, 46), (780, 36), (798, 16), (844, 59), (852, 54), (856, 26), (869, 11), (874, 96), (884, 29), (885, 69), (886, 52), (888, 44), (898, 18), (919, 25), (921, 31), (924, 32), (933, 64), (944, 55), (945, 22), (949, 60), (951, 2), (952, 8), (958, 8), (959, 12), (960, 106), (971, 9), (972, 11), (973, 120), (985, 36), (1006, 2), (1009, 56), (1011, 26), (1012, 12), (1048, 20), (1069, 36), (1073, 20), (1076, 4), (1090, 19), (1122, 41), (1123, 4), (1130, 1), (1133, 11), (1143, 4), (1155, 27), (1171, 24), (1174, 18), (1175, 17), (1176, 14), (1178, 15), (1179, 43), (1186, 27), (1188, 9), (1193, 61), (1212, 54), (1223, 35), (1226, 57), (1248, 101), (1266, 11), (1273, 29), (1293, 12), (1316, 14), (1358, 2), (1403, 10), (1447, 18), (1472, 9), (1497, 16), (1572, 5), (1663, 17), (1675, 42), (1765, 65), (1766, 69), (2132, 9), (2225, 36), (2288, 23)]
def cs89749 : List ℕ := [157, 23, 0, 65, 173, 95, 0, 150, 253, 160, 42, 113, 256, 96, 126, 0, 256, 154, 256, 70, 96, 42, 88, 255, 160, 421, 256, 0, 0, 215, 257, 56, 192, 256, 35, 257, 0, 255, 70, 237, 90, 237, 97, 217, 332, 256, 91, 307, 204, 201, 256, 256, 176, 255, 256, 168, 257, 0, 255, 256, 569, 256, 234, 0, 113, 197, 256, 84, 257, 256, 255, 256, 255, 204, 241, 449, 473, 256, 113, 256, 178, 606, 187, 255, 256, 248, 174, 255, 255, 256, 256, 255, 256, 254, 256, 256, 256, 255, 594, 256, 256, 256, 63, 255, 256, 256, 255, 215, 256, 202, 256, 256, 255, 145, 256, 256, 256, 257, 256, 256, 256, 255, 257, 257, 257, 235, 256, 255, 255, 257, 257, 185, 257, 256, 257, 252, 254, 231, 257, 258, 257, 239, 214, 257, 257, 215, 240, 220, 256, 257, 257, 257, 258, 257]
theorem node89749 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89749 support demand code
    entries89749 ((insert 27 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 98 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries89751 : List (Fin 2295 × ℕ) := [(137, 2), (177, 14), (269, 2), (404, 13), (506, 6), (571, 1), (588, 2), (629, 1), (631, 9), (741, 3), (780, 15), (797, 4), (843, 4), (844, 7), (852, 10), (866, 4), (874, 8), (885, 9), (886, 9), (887, 4), (904, 4), (919, 11), (920, 2), (931, 1), (933, 1), (934, 1), (944, 10), (945, 13), (946, 3), (952, 2), (960, 14), (969, 7), (970, 3), (973, 14), (981, 1), (984, 3), (985, 3), (1006, 4), (1012, 5), (1047, 2), (1049, 8), (1070, 1), (1073, 2), (1089, 1), (1090, 1), (1126, 3), (1128, 1), (1143, 4), (1153, 4), (1155, 9), (1171, 4), (1175, 8), (1176, 4), (1177, 2), (1193, 5), (1248, 10), (1249, 8), (1275, 2), (1293, 1), (1501, 1), (1604, 2), (1605, 1), (1616, 2), (1657, 6), (1667, 2), (1765, 15), (1766, 3), (1857, 1), (1887, 1), (2149, 1), (2225, 6)]
def cs89751 : List ℕ := [18, 6, 2, 15, 21, 3, 0, 25, 29, 24, 4, 21, 31, 8, 11, 0, 31, 18, 32, 7, 17, 0, 18, 31, 31, 52, 31, 0, 2, 25, 31, 13, 30, 32, 12, 31, 6, 32, 14, 37, 8, 31, 14, 32, 39, 32, 18, 42, 32, 30, 31, 31, 11, 32, 31, 14, 32, 0, 32, 31, 77, 31, 24, 2, 21, 22, 32, 0, 31, 31, 32, 32, 32, 31, 32, 58, 75, 31, 5, 32, 20, 70, 16, 32, 14, 25, 22, 32, 92, 31, 32, 31, 32, 31, 32, 31, 24, 32, 31, 33, 30, 32, 31, 31, 32, 31, 32, 26, 21, 0, 32, 32, 31, 31, 26, 32, 32, 31, 33, 31, 31, 32, 28, 32, 32, 22, 32, 32, 31, 33, 32, 28, 33, 32, 32, 32, 32, 22, 32, 32, 32, 32, 29, 33, 31, 27, 30, 26, 32, 25, 30, 30, 27, 27]
theorem node89751 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 27 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89751 support demand code
    entries89751 ((insert 98 (insert 27 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 88 (insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
def entries89752 : List (Fin 2295 × ℕ) := [(4, 8), (72, 17), (350, 8), (468, 25), (506, 19), (571, 19), (572, 2), (629, 28), (631, 30), (730, 42), (741, 7), (780, 14), (797, 7), (815, 4), (844, 17), (852, 18), (856, 6), (866, 48), (874, 39), (884, 2), (885, 29), (886, 17), (921, 16), (924, 14), (933, 23), (934, 16), (944, 43), (958, 13), (966, 5), (973, 50), (985, 8), (1009, 12), (1011, 2), (1012, 14), (1025, 7), (1070, 14), (1072, 4), (1073, 28), (1076, 15), (1155, 27), (1159, 4), (1169, 15), (1171, 18), (1175, 7), (1193, 15), (1212, 12), (1247, 2), (1248, 27), (1249, 8), (1258, 3), (1293, 11), (1344, 2), (1403, 8), (1488, 7), (1546, 6), (1572, 5), (1604, 11), (1657, 10), (1663, 5), (1765, 36), (1766, 5), (1791, 27), (1887, 2), (2073, 2), (2132, 6), (2236, 31)]
def cs89752 : List ℕ := [42, 43, 11, 36, 51, 11, 0, 81, 74, 60, 65, 71, 99, 39, 50, 0, 99, 50, 99, 32, 100, 0, 0, 99, 71, 210, 98, 0, 28, 58, 100, 16, 74, 101, 7, 99, 59, 99, 17, 78, 71, 99, 43, 88, 115, 101, 39, 172, 42, 85, 99, 98, 71, 100, 100, 54, 59, 0, 100, 100, 231, 90, 100, 7, 50, 61, 100, 28, 101, 100, 99, 100, 100, 70, 100, 204, 118, 99, 25, 101, 55, 213, 99, 100, 74, 77, 100, 100, 7, 100, 101, 89, 99, 99, 100, 100, 100, 100, 14, 100, 101, 100, 100, 99, 96, 89, 100, 86, 95, 12, 100, 99, 93, 75, 94, 100, 100, 100, 100, 100, 83, 50, 100, 99, 100, 100, 100, 100, 77, 100, 99, 72, 100, 99, 100, 82, 87, 72, 99, 99, 87, 100, 100, 100, 59, 87, 90, 87, 87, 82, 72, 96, 79, 89]
theorem node89752 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 98 (insert 27 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89752 support demand code
    entries89752 ((insert 88 (insert 98 (insert 27 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)) ((insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89750 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 27 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 98 (insert 27 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    88 node89751 node89752
theorem node89748 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 27 (insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    98 node89749 node89750
theorem node89746 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 57 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    27 node89747 node89748
theorem node89715 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 75 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    57 node89745 node89746
def entries89743 : List (Fin 2295 × ℕ) := [(4, 28), (37, 3), (72, 108), (179, 1), (485, 1), (497, 27), (498, 75), (506, 112), (514, 65), (542, 38), (629, 66), (631, 40), (679, 48), (680, 38), (737, 109), (740, 42), (812, 107), (813, 19), (814, 54), (815, 12), (845, 47), (852, 65), (884, 23), (886, 81), (888, 116), (892, 153), (924, 59), (934, 2), (944, 73), (952, 24), (958, 47), (960, 141), (962, 50), (973, 146), (1006, 23), (1009, 28), (1014, 5), (1023, 14), (1025, 45), (1033, 16), (1038, 13), (1043, 11), (1072, 17), (1073, 38), (1075, 6), (1089, 8), (1097, 38), (1099, 13), (1120, 1), (1123, 20), (1141, 10), (1143, 13), (1154, 23), (1155, 8), (1169, 31), (1171, 4), (1174, 9), (1185, 23), (1186, 51), (1189, 38), (1193, 44), (1212, 29), (1217, 6), (1226, 35), (1246, 31), (1339, 12), (1403, 71), (1485, 3), (1488, 5), (1497, 7), (1501, 84), (1701, 29), (1705, 31), (1770, 100), (1902, 8), (1987, 27), (1993, 15), (2169, 39)]
def cs89743 : List ℕ := [150, 213, 44, 0, 175, 110, 0, 256, 215, 112, 173, 6, 256, 0, 256, 0, 176, 257, 256, 119, 256, 153, 85, 256, 112, 513, 256, 362, 108, 107, 257, 68, 256, 257, 153, 256, 0, 255, 256, 212, 2, 208, 222, 256, 498, 255, 256, 474, 67, 256, 256, 538, 256, 256, 255, 184, 256, 257, 256, 256, 455, 257, 256, 198, 255, 195, 255, 78, 257, 257, 256, 590, 232, 207, 252, 4, 559, 210, 30, 257, 257, 757, 250, 255, 256, 107, 256, 257, 269, 257, 256, 206, 681, 256, 256, 255, 179, 524, 256, 256, 256, 257, 256, 220, 255, 256, 257, 257, 253, 153, 257, 255, 257, 255, 146, 257, 256, 257, 257, 255, 257, 256, 256, 257, 257, 253, 256, 255, 255, 223, 258, 193, 256, 257, 256, 241, 230, 239, 257, 257, 160, 194, 252, 257, 193, 216, 257, 257, 211, 257, 249, 239, 257, 257]
theorem node89743 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 27 (insert 71 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89743 support demand code
    entries89743 ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 97 (insert 27 (insert 71 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries89744 : List (Fin 2295 × ℕ) := [(4, 8), (37, 18), (72, 34), (181, 16), (342, 7), (404, 20), (485, 24), (491, 19), (498, 28), (506, 33), (514, 17), (542, 13), (577, 5), (629, 20), (631, 17), (679, 8), (680, 7), (681, 3), (739, 9), (741, 41), (797, 11), (814, 16), (815, 24), (816, 7), (818, 2), (845, 5), (849, 1), (852, 35), (884, 24), (885, 16), (886, 19), (888, 37), (892, 42), (924, 32), (934, 17), (944, 37), (959, 17), (960, 17), (970, 12), (973, 51), (982, 11), (1009, 10), (1023, 6), (1025, 5), (1043, 13), (1073, 33), (1075, 4), (1081, 8), (1089, 5), (1090, 4), (1113, 12), (1139, 1), (1154, 13), (1155, 9), (1169, 12), (1186, 21), (1189, 24), (1193, 16), (1226, 21), (1234, 12), (1249, 2), (1286, 9), (1497, 2), (1528, 12), (1545, 1), (1670, 13), (1689, 11), (1701, 19), (1728, 4), (1765, 6), (1770, 36), (1845, 20), (1848, 3), (1864, 5), (2000, 6), (2169, 21), (2225, 11)]
def cs89744 : List ℕ := [52, 73, 24, 7, 83, 78, 24, 100, 100, 39, 51, 30, 100, 0, 100, 0, 100, 90, 100, 55, 100, 42, 16, 100, 50, 212, 100, 144, 34, 42, 100, 40, 100, 100, 61, 100, 0, 100, 101, 128, 17, 76, 80, 76, 200, 100, 100, 165, 46, 99, 100, 224, 99, 99, 100, 54, 100, 100, 99, 101, 170, 100, 101, 74, 66, 71, 100, 13, 100, 100, 101, 206, 100, 99, 95, 0, 216, 100, 41, 101, 100, 262, 75, 100, 100, 30, 101, 101, 100, 91, 101, 78, 202, 100, 100, 101, 102, 0, 100, 100, 101, 100, 100, 100, 100, 52, 101, 99, 100, 21, 100, 101, 101, 90, 92, 101, 100, 100, 101, 100, 100, 91, 100, 101, 100, 81, 100, 101, 87, 102, 100, 65, 102, 101, 100, 101, 81, 98, 101, 100, 79, 83, 84, 100, 95, 84, 94, 94, 53, 72, 97, 83, 100, 94]
theorem node89744 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 97 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 71 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89744 support demand code
    entries89744 ((insert 97 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 71 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89741 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 71 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 27 (insert 71 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    97 node89743 node89744
def entries89742 : List (Fin 2295 × ℕ) := [(37, 20), (72, 35), (181, 22), (350, 16), (409, 9), (485, 10), (494, 2), (498, 2), (506, 25), (540, 20), (542, 27), (587, 4), (629, 12), (631, 22), (679, 24), (680, 15), (690, 13), (737, 24), (741, 12), (812, 2), (815, 12), (845, 49), (852, 31), (874, 37), (884, 18), (885, 5), (886, 28), (888, 21), (908, 10), (924, 23), (934, 6), (944, 47), (952, 1), (958, 19), (959, 30), (960, 6), (962, 15), (973, 56), (978, 16), (1009, 3), (1014, 19), (1025, 1), (1033, 6), (1043, 1), (1073, 19), (1089, 5), (1090, 4), (1113, 17), (1123, 1), (1128, 8), (1154, 14), (1167, 11), (1174, 7), (1175, 18), (1186, 19), (1188, 8), (1193, 8), (1226, 31), (1228, 1), (1249, 1), (1258, 10), (1272, 7), (1297, 4), (1344, 20), (1403, 19), (1442, 4), (1477, 6), (1478, 1), (1482, 1), (1488, 2), (1497, 9), (1604, 6), (1689, 8), (1701, 17), (1745, 1), (1765, 5), (1766, 34), (1845, 14), (1848, 4), (1849, 8)]
def cs89742 : List ℕ := [8, 49, 6, 5, 39, 64, 0, 88, 69, 64, 35, 5, 100, 37, 94, 0, 101, 84, 101, 47, 100, 0, 26, 100, 70, 163, 101, 0, 51, 35, 100, 17, 101, 99, 25, 99, 16, 100, 101, 40, 12, 100, 51, 99, 140, 100, 100, 180, 39, 100, 99, 229, 81, 99, 100, 48, 94, 100, 99, 98, 171, 99, 98, 73, 80, 76, 101, 30, 99, 99, 99, 195, 100, 87, 99, 0, 239, 98, 18, 98, 100, 246, 98, 100, 84, 39, 100, 99, 100, 97, 99, 86, 209, 99, 99, 101, 83, 99, 99, 100, 100, 105, 99, 99, 83, 93, 99, 98, 101, 34, 100, 100, 98, 79, 52, 100, 99, 99, 100, 101, 99, 99, 99, 97, 99, 79, 101, 101, 100, 99, 98, 101, 100, 99, 101, 100, 83, 100, 100, 99, 86, 77, 90, 101, 62, 93, 100, 92, 100, 94, 81, 101, 100, 80]
theorem node89742 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89742 support demand code
    entries89742 ((insert 27 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 71 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89737 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 71 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    27 node89741 node89742
def entries89739 : List (Fin 2295 × ℕ) := [(37, 15), (72, 22), (177, 13), (269, 32), (485, 39), (491, 18), (497, 1), (498, 7), (506, 9), (542, 38), (577, 4), (588, 5), (629, 9), (631, 36), (639, 12), (681, 19), (736, 16), (737, 30), (739, 9), (741, 36), (845, 29), (846, 5), (852, 26), (870, 17), (874, 31), (885, 14), (886, 17), (888, 36), (892, 11), (896, 20), (897, 18), (919, 25), (920, 6), (944, 32), (946, 19), (952, 8), (959, 28), (960, 34), (970, 20), (973, 58), (981, 2), (1006, 9), (1009, 15), (1033, 5), (1043, 3), (1072, 12), (1073, 10), (1089, 5), (1090, 13), (1098, 10), (1111, 1), (1113, 15), (1123, 13), (1143, 6), (1153, 5), (1154, 7), (1155, 1), (1171, 6), (1174, 15), (1175, 16), (1186, 19), (1189, 30), (1193, 9), (1247, 1), (1276, 10), (1401, 2), (1480, 5), (1489, 12), (1633, 1), (1655, 4), (1766, 15), (1767, 9), (1845, 2), (1850, 14), (1851, 5), (1852, 21), (1858, 5), (1863, 1), (1870, 3), (1877, 14), (2225, 15)]
def cs89739 : List ℕ := [18, 64, 39, 9, 65, 69, 18, 99, 77, 24, 22, 35, 100, 31, 101, 0, 85, 99, 99, 51, 100, 31, 36, 102, 26, 151, 100, 93, 22, 58, 100, 31, 100, 100, 75, 100, 0, 101, 100, 108, 0, 102, 55, 88, 209, 100, 101, 182, 46, 99, 101, 200, 101, 99, 99, 42, 100, 101, 101, 101, 128, 99, 100, 88, 95, 68, 99, 20, 99, 100, 102, 67, 81, 100, 98, 6, 231, 102, 19, 99, 100, 180, 86, 100, 92, 38, 53, 101, 267, 100, 98, 74, 162, 101, 100, 99, 84, 100, 99, 98, 99, 100, 100, 101, 98, 100, 101, 98, 85, 19, 99, 99, 100, 87, 101, 99, 99, 100, 98, 111, 100, 98, 98, 99, 100, 96, 99, 99, 99, 98, 92, 89, 99, 100, 81, 100, 98, 80, 99, 100, 100, 91, 93, 99, 77, 84, 99, 92, 84, 99, 89, 99, 99, 88]
theorem node89739 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89739 support demand code
    entries89739 ((insert 71 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 88 (insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89740 : List (Fin 2295 × ℕ) := [(4, 8), (37, 39), (72, 68), (271, 94), (485, 65), (491, 45), (498, 20), (506, 36), (542, 78), (572, 6), (577, 9), (587, 13), (629, 94), (679, 24), (681, 1), (737, 102), (739, 26), (740, 25), (741, 77), (819, 2), (845, 79), (852, 68), (870, 23), (874, 62), (884, 40), (885, 36), (886, 34), (888, 101), (892, 101), (898, 55), (919, 7), (933, 22), (944, 67), (951, 22), (952, 26), (971, 37), (973, 140), (981, 25), (1006, 32), (1009, 62), (1025, 19), (1043, 28), (1073, 39), (1075, 5), (1089, 16), (1090, 1), (1122, 39), (1123, 28), (1132, 4), (1154, 13), (1155, 5), (1174, 19), (1175, 28), (1185, 9), (1186, 88), (1189, 65), (1193, 37), (1234, 60), (1246, 33), (1247, 10), (1277, 3), (1403, 47), (1486, 3), (1545, 38), (1705, 11), (1752, 8), (1766, 48), (1767, 45), (1848, 22), (1887, 7), (1991, 20), (2000, 31), (2169, 39), (2225, 42)]
def cs89740 : List ℕ := [82, 152, 110, 45, 178, 152, 45, 257, 217, 84, 68, 68, 257, 62, 256, 0, 223, 257, 256, 146, 256, 101, 68, 256, 109, 451, 256, 256, 68, 94, 257, 46, 256, 257, 157, 257, 0, 255, 256, 240, 28, 256, 125, 202, 496, 256, 256, 460, 93, 256, 256, 612, 255, 256, 257, 163, 256, 256, 255, 257, 342, 193, 256, 227, 222, 186, 256, 38, 257, 256, 256, 0, 255, 255, 256, 0, 357, 242, 40, 257, 256, 395, 255, 215, 256, 94, 93, 255, 47, 257, 257, 202, 261, 256, 217, 256, 180, 255, 256, 256, 257, 256, 255, 255, 241, 227, 255, 257, 187, 134, 256, 256, 195, 249, 255, 258, 255, 257, 255, 256, 57, 149, 257, 256, 256, 234, 256, 256, 197, 256, 255, 187, 255, 257, 256, 171, 234, 195, 255, 257, 254, 208, 229, 256, 256, 225, 179, 239, 251, 257, 255, 256, 256, 245]
theorem node89740 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 71 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89740 support demand code
    entries89740 ((insert 88 (insert 71 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node89738 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    88 node89739 node89740
theorem node89733 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    71 node89737 node89738
def entries89735 : List (Fin 2295 × ℕ) := [(4, 1), (37, 27), (72, 25), (269, 10), (485, 39), (491, 51), (497, 46), (506, 13), (542, 20), (571, 2), (577, 12), (631, 9), (632, 3), (679, 37), (681, 1), (736, 5), (738, 6), (741, 34), (786, 12), (843, 20), (845, 10), (846, 30), (849, 5), (852, 53), (870, 28), (872, 11), (874, 34), (884, 21), (886, 36), (892, 8), (904, 8), (920, 21), (931, 4), (944, 12), (945, 37), (946, 9), (947, 27), (958, 8), (960, 25), (969, 6), (970, 24), (973, 58), (981, 15), (1009, 4), (1033, 7), (1034, 1), (1040, 1), (1072, 9), (1073, 16), (1081, 2), (1089, 11), (1090, 3), (1099, 7), (1101, 2), (1108, 9), (1123, 5), (1153, 8), (1155, 9), (1171, 10), (1174, 7), (1175, 26), (1182, 4), (1184, 7), (1186, 16), (1189, 7), (1193, 19), (1247, 10), (1249, 4), (1322, 4), (1370, 2), (1401, 5), (1442, 2), (1501, 37), (1845, 6), (1847, 3), (1848, 1), (1852, 13), (1857, 7), (1880, 1), (1987, 7), (2000, 1), (2225, 15)]
def cs89735 : List ℕ := [19, 48, 7, 5, 80, 66, 51, 100, 100, 13, 25, 79, 100, 45, 79, 0, 96, 100, 100, 29, 100, 8, 37, 100, 36, 156, 100, 101, 25, 12, 100, 21, 99, 100, 83, 100, 0, 100, 99, 116, 6, 75, 100, 58, 206, 99, 100, 191, 54, 98, 99, 243, 91, 100, 100, 53, 100, 100, 100, 99, 234, 52, 100, 68, 57, 53, 100, 12, 99, 101, 100, 85, 99, 99, 100, 10, 194, 100, 68, 98, 100, 160, 84, 100, 59, 25, 58, 100, 262, 98, 100, 100, 28, 99, 100, 100, 72, 100, 99, 99, 99, 99, 99, 100, 68, 100, 100, 99, 72, 23, 101, 100, 99, 73, 77, 99, 100, 99, 101, 118, 100, 101, 80, 89, 99, 72, 101, 100, 99, 101, 100, 91, 102, 99, 88, 99, 101, 79, 100, 100, 99, 97, 100, 101, 100, 100, 100, 100, 99, 101, 100, 100, 97, 83]
theorem node89735 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89735 support demand code
    entries89735 ((insert 92 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 88 (insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89736 : List (Fin 2295 × ℕ) := [(4, 11), (37, 45), (72, 16), (181, 53), (271, 3), (342, 17), (485, 20), (491, 94), (497, 109), (498, 4), (506, 81), (542, 14), (577, 8), (629, 83), (631, 9), (679, 45), (681, 26), (731, 57), (736, 43), (740, 2), (741, 9), (817, 12), (819, 4), (833, 8), (835, 20), (845, 4), (852, 147), (870, 32), (874, 56), (884, 24), (886, 57), (887, 33), (892, 57), (921, 64), (924, 134), (925, 4), (944, 62), (951, 68), (958, 36), (972, 10), (973, 127), (981, 39), (1009, 22), (1023, 9), (1025, 18), (1033, 16), (1073, 75), (1075, 52), (1076, 3), (1089, 33), (1123, 31), (1143, 15), (1155, 44), (1171, 21), (1175, 29), (1186, 84), (1193, 73), (1293, 11), (1316, 3), (1322, 58), (1342, 50), (1375, 20), (1401, 21), (1403, 33), (1442, 10), (1488, 27), (1647, 74), (1683, 4), (1745, 16), (1766, 13), (1770, 106), (1887, 7), (1991, 27), (1993, 11), (1998, 13), (2169, 7)]
def cs89736 : List ℕ := [179, 121, 0, 0, 231, 184, 94, 257, 255, 94, 16, 126, 256, 56, 145, 0, 114, 226, 256, 78, 257, 57, 53, 255, 133, 357, 256, 257, 16, 96, 257, 71, 255, 256, 135, 240, 0, 256, 256, 274, 0, 256, 173, 256, 488, 255, 257, 567, 111, 256, 256, 592, 257, 256, 257, 113, 256, 256, 256, 257, 630, 114, 257, 226, 160, 146, 257, 36, 256, 257, 257, 255, 256, 256, 257, 21, 310, 256, 119, 256, 256, 411, 232, 256, 253, 52, 164, 257, 29, 255, 257, 255, 0, 257, 256, 257, 244, 256, 255, 256, 256, 255, 208, 257, 161, 256, 255, 254, 255, 97, 255, 256, 229, 191, 234, 256, 256, 256, 256, 256, 186, 256, 256, 256, 255, 179, 256, 256, 196, 256, 234, 156, 256, 255, 256, 256, 206, 179, 256, 255, 249, 209, 194, 256, 217, 238, 237, 211, 210, 252, 158, 255, 221, 255]
theorem node89736 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 92 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89736 support demand code
    entries89736 ((insert 88 (insert 92 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node89734 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    88 node89735 node89736
theorem node89717 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 51 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    92 node89733 node89734
def entries89731 : List (Fin 2295 × ℕ) := [(177, 8), (514, 8), (587, 20), (588, 38), (630, 34), (632, 35), (639, 19), (677, 8), (737, 30), (738, 14), (739, 3), (741, 11), (814, 10), (817, 2), (819, 13), (845, 22), (855, 29), (856, 27), (865, 21), (867, 17), (884, 14), (885, 16), (886, 8), (888, 73), (892, 95), (898, 15), (919, 16), (920, 5), (922, 9), (934, 15), (944, 34), (959, 27), (960, 40), (961, 5), (966, 12), (970, 11), (973, 58), (1006, 21), (1009, 17), (1025, 12), (1033, 2), (1043, 12), (1072, 4), (1077, 12), (1089, 11), (1101, 1), (1103, 9), (1110, 1), (1123, 14), (1132, 16), (1186, 42), (1189, 54), (1193, 15), (1217, 10), (1226, 4), (1308, 14), (1358, 5), (1403, 15), (1488, 15), (1497, 1), (1678, 10), (1681, 21), (1705, 4), (1845, 3), (1848, 4), (1861, 7), (1863, 2), (1991, 10), (2225, 4), (2293, 2)]
def cs89731 : List ℕ := [37, 86, 64, 7, 79, 66, 10, 98, 79, 0, 63, 22, 100, 0, 79, 0, 68, 101, 100, 73, 100, 95, 81, 101, 0, 243, 100, 222, 0, 100, 101, 30, 65, 101, 64, 78, 0, 265, 8, 110, 15, 99, 100, 85, 206, 100, 100, 123, 35, 100, 99, 0, 100, 101, 100, 145, 100, 100, 100, 100, 65, 99, 100, 12, 77, 100, 100, 27, 100, 199, 50, 100, 99, 100, 70, 27, 248, 101, 38, 99, 100, 244, 66, 100, 100, 41, 28, 101, 100, 101, 99, 75, 221, 99, 99, 100, 83, 100, 100, 99, 98, 101, 100, 100, 101, 80, 100, 100, 99, 47, 101, 100, 99, 100, 87, 96, 99, 99, 101, 100, 100, 100, 100, 100, 99, 99, 100, 100, 99, 97, 64, 59, 100, 100, 99, 74, 82, 77, 100, 100, 94, 92, 80, 100, 81, 71, 65, 100, 99, 100, 87, 100, 100, 100]
theorem node89731 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 27 (insert 37 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89731 support demand code
    entries89731 ((insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 27 (insert 37 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89732 : List (Fin 2295 × ℕ) := [(179, 25), (409, 10), (475, 24), (491, 6), (514, 18), (542, 43), (587, 19), (588, 51), (629, 25), (639, 10), (737, 16), (739, 5), (741, 20), (813, 8), (815, 1), (843, 3), (846, 37), (852, 45), (853, 3), (855, 17), (856, 50), (870, 3), (884, 34), (885, 12), (886, 36), (888, 50), (898, 4), (922, 19), (944, 6), (958, 9), (959, 43), (960, 28), (966, 11), (970, 22), (973, 56), (981, 3), (1009, 20), (1033, 1), (1041, 4), (1045, 7), (1072, 8), (1073, 31), (1078, 4), (1089, 3), (1113, 4), (1154, 8), (1169, 8), (1174, 2), (1175, 3), (1185, 6), (1186, 31), (1189, 13), (1193, 13), (1212, 5), (1261, 11), (1293, 12), (1308, 1), (1339, 6), (1375, 6), (1403, 18), (1488, 11), (1497, 16), (1528, 6), (1588, 9), (1616, 2), (1632, 4), (1678, 29), (1845, 12), (1848, 8), (1866, 5)]
def cs89732 : List ℕ := [18, 79, 13, 29, 100, 70, 40, 100, 55, 0, 47, 38, 99, 0, 98, 0, 100, 100, 99, 50, 101, 0, 99, 98, 3, 220, 100, 111, 0, 50, 100, 19, 99, 108, 58, 95, 0, 198, 25, 90, 0, 54, 100, 52, 150, 96, 88, 149, 25, 100, 99, 0, 101, 99, 100, 25, 99, 43, 99, 101, 123, 81, 101, 58, 54, 99, 100, 46, 99, 0, 48, 100, 100, 68, 100, 50, 175, 99, 53, 96, 50, 157, 101, 98, 80, 51, 69, 101, 100, 99, 99, 73, 177, 100, 100, 81, 88, 98, 100, 99, 100, 100, 100, 92, 100, 86, 100, 99, 98, 42, 100, 101, 100, 64, 74, 99, 98, 100, 101, 100, 101, 100, 84, 100, 99, 100, 100, 100, 101, 98, 100, 85, 101, 100, 99, 99, 67, 87, 100, 100, 99, 91, 100, 100, 96, 90, 95, 100, 85, 100, 87, 95, 100, 100]
theorem node89732 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 37 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89732 support demand code
    entries89732 ((insert 69 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 27 (insert 37 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89729 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 37 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 37 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    69 node89731 node89732
def entries89730 : List (Fin 2295 × ℕ) := [(4, 23), (177, 12), (179, 21), (350, 11), (409, 8), (475, 19), (494, 2), (542, 46), (587, 18), (588, 41), (630, 31), (690, 11), (737, 31), (739, 21), (741, 33), (813, 2), (815, 8), (817, 4), (845, 46), (856, 27), (874, 17), (884, 15), (885, 21), (886, 10), (887, 20), (888, 53), (898, 8), (919, 18), (922, 22), (934, 5), (944, 40), (959, 31), (960, 20), (962, 9), (966, 11), (970, 6), (973, 53), (1004, 1), (1006, 4), (1009, 23), (1033, 4), (1045, 1), (1072, 11), (1073, 14), (1110, 5), (1113, 4), (1114, 1), (1123, 11), (1154, 2), (1155, 12), (1174, 4), (1175, 18), (1186, 29), (1193, 23), (1226, 10), (1258, 10), (1286, 2), (1297, 3), (1308, 4), (1344, 8), (1354, 2), (1375, 4), (1403, 27), (1497, 15), (1632, 2), (1633, 3), (1655, 1), (1657, 8), (1683, 22), (1845, 13), (1848, 13), (1903, 4), (1991, 2), (2225, 2)]
def cs89730 : List ℕ := [31, 77, 0, 19, 54, 27, 0, 56, 54, 0, 0, 27, 100, 17, 100, 0, 54, 100, 36, 73, 100, 0, 100, 100, 0, 173, 100, 0, 0, 86, 100, 40, 78, 100, 22, 100, 0, 139, 33, 72, 5, 72, 100, 99, 113, 68, 56, 116, 65, 100, 100, 0, 99, 100, 100, 17, 100, 99, 99, 100, 70, 100, 89, 57, 99, 100, 100, 0, 100, 100, 71, 100, 101, 99, 86, 27, 215, 100, 33, 101, 85, 219, 101, 99, 101, 55, 69, 101, 101, 100, 101, 81, 210, 100, 101, 101, 100, 100, 101, 101, 101, 99, 100, 93, 100, 100, 100, 100, 100, 38, 99, 100, 101, 83, 81, 101, 100, 100, 99, 100, 78, 101, 101, 101, 101, 96, 100, 101, 101, 101, 86, 90, 100, 101, 100, 101, 75, 75, 100, 100, 83, 85, 85, 100, 100, 85, 83, 82, 92, 98, 100, 100, 94, 101]
theorem node89730 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 27 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89730 support demand code
    entries89730 ((insert 27 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 37 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89725 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    27 node89729 node89730
def entries89727 : List (Fin 2295 × ℕ) := [(177, 20), (542, 17), (639, 3), (736, 4), (737, 10), (739, 5), (741, 15), (742, 1), (816, 1), (845, 15), (846, 3), (852, 3), (853, 5), (856, 10), (872, 2), (874, 7), (885, 8), (886, 6), (888, 20), (892, 9), (896, 3), (897, 1), (919, 5), (920, 3), (922, 2), (934, 3), (944, 10), (946, 10), (959, 23), (960, 5), (970, 6), (973, 20), (1006, 2), (1009, 2), (1031, 1), (1043, 2), (1073, 3), (1081, 3), (1089, 4), (1090, 2), (1098, 2), (1103, 5), (1113, 7), (1155, 1), (1174, 3), (1175, 4), (1186, 8), (1189, 12), (1193, 3), (1235, 2), (1258, 3), (1403, 1), (1497, 2), (1501, 1), (1619, 2), (1655, 2), (1848, 2), (1850, 6), (1852, 6), (2225, 4)]
def cs89727 : List ℕ := [3, 30, 12, 0, 18, 15, 0, 33, 15, 2, 0, 0, 30, 9, 32, 0, 14, 33, 31, 20, 32, 12, 22, 32, 2, 59, 32, 32, 0, 20, 32, 10, 3, 33, 27, 32, 0, 2, 20, 38, 3, 0, 11, 27, 63, 32, 32, 12, 32, 33, 32, 0, 17, 32, 33, 19, 32, 19, 14, 33, 22, 30, 25, 17, 30, 31, 32, 3, 32, 31, 31, 31, 22, 32, 20, 10, 86, 32, 3, 32, 32, 75, 31, 26, 1, 11, 10, 27, 89, 33, 32, 23, 68, 32, 19, 31, 22, 31, 40, 32, 32, 32, 32, 31, 32, 32, 31, 32, 29, 8, 33, 32, 31, 29, 32, 32, 31, 31, 32, 35, 31, 31, 32, 32, 30, 28, 31, 32, 31, 30, 26, 29, 31, 32, 29, 30, 29, 27, 31, 31, 30, 28, 32, 31, 18, 32, 30, 30, 27, 31, 26, 32, 31, 29]
theorem node89727 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89727 support demand code
    entries89727 ((insert 37 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 88 (insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
def entries89728 : List (Fin 2295 × ℕ) := [(179, 127), (542, 120), (639, 5), (730, 57), (731, 60), (737, 95), (739, 6), (741, 125), (742, 30), (815, 36), (817, 9), (845, 93), (852, 13), (853, 13), (856, 92), (860, 15), (872, 36), (873, 36), (874, 27), (884, 31), (885, 38), (886, 46), (888, 127), (892, 100), (919, 7), (922, 43), (924, 4), (934, 71), (944, 93), (959, 98), (961, 23), (966, 3), (970, 10), (973, 149), (1004, 7), (1006, 18), (1009, 57), (1043, 10), (1072, 10), (1073, 74), (1075, 25), (1076, 4), (1089, 30), (1110, 1), (1113, 28), (1123, 16), (1154, 12), (1174, 2), (1175, 21), (1186, 63), (1188, 11), (1189, 108), (1193, 20), (1212, 16), (1223, 7), (1247, 16), (1261, 14), (1308, 10), (1344, 31), (1375, 5), (1403, 59), (1497, 22), (1545, 58), (1705, 13), (1770, 35), (1791, 7), (1845, 23), (1848, 21), (1993, 12), (2225, 18)]
def cs89728 : List ℕ := [62, 236, 108, 0, 148, 140, 0, 256, 150, 0, 0, 7, 255, 99, 248, 0, 122, 256, 255, 127, 255, 100, 127, 255, 0, 476, 255, 256, 0, 127, 255, 50, 4, 256, 179, 225, 0, 0, 127, 244, 71, 0, 100, 193, 520, 223, 255, 92, 255, 256, 256, 0, 178, 256, 256, 199, 255, 156, 164, 255, 180, 256, 255, 123, 168, 256, 255, 58, 256, 255, 255, 256, 254, 138, 177, 92, 536, 256, 34, 255, 255, 600, 254, 223, 255, 133, 220, 254, 142, 256, 256, 176, 515, 255, 176, 256, 205, 257, 256, 255, 256, 256, 256, 256, 256, 220, 257, 256, 257, 102, 256, 256, 256, 197, 257, 256, 256, 255, 255, 256, 179, 205, 257, 256, 256, 246, 257, 256, 210, 256, 256, 194, 256, 257, 258, 193, 194, 215, 256, 256, 143, 182, 256, 256, 182, 257, 248, 244, 186, 251, 256, 256, 240, 228]
theorem node89728 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 37 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89728 support demand code
    entries89728 ((insert 88 (insert 37 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)) ((insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node89726 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 37 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    88 node89727 node89728
theorem node89719 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    37 node89725 node89726
def entries89721 : List (Fin 2295 × ℕ) := [(4, 34), (177, 54), (475, 15), (491, 41), (542, 49), (588, 13), (632, 6), (639, 27), (736, 21), (741, 32), (786, 9), (843, 5), (845, 9), (846, 40), (852, 40), (856, 23), (872, 5), (873, 21), (874, 9), (885, 21), (886, 35), (887, 32), (892, 2), (896, 9), (904, 1), (919, 18), (920, 4), (928, 39), (944, 18), (945, 31), (959, 16), (960, 29), (969, 10), (970, 27), (973, 55), (981, 17), (1006, 9), (1009, 16), (1033, 5), (1073, 21), (1089, 17), (1101, 2), (1103, 8), (1108, 7), (1113, 3), (1123, 5), (1154, 9), (1174, 13), (1175, 15), (1186, 22), (1189, 8), (1193, 9), (1212, 4), (1247, 6), (1249, 4), (1258, 2), (1261, 8), (1293, 4), (1364, 4), (1370, 3), (1501, 22), (1528, 7), (1545, 1), (1585, 8), (1668, 4), (1845, 11), (1848, 1), (1850, 8), (1852, 8), (1857, 11), (1997, 2), (2225, 20)]
def cs89721 : List ℕ := [9, 91, 8, 17, 91, 23, 41, 97, 51, 2, 0, 58, 49, 35, 100, 0, 56, 100, 100, 32, 99, 11, 89, 100, 20, 139, 78, 100, 0, 62, 100, 30, 52, 100, 77, 86, 0, 99, 93, 117, 0, 23, 94, 62, 208, 99, 100, 99, 96, 100, 100, 0, 99, 101, 100, 37, 100, 99, 100, 100, 123, 56, 89, 49, 56, 49, 99, 10, 100, 100, 84, 100, 100, 99, 100, 23, 209, 101, 43, 99, 81, 158, 100, 99, 47, 30, 77, 80, 304, 100, 100, 86, 45, 99, 99, 99, 95, 99, 101, 100, 99, 101, 99, 99, 56, 100, 101, 100, 84, 26, 100, 101, 100, 100, 86, 100, 100, 99, 100, 114, 99, 101, 74, 101, 99, 80, 100, 100, 101, 99, 100, 83, 101, 101, 100, 100, 90, 86, 101, 100, 99, 82, 101, 100, 101, 99, 98, 98, 84, 100, 100, 100, 100, 81]
theorem node89721 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89721 support demand code
    entries89721 ((insert 92 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 88 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89723 : List (Fin 2295 × ℕ) := [(4, 32), (475, 7), (491, 23), (542, 7), (577, 19), (630, 12), (632, 20), (639, 8), (730, 48), (736, 22), (819, 7), (845, 18), (846, 24), (852, 25), (856, 41), (872, 10), (873, 10), (874, 16), (884, 16), (885, 4), (886, 21), (887, 49), (892, 20), (920, 10), (921, 5), (922, 3), (924, 57), (925, 2), (933, 5), (944, 28), (945, 10), (966, 19), (973, 52), (981, 5), (1006, 15), (1009, 22), (1025, 21), (1073, 15), (1099, 12), (1118, 3), (1120, 4), (1122, 1), (1123, 33), (1130, 8), (1132, 4), (1155, 2), (1186, 46), (1193, 26), (1217, 28), (1403, 25), (1591, 12), (1668, 2), (1680, 29), (1681, 4), (1701, 27), (1861, 4), (1866, 1), (1991, 10), (1993, 17), (2225, 7), (2283, 6)]
def cs89723 : List ℕ := [59, 74, 28, 12, 83, 69, 24, 100, 58, 0, 4, 63, 99, 36, 65, 0, 73, 101, 100, 49, 100, 20, 29, 97, 5, 187, 100, 100, 0, 65, 100, 45, 100, 101, 52, 100, 0, 100, 0, 106, 5, 77, 80, 87, 200, 100, 71, 74, 91, 101, 100, 0, 101, 100, 100, 56, 101, 101, 101, 100, 142, 81, 86, 26, 87, 51, 100, 6, 101, 208, 53, 101, 102, 93, 100, 41, 120, 85, 35, 101, 91, 167, 101, 101, 101, 47, 25, 101, 10, 101, 101, 83, 0, 100, 101, 100, 100, 99, 101, 101, 100, 100, 32, 94, 53, 100, 101, 93, 100, 46, 100, 100, 94, 79, 68, 95, 100, 101, 101, 100, 49, 86, 98, 100, 101, 89, 100, 101, 75, 100, 80, 52, 100, 100, 100, 101, 90, 59, 100, 100, 83, 77, 76, 100, 100, 83, 79, 98, 79, 98, 92, 100, 100, 100]
theorem node89723 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 92 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89723 support demand code
    entries89723 ((insert 88 (insert 92 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)) ((insert 69 (insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries89724 : List (Fin 2295 × ℕ) := [(4, 13), (179, 51), (475, 4), (491, 31), (507, 5), (542, 33), (587, 46), (588, 1), (639, 20), (736, 27), (741, 18), (817, 12), (843, 8), (845, 35), (846, 29), (852, 29), (856, 23), (872, 11), (873, 30), (885, 21), (886, 23), (887, 6), (888, 17), (890, 38), (921, 17), (924, 26), (930, 1), (933, 24), (944, 17), (958, 16), (972, 9), (973, 46), (981, 9), (1009, 27), (1025, 4), (1033, 6), (1045, 19), (1073, 39), (1076, 8), (1089, 5), (1110, 5), (1113, 5), (1121, 9), (1123, 9), (1155, 15), (1174, 4), (1175, 15), (1186, 28), (1193, 23), (1212, 11), (1217, 2), (1261, 10), (1293, 1), (1316, 1), (1322, 5), (1375, 5), (1403, 13), (1488, 2), (1497, 3), (1528, 11), (1655, 1), (1666, 4), (1667, 2), (1701, 1), (1845, 13), (1983, 3), (1993, 5), (1997, 18), (2283, 2)]
def cs89724 : List ℕ := [25, 77, 2, 22, 65, 25, 31, 95, 36, 23, 0, 55, 82, 41, 69, 0, 46, 100, 99, 23, 101, 38, 98, 71, 32, 140, 99, 100, 0, 69, 101, 18, 100, 100, 50, 63, 0, 100, 55, 79, 24, 22, 95, 82, 203, 100, 100, 92, 51, 101, 100, 0, 100, 100, 99, 79, 100, 86, 100, 101, 81, 26, 100, 33, 70, 77, 99, 18, 100, 6, 100, 100, 68, 46, 99, 23, 114, 88, 1, 101, 21, 92, 101, 100, 80, 99, 99, 100, 19, 101, 101, 84, 20, 100, 99, 98, 93, 100, 100, 101, 100, 101, 36, 84, 98, 100, 99, 101, 100, 49, 100, 101, 56, 68, 75, 101, 100, 99, 99, 108, 37, 53, 99, 100, 99, 77, 100, 100, 87, 99, 101, 68, 98, 101, 100, 99, 85, 79, 100, 100, 99, 63, 85, 97, 99, 100, 94, 85, 83, 100, 79, 100, 86, 100]
theorem node89724 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 88 (insert 92 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs89724 support demand code
    entries89724 ((insert 69 (insert 88 (insert 92 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))))) : Finset (Fin 154)) ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node89722 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 92 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 92 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))))) : Finset (Fin 154)) ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    69 node89723 node89724
theorem node89720 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))))) : Finset (Fin 154)) ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    88 node89721 node89722
theorem node89718 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))))) : Finset (Fin 154)) ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    92 node89719 node89720
theorem node89716 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 75 (insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))))) : Finset (Fin 154)) ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    51 node89717 node89718
theorem node89714 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 31 (insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    75 node89715 node89716
theorem node89649 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 67 (insert 34 (insert 36 (insert 109 (insert 78 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 60 (insert 81 (insert 47 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    31 node89713 node89714
#print axioms node89649
end OmissionResidualCover31Fused
