import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries98021 : List (Fin 2295 × ℕ) := [(164, 1)]
def cs98021 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node98021 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98021 support demand code
    entries98021 ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)) ((insert 95 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries98023 : List (Fin 2295 × ℕ) := [(892, 1)]
def cs98023 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node98023 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98023 support demand code
    entries98023 ((insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 55 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries98027 : List (Fin 2295 × ℕ) := [(162, 1)]
def cs98027 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node98027 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 105 (insert 93 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98027 support demand code
    entries98027 ((insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 105 (insert 93 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries98029 : List (Fin 2295 × ℕ) := [(896, 1)]
def cs98029 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node98029 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 93 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98029 support demand code
    entries98029 ((insert 105 (insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 88 (insert 93 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries98030 : List (Fin 2295 × ℕ) := [(37, 19), (77, 13), (99, 6), (137, 3), (409, 4), (488, 1), (571, 7), (581, 6), (585, 20), (588, 14), (617, 7), (738, 1), (741, 7), (743, 1), (812, 6), (813, 1), (833, 6), (835, 1), (844, 7), (846, 3), (852, 6), (885, 7), (888, 2), (893, 26), (894, 26), (917, 1), (933, 13), (938, 6), (958, 6), (970, 5), (972, 4), (973, 19), (984, 8), (1008, 2), (1011, 5), (1025, 4), (1043, 3), (1049, 1), (1070, 4), (1073, 3), (1090, 3), (1107, 3), (1108, 2), (1114, 2), (1122, 1), (1123, 6), (1154, 2), (1155, 1), (1171, 6), (1178, 2), (1185, 3), (1186, 5), (1188, 7), (1191, 4), (1219, 4), (1235, 4), (1258, 3), (1261, 2), (1276, 4), (1293, 2), (1313, 2), (1400, 6), (1618, 5), (1629, 6), (1678, 7), (1701, 2), (1767, 5), (1785, 6), (1859, 3), (1886, 4)]
def cs98030 : List ℕ := [21, 14, 5, 15, 23, 29, 10, 32, 32, 5, 32, 7, 32, 6, 32, 0, 23, 32, 32, 32, 32, 88, 14, 27, 5, 94, 32, 120, 13, 6, 32, 33, 28, 32, 16, 32, 26, 32, 32, 32, 27, 25, 20, 32, 85, 29, 68, 41, 12, 17, 32, 33, 32, 32, 31, 10, 32, 32, 32, 32, 0, 33, 32, 16, 31, 31, 31, 84, 24, 49, 20, 32, 32, 32, 25, 32, 29, 28, 71, 32, 21, 70, 32, 29, 25, 19, 32, 32, 18, 32, 32, 32, 32, 62, 32, 5, 32, 30, 31, 19, 32, 32, 24, 32, 32, 0, 31, 24, 33, 14, 32, 32, 30, 13, 22, 32, 32, 32, 32, 33, 32, 31, 27, 26, 33, 25, 29, 32, 20, 32, 32, 19, 32, 32, 32, 32, 32, 21, 32, 32, 33, 32, 25, 33, 30, 24, 28, 29, 32, 32, 28, 26, 33, 32]
theorem node98030 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 105 (insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98030 support demand code
    entries98030 ((insert 88 (insert 105 (insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 93 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
theorem node98028 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 105 (insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 105 (insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 93 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    88 node98029 node98030
theorem node98025 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 93 (insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    105 node98027 node98028
def entries98026 : List (Fin 2295 × ℕ) := [(37, 133), (75, 107), (77, 68), (99, 82), (137, 81), (273, 2), (353, 30), (484, 11), (488, 11), (491, 55), (581, 165), (587, 76), (588, 32), (617, 78), (640, 35), (679, 3), (737, 38), (741, 81), (813, 23), (843, 31), (844, 15), (852, 76), (853, 5), (858, 5), (860, 40), (869, 35), (883, 2), (885, 26), (888, 24), (893, 139), (894, 198), (896, 121), (917, 31), (921, 37), (925, 17), (930, 38), (932, 18), (934, 10), (938, 45), (957, 94), (966, 23), (972, 40), (973, 134), (984, 80), (985, 9), (1007, 26), (1008, 1), (1011, 12), (1012, 21), (1025, 36), (1049, 7), (1073, 1), (1108, 16), (1123, 67), (1126, 35), (1133, 52), (1171, 43), (1174, 8), (1185, 29), (1186, 70), (1188, 61), (1219, 62), (1226, 5), (1284, 10), (1313, 29), (1361, 2), (1400, 3), (1572, 7), (1591, 73), (1636, 14), (1657, 13), (1678, 39), (1705, 2), (1770, 58), (1859, 10), (1886, 22), (1991, 18), (2161, 14)]
def cs98026 : List ℕ := [125, 172, 0, 91, 179, 257, 109, 256, 254, 0, 214, 175, 257, 82, 256, 0, 205, 256, 257, 179, 257, 752, 108, 256, 0, 719, 217, 882, 68, 107, 256, 255, 148, 255, 133, 256, 139, 257, 256, 256, 131, 255, 163, 256, 884, 255, 638, 313, 66, 134, 256, 255, 256, 256, 255, 74, 256, 256, 256, 255, 17, 255, 256, 189, 255, 256, 256, 830, 255, 388, 164, 256, 256, 147, 219, 247, 181, 256, 527, 256, 223, 402, 256, 255, 178, 60, 256, 255, 256, 256, 256, 256, 257, 121, 255, 9, 255, 255, 256, 247, 255, 255, 92, 255, 204, 255, 257, 228, 256, 139, 230, 255, 256, 255, 227, 210, 256, 256, 254, 256, 218, 207, 255, 255, 256, 177, 255, 256, 257, 255, 164, 142, 255, 256, 257, 187, 228, 148, 256, 256, 256, 217, 177, 255, 257, 222, 228, 255, 256, 255, 256, 256, 204, 233]
theorem node98026 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 93 (insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98026 support demand code
    entries98026 ((insert 93 (insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node98024 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    93 node98025 node98026
theorem node98022 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 95 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    55 node98023 node98024
theorem node98007 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)) ((insert 69 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    95 node98021 node98022
def entries98019 : List (Fin 2295 × ℕ) := [(20, 5), (75, 117), (135, 9), (137, 31), (273, 58), (471, 55), (474, 49), (482, 10), (488, 55), (491, 33), (572, 167), (576, 26), (588, 148), (618, 19), (741, 30), (742, 9), (842, 46), (843, 31), (852, 64), (869, 39), (885, 41), (888, 26), (892, 63), (893, 173), (894, 148), (916, 11), (917, 152), (918, 140), (921, 22), (930, 64), (934, 11), (938, 73), (957, 30), (958, 43), (960, 31), (965, 12), (966, 41), (973, 126), (984, 107), (1009, 23), (1012, 13), (1022, 4), (1025, 28), (1068, 9), (1072, 10), (1073, 38), (1095, 1), (1107, 9), (1123, 30), (1139, 11), (1153, 8), (1155, 49), (1165, 9), (1170, 26), (1171, 48), (1175, 54), (1179, 38), (1185, 5), (1186, 31), (1198, 53), (1201, 35), (1212, 45), (1247, 5), (1258, 7), (1279, 97), (1307, 5), (1308, 21), (1328, 22), (1399, 1), (1454, 1), (1488, 18), (1502, 14), (1517, 39), (1678, 31), (1701, 30), (1767, 40), (1912, 1), (2017, 20)]
def cs98019 : List ℕ := [93, 163, 95, 152, 183, 222, 108, 256, 144, 0, 221, 257, 256, 113, 256, 0, 248, 256, 256, 193, 271, 609, 168, 256, 216, 622, 248, 762, 0, 195, 256, 615, 245, 257, 138, 257, 173, 256, 84, 730, 209, 257, 181, 256, 955, 256, 320, 440, 20, 215, 256, 256, 252, 256, 257, 257, 255, 257, 148, 256, 0, 256, 256, 84, 195, 256, 257, 1016, 229, 63, 188, 256, 256, 58, 247, 257, 260, 255, 523, 256, 257, 417, 255, 256, 168, 203, 198, 256, 377, 256, 256, 255, 256, 256, 256, 257, 256, 255, 256, 224, 256, 256, 74, 256, 257, 256, 248, 217, 256, 119, 255, 257, 204, 148, 255, 256, 255, 256, 256, 256, 130, 255, 252, 207, 254, 223, 255, 255, 220, 255, 256, 224, 254, 256, 248, 256, 256, 199, 255, 256, 256, 255, 213, 254, 255, 256, 248, 255, 255, 256, 255, 256, 255, 256]
theorem node98019 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98019 support demand code
    entries98019 ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries98020 : List (Fin 2295 × ℕ) := [(20, 3), (35, 13), (37, 93), (75, 70), (77, 111), (137, 99), (273, 35), (409, 6), (488, 27), (491, 51), (507, 120), (540, 10), (572, 13), (587, 7), (588, 64), (617, 57), (629, 44), (679, 8), (739, 41), (740, 66), (741, 18), (843, 57), (844, 13), (849, 18), (852, 67), (858, 60), (870, 21), (885, 31), (888, 14), (892, 52), (893, 173), (894, 194), (906, 12), (930, 45), (931, 19), (932, 27), (938, 91), (957, 49), (958, 28), (960, 65), (966, 34), (969, 19), (970, 32), (973, 127), (984, 55), (985, 64), (1012, 11), (1045, 16), (1072, 22), (1073, 10), (1089, 23), (1090, 9), (1107, 19), (1108, 6), (1111, 23), (1114, 9), (1123, 37), (1154, 16), (1169, 34), (1171, 20), (1175, 31), (1176, 9), (1177, 32), (1179, 16), (1186, 28), (1191, 22), (1212, 30), (1219, 25), (1223, 79), (1261, 11), (1275, 8), (1293, 8), (1308, 27), (1335, 14), (1488, 22), (1502, 6), (1517, 15), (1572, 10), (1616, 13), (1617, 4), (1636, 9), (1657, 22), (1667, 19), (1701, 2), (1705, 15), (1767, 50), (1852, 7), (1858, 3), (1887, 25), (1912, 7), (2002, 15), (2008, 6)]
def cs98020 : List ℕ := [186, 47, 50, 124, 190, 155, 141, 256, 238, 141, 181, 228, 256, 22, 235, 0, 256, 255, 256, 120, 340, 489, 71, 257, 147, 724, 256, 675, 111, 151, 256, 2, 256, 257, 164, 256, 173, 256, 257, 196, 158, 232, 122, 258, 753, 245, 424, 383, 0, 101, 257, 258, 257, 257, 257, 256, 256, 257, 256, 257, 0, 257, 255, 252, 241, 257, 256, 723, 256, 52, 185, 256, 256, 165, 257, 256, 291, 257, 623, 255, 141, 349, 256, 257, 88, 147, 256, 257, 257, 256, 257, 257, 257, 258, 249, 257, 257, 257, 257, 257, 256, 257, 259, 258, 256, 257, 258, 241, 257, 74, 257, 257, 259, 166, 258, 256, 257, 256, 257, 256, 258, 257, 256, 246, 256, 181, 256, 257, 256, 256, 246, 243, 256, 256, 256, 256, 229, 202, 255, 256, 256, 257, 256, 256, 256, 256, 222, 257, 256, 256, 256, 256, 256, 206]
theorem node98020 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98020 support demand code
    entries98020 ((insert 31 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node98015 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154))
    31 node98019 node98020
def entries98017 : List (Fin 2295 × ℕ) := [(43, 1), (72, 44), (75, 23), (77, 60), (86, 32), (135, 31), (137, 18), (273, 30), (479, 10), (491, 44), (507, 94), (512, 31), (514, 12), (572, 43), (579, 11), (588, 77), (617, 50), (740, 77), (742, 21), (743, 4), (842, 4), (843, 22), (844, 91), (858, 76), (873, 69), (885, 10), (892, 26), (893, 162), (894, 184), (898, 16), (925, 2), (930, 51), (931, 17), (932, 46), (934, 27), (938, 111), (957, 5), (958, 46), (959, 16), (960, 67), (966, 26), (970, 16), (972, 12), (973, 136), (984, 64), (985, 21), (1007, 21), (1010, 14), (1011, 4), (1012, 3), (1045, 33), (1060, 1), (1061, 24), (1069, 7), (1073, 59), (1107, 1), (1110, 24), (1111, 19), (1119, 15), (1123, 31), (1169, 22), (1173, 33), (1174, 9), (1175, 35), (1178, 8), (1179, 19), (1183, 16), (1184, 23), (1185, 7), (1186, 61), (1212, 17), (1223, 88), (1261, 27), (1263, 10), (1279, 12), (1293, 22), (1357, 3), (1488, 9), (1523, 6), (1534, 6), (1572, 36), (1594, 100), (1616, 19), (1657, 55), (1675, 63), (1701, 2), (1852, 8)]
def cs98017 : List ℕ := [234, 67, 0, 0, 153, 115, 121, 256, 256, 94, 233, 231, 256, 172, 246, 100, 257, 255, 175, 143, 409, 583, 93, 256, 106, 605, 256, 568, 204, 87, 256, 211, 234, 256, 180, 256, 162, 256, 255, 24, 171, 257, 196, 256, 768, 227, 384, 306, 0, 92, 256, 256, 256, 256, 255, 256, 254, 256, 256, 255, 2, 256, 256, 104, 229, 255, 255, 708, 256, 26, 234, 256, 256, 73, 256, 205, 314, 255, 595, 256, 144, 347, 256, 164, 89, 158, 256, 256, 255, 255, 255, 256, 255, 255, 256, 225, 255, 256, 416, 256, 256, 257, 191, 256, 256, 256, 254, 207, 255, 147, 256, 257, 213, 212, 255, 255, 256, 256, 257, 257, 203, 255, 255, 244, 256, 191, 257, 256, 256, 255, 255, 216, 256, 255, 257, 256, 256, 218, 256, 257, 256, 256, 246, 257, 255, 257, 256, 255, 257, 256, 255, 257, 256, 256]
theorem node98017 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98017 support demand code
    entries98017 ((insert 39 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 98 (insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries98018 : List (Fin 2295 × ℕ) := [(35, 12), (75, 19), (77, 53), (135, 15), (137, 12), (273, 19), (409, 8), (479, 5), (490, 3), (491, 35), (507, 45), (512, 5), (572, 2), (579, 14), (588, 26), (617, 9), (681, 17), (738, 4), (740, 1), (741, 32), (743, 1), (812, 15), (813, 1), (843, 2), (844, 33), (858, 29), (873, 21), (885, 5), (886, 1), (888, 23), (892, 10), (893, 78), (894, 63), (895, 8), (932, 32), (936, 24), (957, 8), (958, 23), (962, 4), (966, 13), (970, 12), (973, 52), (984, 23), (1010, 9), (1012, 10), (1022, 2), (1047, 8), (1060, 1), (1061, 13), (1068, 15), (1072, 4), (1073, 17), (1094, 9), (1107, 7), (1110, 7), (1111, 1), (1113, 11), (1119, 2), (1121, 5), (1139, 2), (1155, 4), (1169, 15), (1172, 3), (1173, 19), (1177, 18), (1184, 5), (1186, 19), (1212, 10), (1223, 23), (1261, 12), (1263, 5), (1279, 8), (1293, 11), (1308, 6), (1572, 11), (1594, 30), (1616, 5), (1657, 29), (1705, 1), (1861, 2), (1991, 9)]
def cs98018 : List ℕ := [87, 37, 0, 2, 57, 50, 67, 100, 99, 45, 79, 100, 100, 63, 101, 30, 100, 91, 76, 55, 167, 227, 26, 99, 53, 247, 100, 260, 83, 31, 101, 77, 100, 100, 52, 96, 86, 100, 100, 13, 56, 99, 61, 100, 279, 89, 149, 121, 0, 37, 73, 99, 100, 100, 100, 100, 101, 99, 100, 98, 1, 78, 100, 95, 64, 100, 101, 267, 100, 10, 77, 100, 100, 36, 100, 93, 105, 100, 261, 100, 51, 106, 99, 62, 52, 89, 101, 100, 99, 99, 101, 99, 100, 98, 77, 101, 100, 100, 0, 94, 100, 99, 99, 99, 101, 100, 101, 97, 99, 38, 99, 101, 99, 97, 85, 100, 99, 99, 100, 100, 71, 69, 101, 100, 99, 89, 100, 100, 53, 100, 99, 99, 100, 99, 100, 100, 100, 93, 99, 99, 99, 95, 99, 99, 68, 88, 100, 100, 99, 100, 79, 99, 86, 90]
theorem node98018 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 39 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98018 support demand code
    entries98018 ((insert 98 (insert 39 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node98016 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    98 node98017 node98018
theorem node98009 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 20 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    39 node98015 node98016
def entries98011 : List (Fin 2295 × ℕ) := [(75, 9), (77, 24), (130, 14), (179, 9), (342, 7), (471, 8), (484, 29), (488, 10), (507, 2), (530, 1), (572, 26), (579, 6), (587, 19), (588, 22), (617, 7), (679, 33), (741, 18), (843, 9), (844, 33), (852, 33), (860, 23), (873, 26), (883, 33), (885, 8), (886, 7), (888, 10), (892, 1), (893, 72), (894, 38), (898, 2), (900, 19), (917, 12), (930, 24), (932, 4), (933, 8), (934, 3), (938, 11), (957, 10), (958, 33), (959, 11), (960, 20), (962, 2), (966, 11), (970, 13), (973, 51), (984, 23), (1012, 7), (1047, 2), (1060, 2), (1061, 17), (1067, 3), (1068, 15), (1069, 4), (1072, 6), (1073, 21), (1110, 9), (1113, 14), (1121, 9), (1123, 8), (1133, 1), (1155, 2), (1159, 7), (1169, 26), (1171, 18), (1177, 21), (1179, 6), (1186, 15), (1189, 26), (1191, 3), (1198, 8), (1201, 30), (1212, 8), (1242, 2), (1261, 12), (1293, 14), (1308, 6), (1335, 6), (1488, 5), (1534, 9), (1572, 6), (1594, 8), (1623, 10), (1666, 2), (1705, 1), (1913, 2), (2280, 27)]
def cs98011 : List ℕ := [44, 56, 34, 11, 100, 82, 0, 100, 100, 2, 41, 0, 100, 75, 100, 8, 99, 100, 95, 44, 33, 172, 79, 100, 10, 282, 84, 154, 32, 55, 100, 89, 99, 221, 67, 99, 72, 99, 98, 100, 41, 98, 75, 100, 308, 100, 101, 211, 9, 44, 99, 100, 100, 78, 99, 101, 98, 101, 99, 100, 9, 98, 84, 75, 35, 101, 101, 287, 91, 1, 54, 99, 100, 99, 100, 101, 133, 100, 210, 100, 100, 96, 101, 100, 65, 101, 100, 100, 100, 99, 99, 100, 98, 100, 100, 101, 101, 100, 100, 100, 98, 100, 100, 101, 99, 81, 101, 100, 100, 31, 100, 100, 100, 68, 101, 91, 100, 99, 101, 100, 89, 100, 100, 81, 100, 95, 100, 101, 100, 100, 100, 101, 100, 100, 99, 100, 100, 100, 100, 100, 97, 92, 100, 100, 83, 100, 100, 100, 100, 100, 89, 96, 93, 76]
theorem node98011 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98011 support demand code
    entries98011 ((insert 20 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 33 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries98013 : List (Fin 2295 × ℕ) := [(70, 15), (75, 40), (77, 44), (137, 19), (181, 12), (273, 18), (409, 4), (471, 50), (488, 9), (572, 50), (588, 45), (617, 7), (629, 34), (631, 2), (679, 7), (738, 8), (813, 15), (843, 23), (852, 26), (853, 47), (869, 53), (870, 21), (873, 2), (892, 7), (893, 66), (894, 54), (917, 30), (918, 6), (930, 35), (931, 30), (938, 24), (957, 4), (958, 16), (960, 12), (962, 3), (965, 9), (966, 20), (970, 1), (973, 48), (984, 27), (985, 14), (1009, 6), (1012, 5), (1025, 11), (1043, 6), (1045, 10), (1055, 1), (1056, 3), (1061, 6), (1068, 2), (1069, 1), (1072, 2), (1073, 21), (1110, 1), (1119, 5), (1123, 6), (1139, 1), (1153, 1), (1155, 16), (1169, 15), (1170, 7), (1171, 13), (1176, 5), (1177, 14), (1179, 18), (1186, 4), (1191, 2), (1212, 26), (1223, 13), (1261, 10), (1273, 4), (1400, 3), (1471, 1), (1488, 12), (1534, 1), (1572, 2), (1629, 2), (1667, 4), (1701, 14), (1791, 7), (1912, 3), (2280, 5)]
def cs98013 : List ℕ := [15, 0, 50, 2, 41, 58, 0, 89, 15, 0, 101, 87, 74, 2, 101, 0, 84, 76, 101, 50, 15, 183, 62, 34, 50, 254, 68, 232, 44, 96, 89, 101, 70, 76, 49, 99, 66, 100, 86, 226, 99, 101, 50, 79, 289, 101, 104, 215, 0, 82, 100, 100, 101, 100, 100, 100, 139, 100, 100, 101, 0, 100, 96, 99, 83, 97, 101, 315, 99, 7, 28, 100, 99, 65, 100, 100, 108, 101, 279, 100, 99, 131, 100, 100, 56, 96, 101, 100, 99, 99, 99, 100, 99, 101, 100, 101, 100, 100, 100, 100, 101, 100, 56, 93, 100, 100, 98, 79, 101, 55, 100, 100, 100, 69, 100, 101, 100, 100, 100, 101, 83, 100, 100, 85, 100, 89, 100, 101, 100, 100, 101, 89, 100, 100, 101, 100, 100, 101, 100, 100, 101, 100, 100, 100, 100, 101, 100, 100, 100, 100, 100, 99, 97, 98]
theorem node98013 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 33 (insert 20 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98013 support demand code
    entries98013 ((insert 33 (insert 20 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries98014 : List (Fin 2295 × ℕ) := [(75, 289), (77, 551), (135, 137), (137, 202), (273, 110), (479, 406), (484, 259), (488, 227), (494, 165), (507, 48), (572, 26), (587, 161), (588, 267), (679, 177), (681, 26), (739, 63), (740, 104), (741, 74), (843, 63), (850, 158), (870, 59), (873, 448), (888, 243), (892, 73), (893, 713), (894, 621), (930, 15), (931, 33), (932, 173), (938, 177), (957, 83), (958, 254), (959, 255), (960, 161), (966, 44), (969, 57), (970, 65), (972, 35), (973, 456), (984, 361), (985, 28), (1010, 63), (1012, 77), (1022, 30), (1025, 31), (1061, 78), (1068, 170), (1073, 162), (1107, 33), (1110, 54), (1119, 63), (1123, 250), (1155, 23), (1162, 3), (1169, 120), (1170, 70), (1171, 190), (1175, 262), (1179, 25), (1186, 223), (1212, 46), (1233, 86), (1261, 187), (1263, 161), (1293, 103), (1297, 75), (1335, 10), (1403, 81), (1488, 65), (1560, 66), (1572, 62), (1594, 231), (1616, 91), (1675, 14), (1705, 49), (1773, 79), (1788, 67), (1791, 14), (1861, 79), (1887, 27), (1912, 25), (1997, 9), (2280, 67)]
def cs98014 : List ℕ := [146, 0, 0, 246, 406, 717, 146, 717, 392, 57, 1000, 147, 960, 679, 1000, 231, 677, 363, 1001, 500, 146, 2248, 495, 985, 57, 2487, 1001, 1647, 782, 525, 205, 935, 1000, 380, 493, 1001, 713, 1000, 1000, 59, 1001, 999, 655, 1001, 2531, 895, 1426, 1662, 0, 269, 1000, 1000, 999, 1001, 1002, 1001, 1000, 1000, 1000, 1001, 0, 756, 637, 1000, 809, 1000, 1001, 2417, 1001, 73, 597, 1001, 1000, 728, 931, 849, 1736, 740, 2410, 1001, 487, 1038, 1000, 932, 404, 637, 1001, 1001, 1097, 1001, 1000, 1000, 1001, 1000, 999, 1002, 1001, 1001, 999, 948, 1001, 1000, 999, 999, 1002, 1002, 999, 932, 1001, 395, 1000, 1000, 967, 895, 1000, 1001, 1001, 1000, 1001, 1001, 810, 1001, 1001, 1001, 1001, 836, 1001, 1000, 1001, 1001, 1000, 1001, 1000, 1000, 1002, 999, 1001, 844, 999, 1000, 1001, 828, 950, 1001, 1001, 984, 1000, 1001, 1000, 1000, 1000, 1001, 856, 1000]
theorem node98014 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 33 (insert 20 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98014 support demand code
    entries98014 ((insert 39 (insert 33 (insert 20 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node98012 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 33 (insert 20 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 33 (insert 20 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    39 node98013 node98014
theorem node98010 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 20 (insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    33 node98011 node98012
theorem node98008 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    20 node98009 node98010
theorem node97997 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)) ((insert 47 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    69 node98007 node98008
def entries98003 : List (Fin 2295 × ℕ) := [(4, 15), (37, 26), (77, 33), (92, 44), (137, 24), (159, 10), (273, 23), (303, 2), (469, 9), (474, 44), (507, 20), (527, 2), (572, 20), (617, 4), (731, 7), (736, 2), (737, 24), (739, 3), (741, 7), (852, 10), (855, 11), (867, 16), (870, 1), (873, 43), (885, 7), (886, 7), (888, 13), (892, 24), (894, 81), (896, 39), (915, 32), (931, 2), (934, 6), (938, 13), (955, 5), (957, 20), (965, 10), (966, 9), (972, 18), (973, 49), (984, 16), (985, 27), (1025, 10), (1043, 6), (1045, 13), (1061, 8), (1071, 1), (1073, 15), (1089, 18), (1090, 3), (1107, 3), (1108, 4), (1119, 9), (1122, 4), (1123, 13), (1128, 4), (1137, 5), (1169, 9), (1171, 14), (1176, 4), (1177, 15), (1179, 19), (1186, 20), (1188, 15), (1189, 49), (1212, 10), (1226, 15), (1232, 6), (1261, 15), (1273, 3), (1279, 1), (1293, 13), (1296, 7), (1313, 3), (1488, 15), (1629, 52), (1701, 7), (1705, 2), (1770, 26), (1852, 10), (1866, 5), (2020, 1), (2021, 1)]
def cs98003 : List ℕ := [34, 100, 49, 52, 77, 74, 5, 100, 100, 20, 101, 60, 99, 94, 100, 0, 98, 99, 262, 59, 100, 154, 0, 99, 81, 340, 100, 363, 33, 0, 99, 100, 100, 100, 75, 100, 0, 87, 59, 235, 54, 100, 0, 99, 374, 101, 208, 0, 37, 85, 99, 100, 25, 100, 101, 141, 101, 100, 100, 100, 39, 100, 101, 76, 97, 99, 101, 267, 100, 100, 39, 100, 83, 70, 93, 85, 164, 100, 183, 100, 74, 87, 100, 70, 58, 86, 101, 99, 100, 99, 100, 100, 100, 100, 86, 100, 104, 99, 100, 100, 101, 100, 80, 91, 101, 99, 100, 85, 101, 75, 99, 100, 100, 100, 97, 99, 102, 100, 100, 100, 98, 97, 99, 99, 101, 77, 100, 100, 100, 101, 82, 82, 100, 100, 100, 100, 99, 95, 99, 101, 100, 101, 100, 100, 100, 100, 94, 100, 100, 101, 100, 100, 98, 90]
theorem node98003 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 18 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98003 support demand code
    entries98003 ((insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 18 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries98005 : List (Fin 2295 × ℕ) := [(4, 28), (37, 169), (72, 50), (75, 21), (77, 37), (137, 68), (273, 34), (421, 26), (475, 61), (491, 23), (507, 49), (572, 80), (579, 12), (585, 63), (617, 6), (618, 55), (731, 5), (737, 50), (741, 62), (743, 20), (833, 15), (844, 52), (852, 80), (860, 10), (867, 84), (873, 113), (884, 23), (886, 19), (888, 7), (892, 36), (894, 153), (896, 37), (921, 6), (931, 18), (932, 5), (934, 20), (938, 26), (957, 21), (966, 40), (970, 29), (972, 4), (973, 118), (984, 59), (985, 68), (1007, 12), (1045, 7), (1061, 11), (1073, 19), (1089, 6), (1090, 11), (1096, 4), (1107, 22), (1114, 6), (1119, 1), (1122, 9), (1123, 41), (1133, 10), (1155, 14), (1160, 4), (1162, 10), (1169, 50), (1171, 26), (1174, 29), (1175, 51), (1179, 4), (1186, 36), (1188, 45), (1212, 41), (1223, 9), (1226, 10), (1261, 31), (1263, 36), (1293, 26), (1316, 16), (1364, 9), (1469, 1), (1500, 32), (1545, 37), (1572, 32), (1591, 13), (1632, 15), (1633, 2), (1674, 43), (1705, 8), (1779, 27), (1785, 17), (1787, 30), (1859, 87), (1887, 29)]
def cs98005 : List ℕ := [148, 28, 0, 61, 144, 256, 153, 255, 252, 49, 239, 180, 255, 140, 226, 0, 206, 123, 337, 256, 255, 475, 0, 255, 49, 801, 255, 613, 88, 111, 190, 144, 231, 255, 80, 255, 1, 255, 256, 6, 255, 256, 113, 255, 613, 257, 519, 0, 93, 141, 256, 450, 255, 256, 255, 256, 255, 256, 255, 255, 42, 256, 255, 172, 242, 257, 256, 519, 256, 256, 211, 255, 256, 219, 255, 203, 402, 255, 354, 255, 186, 277, 256, 255, 139, 174, 255, 242, 256, 256, 256, 256, 255, 256, 251, 256, 255, 256, 256, 256, 256, 256, 243, 248, 207, 256, 256, 198, 256, 131, 256, 256, 256, 224, 256, 256, 256, 255, 256, 256, 240, 256, 251, 256, 254, 194, 256, 256, 255, 256, 254, 248, 257, 255, 256, 256, 256, 206, 255, 257, 254, 257, 254, 255, 255, 256, 232, 256, 256, 256, 256, 256, 254, 213]
theorem node98005 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 18 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98005 support demand code
    entries98005 ((insert 39 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 51 (insert 18 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries98006 : List (Fin 2295 × ℕ) := [(4, 18), (75, 3), (77, 12), (135, 18), (409, 4), (475, 41), (479, 29), (507, 28), (618, 13), (731, 13), (737, 18), (741, 6), (743, 10), (833, 9), (844, 21), (852, 15), (860, 4), (867, 44), (870, 3), (873, 39), (886, 26), (888, 33), (890, 22), (892, 28), (894, 65), (896, 38), (934, 15), (957, 25), (958, 3), (965, 6), (966, 18), (973, 52), (984, 16), (985, 20), (1007, 9), (1011, 3), (1012, 6), (1061, 2), (1068, 3), (1073, 4), (1089, 1), (1090, 6), (1107, 11), (1108, 5), (1120, 2), (1122, 8), (1123, 12), (1131, 2), (1133, 8), (1155, 9), (1169, 17), (1171, 7), (1173, 8), (1175, 18), (1176, 11), (1177, 2), (1179, 17), (1186, 6), (1188, 20), (1212, 14), (1261, 19), (1293, 6), (1364, 1), (1488, 4), (1545, 8), (1560, 10), (1591, 1), (1616, 11), (1657, 19), (1674, 17), (1705, 4), (1780, 3), (1861, 15), (2017, 26)]
def cs98006 : List ℕ := [55, 37, 0, 56, 81, 26, 17, 99, 67, 28, 100, 78, 100, 65, 95, 0, 78, 78, 123, 33, 99, 199, 26, 99, 28, 247, 100, 225, 12, 46, 84, 47, 84, 101, 26, 100, 0, 100, 38, 3, 44, 100, 17, 100, 263, 65, 233, 0, 59, 59, 101, 0, 100, 100, 100, 162, 102, 100, 100, 100, 26, 75, 100, 36, 99, 101, 100, 246, 69, 99, 77, 101, 100, 44, 88, 99, 186, 83, 120, 101, 66, 104, 100, 95, 60, 100, 100, 74, 100, 91, 100, 99, 100, 100, 76, 100, 101, 100, 100, 100, 101, 101, 100, 85, 100, 100, 99, 75, 100, 47, 101, 100, 85, 79, 100, 101, 100, 100, 99, 100, 89, 75, 95, 101, 100, 84, 100, 100, 92, 100, 100, 100, 99, 100, 101, 100, 98, 89, 100, 99, 100, 100, 98, 100, 89, 100, 100, 100, 100, 100, 99, 100, 99, 92]
theorem node98006 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 39 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98006 support demand code
    entries98006 ((insert 51 (insert 39 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 18 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node98004 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 18 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    51 node98005 node98006
theorem node97999 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 18 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    39 node98003 node98004
def entries98001 : List (Fin 2295 × ℕ) := [(4, 90), (37, 99), (75, 127), (137, 57), (273, 68), (409, 9), (468, 71), (479, 38), (491, 25), (572, 31), (618, 35), (691, 14), (731, 24), (741, 13), (743, 10), (813, 10), (844, 31), (852, 58), (867, 20), (870, 45), (873, 12), (888, 77), (892, 92), (894, 170), (896, 17), (906, 7), (915, 129), (917, 26), (931, 31), (938, 79), (957, 41), (965, 37), (966, 34), (972, 5), (973, 133), (984, 51), (985, 46), (1007, 6), (1010, 17), (1011, 4), (1012, 19), (1025, 10), (1048, 8), (1061, 4), (1069, 13), (1073, 11), (1107, 19), (1108, 13), (1113, 6), (1114, 9), (1123, 38), (1133, 1), (1155, 38), (1169, 40), (1171, 37), (1175, 43), (1177, 9), (1179, 25), (1185, 5), (1186, 45), (1188, 49), (1212, 25), (1226, 54), (1258, 4), (1261, 21), (1273, 6), (1293, 9), (1308, 26), (1400, 52), (1488, 37), (1517, 90), (1545, 15), (1572, 2), (1605, 20), (1623, 23), (1629, 19), (1636, 9), (1667, 6), (1701, 40), (1705, 15), (1852, 5), (1887, 20), (1912, 12)]
def cs98001 : List ℕ := [31, 161, 0, 0, 186, 99, 115, 198, 189, 0, 166, 231, 154, 12, 217, 0, 147, 256, 12, 207, 256, 406, 0, 256, 7, 617, 120, 520, 0, 127, 256, 256, 177, 256, 50, 256, 0, 154, 99, 393, 157, 256, 25, 257, 673, 224, 462, 0, 147, 256, 256, 255, 208, 258, 256, 257, 256, 257, 159, 256, 129, 255, 255, 128, 257, 258, 255, 805, 256, 256, 189, 256, 256, 220, 257, 256, 401, 256, 438, 256, 255, 450, 256, 231, 167, 221, 179, 256, 257, 257, 255, 257, 256, 256, 149, 257, 256, 257, 256, 256, 257, 256, 122, 247, 255, 257, 256, 217, 257, 111, 256, 255, 256, 174, 256, 257, 256, 256, 255, 256, 256, 254, 240, 215, 256, 210, 256, 255, 257, 254, 256, 242, 255, 254, 256, 256, 255, 207, 256, 255, 257, 254, 231, 256, 255, 256, 233, 256, 256, 255, 250, 256, 252, 252]
theorem node98001 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98001 support demand code
    entries98001 ((insert 18 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries98002 : List (Fin 2295 × ℕ) := [(4, 28), (37, 45), (75, 44), (137, 3), (273, 27), (386, 1), (409, 15), (479, 39), (490, 12), (491, 2), (585, 10), (618, 8), (731, 15), (736, 4), (740, 8), (741, 18), (743, 8), (844, 46), (852, 10), (867, 40), (870, 18), (873, 15), (886, 30), (888, 25), (892, 26), (894, 66), (896, 7), (925, 5), (931, 14), (938, 32), (957, 35), (965, 9), (966, 21), (973, 49), (984, 18), (985, 20), (1007, 7), (1012, 12), (1068, 2), (1073, 6), (1107, 9), (1108, 7), (1119, 4), (1120, 1), (1123, 14), (1133, 5), (1153, 4), (1155, 17), (1159, 5), (1169, 16), (1173, 19), (1174, 8), (1175, 24), (1179, 12), (1186, 4), (1188, 28), (1204, 1), (1212, 10), (1226, 14), (1228, 10), (1247, 4), (1261, 18), (1263, 26), (1275, 5), (1308, 17), (1323, 1), (1488, 6), (1545, 4), (1591, 1), (1623, 5), (1637, 16), (1667, 2), (1795, 4), (1887, 6), (2007, 2)]
def cs98002 : List ℕ := [46, 29, 21, 1, 98, 45, 14, 99, 100, 0, 100, 32, 72, 32, 89, 16, 37, 93, 15, 70, 100, 196, 0, 101, 4, 311, 44, 197, 16, 44, 94, 101, 44, 101, 68, 100, 4, 54, 61, 23, 86, 101, 2, 100, 220, 101, 192, 0, 57, 59, 101, 101, 100, 100, 100, 101, 100, 100, 72, 100, 35, 101, 100, 49, 89, 100, 101, 250, 101, 100, 100, 101, 100, 94, 77, 80, 181, 100, 145, 101, 82, 191, 100, 87, 57, 57, 100, 61, 100, 100, 100, 99, 101, 100, 60, 100, 101, 100, 101, 100, 101, 100, 75, 91, 100, 100, 100, 81, 100, 26, 99, 99, 100, 65, 100, 100, 100, 100, 99, 99, 96, 100, 94, 99, 100, 84, 99, 99, 98, 100, 100, 97, 99, 100, 100, 100, 100, 79, 99, 100, 100, 100, 94, 99, 77, 99, 100, 100, 100, 97, 100, 100, 90, 95]
theorem node98002 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 18 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs98002 support demand code
    entries98002 ((insert 39 (insert 18 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node98000 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    39 node98001 node98002
theorem node97998 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    18 node97999 node98000
theorem node97971 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)) ((insert 46 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    47 node97997 node97998
def entries97993 : List (Fin 2295 × ℕ) := [(37, 26), (75, 50), (137, 30), (273, 22), (468, 25), (488, 9), (490, 4), (491, 3), (571, 34), (588, 33), (617, 2), (678, 8), (679, 14), (681, 18), (739, 2), (741, 8), (813, 10), (844, 35), (846, 17), (847, 3), (849, 2), (865, 10), (873, 7), (885, 2), (888, 21), (893, 69), (894, 10), (906, 2), (916, 47), (917, 13), (918, 2), (930, 12), (931, 2), (932, 30), (934, 5), (938, 17), (957, 13), (958, 22), (960, 10), (966, 9), (970, 9), (972, 4), (973, 52), (984, 18), (985, 11), (1009, 2), (1010, 6), (1011, 5), (1012, 4), (1025, 10), (1045, 4), (1055, 4), (1061, 10), (1070, 1), (1073, 11), (1107, 8), (1113, 6), (1123, 17), (1155, 9), (1169, 18), (1170, 2), (1171, 16), (1175, 15), (1177, 1), (1178, 4), (1179, 7), (1182, 2), (1184, 5), (1186, 20), (1189, 20), (1212, 7), (1226, 11), (1234, 10), (1261, 7), (1293, 4), (1296, 16), (1297, 1), (1308, 2), (1342, 3), (1372, 26), (1403, 12), (1502, 5), (1511, 9), (1517, 17), (1572, 6), (1629, 21), (1667, 4), (1670, 6), (1675, 9), (1701, 13), (1705, 8), (1744, 2), (1912, 3), (1991, 8), (2280, 2)]
def cs97993 : List ℕ := [35, 71, 23, 11, 29, 60, 33, 100, 71, 0, 99, 58, 96, 49, 88, 0, 94, 100, 100, 81, 124, 138, 35, 100, 27, 289, 99, 201, 0, 61, 100, 100, 99, 100, 59, 99, 69, 99, 99, 184, 101, 99, 47, 100, 270, 99, 10, 186, 32, 67, 100, 191, 99, 101, 101, 99, 99, 99, 100, 101, 0, 100, 99, 100, 97, 100, 98, 314, 100, 100, 100, 100, 100, 87, 69, 99, 119, 100, 199, 100, 99, 153, 100, 79, 89, 66, 99, 100, 101, 100, 101, 100, 99, 100, 89, 99, 101, 100, 99, 100, 101, 100, 100, 100, 99, 91, 99, 92, 100, 47, 100, 100, 100, 96, 99, 100, 99, 100, 100, 100, 83, 99, 101, 99, 100, 90, 100, 99, 99, 100, 99, 99, 99, 99, 99, 100, 100, 91, 100, 99, 100, 99, 95, 99, 99, 98, 100, 99, 95, 100, 99, 99, 99, 95]
theorem node97993 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 20 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97993 support demand code
    entries97993 ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 39 (insert 20 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries97995 : List (Fin 2295 × ℕ) := [(37, 45), (46, 4), (75, 48), (100, 5), (137, 40), (273, 18), (352, 1), (468, 33), (488, 3), (490, 62), (491, 1), (507, 11), (512, 3), (529, 5), (531, 11), (571, 12), (731, 13), (739, 12), (740, 5), (741, 9), (813, 5), (843, 9), (844, 63), (867, 7), (870, 3), (872, 19), (873, 27), (874, 1), (888, 22), (893, 69), (894, 20), (895, 6), (916, 39), (928, 4), (929, 15), (930, 36), (931, 10), (932, 27), (934, 1), (949, 7), (957, 12), (958, 21), (966, 5), (970, 14), (973, 53), (984, 27), (1010, 1), (1011, 1), (1012, 7), (1022, 1), (1047, 2), (1048, 8), (1049, 4), (1061, 6), (1073, 13), (1089, 9), (1107, 7), (1108, 1), (1113, 1), (1123, 13), (1127, 9), (1128, 5), (1154, 8), (1155, 8), (1169, 10), (1172, 13), (1173, 18), (1175, 3), (1177, 19), (1179, 7), (1186, 17), (1188, 18), (1212, 6), (1232, 2), (1261, 4), (1275, 1), (1293, 17), (1372, 17), (1403, 15), (1488, 18), (1560, 9), (1646, 7), (1666, 1), (1667, 1), (1675, 4), (1678, 27), (1701, 12), (1705, 5), (1785, 10)]
def cs97995 : List ℕ := [63, 60, 0, 0, 27, 48, 94, 96, 72, 11, 99, 99, 99, 85, 93, 0, 76, 97, 96, 86, 196, 161, 0, 100, 11, 284, 99, 195, 0, 66, 99, 67, 94, 100, 34, 99, 75, 100, 100, 54, 90, 99, 15, 100, 261, 100, 20, 127, 38, 62, 97, 127, 100, 74, 101, 100, 100, 99, 99, 101, 7, 99, 100, 45, 75, 100, 229, 277, 100, 99, 99, 99, 100, 70, 47, 99, 148, 100, 263, 101, 100, 143, 100, 81, 38, 100, 99, 100, 101, 101, 101, 94, 101, 100, 58, 100, 100, 100, 100, 101, 102, 100, 86, 99, 101, 101, 100, 98, 101, 39, 99, 99, 100, 102, 99, 102, 100, 101, 100, 100, 98, 101, 103, 97, 100, 94, 100, 99, 101, 101, 101, 100, 100, 100, 101, 102, 101, 85, 101, 100, 102, 100, 100, 100, 101, 100, 94, 100, 101, 101, 87, 101, 100, 87]
theorem node97995 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 20 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97995 support demand code
    entries97995 ((insert 39 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 66 (insert 20 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries97996 : List (Fin 2295 × ℕ) := [(46, 21), (75, 27), (100, 14), (135, 1), (137, 21), (273, 32), (468, 49), (490, 29), (507, 10), (529, 19), (569, 1), (571, 21), (587, 12), (617, 9), (678, 4), (679, 23), (681, 37), (739, 8), (740, 3), (741, 7), (813, 3), (844, 51), (865, 26), (867, 5), (873, 18), (888, 4), (893, 66), (894, 14), (916, 35), (931, 10), (932, 32), (933, 14), (934, 1), (938, 19), (957, 15), (958, 26), (960, 9), (966, 9), (971, 5), (973, 54), (984, 15), (985, 13), (1009, 6), (1010, 4), (1011, 5), (1012, 5), (1021, 2), (1025, 5), (1061, 8), (1070, 3), (1073, 11), (1107, 7), (1114, 5), (1123, 30), (1133, 4), (1153, 9), (1155, 4), (1169, 21), (1173, 17), (1175, 17), (1183, 4), (1185, 7), (1186, 25), (1226, 20), (1235, 4), (1261, 6), (1275, 1), (1276, 3), (1293, 12), (1372, 32), (1403, 16), (1488, 13), (1503, 2), (1572, 7), (1619, 5), (1637, 4), (1670, 1), (1675, 5), (1678, 28), (1705, 4), (1785, 5), (1912, 4)]
def cs97996 : List ℕ := [51, 77, 4, 0, 32, 0, 78, 100, 28, 15, 100, 78, 100, 87, 90, 4, 71, 100, 99, 25, 188, 142, 12, 99, 15, 222, 99, 168, 4, 58, 100, 59, 88, 100, 38, 100, 66, 100, 69, 35, 99, 100, 22, 100, 248, 68, 14, 143, 28, 65, 100, 158, 100, 83, 100, 116, 99, 99, 100, 100, 0, 100, 100, 99, 101, 99, 21, 291, 99, 99, 100, 100, 100, 94, 72, 92, 133, 99, 191, 100, 101, 176, 100, 63, 65, 57, 100, 100, 100, 99, 99, 100, 94, 99, 56, 99, 99, 98, 100, 87, 100, 100, 100, 100, 73, 99, 99, 94, 100, 37, 99, 100, 100, 99, 100, 99, 100, 100, 100, 100, 71, 100, 100, 89, 99, 100, 100, 100, 99, 100, 99, 96, 101, 99, 101, 100, 100, 75, 100, 100, 100, 94, 93, 101, 100, 86, 90, 100, 100, 101, 100, 101, 92, 99]
theorem node97996 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 39 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97996 support demand code
    entries97996 ((insert 66 (insert 39 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 20 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node97994 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 20 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    66 node97995 node97996
theorem node97987 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 20 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    39 node97993 node97994
def entries97991 : List (Fin 2295 × ℕ) := [(4, 219), (46, 278), (137, 245), (273, 209), (386, 25), (475, 33), (488, 201), (529, 176), (571, 288), (587, 252), (588, 282), (640, 55), (679, 259), (680, 59), (681, 261), (727, 44), (737, 77), (740, 58), (813, 58), (815, 30), (833, 3), (835, 136), (843, 39), (844, 232), (873, 135), (883, 308), (885, 105), (887, 24), (888, 74), (893, 484), (894, 480), (898, 75), (916, 110), (929, 196), (930, 191), (931, 179), (932, 152), (933, 31), (934, 105), (938, 119), (957, 63), (958, 195), (960, 350), (962, 17), (966, 142), (972, 115), (973, 510), (984, 166), (985, 163), (1009, 78), (1010, 32), (1012, 50), (1022, 29), (1025, 102), (1045, 28), (1061, 59), (1072, 76), (1073, 66), (1110, 30), (1119, 81), (1123, 102), (1125, 26), (1155, 156), (1165, 53), (1169, 214), (1174, 44), (1175, 171), (1178, 27), (1179, 170), (1184, 11), (1185, 43), (1186, 127), (1189, 3), (1212, 149), (1226, 137), (1255, 117), (1258, 33), (1275, 16), (1293, 6), (1296, 319), (1313, 214), (1372, 119), (1403, 19), (1572, 56), (1591, 56), (1623, 61), (1625, 144), (1667, 53), (1675, 286), (1701, 93), (1912, 22), (2160, 34)]
def cs97991 : List ℕ := [446, 222, 120, 247, 553, 734, 278, 235, 755, 0, 286, 33, 999, 866, 1000, 0, 977, 999, 999, 386, 232, 1645, 609, 1000, 319, 2526, 841, 1286, 0, 708, 700, 876, 776, 999, 388, 1000, 484, 1000, 1000, 999, 1000, 1000, 820, 1000, 2141, 999, 480, 2338, 137, 698, 1000, 1850, 991, 907, 999, 1142, 1000, 2163, 1000, 863, 0, 1001, 1001, 1000, 1000, 999, 1000, 2767, 1001, 1001, 1000, 1000, 1000, 1001, 787, 1000, 1410, 818, 2051, 1000, 1000, 1727, 1001, 1000, 888, 690, 999, 999, 1094, 1001, 1000, 1001, 1000, 1000, 1000, 1000, 999, 998, 1937, 1001, 1000, 1000, 999, 1001, 903, 1000, 1000, 925, 1000, 659, 1000, 1000, 1000, 900, 1000, 1000, 1000, 1001, 1000, 1001, 1000, 1001, 1000, 949, 1000, 919, 1000, 1001, 1000, 1000, 1000, 1000, 999, 1001, 1000, 1000, 1000, 949, 1000, 1001, 1000, 1000, 983, 1000, 1001, 1000, 977, 1000, 1000, 1000, 1001, 1000, 1000, 1001]
theorem node97991 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 57 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97991 support demand code
    entries97991 ((insert 20 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 98 (insert 57 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries97992 : List (Fin 2295 × ℕ) := [(4, 18), (20, 3), (46, 44), (137, 18), (273, 21), (488, 31), (498, 21), (507, 11), (529, 9), (571, 21), (587, 34), (588, 17), (678, 2), (679, 4), (680, 7), (681, 37), (738, 7), (739, 16), (743, 6), (813, 21), (842, 2), (843, 1), (844, 4), (873, 15), (874, 21), (883, 41), (885, 11), (886, 10), (888, 4), (893, 61), (894, 29), (916, 21), (917, 14), (920, 3), (927, 2), (928, 14), (931, 19), (932, 23), (933, 11), (944, 4), (958, 24), (962, 7), (966, 14), (973, 50), (984, 22), (985, 17), (1012, 8), (1043, 5), (1047, 2), (1049, 9), (1061, 3), (1070, 2), (1072, 1), (1073, 23), (1123, 3), (1128, 3), (1139, 14), (1141, 1), (1154, 17), (1155, 8), (1160, 1), (1169, 28), (1174, 2), (1175, 19), (1212, 22), (1255, 22), (1261, 13), (1283, 9), (1296, 9), (1308, 4), (1313, 28), (1344, 3), (1403, 9), (1488, 9), (1552, 6), (1560, 8), (1572, 1), (1594, 9), (1680, 15), (1701, 1), (1705, 4), (1785, 11), (1791, 8), (1887, 4), (2003, 7), (2160, 18)]
def cs97992 : List ℕ := [32, 18, 22, 31, 68, 77, 44, 4, 95, 11, 11, 0, 100, 97, 101, 9, 89, 97, 102, 50, 4, 176, 66, 101, 20, 270, 98, 99, 9, 79, 66, 97, 98, 100, 52, 101, 61, 100, 100, 100, 101, 100, 81, 93, 245, 100, 29, 249, 15, 101, 101, 192, 100, 93, 100, 101, 100, 189, 101, 101, 10, 100, 100, 100, 89, 101, 100, 279, 100, 101, 100, 101, 100, 76, 76, 92, 119, 100, 205, 100, 99, 161, 100, 99, 100, 64, 100, 100, 99, 101, 100, 100, 101, 101, 66, 100, 100, 99, 3, 101, 99, 100, 99, 101, 99, 99, 100, 78, 99, 37, 100, 100, 100, 99, 60, 99, 101, 100, 100, 99, 100, 75, 99, 79, 100, 100, 99, 100, 100, 100, 100, 99, 100, 100, 99, 94, 99, 80, 100, 100, 99, 100, 100, 100, 100, 100, 100, 100, 100, 100, 93, 99, 101, 81]
theorem node97992 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 20 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97992 support demand code
    entries97992 ((insert 98 (insert 20 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 57 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node97989 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 20 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 57 (insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    98 node97991 node97992
def entries97990 : List (Fin 2295 × ℕ) := [(4, 83), (37, 92), (46, 63), (75, 12), (77, 83), (83, 26), (137, 133), (273, 49), (475, 107), (488, 9), (571, 74), (587, 27), (588, 42), (617, 23), (640, 17), (739, 8), (741, 18), (813, 5), (844, 43), (846, 28), (867, 36), (873, 34), (874, 43), (883, 35), (887, 16), (888, 68), (893, 171), (916, 137), (917, 11), (931, 25), (932, 23), (938, 43), (957, 74), (958, 48), (960, 10), (966, 9), (969, 17), (972, 24), (973, 130), (984, 55), (985, 24), (1009, 2), (1011, 5), (1012, 32), (1025, 19), (1061, 9), (1073, 16), (1108, 2), (1111, 4), (1113, 5), (1114, 17), (1123, 54), (1125, 7), (1126, 12), (1133, 2), (1153, 4), (1155, 34), (1169, 68), (1171, 12), (1175, 57), (1179, 23), (1186, 33), (1188, 15), (1226, 76), (1251, 26), (1255, 36), (1258, 14), (1261, 16), (1275, 1), (1313, 14), (1316, 9), (1328, 6), (1344, 25), (1372, 32), (1403, 41), (1454, 6), (1488, 1), (1572, 2), (1616, 8), (1623, 13), (1652, 3), (1667, 28), (1675, 2), (1701, 32), (1705, 21), (1991, 27), (2280, 31)]
def cs97990 : List ℕ := [57, 111, 36, 121, 133, 115, 63, 71, 189, 0, 133, 133, 173, 145, 257, 0, 168, 257, 258, 250, 79, 284, 100, 256, 0, 737, 256, 235, 83, 108, 95, 255, 256, 256, 121, 256, 171, 257, 175, 256, 255, 256, 102, 255, 664, 255, 0, 280, 91, 112, 258, 379, 256, 246, 256, 257, 257, 0, 257, 255, 0, 255, 239, 225, 256, 256, 256, 739, 255, 256, 256, 256, 256, 223, 194, 198, 390, 256, 496, 255, 182, 471, 255, 256, 197, 143, 255, 256, 255, 228, 255, 255, 256, 256, 256, 255, 255, 255, 256, 256, 255, 255, 137, 257, 256, 255, 255, 255, 256, 89, 255, 255, 257, 198, 255, 255, 256, 256, 257, 255, 246, 255, 257, 248, 256, 248, 255, 255, 254, 256, 255, 255, 255, 255, 255, 256, 256, 221, 256, 255, 256, 231, 237, 256, 255, 247, 242, 255, 255, 256, 255, 249, 239, 206]
theorem node97990 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 20 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97990 support demand code
    entries97990 ((insert 57 (insert 20 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node97988 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 20 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    57 node97989 node97990
theorem node97979 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 47 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    20 node97987 node97988
def entries97985 : List (Fin 2295 × ℕ) := [(4, 23), (37, 40), (77, 49), (137, 20), (179, 3), (244, 19), (273, 16), (386, 26), (421, 17), (469, 14), (529, 6), (571, 36), (676, 3), (737, 19), (740, 16), (815, 1), (844, 51), (867, 14), (873, 12), (874, 8), (883, 1), (885, 12), (887, 1), (888, 23), (894, 22), (915, 2), (916, 22), (921, 13), (932, 35), (934, 8), (944, 2), (946, 29), (966, 14), (972, 14), (973, 48), (984, 12), (985, 10), (1007, 4), (1009, 14), (1010, 1), (1011, 7), (1012, 12), (1022, 9), (1044, 3), (1048, 4), (1053, 1), (1060, 1), (1061, 1), (1069, 3), (1072, 1), (1073, 15), (1077, 1), (1108, 1), (1123, 10), (1133, 10), (1155, 10), (1165, 8), (1169, 19), (1173, 19), (1174, 4), (1175, 10), (1178, 1), (1179, 12), (1183, 2), (1185, 9), (1186, 11), (1188, 20), (1201, 8), (1212, 19), (1226, 27), (1258, 10), (1261, 6), (1273, 1), (1275, 1), (1281, 7), (1285, 14), (1354, 1), (1372, 11), (1403, 6), (1502, 4), (1545, 17), (1572, 3), (1591, 1), (1623, 15), (1625, 36), (1665, 1), (1674, 11), (1675, 10), (1859, 28)]
def cs97985 : List ℕ := [86, 45, 7, 21, 31, 76, 39, 100, 85, 0, 73, 63, 100, 59, 101, 0, 68, 101, 100, 100, 100, 51, 3, 100, 35, 277, 84, 99, 49, 79, 99, 101, 44, 101, 49, 100, 0, 100, 92, 100, 99, 100, 23, 100, 184, 99, 22, 0, 79, 92, 99, 132, 100, 100, 100, 99, 100, 100, 99, 99, 2, 99, 99, 100, 101, 99, 100, 217, 99, 191, 100, 99, 100, 99, 77, 99, 174, 82, 183, 100, 99, 178, 99, 100, 65, 83, 99, 99, 142, 99, 100, 99, 133, 100, 88, 100, 99, 101, 238, 100, 100, 99, 100, 100, 100, 97, 100, 92, 100, 67, 100, 100, 100, 101, 100, 100, 100, 99, 100, 100, 99, 100, 101, 92, 100, 100, 101, 100, 100, 101, 100, 98, 100, 100, 100, 101, 92, 81, 101, 99, 91, 92, 97, 100, 100, 87, 101, 98, 100, 101, 101, 100, 100, 101]
theorem node97985 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 69 (insert 92 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97985 support demand code
    entries97985 ((insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 98 (insert 69 (insert 92 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries97986 : List (Fin 2295 × ℕ) := [(4, 66), (37, 154), (72, 6), (75, 7), (77, 96), (132, 4), (137, 63), (273, 13), (468, 53), (498, 22), (529, 1), (571, 32), (617, 26), (630, 85), (632, 42), (730, 19), (731, 133), (737, 3), (739, 2), (741, 61), (743, 39), (776, 8), (812, 2), (813, 14), (817, 18), (844, 117), (855, 29), (867, 51), (873, 46), (874, 96), (883, 29), (885, 22), (888, 29), (894, 51), (915, 60), (916, 75), (917, 9), (925, 24), (932, 83), (934, 33), (962, 2), (966, 66), (970, 3), (973, 132), (984, 37), (985, 42), (1005, 3), (1007, 3), (1009, 12), (1012, 26), (1049, 21), (1073, 27), (1107, 8), (1108, 20), (1123, 38), (1125, 4), (1133, 32), (1139, 13), (1155, 30), (1169, 59), (1173, 46), (1174, 18), (1175, 47), (1184, 4), (1186, 25), (1199, 4), (1201, 10), (1212, 19), (1241, 17), (1276, 11), (1308, 11), (1344, 22), (1372, 9), (1403, 4), (1483, 2), (1545, 40), (1552, 12), (1560, 15), (1572, 13), (1623, 42), (1636, 13), (1666, 16), (1701, 18), (1705, 20), (1773, 59), (1785, 9), (1859, 34), (1991, 26), (2130, 40)]
def cs97986 : List ℕ := [151, 133, 0, 0, 80, 231, 97, 204, 256, 40, 169, 87, 255, 206, 257, 0, 205, 256, 255, 255, 255, 140, 0, 256, 40, 805, 182, 136, 102, 220, 255, 255, 111, 256, 121, 255, 0, 255, 256, 255, 255, 255, 71, 255, 601, 256, 51, 0, 192, 250, 254, 335, 256, 222, 256, 255, 255, 255, 255, 256, 84, 254, 217, 229, 256, 255, 256, 516, 255, 478, 254, 254, 257, 255, 182, 186, 329, 254, 481, 255, 255, 419, 256, 256, 221, 151, 256, 256, 254, 254, 256, 257, 282, 255, 166, 256, 256, 255, 78, 256, 253, 256, 257, 255, 227, 254, 257, 213, 255, 65, 256, 256, 256, 256, 230, 254, 255, 255, 256, 256, 255, 256, 255, 249, 256, 249, 256, 257, 207, 254, 233, 256, 256, 256, 255, 255, 256, 204, 257, 255, 213, 256, 256, 255, 217, 226, 256, 255, 256, 256, 256, 255, 206, 234]
theorem node97986 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97986 support demand code
    entries97986 ((insert 98 (insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 92 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node97983 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 69 (insert 92 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154))
    98 node97985 node97986
def entries97984 : List (Fin 2295 × ℕ) := [(4, 211), (37, 409), (46, 60), (72, 78), (75, 340), (132, 18), (137, 169), (273, 165), (475, 56), (484, 84), (498, 202), (569, 140), (572, 350), (617, 67), (736, 81), (740, 49), (741, 99), (743, 17), (843, 8), (844, 329), (855, 106), (867, 449), (873, 342), (885, 227), (886, 39), (888, 192), (894, 188), (915, 268), (916, 305), (922, 2), (931, 8), (932, 322), (933, 1), (934, 83), (938, 139), (957, 52), (960, 135), (965, 148), (966, 221), (970, 21), (972, 82), (973, 493), (984, 129), (985, 260), (1009, 50), (1010, 29), (1011, 3), (1012, 19), (1025, 9), (1045, 25), (1047, 2), (1068, 27), (1073, 144), (1107, 25), (1108, 53), (1119, 128), (1123, 177), (1143, 16), (1155, 137), (1169, 275), (1171, 7), (1173, 174), (1174, 5), (1175, 198), (1179, 138), (1186, 87), (1188, 64), (1201, 178), (1212, 68), (1226, 130), (1228, 24), (1241, 96), (1261, 219), (1293, 32), (1308, 57), (1323, 91), (1324, 49), (1335, 3), (1545, 138), (1560, 25), (1572, 38), (1616, 45), (1623, 71), (1675, 134), (1701, 127), (1859, 223), (1887, 27), (1991, 117), (2280, 82)]
def cs97984 : List ℕ := [552, 389, 0, 56, 389, 1000, 283, 552, 1000, 0, 1001, 279, 1000, 569, 1001, 0, 760, 778, 1000, 1000, 1001, 900, 82, 1001, 0, 3358, 1000, 860, 78, 616, 818, 1000, 610, 1000, 555, 1000, 0, 1000, 487, 1000, 1000, 1000, 216, 1000, 2212, 1000, 188, 82, 194, 1000, 1000, 1522, 806, 1000, 999, 1000, 1001, 579, 667, 1000, 307, 1000, 1000, 556, 999, 1000, 1000, 2419, 933, 194, 1000, 1000, 1000, 507, 747, 875, 1400, 1001, 1659, 1000, 852, 1005, 1000, 896, 358, 876, 1000, 999, 999, 1001, 1000, 1000, 1474, 999, 864, 870, 999, 998, 999, 999, 1000, 1000, 1000, 999, 999, 999, 1000, 766, 999, 400, 1000, 998, 1000, 998, 999, 1001, 1001, 999, 999, 999, 935, 998, 779, 1001, 999, 999, 998, 1000, 1000, 999, 1000, 1000, 1000, 998, 1000, 998, 924, 960, 999, 999, 999, 999, 984, 1001, 943, 1000, 998, 1000, 999, 928, 999, 953, 841, 950]
theorem node97984 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97984 support demand code
    entries97984 ((insert 69 (insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 92 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node97981 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 92 (insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    69 node97983 node97984
def entries97982 : List (Fin 2295 × ℕ) := [(4, 2026), (37, 4905), (46, 2051), (72, 669), (75, 2305), (77, 672), (137, 1686), (273, 2704), (421, 2409), (475, 215), (498, 1585), (507, 1113), (514, 1952), (569, 1126), (571, 3238), (731, 1635), (741, 2324), (833, 283), (844, 3600), (852, 687), (855, 792), (867, 2125), (873, 3770), (883, 570), (885, 2087), (886, 197), (887, 1218), (894, 2402), (900, 896), (915, 1990), (916, 897), (917, 1776), (931, 2462), (933, 895), (938, 1262), (945, 38), (946, 1473), (957, 1210), (958, 307), (966, 2445), (970, 374), (972, 1107), (973, 4893), (984, 1814), (985, 1794), (1008, 126), (1011, 336), (1045, 520), (1052, 674), (1069, 369), (1073, 1819), (1082, 66), (1096, 344), (1107, 279), (1123, 1309), (1133, 444), (1139, 923), (1143, 143), (1152, 20), (1153, 619), (1155, 1305), (1169, 2493), (1171, 298), (1173, 2316), (1175, 2125), (1179, 595), (1186, 1564), (1212, 599), (1232, 32), (1241, 1162), (1261, 1761), (1263, 1484), (1273, 277), (1286, 486), (1372, 662), (1399, 330), (1523, 1188), (1545, 644), (1605, 1310), (1616, 167), (1623, 1585), (1625, 426), (1637, 1173), (1675, 1104), (1701, 1095), (1780, 147), (1859, 2323), (1887, 225)]
def cs97982 : List ℕ := [5923, 2026, 1173, 215, 3886, 8020, 4374, 6610, 10000, 1113, 10000, 2538, 9999, 5605, 10000, 1173, 8815, 7677, 10001, 9361, 10000, 10519, 0, 10000, 1113, 30310, 10001, 10286, 2514, 5886, 9673, 10000, 6355, 10000, 5614, 10000, 0, 7833, 7419, 10000, 9765, 9999, 3056, 9999, 23097, 10001, 4573, 0, 4456, 10000, 9999, 16271, 9999, 10000, 10001, 10000, 10000, 7023, 10001, 10001, 2187, 10000, 9999, 8385, 10001, 10000, 10001, 24717, 9999, 10000, 10000, 10001, 9999, 6616, 7919, 7496, 11925, 10000, 18659, 9999, 4456, 15167, 10000, 9999, 4815, 7717, 10002, 10000, 10000, 9998, 10000, 9999, 0, 9999, 7899, 10001, 10001, 10001, 10000, 9999, 9999, 10000, 7439, 9904, 8091, 10000, 10000, 7879, 10000, 4142, 9999, 10000, 10000, 6995, 9999, 9999, 10000, 9999, 10000, 10000, 8873, 10000, 8220, 8432, 9999, 10000, 10001, 10001, 10001, 10001, 8112, 9511, 10001, 9999, 10000, 10000, 10001, 8501, 9997, 9999, 9999, 10001, 9935, 9999, 10000, 10001, 9999, 9549, 9999, 10000, 9999, 9820, 8495, 9999]
theorem node97982 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97982 support demand code
    entries97982 ((insert 92 (insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node97980 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    92 node97981 node97982
theorem node97973 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 51 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    47 node97979 node97980
def entries97977 : List (Fin 2295 × ℕ) := [(4, 39), (20, 6), (70, 3), (75, 6), (77, 17), (135, 12), (353, 6), (387, 17), (468, 49), (527, 5), (531, 32), (587, 34), (588, 7), (617, 13), (727, 4), (731, 5), (740, 28), (835, 6), (843, 9), (844, 29), (847, 22), (855, 1), (867, 12), (874, 15), (883, 5), (885, 7), (888, 16), (893, 50), (894, 9), (898, 5), (913, 16), (916, 45), (917, 3), (925, 11), (929, 24), (930, 59), (931, 8), (932, 20), (933, 15), (934, 3), (938, 22), (958, 14), (960, 40), (962, 4), (966, 15), (972, 11), (973, 53), (984, 14), (985, 10), (1007, 1), (1009, 9), (1010, 2), (1012, 11), (1025, 6), (1045, 2), (1061, 2), (1072, 8), (1073, 15), (1110, 1), (1114, 4), (1123, 12), (1153, 3), (1155, 14), (1165, 11), (1169, 21), (1171, 12), (1173, 5), (1175, 16), (1179, 1), (1184, 17), (1185, 2), (1186, 25), (1188, 4), (1212, 1), (1261, 2), (1275, 5), (1372, 14), (1572, 4), (1591, 11), (1623, 9), (1629, 9), (1665, 5), (1674, 15), (1675, 19), (1773, 1), (1997, 16)]
def cs97977 : List ℕ := [29, 88, 22, 22, 39, 1, 16, 100, 45, 16, 66, 65, 100, 67, 100, 0, 82, 101, 100, 16, 99, 103, 46, 100, 16, 249, 64, 102, 17, 82, 99, 101, 77, 101, 54, 100, 50, 100, 100, 100, 46, 100, 76, 102, 221, 55, 9, 215, 9, 58, 99, 0, 100, 101, 101, 99, 100, 101, 101, 100, 11, 101, 99, 32, 102, 100, 117, 273, 95, 99, 100, 101, 100, 43, 76, 102, 133, 100, 264, 100, 101, 196, 100, 100, 43, 64, 100, 102, 100, 100, 100, 101, 100, 99, 101, 99, 101, 100, 245, 91, 100, 100, 50, 99, 101, 99, 101, 97, 99, 61, 101, 101, 100, 83, 99, 100, 100, 100, 101, 100, 81, 101, 100, 89, 95, 100, 100, 100, 99, 100, 100, 92, 101, 100, 100, 100, 101, 77, 100, 99, 99, 83, 95, 100, 100, 96, 90, 100, 100, 100, 91, 100, 100, 100]
theorem node97977 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 47 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97977 support demand code
    entries97977 ((insert 51 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 98 (insert 47 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries97978 : List (Fin 2295 × ℕ) := [(4, 299), (20, 155), (35, 181), (75, 55), (77, 556), (135, 151), (409, 108), (468, 334), (488, 188), (514, 182), (531, 189), (569, 251), (587, 345), (617, 138), (738, 11), (739, 52), (740, 8), (741, 137), (812, 38), (813, 195), (843, 115), (844, 325), (850, 57), (867, 93), (869, 8), (873, 111), (874, 297), (883, 199), (885, 68), (888, 126), (893, 648), (894, 12), (916, 472), (917, 188), (925, 160), (928, 223), (931, 239), (932, 174), (933, 53), (958, 150), (961, 57), (962, 42), (966, 262), (970, 10), (973, 548), (984, 190), (985, 110), (1012, 55), (1021, 11), (1022, 53), (1043, 27), (1055, 38), (1061, 97), (1073, 243), (1094, 37), (1110, 94), (1113, 6), (1123, 11), (1126, 44), (1139, 165), (1155, 145), (1169, 198), (1171, 177), (1173, 65), (1175, 167), (1184, 36), (1185, 97), (1186, 210), (1219, 65), (1261, 119), (1308, 12), (1403, 104), (1488, 63), (1560, 22), (1572, 16), (1636, 26), (1648, 221), (1773, 90), (1791, 38), (1887, 42), (1912, 2), (1991, 89), (1997, 30), (2292, 293)]
def cs97978 : List ℕ := [325, 698, 0, 307, 299, 369, 90, 724, 635, 30, 886, 437, 999, 933, 1000, 0, 999, 999, 1000, 126, 999, 805, 345, 849, 30, 2790, 593, 1000, 556, 804, 999, 1000, 535, 999, 297, 1001, 648, 1000, 1000, 1000, 466, 999, 617, 1000, 2223, 796, 12, 1948, 514, 717, 771, 0, 951, 1000, 1001, 999, 1001, 1000, 1000, 1001, 160, 1000, 894, 818, 747, 1000, 1000, 2177, 909, 1000, 972, 1001, 1000, 869, 698, 1000, 1253, 1001, 3049, 1000, 1001, 1550, 1000, 926, 607, 718, 1001, 1000, 1001, 1000, 1000, 1000, 1002, 1001, 801, 1000, 999, 1001, 232, 1001, 1000, 1000, 1000, 1000, 1001, 1001, 1001, 940, 1001, 464, 1000, 1000, 1000, 1001, 948, 1001, 1000, 1000, 1000, 1000, 1000, 899, 1001, 1000, 1000, 999, 1001, 1000, 975, 1001, 1000, 966, 1000, 1000, 1000, 1000, 1000, 810, 1000, 1000, 976, 1000, 999, 1001, 932, 1000, 931, 1000, 1000, 1000, 920, 963, 858, 1000]
theorem node97978 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 51 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97978 support demand code
    entries97978 ((insert 98 (insert 51 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 47 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node97975 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    98 node97977 node97978
def entries97976 : List (Fin 2295 × ℕ) := [(4, 120), (46, 52), (77, 36), (135, 62), (409, 46), (421, 3), (475, 52), (527, 45), (569, 25), (617, 13), (632, 21), (730, 22), (731, 76), (737, 50), (741, 9), (844, 84), (867, 98), (872, 14), (873, 90), (883, 22), (885, 40), (886, 35), (887, 58), (888, 75), (915, 9), (916, 116), (918, 22), (925, 11), (931, 11), (932, 10), (938, 35), (957, 24), (959, 14), (965, 54), (966, 60), (970, 25), (973, 130), (984, 55), (985, 19), (1007, 19), (1011, 4), (1012, 12), (1043, 6), (1060, 1), (1061, 35), (1068, 13), (1073, 19), (1082, 35), (1107, 14), (1108, 4), (1120, 11), (1123, 55), (1125, 10), (1130, 3), (1132, 2), (1133, 6), (1153, 2), (1169, 52), (1172, 13), (1173, 41), (1174, 4), (1175, 44), (1176, 13), (1179, 40), (1186, 54), (1188, 47), (1232, 22), (1252, 9), (1261, 37), (1276, 10), (1293, 7), (1399, 4), (1545, 24), (1591, 11), (1605, 20), (1616, 16), (1623, 47), (1625, 11), (1634, 2), (1675, 48), (1861, 74), (1991, 28), (2139, 1)]
def cs97976 : List ℕ := [158, 120, 0, 126, 120, 0, 52, 158, 120, 0, 256, 126, 255, 104, 256, 0, 233, 256, 255, 133, 256, 100, 0, 256, 0, 671, 236, 172, 36, 132, 255, 256, 137, 256, 102, 230, 0, 256, 38, 256, 21, 255, 48, 255, 471, 80, 0, 2, 165, 162, 254, 0, 242, 253, 256, 255, 256, 118, 255, 256, 55, 225, 256, 153, 256, 255, 256, 560, 238, 255, 255, 255, 257, 219, 160, 257, 450, 236, 390, 256, 255, 300, 257, 241, 186, 256, 239, 257, 255, 255, 257, 256, 255, 256, 188, 256, 257, 256, 255, 256, 255, 256, 256, 246, 255, 256, 256, 193, 256, 94, 255, 257, 256, 255, 256, 255, 257, 257, 256, 256, 256, 235, 255, 256, 257, 236, 255, 256, 255, 257, 256, 256, 257, 257, 256, 257, 238, 248, 256, 256, 256, 256, 255, 256, 233, 255, 257, 253, 256, 256, 256, 256, 245, 233]
theorem node97976 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 51 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97976 support demand code
    entries97976 ((insert 47 (insert 51 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node97974 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    47 node97975 node97976
theorem node97972 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    51 node97973 node97974
theorem node97945 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)) ((insert 21 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    46 node97971 node97972
def entries97963 : List (Fin 2295 × ℕ) := [(4, 1869), (72, 3371), (77, 919), (132, 3288), (135, 1665), (273, 1465), (386, 4516), (409, 69), (421, 894), (469, 2028), (475, 2733), (479, 705), (531, 265), (587, 1437), (588, 2164), (618, 1124), (619, 444), (621, 319), (731, 1135), (736, 3106), (737, 750), (740, 602), (743, 248), (844, 4793), (867, 1865), (870, 612), (872, 763), (873, 2716), (878, 778), (883, 1932), (884, 99), (887, 4451), (888, 2829), (894, 1625), (898, 689), (915, 413), (916, 2625), (918, 564), (922, 407), (929, 1528), (930, 3568), (938, 2761), (949, 1876), (960, 5212), (965, 955), (966, 2138), (970, 867), (973, 5653), (984, 1529), (1007, 39), (1010, 97), (1011, 447), (1012, 733), (1043, 421), (1048, 496), (1049, 1091), (1053, 343), (1055, 416), (1061, 520), (1073, 732), (1090, 136), (1108, 73), (1120, 739), (1123, 163), (1132, 669), (1133, 729), (1155, 869), (1159, 37), (1165, 1118), (1169, 1577), (1172, 467), (1173, 2253), (1177, 1176), (1179, 1002), (1184, 1057), (1185, 1036), (1186, 2093), (1188, 726), (1226, 414), (1258, 157), (1261, 711), (1275, 348), (1281, 469), (1293, 11), (1372, 4), (1516, 50), (1545, 985), (1591, 250), (1605, 715), (1623, 427), (1629, 90), (1634, 614), (1636, 209), (1657, 983), (1701, 432), (1861, 1021)]
def cs97963 : List ℕ := [7266, 4880, 469, 4223, 3557, 0, 0, 9999, 2852, 0, 7266, 7846, 9999, 3748, 7920, 0, 9547, 9375, 9999, 7280, 9999, 1625, 4290, 10000, 2497, 25098, 10000, 8985, 4290, 0, 9999, 10000, 8910, 10000, 3838, 10000, 0, 9999, 10000, 9999, 3993, 10000, 3601, 10000, 14409, 10001, 5978, 10000, 2990, 5227, 9999, 10000, 7166, 10000, 10000, 9999, 10000, 10000, 10000, 9999, 2388, 10001, 10000, 8194, 10000, 10000, 25485, 21126, 9566, 10001, 9999, 10000, 10000, 7373, 5848, 10000, 19331, 10000, 24040, 10000, 10001, 22008, 10000, 10000, 5363, 9999, 8372, 10000, 10000, 9999, 9999, 10000, 10000, 10000, 10000, 10000, 10000, 9999, 23963, 10000, 10000, 9999, 6054, 9999, 10000, 9999, 10001, 8742, 9999, 5188, 10000, 9999, 10000, 6699, 9999, 9999, 9999, 10000, 10001, 9999, 10000, 9999, 9999, 9069, 10000, 10000, 9854, 9999, 10000, 9998, 9999, 9020, 10000, 9999, 9999, 9999, 9999, 9324, 9999, 10000, 9999, 9999, 9999, 9999, 7488, 9552, 9999, 9999, 9998, 9999, 9468, 9999, 9999, 9999]
theorem node97963 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97963 support demand code
    entries97963 ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 66 (insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries97969 : List (Fin 2295 × ℕ) := [(4, 19), (77, 13), (137, 26), (150, 29), (151, 7), (179, 31), (248, 31), (273, 18), (386, 14), (387, 11), (409, 2), (469, 31), (471, 4), (479, 12), (482, 35), (542, 12), (571, 20), (587, 20), (588, 7), (617, 22), (618, 22), (679, 17), (844, 26), (860, 8), (867, 3), (869, 11), (883, 3), (885, 8), (894, 15), (898, 1), (913, 21), (915, 61), (916, 34), (917, 27), (921, 7), (922, 9), (930, 17), (934, 5), (938, 40), (946, 4), (957, 8), (958, 6), (960, 26), (966, 14), (972, 17), (973, 52), (984, 15), (985, 9), (1009, 8), (1011, 2), (1012, 10), (1024, 3), (1025, 9), (1055, 2), (1061, 4), (1072, 1), (1073, 13), (1107, 1), (1114, 3), (1118, 12), (1123, 14), (1125, 6), (1155, 16), (1165, 9), (1169, 23), (1171, 17), (1175, 23), (1179, 10), (1184, 6), (1185, 3), (1186, 17), (1188, 3), (1212, 8), (1226, 25), (1240, 13), (1258, 4), (1261, 8), (1281, 24), (1308, 5), (1403, 4), (1404, 2), (1511, 6), (1517, 28), (1545, 3), (1591, 3), (1630, 1), (1667, 3), (1670, 2), (1744, 1), (1912, 3)]
def cs97969 : List ℕ := [50, 56, 28, 30, 37, 41, 34, 97, 33, 0, 22, 100, 99, 0, 50, 0, 100, 99, 100, 58, 99, 15, 59, 99, 100, 177, 80, 168, 13, 65, 100, 281, 73, 99, 32, 100, 0, 99, 95, 319, 65, 99, 27, 99, 246, 87, 69, 100, 69, 100, 100, 100, 67, 100, 101, 100, 99, 100, 100, 99, 61, 100, 100, 99, 92, 101, 44, 341, 99, 100, 100, 99, 100, 100, 91, 101, 147, 99, 171, 98, 101, 198, 100, 98, 100, 80, 95, 99, 112, 99, 99, 101, 99, 98, 99, 102, 99, 99, 238, 91, 98, 100, 61, 99, 102, 101, 99, 98, 98, 61, 100, 101, 99, 64, 100, 99, 98, 98, 99, 103, 99, 101, 99, 87, 96, 100, 101, 102, 100, 98, 96, 101, 100, 99, 98, 96, 101, 87, 97, 100, 96, 92, 99, 99, 98, 101, 89, 100, 99, 100, 93, 100, 99, 98]
theorem node97969 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 39 (insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97969 support demand code
    entries97969 ((insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 31 (insert 39 (insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries97970 : List (Fin 2295 × ℕ) := [(4, 60), (36, 4), (77, 60), (137, 9), (151, 6), (179, 50), (273, 32), (386, 84), (498, 18), (527, 30), (571, 50), (587, 4), (588, 59), (617, 25), (632, 18), (679, 13), (681, 10), (736, 50), (740, 21), (833, 22), (835, 20), (844, 35), (847, 33), (858, 66), (873, 24), (874, 32), (885, 66), (894, 31), (898, 46), (906, 52), (916, 46), (931, 21), (932, 38), (933, 52), (934, 13), (938, 129), (946, 6), (958, 7), (960, 79), (966, 39), (972, 24), (973, 116), (984, 34), (985, 32), (1006, 6), (1009, 6), (1011, 22), (1012, 39), (1025, 32), (1044, 28), (1045, 14), (1052, 14), (1053, 24), (1055, 3), (1061, 13), (1072, 19), (1073, 51), (1081, 10), (1143, 9), (1152, 7), (1153, 27), (1155, 36), (1169, 60), (1171, 60), (1175, 5), (1178, 4), (1182, 33), (1183, 2), (1185, 2), (1186, 47), (1188, 43), (1191, 14), (1212, 34), (1217, 104), (1223, 28), (1226, 29), (1232, 10), (1261, 11), (1275, 3), (1545, 32), (1591, 33), (1625, 11), (1665, 43), (1701, 8), (1714, 21), (1719, 23), (1831, 100), (1861, 24)]
def cs97970 : List ℕ := [205, 60, 158, 38, 102, 122, 66, 245, 120, 21, 84, 156, 257, 56, 134, 21, 252, 175, 256, 79, 257, 31, 182, 257, 73, 571, 192, 293, 60, 102, 257, 54, 142, 257, 229, 255, 21, 255, 256, 323, 227, 255, 86, 257, 391, 218, 59, 255, 151, 255, 255, 255, 175, 256, 255, 260, 257, 254, 255, 256, 0, 256, 255, 254, 255, 256, 64, 542, 255, 255, 255, 256, 255, 255, 240, 255, 319, 257, 440, 256, 255, 568, 255, 256, 256, 251, 253, 257, 256, 256, 256, 256, 256, 255, 256, 256, 257, 257, 640, 228, 255, 257, 256, 255, 245, 256, 257, 215, 255, 111, 258, 256, 256, 256, 256, 255, 256, 256, 257, 255, 257, 257, 255, 234, 257, 248, 256, 256, 256, 257, 256, 209, 257, 257, 254, 256, 256, 197, 257, 256, 256, 209, 257, 256, 208, 209, 257, 257, 239, 257, 200, 235, 257, 250]
theorem node97970 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97970 support demand code
    entries97970 ((insert 31 (insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node97965 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 39 (insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    31 node97969 node97970
def entries97967 : List (Fin 2295 × ℕ) := [(36, 77), (77, 267), (86, 106), (137, 127), (179, 183), (273, 130), (386, 426), (387, 63), (479, 108), (496, 141), (571, 206), (587, 193), (618, 229), (619, 87), (640, 86), (679, 16), (680, 23), (681, 75), (727, 78), (736, 422), (737, 45), (738, 70), (815, 49), (844, 289), (852, 134), (858, 242), (869, 13), (873, 193), (874, 202), (885, 74), (886, 2), (894, 93), (898, 179), (900, 49), (916, 133), (925, 73), (929, 15), (932, 178), (933, 154), (934, 86), (938, 454), (957, 71), (958, 69), (960, 227), (966, 70), (972, 177), (973, 516), (984, 128), (985, 93), (1007, 3), (1009, 134), (1011, 34), (1012, 123), (1045, 14), (1061, 69), (1069, 221), (1072, 104), (1073, 213), (1075, 86), (1082, 75), (1113, 14), (1114, 35), (1123, 16), (1151, 23), (1152, 14), (1155, 115), (1165, 37), (1169, 219), (1171, 124), (1173, 7), (1175, 133), (1179, 28), (1182, 49), (1183, 32), (1184, 116), (1186, 197), (1212, 68), (1223, 184), (1226, 172), (1258, 27), (1261, 111), (1275, 72), (1342, 21), (1400, 24), (1477, 6), (1545, 37), (1591, 60), (1619, 243), (1625, 25), (1701, 43), (1831, 394), (1861, 285)]
def cs97967 : List ℕ := [758, 0, 0, 285, 426, 77, 242, 1000, 325, 243, 552, 588, 1000, 395, 267, 0, 672, 687, 1000, 206, 1000, 93, 555, 1000, 243, 1437, 642, 960, 267, 208, 982, 531, 924, 999, 177, 999, 0, 1001, 1000, 263, 1000, 1000, 193, 1000, 1478, 864, 1000, 1000, 619, 1000, 1001, 998, 797, 1001, 1000, 1121, 1002, 999, 1001, 1857, 75, 999, 1001, 999, 1001, 1000, 174, 1975, 999, 1000, 1000, 1000, 1000, 957, 959, 1001, 1515, 812, 1486, 1000, 999, 2354, 1000, 954, 657, 1000, 1001, 1002, 1034, 1000, 1000, 1000, 1000, 1000, 1001, 1000, 1001, 1001, 2683, 1001, 1000, 1000, 999, 1001, 830, 1001, 1001, 1000, 1000, 586, 1000, 1001, 999, 1002, 1001, 1000, 1000, 1001, 1001, 1000, 1000, 1001, 1001, 930, 1001, 1000, 1001, 1000, 1001, 1000, 1001, 868, 1000, 1001, 1000, 1001, 1001, 863, 1000, 1000, 994, 779, 1000, 1000, 920, 950, 1001, 1000, 1001, 947, 920, 1000, 1001, 1000]
theorem node97967 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97967 support demand code
    entries97967 ((insert 39 (insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 59 (insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries97968 : List (Fin 2295 × ℕ) := [(4, 33), (77, 54), (86, 23), (137, 46), (151, 67), (179, 86), (273, 35), (386, 102), (387, 40), (397, 21), (468, 27), (529, 4), (571, 54), (587, 55), (588, 27), (618, 78), (621, 18), (678, 2), (679, 5), (681, 37), (727, 3), (740, 34), (835, 13), (844, 81), (858, 22), (873, 40), (874, 61), (885, 22), (894, 35), (898, 32), (933, 17), (934, 1), (938, 73), (958, 19), (960, 108), (966, 40), (970, 17), (972, 26), (973, 138), (984, 18), (985, 18), (1007, 3), (1011, 9), (1012, 23), (1043, 13), (1053, 11), (1055, 18), (1060, 3), (1061, 25), (1072, 17), (1073, 11), (1081, 14), (1082, 31), (1089, 3), (1107, 12), (1123, 1), (1131, 4), (1132, 11), (1133, 13), (1151, 11), (1155, 23), (1165, 22), (1169, 65), (1171, 52), (1175, 52), (1181, 33), (1183, 7), (1184, 23), (1185, 4), (1186, 52), (1188, 21), (1226, 30), (1253, 25), (1261, 8), (1293, 8), (1372, 48), (1403, 7), (1545, 45), (1560, 6), (1591, 21), (1604, 22), (1625, 19), (1667, 9), (1670, 3), (1831, 70), (1861, 101)]
def cs97968 : List ℕ := [207, 60, 22, 101, 58, 0, 22, 256, 58, 0, 155, 176, 234, 153, 87, 0, 243, 181, 254, 143, 256, 35, 200, 255, 22, 411, 256, 254, 76, 105, 256, 27, 218, 256, 74, 256, 47, 256, 257, 22, 140, 255, 82, 256, 329, 207, 153, 234, 140, 65, 256, 256, 248, 256, 257, 306, 256, 256, 256, 18, 0, 257, 257, 257, 254, 256, 74, 489, 255, 256, 215, 256, 257, 257, 203, 256, 486, 255, 336, 256, 258, 481, 256, 257, 230, 195, 222, 239, 271, 256, 256, 256, 258, 256, 257, 254, 255, 255, 651, 256, 256, 256, 177, 257, 255, 255, 256, 220, 256, 144, 255, 256, 258, 247, 256, 256, 255, 256, 255, 255, 249, 255, 255, 255, 256, 255, 255, 255, 257, 254, 256, 255, 254, 255, 254, 256, 255, 254, 255, 255, 256, 254, 252, 255, 197, 255, 255, 255, 256, 255, 217, 255, 255, 227]
theorem node97968 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 39 (insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97968 support demand code
    entries97968 ((insert 59 (insert 39 (insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node97966 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    59 node97967 node97968
theorem node97964 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 66 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    39 node97965 node97966
theorem node97947 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 98 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    66 node97963 node97964
def entries97961 : List (Fin 2295 × ℕ) := [(4, 346), (37, 420), (77, 172), (132, 54), (135, 116), (137, 207), (273, 165), (469, 149), (475, 262), (479, 106), (488, 119), (571, 145), (588, 310), (619, 142), (739, 70), (741, 265), (843, 88), (844, 447), (847, 126), (858, 104), (867, 237), (868, 41), (872, 225), (873, 169), (884, 286), (885, 96), (887, 181), (888, 203), (894, 264), (916, 304), (917, 276), (918, 48), (927, 30), (928, 295), (931, 234), (932, 135), (936, 206), (946, 26), (955, 123), (957, 39), (960, 174), (966, 145), (970, 90), (973, 519), (984, 192), (985, 154), (1004, 39), (1005, 23), (1008, 75), (1021, 47), (1049, 32), (1052, 10), (1073, 117), (1089, 101), (1107, 5), (1108, 134), (1123, 33), (1127, 6), (1128, 5), (1153, 11), (1155, 144), (1169, 104), (1173, 192), (1174, 18), (1176, 21), (1177, 250), (1179, 25), (1181, 89), (1184, 65), (1186, 222), (1188, 81), (1211, 14), (1212, 10), (1226, 18), (1229, 19), (1241, 74), (1261, 54), (1328, 13), (1384, 103), (1500, 153), (1545, 126), (1583, 104), (1588, 78), (1646, 38), (1648, 73), (1657, 103), (1746, 36), (1861, 68), (1877, 10), (1912, 51), (1927, 65), (2052, 37), (2122, 14), (2149, 19), (2282, 59)]
def cs97961 : List ℕ := [618, 598, 126, 330, 555, 539, 104, 999, 869, 0, 518, 582, 999, 394, 621, 0, 930, 1000, 999, 987, 1000, 264, 329, 1000, 149, 3220, 855, 1090, 172, 19, 1000, 999, 824, 1000, 336, 1001, 41, 1000, 1000, 999, 881, 836, 391, 1000, 1801, 1000, 615, 1000, 502, 1001, 897, 1001, 423, 999, 1001, 1000, 1002, 1000, 1000, 1000, 286, 1001, 806, 748, 612, 999, 2208, 1930, 974, 1000, 1000, 1000, 1001, 900, 464, 1000, 1535, 1001, 2474, 1002, 1000, 1814, 999, 1000, 805, 1000, 999, 1001, 2365, 1003, 1001, 1001, 1001, 999, 1001, 1000, 1000, 922, 723, 1002, 1001, 1001, 1000, 1000, 1000, 1000, 1000, 969, 1001, 567, 1001, 1001, 1000, 1000, 1000, 1002, 1003, 1001, 1001, 1000, 967, 1000, 1002, 1003, 1002, 862, 1000, 1001, 999, 1002, 1003, 912, 1001, 1002, 1002, 1001, 1000, 841, 1003, 1002, 1002, 1000, 911, 1002, 1002, 1000, 1002, 1002, 1002, 1001, 1001, 1001, 974, 1002]
theorem node97961 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 88 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97961 support demand code
    entries97961 ((insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 66 (insert 88 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries97962 : List (Fin 2295 × ℕ) := [(4, 94), (35, 51), (77, 46), (86, 7), (130, 3), (135, 2), (137, 41), (177, 118), (273, 44), (468, 35), (471, 36), (498, 9), (529, 9), (531, 23), (571, 69), (588, 119), (617, 42), (618, 16), (679, 14), (681, 52), (729, 45), (731, 5), (741, 86), (833, 2), (835, 3), (844, 97), (855, 13), (858, 58), (873, 41), (874, 69), (884, 11), (885, 48), (894, 49), (916, 55), (917, 99), (918, 18), (928, 7), (931, 48), (932, 98), (936, 44), (946, 45), (957, 13), (960, 62), (965, 1), (966, 57), (970, 21), (973, 135), (984, 30), (985, 27), (1009, 30), (1012, 30), (1021, 23), (1043, 12), (1045, 5), (1052, 6), (1053, 17), (1060, 4), (1070, 33), (1072, 21), (1073, 40), (1082, 10), (1107, 13), (1108, 12), (1110, 2), (1143, 6), (1155, 21), (1169, 38), (1171, 27), (1174, 21), (1175, 62), (1181, 20), (1184, 18), (1185, 10), (1186, 51), (1212, 2), (1226, 27), (1247, 17), (1261, 6), (1269, 30), (1293, 19), (1375, 3), (1400, 36), (1454, 1), (1545, 33), (1548, 31), (1633, 5), (1861, 65), (1877, 18), (1927, 27), (2047, 27), (2283, 2)]
def cs97962 : List ℕ := [162, 129, 36, 65, 94, 64, 58, 233, 154, 0, 111, 107, 255, 193, 140, 0, 241, 256, 256, 69, 255, 49, 237, 256, 36, 528, 152, 260, 46, 169, 256, 252, 228, 256, 83, 257, 0, 255, 255, 256, 256, 257, 119, 255, 482, 256, 101, 255, 213, 256, 256, 256, 91, 256, 256, 256, 256, 255, 255, 255, 11, 257, 185, 256, 227, 254, 34, 486, 257, 256, 255, 256, 175, 256, 249, 256, 433, 255, 461, 255, 255, 473, 255, 256, 226, 208, 257, 232, 762, 256, 257, 256, 256, 255, 255, 256, 257, 257, 181, 256, 256, 256, 256, 255, 258, 256, 256, 247, 257, 132, 256, 257, 256, 257, 181, 256, 256, 256, 257, 279, 251, 249, 257, 255, 256, 253, 257, 257, 256, 257, 256, 256, 256, 258, 257, 257, 257, 203, 257, 256, 256, 257, 257, 256, 168, 257, 257, 255, 257, 256, 247, 256, 256, 219]
theorem node97962 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 66 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97962 support demand code
    entries97962 ((insert 66 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 88 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node97949 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 88 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    66 node97961 node97962
def entries97959 : List (Fin 2295 × ℕ) := [(35, 48), (37, 25), (77, 81), (273, 39), (409, 24), (488, 24), (512, 73), (540, 90), (542, 56), (571, 34), (572, 13), (576, 10), (588, 29), (731, 63), (741, 52), (743, 23), (813, 7), (844, 86), (847, 59), (853, 35), (858, 83), (865, 48), (867, 17), (868, 30), (873, 5), (878, 30), (885, 53), (888, 97), (915, 90), (916, 81), (917, 3), (933, 13), (934, 49), (944, 40), (957, 32), (958, 25), (965, 12), (966, 53), (973, 140), (984, 12), (985, 37), (1010, 18), (1012, 18), (1043, 1), (1044, 5), (1045, 8), (1061, 27), (1073, 63), (1107, 12), (1108, 27), (1113, 19), (1121, 2), (1128, 15), (1133, 1), (1139, 4), (1153, 5), (1154, 44), (1169, 51), (1171, 60), (1177, 29), (1184, 12), (1186, 38), (1219, 81), (1223, 29), (1232, 6), (1234, 24), (1246, 7), (1261, 37), (1308, 59), (1342, 23), (1372, 76), (1384, 2), (1488, 39), (1517, 6), (1591, 12), (1605, 5), (1623, 38), (1636, 35), (1646, 7), (1648, 14), (1667, 3), (1701, 45), (1705, 12), (1991, 17)]
def cs97959 : List ℕ := [115, 81, 59, 81, 29, 132, 89, 255, 102, 0, 249, 116, 255, 129, 257, 0, 236, 256, 256, 176, 639, 0, 29, 256, 0, 666, 256, 402, 81, 48, 255, 257, 147, 256, 175, 256, 30, 256, 174, 491, 109, 256, 69, 256, 611, 231, 215, 153, 145, 238, 255, 255, 113, 256, 255, 257, 257, 256, 255, 255, 90, 255, 256, 256, 257, 256, 256, 491, 209, 255, 256, 257, 257, 184, 159, 256, 301, 256, 451, 256, 255, 378, 257, 257, 209, 163, 257, 257, 70, 255, 256, 234, 256, 256, 198, 257, 257, 258, 14, 256, 256, 256, 255, 255, 257, 258, 255, 237, 257, 50, 255, 256, 256, 172, 234, 257, 256, 256, 256, 257, 256, 207, 257, 240, 255, 251, 257, 256, 185, 257, 256, 243, 255, 256, 257, 256, 230, 234, 256, 256, 240, 256, 256, 255, 137, 256, 249, 256, 257, 256, 209, 214, 239, 184]
theorem node97959 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 20 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97959 support demand code
    entries97959 ((insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 39 (insert 20 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries97960 : List (Fin 2295 × ℕ) := [(37, 434), (72, 9), (77, 411), (135, 283), (273, 117), (468, 339), (488, 16), (490, 239), (507, 92), (512, 137), (514, 151), (540, 172), (542, 116), (571, 17), (572, 89), (618, 244), (679, 60), (731, 317), (736, 235), (738, 155), (741, 152), (743, 260), (844, 571), (858, 297), (867, 139), (868, 153), (873, 332), (874, 444), (878, 203), (886, 16), (888, 281), (916, 156), (925, 103), (931, 40), (932, 145), (933, 50), (934, 128), (957, 222), (962, 188), (965, 10), (966, 317), (973, 508), (984, 110), (985, 92), (1009, 80), (1012, 88), (1043, 10), (1056, 8), (1061, 89), (1069, 59), (1073, 238), (1107, 49), (1108, 187), (1123, 16), (1128, 12), (1132, 77), (1133, 1), (1139, 31), (1152, 44), (1154, 101), (1169, 145), (1171, 8), (1173, 253), (1175, 94), (1186, 160), (1232, 81), (1234, 79), (1261, 174), (1297, 59), (1308, 20), (1344, 45), (1372, 79), (1433, 103), (1488, 173), (1545, 149), (1572, 58), (1580, 16), (1591, 6), (1605, 64), (1636, 149), (1657, 74), (1705, 91), (2000, 8), (2002, 37), (2085, 42)]
def cs97960 : List ℕ := [645, 413, 0, 0, 90, 450, 573, 1000, 508, 129, 1000, 689, 1000, 871, 1001, 0, 1000, 942, 1000, 821, 2644, 0, 0, 1000, 129, 2461, 943, 1244, 420, 37, 1000, 455, 725, 1001, 347, 1000, 153, 1000, 1001, 156, 485, 1001, 151, 1000, 1583, 767, 825, 456, 460, 769, 928, 1001, 1000, 1000, 999, 1000, 1000, 1001, 1000, 999, 119, 1000, 1000, 1001, 1000, 999, 1001, 1510, 768, 1000, 1000, 999, 917, 645, 664, 1000, 1656, 1000, 1696, 1001, 1001, 1788, 1001, 755, 654, 847, 999, 1001, 279, 1000, 1001, 887, 999, 999, 837, 1000, 1002, 999, 16, 1001, 999, 1000, 1000, 1000, 1001, 999, 999, 953, 999, 348, 999, 1000, 1001, 1000, 765, 999, 1000, 1001, 1000, 999, 999, 753, 1000, 1000, 1001, 994, 999, 999, 694, 1000, 1000, 747, 999, 999, 1000, 1001, 990, 802, 998, 999, 953, 1000, 999, 1000, 463, 937, 1000, 1000, 998, 1000, 935, 888, 769, 808]
theorem node97960 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97960 support demand code
    entries97960 ((insert 39 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 20 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node97951 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 20 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    39 node97959 node97960
def entries97957 : List (Fin 2295 × ℕ) := [(4, 103), (37, 99), (77, 112), (86, 1), (137, 43), (273, 69), (471, 4), (475, 67), (479, 84), (488, 61), (496, 24), (588, 43), (618, 30), (619, 18), (621, 19), (632, 60), (640, 31), (679, 39), (681, 7), (729, 13), (731, 43), (736, 60), (741, 34), (844, 13), (855, 27), (860, 13), (869, 88), (873, 91), (874, 49), (884, 55), (885, 21), (886, 22), (887, 1), (888, 53), (892, 4), (916, 128), (931, 13), (932, 70), (933, 21), (955, 15), (957, 70), (958, 28), (962, 20), (965, 6), (966, 50), (973, 129), (984, 30), (985, 22), (1005, 21), (1043, 42), (1060, 51), (1068, 20), (1082, 1), (1089, 10), (1094, 25), (1108, 13), (1110, 4), (1113, 51), (1123, 66), (1132, 35), (1139, 2), (1143, 14), (1154, 35), (1155, 57), (1169, 84), (1171, 43), (1175, 43), (1212, 11), (1228, 3), (1232, 13), (1241, 2), (1247, 6), (1261, 29), (1308, 37), (1344, 15), (1384, 19), (1400, 33), (1433, 16), (1488, 20), (1548, 13), (1560, 45), (1605, 1), (1623, 14), (1681, 41), (1705, 3), (1887, 36), (1997, 18)]
def cs97957 : List ℕ := [13, 103, 4, 85, 187, 187, 0, 101, 239, 18, 112, 174, 256, 140, 215, 0, 145, 205, 256, 153, 13, 4, 43, 255, 22, 735, 224, 108, 112, 119, 230, 255, 197, 256, 43, 257, 0, 256, 257, 255, 255, 256, 64, 256, 426, 256, 225, 257, 104, 255, 255, 257, 246, 257, 257, 255, 255, 258, 256, 491, 77, 256, 256, 257, 257, 256, 257, 440, 220, 255, 256, 256, 252, 212, 258, 257, 342, 255, 478, 256, 232, 347, 256, 255, 257, 210, 256, 256, 140, 256, 257, 255, 256, 255, 235, 255, 256, 256, 66, 256, 257, 256, 256, 256, 217, 256, 255, 256, 256, 104, 256, 256, 257, 238, 248, 257, 255, 257, 256, 256, 256, 256, 258, 245, 256, 256, 257, 256, 185, 256, 257, 256, 255, 514, 257, 257, 257, 233, 255, 256, 257, 228, 256, 256, 256, 211, 256, 246, 256, 189, 254, 210, 256, 215]
theorem node97957 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 133 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97957 support demand code
    entries97957 ((insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 59 (insert 133 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries97958 : List (Fin 2295 × ℕ) := [(4, 46), (20, 13), (37, 20), (77, 32), (83, 13), (130, 26), (135, 3), (137, 11), (273, 24), (409, 17), (471, 24), (475, 9), (571, 31), (587, 41), (588, 14), (618, 27), (621, 10), (679, 11), (731, 9), (741, 13), (813, 16), (855, 24), (869, 28), (873, 20), (874, 20), (885, 24), (886, 12), (887, 15), (888, 33), (894, 28), (915, 13), (921, 10), (957, 19), (958, 9), (963, 7), (965, 8), (966, 28), (973, 46), (984, 13), (985, 15), (1010, 2), (1020, 5), (1022, 6), (1043, 2), (1055, 1), (1056, 11), (1060, 25), (1073, 4), (1082, 6), (1093, 5), (1094, 18), (1108, 14), (1120, 3), (1123, 20), (1130, 1), (1133, 6), (1153, 29), (1154, 19), (1155, 13), (1169, 21), (1170, 1), (1171, 32), (1175, 20), (1186, 1), (1232, 15), (1261, 7), (1344, 9), (1372, 2), (1403, 2), (1433, 20), (1488, 3), (1502, 4), (1545, 4), (1548, 10), (1680, 1), (1744, 2), (1791, 6), (1887, 5), (1991, 10), (2291, 11)]
def cs97958 : List ℕ := [0, 46, 24, 22, 46, 44, 0, 24, 79, 0, 32, 50, 33, 55, 78, 0, 100, 100, 99, 99, 0, 28, 67, 99, 24, 280, 101, 89, 32, 25, 64, 89, 100, 100, 20, 101, 0, 100, 65, 99, 42, 100, 67, 82, 136, 81, 65, 100, 23, 35, 100, 99, 101, 99, 101, 100, 99, 100, 100, 0, 25, 101, 101, 99, 72, 100, 101, 183, 100, 101, 42, 100, 101, 99, 84, 101, 142, 99, 155, 101, 87, 151, 101, 101, 60, 85, 100, 101, 20, 100, 100, 99, 101, 84, 100, 100, 100, 100, 20, 100, 100, 99, 100, 101, 100, 94, 100, 69, 100, 18, 100, 100, 99, 96, 80, 97, 100, 101, 100, 99, 94, 100, 100, 101, 100, 100, 100, 99, 90, 101, 101, 100, 100, 184, 99, 100, 100, 69, 99, 100, 100, 100, 99, 101, 99, 78, 100, 83, 99, 79, 99, 94, 100, 75]
theorem node97958 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 133 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97958 support demand code
    entries97958 ((insert 59 (insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 133 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node97953 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 133 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 133 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    59 node97957 node97958
def entries97955 : List (Fin 2295 × ℕ) := [(4, 123), (20, 19), (37, 86), (77, 81), (137, 16), (273, 60), (409, 1), (475, 50), (479, 118), (488, 45), (571, 5), (587, 34), (618, 54), (621, 8), (632, 38), (640, 12), (679, 37), (681, 36), (731, 40), (736, 16), (737, 9), (738, 16), (743, 1), (813, 34), (855, 45), (869, 114), (873, 56), (874, 63), (884, 55), (885, 4), (888, 41), (916, 94), (932, 67), (933, 24), (934, 24), (944, 5), (957, 40), (958, 59), (961, 23), (965, 10), (966, 60), (973, 123), (984, 55), (985, 27), (1004, 6), (1043, 15), (1047, 11), (1049, 12), (1055, 7), (1061, 45), (1069, 17), (1072, 22), (1073, 40), (1077, 22), (1107, 7), (1133, 24), (1138, 62), (1143, 2), (1161, 4), (1169, 72), (1171, 61), (1175, 39), (1186, 60), (1261, 1), (1276, 4), (1308, 31), (1328, 1), (1344, 25), (1399, 12), (1400, 29), (1545, 21), (1605, 38), (1623, 44), (1680, 47), (1705, 24), (1887, 4), (1991, 24), (1997, 41), (2001, 5), (2161, 16)]
def cs97955 : List ℕ := [0, 123, 0, 110, 241, 176, 0, 118, 228, 41, 81, 205, 210, 138, 204, 0, 75, 256, 255, 132, 0, 0, 81, 257, 41, 670, 188, 91, 81, 145, 185, 256, 232, 256, 39, 256, 0, 255, 256, 256, 254, 255, 92, 256, 368, 255, 209, 256, 125, 255, 255, 256, 246, 257, 256, 255, 255, 257, 256, 453, 55, 255, 249, 256, 256, 256, 256, 451, 190, 255, 190, 255, 197, 256, 216, 256, 294, 256, 450, 256, 255, 283, 256, 254, 256, 256, 256, 255, 150, 256, 255, 256, 255, 255, 192, 256, 256, 255, 0, 255, 255, 257, 255, 255, 256, 256, 255, 225, 256, 83, 257, 256, 254, 256, 222, 257, 254, 255, 256, 257, 256, 245, 256, 230, 254, 256, 257, 256, 257, 254, 246, 234, 256, 123, 257, 222, 255, 239, 257, 256, 237, 255, 214, 256, 154, 239, 209, 256, 256, 256, 147, 257, 191, 187]
theorem node97955 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 133 (insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97955 support demand code
    entries97955 ((insert 133 (insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 59 (insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries97956 : List (Fin 2295 × ℕ) := [(4, 37), (20, 10), (37, 24), (77, 15), (83, 34), (135, 18), (137, 11), (273, 12), (409, 13), (471, 19), (475, 10), (571, 29), (587, 25), (588, 29), (618, 37), (619, 1), (621, 4), (679, 7), (681, 1), (743, 1), (813, 10), (842, 3), (844, 9), (855, 21), (869, 10), (873, 21), (874, 25), (883, 31), (885, 17), (887, 13), (888, 32), (894, 20), (915, 20), (917, 2), (925, 5), (944, 9), (957, 3), (958, 11), (962, 18), (965, 14), (966, 37), (973, 46), (984, 11), (985, 19), (1012, 6), (1055, 20), (1061, 19), (1073, 13), (1081, 5), (1108, 20), (1119, 6), (1121, 2), (1131, 13), (1133, 4), (1138, 9), (1139, 13), (1146, 2), (1162, 7), (1169, 24), (1171, 30), (1175, 24), (1186, 9), (1261, 7), (1308, 8), (1344, 9), (1433, 7), (1545, 18), (1591, 8), (1680, 11), (1744, 10), (1791, 2), (1944, 2), (1991, 11), (1997, 4), (2138, 2), (2161, 6)]
def cs97956 : List ℕ := [9, 37, 19, 24, 37, 45, 0, 28, 71, 4, 15, 58, 44, 56, 52, 0, 96, 100, 100, 98, 9, 20, 65, 100, 23, 267, 99, 81, 15, 25, 67, 93, 96, 100, 24, 99, 0, 100, 63, 99, 40, 99, 74, 93, 136, 78, 62, 100, 21, 22, 99, 100, 99, 101, 99, 101, 99, 99, 100, 0, 25, 99, 99, 101, 73, 101, 99, 193, 100, 99, 38, 99, 101, 65, 78, 99, 161, 100, 141, 100, 74, 136, 100, 97, 61, 91, 99, 99, 26, 101, 101, 101, 99, 81, 100, 100, 99, 98, 0, 99, 100, 101, 100, 92, 99, 99, 99, 87, 100, 29, 101, 100, 99, 93, 77, 100, 99, 101, 99, 100, 95, 89, 99, 99, 99, 100, 99, 99, 99, 98, 100, 94, 100, 46, 99, 99, 100, 97, 99, 100, 91, 99, 72, 100, 47, 98, 84, 101, 100, 100, 66, 87, 66, 55]
theorem node97956 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 59 (insert 133 (insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs97956 support demand code
    entries97956 ((insert 59 (insert 133 (insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node97954 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 133 (insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 133 (insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    59 node97955 node97956
theorem node97952 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 20 (insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    133 node97953 node97954
theorem node97950 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    20 node97951 node97952
theorem node97948 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 98 (insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅)))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    88 node97949 node97950
theorem node97946 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 21 (insert 60 (insert 34 (insert 36 (insert 109 ∅))))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    98 node97947 node97948
theorem node97944 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 34 (insert 36 (insert 109 ∅)))) : Finset (Fin 154)) ((insert 67 (insert 81 (insert 27 (insert 78 (insert 25 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    21 node97945 node97946
#print axioms node97944
end OmissionResidualCover31Fused
