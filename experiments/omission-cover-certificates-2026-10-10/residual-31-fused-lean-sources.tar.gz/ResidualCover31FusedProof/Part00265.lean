import ResidualCover31FusedProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover31Fused
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries78709 : List (Fin 2295 × ℕ) := [(100, 81), (177, 17), (181, 2), (342, 3), (471, 20), (494, 9), (514, 25), (539, 122), (549, 58), (578, 93), (582, 29), (622, 106), (639, 71), (675, 8), (681, 113), (738, 20), (740, 33), (741, 39), (846, 28), (850, 30), (851, 31), (852, 73), (870, 93), (872, 19), (880, 34), (889, 120), (891, 14), (898, 77), (907, 6), (908, 40), (920, 69), (925, 2), (944, 106), (947, 35), (949, 99), (951, 74), (952, 57), (953, 5), (958, 8), (959, 19), (960, 61), (970, 10), (973, 127), (978, 72), (1006, 19), (1009, 60), (1014, 20), (1043, 29), (1049, 49), (1072, 5), (1073, 14), (1108, 5), (1128, 17), (1143, 9), (1154, 42), (1155, 35), (1167, 34), (1174, 6), (1175, 15), (1177, 41), (1212, 53), (1254, 85), (1268, 31), (1275, 6), (1308, 41), (1342, 25), (1354, 15), (1447, 14), (1469, 6), (1493, 45), (1498, 95), (1501, 53), (1528, 12), (1537, 10), (1577, 24), (1645, 8), (1651, 4), (1705, 18), (1845, 33), (1846, 20), (1887, 35), (1901, 33), (1998, 7), (2000, 56), (2001, 6), (2132, 19), (2236, 12)]
def cs78709 : List ℕ := [0, 113, 30, 30, 189, 109, 24, 256, 128, 4, 25, 202, 257, 174, 146, 256, 239, 257, 256, 31, 256, 256, 194, 241, 256, 0, 256, 632, 166, 17, 256, 256, 257, 256, 83, 256, 934, 256, 211, 257, 256, 256, 256, 212, 668, 256, 256, 947, 48, 256, 257, 1062, 89, 257, 256, 291, 256, 256, 256, 257, 958, 256, 256, 256, 230, 256, 578, 42, 257, 255, 616, 257, 256, 162, 257, 255, 379, 256, 134, 257, 256, 728, 252, 257, 256, 255, 256, 256, 257, 257, 258, 199, 257, 257, 251, 255, 256, 256, 256, 206, 258, 293, 257, 256, 252, 256, 255, 257, 206, 58, 257, 256, 256, 202, 255, 257, 257, 257, 257, 249, 189, 244, 258, 257, 257, 240, 257, 256, 255, 257, 183, 223, 257, 257, 257, 245, 230, 234, 257, 257, 237, 240, 214, 258, 237, 256, 257, 219, 256, 203, 237, 257, 257, 221]
theorem node78709 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 81 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78709 support demand code
    entries78709 ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 70 (insert 81 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78710 : List (Fin 2295 × ℕ) := [(23, 22), (288, 36), (471, 4), (491, 31), (497, 1), (514, 22), (539, 73), (549, 71), (551, 18), (578, 50), (620, 6), (622, 2), (631, 3), (679, 63), (681, 108), (691, 30), (736, 59), (797, 3), (815, 10), (850, 25), (852, 96), (870, 75), (880, 4), (889, 117), (891, 66), (898, 92), (901, 50), (907, 43), (908, 55), (919, 22), (922, 26), (925, 2), (944, 103), (951, 10), (952, 34), (959, 57), (960, 61), (970, 37), (973, 111), (978, 68), (994, 16), (1006, 28), (1009, 42), (1033, 42), (1043, 7), (1049, 19), (1061, 5), (1073, 32), (1076, 17), (1093, 6), (1098, 2), (1100, 37), (1154, 28), (1155, 17), (1167, 12), (1171, 7), (1176, 1), (1177, 74), (1179, 39), (1186, 23), (1212, 48), (1219, 76), (1223, 30), (1247, 24), (1254, 25), (1267, 24), (1268, 129), (1272, 13), (1308, 13), (1370, 7), (1375, 38), (1477, 15), (1493, 64), (1498, 100), (1501, 19), (1508, 11), (1535, 2), (1635, 8), (1652, 6), (1655, 20), (1670, 7), (1690, 1), (1845, 13), (1848, 11), (1849, 9), (2000, 20)]
def cs78710 : List ℕ := [30, 101, 4, 101, 175, 100, 31, 255, 56, 0, 22, 237, 257, 129, 73, 257, 257, 256, 256, 131, 257, 257, 175, 257, 257, 7, 257, 675, 126, 3, 256, 257, 256, 258, 80, 257, 714, 256, 250, 255, 257, 256, 257, 151, 534, 256, 258, 1011, 8, 256, 121, 748, 80, 256, 258, 334, 256, 256, 256, 243, 742, 257, 256, 256, 98, 239, 437, 20, 256, 257, 44, 256, 257, 231, 258, 257, 477, 208, 7, 256, 256, 500, 71, 255, 187, 258, 256, 257, 256, 256, 256, 226, 256, 255, 257, 257, 239, 255, 256, 257, 255, 257, 212, 66, 236, 256, 256, 258, 255, 110, 256, 257, 257, 170, 131, 256, 256, 256, 256, 218, 179, 223, 256, 257, 257, 236, 255, 257, 257, 257, 257, 198, 256, 256, 256, 256, 200, 203, 255, 256, 256, 208, 256, 256, 199, 256, 255, 218, 256, 252, 222, 256, 256, 206]
theorem node78710 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78710 support demand code
    entries78710 ((insert 70 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 81 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78701 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 81 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    70 node78709 node78710
def entries78705 : List (Fin 2295 × ℕ) := [(158, 1)]
def cs78705 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node78705 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 21 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78705 support demand code
    entries78705 ((insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 75 (insert 21 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries78707 : List (Fin 2295 × ℕ) := [(889, 1)]
def cs78707 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node78707 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 21 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78707 support demand code
    entries78707 ((insert 75 (insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 55 (insert 21 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries78708 : List (Fin 2295 × ℕ) := [(21, 3), (23, 6), (177, 9), (179, 6), (491, 5), (514, 3), (539, 8), (551, 3), (578, 19), (639, 10), (676, 4), (677, 1), (680, 8), (681, 1), (817, 1), (833, 1), (846, 5), (852, 12), (870, 10), (872, 9), (888, 10), (891, 18), (901, 2), (902, 2), (908, 8), (919, 2), (924, 5), (925, 2), (944, 7), (945, 5), (946, 2), (952, 8), (969, 5), (970, 1), (971, 4), (972, 2), (973, 16), (978, 4), (994, 3), (1009, 5), (1042, 7), (1045, 6), (1073, 9), (1076, 1), (1110, 1), (1113, 5), (1122, 2), (1123, 4), (1141, 2), (1149, 2), (1167, 5), (1175, 1), (1177, 3), (1179, 1), (1183, 1), (1186, 10), (1212, 1), (1219, 6), (1227, 1), (1254, 1), (1261, 5), (1267, 5), (1269, 2), (1293, 4), (1299, 3), (1480, 6), (1488, 2), (1493, 3), (1498, 16), (1501, 4), (1577, 7), (1645, 6), (1798, 2), (1845, 2), (1848, 4), (1901, 1), (1903, 1), (1991, 1)]
def cs78708 : List ℕ := [0, 14, 2, 11, 19, 18, 12, 32, 7, 2, 5, 31, 32, 10, 17, 29, 28, 33, 32, 10, 32, 48, 22, 31, 31, 0, 32, 103, 19, 15, 31, 32, 32, 32, 12, 32, 99, 32, 31, 32, 32, 32, 32, 22, 71, 33, 32, 86, 22, 32, 26, 81, 21, 33, 32, 37, 32, 31, 32, 30, 74, 6, 32, 31, 15, 27, 40, 6, 32, 32, 30, 29, 33, 30, 33, 4, 57, 26, 1, 32, 32, 0, 20, 32, 31, 33, 32, 30, 31, 32, 31, 22, 32, 32, 32, 32, 31, 32, 32, 30, 31, 33, 31, 31, 32, 31, 32, 32, 32, 18, 32, 32, 28, 20, 30, 31, 32, 31, 31, 29, 20, 22, 31, 33, 32, 31, 33, 32, 32, 33, 24, 32, 32, 32, 32, 31, 22, 30, 31, 31, 32, 26, 31, 32, 31, 30, 29, 32, 30, 32, 31, 31, 30, 29]
theorem node78708 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 75 (insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78708 support demand code
    entries78708 ((insert 55 (insert 75 (insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 21 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
theorem node78706 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 75 (insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 21 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    55 node78707 node78708
theorem node78703 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    75 node78705 node78706
def entries78704 : List (Fin 2295 × ℕ) := [(177, 12), (342, 7), (469, 14), (479, 15), (491, 22), (539, 48), (549, 9), (551, 16), (631, 10), (639, 20), (674, 1), (680, 25), (816, 3), (817, 12), (846, 13), (850, 1), (852, 40), (870, 39), (871, 11), (872, 14), (875, 13), (879, 24), (898, 14), (901, 8), (902, 11), (908, 30), (919, 16), (921, 5), (924, 1), (929, 10), (944, 40), (946, 13), (948, 1), (950, 24), (952, 29), (954, 1), (960, 1), (970, 23), (973, 38), (977, 4), (978, 31), (1009, 15), (1033, 15), (1047, 7), (1072, 1), (1073, 5), (1076, 8), (1100, 18), (1110, 2), (1113, 7), (1122, 7), (1123, 1), (1126, 12), (1149, 5), (1153, 10), (1154, 8), (1155, 13), (1167, 16), (1174, 7), (1175, 15), (1177, 16), (1179, 25), (1183, 5), (1212, 4), (1234, 43), (1247, 16), (1254, 8), (1257, 4), (1264, 9), (1269, 10), (1281, 10), (1293, 17), (1335, 1), (1493, 6), (1497, 7), (1498, 45), (1501, 6), (1522, 33), (1645, 14), (1667, 4), (1848, 12), (2062, 3)]
def cs78704 : List ℕ := [10, 35, 10, 11, 63, 78, 22, 100, 11, 0, 0, 93, 100, 61, 61, 100, 100, 100, 99, 0, 101, 0, 38, 100, 100, 0, 100, 162, 44, 31, 100, 93, 100, 99, 59, 69, 214, 101, 99, 100, 74, 100, 97, 74, 163, 99, 100, 325, 68, 100, 80, 287, 48, 100, 100, 99, 100, 101, 101, 100, 282, 58, 101, 100, 52, 96, 208, 21, 100, 101, 100, 13, 99, 100, 100, 99, 113, 95, 40, 99, 100, 1, 46, 101, 100, 100, 69, 100, 99, 100, 99, 98, 100, 100, 101, 99, 101, 100, 101, 99, 99, 100, 100, 68, 99, 87, 101, 99, 94, 30, 100, 99, 101, 88, 91, 99, 100, 100, 100, 82, 58, 100, 99, 99, 101, 81, 99, 99, 100, 100, 100, 99, 100, 100, 96, 100, 81, 86, 100, 99, 95, 88, 100, 94, 95, 99, 99, 90, 100, 75, 100, 73, 100, 60]
theorem node78704 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78704 support demand code
    entries78704 ((insert 21 (insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78702 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    21 node78703 node78704
theorem node78685 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 51 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    81 node78701 node78702
def entries78695 : List (Fin 2295 × ℕ) := [(158, 1)]
def cs78695 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node78695 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78695 support demand code
    entries78695 ((insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 75 (insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries78697 : List (Fin 2295 × ℕ) := [(889, 1)]
def cs78697 : List ℕ := [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
theorem node78697 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78697 support demand code
    entries78697 ((insert 75 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 55 (insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 0 31 code_correct
  decide +kernel
def entries78699 : List (Fin 2295 × ℕ) := [(21, 52), (86, 62), (98, 18), (177, 197), (342, 22), (472, 233), (482, 46), (491, 169), (531, 54), (550, 212), (551, 140), (580, 55), (588, 28), (625, 429), (632, 337), (639, 265), (675, 51), (736, 181), (738, 139), (812, 24), (842, 27), (846, 346), (887, 542), (891, 705), (901, 186), (902, 126), (907, 67), (908, 261), (919, 34), (922, 95), (923, 135), (924, 321), (925, 254), (926, 41), (944, 231), (951, 13), (959, 77), (960, 343), (969, 6), (970, 221), (973, 502), (978, 312), (994, 63), (1009, 13), (1033, 94), (1043, 170), (1049, 41), (1073, 235), (1076, 29), (1110, 120), (1113, 131), (1143, 87), (1154, 108), (1167, 108), (1186, 380), (1212, 9), (1219, 27), (1235, 17), (1254, 130), (1281, 260), (1286, 125), (1293, 77), (1299, 95), (1308, 36), (1379, 299), (1403, 190), (1497, 48), (1577, 110), (1616, 22), (1633, 4), (1654, 193), (1705, 30), (1845, 60), (1848, 185), (1859, 4), (1901, 193), (1983, 259), (1991, 129), (1993, 34), (1998, 2)]
def cs78699 : List ℕ := [264, 503, 493, 339, 130, 50, 283, 1000, 611, 0, 299, 762, 1000, 265, 110, 462, 999, 907, 1000, 542, 999, 1347, 225, 1000, 1001, 0, 1000, 2854, 757, 534, 1000, 1000, 995, 999, 373, 1000, 2787, 999, 456, 1001, 757, 607, 999, 798, 1862, 1000, 1001, 931, 197, 1000, 999, 108, 999, 999, 1000, 1199, 1000, 1000, 1000, 1001, 1079, 1000, 999, 1000, 755, 712, 1587, 108, 999, 1000, 1000, 2462, 1000, 897, 629, 41, 2489, 1000, 129, 1000, 1000, 2022, 583, 999, 516, 677, 1000, 1001, 1001, 999, 999, 908, 1000, 999, 1000, 1000, 936, 1000, 1000, 999, 1000, 998, 859, 906, 1000, 1000, 1000, 998, 999, 430, 999, 999, 803, 784, 579, 999, 1000, 999, 999, 737, 1001, 1000, 811, 1000, 1000, 734, 1000, 1001, 982, 1000, 999, 658, 1000, 999, 1000, 999, 706, 674, 1000, 999, 1000, 982, 991, 1000, 1000, 767, 891, 999, 640, 891, 915, 978, 999, 913]
theorem node78699 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 75 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78699 support demand code
    entries78699 ((insert 55 (insert 75 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries78700 : List (Fin 2295 × ℕ) := [(86, 12), (98, 14), (177, 11), (179, 4), (472, 11), (482, 1), (491, 23), (514, 13), (551, 48), (580, 20), (624, 25), (625, 14), (632, 37), (639, 35), (675, 7), (676, 3), (737, 22), (739, 6), (797, 2), (798, 6), (833, 6), (842, 5), (846, 25), (888, 51), (891, 69), (901, 10), (902, 13), (908, 18), (919, 14), (923, 21), (924, 34), (925, 15), (926, 7), (929, 10), (944, 15), (945, 10), (952, 3), (969, 22), (970, 6), (971, 6), (972, 8), (973, 45), (978, 28), (994, 16), (1033, 4), (1042, 29), (1045, 10), (1047, 15), (1061, 11), (1073, 12), (1110, 1), (1113, 15), (1122, 13), (1123, 1), (1167, 11), (1175, 15), (1183, 3), (1186, 32), (1212, 8), (1219, 9), (1254, 15), (1257, 5), (1258, 2), (1267, 13), (1277, 2), (1281, 17), (1284, 4), (1286, 3), (1293, 8), (1481, 2), (1528, 4), (1654, 24), (1704, 8), (1798, 22), (1848, 22), (1901, 11), (1991, 7), (2225, 6)]
def cs78700 : List ℕ := [17, 71, 50, 48, 15, 23, 23, 99, 72, 22, 35, 98, 99, 25, 22, 48, 88, 85, 99, 51, 99, 148, 23, 98, 99, 0, 99, 295, 70, 62, 99, 99, 99, 100, 49, 100, 262, 100, 33, 99, 85, 93, 99, 90, 207, 100, 101, 93, 33, 100, 99, 25, 100, 99, 99, 115, 100, 101, 99, 100, 126, 20, 61, 100, 98, 52, 146, 14, 100, 100, 100, 166, 100, 101, 99, 15, 175, 100, 16, 100, 100, 0, 58, 101, 72, 101, 100, 100, 100, 100, 101, 88, 100, 101, 97, 96, 100, 100, 99, 102, 101, 100, 102, 98, 100, 100, 99, 101, 101, 61, 100, 100, 81, 87, 100, 101, 100, 100, 100, 76, 53, 77, 83, 101, 99, 72, 100, 99, 79, 99, 98, 100, 100, 100, 100, 99, 64, 87, 100, 101, 99, 81, 101, 100, 99, 76, 83, 101, 100, 85, 99, 100, 92, 90]
theorem node78700 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 55 (insert 75 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78700 support demand code
    entries78700 ((insert 81 (insert 55 (insert 75 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78698 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 55 (insert 75 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 55 (insert 75 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    81 node78699 node78700
theorem node78696 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 75 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    55 node78697 node78698
theorem node78693 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 21 (insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    75 node78695 node78696
def entries78694 : List (Fin 2295 × ℕ) := [(86, 23), (98, 69), (289, 157), (342, 39), (478, 291), (482, 146), (483, 20), (491, 27), (514, 131), (531, 125), (550, 362), (551, 288), (624, 18), (625, 470), (631, 88), (632, 508), (639, 142), (797, 25), (816, 19), (817, 30), (833, 50), (843, 50), (846, 174), (852, 58), (860, 209), (869, 65), (870, 192), (872, 143), (873, 230), (874, 83), (879, 112), (880, 54), (888, 88), (908, 19), (919, 148), (920, 195), (924, 418), (925, 158), (944, 331), (945, 10), (959, 161), (960, 67), (970, 187), (973, 477), (978, 376), (1009, 10), (1033, 109), (1042, 71), (1047, 113), (1073, 40), (1076, 9), (1098, 61), (1100, 75), (1110, 57), (1113, 88), (1122, 27), (1123, 61), (1155, 157), (1167, 137), (1172, 24), (1173, 122), (1174, 24), (1175, 8), (1177, 258), (1186, 233), (1188, 256), (1212, 24), (1223, 102), (1233, 75), (1254, 345), (1257, 29), (1258, 63), (1288, 25), (1293, 99), (1297, 5), (1403, 13), (1435, 6), (1449, 97), (1492, 124), (1497, 1), (1517, 33), (1528, 68), (1556, 119), (1577, 185), (1616, 29), (1701, 48), (1705, 38), (1809, 30), (1848, 58), (1859, 30), (1887, 174), (1991, 14), (1993, 43), (1998, 92)]
def cs78694 : List ℕ := [132, 519, 0, 0, 796, 196, 275, 1000, 805, 0, 131, 1002, 1001, 650, 334, 1001, 774, 1000, 1000, 88, 1002, 0, 0, 1001, 1001, 0, 999, 1666, 507, 596, 1001, 1001, 1001, 1000, 518, 1001, 2313, 1002, 157, 1001, 824, 807, 1001, 872, 2129, 1000, 1000, 979, 266, 999, 1001, 0, 1001, 999, 999, 1000, 995, 1001, 1000, 1000, 1207, 1001, 1002, 1000, 1000, 1001, 1254, 235, 1000, 1000, 1000, 1909, 1001, 999, 1001, 1000, 1659, 1001, 146, 1000, 1000, 1000, 516, 999, 891, 1001, 981, 998, 1000, 1000, 1000, 962, 1000, 826, 1000, 1001, 842, 1000, 1000, 999, 999, 1000, 998, 734, 1001, 1000, 999, 1000, 999, 257, 1000, 1000, 871, 744, 591, 989, 1000, 1000, 1000, 981, 752, 1000, 1000, 1000, 1000, 771, 1002, 1001, 1001, 1000, 999, 1000, 1001, 1000, 1001, 1000, 1000, 751, 1000, 1000, 1000, 937, 999, 1000, 1000, 995, 1000, 999, 980, 885, 767, 1000, 1000, 1000]
theorem node78694 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 21 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78694 support demand code
    entries78694 ((insert 21 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node78687 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 71 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    21 node78693 node78694
def entries78691 : List (Fin 2295 × ℕ) := [(177, 601), (179, 3664), (288, 5734), (342, 1122), (472, 2872), (531, 3537), (552, 2423), (624, 1412), (631, 2312), (639, 143), (664, 448), (737, 2034), (739, 1643), (741, 3559), (817, 770), (846, 977), (849, 1955), (870, 2186), (879, 2497), (887, 989), (888, 1795), (889, 5130), (897, 546), (898, 233), (902, 2299), (908, 2826), (920, 204), (922, 1722), (944, 2796), (945, 1260), (946, 3226), (952, 706), (970, 2115), (973, 4977), (978, 3922), (994, 960), (1033, 924), (1043, 350), (1073, 263), (1075, 197), (1076, 177), (1098, 583), (1099, 1036), (1100, 1492), (1110, 781), (1111, 1056), (1123, 1616), (1141, 94), (1155, 519), (1167, 141), (1171, 362), (1176, 435), (1177, 1575), (1186, 3448), (1219, 389), (1235, 486), (1254, 3135), (1261, 83), (1267, 2327), (1281, 730), (1286, 224), (1293, 1552), (1295, 242), (1375, 684), (1403, 303), (1495, 901), (1497, 65), (1517, 113), (1536, 893), (1577, 2759), (1633, 956), (1654, 1063), (1688, 1479), (1848, 431), (1859, 688), (1887, 797), (1901, 754), (1964, 969), (1991, 1116), (1993, 704), (2225, 521), (2242, 316)]
def cs78691 : List ℕ := [1734, 4501, 3918, 3074, 3135, 1973, 3560, 10000, 5921, 0, 1870, 10000, 9999, 5260, 2759, 8580, 10000, 9999, 9999, 3677, 10000, 9999, 5044, 10000, 10001, 362, 10000, 25154, 7458, 8056, 9999, 9999, 3119, 9999, 5818, 10000, 27491, 10000, 9999, 9999, 6927, 9999, 10001, 6802, 16439, 9999, 10000, 22439, 8751, 10000, 9167, 706, 9999, 10000, 10000, 10067, 9999, 9999, 10000, 10001, 8781, 5016, 8157, 10000, 9186, 10000, 25728, 254, 10000, 19964, 10000, 0, 10001, 10000, 4538, 9999, 19793, 10000, 1542, 10000, 10000, 17323, 5198, 10001, 9999, 6324, 3070, 9659, 10000, 10000, 9988, 9823, 9897, 10000, 10000, 9999, 7992, 10000, 9999, 9192, 10001, 10000, 9389, 10000, 10000, 7446, 10000, 10000, 10000, 3448, 10000, 10000, 6689, 10001, 10001, 10001, 10000, 10000, 10000, 8289, 10000, 9473, 10001, 10000, 10000, 6505, 10000, 9999, 9266, 10001, 10001, 7193, 9999, 9999, 10000, 10000, 8403, 6792, 10001, 10000, 9584, 9378, 9955, 10000, 10000, 7854, 8878, 9622, 7910, 10000, 8725, 10000, 9222, 8944]
theorem node78691 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78691 support demand code
    entries78691 ((insert 71 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries78692 : List (Fin 2295 × ℕ) := [(86, 11), (97, 3), (177, 5), (179, 42), (342, 6), (471, 7), (472, 14), (482, 5), (484, 6), (551, 12), (552, 25), (588, 12), (620, 3), (631, 6), (632, 9), (639, 23), (664, 5), (737, 25), (739, 8), (776, 1), (833, 8), (843, 20), (846, 7), (859, 16), (870, 18), (872, 30), (879, 12), (888, 3), (889, 64), (898, 5), (902, 5), (908, 12), (919, 3), (920, 2), (925, 10), (934, 3), (944, 16), (945, 33), (946, 10), (952, 5), (958, 15), (969, 7), (970, 20), (973, 51), (978, 34), (1009, 1), (1033, 10), (1042, 13), (1073, 29), (1098, 7), (1100, 1), (1110, 15), (1113, 18), (1114, 6), (1123, 3), (1155, 4), (1167, 13), (1174, 2), (1176, 4), (1177, 17), (1186, 33), (1247, 3), (1254, 31), (1261, 14), (1267, 35), (1269, 2), (1281, 7), (1295, 2), (1335, 1), (1495, 29), (1497, 1), (1517, 16), (1535, 28), (1536, 4), (1605, 1), (1609, 7), (1633, 3), (1845, 21), (1848, 7), (1864, 17), (1887, 1), (1901, 34), (1991, 10)]
def cs78692 : List ℕ := [7, 38, 28, 7, 59, 11, 33, 98, 81, 0, 29, 100, 99, 67, 17, 78, 99, 99, 99, 35, 100, 99, 64, 99, 99, 0, 99, 273, 79, 79, 100, 98, 95, 99, 21, 99, 282, 100, 54, 99, 80, 94, 100, 75, 206, 100, 99, 185, 91, 100, 101, 5, 99, 98, 99, 162, 100, 100, 100, 98, 102, 1, 65, 99, 100, 69, 223, 44, 101, 113, 99, 10, 100, 99, 34, 100, 143, 99, 10, 100, 99, 0, 65, 100, 98, 100, 61, 100, 100, 100, 99, 97, 88, 99, 89, 80, 80, 100, 100, 94, 101, 99, 90, 98, 100, 100, 99, 98, 101, 33, 99, 98, 98, 89, 71, 101, 99, 101, 101, 106, 88, 90, 100, 99, 100, 66, 101, 99, 100, 99, 100, 101, 100, 99, 100, 100, 74, 88, 100, 100, 100, 75, 99, 90, 100, 100, 100, 100, 83, 100, 88, 101, 88, 88]
theorem node78692 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 71 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78692 support demand code
    entries78692 ((insert 81 (insert 71 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78689 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    81 node78691 node78692
def entries78690 : List (Fin 2295 × ℕ) := [(177, 54), (179, 524), (289, 126), (342, 53), (474, 61), (551, 91), (552, 320), (583, 20), (584, 128), (620, 146), (625, 244), (631, 422), (639, 1), (664, 110), (675, 134), (737, 77), (739, 157), (741, 177), (816, 22), (833, 36), (842, 49), (843, 233), (846, 62), (849, 235), (852, 121), (870, 191), (872, 522), (879, 113), (888, 70), (889, 734), (897, 130), (901, 61), (908, 34), (922, 257), (928, 127), (944, 161), (958, 3), (959, 266), (965, 181), (969, 138), (970, 62), (973, 505), (978, 280), (994, 191), (1022, 4), (1045, 14), (1047, 3), (1061, 20), (1073, 291), (1100, 139), (1113, 128), (1123, 199), (1155, 68), (1167, 23), (1174, 20), (1175, 125), (1177, 67), (1179, 2), (1183, 4), (1184, 28), (1186, 302), (1247, 105), (1254, 365), (1261, 24), (1281, 16), (1375, 68), (1379, 81), (1403, 156), (1495, 171), (1498, 48), (1517, 73), (1535, 265), (1577, 122), (1627, 36), (1655, 155), (1848, 35), (1849, 165), (1858, 5), (1901, 23), (1991, 105), (1998, 121), (2062, 81), (2225, 18), (2259, 135)]
def cs78690 : List ℕ := [187, 427, 187, 312, 922, 219, 195, 1000, 505, 0, 252, 999, 1000, 626, 158, 865, 852, 999, 1000, 335, 999, 999, 708, 1000, 1000, 0, 1000, 2561, 543, 1000, 999, 999, 402, 1000, 555, 1001, 3021, 999, 831, 999, 728, 801, 999, 906, 2568, 1000, 1000, 2246, 578, 1000, 999, 48, 1000, 999, 1000, 1452, 999, 1000, 1000, 999, 1147, 271, 787, 999, 999, 995, 2167, 103, 1000, 0, 1000, 271, 1000, 999, 639, 1000, 1271, 999, 312, 1000, 1000, 982, 686, 999, 999, 1000, 505, 999, 998, 1000, 983, 805, 1000, 1000, 999, 704, 998, 999, 1000, 1001, 999, 999, 999, 955, 1000, 998, 998, 1000, 952, 332, 999, 1000, 820, 998, 900, 999, 1000, 1000, 999, 1008, 514, 940, 1000, 1001, 999, 874, 999, 1000, 998, 1000, 1000, 744, 999, 1000, 974, 1000, 717, 720, 999, 1000, 999, 832, 846, 1000, 999, 990, 892, 935, 999, 1000, 791, 999, 837, 879]
theorem node78690 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 71 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78690 support demand code
    entries78690 ((insert 69 (insert 71 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node78688 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    69 node78689 node78690
theorem node78686 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 51 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    71 node78687 node78688
theorem node78647 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 60 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    51 node78685 node78686
def entries78683 : List (Fin 2295 × ℕ) := [(25, 35), (50, 30), (152, 41), (179, 50), (472, 102), (475, 20), (490, 9), (512, 37), (551, 8), (581, 38), (587, 3), (588, 54), (621, 8), (622, 94), (625, 1), (632, 40), (639, 20), (672, 28), (674, 32), (675, 41), (680, 6), (741, 10), (756, 46), (812, 6), (813, 21), (815, 56), (817, 22), (849, 42), (851, 53), (860, 47), (870, 68), (872, 19), (874, 59), (888, 4), (892, 98), (897, 54), (898, 61), (902, 51), (908, 127), (920, 4), (944, 70), (959, 40), (969, 28), (970, 20), (973, 118), (978, 100), (993, 2), (1006, 19), (1009, 12), (1012, 38), (1049, 56), (1069, 13), (1076, 19), (1098, 18), (1100, 6), (1110, 30), (1123, 21), (1126, 15), (1143, 21), (1154, 49), (1155, 1), (1171, 11), (1173, 13), (1177, 29), (1186, 88), (1188, 84), (1227, 85), (1254, 1), (1267, 34), (1308, 4), (1375, 14), (1517, 21), (1537, 25), (1572, 4), (1577, 97), (1582, 24), (1636, 23), (1701, 45), (1705, 9), (1751, 1), (1845, 37), (1859, 40), (1964, 26), (1991, 48), (2204, 54)]
def cs78683 : List ℕ := [40, 1, 127, 86, 89, 115, 191, 256, 129, 0, 87, 256, 255, 129, 97, 129, 255, 255, 255, 45, 255, 255, 222, 214, 256, 11, 256, 646, 256, 90, 255, 255, 210, 256, 55, 256, 697, 486, 141, 255, 256, 256, 256, 206, 484, 256, 722, 426, 134, 256, 255, 256, 256, 255, 256, 255, 256, 255, 256, 256, 0, 256, 256, 255, 256, 255, 372, 44, 226, 647, 255, 256, 256, 255, 137, 248, 482, 255, 24, 256, 257, 624, 237, 224, 257, 256, 182, 257, 255, 256, 257, 256, 388, 256, 256, 255, 233, 256, 256, 241, 256, 255, 163, 127, 257, 228, 255, 257, 257, 88, 256, 256, 256, 211, 186, 242, 257, 256, 257, 147, 256, 255, 239, 256, 256, 173, 256, 256, 249, 257, 257, 147, 255, 256, 256, 256, 188, 179, 255, 256, 256, 250, 222, 257, 254, 156, 208, 221, 195, 244, 208, 256, 256, 207]
theorem node78683 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 92 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78683 support demand code
    entries78683 ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 81 (insert 92 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78684 : List (Fin 2295 × ℕ) := [(25, 1710), (50, 1268), (179, 2901), (349, 977), (409, 800), (472, 1926), (475, 513), (490, 370), (507, 141), (512, 2238), (551, 394), (582, 2511), (583, 3197), (588, 3814), (620, 1213), (623, 4984), (629, 214), (631, 651), (639, 547), (737, 695), (739, 45), (756, 102), (818, 1140), (835, 2), (849, 1047), (851, 1387), (860, 2262), (870, 2215), (872, 2081), (873, 1331), (889, 1397), (890, 420), (891, 1109), (897, 972), (898, 1768), (902, 2472), (908, 4478), (922, 143), (944, 1894), (951, 20), (959, 1444), (960, 2632), (970, 2729), (973, 4831), (978, 3592), (1010, 1367), (1012, 907), (1022, 92), (1042, 284), (1047, 2723), (1075, 216), (1076, 488), (1093, 285), (1110, 353), (1111, 13), (1113, 1065), (1123, 276), (1126, 319), (1154, 208), (1155, 965), (1167, 211), (1171, 371), (1172, 644), (1176, 815), (1177, 1187), (1179, 979), (1186, 1965), (1212, 2018), (1261, 116), (1281, 570), (1293, 1308), (1308, 2544), (1354, 163), (1379, 18), (1488, 589), (1497, 570), (1517, 2465), (1528, 1129), (1536, 538), (1537, 3090), (1577, 3409), (1582, 471), (1616, 221), (1845, 397), (1848, 953), (1859, 460), (1950, 319), (1993, 503), (1998, 1269)]
def cs78684 : List ℕ := [1030, 0, 5586, 2601, 3097, 4021, 7175, 10000, 6939, 141, 2727, 10002, 10000, 6502, 3409, 4274, 8773, 10001, 9704, 538, 10001, 8652, 9455, 10001, 10001, 371, 10000, 24379, 10000, 3766, 9998, 10000, 10001, 10000, 1691, 10000, 27299, 17363, 2901, 10001, 10000, 10001, 10000, 7417, 17673, 10000, 19121, 15619, 2901, 9999, 10001, 8196, 10000, 10000, 9999, 10001, 10000, 10001, 10000, 10000, 1417, 10001, 10001, 10000, 9999, 10001, 15755, 2676, 8092, 0, 10001, 10001, 10000, 3164, 10000, 10000, 15313, 10001, 1015, 10001, 10000, 8852, 10001, 10000, 7651, 10001, 10001, 10001, 10000, 10001, 10000, 9330, 18262, 9655, 9999, 10001, 8511, 10000, 10000, 9073, 10000, 10001, 8725, 3012, 10000, 9585, 10000, 10001, 10000, 4962, 10000, 10000, 6081, 6639, 7979, 10001, 10000, 10000, 10001, 8200, 10000, 10000, 10000, 10001, 10000, 6627, 10000, 10001, 7013, 10000, 10001, 10001, 10001, 10001, 10001, 9999, 8836, 10001, 10000, 10000, 10000, 9667, 10001, 9354, 9453, 6997, 10000, 10001, 8910, 10000, 9454, 10001, 10001, 10000]
theorem node78684 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 92 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78684 support demand code
    entries78684 ((insert 69 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 92 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node78681 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 92 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 81 (insert 92 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154))
    69 node78683 node78684
def entries78682 : List (Fin 2295 × ℕ) := [(25, 1448), (50, 787), (99, 784), (179, 1458), (472, 2487), (475, 1985), (482, 104), (512, 4134), (550, 152), (551, 1382), (552, 440), (585, 579), (587, 6), (588, 1969), (623, 4354), (632, 804), (639, 1860), (674, 1413), (675, 910), (677, 784), (728, 866), (739, 565), (756, 687), (817, 580), (842, 98), (849, 2252), (851, 1970), (860, 777), (870, 2127), (872, 2504), (888, 925), (891, 3951), (897, 1699), (898, 999), (902, 3295), (908, 3810), (920, 332), (921, 1144), (944, 3139), (960, 2367), (971, 190), (972, 1358), (973, 4770), (978, 3951), (1007, 1209), (1010, 70), (1033, 456), (1042, 628), (1047, 1438), (1061, 819), (1076, 421), (1100, 988), (1110, 1071), (1113, 292), (1122, 728), (1123, 794), (1126, 170), (1153, 601), (1155, 882), (1172, 794), (1176, 1610), (1177, 2128), (1179, 1527), (1186, 2355), (1212, 748), (1227, 3635), (1233, 426), (1235, 113), (1267, 1835), (1281, 1048), (1361, 288), (1517, 1670), (1537, 1323), (1577, 3064), (1667, 517), (1704, 579), (1705, 865), (1845, 13), (1849, 912), (1852, 1328), (1864, 84), (1950, 1724), (2225, 858)]
def cs78682 : List ℕ := [1048, 0, 4858, 5285, 3418, 1427, 4818, 10000, 4611, 0, 4134, 9978, 10000, 4611, 3148, 5038, 9096, 10000, 10000, 925, 10000, 10000, 6710, 8814, 10000, 0, 10000, 25653, 9999, 2925, 10000, 10000, 10000, 10001, 3046, 8701, 29602, 17198, 5672, 10000, 9999, 10000, 10000, 7535, 19746, 10000, 20569, 15455, 2037, 10000, 10000, 9999, 10001, 10000, 10000, 11720, 10000, 10000, 10000, 10001, 0, 6873, 10000, 10000, 10000, 10000, 15423, 1670, 9188, 10000, 10001, 8398, 10000, 8402, 5441, 9572, 17102, 10000, 794, 10001, 9999, 2367, 9786, 8965, 6730, 10001, 10000, 10001, 9999, 10000, 10000, 9996, 12708, 9999, 9999, 8195, 5846, 9999, 10000, 9546, 10000, 10000, 5279, 6430, 10000, 10000, 10000, 10000, 9999, 6178, 10000, 10000, 5051, 7714, 10000, 10000, 10000, 10000, 10001, 8866, 6259, 8304, 8902, 10001, 9999, 5564, 10001, 10001, 9622, 10000, 8637, 10000, 10002, 9999, 10000, 9999, 8508, 9400, 10001, 10000, 9999, 8819, 10000, 9980, 10001, 9578, 10000, 9263, 10000, 10000, 10001, 10001, 10001, 9181]
theorem node78682 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78682 support demand code
    entries78682 ((insert 81 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node78677 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 92 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    81 node78681 node78682
def entries78679 : List (Fin 2295 × ℕ) := [(25, 5), (99, 6), (152, 1), (179, 5), (342, 9), (431, 8), (472, 8), (475, 27), (478, 10), (484, 11), (512, 35), (550, 24), (551, 16), (571, 8), (582, 9), (622, 16), (625, 43), (639, 35), (675, 14), (681, 42), (741, 1), (849, 20), (851, 45), (860, 3), (870, 23), (872, 4), (890, 2), (891, 40), (896, 5), (897, 15), (898, 15), (902, 29), (907, 41), (920, 7), (944, 23), (960, 8), (971, 13), (972, 7), (973, 49), (978, 41), (1007, 4), (1009, 2), (1034, 1), (1043, 5), (1049, 12), (1061, 1), (1076, 7), (1097, 10), (1098, 14), (1110, 5), (1111, 16), (1113, 7), (1122, 4), (1123, 13), (1153, 14), (1155, 2), (1167, 4), (1173, 4), (1176, 12), (1177, 24), (1178, 4), (1179, 14), (1183, 7), (1186, 23), (1219, 10), (1227, 20), (1241, 9), (1247, 1), (1284, 2), (1293, 12), (1379, 15), (1517, 3), (1537, 14), (1572, 1), (1577, 37), (1636, 1), (1667, 3), (1688, 10), (1701, 15), (1703, 11), (1845, 5), (1852, 17), (1901, 8), (1950, 7), (1991, 3), (1993, 5)]
def cs78679 : List ℕ := [0, 10, 22, 57, 60, 25, 40, 99, 32, 0, 50, 100, 100, 32, 37, 77, 93, 101, 100, 9, 100, 101, 46, 100, 99, 0, 99, 268, 100, 26, 100, 100, 100, 101, 34, 50, 339, 168, 78, 100, 99, 100, 100, 87, 191, 100, 166, 169, 16, 99, 100, 100, 100, 100, 100, 112, 89, 100, 100, 101, 0, 66, 101, 201, 99, 100, 134, 20, 88, 101, 100, 93, 100, 100, 35, 83, 150, 100, 11, 101, 99, 100, 101, 96, 100, 99, 100, 99, 101, 101, 100, 101, 8, 83, 96, 100, 94, 99, 101, 88, 99, 101, 100, 69, 89, 100, 99, 101, 100, 61, 101, 100, 100, 90, 92, 100, 100, 101, 100, 87, 77, 86, 93, 100, 101, 59, 100, 99, 95, 98, 85, 89, 100, 100, 99, 100, 100, 87, 100, 101, 100, 99, 101, 100, 100, 93, 100, 93, 100, 92, 100, 100, 100, 90]
theorem node78679 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 63 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78679 support demand code
    entries78679 ((insert 92 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 63 (insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries78680 : List (Fin 2295 × ℕ) := [(25, 2), (86, 7), (99, 1), (100, 2), (177, 66), (179, 25), (341, 5), (469, 26), (472, 19), (491, 69), (512, 75), (550, 62), (585, 69), (588, 24), (620, 47), (622, 115), (639, 2), (675, 85), (729, 3), (741, 27), (816, 3), (843, 7), (851, 19), (860, 50), (870, 59), (872, 43), (891, 120), (898, 22), (902, 89), (907, 66), (908, 47), (930, 68), (944, 86), (960, 18), (969, 8), (970, 62), (971, 21), (973, 118), (978, 104), (1007, 4), (1010, 24), (1033, 14), (1043, 31), (1047, 18), (1049, 23), (1056, 7), (1076, 34), (1098, 21), (1110, 17), (1113, 27), (1114, 21), (1122, 25), (1123, 9), (1155, 6), (1170, 11), (1175, 10), (1176, 23), (1177, 52), (1178, 4), (1179, 46), (1186, 63), (1212, 9), (1233, 18), (1241, 21), (1272, 3), (1293, 50), (1354, 11), (1517, 21), (1537, 75), (1572, 20), (1607, 4), (1701, 28), (1703, 17), (1705, 3), (1751, 19), (1798, 47), (1845, 32), (1950, 68), (1957, 16), (2002, 27)]
def cs78680 : List ℕ := [0, 73, 141, 47, 21, 122, 117, 256, 256, 74, 138, 256, 256, 137, 63, 62, 232, 191, 237, 0, 255, 256, 154, 218, 256, 11, 256, 658, 228, 139, 171, 256, 256, 255, 10, 256, 723, 305, 176, 256, 256, 256, 200, 185, 387, 255, 569, 191, 108, 256, 256, 241, 192, 257, 271, 304, 256, 256, 256, 255, 47, 222, 256, 0, 256, 256, 417, 28, 250, 256, 256, 256, 127, 226, 212, 204, 389, 256, 79, 255, 203, 256, 174, 256, 114, 256, 256, 255, 256, 256, 255, 257, 65, 255, 256, 256, 173, 257, 255, 255, 255, 257, 255, 122, 256, 256, 256, 255, 256, 143, 256, 257, 190, 256, 256, 255, 255, 255, 256, 227, 189, 256, 256, 254, 256, 129, 257, 257, 216, 255, 186, 238, 256, 257, 256, 256, 254, 248, 256, 256, 255, 234, 256, 230, 255, 233, 251, 219, 257, 234, 256, 256, 255, 235]
theorem node78680 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 63 (insert 92 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78680 support demand code
    entries78680 ((insert 63 (insert 92 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78678 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    63 node78679 node78680
theorem node78669 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 37 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    92 node78677 node78678
def entries78675 : List (Fin 2295 × ℕ) := [(99, 52), (177, 13), (179, 122), (227, 66), (315, 1), (431, 18), (472, 152), (515, 19), (531, 84), (540, 17), (541, 67), (542, 24), (551, 49), (552, 55), (585, 23), (622, 103), (674, 51), (675, 56), (728, 29), (739, 14), (741, 54), (812, 25), (814, 4), (815, 46), (817, 19), (849, 53), (860, 39), (869, 18), (870, 89), (872, 1), (873, 2), (880, 33), (892, 135), (902, 51), (908, 86), (920, 12), (944, 102), (945, 5), (946, 73), (952, 26), (959, 12), (969, 30), (973, 128), (978, 96), (1006, 9), (1012, 33), (1049, 46), (1098, 6), (1122, 6), (1123, 1), (1126, 37), (1141, 6), (1143, 11), (1155, 37), (1173, 46), (1176, 1), (1177, 53), (1186, 60), (1188, 3), (1212, 5), (1223, 52), (1226, 32), (1227, 41), (1233, 27), (1245, 36), (1254, 34), (1284, 2), (1295, 7), (1308, 7), (1375, 10), (1390, 12), (1401, 13), (1403, 7), (1572, 5), (1636, 33), (1701, 40), (1705, 12), (1845, 25), (1852, 22), (1901, 44), (1931, 17), (1932, 2), (1950, 17), (1991, 30), (1995, 21), (2225, 24)]
def cs78675 : List ℕ := [52, 34, 152, 53, 88, 0, 0, 257, 203, 0, 19, 193, 256, 202, 140, 137, 257, 256, 255, 0, 257, 256, 135, 258, 256, 0, 257, 490, 255, 135, 257, 257, 0, 256, 132, 256, 788, 0, 233, 256, 256, 135, 225, 147, 546, 255, 811, 262, 248, 258, 180, 257, 212, 256, 274, 255, 255, 257, 255, 258, 26, 255, 216, 257, 258, 256, 406, 51, 256, 702, 256, 256, 256, 255, 182, 243, 553, 257, 46, 257, 255, 651, 236, 256, 256, 254, 256, 257, 253, 257, 256, 257, 256, 257, 196, 255, 168, 256, 254, 258, 256, 257, 175, 253, 255, 256, 256, 257, 257, 65, 257, 257, 231, 255, 232, 250, 257, 256, 256, 191, 255, 255, 256, 258, 256, 183, 256, 256, 212, 256, 239, 182, 257, 256, 257, 256, 233, 210, 257, 257, 231, 256, 233, 257, 194, 202, 256, 257, 256, 256, 257, 257, 193, 257]
theorem node78675 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 69 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78675 support demand code
    entries78675 ((insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 69 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78676 : List (Fin 2295 × ℕ) := [(50, 4), (86, 8), (99, 8), (177, 36), (179, 51), (472, 30), (515, 109), (540, 7), (542, 67), (550, 133), (552, 29), (577, 9), (585, 68), (623, 100), (675, 62), (728, 23), (833, 18), (843, 14), (849, 11), (852, 12), (860, 27), (869, 52), (870, 94), (872, 40), (890, 2), (891, 84), (896, 21), (902, 47), (908, 92), (920, 29), (921, 8), (944, 85), (945, 1), (952, 41), (959, 23), (971, 20), (972, 43), (973, 122), (978, 77), (1007, 35), (1033, 9), (1034, 8), (1047, 16), (1056, 7), (1061, 14), (1068, 2), (1076, 28), (1097, 2), (1098, 6), (1099, 1), (1100, 34), (1110, 7), (1111, 39), (1113, 13), (1122, 31), (1123, 23), (1153, 33), (1155, 5), (1167, 16), (1172, 4), (1176, 47), (1177, 67), (1178, 3), (1179, 46), (1183, 11), (1186, 34), (1212, 22), (1235, 14), (1245, 18), (1247, 20), (1254, 37), (1267, 62), (1284, 7), (1401, 27), (1537, 63), (1663, 13), (1667, 12), (1703, 1), (1704, 4), (1848, 26), (1852, 37), (1950, 114)]
def cs78676 : List ℕ := [0, 37, 93, 11, 49, 63, 0, 256, 245, 0, 109, 191, 256, 111, 101, 162, 239, 258, 122, 0, 256, 255, 92, 256, 255, 0, 256, 491, 254, 92, 257, 256, 133, 257, 15, 256, 919, 0, 110, 257, 255, 105, 223, 256, 452, 255, 688, 212, 93, 256, 146, 256, 223, 257, 286, 305, 257, 256, 255, 256, 41, 256, 231, 256, 256, 256, 358, 107, 257, 193, 256, 256, 256, 255, 186, 256, 371, 257, 15, 258, 255, 23, 197, 208, 144, 256, 255, 257, 255, 257, 256, 230, 256, 255, 232, 214, 184, 255, 257, 200, 256, 257, 189, 188, 255, 255, 257, 256, 256, 168, 256, 256, 175, 255, 257, 256, 256, 257, 257, 243, 166, 257, 256, 257, 256, 155, 256, 257, 215, 257, 225, 256, 257, 256, 256, 256, 236, 224, 257, 256, 256, 245, 249, 257, 257, 245, 256, 257, 256, 257, 257, 248, 257, 194]
theorem node78676 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78676 support demand code
    entries78676 ((insert 81 (insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78671 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    81 node78675 node78676
def entries78673 : List (Fin 2295 × ℕ) := [(23, 8), (159, 21), (177, 16), (179, 141), (273, 25), (342, 42), (483, 4), (515, 113), (541, 59), (550, 57), (552, 69), (579, 39), (582, 20), (584, 24), (623, 79), (625, 2), (639, 14), (675, 91), (738, 31), (741, 83), (849, 47), (851, 16), (852, 76), (859, 4), (869, 25), (870, 68), (872, 63), (890, 13), (891, 106), (902, 64), (908, 84), (920, 53), (944, 32), (951, 14), (959, 22), (960, 64), (969, 23), (970, 55), (973, 129), (978, 64), (1007, 18), (1010, 28), (1020, 9), (1022, 21), (1047, 48), (1073, 37), (1075, 21), (1076, 14), (1093, 8), (1094, 2), (1113, 10), (1155, 34), (1172, 8), (1173, 22), (1174, 13), (1175, 3), (1177, 53), (1179, 21), (1186, 37), (1212, 33), (1241, 19), (1247, 3), (1254, 13), (1261, 1), (1293, 44), (1298, 16), (1370, 16), (1375, 11), (1403, 34), (1434, 45), (1528, 13), (1537, 55), (1627, 20), (1667, 8), (1845, 19), (1848, 32), (1856, 7), (1887, 11), (1950, 17), (1991, 10), (2061, 6), (2242, 51)]
def cs78673 : List ℕ := [71, 13, 126, 47, 133, 130, 0, 256, 154, 0, 113, 126, 256, 163, 79, 126, 256, 255, 218, 0, 256, 243, 157, 256, 256, 0, 225, 479, 165, 157, 255, 256, 82, 255, 93, 256, 929, 0, 157, 256, 256, 164, 256, 152, 529, 256, 442, 192, 157, 256, 210, 257, 174, 255, 256, 256, 256, 256, 256, 255, 14, 254, 168, 256, 255, 255, 347, 25, 256, 0, 498, 256, 256, 256, 207, 176, 421, 255, 30, 255, 256, 255, 226, 256, 193, 255, 257, 255, 256, 255, 255, 212, 256, 251, 144, 256, 149, 257, 255, 238, 256, 254, 256, 238, 257, 256, 257, 255, 256, 91, 255, 255, 157, 256, 256, 255, 257, 256, 255, 274, 231, 170, 206, 256, 257, 165, 256, 256, 257, 257, 204, 255, 256, 255, 257, 257, 233, 246, 256, 255, 257, 251, 255, 251, 257, 254, 256, 210, 255, 256, 255, 255, 231, 252]
theorem node78673 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78673 support demand code
    entries78673 ((insert 69 (insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 70 (insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78674 : List (Fin 2295 × ℕ) := [(177, 8), (179, 5), (431, 2), (515, 11), (541, 6), (550, 8), (552, 5), (583, 4), (620, 13), (623, 10), (675, 3), (729, 2), (736, 2), (739, 3), (816, 3), (851, 3), (852, 7), (860, 2), (869, 4), (870, 14), (891, 12), (892, 4), (908, 12), (922, 7), (930, 3), (944, 9), (960, 5), (969, 5), (970, 3), (971, 1), (972, 6), (973, 17), (978, 7), (994, 4), (1012, 1), (1047, 2), (1076, 2), (1098, 6), (1111, 5), (1113, 4), (1123, 5), (1153, 1), (1155, 3), (1167, 4), (1176, 3), (1177, 8), (1179, 7), (1186, 3), (1212, 1), (1223, 2), (1241, 2), (1293, 2), (1299, 2), (1354, 2), (1488, 3), (1627, 10), (1645, 2), (1663, 2), (1667, 8), (1950, 8), (1958, 7), (1991, 1), (2259, 2)]
def cs78674 : List ℕ := [14, 0, 12, 0, 24, 19, 0, 32, 24, 0, 11, 32, 33, 7, 16, 20, 32, 31, 7, 0, 31, 32, 13, 22, 32, 0, 32, 65, 24, 13, 32, 32, 15, 32, 0, 19, 101, 0, 16, 32, 26, 11, 25, 27, 49, 32, 77, 24, 13, 32, 18, 14, 22, 32, 34, 38, 26, 32, 32, 33, 2, 32, 27, 31, 21, 30, 37, 8, 31, 4, 0, 32, 31, 21, 29, 27, 51, 32, 3, 31, 32, 18, 32, 32, 12, 32, 31, 33, 32, 31, 15, 27, 32, 32, 29, 30, 31, 32, 32, 31, 32, 32, 28, 23, 32, 31, 31, 31, 30, 18, 32, 32, 30, 22, 32, 31, 31, 31, 33, 28, 28, 24, 32, 31, 31, 27, 32, 32, 29, 31, 24, 32, 32, 32, 31, 31, 28, 32, 32, 31, 31, 31, 32, 32, 31, 32, 27, 30, 32, 32, 32, 29, 29, 26]
theorem node78674 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 69 (insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78674 support demand code
    entries78674 ((insert 70 (insert 69 (insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
theorem node78672 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    70 node78673 node78674
theorem node78670 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 37 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    69 node78671 node78672
theorem node78649 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    37 node78669 node78670
def entries78667 : List (Fin 2295 × ℕ) := [(23, 66), (49, 53), (98, 42), (269, 4), (271, 5), (273, 8), (288, 126), (512, 62), (541, 5), (551, 106), (552, 29), (571, 29), (632, 40), (639, 2), (681, 71), (691, 4), (693, 4), (727, 18), (736, 49), (738, 8), (739, 24), (851, 27), (870, 73), (872, 26), (887, 15), (888, 69), (891, 104), (897, 6), (898, 71), (920, 82), (922, 47), (934, 18), (944, 105), (959, 27), (960, 86), (970, 69), (973, 131), (978, 87), (1009, 4), (1012, 14), (1033, 1), (1043, 1), (1049, 13), (1061, 22), (1076, 13), (1098, 5), (1100, 24), (1110, 22), (1113, 5), (1123, 14), (1126, 14), (1143, 17), (1155, 35), (1170, 5), (1171, 41), (1173, 16), (1177, 60), (1179, 49), (1186, 32), (1212, 16), (1219, 18), (1246, 13), (1247, 20), (1254, 65), (1281, 29), (1285, 9), (1293, 41), (1296, 15), (1342, 21), (1384, 12), (1403, 16), (1433, 28), (1488, 4), (1517, 62), (1537, 51), (1547, 5), (1582, 16), (1591, 10), (1635, 29), (1636, 5), (1701, 7), (1705, 5), (1845, 12), (1991, 2), (1993, 6), (1998, 7), (2000, 25), (2023, 4), (2225, 24)]
def cs78667 : List ℕ := [29, 83, 80, 72, 158, 82, 78, 256, 193, 0, 78, 256, 256, 143, 5, 151, 256, 256, 325, 113, 257, 104, 77, 192, 255, 46, 256, 620, 0, 40, 256, 256, 141, 257, 34, 256, 403, 257, 256, 541, 98, 256, 256, 142, 557, 233, 0, 518, 46, 256, 241, 251, 45, 257, 256, 255, 254, 497, 256, 257, 0, 209, 256, 257, 256, 254, 462, 96, 256, 256, 255, 256, 257, 181, 73, 256, 540, 255, 62, 257, 257, 462, 137, 257, 221, 256, 255, 256, 256, 255, 257, 255, 256, 257, 257, 255, 198, 257, 256, 257, 257, 256, 257, 183, 255, 256, 257, 257, 256, 97, 255, 257, 257, 227, 189, 257, 256, 257, 255, 191, 257, 257, 256, 256, 257, 197, 256, 256, 246, 257, 230, 196, 256, 257, 256, 257, 255, 255, 256, 256, 249, 256, 256, 256, 234, 255, 256, 218, 256, 256, 256, 256, 228, 218]
theorem node78667 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 39 (insert 81 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78667 support demand code
    entries78667 ((insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 57 (insert 39 (insert 81 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78668 : List (Fin 2295 × ℕ) := [(49, 26), (100, 19), (177, 2), (179, 14), (342, 23), (431, 1), (471, 24), (484, 14), (512, 7), (531, 23), (541, 27), (551, 14), (552, 7), (572, 11), (639, 43), (730, 3), (736, 12), (741, 5), (846, 3), (849, 30), (851, 42), (870, 34), (874, 17), (888, 30), (891, 38), (898, 12), (902, 7), (920, 20), (944, 20), (951, 6), (952, 12), (969, 9), (970, 2), (973, 50), (976, 3), (978, 32), (1009, 5), (1012, 11), (1047, 10), (1049, 5), (1076, 7), (1098, 8), (1108, 3), (1110, 2), (1123, 5), (1126, 9), (1137, 4), (1141, 1), (1153, 5), (1155, 23), (1170, 5), (1171, 19), (1172, 3), (1176, 4), (1177, 27), (1179, 14), (1186, 9), (1188, 14), (1212, 14), (1226, 24), (1261, 15), (1293, 5), (1308, 6), (1370, 4), (1375, 1), (1403, 7), (1491, 2), (1577, 36), (1635, 1), (1636, 5), (1645, 2), (1667, 2), (1701, 16), (1703, 14), (1704, 2), (1705, 9), (1798, 17), (1845, 3), (1859, 13), (1991, 8)]
def cs78668 : List ℕ := [13, 20, 41, 47, 42, 44, 49, 99, 43, 17, 24, 100, 100, 59, 80, 59, 78, 99, 186, 41, 100, 55, 44, 100, 100, 24, 100, 217, 2, 32, 100, 100, 53, 99, 38, 100, 185, 99, 32, 175, 30, 74, 100, 99, 219, 100, 2, 106, 73, 91, 100, 48, 86, 99, 99, 100, 89, 0, 100, 100, 35, 79, 100, 100, 99, 100, 136, 6, 100, 100, 100, 100, 101, 100, 32, 99, 187, 100, 27, 100, 84, 149, 81, 100, 100, 93, 100, 99, 100, 99, 99, 96, 99, 100, 72, 99, 99, 99, 99, 84, 100, 100, 73, 52, 100, 99, 99, 99, 100, 37, 99, 100, 98, 73, 83, 100, 100, 100, 99, 81, 100, 99, 90, 99, 100, 86, 100, 101, 94, 101, 94, 93, 100, 101, 99, 99, 100, 95, 99, 100, 100, 100, 100, 94, 99, 100, 100, 97, 100, 100, 100, 100, 92, 96]
theorem node78668 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 57 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 81 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78668 support demand code
    entries78668 ((insert 57 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 39 (insert 81 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78665 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 81 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 39 (insert 81 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    57 node78667 node78668
def entries78666 : List (Fin 2295 × ℕ) := [(21, 102), (86, 2693), (100, 4567), (177, 856), (179, 4646), (273, 331), (289, 1214), (475, 1696), (491, 714), (551, 2865), (582, 714), (584, 2126), (639, 1999), (681, 102), (727, 6), (729, 102), (738, 1472), (741, 341), (851, 4409), (858, 558), (859, 621), (872, 2214), (874, 123), (888, 1794), (891, 3760), (898, 107), (902, 2409), (922, 120), (933, 323), (944, 3284), (951, 631), (952, 751), (958, 325), (960, 3886), (970, 2680), (973, 4836), (978, 3369), (1009, 130), (1012, 631), (1033, 193), (1043, 645), (1047, 494), (1049, 1242), (1093, 92), (1094, 1061), (1097, 235), (1098, 1394), (1113, 644), (1123, 775), (1153, 1125), (1155, 1125), (1167, 1576), (1172, 77), (1173, 1941), (1175, 836), (1177, 1743), (1179, 585), (1186, 2026), (1212, 560), (1234, 884), (1237, 919), (1246, 2298), (1247, 638), (1269, 815), (1293, 1911), (1379, 1835), (1384, 826), (1403, 1654), (1433, 2354), (1488, 309), (1498, 1271), (1635, 90), (1705, 715), (1740, 1302), (1846, 440), (1848, 432), (1859, 3687), (1991, 279), (2225, 220), (2242, 693), (2259, 292)]
def cs78666 : List ℕ := [4672, 919, 985, 1798, 5620, 6862, 4959, 10000, 621, 0, 3137, 10001, 9281, 8206, 0, 5438, 9999, 9283, 13691, 1794, 10000, 9737, 5609, 10000, 7342, 0, 9999, 18832, 0, 5502, 9999, 10001, 8287, 10000, 2854, 10000, 20807, 10001, 10000, 120, 3498, 10001, 10000, 7929, 20374, 9001, 0, 15880, 9510, 10000, 8782, 6268, 10001, 7929, 10001, 10001, 9644, 10000, 10001, 6323, 2653, 9527, 9672, 10000, 10001, 10001, 12686, 2549, 10001, 10000, 9999, 10000, 10000, 10001, 5205, 10001, 18508, 10000, 2018, 10001, 9580, 16773, 6387, 10001, 9999, 10002, 9909, 9999, 10001, 10000, 10000, 9844, 9999, 10000, 6824, 10001, 8534, 10000, 9999, 8173, 10001, 10001, 10000, 8877, 10000, 10000, 10000, 10001, 10001, 3171, 10001, 10002, 9999, 9700, 8788, 10002, 9999, 10000, 10000, 7415, 9999, 10000, 9784, 9999, 10000, 8560, 10001, 9999, 10000, 10001, 8463, 9068, 10000, 9998, 10000, 10000, 10001, 8553, 10000, 10000, 9998, 9624, 10000, 10000, 9753, 8715, 9951, 9713, 10000, 10001, 9999, 10001, 9947, 8547]
theorem node78666 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78666 support demand code
    entries78666 ((insert 39 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node78661 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    39 node78665 node78666
def entries78663 : List (Fin 2295 × ℕ) := [(23, 57), (49, 17), (177, 9), (179, 17), (341, 9), (342, 4), (482, 2), (491, 26), (551, 55), (572, 56), (630, 9), (639, 50), (676, 6), (677, 4), (678, 43), (680, 47), (726, 6), (731, 61), (737, 59), (739, 27), (816, 22), (849, 39), (851, 103), (870, 89), (888, 87), (891, 106), (898, 27), (920, 93), (921, 20), (934, 27), (944, 83), (946, 25), (969, 20), (972, 42), (973, 122), (978, 96), (993, 20), (1033, 4), (1034, 8), (1042, 8), (1047, 33), (1056, 18), (1061, 17), (1076, 38), (1100, 10), (1111, 39), (1113, 3), (1122, 7), (1123, 42), (1126, 8), (1152, 14), (1153, 22), (1155, 24), (1170, 7), (1171, 19), (1172, 14), (1176, 41), (1177, 65), (1179, 44), (1186, 27), (1212, 28), (1234, 28), (1235, 12), (1261, 1), (1281, 46), (1285, 22), (1296, 47), (1361, 4), (1370, 8), (1379, 16), (1491, 10), (1495, 62), (1517, 32), (1537, 10), (1577, 1), (1667, 20), (1703, 14), (1704, 39), (1705, 20), (1849, 30), (1852, 29), (1859, 39), (1964, 34)]
def cs78663 : List ℕ := [85, 0, 56, 107, 160, 132, 98, 255, 130, 0, 112, 255, 256, 113, 1, 128, 256, 256, 313, 143, 256, 122, 106, 165, 255, 26, 256, 621, 0, 88, 256, 256, 177, 257, 63, 256, 363, 256, 197, 518, 93, 255, 256, 192, 483, 256, 0, 285, 193, 256, 256, 253, 56, 257, 257, 290, 256, 256, 257, 256, 0, 155, 256, 256, 257, 256, 344, 50, 257, 229, 256, 136, 256, 256, 48, 249, 368, 256, 40, 257, 257, 0, 173, 257, 256, 257, 256, 257, 256, 257, 257, 247, 256, 257, 235, 212, 186, 256, 257, 259, 257, 256, 256, 189, 256, 257, 256, 258, 258, 141, 256, 257, 203, 248, 257, 237, 257, 257, 258, 232, 216, 256, 257, 258, 257, 162, 256, 256, 251, 257, 241, 257, 256, 256, 256, 257, 247, 220, 256, 257, 257, 256, 257, 258, 257, 255, 247, 245, 256, 257, 256, 256, 243, 201]
theorem node78663 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78663 support demand code
    entries78663 ((insert 81 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 39 (insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78664 : List (Fin 2295 × ℕ) := [(86, 46), (98, 25), (146, 11), (179, 39), (289, 79), (341, 6), (342, 9), (352, 4), (475, 41), (483, 31), (491, 31), (529, 39), (550, 77), (551, 47), (572, 86), (582, 40), (639, 49), (680, 41), (731, 61), (737, 43), (739, 23), (843, 26), (851, 86), (852, 32), (860, 24), (872, 38), (888, 10), (891, 97), (902, 69), (924, 41), (934, 15), (944, 76), (946, 21), (958, 13), (969, 11), (970, 50), (973, 106), (978, 120), (1007, 14), (1012, 4), (1033, 15), (1047, 32), (1076, 14), (1093, 8), (1098, 44), (1099, 40), (1100, 9), (1111, 34), (1113, 21), (1114, 8), (1120, 9), (1122, 10), (1123, 32), (1155, 29), (1167, 15), (1172, 28), (1173, 13), (1174, 37), (1175, 11), (1177, 59), (1179, 48), (1186, 30), (1212, 38), (1235, 6), (1237, 11), (1241, 10), (1261, 9), (1293, 32), (1295, 1), (1379, 87), (1434, 3), (1477, 32), (1488, 12), (1667, 1), (1703, 32), (1704, 34), (1705, 22), (1859, 97), (2259, 30)]
def cs78664 : List ℕ := [127, 11, 30, 41, 159, 169, 128, 256, 27, 0, 87, 256, 237, 105, 0, 124, 256, 222, 243, 96, 256, 224, 105, 256, 196, 0, 257, 476, 0, 105, 256, 256, 256, 256, 89, 257, 509, 256, 257, 0, 176, 256, 256, 225, 424, 257, 56, 326, 187, 242, 179, 201, 256, 253, 256, 257, 252, 257, 256, 255, 41, 224, 245, 256, 255, 257, 332, 28, 256, 155, 223, 215, 256, 229, 164, 198, 362, 256, 41, 256, 257, 0, 163, 257, 257, 258, 256, 255, 256, 256, 256, 255, 256, 220, 206, 234, 212, 257, 257, 220, 255, 255, 256, 169, 257, 256, 258, 257, 256, 116, 255, 256, 128, 256, 257, 256, 257, 256, 255, 214, 247, 257, 256, 257, 257, 162, 256, 256, 257, 257, 245, 256, 256, 255, 257, 257, 226, 229, 255, 255, 256, 256, 255, 185, 257, 256, 256, 251, 255, 233, 256, 244, 222, 213]
theorem node78664 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 81 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78664 support demand code
    entries78664 ((insert 39 (insert 81 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78662 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    39 node78663 node78664
theorem node78651 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 18 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    81 node78661 node78662
def entries78659 : List (Fin 2295 × ℕ) := [(20, 134), (179, 139), (273, 93), (289, 88), (466, 163), (472, 10), (478, 2), (498, 124), (514, 1), (550, 83), (551, 185), (552, 218), (571, 195), (582, 483), (588, 251), (632, 214), (679, 254), (690, 26), (737, 66), (738, 11), (739, 125), (743, 47), (832, 21), (833, 99), (851, 466), (857, 99), (862, 289), (870, 169), (888, 148), (891, 329), (920, 386), (933, 31), (944, 241), (959, 267), (960, 243), (969, 108), (970, 77), (973, 426), (978, 288), (1009, 1), (1010, 40), (1012, 290), (1019, 246), (1022, 286), (1033, 249), (1047, 292), (1049, 160), (1073, 233), (1094, 278), (1098, 260), (1100, 61), (1111, 10), (1121, 61), (1123, 252), (1126, 31), (1143, 1), (1147, 57), (1154, 11), (1155, 33), (1160, 3), (1173, 110), (1177, 112), (1179, 36), (1186, 462), (1188, 54), (1223, 245), (1237, 114), (1247, 2), (1261, 152), (1354, 21), (1403, 34), (1495, 69), (1498, 66), (1517, 309), (1616, 68), (1670, 8), (1685, 63), (1701, 15), (1745, 94), (1993, 113), (2280, 34), (2293, 22)]
def cs78659 : List ℕ := [408, 114, 10, 134, 827, 180, 408, 1000, 792, 0, 70, 1000, 1001, 134, 0, 684, 668, 999, 0, 343, 1000, 875, 487, 648, 745, 0, 1001, 1842, 63, 606, 1000, 1000, 905, 1000, 173, 1001, 2025, 999, 552, 999, 418, 999, 999, 288, 1592, 1000, 245, 1460, 286, 1000, 821, 837, 1000, 845, 1000, 999, 1001, 999, 999, 999, 66, 999, 1000, 999, 1000, 1000, 1298, 309, 999, 493, 1000, 999, 999, 999, 795, 1000, 1518, 1000, 110, 1032, 574, 999, 807, 999, 1000, 1000, 1000, 1000, 1000, 1000, 1001, 1253, 999, 999, 999, 999, 665, 1001, 999, 787, 1000, 1001, 999, 1000, 1000, 1000, 1000, 1002, 1000, 555, 1000, 1001, 999, 523, 953, 1001, 1468, 1000, 1001, 811, 1000, 999, 925, 992, 999, 537, 1001, 2519, 999, 1000, 1001, 864, 1001, 1000, 1000, 1000, 761, 1000, 1000, 1001, 988, 732, 799, 1001, 951, 807, 710, 931, 599, 1000, 992, 1001, 1000, 1000]
theorem node78659 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 116 (insert 91 (insert 127 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78659 support demand code
    entries78659 ((insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 116 (insert 91 (insert 127 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries78660 : List (Fin 2295 × ℕ) := [(179, 18), (273, 14), (342, 2), (466, 51), (478, 4), (491, 3), (498, 23), (551, 13), (552, 3), (571, 7), (572, 2), (582, 7), (630, 16), (632, 2), (639, 1), (680, 8), (690, 6), (691, 4), (731, 3), (736, 2), (737, 14), (739, 4), (813, 4), (835, 17), (851, 40), (862, 11), (870, 38), (887, 8), (888, 33), (889, 7), (891, 43), (898, 24), (920, 39), (933, 2), (934, 2), (944, 37), (959, 34), (960, 2), (969, 23), (970, 8), (972, 9), (973, 45), (978, 52), (1019, 3), (1033, 14), (1047, 43), (1049, 3), (1073, 21), (1075, 3), (1093, 27), (1094, 3), (1111, 10), (1114, 5), (1123, 13), (1143, 1), (1154, 12), (1162, 6), (1173, 14), (1177, 28), (1186, 10), (1199, 10), (1247, 12), (1342, 27), (1379, 20), (1433, 4), (1494, 3), (1495, 23), (1498, 2), (1668, 14), (1685, 5), (1701, 13), (1847, 1), (1848, 32), (1945, 9), (1998, 11), (2157, 9)]
def cs78660 : List ℕ := [51, 10, 0, 0, 54, 15, 13, 95, 56, 0, 46, 92, 99, 10, 10, 46, 99, 100, 0, 50, 100, 95, 47, 100, 41, 10, 99, 124, 5, 51, 101, 86, 42, 61, 19, 93, 165, 100, 58, 100, 22, 100, 101, 64, 156, 99, 0, 138, 53, 98, 84, 100, 53, 76, 99, 99, 100, 100, 100, 99, 12, 90, 101, 100, 99, 100, 152, 0, 101, 80, 100, 101, 100, 101, 14, 99, 170, 100, 14, 100, 69, 101, 60, 101, 99, 99, 100, 99, 101, 100, 94, 111, 100, 100, 100, 100, 67, 99, 100, 77, 100, 100, 100, 88, 99, 81, 100, 99, 99, 19, 100, 132, 100, 93, 100, 99, 24, 101, 100, 94, 100, 100, 99, 87, 99, 59, 100, 178, 100, 99, 99, 73, 100, 100, 74, 99, 87, 100, 100, 100, 99, 100, 77, 91, 99, 100, 82, 86, 100, 86, 99, 98, 87, 64]
theorem node78660 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 116 (insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 91 (insert 127 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78660 support demand code
    entries78660 ((insert 116 (insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 91 (insert 127 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78657 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 91 (insert 127 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 91 (insert 127 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    116 node78659 node78660
def entries78658 : List (Fin 2295 × ℕ) := [(179, 242), (288, 59), (289, 124), (342, 124), (466, 449), (498, 222), (550, 291), (551, 33), (552, 191), (571, 248), (582, 391), (588, 75), (630, 133), (632, 206), (679, 141), (690, 290), (737, 93), (851, 338), (852, 94), (857, 35), (859, 184), (870, 329), (888, 112), (891, 282), (897, 36), (898, 48), (920, 220), (934, 245), (944, 282), (959, 64), (960, 110), (969, 50), (970, 95), (973, 431), (1007, 142), (1012, 15), (1019, 73), (1022, 100), (1033, 37), (1043, 26), (1047, 33), (1049, 108), (1073, 125), (1076, 116), (1093, 216), (1094, 60), (1098, 80), (1100, 65), (1123, 117), (1143, 11), (1154, 28), (1155, 95), (1162, 63), (1167, 186), (1176, 117), (1177, 167), (1179, 213), (1186, 246), (1212, 19), (1234, 16), (1237, 89), (1247, 118), (1254, 27), (1261, 68), (1277, 35), (1293, 124), (1308, 13), (1379, 26), (1403, 184), (1433, 29), (1488, 22), (1495, 266), (1500, 16), (1508, 38), (1517, 103), (1534, 47), (1541, 110), (1547, 36), (1572, 8), (1577, 3), (1616, 61), (1667, 43), (1685, 128), (1745, 21), (2061, 168), (2157, 26), (2242, 3), (2293, 45)]
def cs78658 : List ℕ := [452, 116, 3, 0, 548, 92, 141, 1000, 459, 0, 292, 1000, 1000, 0, 3, 912, 860, 656, 0, 360, 1001, 827, 529, 816, 876, 0, 1001, 1621, 128, 754, 1000, 726, 735, 1000, 128, 702, 2124, 1002, 710, 999, 585, 1001, 1000, 357, 1473, 1001, 94, 1292, 447, 1000, 1000, 781, 1001, 943, 1000, 1000, 1000, 1001, 1000, 999, 0, 947, 1000, 1000, 999, 1000, 1061, 289, 1000, 749, 999, 1000, 1001, 1000, 574, 1000, 1546, 999, 0, 1000, 483, 1001, 824, 1001, 1000, 1000, 999, 999, 1001, 1000, 848, 483, 1001, 1000, 961, 1000, 1000, 1000, 1002, 736, 1000, 1000, 1000, 1000, 1000, 1001, 1001, 1000, 1000, 478, 1001, 1000, 1000, 565, 1001, 1000, 1000, 1000, 1001, 840, 1001, 1002, 1000, 999, 1001, 785, 1000, 1526, 1000, 1000, 984, 1001, 1000, 1001, 999, 1001, 749, 999, 1002, 1000, 1000, 1000, 832, 964, 1001, 999, 632, 1000, 1000, 974, 1001, 874, 1000, 887]
theorem node78658 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 91 (insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 127 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78658 support demand code
    entries78658 ((insert 91 (insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 127 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node78653 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 127 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 127 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    91 node78657 node78658
def entries78655 : List (Fin 2295 × ℕ) := [(179, 356), (273, 70), (288, 105), (342, 130), (466, 228), (472, 114), (483, 135), (490, 103), (498, 345), (514, 104), (551, 199), (552, 19), (571, 82), (582, 271), (588, 17), (690, 185), (727, 48), (728, 20), (731, 4), (737, 66), (739, 74), (833, 23), (851, 204), (852, 54), (862, 70), (870, 340), (887, 55), (888, 227), (889, 67), (891, 341), (898, 127), (902, 154), (920, 183), (922, 60), (934, 86), (944, 243), (952, 23), (969, 284), (973, 367), (978, 439), (993, 45), (1009, 34), (1010, 39), (1033, 48), (1075, 118), (1097, 55), (1099, 7), (1110, 35), (1111, 35), (1120, 194), (1152, 12), (1153, 281), (1154, 342), (1167, 76), (1170, 179), (1173, 194), (1176, 70), (1177, 269), (1178, 108), (1233, 101), (1237, 133), (1241, 146), (1246, 25), (1257, 1), (1261, 168), (1308, 61), (1335, 9), (1342, 87), (1379, 167), (1495, 70), (1500, 152), (1508, 52), (1517, 95), (1528, 100), (1534, 124), (1577, 51), (1681, 12), (1701, 137), (1983, 32), (2022, 101), (2157, 39), (2259, 50), (2292, 215)]
def cs78655 : List ℕ := [278, 133, 164, 0, 441, 318, 249, 783, 454, 0, 341, 1000, 1000, 0, 51, 339, 1001, 1000, 0, 364, 1001, 846, 500, 1000, 771, 179, 1000, 1487, 0, 583, 1000, 1001, 355, 832, 194, 872, 1821, 1000, 605, 1000, 600, 999, 1000, 789, 1389, 1000, 54, 1513, 851, 999, 647, 671, 1000, 967, 999, 1001, 999, 998, 999, 999, 90, 904, 1000, 1000, 999, 1001, 1399, 171, 979, 796, 999, 1000, 1001, 998, 676, 1000, 1584, 1000, 373, 1000, 802, 1000, 522, 999, 998, 1000, 1001, 999, 1000, 1001, 1000, 1000, 998, 1000, 871, 1001, 1000, 999, 1000, 956, 999, 1000, 997, 452, 1000, 1000, 1000, 1001, 1000, 108, 1000, 1000, 999, 1000, 972, 1002, 1000, 999, 999, 745, 999, 1001, 825, 1001, 1000, 850, 1000, 523, 1000, 1001, 870, 1000, 1719, 1001, 1000, 1000, 1000, 903, 1001, 1001, 1000, 898, 914, 907, 1000, 938, 888, 759, 1001, 640, 1001, 756, 1000, 715]
theorem node78655 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 127 (insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 132 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78655 support demand code
    entries78655 ((insert 127 (insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 132 (insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries78656 : List (Fin 2295 × ℕ) := [(179, 336), (273, 53), (288, 223), (289, 131), (342, 234), (466, 175), (472, 180), (483, 103), (495, 84), (498, 345), (512, 60), (550, 152), (552, 107), (572, 140), (582, 260), (632, 105), (639, 130), (690, 72), (737, 24), (797, 21), (816, 64), (833, 87), (851, 358), (852, 136), (862, 87), (870, 391), (887, 31), (891, 289), (898, 127), (902, 30), (920, 282), (922, 133), (934, 147), (944, 168), (969, 165), (970, 116), (973, 217), (978, 321), (993, 177), (1007, 57), (1009, 8), (1010, 3), (1022, 119), (1034, 12), (1043, 103), (1076, 126), (1098, 93), (1100, 72), (1121, 133), (1123, 107), (1137, 78), (1154, 317), (1167, 139), (1173, 281), (1176, 83), (1177, 303), (1179, 98), (1188, 188), (1223, 47), (1237, 78), (1246, 15), (1247, 41), (1257, 178), (1261, 131), (1269, 128), (1308, 214), (1335, 40), (1344, 12), (1370, 18), (1379, 137), (1495, 193), (1517, 123), (1577, 160), (1605, 82), (1858, 145), (2157, 55), (2259, 26), (2292, 8), (2293, 31)]
def cs78656 : List ℕ := [248, 78, 206, 0, 645, 207, 283, 1000, 618, 0, 390, 1000, 1000, 0, 160, 612, 999, 1000, 0, 171, 999, 686, 463, 1000, 999, 0, 1000, 1481, 0, 480, 1000, 1000, 581, 1000, 281, 841, 2127, 999, 705, 1001, 758, 999, 999, 793, 1733, 1000, 183, 1285, 660, 1000, 822, 608, 961, 1000, 1000, 999, 1000, 1000, 999, 1001, 0, 814, 1000, 999, 1000, 999, 1237, 262, 1000, 738, 1001, 1000, 1000, 999, 836, 999, 1491, 999, 281, 1001, 595, 1001, 617, 1000, 999, 999, 999, 1000, 1000, 1000, 999, 678, 1001, 1000, 710, 999, 921, 999, 1001, 984, 1000, 1000, 929, 636, 999, 999, 1001, 999, 999, 98, 1000, 999, 1001, 999, 618, 999, 1000, 1000, 1000, 606, 1001, 1000, 998, 541, 1001, 723, 999, 422, 986, 704, 912, 942, 315, 999, 702, 999, 987, 532, 999, 999, 1000, 679, 999, 386, 767, 618, 999, 653, 999, 662, 768, 520, 978, 217]
theorem node78656 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 132 (insert 127 (insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78656 support demand code
    entries78656 ((insert 132 (insert 127 (insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node78654 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 127 (insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 127 (insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    132 node78655 node78656
theorem node78652 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    127 node78653 node78654
theorem node78650 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    18 node78651 node78652
theorem node78648 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    46 node78649 node78650
theorem node78589 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 47 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    60 node78647 node78648
def entries78645 : List (Fin 2295 × ℕ) := [(24, 75), (152, 133), (159, 106), (177, 158), (179, 281), (341, 8), (471, 136), (483, 305), (490, 62), (491, 125), (514, 170), (552, 292), (581, 265), (585, 144), (621, 55), (622, 301), (624, 64), (625, 43), (632, 102), (639, 103), (674, 233), (675, 76), (677, 21), (741, 203), (815, 96), (817, 38), (849, 219), (852, 356), (858, 61), (870, 231), (873, 148), (874, 292), (890, 156), (892, 150), (901, 73), (902, 225), (907, 215), (908, 202), (924, 87), (925, 93), (944, 405), (945, 43), (946, 341), (949, 4), (951, 205), (952, 105), (959, 222), (970, 25), (973, 430), (978, 396), (1006, 13), (1009, 174), (1012, 171), (1043, 172), (1049, 297), (1076, 23), (1122, 22), (1126, 108), (1128, 58), (1143, 97), (1154, 307), (1177, 210), (1186, 120), (1212, 143), (1219, 93), (1254, 164), (1308, 53), (1322, 5), (1375, 18), (1469, 176), (1537, 112), (1585, 110), (1607, 97), (1632, 52), (1633, 28), (1641, 119), (1654, 44), (1667, 25), (1688, 37), (1701, 98), (1705, 72), (1845, 189), (1864, 324), (1950, 63), (2132, 46), (2225, 138), (2236, 157)]
def cs78645 : List ℕ := [0, 257, 248, 312, 595, 417, 572, 999, 383, 0, 170, 999, 1000, 552, 324, 292, 980, 1000, 1000, 133, 999, 999, 439, 991, 845, 0, 1000, 2648, 1001, 999, 999, 999, 566, 1000, 312, 1000, 2440, 999, 439, 999, 1001, 999, 1000, 685, 2248, 1000, 3226, 0, 999, 1000, 1000, 1000, 999, 1000, 1000, 1000, 1000, 999, 1000, 999, 999, 1001, 1000, 644, 1000, 1001, 1677, 61, 1000, 2993, 1792, 1000, 796, 999, 822, 1000, 1956, 1000, 84, 1000, 1000, 2653, 999, 999, 1000, 1000, 1000, 1000, 999, 1000, 999, 997, 1000, 999, 605, 1000, 725, 1000, 1000, 999, 999, 1000, 868, 999, 1000, 1000, 1000, 999, 999, 263, 1000, 999, 623, 1000, 909, 999, 1000, 1000, 1000, 640, 999, 903, 999, 999, 1000, 617, 999, 1000, 991, 999, 937, 640, 1000, 1000, 1000, 937, 812, 837, 1000, 1000, 949, 727, 832, 999, 969, 712, 857, 801, 857, 794, 1000, 1000, 1000, 693]
theorem node78645 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78645 support demand code
    entries78645 ((insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 69 (insert 81 (insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries78646 : List (Fin 2295 × ℕ) := [(159, 462), (177, 894), (179, 5303), (342, 1035), (483, 33), (490, 4803), (491, 1861), (496, 25), (514, 2717), (550, 2716), (552, 1912), (583, 3227), (584, 1161), (623, 481), (625, 4265), (639, 2954), (675, 1006), (741, 1879), (780, 852), (784, 841), (833, 374), (849, 1466), (851, 189), (852, 1889), (857, 229), (860, 23), (870, 2946), (873, 1857), (890, 725), (891, 2252), (895, 102), (901, 1676), (902, 1995), (907, 387), (908, 4248), (922, 67), (944, 2476), (947, 974), (951, 2967), (952, 381), (959, 3176), (969, 168), (970, 566), (972, 1522), (973, 5055), (978, 3204), (1006, 71), (1009, 1200), (1012, 140), (1033, 292), (1047, 2748), (1073, 708), (1075, 84), (1076, 108), (1113, 603), (1139, 29), (1154, 1840), (1155, 373), (1167, 1114), (1175, 539), (1176, 907), (1177, 2384), (1186, 1110), (1212, 912), (1254, 248), (1260, 1230), (1261, 37), (1269, 534), (1284, 290), (1286, 218), (1293, 879), (1297, 177), (1304, 142), (1447, 413), (1449, 485), (1488, 399), (1528, 663), (1537, 5197), (1585, 181), (1654, 389), (1667, 1840), (1705, 52), (1845, 635), (1848, 1736), (1887, 550), (1950, 2476), (2225, 364)]
def cs78646 : List ℕ := [0, 248, 5197, 1608, 2326, 5230, 7035, 9999, 8358, 0, 2717, 10000, 9999, 7054, 0, 4628, 8195, 9101, 8662, 0, 10000, 8318, 6197, 9141, 10000, 0, 10000, 29361, 9381, 6197, 10000, 10000, 7519, 9999, 2005, 9999, 26673, 9752, 6197, 9999, 10001, 10000, 10001, 10000, 15179, 9999, 19603, 0, 6197, 10000, 9999, 10000, 10001, 9999, 9999, 9999, 10000, 10000, 10000, 9999, 10000, 6373, 10000, 8527, 5121, 9999, 16572, 1216, 9013, 387, 21925, 10001, 5976, 10001, 8364, 10000, 17008, 9999, 1192, 10001, 10000, 12786, 10000, 10000, 8368, 10000, 10000, 9999, 10000, 10001, 10002, 9225, 10001, 10000, 7262, 10000, 9147, 9999, 10001, 10002, 10001, 10573, 10001, 10001, 9999, 9999, 10000, 9203, 10001, 3544, 10000, 10001, 9845, 8829, 10000, 10000, 10001, 10002, 10000, 10433, 5726, 9885, 10001, 10001, 10001, 7440, 9999, 10001, 7322, 10001, 7557, 9999, 9999, 10002, 10002, 10004, 9548, 10000, 10001, 10001, 10000, 9528, 10000, 10001, 10002, 9578, 9383, 8191, 10000, 10001, 10002, 10000, 10001, 7627]
theorem node78646 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78646 support demand code
    entries78646 ((insert 69 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
theorem node78641 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 81 (insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    69 node78645 node78646
def entries78643 : List (Fin 2295 × ℕ) := [(50, 36), (177, 132), (179, 255), (342, 29), (469, 12), (483, 125), (490, 406), (494, 209), (514, 314), (550, 316), (552, 90), (583, 124), (585, 363), (621, 2), (623, 203), (624, 132), (625, 117), (639, 311), (677, 77), (739, 33), (781, 125), (785, 116), (849, 204), (851, 168), (852, 111), (860, 52), (870, 283), (872, 155), (873, 171), (891, 315), (896, 148), (901, 95), (902, 235), (908, 548), (921, 44), (923, 60), (925, 47), (944, 404), (946, 108), (950, 62), (952, 312), (959, 32), (960, 1), (969, 32), (970, 37), (971, 129), (972, 74), (973, 460), (978, 302), (1009, 61), (1012, 20), (1033, 50), (1047, 173), (1061, 71), (1099, 27), (1100, 143), (1110, 97), (1111, 36), (1122, 155), (1123, 37), (1126, 101), (1149, 78), (1153, 63), (1154, 129), (1167, 178), (1175, 44), (1176, 58), (1177, 260), (1179, 65), (1186, 85), (1212, 81), (1247, 59), (1254, 77), (1266, 159), (1284, 6), (1286, 36), (1293, 150), (1304, 33), (1537, 423), (1641, 24), (1654, 50), (1667, 67), (1703, 70), (1705, 119), (1845, 1), (1848, 123), (1864, 171), (2022, 13), (2225, 61)]
def cs78643 : List ℕ := [0, 89, 423, 237, 356, 548, 610, 1000, 638, 0, 314, 982, 1000, 749, 171, 406, 939, 1000, 998, 0, 1001, 1000, 457, 1001, 999, 0, 1000, 2971, 1000, 628, 1001, 999, 1000, 1002, 248, 1000, 2574, 1001, 457, 999, 1000, 1000, 837, 1000, 1814, 1000, 2254, 0, 565, 1001, 1000, 1000, 1001, 1000, 1000, 1285, 1000, 1000, 1000, 1001, 1000, 565, 1001, 573, 591, 993, 1683, 326, 1000, 1001, 1972, 999, 658, 1002, 705, 1000, 1615, 981, 98, 1001, 1000, 46, 1000, 1001, 770, 1000, 957, 999, 1001, 1000, 1000, 903, 1628, 1001, 879, 778, 941, 999, 1001, 1000, 1000, 1001, 1001, 723, 999, 1000, 1002, 1000, 999, 434, 1001, 1000, 1001, 1000, 1002, 999, 1001, 1000, 1000, 828, 691, 1002, 999, 1000, 1000, 777, 1000, 1002, 1002, 1000, 963, 1000, 1002, 1001, 1001, 979, 900, 938, 1001, 999, 1000, 847, 1000, 1000, 1001, 954, 982, 1000, 1000, 888, 1002, 930, 883, 639]
theorem node78643 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78643 support demand code
    entries78643 ((insert 81 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries78644 : List (Fin 2295 × ℕ) := [(99, 2), (179, 3), (341, 7), (490, 25), (491, 3), (507, 14), (514, 37), (542, 1), (552, 19), (583, 5), (624, 15), (625, 34), (639, 31), (674, 6), (675, 26), (833, 8), (849, 20), (851, 7), (852, 31), (858, 2), (860, 17), (870, 14), (872, 11), (873, 12), (890, 2), (891, 22), (896, 19), (901, 28), (908, 10), (920, 19), (924, 36), (925, 14), (944, 34), (945, 5), (946, 25), (951, 2), (952, 2), (969, 5), (970, 6), (972, 5), (973, 44), (978, 47), (1009, 3), (1033, 8), (1039, 9), (1041, 7), (1043, 10), (1047, 18), (1049, 5), (1061, 1), (1076, 2), (1098, 3), (1111, 6), (1113, 1), (1122, 2), (1126, 8), (1154, 2), (1155, 17), (1167, 6), (1172, 5), (1173, 3), (1175, 16), (1176, 15), (1177, 9), (1179, 23), (1186, 12), (1212, 19), (1254, 11), (1322, 6), (1506, 2), (1517, 4), (1537, 42), (1585, 2), (1607, 22), (1627, 10), (1663, 1), (1667, 7), (1705, 6), (1848, 8), (1849, 2), (1864, 8), (2021, 8)]
def cs78644 : List ℕ := [10, 11, 52, 20, 59, 52, 42, 101, 80, 14, 37, 75, 100, 67, 19, 19, 100, 93, 101, 0, 101, 80, 3, 100, 85, 0, 98, 240, 59, 33, 100, 100, 101, 100, 44, 101, 202, 101, 3, 101, 101, 101, 100, 87, 208, 100, 206, 0, 33, 100, 101, 68, 86, 100, 100, 100, 94, 101, 99, 100, 84, 14, 101, 89, 84, 100, 105, 31, 101, 100, 133, 100, 95, 101, 92, 79, 139, 101, 8, 100, 100, 2, 100, 100, 16, 101, 99, 100, 100, 101, 99, 100, 12, 101, 97, 93, 72, 101, 99, 100, 100, 100, 101, 39, 91, 100, 100, 100, 101, 59, 100, 101, 43, 101, 86, 100, 101, 100, 99, 84, 59, 83, 100, 100, 100, 62, 100, 100, 99, 101, 100, 95, 100, 101, 100, 101, 97, 97, 100, 101, 100, 100, 100, 99, 100, 98, 101, 100, 100, 100, 100, 100, 100, 100]
theorem node78644 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 81 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78644 support demand code
    entries78644 ((insert 92 (insert 81 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78642 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    92 node78643 node78644
theorem node78621 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 46 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    81 node78641 node78642
def entries78639 : List (Fin 2295 × ℕ) := [(86, 4), (100, 9), (146, 15), (177, 19), (491, 13), (514, 21), (550, 23), (552, 20), (580, 4), (632, 60), (639, 13), (739, 28), (741, 5), (780, 2), (815, 23), (851, 21), (870, 4), (872, 6), (874, 12), (888, 39), (891, 35), (902, 5), (908, 14), (920, 12), (922, 4), (923, 8), (924, 27), (925, 26), (926, 3), (944, 46), (951, 32), (952, 15), (958, 2), (959, 4), (960, 50), (973, 47), (978, 13), (991, 8), (1009, 13), (1016, 6), (1043, 19), (1047, 13), (1049, 21), (1073, 6), (1098, 1), (1100, 17), (1128, 14), (1153, 14), (1155, 49), (1167, 41), (1188, 5), (1212, 2), (1219, 5), (1254, 25), (1266, 28), (1275, 2), (1281, 29), (1285, 13), (1335, 1), (1403, 14), (1459, 2), (1500, 13), (1515, 9), (1537, 13), (1556, 19), (1585, 11), (1689, 21), (1705, 14), (1848, 2), (1859, 5), (1901, 7), (2236, 6), (2242, 1)]
def cs78639 : List ℕ := [35, 30, 43, 47, 46, 19, 18, 99, 58, 0, 21, 98, 98, 60, 0, 43, 99, 83, 99, 39, 99, 39, 19, 99, 99, 0, 99, 188, 14, 79, 98, 90, 100, 100, 5, 99, 156, 99, 19, 98, 14, 99, 100, 94, 201, 83, 14, 0, 37, 99, 100, 100, 100, 94, 99, 101, 100, 99, 100, 73, 223, 99, 100, 0, 93, 88, 168, 43, 100, 99, 239, 265, 100, 57, 73, 100, 187, 101, 0, 100, 71, 230, 100, 100, 78, 101, 100, 99, 99, 100, 99, 68, 282, 101, 84, 81, 87, 100, 99, 99, 100, 114, 100, 100, 99, 100, 99, 99, 100, 5, 101, 101, 90, 88, 99, 100, 101, 99, 100, 53, 99, 99, 100, 101, 99, 101, 101, 101, 98, 99, 99, 88, 100, 99, 82, 99, 66, 101, 99, 99, 74, 76, 94, 100, 96, 67, 81, 90, 50, 64, 81, 72, 64, 100]
theorem node78639 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 81 (insert 71 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78639 support demand code
    entries78639 ((insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 81 (insert 71 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries78640 : List (Fin 2295 × ℕ) := [(44, 1), (100, 61), (146, 6), (342, 8), (471, 10), (491, 74), (514, 63), (529, 3), (531, 13), (550, 60), (580, 2), (630, 29), (632, 76), (639, 76), (731, 46), (741, 26), (780, 3), (782, 12), (784, 3), (817, 15), (833, 17), (850, 8), (851, 63), (870, 25), (872, 18), (887, 31), (891, 147), (902, 37), (919, 31), (920, 52), (923, 57), (924, 96), (925, 39), (944, 94), (947, 23), (949, 57), (951, 50), (960, 58), (969, 16), (970, 18), (973, 109), (978, 99), (1009, 15), (1012, 6), (1033, 1), (1043, 31), (1047, 14), (1049, 72), (1099, 8), (1100, 34), (1120, 8), (1123, 20), (1128, 4), (1139, 31), (1143, 14), (1153, 35), (1155, 68), (1167, 47), (1173, 34), (1175, 54), (1177, 27), (1179, 21), (1186, 32), (1212, 19), (1254, 74), (1269, 27), (1281, 17), (1285, 56), (1447, 64), (1534, 3), (1537, 66), (1654, 4), (1667, 15), (1705, 12), (1845, 13), (1846, 8), (1946, 4), (2029, 5), (2241, 12), (2242, 21), (2259, 2)]
def cs78640 : List ℕ := [45, 74, 116, 85, 139, 89, 75, 258, 204, 0, 63, 257, 257, 221, 0, 60, 258, 214, 256, 31, 257, 153, 0, 257, 232, 0, 257, 500, 0, 105, 257, 257, 256, 257, 88, 256, 435, 255, 0, 257, 89, 256, 239, 256, 604, 255, 4, 0, 46, 257, 256, 255, 257, 255, 256, 276, 256, 256, 255, 169, 435, 182, 256, 20, 256, 241, 355, 47, 257, 256, 554, 462, 216, 117, 185, 256, 402, 255, 114, 256, 46, 404, 256, 256, 142, 256, 255, 256, 256, 255, 255, 242, 61, 256, 217, 255, 235, 255, 255, 256, 255, 270, 93, 256, 239, 256, 255, 255, 256, 72, 255, 256, 61, 229, 255, 255, 255, 255, 256, 190, 169, 256, 230, 256, 255, 205, 255, 255, 255, 255, 166, 237, 255, 255, 254, 255, 255, 212, 256, 255, 255, 256, 214, 255, 254, 231, 256, 207, 256, 213, 255, 255, 243, 228]
theorem node78640 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 71 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78640 support demand code
    entries78640 ((insert 92 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 71 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78637 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 71 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 71 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154))
    92 node78639 node78640
def entries78638 : List (Fin 2295 × ℕ) := [(342, 31), (484, 31), (491, 114), (498, 14), (514, 43), (529, 27), (550, 25), (632, 60), (639, 84), (730, 13), (731, 48), (781, 29), (783, 12), (816, 1), (851, 83), (858, 6), (859, 4), (870, 25), (872, 42), (888, 47), (891, 103), (902, 45), (919, 39), (920, 38), (923, 57), (924, 94), (925, 46), (944, 68), (946, 67), (952, 72), (969, 24), (971, 18), (972, 8), (973, 90), (977, 8), (978, 90), (1009, 12), (1012, 10), (1042, 25), (1047, 25), (1049, 53), (1073, 10), (1075, 12), (1098, 27), (1100, 13), (1111, 6), (1113, 7), (1126, 35), (1143, 13), (1149, 13), (1153, 22), (1155, 70), (1167, 63), (1173, 13), (1175, 67), (1177, 10), (1179, 38), (1186, 18), (1212, 19), (1219, 10), (1235, 22), (1254, 43), (1258, 3), (1266, 58), (1269, 40), (1281, 20), (1285, 34), (1449, 8), (1528, 17), (1537, 80), (1705, 33), (1710, 30), (1845, 14), (1859, 2), (2020, 5), (2021, 11), (2029, 8), (2072, 13), (2240, 16), (2247, 10)]
def cs78638 : List ℕ := [40, 53, 110, 64, 126, 123, 122, 256, 175, 0, 43, 256, 256, 183, 0, 25, 255, 212, 256, 47, 256, 103, 0, 256, 169, 0, 257, 447, 0, 60, 255, 256, 255, 256, 90, 244, 338, 256, 0, 256, 80, 256, 256, 255, 517, 255, 0, 0, 128, 257, 255, 257, 256, 255, 257, 256, 256, 257, 256, 167, 453, 86, 256, 60, 252, 211, 330, 69, 255, 188, 573, 325, 203, 146, 197, 256, 342, 255, 43, 255, 175, 0, 255, 255, 207, 256, 255, 256, 255, 255, 257, 238, 256, 114, 255, 255, 255, 255, 255, 256, 256, 255, 255, 154, 255, 251, 256, 256, 255, 101, 255, 256, 255, 255, 228, 256, 255, 256, 255, 177, 208, 256, 256, 256, 256, 191, 255, 255, 255, 256, 257, 255, 255, 255, 255, 252, 210, 255, 255, 256, 256, 240, 255, 256, 241, 248, 255, 231, 253, 153, 255, 217, 230, 213]
theorem node78638 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78638 support demand code
    entries78638 ((insert 81 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 71 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78631 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 71 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    81 node78637 node78638
def entries78635 : List (Fin 2295 × ℕ) := [(146, 28), (177, 168), (179, 5633), (472, 2225), (490, 1705), (491, 800), (498, 1545), (514, 2264), (552, 2737), (584, 3711), (586, 223), (632, 3224), (639, 2040), (664, 727), (731, 766), (741, 1901), (780, 1861), (781, 1622), (797, 326), (846, 925), (851, 1339), (857, 1386), (859, 1545), (870, 2411), (872, 2164), (874, 3224), (902, 1705), (908, 711), (920, 3382), (925, 609), (944, 4198), (945, 103), (946, 2682), (948, 965), (951, 1821), (952, 1816), (969, 428), (970, 1266), (971, 376), (973, 4509), (978, 3183), (1009, 282), (1012, 661), (1039, 329), (1043, 711), (1047, 466), (1048, 50), (1049, 3934), (1076, 282), (1096, 389), (1126, 2056), (1143, 186), (1149, 329), (1152, 976), (1155, 3136), (1167, 2026), (1173, 102), (1175, 3079), (1177, 385), (1179, 430), (1212, 447), (1248, 215), (1254, 3224), (1266, 888), (1269, 1579), (1285, 1240), (1293, 491), (1447, 979), (1449, 3223), (1537, 1667), (1616, 148), (1705, 740), (1710, 775), (1845, 2294), (1859, 620), (1901, 161)]
def cs78635 : List ℕ := [620, 4149, 3892, 1240, 4563, 2287, 4511, 10000, 9382, 0, 2264, 10000, 10002, 8456, 0, 2737, 10000, 9959, 10001, 0, 9999, 3934, 5801, 10001, 7869, 0, 10000, 17439, 711, 9025, 10000, 10000, 3661, 10000, 4106, 10001, 17382, 9999, 5801, 10001, 3892, 10001, 9999, 7277, 21676, 9999, 711, 0, 9352, 10000, 9359, 9829, 9999, 10001, 10000, 9999, 9999, 10001, 9999, 7342, 15724, 766, 9999, 329, 10000, 10000, 14003, 2026, 9999, 9999, 29970, 609, 7121, 9999, 6200, 15039, 10614, 10001, 1842, 9999, 4262, 10001, 9864, 17586, 9999, 10000, 4944, 10001, 9999, 10000, 10000, 9932, 10000, 10001, 5065, 9999, 7241, 10000, 9999, 10001, 9999, 10000, 10000, 9487, 9791, 10000, 10000, 10000, 9999, 1253, 10000, 10001, 8054, 9989, 10000, 10000, 10000, 9999, 10001, 8023, 5729, 10000, 9999, 10000, 9999, 7248, 9999, 10000, 9999, 10000, 8095, 9999, 9999, 10000, 7123, 7786, 9165, 9725, 9999, 10000, 9999, 9304, 9172, 9901, 7686, 9532, 10000, 9038, 9999, 5387, 9999, 9582, 6965, 8240]
theorem node78635 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 83 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78635 support demand code
    entries78635 ((insert 71 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 75 (insert 83 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 10000 31 code_correct
  decide +kernel
def entries78636 : List (Fin 2295 × ℕ) := [(43, 8), (86, 54), (177, 61), (179, 73), (472, 52), (490, 29), (512, 15), (514, 39), (552, 96), (584, 38), (632, 94), (639, 48), (640, 9), (731, 30), (736, 17), (739, 27), (741, 67), (817, 67), (833, 61), (851, 54), (857, 44), (859, 29), (870, 44), (872, 51), (874, 27), (888, 80), (919, 10), (920, 21), (923, 1), (944, 121), (945, 39), (946, 53), (947, 7), (948, 4), (949, 12), (950, 70), (951, 67), (952, 60), (954, 1), (970, 18), (973, 138), (978, 62), (994, 32), (1006, 10), (1009, 29), (1016, 14), (1047, 7), (1072, 45), (1073, 42), (1123, 5), (1149, 2), (1152, 9), (1153, 12), (1155, 60), (1167, 45), (1174, 2), (1175, 71), (1179, 4), (1212, 38), (1247, 18), (1254, 20), (1281, 87), (1293, 4), (1375, 16), (1403, 33), (1483, 13), (1528, 11), (1537, 21), (1545, 19), (1585, 25), (1654, 29), (1660, 1), (1667, 14), (1845, 60), (1848, 11), (1849, 9), (1859, 22), (1901, 47)]
def cs78636 : List ℕ := [109, 20, 160, 87, 74, 43, 103, 256, 146, 0, 54, 256, 255, 146, 8, 96, 256, 257, 255, 80, 256, 75, 134, 204, 256, 0, 256, 467, 0, 249, 255, 256, 67, 256, 73, 255, 310, 256, 134, 255, 73, 256, 256, 231, 460, 191, 29, 0, 256, 255, 256, 256, 257, 256, 256, 255, 256, 255, 256, 176, 271, 30, 256, 0, 231, 256, 439, 64, 257, 256, 587, 1, 255, 256, 229, 11, 363, 256, 93, 256, 202, 231, 235, 372, 210, 255, 175, 255, 256, 256, 256, 200, 256, 254, 158, 255, 256, 204, 256, 256, 256, 306, 255, 256, 255, 256, 174, 257, 251, 43, 256, 256, 209, 168, 221, 257, 255, 256, 255, 298, 180, 256, 257, 256, 256, 256, 256, 255, 255, 257, 216, 256, 255, 257, 255, 212, 224, 255, 256, 256, 219, 236, 257, 245, 194, 255, 256, 239, 256, 228, 256, 256, 192, 236]
theorem node78636 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 75 (insert 71 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78636 support demand code
    entries78636 ((insert 75 (insert 71 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 83 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78633 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 83 (insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    75 node78635 node78636
def entries78634 : List (Fin 2295 × ℕ) := [(43, 88), (177, 70), (179, 194), (342, 467), (490, 29), (491, 143), (514, 180), (630, 116), (731, 152), (740, 53), (741, 314), (777, 81), (779, 170), (780, 24), (781, 105), (783, 106), (851, 305), (857, 19), (858, 120), (859, 40), (870, 252), (872, 206), (874, 66), (888, 182), (891, 182), (901, 27), (902, 152), (920, 116), (922, 80), (924, 35), (944, 116), (945, 369), (946, 215), (951, 271), (952, 212), (972, 17), (973, 448), (977, 30), (978, 252), (1006, 39), (1009, 199), (1043, 77), (1047, 52), (1049, 66), (1061, 68), (1073, 130), (1076, 55), (1098, 43), (1100, 29), (1128, 115), (1149, 47), (1155, 339), (1167, 206), (1174, 75), (1175, 268), (1176, 3), (1179, 152), (1186, 43), (1254, 130), (1258, 48), (1263, 40), (1266, 177), (1269, 55), (1273, 18), (1275, 140), (1276, 11), (1285, 148), (1354, 45), (1370, 90), (1375, 6), (1379, 95), (1447, 144), (1528, 47), (1537, 280), (1585, 124), (1689, 48), (1705, 2), (1845, 68), (1846, 58), (1859, 222), (1946, 77), (1991, 26), (2072, 16), (2240, 136), (2242, 63)]
def cs78634 : List ℕ := [285, 130, 343, 225, 435, 565, 621, 1000, 715, 0, 275, 1001, 1000, 777, 88, 0, 1000, 1000, 999, 182, 1001, 405, 264, 999, 491, 0, 1000, 1458, 0, 468, 1000, 883, 363, 1000, 343, 999, 1095, 1001, 264, 1000, 383, 1000, 1001, 684, 2074, 561, 40, 95, 1000, 999, 1001, 999, 1001, 1000, 1000, 999, 1002, 867, 999, 512, 1473, 152, 906, 714, 942, 999, 1269, 326, 1001, 999, 2767, 217, 1000, 805, 911, 999, 1642, 1000, 0, 1000, 999, 1000, 1000, 116, 1000, 1000, 938, 1000, 1000, 1000, 999, 853, 1000, 999, 499, 999, 744, 999, 1000, 1000, 1000, 1105, 1000, 830, 1000, 1001, 1000, 1000, 672, 230, 1000, 1000, 999, 1000, 1000, 1000, 999, 1000, 1001, 924, 796, 1000, 1000, 999, 999, 939, 1000, 1000, 1000, 999, 999, 1000, 1000, 1000, 868, 1000, 965, 1000, 1001, 1000, 999, 1000, 949, 1000, 999, 1000, 807, 697, 930, 737, 1001, 947, 757, 999]
theorem node78634 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 83 (insert 71 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78634 support demand code
    entries78634 ((insert 83 (insert 71 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node78632 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    83 node78633 node78634
theorem node78623 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 60 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    71 node78631 node78632
def entries78625 : List (Fin 2295 × ℕ) := [(146, 2), (177, 13), (269, 4), (341, 2), (491, 33), (512, 1), (514, 26), (550, 9), (632, 30), (639, 23), (739, 9), (741, 21), (742, 2), (816, 12), (851, 27), (870, 12), (872, 10), (874, 13), (888, 17), (891, 27), (895, 29), (902, 25), (908, 10), (920, 21), (944, 27), (945, 36), (959, 1), (960, 39), (965, 2), (969, 16), (970, 16), (973, 47), (978, 39), (1007, 8), (1012, 4), (1033, 2), (1043, 1), (1047, 19), (1061, 8), (1076, 6), (1097, 2), (1098, 10), (1102, 2), (1110, 1), (1126, 3), (1143, 6), (1153, 6), (1155, 17), (1159, 2), (1167, 6), (1170, 3), (1173, 13), (1174, 15), (1175, 11), (1177, 12), (1179, 15), (1186, 7), (1212, 17), (1233, 3), (1247, 2), (1254, 4), (1281, 17), (1285, 10), (1293, 11), (1295, 10), (1298, 3), (1370, 8), (1502, 5), (1534, 9), (1537, 33), (1685, 44), (1699, 7), (1751, 3), (1844, 7), (1847, 8), (1848, 3), (1901, 6), (1946, 10), (2073, 3), (2225, 2), (2240, 1), (2242, 8), (2259, 11)]
def cs78625 : List ℕ := [36, 4, 69, 37, 42, 52, 33, 100, 63, 7, 27, 97, 99, 89, 0, 53, 100, 78, 99, 24, 100, 100, 64, 100, 95, 3, 100, 191, 54, 94, 100, 99, 24, 100, 90, 99, 158, 100, 64, 99, 59, 99, 88, 92, 200, 99, 10, 0, 100, 100, 46, 98, 100, 100, 100, 99, 99, 99, 101, 86, 7, 84, 100, 6, 99, 101, 166, 35, 86, 79, 168, 100, 61, 100, 49, 79, 227, 101, 18, 101, 63, 100, 101, 101, 44, 99, 89, 98, 279, 93, 101, 100, 100, 89, 65, 99, 71, 100, 100, 100, 101, 100, 85, 101, 99, 98, 76, 101, 100, 39, 100, 100, 101, 82, 99, 100, 100, 102, 98, 97, 100, 99, 100, 101, 100, 69, 99, 101, 99, 99, 95, 99, 98, 101, 100, 102, 99, 100, 99, 101, 101, 99, 99, 101, 100, 95, 100, 88, 100, 101, 100, 100, 97, 91]
theorem node78625 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78625 support demand code
    entries78625 ((insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 88 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries78629 : List (Fin 2295 × ℕ) := [(100, 31), (179, 124), (273, 50), (352, 1), (429, 19), (484, 4), (490, 91), (491, 35), (498, 4), (512, 54), (529, 13), (531, 23), (550, 13), (552, 17), (580, 3), (630, 66), (639, 73), (730, 6), (731, 95), (737, 11), (739, 29), (740, 6), (756, 3), (813, 11), (817, 30), (833, 13), (851, 58), (870, 48), (874, 13), (891, 101), (902, 60), (908, 72), (934, 29), (944, 109), (965, 13), (972, 9), (973, 125), (978, 67), (1009, 1), (1010, 6), (1012, 2), (1033, 3), (1043, 7), (1047, 37), (1049, 1), (1073, 7), (1076, 7), (1098, 7), (1100, 16), (1111, 25), (1121, 12), (1123, 44), (1155, 65), (1167, 57), (1172, 1), (1173, 65), (1175, 14), (1177, 45), (1178, 14), (1179, 22), (1186, 19), (1188, 4), (1212, 21), (1235, 15), (1254, 16), (1261, 2), (1285, 45), (1308, 18), (1344, 14), (1370, 17), (1403, 44), (1500, 15), (1502, 8), (1503, 3), (1537, 122), (1560, 15), (1645, 12), (1667, 7), (1674, 20), (1701, 41), (1705, 28), (1791, 17), (1849, 20), (1946, 5), (2242, 51), (2259, 9)]
def cs78629 : List ℕ := [60, 16, 182, 50, 83, 186, 146, 256, 192, 0, 54, 249, 256, 252, 20, 30, 256, 252, 256, 0, 256, 124, 124, 256, 257, 0, 256, 481, 84, 210, 257, 256, 217, 256, 80, 256, 474, 255, 124, 256, 223, 489, 181, 257, 410, 257, 84, 0, 247, 378, 252, 249, 130, 212, 255, 257, 256, 255, 257, 255, 0, 256, 256, 32, 254, 257, 265, 77, 256, 256, 375, 255, 208, 256, 152, 195, 373, 257, 79, 256, 207, 255, 256, 256, 256, 256, 256, 255, 81, 256, 255, 197, 253, 256, 179, 256, 247, 255, 255, 255, 255, 256, 236, 107, 255, 256, 255, 256, 255, 100, 256, 255, 174, 230, 255, 255, 256, 255, 256, 197, 255, 254, 256, 255, 255, 249, 256, 255, 253, 255, 252, 256, 255, 255, 255, 255, 256, 256, 254, 255, 254, 255, 238, 204, 255, 255, 255, 248, 254, 237, 255, 255, 202, 230]
theorem node78629 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 49 (insert 41 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78629 support demand code
    entries78629 ((insert 88 (insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 49 (insert 41 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78630 : List (Fin 2295 × ℕ) := [(43, 45), (86, 61), (179, 457), (273, 250), (284, 8), (344, 146), (349, 102), (429, 110), (469, 123), (512, 369), (550, 112), (552, 122), (572, 163), (630, 311), (632, 176), (639, 237), (731, 90), (756, 95), (813, 123), (817, 185), (833, 104), (846, 138), (851, 82), (887, 165), (888, 272), (891, 417), (902, 132), (920, 49), (922, 128), (944, 396), (965, 35), (972, 50), (973, 473), (978, 226), (1004, 37), (1005, 8), (1007, 10), (1047, 139), (1049, 90), (1061, 65), (1073, 81), (1075, 3), (1076, 7), (1111, 45), (1123, 150), (1155, 224), (1167, 291), (1173, 233), (1177, 217), (1179, 30), (1186, 38), (1212, 144), (1246, 92), (1247, 10), (1251, 1), (1254, 248), (1261, 23), (1285, 185), (1293, 48), (1296, 184), (1308, 54), (1403, 236), (1488, 14), (1500, 119), (1503, 16), (1528, 77), (1667, 59), (1705, 83), (1751, 14), (1791, 126), (1846, 51), (1849, 84), (1859, 145), (2029, 7), (2131, 32), (2244, 194), (2259, 38), (2283, 2)]
def cs78630 : List ℕ := [190, 703, 38, 379, 368, 367, 190, 975, 617, 32, 369, 1001, 1001, 401, 45, 234, 991, 1000, 1001, 632, 1001, 462, 457, 1000, 990, 0, 1000, 1989, 0, 989, 1001, 1001, 908, 1000, 371, 1001, 1019, 1001, 549, 1001, 233, 1803, 709, 1001, 1698, 999, 0, 92, 806, 368, 750, 1001, 595, 1000, 1000, 1000, 999, 980, 1000, 546, 0, 1000, 825, 237, 760, 1000, 1241, 293, 999, 1001, 1150, 999, 933, 1000, 601, 829, 1475, 1000, 268, 1000, 784, 999, 1000, 999, 1000, 1000, 999, 1001, 384, 1000, 1001, 809, 1000, 1000, 769, 1000, 997, 963, 1000, 913, 999, 1000, 912, 721, 1000, 1000, 1000, 1001, 891, 262, 1000, 1000, 770, 759, 1001, 1000, 1000, 999, 1001, 772, 846, 1001, 1000, 1001, 999, 997, 1000, 1000, 1000, 1001, 880, 981, 1001, 1000, 999, 1000, 1000, 1001, 1000, 1000, 999, 1001, 1000, 929, 900, 884, 985, 1001, 1000, 957, 1000, 999, 700, 879]
theorem node78630 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 49 (insert 88 (insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78630 support demand code
    entries78630 ((insert 49 (insert 88 (insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 41 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node78627 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 41 (insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    49 node78629 node78630
def entries78628 : List (Fin 2295 × ℕ) := [(21, 6), (179, 61), (342, 8), (429, 18), (472, 45), (474, 4), (491, 45), (514, 14), (550, 10), (552, 2), (584, 31), (639, 24), (676, 22), (677, 4), (731, 25), (739, 5), (851, 14), (859, 9), (862, 19), (870, 10), (874, 30), (888, 30), (891, 28), (902, 25), (908, 13), (920, 3), (922, 18), (925, 11), (944, 31), (960, 9), (973, 49), (978, 43), (1041, 7), (1043, 6), (1047, 19), (1061, 7), (1110, 7), (1122, 3), (1123, 8), (1126, 5), (1128, 2), (1155, 11), (1167, 7), (1171, 3), (1172, 6), (1173, 6), (1174, 1), (1175, 15), (1179, 18), (1186, 20), (1212, 13), (1254, 2), (1272, 5), (1281, 39), (1298, 12), (1308, 19), (1322, 4), (1342, 4), (1488, 6), (1528, 3), (1645, 5), (1701, 4), (1705, 12), (1809, 13), (1849, 11), (1901, 21), (1993, 4), (2007, 3), (2023, 1), (2206, 2), (2241, 2)]
def cs78628 : List ℕ := [39, 2, 84, 49, 16, 0, 45, 100, 51, 0, 14, 100, 100, 51, 0, 12, 100, 66, 100, 30, 100, 59, 61, 66, 100, 3, 100, 194, 20, 61, 100, 99, 21, 100, 28, 100, 161, 91, 65, 99, 52, 0, 100, 77, 164, 96, 20, 4, 90, 100, 27, 11, 98, 99, 99, 123, 100, 70, 100, 100, 11, 72, 100, 41, 99, 100, 135, 7, 100, 85, 92, 100, 79, 72, 51, 52, 163, 100, 15, 100, 79, 99, 100, 98, 100, 99, 84, 99, 26, 100, 101, 99, 100, 98, 51, 99, 68, 100, 100, 99, 100, 99, 99, 28, 99, 100, 99, 101, 98, 51, 99, 99, 68, 92, 99, 99, 99, 101, 99, 65, 80, 99, 100, 100, 100, 71, 99, 99, 83, 99, 97, 78, 100, 100, 100, 100, 87, 99, 100, 100, 100, 99, 99, 100, 83, 94, 99, 100, 100, 94, 100, 100, 100, 94]
theorem node78628 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 41 (insert 88 (insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78628 support demand code
    entries78628 ((insert 41 (insert 88 (insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78626 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 88 (insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    41 node78627 node78628
theorem node78624 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 60 (insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    88 node78625 node78626
theorem node78622 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    60 node78623 node78624
theorem node78591 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 70 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    46 node78621 node78622
def entries78619 : List (Fin 2295 × ℕ) := [(100, 456), (227, 42), (285, 147), (350, 29), (429, 114), (483, 67), (490, 18), (512, 50), (550, 50), (552, 24), (624, 227), (625, 131), (632, 623), (691, 138), (737, 272), (739, 54), (797, 190), (812, 69), (815, 128), (817, 140), (849, 50), (870, 50), (874, 32), (888, 369), (891, 583), (901, 18), (908, 12), (919, 128), (922, 138), (923, 210), (924, 262), (925, 335), (944, 431), (952, 47), (959, 119), (960, 218), (962, 185), (973, 424), (978, 269), (1012, 155), (1033, 21), (1043, 84), (1047, 85), (1049, 157), (1098, 96), (1123, 72), (1143, 257), (1155, 271), (1161, 25), (1167, 307), (1171, 237), (1177, 38), (1186, 107), (1188, 267), (1212, 77), (1219, 167), (1233, 71), (1254, 291), (1281, 255), (1295, 60), (1298, 44), (1335, 25), (1354, 4), (1370, 27), (1385, 26), (1488, 117), (1503, 24), (1517, 75), (1535, 103), (1627, 143), (1705, 75), (1751, 68), (1778, 13), (1791, 5), (1845, 91), (1858, 39), (2206, 68), (2217, 233), (2246, 27)]
def cs78619 : List ℕ := [398, 458, 398, 472, 537, 237, 93, 999, 434, 0, 50, 999, 1000, 528, 143, 74, 1000, 918, 1000, 472, 999, 999, 0, 977, 566, 237, 1000, 1688, 816, 856, 999, 1000, 1000, 1000, 217, 1000, 2001, 999, 0, 1001, 999, 999, 455, 1000, 2221, 1000, 999, 0, 317, 1000, 1000, 115, 999, 1000, 1012, 1000, 999, 999, 1001, 745, 1000, 1001, 746, 916, 978, 796, 1090, 382, 1000, 1970, 47, 2615, 974, 1000, 844, 699, 2626, 1000, 237, 1001, 1000, 1994, 963, 1000, 1000, 1000, 1000, 1000, 1001, 1000, 1000, 869, 2005, 1001, 867, 1000, 975, 1000, 1001, 1000, 1000, 1000, 1000, 987, 1000, 990, 1000, 1000, 1001, 369, 1000, 999, 1001, 1000, 935, 1000, 1000, 1000, 1000, 522, 1001, 1000, 999, 1000, 1000, 968, 1000, 999, 1001, 999, 1000, 769, 1000, 1000, 1000, 1001, 783, 1000, 1000, 1000, 1000, 960, 1000, 938, 831, 622, 1000, 986, 861, 870, 835, 933, 701, 950]
theorem node78619 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 81 (insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78619 support demand code
    entries78619 ((insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 69 (insert 81 (insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
def entries78620 : List (Fin 2295 × ℕ) := [(23, 23), (86, 5), (177, 47), (342, 13), (469, 31), (475, 25), (483, 36), (514, 67), (550, 35), (552, 66), (583, 96), (625, 55), (691, 21), (736, 41), (737, 68), (797, 23), (815, 3), (842, 29), (849, 40), (850, 9), (852, 54), (858, 21), (870, 26), (880, 13), (888, 190), (891, 142), (901, 84), (922, 36), (924, 66), (925, 63), (944, 88), (959, 67), (960, 112), (962, 12), (965, 41), (973, 86), (978, 84), (994, 23), (1012, 16), (1033, 13), (1042, 3), (1043, 11), (1047, 95), (1094, 28), (1099, 4), (1128, 28), (1143, 16), (1155, 72), (1167, 63), (1171, 9), (1177, 30), (1178, 12), (1186, 33), (1212, 9), (1241, 19), (1281, 61), (1308, 11), (1322, 31), (1335, 36), (1370, 6), (1488, 6), (1497, 23), (1508, 28), (1517, 9), (1536, 3), (1537, 9), (1560, 22), (1627, 18), (1628, 23), (1689, 43), (1705, 37), (1848, 32), (1859, 58), (2206, 8), (2241, 5)]
def cs78620 : List ℕ := [137, 31, 88, 135, 95, 121, 111, 257, 27, 0, 67, 256, 256, 9, 18, 114, 249, 257, 256, 193, 257, 256, 47, 235, 256, 9, 256, 712, 66, 47, 256, 256, 256, 256, 53, 256, 385, 212, 47, 256, 126, 106, 257, 228, 358, 256, 257, 0, 47, 256, 256, 60, 222, 257, 256, 256, 257, 146, 256, 223, 256, 256, 257, 236, 158, 237, 382, 93, 256, 0, 52, 582, 255, 189, 189, 162, 611, 257, 50, 256, 256, 404, 243, 256, 46, 255, 255, 255, 256, 257, 255, 218, 567, 255, 222, 226, 236, 255, 257, 255, 256, 256, 255, 132, 255, 256, 256, 255, 255, 88, 256, 254, 227, 256, 245, 256, 255, 256, 255, 116, 256, 237, 254, 257, 256, 204, 255, 255, 257, 256, 256, 205, 256, 255, 256, 255, 136, 256, 256, 255, 250, 182, 250, 256, 211, 165, 227, 191, 203, 201, 247, 229, 186, 219]
theorem node78620 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78620 support demand code
    entries78620 ((insert 69 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 81 (insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78615 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 81 (insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154))
    69 node78619 node78620
def entries78617 : List (Fin 2295 × ℕ) := [(25, 2), (177, 4), (341, 2), (429, 3), (472, 12), (474, 20), (490, 3), (494, 2), (514, 27), (530, 1), (552, 24), (572, 29), (583, 30), (620, 27), (624, 45), (632, 24), (737, 42), (739, 2), (833, 12), (849, 14), (851, 3), (852, 38), (858, 16), (870, 22), (873, 3), (888, 15), (891, 50), (896, 12), (901, 39), (908, 43), (924, 43), (925, 7), (944, 34), (952, 9), (960, 24), (969, 2), (970, 13), (973, 43), (978, 39), (1009, 13), (1012, 4), (1033, 1), (1042, 13), (1047, 27), (1097, 1), (1098, 2), (1099, 4), (1110, 1), (1113, 3), (1123, 13), (1153, 8), (1155, 13), (1167, 4), (1176, 12), (1177, 22), (1179, 8), (1186, 17), (1212, 18), (1235, 6), (1247, 4), (1281, 22), (1322, 8), (1335, 5), (1497, 5), (1506, 3), (1586, 1), (1663, 8), (1798, 1), (1848, 12), (1856, 3), (1859, 10), (1864, 14), (1899, 13), (1958, 13), (1975, 8), (2023, 9), (2072, 3), (2209, 5)]
def cs78617 : List ℕ := [32, 10, 35, 57, 43, 32, 43, 99, 14, 2, 28, 101, 101, 25, 15, 45, 93, 95, 93, 57, 101, 99, 4, 94, 101, 0, 99, 297, 101, 42, 101, 101, 100, 99, 14, 99, 213, 100, 4, 101, 100, 75, 87, 58, 152, 100, 231, 1, 4, 99, 100, 52, 100, 99, 99, 99, 100, 100, 100, 99, 99, 101, 101, 100, 67, 99, 136, 32, 100, 100, 9, 162, 92, 93, 98, 81, 189, 100, 0, 100, 100, 36, 93, 100, 41, 99, 99, 100, 101, 100, 99, 87, 189, 101, 100, 99, 87, 100, 100, 100, 100, 99, 100, 62, 100, 99, 99, 89, 100, 43, 99, 99, 34, 100, 87, 99, 99, 100, 99, 77, 70, 69, 100, 99, 100, 73, 99, 99, 91, 99, 83, 99, 98, 99, 91, 100, 77, 94, 100, 100, 101, 79, 88, 99, 98, 73, 92, 86, 100, 99, 99, 100, 99, 100]
theorem node78617 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78617 support demand code
    entries78617 ((insert 81 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries78618 : List (Fin 2295 × ℕ) := [(86, 13), (177, 1), (341, 1), (350, 8), (352, 1), (474, 2), (482, 2), (490, 4), (514, 7), (550, 25), (572, 50), (580, 2), (630, 33), (632, 46), (737, 38), (739, 3), (797, 22), (817, 8), (849, 15), (851, 9), (852, 10), (858, 8), (888, 31), (891, 53), (901, 19), (919, 11), (923, 13), (924, 33), (925, 24), (934, 9), (944, 38), (945, 17), (946, 2), (960, 19), (965, 2), (969, 2), (970, 15), (973, 40), (978, 26), (1009, 8), (1012, 4), (1033, 6), (1042, 9), (1049, 12), (1073, 2), (1098, 15), (1099, 7), (1100, 6), (1123, 9), (1138, 1), (1139, 5), (1143, 11), (1149, 1), (1155, 20), (1167, 25), (1171, 13), (1173, 1), (1175, 16), (1177, 9), (1179, 16), (1186, 15), (1212, 8), (1247, 4), (1254, 11), (1269, 2), (1281, 57), (1293, 7), (1295, 1), (1297, 10), (1370, 6), (1481, 1), (1663, 8), (1705, 9), (2023, 4), (2072, 10), (2073, 1), (2244, 13)]
def cs78618 : List ℕ := [57, 24, 57, 87, 30, 2, 12, 100, 11, 0, 7, 100, 100, 0, 0, 25, 77, 100, 89, 81, 100, 55, 1, 100, 99, 13, 101, 188, 0, 81, 100, 100, 99, 100, 32, 91, 100, 99, 1, 100, 59, 99, 46, 85, 168, 100, 10, 0, 20, 100, 74, 50, 100, 100, 100, 103, 100, 80, 99, 60, 100, 100, 77, 13, 100, 80, 82, 33, 101, 99, 0, 173, 96, 52, 99, 63, 169, 96, 16, 100, 100, 23, 50, 100, 59, 100, 100, 100, 99, 99, 100, 78, 154, 99, 101, 86, 91, 99, 100, 100, 99, 99, 99, 100, 100, 93, 100, 100, 99, 39, 99, 100, 56, 100, 92, 98, 100, 100, 100, 68, 65, 100, 99, 99, 100, 96, 98, 101, 93, 100, 99, 99, 100, 101, 94, 99, 80, 100, 100, 100, 100, 90, 100, 84, 99, 93, 101, 92, 101, 92, 100, 99, 81, 97]
theorem node78618 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 81 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78618 support demand code
    entries78618 ((insert 46 (insert 81 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78616 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 81 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 81 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    46 node78617 node78618
theorem node78609 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 92 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    81 node78615 node78616
def entries78611 : List (Fin 2295 × ℕ) := [(100, 83), (429, 19), (431, 13), (514, 44), (531, 63), (550, 82), (571, 68), (583, 19), (620, 20), (624, 67), (625, 120), (630, 5), (632, 160), (675, 9), (676, 19), (733, 39), (735, 81), (736, 5), (833, 36), (849, 37), (851, 24), (852, 20), (859, 7), (870, 44), (887, 18), (891, 168), (919, 82), (922, 19), (923, 18), (924, 89), (925, 67), (944, 100), (946, 6), (965, 6), (970, 28), (973, 106), (978, 84), (1005, 1), (1033, 49), (1043, 17), (1049, 52), (1097, 13), (1098, 20), (1100, 32), (1114, 1), (1123, 37), (1143, 19), (1153, 40), (1155, 58), (1167, 67), (1173, 42), (1175, 6), (1177, 78), (1179, 5), (1186, 44), (1254, 138), (1257, 24), (1281, 73), (1293, 6), (1297, 24), (1298, 3), (1370, 25), (1481, 17), (1483, 11), (1705, 4), (1845, 17), (1848, 2), (1991, 19), (1993, 7), (2020, 1), (2240, 8)]
def cs78611 : List ℕ := [73, 138, 73, 110, 182, 0, 0, 255, 145, 0, 44, 255, 255, 146, 0, 82, 255, 232, 256, 86, 255, 187, 0, 211, 155, 0, 255, 443, 187, 193, 255, 256, 256, 256, 85, 252, 615, 256, 0, 255, 255, 256, 145, 151, 693, 257, 255, 0, 126, 256, 218, 68, 256, 256, 255, 318, 256, 251, 256, 44, 256, 213, 206, 239, 255, 253, 208, 67, 255, 637, 0, 424, 255, 248, 159, 190, 484, 256, 48, 256, 255, 256, 128, 256, 196, 257, 257, 255, 256, 256, 255, 240, 0, 255, 252, 257, 220, 256, 257, 256, 255, 257, 254, 256, 220, 257, 257, 202, 256, 49, 257, 257, 120, 246, 192, 257, 256, 255, 256, 190, 213, 257, 251, 257, 256, 215, 256, 257, 256, 257, 257, 257, 256, 258, 257, 255, 256, 208, 257, 257, 256, 234, 258, 210, 258, 199, 256, 241, 257, 217, 228, 253, 219, 233]
theorem node78611 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78611 support demand code
    entries78611 ((insert 92 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78613 : List (Fin 2295 × ℕ) := [(177, 6), (341, 1), (342, 5), (483, 29), (491, 31), (512, 9), (542, 9), (552, 30), (577, 3), (583, 23), (620, 32), (625, 45), (675, 20), (736, 11), (816, 5), (833, 24), (843, 3), (849, 13), (852, 45), (870, 21), (886, 4), (888, 14), (891, 49), (901, 36), (907, 10), (908, 5), (918, 8), (922, 8), (924, 42), (925, 1), (944, 33), (951, 12), (959, 2), (960, 24), (970, 8), (971, 3), (973, 46), (978, 44), (994, 8), (1009, 2), (1043, 15), (1047, 30), (1111, 1), (1113, 11), (1114, 2), (1123, 5), (1154, 6), (1155, 11), (1176, 17), (1177, 20), (1179, 14), (1186, 18), (1212, 16), (1223, 11), (1293, 4), (1295, 1), (1361, 4), (1497, 2), (1506, 6), (1517, 13), (1535, 6), (1536, 9), (1537, 14), (1603, 3), (1614, 6), (1622, 1), (1663, 8), (1688, 15), (1846, 2), (1848, 14), (1849, 7), (1859, 5), (1958, 12), (1976, 10), (2022, 4), (2023, 5)]
def cs78613 : List ℕ := [16, 10, 14, 13, 62, 76, 58, 100, 31, 10, 9, 100, 100, 26, 18, 48, 100, 91, 54, 29, 100, 101, 6, 100, 101, 4, 100, 266, 75, 21, 100, 100, 101, 100, 13, 99, 245, 82, 6, 100, 100, 88, 100, 74, 137, 100, 237, 6, 6, 100, 100, 32, 86, 100, 100, 100, 100, 99, 101, 99, 101, 73, 99, 100, 57, 97, 137, 22, 99, 26, 26, 149, 85, 94, 100, 89, 179, 100, 0, 99, 99, 100, 96, 101, 28, 101, 100, 100, 100, 99, 100, 90, 69, 87, 100, 101, 84, 101, 99, 99, 100, 100, 101, 50, 100, 101, 100, 74, 100, 51, 100, 100, 26, 100, 95, 100, 100, 100, 100, 88, 80, 74, 99, 100, 100, 66, 100, 100, 100, 99, 88, 85, 100, 100, 101, 100, 98, 100, 100, 100, 101, 98, 89, 89, 100, 85, 96, 81, 101, 99, 99, 100, 100, 100]
theorem node78613 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78613 support demand code
    entries78613 ((insert 69 (insert 92 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries78614 : List (Fin 2295 × ℕ) := [(86, 51), (342, 94), (469, 1), (482, 300), (483, 1), (491, 417), (514, 150), (550, 98), (552, 97), (580, 331), (691, 41), (736, 129), (786, 135), (816, 29), (833, 79), (849, 150), (851, 450), (870, 98), (887, 37), (888, 302), (891, 474), (901, 210), (902, 66), (922, 81), (923, 16), (924, 259), (925, 219), (944, 242), (960, 266), (965, 114), (970, 148), (973, 382), (978, 353), (994, 11), (1033, 164), (1034, 18), (1043, 12), (1047, 121), (1061, 55), (1098, 22), (1100, 172), (1111, 55), (1123, 136), (1143, 7), (1153, 39), (1154, 163), (1167, 255), (1171, 9), (1172, 51), (1173, 151), (1177, 312), (1179, 81), (1186, 160), (1212, 80), (1281, 26), (1293, 87), (1297, 105), (1322, 31), (1370, 65), (1517, 94), (1528, 133), (1537, 210), (1663, 11), (1703, 15), (1704, 97), (1705, 33), (1848, 27), (1859, 313), (1991, 120), (2022, 10), (2073, 37), (2240, 79)]
def cs78614 : List ℕ := [339, 1, 236, 176, 450, 824, 824, 1000, 210, 0, 150, 1000, 1000, 210, 0, 195, 1000, 1001, 1000, 339, 1000, 805, 112, 876, 733, 9, 1000, 2661, 0, 112, 807, 1000, 999, 1001, 352, 549, 1661, 974, 112, 1001, 211, 999, 1000, 639, 1612, 999, 0, 0, 112, 1000, 999, 210, 712, 1001, 1000, 1122, 999, 210, 1000, 317, 704, 840, 1001, 324, 935, 1001, 1064, 349, 999, 37, 276, 1808, 807, 451, 633, 736, 1617, 936, 325, 1001, 302, 699, 421, 1000, 322, 1002, 1000, 1001, 999, 1001, 1001, 972, 578, 1001, 899, 1001, 873, 999, 999, 1001, 1000, 1001, 638, 676, 1000, 1001, 1000, 985, 999, 321, 1001, 1001, 526, 1000, 1002, 1001, 1000, 1001, 1001, 694, 906, 1000, 1000, 1002, 1000, 870, 999, 1000, 1000, 1001, 1002, 1000, 1000, 1000, 998, 1001, 999, 938, 1000, 1000, 1000, 982, 1001, 733, 1001, 808, 1000, 983, 999, 887, 970, 941, 905, 737]
theorem node78614 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 69 (insert 92 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78614 support demand code
    entries78614 ((insert 46 (insert 69 (insert 92 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 1000 31 code_correct
  decide +kernel
theorem node78612 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 92 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 69 (insert 92 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    46 node78613 node78614
theorem node78610 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 92 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 92 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    69 node78611 node78612
theorem node78593 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 71 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    92 node78609 node78610
def entries78607 : List (Fin 2295 × ℕ) := [(23, 12), (177, 11), (179, 13), (342, 4), (471, 18), (482, 32), (494, 7), (495, 22), (512, 22), (514, 4), (552, 36), (572, 23), (583, 55), (584, 5), (585, 8), (620, 21), (622, 18), (675, 12), (842, 17), (843, 2), (851, 8), (852, 33), (870, 26), (888, 23), (892, 4), (907, 24), (908, 5), (918, 19), (919, 50), (922, 10), (944, 20), (946, 3), (952, 14), (969, 17), (972, 38), (973, 49), (977, 2), (978, 24), (994, 16), (1006, 2), (1009, 11), (1012, 5), (1034, 2), (1043, 1), (1060, 3), (1061, 12), (1075, 3), (1097, 13), (1098, 11), (1099, 1), (1100, 18), (1108, 22), (1110, 4), (1114, 1), (1122, 9), (1123, 13), (1154, 9), (1176, 20), (1177, 26), (1179, 26), (1186, 13), (1223, 8), (1235, 5), (1247, 4), (1261, 17), (1281, 14), (1297, 13), (1517, 50), (1559, 17), (1603, 2), (1622, 4), (1645, 18), (1688, 20), (1849, 4), (2062, 24), (2217, 2)]
def cs78607 : List ℕ := [22, 0, 32, 14, 61, 32, 52, 100, 54, 0, 26, 100, 100, 24, 2, 36, 100, 100, 100, 46, 100, 100, 24, 46, 100, 0, 100, 333, 84, 46, 100, 261, 74, 101, 0, 94, 167, 100, 24, 259, 100, 100, 64, 49, 183, 101, 258, 24, 44, 100, 100, 90, 100, 99, 101, 100, 100, 100, 61, 99, 90, 100, 100, 100, 46, 101, 162, 73, 78, 100, 14, 0, 72, 100, 78, 101, 131, 100, 0, 99, 101, 99, 100, 100, 92, 101, 77, 100, 100, 100, 99, 97, 100, 99, 99, 100, 100, 100, 102, 100, 100, 100, 83, 99, 101, 100, 100, 86, 100, 77, 100, 100, 96, 100, 79, 99, 100, 101, 101, 95, 99, 91, 92, 85, 100, 78, 100, 102, 81, 99, 67, 95, 101, 102, 70, 100, 96, 91, 100, 101, 100, 100, 81, 100, 101, 101, 100, 88, 101, 100, 101, 88, 97, 75]
theorem node78607 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 46 (insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78607 support demand code
    entries78607 ((insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 31 (insert 46 (insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
def entries78608 : List (Fin 2295 × ℕ) := [(179, 27), (342, 7), (475, 30), (484, 17), (494, 11), (514, 13), (542, 53), (552, 46), (620, 23), (632, 24), (691, 12), (797, 3), (816, 8), (842, 2), (843, 9), (846, 12), (849, 8), (851, 6), (852, 32), (870, 36), (888, 18), (889, 20), (891, 9), (892, 11), (896, 5), (901, 30), (907, 21), (944, 32), (946, 4), (952, 15), (959, 15), (960, 7), (965, 4), (969, 5), (970, 8), (972, 6), (973, 49), (978, 27), (994, 15), (1006, 17), (1012, 13), (1034, 2), (1047, 7), (1076, 6), (1090, 3), (1098, 5), (1100, 7), (1110, 6), (1111, 6), (1113, 8), (1123, 17), (1126, 3), (1148, 3), (1153, 8), (1154, 3), (1176, 21), (1177, 26), (1179, 14), (1183, 10), (1186, 26), (1223, 17), (1228, 5), (1235, 10), (1247, 5), (1272, 6), (1310, 33), (1348, 1), (1370, 2), (1498, 29), (1517, 17), (1536, 7), (1604, 15), (1645, 21), (1848, 5), (1849, 11), (1900, 1)]
def cs78608 : List ℕ := [17, 12, 15, 38, 56, 46, 17, 101, 17, 0, 13, 100, 101, 0, 53, 75, 91, 100, 67, 41, 100, 45, 27, 100, 90, 0, 76, 193, 99, 51, 100, 0, 93, 101, 20, 101, 209, 101, 27, 85, 100, 88, 98, 77, 121, 101, 251, 49, 65, 101, 100, 100, 97, 100, 116, 101, 95, 100, 93, 101, 94, 78, 101, 98, 45, 101, 164, 32, 101, 99, 15, 31, 82, 100, 100, 101, 168, 100, 14, 100, 100, 99, 99, 101, 98, 100, 83, 100, 101, 100, 100, 91, 100, 64, 67, 100, 99, 102, 100, 100, 101, 99, 100, 74, 101, 101, 101, 94, 88, 46, 99, 99, 89, 101, 75, 101, 101, 101, 100, 96, 54, 100, 101, 100, 102, 84, 101, 100, 94, 100, 100, 99, 100, 100, 84, 101, 96, 73, 100, 100, 102, 100, 100, 91, 100, 89, 100, 100, 101, 101, 100, 101, 100, 90]
theorem node78608 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 31 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78608 support demand code
    entries78608 ((insert 31 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78601 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154))
    31 node78607 node78608
def entries78603 : List (Fin 2295 × ℕ) := [(23, 42), (49, 44), (179, 39), (273, 10), (342, 25), (429, 27), (482, 1), (484, 57), (512, 58), (514, 25), (531, 6), (552, 140), (572, 48), (584, 17), (632, 58), (691, 39), (736, 7), (737, 75), (797, 24), (849, 38), (851, 99), (870, 83), (874, 93), (888, 109), (889, 41), (919, 51), (922, 65), (934, 24), (944, 66), (945, 67), (946, 32), (965, 32), (970, 8), (972, 14), (973, 117), (978, 77), (994, 62), (1006, 6), (1011, 6), (1012, 23), (1034, 11), (1047, 12), (1061, 15), (1076, 27), (1098, 23), (1100, 6), (1123, 75), (1153, 20), (1155, 26), (1171, 8), (1173, 16), (1176, 11), (1177, 82), (1179, 30), (1186, 30), (1212, 27), (1235, 7), (1247, 41), (1261, 12), (1272, 6), (1281, 115), (1298, 22), (1322, 7), (1370, 27), (1517, 58), (1655, 9), (1663, 20), (1667, 6), (1685, 57), (1845, 8), (1846, 30)]
def cs78603 : List ℕ := [115, 0, 115, 153, 141, 58, 58, 256, 44, 0, 83, 256, 255, 99, 0, 197, 256, 256, 396, 157, 256, 115, 96, 115, 256, 8, 256, 579, 57, 154, 256, 255, 183, 255, 111, 256, 297, 256, 96, 536, 72, 247, 256, 182, 489, 258, 0, 41, 195, 256, 256, 115, 125, 256, 256, 257, 256, 58, 256, 210, 92, 64, 256, 84, 205, 238, 366, 58, 256, 256, 0, 0, 238, 257, 121, 249, 424, 256, 56, 256, 256, 210, 145, 256, 136, 256, 152, 255, 257, 256, 256, 249, 256, 255, 160, 257, 222, 256, 257, 256, 257, 256, 221, 208, 256, 256, 257, 232, 237, 101, 256, 256, 195, 243, 234, 256, 256, 255, 256, 216, 134, 258, 252, 257, 255, 238, 257, 257, 257, 257, 255, 210, 257, 256, 202, 256, 234, 226, 256, 256, 256, 182, 194, 256, 257, 229, 230, 215, 256, 256, 257, 256, 224, 200]
theorem node78603 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78603 support demand code
    entries78603 ((insert 46 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78605 : List (Fin 2295 × ℕ) := [(177, 5), (429, 5), (466, 15), (512, 12), (552, 11), (572, 11), (632, 15), (644, 3), (737, 6), (842, 4), (843, 1), (851, 16), (860, 5), (870, 17), (888, 5), (889, 12), (895, 5), (918, 14), (919, 9), (922, 4), (944, 10), (945, 10), (946, 7), (952, 6), (960, 4), (970, 6), (972, 1), (973, 11), (978, 14), (994, 6), (1006, 5), (1033, 6), (1034, 1), (1043, 2), (1047, 3), (1076, 1), (1094, 2), (1098, 1), (1100, 8), (1128, 4), (1143, 1), (1153, 4), (1155, 9), (1167, 1), (1174, 3), (1175, 4), (1177, 7), (1179, 10), (1233, 2), (1247, 2), (1257, 7), (1297, 1), (1370, 7), (1509, 4), (1528, 1), (1602, 1), (1685, 7), (1691, 3)]
def cs78605 : List ℕ := [15, 0, 0, 0, 16, 1, 0, 31, 6, 0, 17, 32, 21, 0, 1, 25, 32, 32, 0, 16, 32, 28, 12, 16, 16, 0, 33, 45, 10, 27, 32, 31, 19, 28, 17, 21, 49, 32, 12, 47, 12, 31, 26, 26, 76, 32, 5, 17, 32, 32, 29, 32, 20, 22, 33, 33, 32, 15, 33, 32, 32, 18, 32, 5, 32, 32, 50, 20, 27, 32, 6, 4, 31, 32, 27, 32, 56, 23, 0, 31, 33, 25, 12, 32, 18, 32, 25, 30, 75, 32, 32, 32, 32, 31, 25, 32, 23, 32, 32, 32, 30, 32, 30, 30, 32, 31, 29, 28, 17, 11, 32, 32, 30, 31, 16, 31, 32, 31, 32, 25, 32, 32, 31, 29, 32, 23, 31, 32, 32, 32, 30, 26, 32, 33, 26, 32, 28, 25, 32, 32, 31, 25, 24, 22, 32, 32, 32, 23, 32, 21, 33, 23, 32, 23]
theorem node78605 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78605 support demand code
    entries78605 ((insert 18 (insert 46 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 88 (insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 32 31 code_correct
  decide +kernel
def entries78606 : List (Fin 2295 × ℕ) := [(179, 24), (273, 14), (342, 7), (429, 18), (466, 43), (512, 13), (514, 14), (552, 28), (572, 20), (584, 31), (632, 47), (691, 28), (731, 20), (736, 2), (737, 22), (739, 3), (777, 7), (816, 1), (817, 4), (851, 37), (870, 28), (887, 21), (888, 22), (889, 39), (891, 10), (919, 28), (922, 36), (924, 9), (944, 33), (945, 5), (952, 17), (972, 2), (973, 37), (978, 47), (994, 41), (1012, 2), (1022, 8), (1098, 35), (1108, 7), (1121, 6), (1123, 14), (1143, 2), (1153, 3), (1154, 11), (1155, 21), (1171, 8), (1175, 12), (1177, 4), (1178, 15), (1179, 32), (1186, 1), (1212, 7), (1247, 13), (1269, 9), (1281, 5), (1338, 8), (1354, 8), (1517, 25), (1528, 7), (1667, 9), (1689, 8), (1846, 3), (1991, 1)]
def cs78606 : List ℕ := [48, 0, 5, 5, 37, 0, 25, 85, 0, 0, 27, 101, 48, 0, 0, 28, 75, 100, 5, 63, 100, 80, 24, 48, 33, 8, 100, 165, 0, 71, 101, 100, 61, 86, 12, 63, 145, 99, 24, 150, 20, 99, 82, 96, 162, 100, 0, 39, 49, 100, 75, 59, 99, 95, 100, 100, 98, 47, 101, 99, 101, 54, 100, 25, 99, 100, 166, 25, 99, 100, 25, 19, 100, 100, 76, 100, 121, 100, 8, 100, 74, 95, 39, 101, 100, 100, 89, 98, 21, 99, 100, 95, 100, 100, 62, 99, 94, 99, 101, 99, 99, 125, 97, 76, 100, 99, 100, 86, 76, 57, 99, 99, 47, 71, 100, 98, 100, 100, 99, 53, 47, 85, 99, 99, 100, 86, 98, 100, 94, 100, 95, 61, 100, 99, 94, 99, 68, 87, 98, 99, 100, 100, 88, 96, 100, 100, 64, 65, 94, 75, 99, 86, 100, 66]
theorem node78606 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 88 (insert 18 (insert 46 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78606 support demand code
    entries78606 ((insert 88 (insert 18 (insert 46 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))))) : Finset (Fin 154)) ((insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78604 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 18 (insert 46 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 18 (insert 46 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    88 node78605 node78606
theorem node78602 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 46 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 46 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    18 node78603 node78604
theorem node78595 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 39 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    46 node78601 node78602
def entries78599 : List (Fin 2295 × ℕ) := [(177, 31), (179, 57), (350, 6), (351, 51), (429, 41), (475, 24), (512, 24), (531, 131), (552, 100), (583, 11), (620, 10), (622, 42), (624, 13), (632, 131), (664, 8), (737, 51), (797, 63), (874, 26), (888, 75), (889, 52), (901, 24), (907, 27), (908, 24), (924, 28), (944, 112), (945, 45), (946, 55), (952, 17), (970, 30), (973, 109), (978, 72), (1005, 4), (1009, 23), (1012, 30), (1033, 21), (1034, 8), (1049, 13), (1061, 14), (1076, 3), (1096, 2), (1098, 19), (1100, 23), (1111, 24), (1114, 21), (1123, 64), (1143, 7), (1155, 18), (1167, 52), (1171, 21), (1173, 17), (1176, 17), (1177, 79), (1179, 7), (1186, 13), (1212, 42), (1247, 16), (1254, 92), (1293, 11), (1298, 34), (1348, 57), (1370, 5), (1488, 2), (1583, 1), (1627, 22), (1663, 21), (1689, 6), (1705, 17), (1751, 17), (1778, 24), (1848, 5), (1849, 25), (1859, 51), (2073, 11), (2217, 26), (2240, 1), (2259, 67)]
def cs78599 : List ℕ := [140, 92, 89, 24, 181, 140, 51, 256, 114, 0, 24, 256, 256, 181, 22, 100, 256, 191, 256, 75, 256, 135, 88, 256, 189, 21, 256, 320, 189, 245, 256, 257, 135, 256, 17, 256, 522, 256, 88, 0, 227, 454, 216, 257, 343, 257, 256, 52, 245, 256, 135, 122, 257, 255, 256, 257, 257, 200, 257, 75, 135, 230, 179, 182, 256, 257, 356, 52, 256, 577, 23, 28, 257, 257, 164, 258, 379, 250, 38, 255, 256, 256, 241, 257, 257, 257, 187, 256, 257, 256, 256, 258, 230, 257, 206, 256, 242, 257, 256, 256, 255, 256, 224, 256, 256, 257, 257, 256, 256, 62, 257, 257, 222, 257, 233, 256, 257, 256, 257, 205, 147, 257, 256, 256, 257, 243, 256, 257, 256, 256, 256, 257, 257, 257, 201, 257, 243, 218, 257, 257, 256, 218, 256, 224, 199, 214, 257, 256, 257, 256, 256, 256, 188, 182]
theorem node78599 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 69 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78599 support demand code
    entries78599 ((insert 39 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 41 (insert 69 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
def entries78600 : List (Fin 2295 × ℕ) := [(179, 24), (341, 2), (342, 11), (350, 3), (468, 30), (514, 36), (552, 15), (571, 27), (583, 33), (622, 21), (664, 8), (677, 13), (737, 26), (797, 2), (817, 10), (833, 2), (850, 44), (851, 20), (870, 11), (874, 31), (888, 28), (889, 23), (901, 30), (902, 2), (922, 1), (924, 10), (925, 8), (944, 28), (945, 16), (946, 36), (952, 13), (970, 15), (973, 39), (978, 17), (1006, 14), (1009, 18), (1033, 20), (1043, 3), (1049, 28), (1061, 5), (1076, 4), (1097, 1), (1098, 4), (1099, 4), (1123, 9), (1141, 2), (1155, 21), (1167, 26), (1173, 3), (1175, 29), (1212, 26), (1235, 2), (1237, 5), (1247, 8), (1254, 19), (1269, 1), (1293, 10), (1348, 20), (1370, 8), (1379, 8), (1392, 13), (1477, 12), (1572, 8), (1689, 6), (1704, 5), (1705, 3), (1715, 1), (1779, 13), (1845, 22), (1846, 1), (2072, 4), (2247, 2)]
def cs78600 : List ℕ := [2, 54, 2, 44, 57, 7, 0, 89, 19, 0, 44, 65, 100, 44, 0, 15, 100, 100, 90, 55, 100, 90, 29, 99, 22, 0, 99, 143, 54, 29, 99, 75, 27, 99, 32, 99, 144, 101, 41, 14, 99, 0, 101, 59, 186, 100, 100, 43, 101, 100, 82, 99, 101, 96, 99, 137, 101, 71, 100, 42, 99, 68, 100, 101, 100, 100, 101, 26, 101, 202, 21, 19, 99, 91, 96, 62, 153, 94, 3, 99, 100, 99, 84, 101, 76, 100, 29, 99, 101, 100, 99, 82, 93, 100, 65, 99, 100, 100, 101, 99, 99, 100, 101, 51, 99, 98, 99, 100, 100, 26, 100, 100, 75, 99, 83, 98, 100, 101, 99, 68, 77, 99, 98, 98, 101, 100, 98, 100, 100, 97, 97, 94, 98, 100, 78, 98, 82, 93, 100, 100, 100, 82, 100, 87, 99, 71, 99, 99, 100, 78, 100, 100, 66, 86]
theorem node78600 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 41 (insert 39 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78600 support demand code
    entries78600 ((insert 41 (insert 39 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 69 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)) 100 31 code_correct
  decide +kernel
theorem node78597 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 69 (insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅)))))) : Finset (Fin 154))
    41 node78599 node78600
def entries78598 : List (Fin 2295 × ℕ) := [(86, 19), (177, 29), (179, 92), (342, 21), (351, 7), (475, 16), (484, 36), (512, 15), (514, 35), (552, 151), (572, 107), (583, 118), (584, 11), (736, 30), (739, 2), (797, 21), (842, 24), (843, 14), (851, 10), (852, 77), (858, 36), (859, 34), (870, 19), (888, 53), (889, 51), (891, 57), (901, 67), (922, 1), (944, 49), (945, 10), (946, 25), (952, 7), (965, 45), (969, 21), (970, 24), (973, 96), (978, 104), (1009, 40), (1012, 5), (1033, 7), (1034, 23), (1061, 21), (1096, 2), (1098, 29), (1099, 4), (1100, 46), (1113, 5), (1123, 42), (1139, 7), (1148, 9), (1149, 4), (1155, 22), (1167, 16), (1172, 13), (1173, 16), (1175, 54), (1176, 36), (1177, 32), (1179, 62), (1186, 51), (1212, 23), (1247, 29), (1370, 28), (1541, 26), (1645, 61), (1663, 40), (1705, 6), (1859, 118), (2073, 8), (2240, 11), (2241, 25), (2259, 52)]
def cs78598 : List ℕ := [170, 0, 52, 16, 139, 206, 154, 257, 34, 0, 50, 224, 256, 0, 0, 151, 256, 246, 170, 160, 256, 237, 121, 256, 203, 0, 256, 592, 61, 121, 256, 201, 185, 256, 83, 237, 427, 256, 121, 20, 220, 256, 256, 212, 376, 256, 256, 51, 156, 256, 204, 175, 256, 250, 257, 254, 257, 118, 254, 171, 125, 194, 160, 228, 227, 255, 270, 52, 255, 35, 7, 83, 233, 257, 256, 255, 355, 247, 74, 255, 256, 57, 256, 256, 157, 255, 255, 257, 257, 255, 256, 256, 256, 214, 159, 255, 204, 256, 257, 255, 256, 256, 187, 176, 255, 256, 244, 233, 255, 136, 256, 256, 167, 255, 241, 255, 256, 256, 257, 218, 185, 255, 255, 255, 255, 234, 255, 256, 256, 254, 256, 256, 255, 255, 230, 255, 238, 244, 256, 255, 256, 254, 222, 220, 255, 252, 240, 237, 256, 255, 255, 256, 232, 192]
theorem node78598 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 69 (insert 39 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply fused_sparse_packed_excludes base cs78598 support demand code
    entries78598 ((insert 69 (insert 39 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))))) : Finset (Fin 154)) ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)) 256 31 code_correct
  decide +kernel
theorem node78596 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 39 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 39 (insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))))) : Finset (Fin 154)) ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    69 node78597 node78598
theorem node78594 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 71 (insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    39 node78595 node78596
theorem node78592 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 70 (insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))))) : Finset (Fin 154)) ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    71 node78593 node78594
theorem node78590 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 47 (insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅))))))) : Finset (Fin 154)) ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    70 node78591 node78592
theorem node78588 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 31 ∧
      (∀ i ∈ ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 31 ((insert 67 (insert 34 (insert 109 (insert 119 (insert 78 (insert 25 ∅)))))) : Finset (Fin 154)) ((insert 27 (insert 36 (insert 66 (insert 76 (insert 44 ∅))))) : Finset (Fin 154))
    47 node78589 node78590
#print axioms node78588
end OmissionResidualCover31Fused
