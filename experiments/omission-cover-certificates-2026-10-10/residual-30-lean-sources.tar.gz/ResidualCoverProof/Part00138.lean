import ResidualCoverProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries621 : List (Fin 1589 × ℕ) := [(37, 379), (46, 210), (75, 341), (315, 126), (384, 24), (468, 209), (469, 14), (479, 280), (507, 114), (515, 283), (530, 134), (531, 75), (551, 299), (571, 32), (639, 14), (680, 60), (731, 384), (737, 173), (741, 57), (819, 88), (843, 97), (856, 217), (863, 355), (867, 15), (869, 104), (870, 265), (872, 210), (893, 5), (894, 129), (895, 107), (906, 412), (916, 2), (917, 141), (920, 1), (928, 154), (930, 202), (936, 231), (937, 97), (938, 184), (940, 62), (951, 76), (952, 107), (958, 80), (966, 10), (973, 455), (978, 248), (1031, 43), (1033, 40), (1034, 24), (1042, 15), (1043, 109), (1049, 82), (1056, 59), (1067, 65), (1111, 134), (1120, 66), (1122, 108), (1123, 41), (1143, 113), (1167, 173), (1173, 232), (1181, 231), (1183, 36), (1186, 134), (1188, 33), (1212, 82), (1227, 31), (1235, 181), (1241, 76), (1249, 22), (1261, 2), (1263, 19), (1267, 157), (1275, 64), (1276, 56), (1280, 60), (1290, 48), (1292, 1), (1297, 97), (1317, 20), (1342, 159), (1358, 347), (1497, 124), (1498, 99), (1503, 68), (1545, 140), (1548, 17), (1580, 37)]
def cs621 : List ℕ := [407, 283, 0, 0, 317, 804, 210, 947, 446, 469, 688, 999, 1000, 456, 588, 398, 999, 1000, 999, 411, 1000, 999, 0, 1000, 999, 1001, 1000, 935, 157, 551, 999, 999, 213, 173, 999, 1000, 999, 15, 985, 999, 799, 839, 582, 906, 1000, 1000, 1000, 2070, 644, 1000, 1000, 999, 1000, 1000, 232, 1000, 1001, 1001, 999, 999, 1000, 999, 645, 999, 1000, 645, 2063, 2326, 969, 999, 1000, 999, 999, 832, 1000, 1000, 101, 1001, 1001, 1000, 1000, 818, 536, 1000, 704, 929, 0, 1000, 1001, 1000, 999, 843, 507, 1001, 534, 420, 1000, 1001, 1000, 1000, 999, 1000, 1000, 1001, 423, 1000, 982, 999, 1000, 464, 1000, 1000, 681, 1001, 1000, 1000, 1000, 482, 1000, 455, 924, 1000, 1000, 1000, 1000, 984, 947, 1000, 583, 1000, 1000, 832, 1000, 1000, 947, 1000, 796, 902, 1000, 1000, 864, 1000, 1000, 1000, 761, 752, 1000, 1000, 1000, 1000, 1124, 868, 1000, 1000]
theorem loads621 : cs621.get =
    load (fun i : Fin entries621.length => support (entries621.get i).1)
      (fun i => (entries621.get i).2) := by
  apply load_eq_of_sparse_packed base cs621 support code
    entries621 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node621 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 47 (insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs621 support demand
    entries621 ((insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 66 (insert 47 (insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅))))))) : Finset (Fin 154)) 1000 30 loads621
  decide +kernel
def entries622 : List (Fin 1589 × ℕ) := [(20, 331), (35, 169), (75, 457), (177, 21), (315, 74), (479, 279), (506, 196), (507, 133), (515, 172), (527, 146), (529, 4), (551, 23), (572, 17), (679, 141), (681, 154), (731, 170), (737, 143), (742, 42), (763, 159), (798, 9), (819, 26), (842, 52), (843, 211), (863, 173), (868, 17), (869, 123), (870, 157), (881, 58), (886, 93), (893, 60), (894, 153), (895, 179), (905, 30), (906, 325), (916, 88), (917, 15), (920, 24), (925, 216), (936, 151), (938, 130), (940, 47), (958, 32), (964, 10), (966, 141), (973, 533), (978, 221), (1009, 17), (1031, 4), (1043, 215), (1055, 24), (1069, 25), (1110, 3), (1111, 115), (1113, 16), (1114, 137), (1120, 9), (1122, 88), (1123, 148), (1143, 176), (1167, 167), (1173, 149), (1181, 203), (1183, 121), (1184, 27), (1186, 151), (1188, 310), (1217, 148), (1222, 117), (1227, 4), (1234, 13), (1235, 62), (1236, 94), (1249, 34), (1262, 89), (1266, 21), (1267, 146), (1268, 162), (1275, 88), (1276, 52), (1280, 90), (1297, 30), (1342, 170), (1358, 178), (1400, 120), (1403, 132), (1469, 25), (1488, 115), (1497, 78), (1498, 19), (1525, 89), (1545, 202), (1580, 5)]
def cs622 : List ℕ := [510, 207, 354, 331, 378, 637, 0, 1000, 589, 591, 735, 907, 1001, 671, 462, 100, 1000, 999, 1000, 179, 999, 999, 21, 1000, 999, 1001, 1000, 1000, 171, 978, 1000, 1000, 653, 167, 1000, 1000, 999, 0, 503, 1000, 999, 999, 195, 999, 1000, 910, 999, 1597, 709, 999, 998, 999, 1000, 1000, 266, 999, 1000, 999, 1000, 1000, 999, 1000, 814, 999, 1000, 999, 322, 2264, 999, 1000, 999, 999, 999, 1000, 924, 723, 310, 1000, 1000, 1000, 1000, 999, 1001, 999, 842, 795, 0, 1000, 1000, 940, 1000, 754, 565, 999, 527, 249, 1000, 1000, 1000, 1000, 999, 1000, 813, 1000, 389, 1000, 1000, 948, 999, 391, 999, 1000, 1000, 1001, 1000, 999, 999, 674, 1000, 533, 1000, 824, 1000, 1000, 1001, 944, 1151, 1000, 994, 999, 1001, 778, 1000, 1000, 768, 1000, 922, 931, 1000, 1000, 932, 1000, 915, 1000, 1001, 745, 910, 1000, 1000, 1000, 1184, 948, 1000, 975]
theorem loads622 : cs622.get =
    load (fun i : Fin entries622.length => support (entries622.get i).1)
      (fun i => (entries622.get i).2) := by
  apply load_eq_of_sparse_packed base cs622 support code
    entries622 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node622 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 66 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs622 support demand
    entries622 ((insert 66 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 47 (insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154)) 1000 30 loads622
  decide +kernel
theorem node617 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 47 (insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154))
    66 node621 node622
def entries619 : List (Fin 1589 × ℕ) := [(7, 28), (20, 256), (37, 68), (46, 141), (62, 430), (75, 310), (360, 26), (384, 7), (385, 2), (469, 166), (471, 80), (472, 181), (479, 70), (507, 254), (526, 398), (529, 28), (531, 91), (542, 316), (585, 7), (625, 319), (731, 359), (737, 30), (743, 55), (762, 22), (798, 136), (843, 65), (869, 152), (870, 108), (872, 33), (878, 70), (886, 348), (894, 228), (895, 65), (896, 221), (906, 187), (915, 26), (922, 148), (925, 172), (935, 107), (938, 138), (940, 75), (950, 39), (951, 4), (952, 111), (955, 40), (966, 87), (968, 20), (973, 552), (978, 192), (985, 46), (1004, 4), (1043, 39), (1044, 55), (1045, 27), (1047, 4), (1049, 108), (1069, 206), (1090, 134), (1107, 22), (1110, 8), (1111, 7), (1114, 123), (1120, 99), (1123, 119), (1143, 133), (1167, 123), (1173, 127), (1177, 76), (1180, 1), (1181, 187), (1183, 209), (1186, 99), (1188, 88), (1212, 86), (1221, 228), (1235, 9), (1258, 76), (1261, 113), (1262, 110), (1275, 54), (1280, 133), (1286, 25), (1293, 104), (1358, 30), (1374, 192), (1400, 101), (1469, 208), (1516, 29), (1545, 45), (1548, 110), (1580, 112)]
def cs619 : List ℕ := [391, 327, 489, 256, 210, 429, 141, 1000, 434, 684, 310, 817, 1000, 978, 949, 0, 1000, 1000, 897, 498, 999, 1000, 0, 999, 1001, 1000, 663, 1001, 527, 707, 999, 999, 426, 193, 1000, 973, 1001, 0, 498, 1000, 1000, 999, 4, 1000, 999, 1002, 2190, 0, 681, 1000, 999, 1000, 1000, 1000, 355, 1000, 1000, 998, 1000, 999, 999, 1000, 626, 930, 999, 739, 1000, 2396, 1000, 1000, 998, 1000, 684, 1001, 847, 999, 164, 1000, 999, 999, 1000, 999, 999, 1000, 680, 999, 76, 998, 1000, 955, 1000, 794, 268, 999, 709, 314, 999, 1000, 999, 999, 1000, 1001, 1001, 999, 556, 1000, 999, 758, 1001, 543, 1000, 1000, 556, 999, 1000, 999, 999, 526, 999, 628, 991, 841, 1000, 1000, 998, 831, 1189, 1000, 779, 999, 999, 835, 1000, 999, 944, 999, 1000, 894, 999, 1001, 856, 1000, 1000, 1000, 999, 915, 999, 1001, 1000, 987, 1232, 1001, 1000, 1000]
theorem loads619 : cs619.get =
    load (fun i : Fin entries619.length => support (entries619.get i).1)
      (fun i => (entries619.get i).2) := by
  apply load_eq_of_sparse_packed base cs619 support code
    entries619 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node619 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs619 support demand
    entries619 ((insert 47 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 46 (insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154)) 1000 30 loads619
  decide +kernel
def entries620 : List (Fin 1589 × ℕ) := [(20, 236), (37, 50), (62, 360), (75, 672), (384, 116), (421, 223), (478, 1), (527, 1), (531, 58), (552, 210), (569, 207), (572, 322), (730, 44), (731, 383), (737, 170), (739, 42), (798, 114), (842, 8), (843, 278), (846, 57), (858, 56), (870, 126), (872, 111), (886, 58), (895, 170), (905, 110), (916, 78), (922, 123), (925, 354), (935, 184), (936, 90), (940, 33), (948, 13), (951, 44), (952, 24), (958, 211), (966, 198), (970, 82), (973, 441), (978, 275), (985, 68), (1043, 124), (1047, 62), (1049, 119), (1055, 67), (1056, 83), (1061, 95), (1120, 190), (1122, 94), (1123, 9), (1133, 83), (1142, 56), (1143, 113), (1155, 31), (1167, 134), (1171, 6), (1173, 211), (1181, 208), (1183, 64), (1186, 71), (1188, 138), (1212, 185), (1219, 117), (1221, 145), (1233, 7), (1236, 290), (1275, 85), (1280, 264), (1317, 9), (1324, 3), (1335, 85), (1354, 55), (1370, 5), (1374, 213), (1434, 57), (1488, 15), (1497, 150), (1503, 52), (1537, 126)]
def cs620 : List ℕ := [699, 438, 271, 353, 291, 875, 56, 1000, 469, 360, 672, 942, 1000, 951, 672, 210, 1000, 1001, 1000, 735, 872, 842, 0, 1000, 1000, 999, 944, 1000, 0, 908, 1000, 1000, 354, 140, 1000, 885, 999, 56, 410, 1001, 799, 1000, 210, 634, 1001, 1000, 0, 0, 617, 999, 1000, 999, 999, 1001, 362, 1001, 1000, 505, 1000, 413, 1000, 1000, 623, 421, 916, 767, 1000, 2346, 999, 675, 1000, 944, 649, 909, 625, 887, 190, 1001, 1001, 999, 942, 751, 1000, 1000, 617, 1001, 0, 1000, 1001, 1000, 999, 879, 764, 873, 559, 346, 1001, 1001, 1001, 998, 999, 1000, 812, 1000, 460, 1001, 1001, 849, 999, 464, 1000, 999, 1001, 1001, 1001, 999, 999, 842, 1000, 524, 1001, 1001, 1000, 999, 1000, 942, 1089, 1000, 770, 999, 999, 725, 1000, 999, 1000, 1000, 782, 912, 999, 998, 948, 1000, 999, 999, 1000, 839, 999, 838, 999, 999, 1093, 987, 999, 884]
theorem loads620 : cs620.get =
    load (fun i : Fin entries620.length => support (entries620.get i).1)
      (fun i => (entries620.get i).2) := by
  apply load_eq_of_sparse_packed base cs620 support code
    entries620 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node620 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs620 support demand
    entries620 ((insert 46 (insert 47 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)) 1000 30 loads620
  decide +kernel
theorem node618 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅))))) : Finset (Fin 154))
    46 node619 node620
theorem node615 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 150 (insert 67 (insert 95 (insert 104 (insert 126 ∅))))) : Finset (Fin 154))
    47 node617 node618
def entries616 : List (Fin 1589 × ℕ) := [(20, 251), (37, 111), (62, 39), (75, 604), (421, 36), (472, 97), (479, 75), (483, 24), (507, 84), (515, 109), (529, 77), (531, 33), (551, 105), (552, 27), (572, 71), (625, 6), (731, 253), (737, 257), (763, 68), (798, 8), (800, 4), (843, 86), (853, 19), (863, 368), (868, 7), (869, 152), (870, 117), (886, 42), (894, 232), (895, 77), (906, 262), (918, 129), (925, 230), (930, 48), (935, 150), (936, 72), (937, 2), (938, 201), (940, 75), (952, 144), (958, 173), (966, 235), (973, 431), (978, 177), (985, 73), (1005, 186), (1043, 135), (1049, 112), (1052, 14), (1053, 95), (1060, 28), (1061, 104), (1070, 20), (1082, 25), (1090, 33), (1111, 56), (1114, 144), (1120, 85), (1122, 204), (1143, 114), (1160, 102), (1161, 1), (1167, 249), (1173, 114), (1180, 238), (1186, 216), (1188, 163), (1217, 126), (1219, 54), (1222, 18), (1236, 261), (1246, 8), (1247, 15), (1258, 18), (1262, 97), (1267, 88), (1280, 100), (1342, 137), (1354, 101), (1358, 129), (1370, 9), (1400, 132), (1454, 31), (1478, 67), (1489, 63), (1497, 143), (1503, 109), (1537, 40), (1545, 24), (1548, 44), (1572, 84), (1576, 142), (1580, 99)]
def cs616 : List ℕ := [616, 172, 281, 305, 435, 699, 0, 999, 499, 491, 720, 957, 1000, 539, 703, 132, 1000, 1000, 1000, 221, 1000, 1001, 0, 999, 1000, 1000, 963, 1000, 236, 855, 999, 999, 314, 249, 1000, 753, 1001, 0, 473, 999, 1000, 1000, 427, 1000, 1000, 999, 1000, 1000, 812, 1001, 999, 998, 1001, 1000, 132, 1000, 1001, 1000, 1000, 918, 999, 1000, 839, 1000, 1001, 798, 999, 2524, 999, 1000, 1000, 1000, 990, 1000, 902, 1000, 272, 1000, 1002, 999, 1000, 782, 1001, 1000, 942, 951, 0, 1001, 1001, 999, 1001, 999, 949, 1000, 594, 392, 1001, 1000, 1001, 1001, 999, 999, 1000, 1000, 465, 1000, 1000, 1001, 1000, 498, 1000, 1001, 1000, 1001, 1001, 1000, 1000, 648, 1000, 431, 1000, 990, 1001, 1001, 1000, 937, 1038, 1000, 799, 1001, 1001, 823, 1000, 1000, 671, 1001, 764, 919, 1000, 1000, 1001, 1000, 711, 1000, 674, 755, 601, 1000, 1001, 920, 431, 1000, 665, 749]
theorem loads616 : cs616.get =
    load (fun i : Fin entries616.length => support (entries616.get i).1)
      (fun i => (entries616.get i).2) := by
  apply load_eq_of_sparse_packed base cs616 support code
    entries616 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node616 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 150 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 95 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs616 support demand
    entries616 ((insert 150 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 95 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)) 1000 30 loads616
  decide +kernel
theorem node605 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 95 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 67 (insert 95 (insert 104 (insert 126 ∅)))) : Finset (Fin 154))
    150 node615 node616
def entries613 : List (Fin 1589 × ℕ) := [(7, 113), (20, 187), (96, 6), (137, 45), (179, 200), (216, 136), (313, 27), (315, 60), (439, 56), (440, 7), (479, 292), (498, 28), (507, 345), (527, 10), (551, 182), (572, 56), (639, 105), (737, 11), (739, 54), (741, 66), (797, 168), (798, 337), (846, 169), (856, 139), (863, 60), (868, 294), (870, 184), (871, 60), (872, 12), (886, 195), (896, 15), (906, 192), (922, 165), (923, 168), (925, 54), (927, 16), (928, 142), (930, 49), (940, 492), (943, 193), (946, 56), (970, 31), (973, 436), (978, 117), (1020, 44), (1031, 244), (1044, 171), (1090, 159), (1111, 140), (1114, 91), (1120, 72), (1123, 263), (1143, 405), (1154, 71), (1173, 231), (1181, 57), (1183, 82), (1188, 194), (1219, 230), (1226, 42), (1227, 228), (1234, 89), (1261, 32), (1267, 85), (1275, 58), (1276, 101), (1292, 190), (1293, 262), (1297, 103), (1312, 174), (1358, 253), (1370, 51), (1401, 33), (1403, 35), (1434, 63), (1488, 181), (1489, 101), (1491, 5), (1497, 277), (1498, 31), (1523, 38), (1537, 55), (1559, 90), (1572, 57), (1576, 5)]
def cs613 : List ℕ := [253, 512, 55, 417, 405, 415, 0, 999, 333, 405, 484, 667, 999, 496, 33, 218, 999, 1000, 1000, 56, 1000, 441, 200, 999, 1000, 999, 999, 1000, 180, 387, 1000, 1001, 603, 0, 1000, 775, 1000, 0, 999, 1000, 999, 858, 375, 931, 1001, 998, 1001, 1840, 850, 883, 999, 998, 357, 1000, 231, 1001, 999, 1000, 1000, 1000, 998, 1000, 961, 999, 962, 920, 1000, 154, 999, 1000, 1000, 1000, 1000, 1001, 761, 883, 292, 1000, 999, 1000, 998, 1000, 1001, 1000, 895, 1002, 0, 1000, 999, 1000, 1001, 553, 640, 2382, 543, 698, 785, 1000, 999, 1001, 1001, 1000, 834, 1000, 288, 1001, 999, 1001, 999, 250, 1001, 1001, 999, 999, 893, 1809, 1000, 184, 1001, 436, 1000, 1000, 1001, 1000, 999, 944, 1637, 1000, 999, 1000, 999, 884, 1000, 999, 1000, 999, 724, 737, 999, 1000, 999, 1000, 665, 1000, 950, 565, 852, 735, 941, 861, 999, 899, 665, 780]
theorem loads613 : cs613.get =
    load (fun i : Fin entries613.length => support (entries613.get i).1)
      (fun i => (entries613.get i).2) := by
  apply load_eq_of_sparse_packed base cs613 support code
    entries613 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node613 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 115 (insert 47 (insert 95 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs613 support demand
    entries613 ((insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 93 (insert 115 (insert 47 (insert 95 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154)) 1000 30 loads613
  decide +kernel
def entries614 : List (Fin 1589 × ℕ) := [(7, 10), (20, 41), (35, 17), (70, 3), (77, 15), (179, 3), (315, 21), (343, 3), (472, 22), (479, 15), (506, 33), (507, 2), (515, 14), (531, 10), (542, 4), (551, 13), (552, 1), (572, 5), (583, 8), (625, 9), (639, 6), (679, 4), (737, 3), (739, 2), (741, 36), (819, 8), (843, 25), (856, 21), (863, 5), (868, 19), (870, 30), (871, 4), (872, 9), (882, 22), (886, 3), (890, 11), (906, 20), (921, 22), (923, 6), (925, 5), (928, 4), (929, 7), (930, 3), (938, 2), (943, 9), (952, 1), (966, 3), (973, 48), (984, 22), (1004, 13), (1022, 1), (1031, 13), (1042, 15), (1044, 19), (1047, 3), (1049, 8), (1067, 1), (1089, 8), (1090, 8), (1111, 17), (1120, 18), (1122, 5), (1123, 11), (1142, 4), (1143, 16), (1173, 24), (1182, 8), (1183, 16), (1184, 4), (1186, 27), (1188, 32), (1219, 19), (1226, 13), (1263, 18), (1266, 16), (1268, 8), (1275, 10), (1281, 8), (1342, 30), (1358, 33), (1497, 11), (1523, 10), (1572, 1), (1580, 2)]
def cs614 : List ℕ := [41, 29, 30, 68, 27, 38, 0, 99, 76, 40, 51, 90, 99, 101, 24, 36, 99, 100, 100, 13, 99, 50, 3, 99, 99, 100, 100, 100, 24, 64, 99, 101, 46, 0, 100, 100, 100, 0, 66, 99, 100, 101, 53, 72, 99, 101, 100, 165, 78, 93, 79, 101, 12, 99, 24, 100, 101, 100, 100, 100, 102, 100, 55, 100, 88, 101, 100, 26, 101, 100, 101, 100, 101, 89, 84, 83, 45, 88, 99, 99, 100, 101, 45, 101, 78, 100, 0, 100, 101, 99, 100, 83, 93, 0, 50, 63, 65, 100, 100, 101, 100, 99, 101, 100, 33, 100, 101, 99, 100, 40, 101, 100, 100, 100, 101, 131, 101, 58, 100, 48, 100, 99, 100, 100, 101, 83, 144, 101, 100, 100, 98, 95, 100, 100, 89, 100, 73, 64, 100, 100, 100, 91, 84, 101, 101, 66, 100, 100, 95, 99, 97, 101, 87, 101]
theorem loads614 : cs614.get =
    load (fun i : Fin entries614.length => support (entries614.get i).1)
      (fun i => (entries614.get i).2) := by
  apply load_eq_of_sparse_packed base cs614 support code
    entries614 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node614 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 115 (insert 47 (insert 95 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs614 support demand
    entries614 ((insert 93 (insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 115 (insert 47 (insert 95 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)) 100 30 loads614
  decide +kernel
theorem node611 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 115 (insert 47 (insert 95 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 115 (insert 47 (insert 95 (insert 104 (insert 126 ∅))))) : Finset (Fin 154))
    93 node613 node614
def entries612 : List (Fin 1589 × ℕ) := [(20, 323), (35, 229), (77, 152), (86, 101), (122, 6), (179, 77), (315, 140), (323, 17), (343, 5), (344, 12), (440, 103), (466, 37), (472, 101), (479, 331), (506, 119), (507, 165), (527, 173), (551, 298), (571, 21), (572, 70), (681, 123), (717, 204), (730, 60), (739, 81), (741, 44), (843, 46), (856, 29), (863, 223), (868, 207), (870, 331), (872, 77), (882, 133), (886, 101), (896, 24), (906, 87), (920, 161), (921, 175), (927, 21), (928, 105), (939, 168), (952, 88), (973, 490), (984, 152), (1006, 22), (1031, 176), (1043, 171), (1045, 4), (1049, 32), (1061, 135), (1075, 148), (1076, 2), (1078, 4), (1114, 168), (1120, 186), (1121, 18), (1122, 163), (1123, 13), (1137, 171), (1169, 10), (1173, 306), (1183, 204), (1186, 36), (1188, 259), (1219, 245), (1226, 146), (1227, 189), (1234, 41), (1246, 38), (1261, 114), (1268, 42), (1275, 161), (1277, 110), (1292, 119), (1298, 173), (1320, 16), (1342, 128), (1358, 286), (1390, 105), (1403, 335), (1469, 31), (1498, 111), (1572, 11)]
def cs612 : List ℕ := [323, 245, 101, 568, 331, 488, 0, 1000, 552, 507, 478, 1000, 1000, 671, 152, 548, 1000, 1000, 871, 133, 999, 219, 77, 1000, 1000, 999, 1000, 1000, 189, 629, 1000, 999, 395, 10, 1000, 1000, 1000, 0, 874, 999, 966, 880, 519, 748, 998, 1000, 966, 1793, 786, 915, 1000, 1001, 290, 999, 306, 1000, 1000, 1000, 1001, 999, 1000, 1001, 887, 1000, 844, 999, 1000, 238, 1000, 1000, 1000, 1000, 1000, 1001, 795, 998, 405, 1000, 999, 999, 1001, 1000, 963, 1001, 903, 916, 0, 999, 1001, 999, 1000, 777, 784, 1000, 350, 190, 801, 1001, 1000, 1000, 1001, 999, 1001, 1000, 520, 963, 1000, 703, 1000, 36, 999, 1000, 1000, 1001, 999, 46, 1000, 240, 1000, 490, 1000, 1001, 1001, 887, 1000, 999, 876, 1000, 969, 1001, 716, 671, 1000, 1000, 486, 1001, 978, 999, 1001, 1000, 995, 839, 881, 948, 586, 676, 1000, 707, 1001, 1000, 994, 687, 542, 1001]
theorem loads612 : cs612.get =
    load (fun i : Fin entries612.length => support (entries612.get i).1)
      (fun i => (entries612.get i).2) := by
  apply load_eq_of_sparse_packed base cs612 support code
    entries612 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node612 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 115 (insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 95 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs612 support demand
    entries612 ((insert 115 (insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 95 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)) 1000 30 loads612
  decide +kernel
theorem node607 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 95 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 47 (insert 95 (insert 104 (insert 126 ∅)))) : Finset (Fin 154))
    115 node611 node612
def entries609 : List (Fin 1589 × ℕ) := [(7, 4), (20, 33), (37, 24), (77, 41), (86, 3), (96, 7), (122, 20), (179, 3), (216, 7), (360, 1), (421, 4), (440, 3), (472, 13), (494, 8), (507, 13), (531, 17), (542, 25), (552, 7), (572, 18), (577, 23), (583, 2), (585, 7), (625, 12), (730, 12), (737, 13), (739, 5), (797, 20), (798, 9), (843, 14), (846, 7), (849, 1), (853, 6), (870, 33), (872, 10), (882, 11), (886, 15), (922, 14), (924, 12), (925, 28), (939, 11), (940, 16), (946, 16), (948, 6), (949, 6), (952, 21), (973, 53), (984, 7), (1005, 25), (1031, 23), (1034, 6), (1049, 1), (1061, 8), (1076, 25), (1090, 16), (1114, 15), (1119, 21), (1120, 2), (1121, 12), (1123, 15), (1142, 22), (1143, 4), (1159, 13), (1162, 1), (1172, 6), (1173, 25), (1181, 7), (1186, 7), (1188, 23), (1219, 18), (1236, 34), (1261, 14), (1275, 10), (1354, 4), (1370, 9), (1400, 20), (1469, 4), (1488, 5), (1497, 15), (1500, 13), (1523, 7), (1537, 20), (1555, 5)]
def cs609 : List ℕ := [34, 29, 33, 52, 38, 84, 0, 100, 77, 13, 41, 88, 99, 91, 66, 38, 100, 99, 99, 42, 100, 33, 3, 100, 87, 100, 98, 99, 77, 36, 100, 101, 53, 0, 98, 100, 101, 0, 68, 99, 101, 100, 32, 80, 98, 100, 101, 0, 92, 100, 100, 99, 37, 98, 31, 100, 100, 100, 100, 60, 99, 100, 87, 93, 99, 65, 99, 7, 101, 100, 99, 100, 62, 101, 74, 59, 52, 97, 100, 100, 99, 100, 101, 99, 55, 100, 0, 100, 100, 100, 101, 99, 99, 101, 78, 51, 101, 98, 100, 101, 100, 99, 100, 81, 26, 100, 99, 84, 99, 14, 100, 100, 99, 98, 100, 100, 100, 12, 99, 53, 100, 99, 99, 100, 99, 99, 141, 100, 100, 100, 100, 74, 98, 99, 62, 100, 78, 90, 217, 100, 99, 99, 84, 100, 97, 63, 99, 82, 99, 100, 99, 74, 81, 75]
theorem loads609 : cs609.get =
    load (fun i : Fin entries609.length => support (entries609.get i).1)
      (fun i => (entries609.get i).2) := by
  apply load_eq_of_sparse_packed base cs609 support code
    entries609 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node609 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 138 (insert 95 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs609 support demand
    entries609 ((insert 47 (insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 138 (insert 95 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)) 100 30 loads609
  decide +kernel
def entries610 : List (Fin 1589 × ℕ) := [(7, 5), (20, 28), (37, 29), (77, 40), (96, 12), (122, 16), (179, 6), (343, 7), (360, 14), (472, 25), (494, 6), (507, 16), (527, 15), (531, 16), (542, 29), (552, 12), (572, 20), (577, 14), (583, 17), (585, 9), (625, 14), (639, 4), (730, 1), (731, 15), (737, 20), (739, 2), (741, 1), (798, 14), (843, 14), (853, 12), (870, 33), (872, 8), (882, 10), (886, 6), (905, 6), (906, 1), (920, 2), (922, 10), (923, 11), (924, 5), (925, 21), (939, 13), (940, 15), (943, 4), (947, 12), (948, 5), (952, 21), (973, 36), (978, 9), (984, 13), (1031, 22), (1043, 12), (1061, 2), (1075, 4), (1078, 17), (1090, 7), (1120, 38), (1122, 42), (1137, 11), (1143, 1), (1153, 21), (1154, 5), (1167, 1), (1172, 1), (1173, 25), (1186, 19), (1188, 20), (1219, 24), (1226, 13), (1236, 27), (1247, 20), (1263, 2), (1272, 3), (1293, 20), (1358, 6), (1370, 15), (1400, 3), (1403, 1), (1497, 25), (1537, 12)]
def cs610 : List ℕ := [33, 29, 37, 52, 32, 80, 0, 100, 71, 16, 40, 90, 101, 81, 69, 38, 100, 100, 100, 49, 100, 49, 6, 100, 99, 100, 100, 101, 70, 34, 100, 100, 53, 1, 100, 100, 100, 0, 75, 100, 100, 86, 23, 96, 100, 100, 100, 0, 85, 99, 100, 101, 55, 100, 26, 99, 99, 100, 101, 55, 100, 101, 59, 100, 100, 90, 101, 1, 99, 100, 101, 100, 41, 100, 79, 44, 33, 61, 100, 100, 97, 100, 99, 99, 55, 100, 0, 99, 101, 99, 100, 60, 101, 99, 68, 61, 91, 100, 100, 99, 100, 99, 100, 68, 37, 99, 100, 100, 99, 23, 99, 99, 100, 100, 88, 99, 99, 24, 99, 36, 100, 94, 100, 99, 99, 99, 132, 100, 100, 100, 99, 74, 99, 100, 99, 92, 73, 75, 36, 100, 70, 61, 66, 99, 94, 74, 61, 95, 78, 100, 36, 56, 81, 55]
theorem loads610 : cs610.get =
    load (fun i : Fin entries610.length => support (entries610.get i).1)
      (fun i => (entries610.get i).2) := by
  apply load_eq_of_sparse_packed base cs610 support code
    entries610 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node610 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 138 (insert 47 (insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs610 support demand
    entries610 ((insert 138 (insert 47 (insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 95 (insert 104 (insert 126 ∅))) : Finset (Fin 154)) 100 30 loads610
  decide +kernel
theorem node608 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 95 (insert 104 (insert 126 ∅))) : Finset (Fin 154))
    138 node609 node610
theorem node606 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 95 (insert 104 (insert 126 ∅))) : Finset (Fin 154))
    47 node607 node608
theorem node604 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 86 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 95 (insert 104 (insert 126 ∅))) : Finset (Fin 154))
    67 node605 node606
#print axioms node604
end OmissionResidualCover
