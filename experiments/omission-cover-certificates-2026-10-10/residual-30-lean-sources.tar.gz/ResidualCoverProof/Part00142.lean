import ResidualCoverProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries467 : List (Fin 1589 × ℕ) := [(35, 24), (37, 55), (46, 88), (75, 244), (86, 88), (177, 69), (179, 47), (203, 14), (387, 156), (479, 238), (507, 304), (526, 77), (551, 360), (572, 72), (585, 10), (617, 304), (639, 29), (730, 273), (736, 137), (737, 199), (740, 102), (798, 455), (813, 248), (814, 1), (819, 30), (834, 109), (835, 437), (843, 25), (846, 259), (856, 19), (864, 72), (867, 30), (868, 15), (870, 175), (886, 268), (896, 91), (904, 93), (916, 10), (917, 73), (923, 69), (925, 119), (930, 477), (940, 511), (944, 51), (952, 176), (958, 26), (973, 402), (984, 80), (985, 69), (1006, 453), (1012, 336), (1019, 48), (1031, 459), (1033, 22), (1049, 7), (1055, 5), (1061, 7), (1077, 55), (1081, 120), (1093, 240), (1103, 358), (1114, 271), (1123, 73), (1159, 122), (1160, 149), (1169, 5), (1173, 76), (1181, 240), (1183, 7), (1212, 194), (1220, 365), (1234, 351), (1241, 84), (1261, 49), (1263, 172), (1267, 275), (1292, 69), (1358, 138), (1360, 41), (1419, 120), (1498, 160), (1517, 25)]
def cs467 : List ℕ := [503, 624, 0, 365, 238, 447, 113, 1000, 371, 376, 478, 791, 1000, 144, 332, 640, 1000, 1000, 1000, 127, 762, 1000, 116, 1001, 1000, 998, 1000, 1867, 275, 472, 1000, 1000, 677, 5, 999, 1001, 999, 55, 999, 1000, 1000, 820, 411, 851, 999, 999, 1001, 1846, 740, 999, 1001, 1000, 935, 1000, 76, 999, 1000, 1000, 1000, 1000, 1000, 1000, 966, 1000, 1000, 982, 999, 1000, 1000, 1000, 1000, 979, 999, 978, 749, 1000, 72, 1000, 1000, 999, 1477, 999, 754, 1000, 911, 1000, 961, 999, 1000, 1000, 999, 1000, 1000, 2757, 365, 464, 1000, 2143, 1000, 999, 1000, 999, 1000, 999, 387, 1000, 1000, 999, 1000, 475, 940, 1000, 1555, 1000, 1000, 710, 999, 278, 1000, 760, 999, 1000, 717, 999, 1760, 936, 402, 2406, 926, 999, 999, 407, 1000, 1000, 833, 999, 478, 1214, 999, 999, 999, 845, 692, 999, 851, 1000, 763, 601, 927, 943, 1000, 637, 999, 877]
theorem loads467 : cs467.get =
    load (fun i : Fin entries467.length => support (entries467.get i).1)
      (fun i => (entries467.get i).2) := by
  apply load_eq_of_sparse_packed base cs467 support code
    entries467 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node467 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 80 (insert 27 (insert 112 (insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs467 support demand
    entries467 ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 80 (insert 27 (insert 112 (insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))))))) : Finset (Fin 154)) 1000 30 loads467
  decide +kernel
def entries468 : List (Fin 1589 × ℕ) := [(20, 2), (35, 6), (46, 18), (179, 15), (205, 10), (315, 11), (387, 18), (479, 29), (507, 41), (515, 10), (541, 7), (550, 13), (551, 9), (571, 4), (616, 3), (678, 10), (736, 5), (737, 27), (740, 5), (798, 39), (813, 8), (834, 15), (835, 47), (846, 20), (856, 26), (868, 7), (870, 20), (886, 29), (893, 12), (894, 2), (895, 11), (905, 5), (920, 3), (924, 10), (925, 2), (927, 19), (940, 62), (944, 10), (950, 17), (973, 39), (984, 16), (985, 5), (1004, 2), (1006, 43), (1012, 28), (1019, 3), (1031, 29), (1049, 15), (1055, 12), (1061, 2), (1081, 3), (1093, 27), (1103, 30), (1107, 2), (1111, 6), (1114, 19), (1123, 7), (1159, 5), (1160, 19), (1161, 4), (1167, 1), (1173, 13), (1181, 27), (1212, 14), (1220, 39), (1227, 36), (1234, 19), (1241, 7), (1263, 13), (1267, 8), (1292, 10), (1320, 6), (1358, 11), (1360, 9), (1491, 13), (1588, 13)]
def cs468 : List ℕ := [50, 59, 0, 41, 29, 42, 18, 99, 21, 41, 27, 70, 99, 8, 25, 35, 99, 100, 100, 4, 84, 100, 15, 99, 101, 99, 84, 176, 8, 41, 99, 99, 79, 1, 100, 60, 100, 0, 99, 100, 85, 83, 31, 76, 101, 99, 99, 173, 34, 100, 99, 99, 90, 100, 13, 100, 100, 99, 97, 99, 99, 100, 92, 99, 64, 79, 100, 101, 99, 99, 100, 100, 99, 83, 68, 100, 0, 100, 100, 100, 19, 100, 101, 100, 61, 101, 52, 99, 100, 101, 100, 99, 76, 286, 62, 33, 101, 201, 100, 100, 99, 100, 100, 100, 28, 99, 99, 101, 100, 50, 101, 100, 91, 100, 100, 85, 100, 24, 100, 69, 95, 101, 57, 100, 186, 96, 39, 241, 78, 100, 101, 40, 100, 100, 93, 100, 52, 115, 101, 100, 100, 101, 63, 101, 100, 100, 73, 60, 97, 85, 100, 66, 100, 88]
theorem loads468 : cs468.get =
    load (fun i : Fin entries468.length => support (entries468.get i).1)
      (fun i => (entries468.get i).2) := by
  apply load_eq_of_sparse_packed base cs468 support code
    entries468 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node468 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 80 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 112 (insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs468 support demand
    entries468 ((insert 80 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 112 (insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))))) : Finset (Fin 154)) 100 30 loads468
  decide +kernel
theorem node465 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 112 (insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 27 (insert 112 (insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))))) : Finset (Fin 154))
    80 node467 node468
def entries466 : List (Fin 1589 × ℕ) := [(7, 39), (35, 12), (46, 18), (122, 3), (179, 14), (387, 13), (439, 4), (466, 6), (472, 17), (479, 23), (496, 3), (497, 3), (498, 12), (506, 1), (507, 40), (515, 6), (541, 7), (570, 20), (624, 18), (673, 11), (737, 12), (740, 2), (798, 43), (813, 19), (819, 13), (834, 6), (835, 46), (843, 4), (856, 30), (868, 27), (869, 9), (870, 23), (872, 2), (886, 17), (904, 4), (905, 14), (906, 16), (916, 1), (917, 10), (918, 5), (920, 14), (924, 3), (925, 8), (927, 2), (930, 29), (936, 7), (940, 47), (944, 3), (952, 15), (973, 40), (978, 1), (984, 8), (1004, 4), (1006, 39), (1012, 32), (1019, 6), (1021, 1), (1031, 26), (1038, 6), (1040, 3), (1045, 5), (1049, 7), (1055, 13), (1077, 1), (1081, 7), (1093, 23), (1101, 5), (1103, 41), (1114, 16), (1123, 18), (1159, 10), (1160, 10), (1167, 6), (1173, 14), (1181, 19), (1186, 3), (1212, 6), (1220, 4), (1232, 3), (1234, 55), (1241, 9), (1339, 1), (1356, 6), (1358, 40), (1360, 21), (1525, 9), (1576, 5)]
def cs466 : List ℕ := [50, 43, 32, 4, 68, 42, 18, 99, 30, 50, 42, 82, 98, 59, 25, 3, 99, 100, 76, 0, 99, 66, 14, 98, 101, 100, 100, 4, 26, 44, 99, 101, 61, 6, 100, 100, 100, 0, 100, 100, 75, 81, 13, 100, 101, 99, 100, 169, 77, 100, 99, 100, 44, 100, 14, 100, 100, 100, 100, 99, 100, 100, 101, 100, 84, 100, 99, 101, 99, 100, 100, 100, 101, 85, 100, 100, 0, 101, 100, 99, 100, 100, 100, 101, 97, 100, 82, 100, 100, 99, 99, 100, 63, 266, 42, 57, 101, 165, 100, 99, 98, 100, 100, 101, 32, 101, 100, 99, 98, 49, 100, 100, 138, 99, 101, 65, 99, 12, 100, 89, 101, 99, 58, 100, 180, 100, 40, 272, 101, 98, 100, 46, 100, 99, 93, 99, 54, 122, 99, 98, 99, 95, 64, 99, 96, 100, 72, 55, 81, 79, 95, 73, 99, 92]
theorem loads466 : cs466.get =
    load (fun i : Fin entries466.length => support (entries466.get i).1)
      (fun i => (entries466.get i).2) := by
  apply load_eq_of_sparse_packed base cs466 support code
    entries466 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node466 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 27 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 112 (insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs466 support demand
    entries466 ((insert 27 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 112 (insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))))) : Finset (Fin 154)) 100 30 loads466
  decide +kernel
theorem node463 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 112 (insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 112 (insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))))) : Finset (Fin 154))
    27 node465 node466
def entries464 : List (Fin 1589 × ℕ) := [(7, 15), (46, 33), (179, 24), (384, 18), (439, 5), (469, 6), (479, 25), (498, 1), (507, 36), (515, 5), (551, 12), (572, 15), (617, 13), (678, 8), (679, 14), (731, 12), (736, 18), (737, 12), (738, 2), (798, 47), (815, 14), (833, 2), (835, 35), (856, 27), (868, 19), (869, 1), (870, 13), (872, 6), (886, 29), (895, 15), (904, 2), (905, 7), (906, 21), (920, 7), (922, 2), (925, 13), (927, 20), (928, 9), (935, 2), (937, 6), (940, 58), (944, 4), (952, 5), (963, 2), (973, 36), (978, 4), (984, 17), (1004, 2), (1006, 43), (1012, 28), (1019, 9), (1031, 27), (1034, 1), (1049, 3), (1055, 7), (1061, 1), (1077, 1), (1081, 10), (1103, 30), (1110, 1), (1113, 2), (1114, 24), (1122, 8), (1123, 36), (1159, 27), (1161, 12), (1173, 21), (1180, 5), (1181, 12), (1212, 1), (1220, 33), (1241, 11), (1267, 21), (1276, 5), (1285, 7), (1292, 8), (1320, 4), (1342, 19), (1358, 24), (1360, 15), (1403, 6), (1525, 2), (1559, 14), (1570, 6), (1580, 10)]
def cs464 : List ℕ := [57, 54, 2, 40, 50, 35, 33, 100, 8, 38, 34, 84, 100, 38, 43, 12, 101, 99, 100, 15, 101, 90, 24, 100, 101, 100, 101, 100, 41, 57, 100, 99, 51, 0, 99, 101, 102, 0, 100, 99, 101, 90, 23, 88, 99, 100, 100, 170, 69, 101, 99, 101, 87, 99, 21, 99, 101, 100, 102, 100, 99, 102, 100, 101, 90, 82, 99, 99, 100, 100, 100, 100, 101, 99, 88, 100, 0, 100, 99, 99, 102, 100, 95, 101, 69, 100, 55, 99, 100, 100, 99, 100, 79, 273, 12, 27, 99, 140, 100, 99, 100, 100, 101, 101, 37, 99, 100, 99, 100, 35, 100, 98, 0, 99, 100, 64, 100, 5, 100, 66, 101, 99, 53, 100, 151, 100, 36, 245, 100, 98, 100, 36, 100, 100, 84, 99, 57, 109, 100, 100, 100, 99, 49, 100, 100, 95, 71, 37, 82, 82, 100, 69, 100, 68]
theorem loads464 : cs464.get =
    load (fun i : Fin entries464.length => support (entries464.get i).1)
      (fun i => (entries464.get i).2) := by
  apply load_eq_of_sparse_packed base cs464 support code
    entries464 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node464 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 112 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs464 support demand
    entries464 ((insert 112 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154)) 100 30 loads464
  decide +kernel
theorem node459 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 97 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154))
    112 node463 node464
def entries461 : List (Fin 1589 × ℕ) := [(7, 4), (35, 28), (46, 38), (86, 9), (179, 3), (203, 2), (439, 16), (466, 47), (472, 7), (479, 22), (507, 29), (527, 3), (531, 3), (570, 37), (617, 22), (624, 2), (639, 6), (673, 7), (680, 13), (739, 37), (797, 9), (798, 34), (815, 10), (819, 5), (842, 18), (843, 5), (844, 2), (856, 3), (863, 7), (868, 6), (869, 2), (870, 21), (881, 26), (886, 1), (896, 36), (905, 5), (906, 26), (920, 31), (924, 15), (925, 20), (927, 29), (936, 7), (940, 35), (944, 9), (946, 11), (952, 17), (957, 1), (973, 28), (978, 9), (984, 20), (985, 15), (1004, 22), (1006, 41), (1031, 29), (1045, 2), (1049, 6), (1055, 14), (1061, 2), (1081, 24), (1093, 11), (1100, 2), (1114, 13), (1122, 8), (1123, 29), (1146, 2), (1159, 6), (1161, 28), (1173, 14), (1212, 2), (1220, 16), (1222, 1), (1234, 54), (1267, 14), (1268, 7), (1269, 4), (1275, 19), (1277, 18), (1292, 23), (1358, 4), (1360, 21), (1393, 8), (1544, 1), (1548, 2), (1575, 7)]
def cs461 : List ℕ := [69, 21, 8, 16, 26, 55, 38, 99, 28, 36, 29, 100, 99, 42, 38, 34, 99, 101, 99, 7, 99, 100, 3, 99, 100, 99, 99, 100, 31, 69, 100, 100, 64, 2, 101, 98, 101, 0, 100, 101, 92, 89, 39, 100, 101, 99, 100, 191, 75, 100, 100, 101, 72, 100, 15, 99, 99, 100, 101, 100, 99, 100, 100, 101, 100, 100, 100, 100, 101, 222, 100, 100, 99, 101, 59, 100, 11, 94, 100, 101, 101, 99, 87, 96, 89, 95, 76, 100, 100, 101, 85, 100, 101, 254, 90, 68, 101, 0, 100, 100, 100, 100, 76, 100, 49, 87, 100, 101, 101, 27, 100, 100, 100, 41, 100, 37, 101, 12, 100, 28, 78, 101, 83, 100, 151, 83, 28, 240, 82, 101, 100, 28, 99, 100, 54, 100, 42, 101, 100, 100, 101, 100, 34, 100, 100, 56, 50, 30, 99, 57, 100, 100, 61, 88]
theorem loads461 : cs461.get =
    load (fun i : Fin entries461.length => support (entries461.get i).1)
      (fun i => (entries461.get i).2) := by
  apply load_eq_of_sparse_packed base cs461 support code
    entries461 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node461 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 97 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs461 support demand
    entries461 ((insert 97 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154)) 100 30 loads461
  decide +kernel
def entries462 : List (Fin 1589 × ℕ) := [(7, 11), (46, 2), (122, 7), (177, 12), (179, 15), (384, 19), (419, 1), (439, 33), (479, 50), (507, 54), (552, 4), (572, 4), (583, 15), (625, 10), (681, 41), (739, 27), (798, 34), (815, 20), (842, 25), (849, 8), (856, 21), (868, 27), (869, 8), (870, 13), (886, 21), (893, 14), (906, 18), (920, 10), (921, 1), (922, 1), (924, 2), (925, 5), (928, 5), (930, 6), (936, 43), (940, 29), (944, 16), (951, 8), (952, 11), (973, 35), (978, 18), (984, 7), (1004, 10), (1006, 38), (1012, 29), (1031, 26), (1049, 19), (1055, 12), (1061, 1), (1077, 16), (1081, 5), (1094, 7), (1100, 12), (1114, 10), (1123, 36), (1159, 31), (1161, 26), (1167, 2), (1173, 15), (1186, 13), (1212, 12), (1220, 38), (1232, 3), (1234, 21), (1277, 8), (1292, 16), (1358, 12), (1420, 13), (1490, 3), (1496, 8), (1498, 5)]
def cs462 : List ℕ := [50, 49, 0, 46, 61, 42, 2, 100, 0, 54, 51, 71, 100, 11, 2, 19, 100, 100, 100, 4, 101, 62, 27, 100, 100, 100, 100, 100, 30, 29, 100, 101, 77, 2, 100, 66, 100, 0, 100, 100, 98, 72, 30, 77, 100, 100, 100, 167, 55, 99, 100, 101, 49, 100, 15, 100, 100, 101, 92, 100, 100, 79, 100, 101, 54, 82, 101, 100, 99, 21, 101, 100, 100, 100, 67, 100, 0, 81, 100, 100, 100, 101, 92, 100, 84, 100, 49, 100, 100, 100, 101, 100, 62, 188, 60, 28, 100, 0, 100, 99, 101, 100, 100, 85, 34, 73, 100, 100, 100, 25, 100, 100, 101, 37, 100, 68, 100, 41, 100, 38, 85, 101, 91, 100, 140, 90, 35, 229, 77, 75, 100, 37, 100, 101, 48, 101, 50, 117, 101, 100, 92, 100, 52, 100, 100, 61, 77, 62, 84, 85, 101, 89, 91, 71]
theorem loads462 : cs462.get =
    load (fun i : Fin entries462.length => support (entries462.get i).1)
      (fun i => (entries462.get i).2) := by
  apply load_eq_of_sparse_packed base cs462 support code
    entries462 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node462 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 69 (insert 97 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs462 support demand
    entries462 ((insert 69 (insert 97 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)) 100 30 loads462
  decide +kernel
theorem node460 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 97 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 97 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154))
    69 node461 node462
theorem node453 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 124 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154))
    97 node459 node460
def entries457 : List (Fin 1589 × ℕ) := [(86, 198), (137, 27), (179, 246), (384, 69), (439, 181), (479, 291), (496, 12), (507, 397), (515, 63), (527, 58), (531, 3), (572, 39), (617, 182), (731, 58), (737, 47), (738, 84), (739, 115), (740, 20), (797, 151), (813, 99), (815, 158), (833, 143), (844, 161), (853, 50), (863, 103), (868, 116), (870, 205), (872, 117), (881, 236), (882, 46), (885, 83), (886, 151), (896, 141), (904, 149), (906, 178), (920, 113), (922, 44), (924, 183), (925, 86), (927, 32), (928, 118), (930, 105), (940, 423), (952, 197), (958, 470), (963, 113), (966, 36), (973, 348), (984, 193), (985, 60), (1004, 22), (1012, 270), (1031, 162), (1047, 79), (1049, 69), (1076, 162), (1077, 15), (1081, 138), (1094, 197), (1100, 297), (1101, 18), (1103, 292), (1114, 31), (1123, 262), (1128, 227), (1147, 20), (1161, 337), (1167, 258), (1169, 39), (1171, 8), (1173, 60), (1180, 23), (1186, 71), (1220, 178), (1234, 498), (1267, 263), (1268, 5), (1292, 112), (1308, 20), (1335, 193), (1344, 143), (1358, 223), (1498, 86), (1525, 77), (1580, 71)]
def cs457 : List ℕ := [562, 178, 77, 178, 362, 248, 0, 1001, 12, 577, 368, 804, 880, 196, 71, 368, 1000, 1000, 1001, 44, 1001, 404, 246, 1000, 999, 1000, 1001, 1000, 263, 246, 1001, 1000, 829, 466, 1000, 1001, 999, 0, 999, 1000, 983, 700, 85, 1000, 1000, 1000, 1001, 1814, 802, 999, 1000, 1000, 1000, 1001, 68, 999, 999, 999, 999, 1000, 1000, 1000, 1000, 1000, 779, 1000, 1000, 1000, 999, 1000, 999, 1413, 1000, 1000, 588, 1001, 0, 846, 1000, 1973, 1000, 999, 952, 968, 999, 850, 872, 1000, 1000, 1000, 1000, 893, 1000, 2795, 402, 538, 1000, 1000, 1000, 1000, 999, 1000, 1000, 1000, 319, 1000, 1000, 1000, 998, 227, 1000, 1001, 999, 1001, 1000, 919, 999, 577, 1000, 658, 999, 1000, 902, 1000, 71, 713, 348, 2252, 1000, 1001, 1000, 645, 1000, 1000, 727, 923, 416, 1261, 1000, 1000, 94, 1001, 1000, 646, 353, 1000, 906, 716, 901, 938, 1000, 779, 632, 419]
theorem loads457 : cs457.get =
    load (fun i : Fin entries457.length => support (entries457.get i).1)
      (fun i => (entries457.get i).2) := by
  apply load_eq_of_sparse_packed base cs457 support code
    entries457 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node457 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 124 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 79 (insert 71 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs457 support demand
    entries457 ((insert 124 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 79 (insert 71 (insert 93 (insert 47 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154)) 1000 30 loads457
  decide +kernel
def entries458 : List (Fin 1589 × ℕ) := [(10, 20), (20, 1), (43, 5), (46, 25), (137, 7), (179, 20), (314, 11), (387, 12), (439, 9), (466, 3), (479, 21), (483, 2), (497, 5), (507, 48), (551, 2), (616, 7), (617, 20), (639, 2), (737, 13), (739, 6), (742, 5), (797, 43), (813, 24), (815, 2), (833, 12), (844, 2), (847, 7), (856, 2), (868, 35), (869, 6), (870, 11), (872, 17), (886, 16), (894, 2), (895, 2), (896, 2), (906, 35), (916, 13), (924, 13), (925, 27), (928, 11), (930, 19), (936, 36), (938, 2), (952, 23), (960, 2), (973, 19), (978, 23), (985, 11), (1004, 5), (1006, 16), (1012, 32), (1019, 18), (1031, 39), (1049, 17), (1076, 25), (1081, 10), (1094, 22), (1100, 19), (1103, 37), (1108, 17), (1123, 21), (1128, 24), (1161, 44), (1173, 10), (1220, 27), (1232, 4), (1234, 30), (1263, 1), (1267, 42), (1299, 2), (1308, 3), (1312, 19), (1335, 33), (1344, 6), (1358, 33), (1403, 1), (1434, 1), (1491, 1), (1498, 12)]
def cs458 : List ℕ := [65, 27, 27, 28, 41, 16, 30, 93, 10, 48, 35, 80, 90, 39, 30, 15, 100, 100, 100, 0, 100, 101, 20, 100, 100, 100, 99, 100, 42, 51, 100, 100, 101, 2, 100, 100, 99, 0, 99, 100, 99, 53, 7, 87, 100, 100, 101, 179, 69, 99, 101, 100, 97, 100, 10, 100, 100, 100, 100, 100, 100, 100, 96, 100, 100, 100, 99, 100, 96, 100, 101, 161, 100, 100, 59, 99, 2, 100, 100, 11, 99, 99, 91, 100, 91, 99, 94, 100, 100, 100, 100, 90, 99, 249, 40, 46, 97, 99, 98, 100, 100, 99, 83, 98, 47, 101, 99, 100, 100, 0, 100, 100, 99, 100, 99, 37, 99, 0, 99, 60, 99, 99, 100, 100, 0, 45, 19, 264, 99, 100, 42, 19, 100, 99, 58, 86, 29, 120, 100, 100, 4, 100, 81, 60, 21, 100, 85, 36, 100, 86, 99, 67, 52, 23]
theorem loads458 : cs458.get =
    load (fun i : Fin entries458.length => support (entries458.get i).1)
      (fun i => (entries458.get i).2) := by
  apply load_eq_of_sparse_packed base cs458 support code
    entries458 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node458 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 79 (insert 124 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs458 support demand
    entries458 ((insert 79 (insert 124 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 71 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)) 100 30 loads458
  decide +kernel
theorem node455 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 124 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 124 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 71 (insert 93 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154))
    79 node457 node458
def entries456 : List (Fin 1589 × ℕ) := [(7, 142), (10, 109), (20, 16), (46, 44), (86, 49), (179, 298), (386, 86), (469, 128), (472, 166), (479, 287), (483, 146), (531, 111), (542, 246), (552, 317), (572, 105), (617, 63), (639, 104), (717, 178), (730, 95), (737, 136), (739, 164), (741, 23), (742, 85), (797, 144), (833, 286), (853, 266), (856, 56), (863, 203), (868, 222), (870, 321), (872, 7), (886, 156), (894, 46), (896, 105), (898, 46), (905, 118), (918, 23), (920, 5), (928, 143), (930, 52), (936, 197), (940, 343), (951, 41), (952, 165), (958, 146), (965, 212), (969, 46), (973, 334), (978, 155), (985, 77), (1004, 27), (1006, 247), (1012, 267), (1019, 66), (1031, 302), (1049, 196), (1055, 6), (1081, 90), (1100, 136), (1103, 211), (1108, 127), (1111, 26), (1114, 185), (1122, 147), (1123, 159), (1128, 182), (1161, 159), (1167, 136), (1172, 15), (1173, 9), (1181, 211), (1220, 138), (1232, 227), (1261, 60), (1268, 147), (1292, 113), (1295, 64), (1312, 507), (1335, 67), (1358, 281), (1403, 32), (1559, 35)]
def cs456 : List ℕ := [419, 408, 275, 154, 538, 581, 44, 1000, 16, 203, 335, 917, 1000, 532, 290, 317, 1000, 1001, 1000, 252, 1000, 446, 344, 1001, 988, 999, 999, 1000, 35, 358, 1000, 1001, 0, 136, 1000, 1001, 999, 46, 1000, 999, 999, 863, 522, 1000, 1001, 999, 1000, 1489, 935, 999, 1001, 1000, 637, 1000, 24, 1001, 999, 1001, 1000, 1000, 999, 1000, 1000, 1000, 745, 1000, 1000, 1000, 822, 1000, 1002, 0, 999, 1000, 688, 999, 0, 811, 1000, 1000, 1000, 1002, 1001, 1000, 999, 912, 330, 1000, 1000, 1000, 999, 860, 668, 2328, 283, 453, 1000, 1000, 999, 999, 1000, 999, 1000, 747, 268, 1000, 999, 999, 1000, 211, 999, 999, 824, 1000, 999, 1000, 1000, 404, 1000, 836, 952, 1000, 999, 999, 60, 741, 334, 2239, 792, 1000, 662, 485, 998, 998, 999, 625, 343, 1229, 764, 998, 498, 999, 779, 643, 370, 979, 773, 638, 998, 777, 998, 720, 612, 561]
theorem loads456 : cs456.get =
    load (fun i : Fin entries456.length => support (entries456.get i).1)
      (fun i => (entries456.get i).2) := by
  apply load_eq_of_sparse_packed base cs456 support code
    entries456 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node456 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 71 (insert 124 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs456 support demand
    entries456 ((insert 71 (insert 124 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 93 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)) 1000 30 loads456
  decide +kernel
theorem node454 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 124 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 124 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 93 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154))
    71 node455 node456
theorem node445 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 93 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154))
    124 node453 node454
def entries451 : List (Fin 1589 × ℕ) := [(10, 43), (77, 101), (122, 152), (177, 73), (419, 140), (466, 44), (472, 99), (479, 224), (507, 177), (515, 56), (531, 126), (551, 186), (552, 79), (583, 119), (617, 176), (640, 38), (672, 98), (673, 20), (681, 76), (731, 375), (737, 83), (813, 4), (814, 96), (815, 106), (819, 46), (843, 30), (856, 248), (863, 104), (868, 228), (869, 53), (870, 340), (871, 9), (882, 47), (886, 102), (894, 65), (904, 190), (906, 32), (921, 127), (925, 153), (928, 30), (929, 79), (934, 181), (938, 454), (944, 156), (952, 146), (973, 261), (978, 74), (984, 5), (985, 233), (1004, 34), (1006, 117), (1012, 383), (1031, 212), (1047, 121), (1055, 103), (1061, 9), (1076, 32), (1077, 31), (1081, 102), (1101, 91), (1103, 417), (1122, 203), (1123, 212), (1128, 87), (1137, 19), (1148, 27), (1159, 58), (1160, 325), (1161, 119), (1162, 203), (1167, 326), (1173, 224), (1186, 90), (1212, 117), (1220, 207), (1232, 154), (1246, 321), (1263, 246), (1266, 52), (1277, 52), (1280, 51), (1292, 39), (1358, 164), (1525, 147), (1580, 63), (1588, 116)]
def cs451 : List ℕ := [466, 258, 289, 207, 330, 338, 0, 999, 246, 428, 571, 859, 999, 241, 164, 464, 909, 1000, 884, 0, 999, 625, 73, 999, 1000, 999, 999, 1000, 253, 73, 999, 999, 477, 326, 999, 999, 999, 0, 680, 1000, 999, 889, 511, 957, 1001, 1000, 999, 1523, 921, 1000, 1000, 999, 119, 1000, 405, 1001, 1000, 999, 999, 999, 1000, 999, 583, 999, 998, 1000, 1000, 1001, 999, 999, 999, 1001, 1000, 1000, 831, 1707, 0, 593, 1000, 1000, 998, 1000, 460, 818, 772, 1000, 999, 999, 1000, 999, 1000, 999, 980, 0, 336, 757, 1000, 1000, 1000, 998, 1000, 1000, 999, 1000, 420, 1000, 1000, 999, 1000, 207, 834, 999, 877, 999, 1825, 687, 999, 363, 949, 923, 631, 1000, 999, 1000, 999, 974, 261, 2544, 888, 999, 1000, 633, 1000, 999, 1000, 999, 485, 1422, 999, 999, 999, 1000, 936, 999, 1000, 1000, 756, 840, 906, 779, 999, 741, 729, 999]
theorem loads451 : cs451.get =
    load (fun i : Fin entries451.length => support (entries451.get i).1)
      (fun i => (entries451.get i).2) := by
  apply load_eq_of_sparse_packed base cs451 support code
    entries451 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node451 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 114 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs451 support demand
    entries451 ((insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 75 (insert 114 (insert 47 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)) 1000 30 loads451
  decide +kernel
def entries452 : List (Fin 1589 × ℕ) := [(10, 21), (35, 21), (46, 40), (75, 7), (116, 8), (120, 1), (177, 32), (472, 5), (474, 2), (479, 18), (494, 14), (507, 11), (515, 12), (531, 7), (542, 26), (551, 18), (552, 3), (572, 4), (583, 9), (625, 8), (730, 3), (731, 47), (737, 19), (739, 9), (741, 30), (814, 8), (815, 19), (817, 10), (819, 7), (843, 17), (844, 6), (853, 9), (864, 20), (869, 1), (870, 37), (872, 12), (893, 5), (895, 8), (904, 6), (906, 15), (916, 1), (920, 9), (925, 18), (929, 16), (930, 30), (934, 5), (938, 14), (952, 34), (955, 3), (957, 5), (973, 30), (984, 17), (1004, 40), (1006, 22), (1031, 37), (1033, 12), (1076, 15), (1077, 18), (1081, 29), (1094, 16), (1103, 51), (1114, 24), (1122, 31), (1123, 9), (1160, 41), (1162, 17), (1167, 16), (1181, 1), (1186, 15), (1212, 14), (1217, 19), (1238, 13), (1241, 1), (1246, 7), (1268, 20), (1358, 25), (1489, 1), (1491, 1), (1498, 27), (1588, 1)]
def cs452 : List ℕ := [63, 0, 58, 2, 39, 76, 40, 100, 34, 31, 19, 97, 101, 81, 73, 58, 101, 100, 100, 24, 101, 99, 32, 101, 101, 100, 100, 101, 17, 100, 101, 100, 57, 22, 100, 100, 100, 0, 95, 100, 100, 62, 73, 100, 100, 99, 100, 136, 89, 100, 100, 101, 90, 100, 5, 100, 101, 101, 100, 100, 100, 100, 86, 82, 67, 100, 101, 101, 100, 100, 101, 99, 100, 100, 77, 0, 20, 92, 102, 99, 100, 99, 62, 99, 74, 87, 48, 101, 100, 100, 101, 100, 100, 0, 82, 53, 102, 99, 101, 80, 101, 100, 100, 101, 0, 101, 101, 100, 100, 33, 100, 101, 100, 101, 187, 45, 101, 34, 52, 81, 100, 101, 101, 101, 101, 68, 30, 291, 92, 101, 101, 46, 100, 101, 101, 101, 30, 119, 101, 101, 101, 77, 76, 101, 98, 99, 45, 75, 76, 83, 88, 59, 77, 101]
theorem loads452 : cs452.get =
    load (fun i : Fin entries452.length => support (entries452.get i).1)
      (fun i => (entries452.get i).2) := by
  apply load_eq_of_sparse_packed base cs452 support code
    entries452 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node452 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 75 (insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 114 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs452 support demand
    entries452 ((insert 75 (insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 114 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)) 100 30 loads452
  decide +kernel
theorem node447 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 114 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 114 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154))
    75 node451 node452
def entries449 : List (Fin 1589 × ℕ) := [(10, 40), (20, 257), (35, 98), (122, 235), (179, 274), (344, 20), (386, 103), (399, 8), (421, 77), (466, 2), (479, 207), (496, 53), (506, 10), (507, 302), (542, 81), (551, 94), (552, 77), (570, 110), (583, 226), (616, 153), (617, 51), (625, 197), (639, 335), (672, 26), (731, 154), (737, 73), (739, 160), (743, 90), (777, 13), (813, 186), (819, 16), (842, 182), (844, 148), (869, 187), (870, 214), (872, 47), (882, 4), (883, 81), (886, 125), (890, 37), (893, 88), (894, 1), (895, 112), (906, 240), (924, 26), (925, 23), (930, 247), (937, 94), (939, 93), (950, 75), (952, 153), (957, 93), (966, 23), (973, 338), (984, 103), (1003, 192), (1004, 236), (1006, 107), (1012, 323), (1028, 6), (1030, 166), (1049, 238), (1081, 112), (1093, 227), (1094, 8), (1103, 564), (1110, 28), (1149, 11), (1160, 263), (1161, 36), (1162, 61), (1167, 194), (1173, 203), (1182, 48), (1186, 202), (1188, 37), (1212, 197), (1217, 278), (1238, 207), (1246, 107), (1251, 37), (1252, 48), (1257, 69), (1263, 59), (1268, 206), (1342, 193), (1358, 112), (1496, 126), (1498, 24), (1525, 46)]
def cs449 : List ℕ := [747, 0, 571, 257, 247, 400, 0, 1000, 674, 358, 172, 1000, 883, 648, 81, 434, 1001, 1000, 999, 206, 1000, 798, 274, 999, 1000, 999, 999, 1000, 432, 629, 1815, 998, 557, 342, 1000, 998, 1001, 0, 821, 1000, 999, 999, 427, 999, 1000, 1001, 999, 1141, 1000, 1001, 1000, 999, 503, 1000, 203, 1000, 1001, 998, 999, 999, 1001, 999, 934, 998, 778, 1000, 1000, 1001, 1001, 999, 988, 1001, 1001, 1000, 616, 1000, 37, 948, 1000, 1001, 999, 1000, 759, 1001, 1000, 1000, 868, 1001, 1000, 1000, 1000, 1000, 735, 0, 989, 657, 1000, 1000, 1001, 1000, 1001, 999, 999, 999, 492, 980, 1001, 1000, 1000, 399, 742, 999, 999, 1000, 242, 949, 1000, 563, 659, 1153, 1000, 1000, 1000, 780, 1001, 853, 338, 2341, 848, 1000, 1001, 698, 1000, 1000, 1000, 1000, 552, 821, 1000, 999, 929, 999, 959, 1000, 710, 999, 951, 1000, 1000, 999, 806, 810, 1000, 1000]
theorem loads449 : cs449.get =
    load (fun i : Fin entries449.length => support (entries449.get i).1)
      (fun i => (entries449.get i).2) := by
  apply load_eq_of_sparse_packed base cs449 support code
    entries449 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node449 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 114 (insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 30 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs449 support demand
    entries449 ((insert 114 (insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 30 (insert 47 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)) 1000 30 loads449
  decide +kernel
def entries450 : List (Fin 1589 × ℕ) := [(20, 32), (75, 22), (86, 13), (122, 13), (137, 4), (177, 14), (179, 3), (323, 14), (386, 11), (399, 3), (469, 12), (479, 53), (483, 21), (485, 21), (507, 19), (515, 38), (526, 2), (531, 8), (542, 24), (552, 2), (571, 3), (577, 5), (584, 1), (616, 19), (617, 4), (731, 38), (737, 11), (739, 27), (743, 15), (813, 15), (819, 8), (846, 19), (849, 8), (853, 24), (868, 13), (870, 1), (872, 3), (890, 6), (894, 3), (895, 9), (906, 29), (916, 1), (924, 17), (930, 27), (937, 13), (944, 8), (950, 13), (952, 24), (957, 4), (966, 5), (973, 30), (984, 19), (985, 16), (1003, 19), (1004, 8), (1006, 30), (1012, 27), (1030, 4), (1049, 20), (1052, 7), (1081, 24), (1093, 24), (1094, 4), (1100, 2), (1103, 49), (1148, 5), (1160, 19), (1161, 4), (1162, 17), (1167, 21), (1173, 5), (1182, 2), (1183, 7), (1186, 11), (1188, 6), (1212, 33), (1246, 12), (1262, 7), (1268, 1), (1292, 2), (1317, 7), (1342, 13), (1498, 10), (1582, 4)]
def cs450 : List ℕ := [0, 31, 0, 44, 53, 82, 4, 84, 39, 19, 79, 26, 99, 44, 46, 29, 100, 98, 98, 4, 93, 54, 17, 101, 99, 100, 100, 98, 13, 71, 1, 100, 67, 21, 98, 100, 100, 4, 69, 98, 101, 100, 60, 100, 99, 99, 100, 141, 99, 100, 83, 101, 75, 98, 5, 100, 99, 100, 100, 101, 101, 100, 32, 100, 84, 100, 100, 100, 99, 100, 102, 99, 99, 99, 58, 100, 6, 61, 100, 100, 100, 100, 46, 72, 100, 99, 65, 100, 100, 100, 82, 100, 100, 0, 89, 47, 100, 100, 99, 100, 100, 100, 100, 101, 29, 86, 99, 100, 100, 44, 100, 100, 99, 100, 30, 72, 100, 70, 88, 83, 100, 100, 100, 101, 99, 91, 30, 233, 79, 100, 100, 60, 100, 100, 100, 99, 35, 96, 100, 100, 79, 100, 98, 100, 79, 100, 79, 100, 100, 79, 100, 85, 100, 100]
theorem loads450 : cs450.get =
    load (fun i : Fin entries450.length => support (entries450.get i).1)
      (fun i => (entries450.get i).2) := by
  apply load_eq_of_sparse_packed base cs450 support code
    entries450 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node450 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 30 (insert 114 (insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 137 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs450 support demand
    entries450 ((insert 30 (insert 114 (insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 47 (insert 137 (insert 127 ∅))) : Finset (Fin 154)) 100 30 loads450
  decide +kernel
theorem node448 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 114 (insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 137 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 114 (insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 137 (insert 127 ∅))) : Finset (Fin 154))
    30 node449 node450
theorem node446 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 137 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 93 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 47 (insert 137 (insert 127 ∅))) : Finset (Fin 154))
    114 node447 node448
theorem node431 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 137 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 47 (insert 137 (insert 127 ∅))) : Finset (Fin 154))
    93 node445 node446
def entries443 : List (Fin 1589 × ℕ) := [(20, 377), (37, 268), (43, 144), (46, 221), (77, 103), (122, 107), (137, 96), (421, 181), (439, 48), (483, 224), (494, 225), (507, 67), (542, 411), (550, 143), (552, 85), (570, 317), (572, 126), (583, 88), (584, 15), (585, 22), (617, 211), (623, 56), (691, 31), (730, 185), (731, 399), (739, 58), (797, 37), (813, 114), (815, 35), (817, 82), (818, 35), (819, 104), (844, 25), (846, 257), (849, 237), (869, 51), (870, 244), (882, 29), (886, 237), (906, 109), (924, 127), (925, 56), (936, 4), (937, 20), (938, 91), (940, 130), (943, 41), (948, 213), (952, 164), (973, 296), (978, 136), (985, 244), (1004, 228), (1019, 142), (1021, 269), (1028, 50), (1031, 104), (1049, 121), (1081, 1), (1093, 275), (1103, 305), (1111, 57), (1114, 117), (1123, 124), (1133, 235), (1160, 328), (1161, 97), (1162, 7), (1165, 27), (1167, 271), (1173, 163), (1180, 27), (1181, 268), (1212, 122), (1220, 71), (1235, 8), (1236, 372), (1261, 98), (1269, 68), (1320, 114), (1392, 54), (1403, 94), (1441, 71), (1545, 28), (1548, 20), (1549, 184), (1555, 44), (1575, 23), (1580, 50)]
def cs443 : List ℕ := [468, 328, 0, 685, 422, 864, 365, 1000, 716, 67, 103, 738, 1000, 427, 1000, 364, 1000, 2061, 999, 394, 1000, 651, 0, 1000, 1000, 1000, 1000, 1001, 343, 742, 1000, 601, 393, 367, 1000, 1000, 1001, 0, 371, 1000, 1001, 1000, 354, 999, 999, 999, 1000, 0, 714, 1000, 1001, 996, 1001, 2075, 163, 1446, 1001, 674, 1000, 435, 1001, 999, 885, 1000, 999, 999, 1000, 1001, 1000, 1000, 1001, 855, 1000, 938, 999, 1000, 0, 942, 1000, 999, 1000, 1000, 1320, 1003, 882, 999, 754, 999, 1001, 999, 1000, 999, 1000, 1002, 868, 692, 999, 1001, 1000, 1546, 1000, 999, 1000, 895, 495, 1000, 1000, 999, 1000, 478, 999, 999, 1000, 977, 999, 999, 1000, 194, 999, 836, 1000, 999, 859, 1000, 999, 999, 323, 2159, 1000, 999, 999, 567, 1000, 999, 1000, 1000, 459, 1212, 999, 999, 999, 980, 757, 999, 1000, 1000, 649, 746, 999, 698, 999, 777, 875, 790]
theorem loads443 : cs443.get =
    load (fun i : Fin entries443.length => support (entries443.get i).1)
      (fun i => (entries443.get i).2) := by
  apply load_eq_of_sparse_packed base cs443 support code
    entries443 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node443 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 99 (insert 17 (insert 53 (insert 82 (insert 137 (insert 127 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs443 support demand
    entries443 ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 55 (insert 99 (insert 17 (insert 53 (insert 82 (insert 137 (insert 127 ∅))))))) : Finset (Fin 154)) 1000 30 loads443
  decide +kernel
def entries444 : List (Fin 1589 × ℕ) := [(7, 10), (37, 34), (46, 24), (77, 22), (387, 1), (420, 2), (421, 15), (439, 1), (472, 19), (483, 20), (507, 14), (529, 4), (531, 15), (540, 2), (542, 31), (552, 15), (570, 14), (617, 17), (625, 16), (691, 2), (730, 23), (731, 32), (737, 1), (739, 14), (813, 4), (815, 18), (817, 9), (819, 3), (842, 3), (844, 1), (846, 26), (870, 38), (882, 3), (886, 18), (922, 17), (923, 8), (924, 14), (925, 29), (940, 6), (948, 11), (951, 1), (952, 20), (973, 21), (978, 41), (1004, 11), (1012, 12), (1019, 16), (1021, 33), (1038, 9), (1047, 14), (1055, 22), (1093, 12), (1094, 10), (1101, 13), (1103, 28), (1114, 10), (1123, 29), (1128, 11), (1133, 17), (1160, 42), (1161, 27), (1165, 4), (1172, 5), (1173, 15), (1180, 13), (1181, 12), (1188, 12), (1212, 10), (1220, 16), (1222, 10), (1233, 13), (1236, 16), (1261, 5), (1263, 14), (1297, 3), (1320, 2), (1356, 10), (1400, 23), (1403, 6), (1448, 3), (1466, 2), (1545, 23), (1548, 5), (1555, 5), (1575, 1), (1580, 11)]
def cs444 : List ℕ := [33, 62, 39, 16, 47, 80, 24, 99, 48, 14, 22, 80, 100, 50, 90, 18, 99, 160, 100, 37, 87, 61, 0, 100, 84, 99, 99, 100, 39, 24, 99, 100, 65, 1, 99, 101, 100, 0, 56, 99, 100, 55, 26, 79, 99, 101, 101, 0, 68, 98, 101, 101, 100, 189, 30, 6, 100, 88, 100, 82, 101, 100, 100, 101, 99, 100, 100, 100, 99, 100, 101, 101, 100, 100, 76, 100, 12, 100, 100, 99, 101, 100, 125, 100, 90, 90, 71, 100, 101, 99, 100, 99, 100, 100, 86, 33, 100, 101, 101, 153, 100, 100, 100, 100, 32, 101, 101, 100, 99, 40, 99, 100, 100, 93, 100, 69, 100, 38, 99, 79, 100, 101, 100, 100, 100, 74, 25, 251, 101, 101, 100, 26, 100, 100, 100, 101, 36, 139, 100, 101, 100, 101, 52, 95, 100, 101, 62, 49, 101, 70, 100, 88, 45, 94]
theorem loads444 : cs444.get =
    load (fun i : Fin entries444.length => support (entries444.get i).1)
      (fun i => (entries444.get i).2) := by
  apply load_eq_of_sparse_packed base cs444 support code
    entries444 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node444 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 55 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 99 (insert 17 (insert 53 (insert 82 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs444 support demand
    entries444 ((insert 55 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 99 (insert 17 (insert 53 (insert 82 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154)) 100 30 loads444
  decide +kernel
theorem node441 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 99 (insert 17 (insert 53 (insert 82 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 99 (insert 17 (insert 53 (insert 82 (insert 137 (insert 127 ∅)))))) : Finset (Fin 154))
    55 node443 node444
def entries442 : List (Fin 1589 × ℕ) := [(7, 3), (20, 29), (46, 33), (72, 27), (77, 11), (86, 17), (122, 26), (137, 8), (203, 10), (205, 1), (439, 3), (472, 5), (483, 23), (507, 9), (526, 16), (542, 19), (550, 25), (570, 23), (577, 17), (583, 8), (616, 9), (617, 31), (625, 4), (672, 4), (730, 17), (731, 39), (736, 6), (737, 22), (797, 20), (798, 1), (814, 9), (815, 9), (843, 8), (844, 8), (846, 32), (870, 28), (884, 18), (906, 2), (920, 16), (925, 33), (936, 11), (937, 13), (938, 4), (940, 11), (947, 5), (951, 3), (952, 28), (957, 3), (963, 7), (966, 18), (973, 26), (978, 27), (985, 1), (1004, 35), (1012, 11), (1019, 14), (1021, 24), (1031, 9), (1047, 10), (1049, 23), (1081, 19), (1090, 1), (1093, 12), (1094, 15), (1103, 43), (1123, 1), (1131, 3), (1133, 19), (1148, 17), (1160, 16), (1161, 16), (1169, 23), (1173, 4), (1181, 12), (1220, 22), (1229, 5), (1236, 24), (1261, 12), (1310, 2), (1320, 41), (1360, 13), (1400, 7), (1420, 6), (1485, 5), (1551, 5), (1576, 2), (1580, 10)]
def cs442 : List ℕ := [54, 57, 5, 51, 37, 47, 33, 101, 29, 9, 38, 91, 100, 47, 100, 51, 100, 199, 101, 0, 100, 76, 0, 100, 99, 96, 101, 100, 83, 62, 100, 100, 67, 31, 100, 101, 100, 0, 38, 100, 100, 100, 35, 99, 100, 100, 100, 0, 86, 100, 100, 100, 100, 178, 4, 100, 100, 72, 100, 77, 100, 100, 101, 100, 100, 100, 100, 99, 99, 101, 100, 100, 86, 100, 74, 100, 0, 100, 99, 99, 101, 101, 131, 99, 87, 100, 96, 99, 100, 100, 99, 100, 101, 100, 100, 78, 99, 100, 74, 5, 100, 100, 100, 100, 58, 100, 100, 68, 92, 37, 100, 100, 100, 100, 100, 60, 101, 26, 72, 91, 100, 100, 54, 100, 101, 94, 26, 305, 100, 100, 100, 66, 100, 100, 101, 100, 30, 127, 101, 100, 101, 100, 71, 96, 98, 97, 35, 67, 100, 33, 100, 74, 97, 60]
theorem loads442 : cs442.get =
    load (fun i : Fin entries442.length => support (entries442.get i).1)
      (fun i => (entries442.get i).2) := by
  apply load_eq_of_sparse_packed base cs442 support code
    entries442 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node442 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 99 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 17 (insert 53 (insert 82 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs442 support demand
    entries442 ((insert 99 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 17 (insert 53 (insert 82 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)) 100 30 loads442
  decide +kernel
theorem node439 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 17 (insert 53 (insert 82 (insert 137 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 17 (insert 53 (insert 82 (insert 137 (insert 127 ∅))))) : Finset (Fin 154))
    99 node441 node442
def entries440 : List (Fin 1589 × ℕ) := [(35, 6), (62, 8), (120, 2), (177, 25), (179, 13), (419, 16), (472, 8), (507, 8), (526, 25), (529, 3), (542, 8), (570, 37), (572, 8), (583, 27), (616, 2), (617, 17), (625, 5), (691, 1), (693, 2), (731, 53), (737, 17), (739, 4), (797, 7), (798, 4), (813, 7), (815, 10), (843, 2), (847, 6), (883, 5), (885, 11), (903, 2), (905, 9), (906, 1), (920, 2), (924, 1), (925, 29), (936, 6), (937, 22), (938, 4), (940, 21), (944, 21), (948, 5), (950, 18), (952, 13), (966, 6), (973, 29), (984, 6), (995, 10), (1004, 16), (1012, 17), (1019, 25), (1021, 5), (1033, 7), (1038, 6), (1047, 14), (1049, 15), (1061, 15), (1093, 24), (1094, 1), (1103, 41), (1123, 29), (1127, 13), (1133, 5), (1160, 27), (1161, 18), (1169, 41), (1173, 26), (1180, 12), (1186, 14), (1217, 25), (1236, 38), (1251, 17), (1261, 3), (1280, 3), (1310, 9), (1318, 2), (1358, 1), (1401, 17), (1420, 8), (1491, 12), (1537, 9), (1548, 10), (1554, 13), (1587, 11)]
def cs440 : List ℕ := [67, 14, 48, 0, 38, 81, 0, 101, 15, 16, 0, 78, 101, 37, 25, 25, 100, 0, 102, 16, 92, 37, 38, 101, 101, 100, 101, 101, 24, 44, 100, 101, 61, 41, 101, 102, 100, 0, 48, 99, 85, 99, 37, 90, 100, 99, 100, 0, 100, 100, 99, 90, 78, 185, 26, 100, 100, 72, 101, 69, 99, 101, 99, 100, 102, 101, 99, 100, 100, 101, 98, 101, 99, 100, 98, 101, 0, 100, 100, 99, 100, 99, 149, 100, 100, 101, 90, 101, 101, 100, 99, 100, 99, 98, 100, 94, 101, 100, 99, 101, 100, 101, 99, 99, 58, 101, 100, 101, 100, 38, 81, 100, 92, 101, 100, 100, 99, 54, 83, 92, 100, 100, 92, 100, 101, 101, 29, 256, 89, 101, 101, 70, 99, 100, 101, 101, 55, 145, 101, 100, 93, 100, 87, 100, 87, 100, 85, 84, 100, 69, 76, 97, 75, 70]
theorem loads440 : cs440.get =
    load (fun i : Fin entries440.length => support (entries440.get i).1)
      (fun i => (entries440.get i).2) := by
  apply load_eq_of_sparse_packed base cs440 support code
    entries440 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node440 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 17 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 53 (insert 82 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs440 support demand
    entries440 ((insert 17 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 53 (insert 82 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)) 100 30 loads440
  decide +kernel
theorem node435 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 53 (insert 82 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 53 (insert 82 (insert 137 (insert 127 ∅)))) : Finset (Fin 154))
    17 node439 node440
def entries437 : List (Fin 1589 × ℕ) := [(7, 339), (46, 194), (62, 106), (72, 345), (77, 71), (86, 32), (122, 43), (179, 87), (205, 31), (419, 54), (469, 57), (472, 73), (483, 174), (496, 138), (507, 82), (529, 84), (531, 232), (577, 130), (583, 398), (616, 100), (617, 206), (625, 112), (672, 13), (730, 206), (731, 449), (737, 94), (739, 150), (797, 189), (798, 246), (813, 34), (815, 234), (819, 20), (843, 4), (844, 41), (870, 206), (872, 57), (882, 236), (886, 106), (906, 39), (918, 74), (920, 211), (922, 131), (925, 324), (937, 287), (938, 10), (940, 172), (943, 28), (944, 94), (948, 33), (950, 99), (952, 151), (966, 178), (973, 218), (985, 334), (1004, 231), (1006, 260), (1012, 137), (1019, 6), (1031, 285), (1049, 209), (1081, 158), (1093, 257), (1100, 17), (1103, 368), (1108, 31), (1123, 270), (1127, 34), (1128, 136), (1137, 303), (1160, 315), (1162, 168), (1167, 188), (1180, 157), (1181, 90), (1186, 57), (1212, 3), (1222, 103), (1236, 262), (1251, 92), (1261, 21), (1269, 80), (1280, 282), (1335, 80), (1420, 27), (1554, 160), (1580, 183)]
def cs437 : List ℕ := [585, 781, 176, 0, 784, 821, 194, 1001, 138, 188, 416, 942, 1000, 1001, 793, 279, 1000, 1000, 977, 106, 1001, 1001, 87, 1000, 1000, 1000, 1000, 1000, 598, 281, 1000, 2481, 406, 229, 897, 1000, 1000, 0, 609, 1000, 1000, 1000, 353, 953, 1000, 999, 1001, 0, 785, 1001, 999, 1001, 657, 188, 103, 999, 1000, 879, 1000, 981, 1000, 1000, 1000, 1000, 1000, 610, 1000, 1000, 1000, 1000, 1000, 1000, 871, 868, 448, 999, 0, 1000, 1000, 1000, 1000, 1000, 1619, 1000, 999, 999, 724, 1000, 1001, 1000, 1000, 1000, 1001, 999, 922, 586, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 893, 415, 877, 1000, 1000, 1000, 335, 1000, 999, 999, 917, 1000, 674, 1000, 492, 999, 678, 999, 1000, 703, 1000, 1000, 969, 218, 2554, 919, 999, 1000, 709, 1001, 1000, 1001, 1000, 218, 1415, 999, 1001, 805, 1000, 964, 1000, 899, 1001, 524, 800, 887, 494, 1001, 527, 948, 593]
theorem loads437 : cs437.get =
    load (fun i : Fin entries437.length => support (entries437.get i).1)
      (fun i => (entries437.get i).2) := by
  apply load_eq_of_sparse_packed base cs437 support code
    entries437 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node437 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 53 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 82 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs437 support demand
    entries437 ((insert 53 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 31 (insert 82 (insert 137 (insert 127 ∅)))) : Finset (Fin 154)) 1000 30 loads437
  decide +kernel
def entries438 : List (Fin 1589 × ℕ) := [(20, 27), (46, 4), (62, 15), (75, 30), (120, 8), (122, 12), (179, 13), (419, 8), (466, 16), (472, 36), (483, 4), (498, 18), (507, 10), (527, 1), (542, 36), (552, 17), (571, 18), (616, 3), (617, 30), (625, 13), (731, 40), (737, 27), (797, 1), (813, 1), (814, 10), (815, 15), (819, 11), (843, 10), (844, 18), (870, 21), (872, 29), (882, 1), (885, 15), (894, 15), (896, 21), (905, 18), (924, 12), (925, 17), (939, 18), (940, 11), (949, 12), (950, 5), (951, 10), (952, 6), (966, 8), (973, 30), (985, 28), (1004, 26), (1006, 33), (1012, 16), (1019, 28), (1031, 11), (1049, 16), (1055, 18), (1081, 19), (1093, 20), (1103, 42), (1107, 24), (1114, 1), (1122, 13), (1123, 16), (1127, 3), (1133, 8), (1137, 9), (1159, 9), (1161, 11), (1162, 11), (1169, 4), (1171, 6), (1180, 6), (1186, 29), (1188, 3), (1220, 30), (1251, 1), (1261, 3), (1277, 12), (1310, 6), (1320, 7), (1403, 6), (1469, 5), (1491, 15), (1545, 2), (1548, 1), (1554, 12), (1576, 4)]
def cs438 : List ℕ := [64, 30, 36, 57, 0, 4, 4, 100, 45, 25, 30, 67, 87, 71, 70, 53, 101, 100, 69, 33, 100, 90, 13, 100, 100, 101, 101, 99, 48, 74, 100, 0, 54, 28, 99, 99, 101, 0, 36, 99, 86, 74, 43, 90, 99, 100, 100, 0, 83, 100, 100, 99, 101, 34, 6, 100, 101, 99, 101, 27, 98, 101, 100, 100, 94, 38, 99, 101, 100, 100, 98, 101, 86, 100, 43, 100, 3, 35, 99, 101, 101, 100, 128, 100, 91, 100, 75, 100, 100, 100, 98, 100, 101, 99, 78, 18, 101, 101, 99, 99, 100, 100, 99, 99, 52, 97, 100, 100, 101, 36, 100, 100, 100, 100, 99, 87, 101, 51, 100, 81, 101, 100, 54, 100, 99, 82, 30, 302, 100, 101, 99, 43, 100, 99, 101, 98, 36, 128, 98, 100, 100, 99, 68, 99, 99, 100, 40, 72, 100, 66, 77, 85, 99, 71]
theorem loads438 : cs438.get =
    load (fun i : Fin entries438.length => support (entries438.get i).1)
      (fun i => (entries438.get i).2) := by
  apply load_eq_of_sparse_packed base cs438 support code
    entries438 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node438 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 31 (insert 53 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 82 (insert 137 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs438 support demand
    entries438 ((insert 31 (insert 53 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 82 (insert 137 (insert 127 ∅))) : Finset (Fin 154)) 100 30 loads438
  decide +kernel
theorem node436 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 53 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 82 (insert 137 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 53 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 82 (insert 137 (insert 127 ∅))) : Finset (Fin 154))
    31 node437 node438
theorem node433 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 82 (insert 137 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 82 (insert 137 (insert 127 ∅))) : Finset (Fin 154))
    53 node435 node436
def entries434 : List (Fin 1589 × ℕ) := [(37, 200), (46, 14), (72, 230), (77, 279), (120, 198), (179, 89), (439, 72), (466, 174), (472, 75), (483, 185), (507, 216), (531, 200), (550, 2), (570, 3), (584, 127), (585, 66), (616, 83), (617, 262), (625, 293), (689, 3), (730, 300), (731, 50), (737, 229), (739, 12), (815, 168), (835, 111), (843, 103), (869, 58), (870, 203), (872, 19), (882, 73), (886, 82), (896, 207), (905, 247), (922, 56), (924, 69), (925, 220), (936, 111), (937, 94), (938, 54), (940, 185), (950, 97), (951, 50), (952, 141), (957, 6), (973, 299), (978, 188), (985, 172), (1004, 179), (1006, 152), (1012, 162), (1017, 5), (1031, 206), (1047, 7), (1049, 78), (1081, 117), (1093, 167), (1094, 97), (1100, 123), (1103, 226), (1107, 4), (1108, 55), (1123, 91), (1128, 7), (1133, 99), (1148, 96), (1159, 206), (1160, 22), (1161, 178), (1167, 272), (1169, 30), (1173, 151), (1179, 22), (1180, 10), (1181, 145), (1186, 145), (1188, 91), (1212, 104), (1220, 265), (1236, 103), (1261, 142), (1262, 62), (1263, 89), (1277, 163), (1280, 23), (1303, 7), (1335, 80), (1358, 91), (1491, 66), (1580, 192), (1587, 75)]
def cs434 : List ℕ := [656, 363, 75, 272, 295, 518, 14, 998, 351, 216, 516, 999, 999, 486, 715, 414, 998, 1000, 1000, 200, 917, 701, 89, 999, 999, 1000, 999, 1000, 1000, 103, 999, 1000, 648, 302, 1000, 1001, 999, 7, 999, 1000, 999, 1000, 179, 967, 1000, 999, 1000, 0, 530, 999, 1001, 999, 218, 1000, 151, 1000, 1001, 365, 1000, 731, 1000, 1000, 451, 770, 1000, 952, 998, 1001, 1001, 1000, 1000, 1001, 519, 999, 696, 999, 113, 703, 1000, 1001, 999, 1001, 0, 1001, 794, 999, 700, 947, 1001, 1001, 1000, 1000, 1000, 1000, 862, 623, 1000, 1002, 1000, 1000, 1000, 1000, 1000, 563, 513, 1001, 1001, 1000, 1001, 426, 1000, 1000, 1000, 1001, 1000, 1000, 1001, 255, 1000, 624, 1001, 1000, 739, 1000, 1002, 1000, 299, 2152, 820, 1001, 1001, 697, 1000, 1001, 919, 1001, 450, 1265, 1001, 1001, 1002, 1000, 885, 1001, 1001, 880, 757, 1001, 1001, 786, 1001, 835, 1001, 733]
theorem loads434 : cs434.get =
    load (fun i : Fin entries434.length => support (entries434.get i).1)
      (fun i => (entries434.get i).2) := by
  apply load_eq_of_sparse_packed base cs434 support code
    entries434 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node434 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 82 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 137 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs434 support demand
    entries434 ((insert 82 (insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 137 (insert 127 ∅)) : Finset (Fin 154)) 1000 30 loads434
  decide +kernel
theorem node432 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 137 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 137 (insert 127 ∅)) : Finset (Fin 154))
    82 node433 node434
theorem node430 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 137 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 137 (insert 127 ∅)) : Finset (Fin 154))
    47 node431 node432
#print axioms node430
end OmissionResidualCover
