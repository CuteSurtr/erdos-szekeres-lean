import ResidualCoverProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries601 : List (Fin 1589 × ℕ) := [(20, 331), (46, 69), (75, 338), (86, 42), (122, 64), (315, 86), (385, 223), (478, 60), (479, 218), (494, 60), (507, 320), (515, 244), (551, 36), (572, 1), (617, 213), (639, 7), (680, 12), (739, 5), (813, 228), (815, 33), (817, 11), (819, 121), (843, 27), (845, 75), (846, 86), (863, 438), (864, 15), (870, 391), (872, 92), (886, 25), (893, 61), (894, 58), (895, 35), (896, 272), (906, 260), (916, 65), (920, 198), (925, 32), (929, 5), (930, 110), (938, 258), (940, 319), (955, 158), (958, 17), (970, 58), (973, 532), (984, 355), (985, 19), (1006, 108), (1043, 205), (1055, 48), (1056, 61), (1090, 4), (1111, 126), (1114, 23), (1120, 74), (1122, 10), (1123, 94), (1140, 34), (1142, 30), (1143, 74), (1160, 22), (1165, 5), (1173, 129), (1180, 149), (1181, 168), (1182, 5), (1183, 202), (1186, 245), (1227, 31), (1236, 155), (1246, 502), (1247, 72), (1258, 51), (1268, 50), (1290, 179), (1308, 112), (1312, 70), (1342, 57), (1356, 3), (1358, 347), (1400, 15), (1454, 97), (1488, 1), (1489, 47), (1498, 230), (1523, 21), (1545, 100), (1548, 21)]
def cs601 : List ℕ := [502, 161, 3, 331, 436, 564, 69, 1001, 510, 773, 761, 935, 1001, 476, 407, 330, 1001, 999, 1001, 51, 1000, 931, 0, 1001, 1001, 999, 1661, 824, 64, 738, 1000, 1001, 582, 75, 1000, 996, 1000, 0, 834, 1000, 979, 1000, 280, 994, 999, 1000, 1001, 2072, 693, 1000, 1000, 1000, 999, 1000, 129, 1000, 1000, 999, 999, 1001, 1001, 1000, 910, 999, 1001, 375, 1000, 2308, 1000, 999, 1001, 1000, 1000, 782, 864, 1001, 15, 1000, 999, 1718, 1000, 1000, 629, 999, 688, 344, 606, 1001, 1000, 1000, 1001, 914, 725, 1000, 529, 0, 1000, 1000, 1001, 1002, 1000, 1000, 999, 999, 547, 1001, 1001, 1002, 999, 741, 1000, 1001, 1000, 1001, 1001, 1001, 1001, 627, 1001, 532, 585, 1001, 1000, 1002, 1001, 769, 1145, 1001, 952, 1001, 1002, 532, 1001, 1001, 957, 1001, 866, 897, 1000, 1002, 868, 1000, 897, 1001, 814, 923, 999, 979, 1001, 1001, 1001, 1000, 1001, 1001]
theorem loads601 : cs601.get =
    load (fun i : Fin entries601.length => support (entries601.get i).1)
      (fun i => (entries601.get i).2) := by
  apply load_eq_of_sparse_packed base cs601 support code
    entries601 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node601 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 79 (insert 67 (insert 26 (insert 47 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs601 support demand
    entries601 ((insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 79 (insert 67 (insert 26 (insert 47 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154)) 1000 30 loads601
  decide +kernel
def entries602 : List (Fin 1589 × ℕ) := [(20, 260), (46, 302), (75, 21), (137, 17), (315, 115), (386, 45), (440, 104), (472, 99), (479, 229), (483, 24), (506, 23), (507, 264), (515, 68), (541, 64), (551, 47), (572, 115), (617, 226), (640, 32), (730, 80), (737, 117), (813, 205), (817, 9), (819, 207), (842, 19), (843, 167), (856, 280), (863, 306), (868, 177), (869, 146), (870, 52), (872, 91), (886, 100), (893, 26), (894, 98), (895, 174), (896, 56), (906, 351), (916, 152), (918, 60), (925, 154), (930, 98), (936, 297), (938, 352), (943, 55), (952, 41), (969, 11), (973, 459), (984, 398), (1004, 74), (1006, 143), (1043, 287), (1049, 73), (1056, 143), (1111, 309), (1114, 8), (1123, 207), (1140, 55), (1142, 15), (1143, 144), (1171, 7), (1173, 103), (1180, 89), (1181, 59), (1183, 151), (1186, 224), (1219, 240), (1227, 195), (1236, 156), (1246, 192), (1258, 89), (1261, 12), (1262, 4), (1267, 128), (1268, 60), (1275, 85), (1286, 40), (1293, 19), (1312, 119), (1335, 1), (1342, 171), (1358, 259), (1401, 15), (1466, 27), (1498, 37), (1523, 147), (1580, 17)]
def cs602 : List ℕ := [415, 240, 99, 500, 402, 497, 302, 1000, 264, 593, 266, 853, 1000, 428, 419, 84, 1000, 1000, 1001, 175, 1000, 1000, 0, 1001, 1001, 1000, 1590, 1001, 128, 583, 1000, 1001, 478, 7, 1000, 1001, 1000, 0, 775, 1001, 1001, 1001, 244, 858, 1000, 1000, 1001, 1991, 562, 999, 1001, 1002, 755, 1000, 110, 1000, 1000, 1000, 1000, 1000, 1001, 1001, 372, 1001, 999, 402, 999, 2171, 953, 1001, 1001, 1001, 1000, 1000, 799, 999, 0, 1001, 1000, 276, 1001, 1001, 708, 999, 602, 421, 458, 1000, 1001, 706, 925, 931, 846, 1001, 458, 0, 1000, 1000, 1001, 1000, 1000, 1000, 998, 999, 696, 1002, 1000, 827, 1001, 427, 1000, 1000, 1000, 1000, 1001, 747, 1001, 386, 999, 459, 883, 1001, 1000, 1002, 1000, 712, 1107, 1001, 858, 1001, 1001, 459, 1002, 1001, 1002, 1000, 856, 607, 1002, 1001, 1002, 977, 754, 1001, 1001, 607, 816, 992, 951, 802, 1002, 1001, 832, 919]
theorem loads602 : cs602.get =
    load (fun i : Fin entries602.length => support (entries602.get i).1)
      (fun i => (entries602.get i).2) := by
  apply load_eq_of_sparse_packed base cs602 support code
    entries602 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node602 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 79 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 26 (insert 47 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs602 support demand
    entries602 ((insert 79 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 26 (insert 47 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)) 1000 30 loads602
  decide +kernel
theorem node595 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 26 (insert 47 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 67 (insert 26 (insert 47 (insert 104 (insert 126 ∅))))) : Finset (Fin 154))
    79 node601 node602
def entries599 : List (Fin 1589 × ℕ) := [(10, 262), (20, 328), (77, 147), (86, 43), (135, 14), (137, 148), (179, 73), (315, 1), (343, 65), (360, 6), (438, 192), (440, 154), (472, 160), (479, 383), (485, 46), (494, 30), (507, 501), (542, 141), (572, 112), (617, 401), (639, 171), (681, 44), (736, 38), (737, 25), (739, 60), (740, 76), (798, 221), (815, 167), (847, 155), (856, 548), (868, 538), (869, 28), (870, 303), (872, 73), (882, 106), (886, 226), (890, 6), (896, 118), (904, 5), (906, 201), (920, 37), (927, 184), (928, 49), (929, 45), (940, 593), (952, 45), (970, 6), (973, 446), (984, 466), (1006, 88), (1009, 78), (1043, 446), (1090, 10), (1098, 19), (1111, 96), (1114, 146), (1120, 163), (1121, 144), (1122, 91), (1123, 428), (1181, 19), (1182, 19), (1188, 1), (1219, 271), (1226, 126), (1227, 260), (1234, 173), (1247, 301), (1258, 166), (1261, 162), (1275, 87), (1292, 50), (1293, 110), (1295, 15), (1342, 26), (1354, 171), (1498, 84), (1523, 119), (1559, 62)]
def cs599 : List ℕ := [0, 271, 577, 599, 645, 728, 0, 999, 328, 501, 735, 645, 999, 663, 288, 190, 999, 973, 1000, 112, 1000, 646, 73, 1000, 1001, 2554, 1902, 1000, 209, 401, 999, 999, 631, 0, 1000, 999, 1000, 0, 1001, 1000, 1000, 978, 65, 755, 1000, 999, 1000, 2047, 467, 850, 1000, 1000, 458, 1000, 0, 1000, 1000, 1001, 1001, 745, 999, 1001, 617, 1001, 1000, 542, 1000, 184, 1000, 1001, 1001, 1001, 1000, 1000, 642, 999, 127, 1000, 1001, 1000, 1000, 1001, 1001, 1001, 520, 245, 568, 1000, 1000, 1000, 1000, 912, 1000, 2520, 523, 0, 394, 1001, 1000, 1000, 1000, 1000, 1001, 750, 847, 914, 1000, 756, 1001, 19, 1000, 1067, 1000, 999, 621, 1000, 1001, 25, 999, 461, 1000, 1000, 999, 969, 1001, 612, 1619, 999, 999, 1000, 919, 446, 1000, 999, 1000, 1000, 892, 465, 1000, 999, 809, 584, 484, 1000, 1000, 643, 465, 853, 1000, 893, 999, 533, 650, 533]
theorem loads599 : cs599.get =
    load (fun i : Fin entries599.length => support (entries599.get i).1)
      (fun i => (entries599.get i).2) := by
  apply load_eq_of_sparse_packed base cs599 support code
    entries599 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node599 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 25 (insert 26 (insert 47 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs599 support demand
    entries599 ((insert 67 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 93 (insert 25 (insert 26 (insert 47 (insert 104 (insert 126 ∅)))))) : Finset (Fin 154)) 1000 30 loads599
  decide +kernel
def entries600 : List (Fin 1589 × ℕ) := [(10, 11), (20, 26), (35, 23), (77, 27), (86, 15), (122, 15), (315, 13), (343, 1), (421, 2), (472, 25), (479, 21), (485, 5), (506, 27), (507, 18), (515, 16), (542, 10), (583, 3), (617, 32), (639, 20), (731, 3), (737, 11), (741, 36), (815, 11), (817, 2), (819, 28), (842, 16), (843, 3), (845, 5), (847, 7), (856, 28), (868, 27), (870, 30), (882, 20), (886, 3), (890, 25), (904, 4), (906, 16), (920, 7), (921, 10), (925, 2), (928, 2), (929, 18), (930, 3), (939, 5), (964, 14), (966, 1), (973, 46), (984, 38), (985, 6), (1004, 6), (1006, 12), (1009, 15), (1043, 22), (1049, 2), (1077, 1), (1090, 1), (1110, 8), (1111, 22), (1119, 15), (1123, 40), (1143, 2), (1176, 3), (1177, 18), (1181, 5), (1186, 25), (1188, 25), (1212, 6), (1219, 24), (1221, 2), (1226, 7), (1258, 18), (1263, 11), (1268, 20), (1275, 3), (1342, 27), (1358, 15), (1469, 1), (1497, 4), (1498, 9), (1523, 11), (1572, 10)]
def cs600 : List ℕ := [17, 29, 45, 50, 32, 67, 0, 99, 60, 45, 70, 86, 99, 80, 37, 44, 99, 100, 96, 20, 99, 65, 0, 98, 99, 177, 166, 99, 43, 49, 99, 98, 61, 5, 99, 99, 100, 0, 77, 98, 100, 100, 23, 100, 99, 100, 86, 182, 78, 93, 73, 100, 28, 99, 2, 100, 99, 99, 101, 98, 99, 101, 37, 101, 92, 99, 99, 5, 98, 101, 99, 98, 100, 78, 68, 99, 53, 99, 100, 99, 100, 100, 87, 64, 63, 89, 64, 100, 99, 100, 99, 96, 99, 0, 26, 25, 57, 97, 100, 100, 98, 100, 101, 100, 87, 67, 100, 100, 98, 50, 100, 100, 101, 97, 100, 89, 100, 32, 100, 67, 93, 98, 99, 100, 100, 77, 131, 100, 99, 99, 83, 71, 99, 100, 99, 99, 99, 52, 99, 100, 99, 77, 60, 100, 100, 69, 70, 100, 99, 80, 100, 100, 100, 80]
theorem loads600 : cs600.get =
    load (fun i : Fin entries600.length => support (entries600.get i).1)
      (fun i => (entries600.get i).2) := by
  apply load_eq_of_sparse_packed base cs600 support code
    entries600 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node600 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 67 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 26 (insert 47 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs600 support demand
    entries600 ((insert 93 (insert 67 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 25 (insert 26 (insert 47 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)) 100 30 loads600
  decide +kernel
theorem node597 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 26 (insert 47 (insert 104 (insert 126 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 25 (insert 26 (insert 47 (insert 104 (insert 126 ∅))))) : Finset (Fin 154))
    93 node599 node600
def entries598 : List (Fin 1589 × ℕ) := [(20, 35), (177, 20), (179, 8), (312, 3), (313, 2), (315, 11), (343, 18), (419, 1), (468, 5), (479, 13), (485, 3), (497, 8), (507, 20), (515, 14), (542, 4), (552, 7), (584, 1), (617, 33), (639, 7), (681, 14), (739, 5), (741, 12), (815, 7), (817, 2), (819, 15), (843, 12), (863, 12), (870, 23), (871, 20), (872, 2), (882, 11), (890, 18), (905, 4), (906, 18), (920, 17), (922, 4), (925, 25), (929, 16), (930, 6), (940, 25), (966, 12), (970, 4), (973, 52), (978, 29), (1006, 9), (1043, 4), (1069, 9), (1076, 10), (1077, 4), (1078, 1), (1090, 19), (1111, 8), (1120, 18), (1123, 31), (1140, 1), (1142, 4), (1143, 18), (1173, 26), (1180, 9), (1181, 2), (1183, 15), (1186, 13), (1188, 13), (1219, 13), (1227, 8), (1236, 16), (1247, 9), (1258, 8), (1263, 4), (1267, 16), (1268, 16), (1280, 5), (1295, 2), (1312, 5), (1342, 24), (1354, 1), (1358, 32), (1370, 17), (1403, 16), (1469, 3), (1491, 16), (1498, 1), (1499, 3), (1523, 10), (1525, 11)]
def cs598 : List ℕ := [53, 23, 11, 48, 29, 25, 0, 95, 47, 43, 25, 94, 87, 73, 4, 35, 100, 100, 99, 16, 100, 47, 28, 100, 98, 0, 140, 100, 22, 63, 101, 100, 76, 0, 100, 100, 99, 0, 101, 100, 99, 88, 39, 77, 100, 100, 101, 174, 73, 90, 101, 100, 29, 100, 29, 100, 99, 101, 100, 101, 100, 100, 57, 101, 100, 57, 100, 26, 101, 101, 101, 99, 100, 101, 71, 100, 13, 100, 100, 101, 101, 99, 100, 100, 69, 64, 40, 99, 100, 100, 101, 81, 74, 99, 50, 0, 83, 99, 100, 100, 100, 100, 100, 100, 72, 90, 99, 101, 100, 24, 100, 100, 100, 100, 100, 101, 97, 44, 100, 54, 88, 99, 100, 99, 99, 87, 125, 100, 100, 98, 100, 52, 99, 101, 91, 100, 91, 67, 100, 101, 83, 99, 78, 100, 99, 83, 94, 101, 100, 100, 100, 92, 75, 80]
theorem loads598 : cs598.get =
    load (fun i : Fin entries598.length => support (entries598.get i).1)
      (fun i => (entries598.get i).2) := by
  apply load_eq_of_sparse_packed base cs598 support code
    entries598 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node598 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 67 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 26 (insert 47 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs598 support demand
    entries598 ((insert 25 (insert 67 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 26 (insert 47 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)) 100 30 loads598
  decide +kernel
theorem node596 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 26 (insert 47 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 26 (insert 47 (insert 104 (insert 126 ∅)))) : Finset (Fin 154))
    25 node597 node598
theorem node591 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 26 (insert 47 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 26 (insert 47 (insert 104 (insert 126 ∅)))) : Finset (Fin 154))
    67 node595 node596
def entries593 : List (Fin 1589 × ℕ) := [(17, 14), (20, 18), (46, 48), (62, 8), (72, 3), (75, 6), (315, 4), (385, 23), (468, 13), (474, 18), (479, 39), (515, 7), (527, 13), (529, 1), (531, 5), (550, 2), (551, 21), (552, 6), (623, 1), (625, 2), (681, 5), (730, 27), (737, 12), (763, 23), (797, 11), (798, 5), (812, 3), (813, 7), (815, 10), (817, 2), (819, 11), (843, 3), (866, 25), (870, 13), (879, 16), (883, 4), (886, 21), (893, 15), (894, 15), (896, 2), (906, 36), (916, 2), (917, 20), (920, 1), (925, 7), (936, 36), (937, 8), (938, 31), (950, 8), (952, 8), (973, 51), (984, 27), (1006, 12), (1012, 14), (1043, 18), (1049, 5), (1055, 2), (1056, 2), (1090, 11), (1107, 4), (1110, 5), (1111, 8), (1113, 4), (1114, 8), (1123, 11), (1143, 17), (1169, 6), (1173, 19), (1180, 4), (1181, 12), (1183, 26), (1186, 22), (1219, 6), (1234, 15), (1258, 10), (1292, 6), (1308, 3), (1342, 50), (1343, 5), (1358, 42), (1488, 5), (1523, 4)]
def cs593 : List ℕ := [42, 19, 0, 56, 39, 6, 48, 100, 32, 8, 47, 92, 98, 46, 57, 45, 99, 99, 30, 8, 99, 100, 0, 100, 89, 98, 6, 101, 6, 72, 99, 100, 9, 6, 99, 100, 101, 0, 81, 100, 52, 99, 34, 100, 100, 97, 101, 160, 92, 99, 99, 99, 100, 100, 19, 99, 100, 99, 100, 100, 99, 100, 79, 100, 91, 60, 98, 285, 99, 99, 100, 101, 100, 100, 97, 98, 0, 99, 101, 99, 100, 100, 70, 100, 97, 55, 42, 101, 100, 99, 100, 92, 61, 100, 34, 6, 100, 101, 100, 100, 100, 99, 97, 100, 42, 99, 101, 100, 100, 38, 100, 100, 82, 100, 99, 96, 100, 48, 100, 51, 78, 100, 100, 99, 100, 88, 95, 99, 74, 100, 99, 57, 100, 99, 87, 100, 88, 75, 100, 100, 88, 100, 94, 100, 84, 67, 100, 98, 100, 100, 100, 94, 95, 99]
theorem loads593 : cs593.get =
    load (fun i : Fin entries593.length => support (entries593.get i).1)
      (fun i => (entries593.get i).2) := by
  apply load_eq_of_sparse_packed base cs593 support code
    entries593 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node593 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 26 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 47 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs593 support demand
    entries593 ((insert 26 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 47 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)) 100 30 loads593
  decide +kernel
def entries594 : List (Fin 1589 × ℕ) := [(43, 403), (72, 7), (77, 11), (179, 146), (216, 29), (313, 36), (315, 110), (343, 85), (439, 31), (474, 205), (479, 566), (496, 75), (515, 164), (526, 71), (531, 26), (551, 188), (673, 151), (737, 53), (739, 41), (741, 69), (798, 4), (815, 81), (819, 24), (843, 145), (845, 75), (853, 18), (866, 53), (868, 63), (870, 89), (872, 261), (882, 26), (886, 247), (904, 157), (920, 47), (923, 32), (925, 313), (927, 40), (929, 5), (940, 336), (948, 90), (949, 35), (968, 40), (973, 435), (978, 75), (984, 163), (985, 55), (1012, 47), (1043, 146), (1049, 144), (1075, 173), (1076, 154), (1090, 327), (1113, 2), (1120, 151), (1121, 29), (1122, 124), (1123, 242), (1143, 136), (1171, 49), (1173, 315), (1181, 3), (1183, 123), (1186, 170), (1188, 291), (1212, 31), (1219, 359), (1227, 80), (1234, 173), (1235, 95), (1246, 170), (1258, 191), (1261, 96), (1269, 37), (1294, 6), (1342, 214), (1390, 56), (1403, 105), (1491, 125), (1496, 230)]
def cs594 : List ℕ := [0, 434, 0, 564, 566, 18, 403, 1000, 75, 0, 528, 653, 803, 287, 421, 339, 1000, 1001, 869, 0, 1000, 483, 146, 1000, 675, 1000, 0, 1001, 18, 549, 1000, 999, 700, 124, 1000, 999, 1000, 0, 846, 1000, 787, 765, 437, 573, 1000, 1001, 999, 1380, 994, 999, 1000, 999, 80, 1001, 364, 1000, 1001, 999, 999, 999, 1000, 999, 283, 1000, 910, 515, 999, 126, 1001, 999, 999, 999, 1001, 999, 581, 899, 291, 925, 1000, 1000, 999, 999, 316, 1000, 1000, 825, 279, 1000, 1000, 1001, 1000, 812, 853, 1000, 427, 0, 873, 1001, 1000, 1000, 1000, 1000, 1000, 1000, 805, 784, 1000, 941, 1000, 244, 1000, 1000, 1000, 1001, 984, 1000, 1001, 324, 1000, 441, 999, 1000, 1000, 1000, 1001, 799, 897, 1001, 1000, 1001, 1000, 435, 1000, 1000, 904, 1000, 945, 611, 1000, 1000, 1001, 946, 780, 1000, 905, 595, 992, 963, 976, 1000, 877, 772, 867, 759]
theorem loads594 : cs594.get =
    load (fun i : Fin entries594.length => support (entries594.get i).1)
      (fun i => (entries594.get i).2) := by
  apply load_eq_of_sparse_packed base cs594 support code
    entries594 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node594 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 26 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs594 support demand
    entries594 ((insert 67 (insert 26 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 104 (insert 126 ∅))) : Finset (Fin 154)) 1000 30 loads594
  decide +kernel
theorem node592 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 26 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 26 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 47 (insert 104 (insert 126 ∅))) : Finset (Fin 154))
    67 node593 node594
theorem node581 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 47 (insert 104 (insert 126 ∅))) : Finset (Fin 154))
    26 node591 node592
def entries587 : List (Fin 1589 × ℕ) := [(35, 31), (37, 103), (46, 48), (62, 385), (70, 155), (75, 502), (122, 22), (384, 77), (385, 44), (419, 45), (469, 40), (472, 110), (478, 23), (507, 160), (531, 142), (542, 45), (550, 17), (552, 142), (569, 79), (577, 45), (617, 303), (625, 17), (730, 170), (731, 224), (737, 129), (763, 129), (797, 50), (815, 186), (819, 105), (843, 164), (846, 54), (869, 2), (870, 144), (872, 120), (886, 163), (894, 200), (896, 73), (905, 114), (906, 57), (914, 104), (918, 155), (922, 75), (925, 265), (935, 120), (937, 181), (938, 288), (948, 65), (952, 78), (966, 136), (968, 1), (970, 45), (973, 416), (978, 430), (1004, 45), (1005, 34), (1006, 153), (1012, 61), (1043, 409), (1049, 249), (1055, 28), (1056, 6), (1069, 22), (1090, 120), (1111, 184), (1120, 178), (1143, 212), (1181, 74), (1182, 25), (1183, 327), (1186, 193), (1212, 64), (1219, 323), (1222, 45), (1236, 323), (1247, 23), (1262, 159), (1286, 94), (1348, 127), (1364, 34), (1400, 115), (1469, 139), (1488, 134), (1524, 14), (1537, 36), (1545, 58), (1548, 96), (1561, 92), (1576, 21), (1580, 46)]
def cs587 : List ℕ := [323, 462, 191, 323, 392, 538, 48, 1000, 329, 545, 657, 877, 1001, 760, 796, 181, 1000, 1001, 1000, 488, 1000, 1000, 0, 1000, 999, 999, 1000, 1000, 326, 840, 1000, 999, 442, 0, 1000, 1000, 1000, 104, 488, 1000, 1001, 999, 221, 916, 1000, 1000, 1001, 0, 703, 1000, 1000, 1000, 999, 1001, 45, 999, 1000, 963, 1000, 679, 1000, 1000, 679, 530, 1001, 858, 1000, 2537, 1000, 1000, 1000, 1000, 840, 1000, 677, 1002, 0, 1001, 1000, 1000, 1001, 999, 1000, 999, 809, 911, 564, 1001, 999, 1001, 1000, 986, 923, 999, 771, 0, 1000, 1001, 999, 1000, 999, 1000, 866, 1000, 983, 1000, 1001, 737, 1000, 520, 999, 1000, 1002, 1505, 1000, 1000, 1001, 848, 1000, 416, 1000, 951, 1001, 1001, 1001, 569, 1394, 1001, 738, 1002, 1000, 416, 1000, 1000, 1000, 1001, 847, 518, 1000, 1000, 1000, 1001, 838, 1000, 960, 668, 960, 1000, 1000, 696, 1000, 885, 864, 1000]
theorem loads587 : cs587.get =
    load (fun i : Fin entries587.length => support (entries587.get i).1)
      (fun i => (entries587.get i).2) := by
  apply load_eq_of_sparse_packed base cs587 support code
    entries587 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node587 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 113 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs587 support demand
    entries587 ((insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 67 (insert 113 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)) 1000 30 loads587
  decide +kernel
def entries589 : List (Fin 1589 × ℕ) := [(10, 126), (37, 295), (70, 302), (86, 37), (122, 169), (343, 167), (420, 250), (421, 72), (431, 18), (468, 11), (472, 227), (507, 143), (527, 159), (531, 4), (542, 170), (571, 75), (577, 121), (583, 111), (585, 43), (617, 349), (622, 64), (624, 137), (730, 250), (731, 178), (737, 410), (797, 44), (812, 85), (815, 44), (843, 193), (845, 47), (870, 179), (872, 282), (882, 143), (886, 111), (904, 36), (905, 74), (922, 140), (923, 140), (924, 70), (925, 192), (929, 27), (939, 201), (940, 216), (943, 12), (948, 82), (949, 124), (952, 5), (966, 38), (973, 452), (978, 430), (984, 118), (1043, 96), (1049, 22), (1069, 258), (1111, 216), (1119, 145), (1120, 217), (1121, 159), (1123, 195), (1143, 36), (1173, 145), (1180, 83), (1181, 81), (1183, 99), (1186, 202), (1212, 26), (1219, 307), (1236, 143), (1247, 104), (1261, 109), (1263, 132), (1275, 119), (1281, 201), (1295, 167), (1354, 61), (1375, 61), (1403, 1), (1469, 223), (1572, 48), (1586, 64), (1588, 25)]
def cs589 : List ℕ := [344, 429, 554, 508, 269, 438, 0, 1000, 427, 207, 302, 942, 1000, 412, 472, 312, 1000, 1000, 1001, 370, 1000, 947, 0, 1001, 888, 999, 1001, 1001, 593, 302, 999, 1001, 609, 47, 1000, 1001, 1001, 0, 322, 1001, 1001, 956, 179, 875, 1000, 999, 1001, 27, 820, 1001, 999, 1000, 361, 1000, 145, 1001, 1000, 1002, 1001, 682, 999, 1001, 403, 1001, 1000, 708, 1000, 263, 1000, 1001, 1001, 1000, 785, 1000, 241, 999, 0, 977, 1001, 1001, 1000, 1001, 868, 1000, 818, 932, 503, 1000, 1000, 1000, 1000, 1000, 1000, 1001, 804, 0, 529, 1948, 1001, 1000, 1000, 1000, 1000, 1001, 936, 1000, 1001, 754, 1000, 404, 1000, 1000, 1000, 2008, 859, 1001, 1000, 365, 999, 619, 1000, 1000, 999, 998, 1001, 597, 1576, 1000, 1001, 1000, 827, 452, 1000, 1000, 1000, 1000, 999, 616, 1000, 1000, 1000, 831, 638, 1000, 1001, 1000, 928, 1000, 986, 990, 972, 918, 761, 898]
theorem loads589 : cs589.get =
    load (fun i : Fin entries589.length => support (entries589.get i).1)
      (fun i => (entries589.get i).2) := by
  apply load_eq_of_sparse_packed base cs589 support code
    entries589 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node589 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 113 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs589 support demand
    entries589 ((insert 67 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 97 (insert 113 (insert 104 (insert 126 ∅)))) : Finset (Fin 154)) 1000 30 loads589
  decide +kernel
def entries590 : List (Fin 1589 × ℕ) := [(10, 16), (20, 31), (37, 11), (70, 28), (77, 19), (122, 20), (137, 2), (179, 6), (343, 22), (360, 7), (419, 4), (469, 21), (472, 9), (478, 16), (483, 14), (507, 9), (527, 14), (531, 10), (542, 29), (550, 16), (571, 15), (577, 22), (617, 25), (730, 8), (739, 7), (741, 14), (797, 7), (798, 7), (815, 18), (819, 11), (870, 28), (872, 14), (884, 6), (886, 15), (920, 1), (922, 5), (924, 13), (925, 11), (939, 23), (940, 4), (943, 14), (946, 17), (948, 16), (951, 14), (952, 2), (966, 9), (967, 4), (968, 4), (970, 22), (973, 50), (978, 18), (1043, 7), (1075, 22), (1076, 10), (1090, 32), (1111, 3), (1122, 10), (1123, 36), (1133, 6), (1142, 12), (1143, 16), (1162, 1), (1171, 2), (1173, 41), (1186, 7), (1188, 10), (1219, 23), (1233, 1), (1236, 9), (1276, 27), (1280, 18), (1286, 3), (1310, 10), (1348, 8), (1370, 12), (1400, 18), (1537, 4), (1576, 14)]
def cs590 : List ℕ := [27, 62, 29, 54, 41, 56, 0, 100, 46, 9, 47, 99, 100, 75, 76, 36, 100, 100, 99, 26, 101, 64, 6, 101, 100, 99, 101, 100, 71, 65, 99, 100, 49, 2, 100, 100, 100, 0, 36, 100, 101, 100, 36, 74, 100, 100, 101, 0, 100, 80, 93, 96, 29, 100, 43, 100, 100, 101, 99, 31, 100, 100, 78, 95, 100, 64, 100, 0, 99, 99, 101, 100, 93, 100, 68, 100, 27, 100, 100, 100, 99, 100, 102, 100, 59, 89, 43, 97, 100, 99, 101, 68, 100, 101, 78, 0, 100, 0, 99, 99, 102, 100, 101, 57, 75, 32, 99, 87, 100, 29, 100, 100, 100, 69, 92, 100, 99, 38, 100, 56, 100, 99, 100, 99, 100, 93, 85, 100, 73, 100, 99, 50, 100, 100, 90, 100, 100, 73, 100, 100, 100, 97, 61, 100, 96, 51, 97, 93, 100, 100, 91, 79, 85, 85]
theorem loads590 : cs590.get =
    load (fun i : Fin entries590.length => support (entries590.get i).1)
      (fun i => (entries590.get i).2) := by
  apply load_eq_of_sparse_packed base cs590 support code
    entries590 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node590 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 97 (insert 67 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 113 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs590 support demand
    entries590 ((insert 97 (insert 67 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 113 (insert 104 (insert 126 ∅))) : Finset (Fin 154)) 100 30 loads590
  decide +kernel
theorem node588 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 113 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 113 (insert 104 (insert 126 ∅))) : Finset (Fin 154))
    97 node589 node590
theorem node583 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 113 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 113 (insert 104 (insert 126 ∅))) : Finset (Fin 154))
    67 node587 node588
def entries585 : List (Fin 1589 × ℕ) := [(20, 14), (62, 45), (70, 8), (75, 65), (119, 3), (215, 5), (315, 6), (384, 4), (385, 4), (421, 7), (472, 20), (483, 7), (507, 16), (531, 21), (542, 13), (552, 11), (569, 5), (577, 1), (617, 25), (625, 12), (730, 17), (731, 31), (736, 16), (798, 4), (813, 18), (842, 9), (867, 2), (870, 30), (872, 7), (882, 6), (886, 2), (894, 23), (896, 4), (905, 4), (906, 4), (914, 13), (915, 9), (918, 18), (925, 25), (935, 21), (936, 4), (937, 4), (938, 16), (950, 14), (952, 21), (966, 19), (968, 10), (969, 3), (973, 51), (978, 18), (985, 16), (996, 10), (1006, 17), (1012, 4), (1049, 13), (1056, 17), (1070, 15), (1078, 1), (1114, 13), (1123, 13), (1142, 21), (1143, 8), (1167, 13), (1180, 5), (1181, 13), (1183, 8), (1186, 27), (1188, 7), (1212, 3), (1217, 2), (1219, 24), (1222, 1), (1233, 5), (1236, 28), (1258, 5), (1262, 7), (1272, 6), (1275, 5), (1280, 6), (1354, 9), (1358, 8), (1400, 15), (1466, 1), (1537, 3), (1545, 11), (1548, 3), (1576, 8), (1580, 9)]
def cs585 : List ℕ := [44, 31, 26, 38, 37, 47, 0, 101, 24, 61, 75, 99, 101, 99, 95, 20, 101, 99, 93, 45, 101, 100, 0, 101, 99, 101, 100, 99, 20, 100, 101, 101, 41, 13, 99, 100, 99, 15, 45, 100, 100, 100, 11, 100, 100, 99, 100, 0, 63, 100, 100, 100, 100, 100, 1, 100, 99, 96, 99, 79, 100, 100, 58, 59, 91, 67, 100, 257, 100, 101, 101, 99, 74, 99, 53, 100, 7, 86, 99, 100, 100, 101, 100, 98, 63, 92, 61, 98, 99, 100, 100, 99, 100, 100, 55, 13, 98, 98, 100, 99, 99, 99, 93, 84, 53, 99, 98, 78, 99, 61, 99, 99, 100, 26, 99, 77, 98, 71, 99, 61, 99, 89, 99, 98, 100, 81, 90, 99, 64, 99, 99, 64, 98, 98, 98, 98, 51, 82, 98, 99, 98, 97, 98, 99, 91, 69, 67, 99, 98, 94, 98, 99, 99, 99]
theorem loads585 : cs585.get =
    load (fun i : Fin entries585.length => support (entries585.get i).1)
      (fun i => (entries585.get i).2) := by
  apply load_eq_of_sparse_packed base cs585 support code
    entries585 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node585 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 113 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs585 support demand
    entries585 ((insert 113 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 104 (insert 126 ∅))) : Finset (Fin 154)) 100 30 loads585
  decide +kernel
def entries586 : List (Fin 1589 × ℕ) := [(10, 13), (43, 4), (70, 42), (77, 26), (86, 12), (122, 17), (343, 2), (421, 16), (472, 17), (483, 8), (507, 10), (526, 15), (542, 12), (571, 9), (577, 20), (583, 8), (585, 2), (617, 33), (731, 24), (736, 26), (813, 9), (819, 21), (842, 9), (846, 21), (870, 26), (872, 29), (882, 9), (886, 12), (923, 23), (925, 19), (929, 18), (939, 11), (940, 13), (943, 10), (947, 10), (952, 25), (966, 9), (968, 14), (973, 42), (978, 27), (985, 7), (1006, 14), (1009, 10), (1011, 8), (1012, 4), (1027, 2), (1049, 2), (1070, 22), (1075, 9), (1076, 8), (1078, 4), (1090, 17), (1114, 7), (1122, 19), (1123, 33), (1142, 25), (1143, 4), (1172, 7), (1173, 8), (1186, 19), (1188, 14), (1219, 11), (1228, 2), (1236, 23), (1247, 12), (1262, 7), (1263, 7), (1280, 28), (1310, 5), (1317, 23), (1370, 6), (1403, 9), (1469, 5), (1491, 14), (1575, 1), (1576, 19)]
def cs586 : List ℕ := [51, 60, 30, 11, 36, 59, 4, 100, 14, 10, 68, 100, 99, 42, 84, 40, 99, 101, 99, 9, 101, 93, 0, 100, 100, 100, 100, 100, 73, 46, 100, 100, 66, 0, 100, 100, 101, 0, 44, 100, 101, 89, 12, 90, 99, 100, 101, 18, 85, 100, 101, 81, 34, 99, 15, 101, 101, 101, 101, 55, 100, 101, 47, 101, 96, 57, 99, 0, 100, 97, 100, 100, 76, 101, 54, 100, 14, 73, 98, 100, 101, 100, 101, 102, 68, 99, 56, 99, 101, 100, 99, 88, 101, 100, 47, 7, 80, 100, 100, 99, 101, 100, 101, 62, 65, 73, 100, 96, 100, 43, 100, 99, 100, 8, 98, 99, 100, 28, 100, 52, 101, 100, 100, 98, 100, 81, 93, 100, 75, 99, 98, 49, 100, 100, 85, 99, 50, 58, 100, 99, 100, 74, 63, 100, 100, 42, 52, 99, 88, 88, 100, 88, 84, 63]
theorem loads586 : cs586.get =
    load (fun i : Fin entries586.length => support (entries586.get i).1)
      (fun i => (entries586.get i).2) := by
  apply load_eq_of_sparse_packed base cs586 support code
    entries586 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node586 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 113 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 104 (insert 126 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs586 support demand
    entries586 ((insert 67 (insert 113 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 104 (insert 126 ∅)) : Finset (Fin 154)) 100 30 loads586
  decide +kernel
theorem node584 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 113 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 104 (insert 126 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 113 (insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 104 (insert 126 ∅)) : Finset (Fin 154))
    67 node585 node586
theorem node582 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 104 (insert 126 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 104 (insert 126 ∅)) : Finset (Fin 154))
    113 node583 node584
theorem node580 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 104 (insert 126 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 95 (insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 104 (insert 126 ∅)) : Finset (Fin 154))
    47 node581 node582
#print axioms node580
end OmissionResidualCover
