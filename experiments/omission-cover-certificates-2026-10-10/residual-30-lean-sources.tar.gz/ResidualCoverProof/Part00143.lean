import ResidualCoverProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries427 : List (Fin 1589 × ℕ) := [(7, 27), (20, 4), (37, 25), (46, 24), (77, 36), (86, 27), (472, 32), (479, 26), (494, 5), (507, 20), (550, 7), (552, 1), (572, 2), (588, 43), (617, 28), (624, 2), (625, 26), (630, 11), (632, 8), (639, 2), (675, 15), (731, 23), (737, 6), (739, 10), (813, 31), (815, 11), (819, 6), (835, 13), (850, 41), (856, 15), (857, 14), (858, 25), (870, 21), (872, 18), (886, 22), (906, 30), (914, 17), (920, 9), (922, 4), (929, 26), (949, 12), (951, 42), (952, 7), (973, 43), (978, 39), (980, 3), (985, 1), (1004, 17), (1006, 33), (1017, 22), (1028, 6), (1049, 28), (1052, 19), (1081, 4), (1086, 2), (1090, 38), (1100, 2), (1103, 88), (1123, 36), (1133, 17), (1173, 21), (1220, 21), (1258, 35), (1263, 7), (1275, 12), (1277, 8), (1286, 1), (1295, 12), (1358, 14), (1458, 2), (1484, 8), (1486, 16), (1495, 9), (1517, 15), (1566, 5)]
def cs427 : List ℕ := [35, 50, 32, 66, 53, 42, 78, 100, 36, 20, 47, 100, 100, 49, 60, 17, 100, 258, 100, 27, 100, 58, 48, 100, 99, 101, 99, 99, 69, 72, 100, 100, 99, 0, 99, 100, 99, 196, 92, 100, 100, 89, 75, 94, 100, 101, 100, 100, 28, 100, 100, 100, 100, 100, 21, 100, 100, 100, 99, 86, 100, 57, 100, 78, 100, 100, 196, 100, 100, 100, 100, 99, 100, 76, 73, 101, 0, 100, 100, 101, 99, 100, 44, 99, 100, 100, 76, 101, 100, 100, 101, 100, 100, 101, 100, 0, 63, 200, 99, 86, 100, 172, 99, 100, 77, 100, 100, 101, 99, 0, 115, 101, 40, 149, 99, 101, 101, 0, 100, 160, 91, 100, 55, 101, 100, 100, 43, 284, 175, 101, 101, 43, 154, 100, 175, 101, 64, 43, 100, 100, 97, 97, 43, 100, 91, 143, 67, 81, 98, 64, 100, 72, 78, 63]
theorem loads427 : cs427.get =
    load (fun i : Fin entries427.length => support (entries427.get i).1)
      (fun i => (entries427.get i).2) := by
  apply load_eq_of_sparse_packed base cs427 support code
    entries427 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node427 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 110 (insert 132 (insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs427 support demand
    entries427 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 66 (insert 110 (insert 132 (insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))))))) : Finset (Fin 154)) 100 30 loads427
  decide +kernel
def entries428 : List (Fin 1589 × ℕ) := [(7, 15), (20, 6), (46, 12), (77, 32), (120, 4), (179, 19), (205, 3), (273, 17), (466, 3), (472, 16), (479, 32), (491, 25), (498, 7), (506, 2), (507, 24), (588, 29), (616, 24), (617, 21), (623, 15), (625, 9), (630, 5), (632, 17), (639, 1), (673, 8), (675, 2), (679, 11), (783, 5), (815, 19), (819, 8), (834, 19), (835, 16), (848, 13), (850, 49), (858, 27), (868, 1), (870, 7), (886, 47), (898, 5), (905, 3), (906, 21), (914, 19), (916, 20), (920, 7), (922, 17), (925, 2), (940, 21), (973, 43), (978, 49), (980, 7), (985, 7), (1001, 16), (1006, 33), (1012, 1), (1017, 31), (1052, 22), (1081, 27), (1090, 42), (1103, 100), (1122, 14), (1123, 43), (1133, 14), (1173, 16), (1220, 25), (1228, 1), (1246, 16), (1258, 43), (1263, 6), (1275, 14), (1358, 9), (1459, 14), (1493, 7), (1549, 4), (1566, 18), (1577, 10), (1584, 1)]
def cs428 : List ℕ := [37, 40, 29, 80, 47, 0, 74, 98, 19, 26, 33, 79, 99, 21, 54, 21, 100, 190, 100, 0, 100, 37, 78, 99, 86, 100, 100, 100, 78, 78, 99, 100, 99, 0, 100, 99, 99, 211, 100, 100, 99, 99, 89, 99, 100, 99, 99, 99, 53, 100, 99, 99, 100, 99, 29, 99, 100, 99, 99, 99, 100, 93, 100, 100, 100, 99, 16, 100, 100, 99, 92, 100, 100, 86, 58, 100, 0, 99, 100, 100, 100, 99, 43, 100, 99, 49, 87, 98, 100, 100, 73, 100, 100, 100, 99, 24, 97, 173, 100, 91, 99, 212, 100, 66, 45, 100, 99, 100, 101, 0, 125, 100, 61, 159, 90, 100, 100, 0, 100, 157, 49, 100, 35, 101, 101, 99, 43, 297, 171, 100, 101, 43, 170, 101, 190, 100, 59, 43, 101, 101, 101, 86, 44, 101, 100, 143, 60, 87, 101, 59, 101, 71, 86, 58]
theorem loads428 : cs428.get =
    load (fun i : Fin entries428.length => support (entries428.get i).1)
      (fun i => (entries428.get i).2) := by
  apply load_eq_of_sparse_packed base cs428 support code
    entries428 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node428 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 66 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 110 (insert 132 (insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs428 support demand
    entries428 ((insert 66 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 110 (insert 132 (insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))))))) : Finset (Fin 154)) 100 30 loads428
  decide +kernel
theorem node425 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 110 (insert 132 (insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 110 (insert 132 (insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))))))) : Finset (Fin 154))
    66 node427 node428
def entries426 : List (Fin 1589 × ℕ) := [(7, 26), (20, 15), (43, 2), (46, 29), (77, 20), (86, 7), (472, 14), (475, 9), (479, 31), (484, 1), (494, 26), (498, 3), (507, 9), (542, 9), (550, 12), (572, 24), (587, 5), (588, 44), (617, 16), (625, 31), (630, 39), (632, 6), (639, 26), (675, 1), (730, 17), (813, 35), (815, 3), (835, 30), (848, 2), (850, 52), (858, 45), (870, 15), (886, 35), (905, 2), (906, 34), (914, 11), (922, 15), (929, 19), (930, 2), (938, 5), (940, 1), (949, 26), (951, 15), (952, 21), (966, 9), (978, 17), (985, 26), (991, 1), (1004, 29), (1009, 34), (1012, 17), (1017, 2), (1033, 4), (1052, 6), (1070, 23), (1081, 5), (1086, 13), (1090, 20), (1094, 25), (1099, 4), (1100, 11), (1103, 100), (1122, 5), (1123, 32), (1149, 19), (1153, 17), (1160, 28), (1171, 5), (1173, 13), (1220, 10), (1222, 12), (1228, 29), (1246, 8), (1251, 3), (1258, 18), (1269, 6), (1275, 5), (1323, 11), (1471, 3), (1507, 1), (1517, 1), (1577, 8), (1582, 14), (1587, 5)]
def cs426 : List ℕ := [10, 53, 28, 100, 57, 27, 100, 100, 18, 9, 35, 68, 101, 46, 68, 40, 87, 233, 100, 24, 100, 60, 49, 80, 99, 100, 82, 99, 51, 102, 99, 101, 88, 5, 99, 100, 100, 236, 49, 99, 100, 98, 101, 100, 101, 100, 101, 101, 25, 99, 100, 100, 100, 100, 32, 100, 99, 100, 100, 101, 100, 75, 100, 100, 101, 100, 101, 100, 99, 100, 100, 99, 100, 100, 78, 100, 0, 99, 102, 100, 99, 100, 47, 100, 100, 75, 71, 101, 100, 100, 100, 100, 99, 100, 101, 0, 101, 176, 100, 100, 100, 121, 100, 100, 57, 100, 99, 101, 100, 0, 17, 102, 61, 139, 98, 94, 100, 9, 101, 114, 93, 100, 53, 100, 100, 71, 0, 226, 172, 101, 100, 0, 137, 100, 157, 100, 37, 0, 100, 101, 100, 69, 38, 98, 100, 100, 86, 49, 61, 48, 100, 19, 44, 62]
theorem loads426 : cs426.get =
    load (fun i : Fin entries426.length => support (entries426.get i).1)
      (fun i => (entries426.get i).2) := by
  apply load_eq_of_sparse_packed base cs426 support code
    entries426 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node426 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 110 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 132 (insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs426 support demand
    entries426 ((insert 110 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 132 (insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))))) : Finset (Fin 154)) 100 30 loads426
  decide +kernel
theorem node423 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 132 (insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 132 (insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))))) : Finset (Fin 154))
    110 node425 node426
def entries424 : List (Fin 1589 × ℕ) := [(7, 33), (20, 19), (37, 15), (46, 29), (77, 11), (86, 2), (179, 11), (431, 7), (466, 4), (472, 27), (475, 12), (479, 38), (491, 5), (498, 12), (507, 22), (587, 32), (588, 9), (616, 10), (617, 33), (625, 9), (630, 14), (632, 25), (639, 7), (675, 20), (730, 11), (813, 36), (833, 14), (850, 42), (856, 8), (858, 46), (868, 2), (870, 21), (872, 2), (886, 41), (894, 7), (906, 30), (914, 11), (916, 3), (920, 14), (921, 1), (922, 3), (925, 5), (929, 3), (940, 16), (949, 26), (951, 9), (952, 11), (966, 4), (975, 4), (978, 47), (985, 22), (1006, 24), (1021, 16), (1031, 11), (1040, 28), (1049, 6), (1081, 29), (1090, 14), (1094, 18), (1103, 100), (1123, 18), (1173, 14), (1220, 23), (1230, 14), (1234, 7), (1251, 18), (1277, 32), (1293, 14), (1360, 36), (1548, 4), (1565, 19), (1566, 1), (1577, 16), (1578, 5), (1584, 18)]
def cs424 : List ℕ := [27, 56, 27, 96, 76, 23, 101, 97, 46, 22, 18, 92, 101, 54, 61, 21, 100, 262, 101, 15, 101, 74, 72, 100, 100, 99, 100, 102, 40, 109, 100, 99, 100, 0, 100, 100, 99, 237, 67, 99, 99, 100, 87, 100, 100, 100, 99, 102, 49, 99, 100, 100, 100, 100, 14, 101, 99, 101, 101, 70, 100, 60, 101, 100, 99, 100, 101, 100, 99, 101, 100, 94, 100, 93, 54, 100, 0, 100, 99, 93, 100, 100, 67, 100, 101, 80, 79, 98, 100, 100, 100, 73, 100, 101, 65, 21, 100, 184, 101, 99, 100, 94, 100, 101, 60, 100, 100, 100, 100, 54, 91, 99, 83, 170, 101, 78, 100, 4, 94, 118, 101, 99, 50, 97, 100, 54, 0, 292, 186, 99, 100, 0, 0, 100, 196, 100, 14, 11, 100, 100, 100, 77, 32, 86, 100, 100, 46, 32, 64, 14, 100, 68, 54, 82]
theorem loads424 : cs424.get =
    load (fun i : Fin entries424.length => support (entries424.get i).1)
      (fun i => (entries424.get i).2) := by
  apply load_eq_of_sparse_packed base cs424 support code
    entries424 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node424 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 132 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs424 support demand
    entries424 ((insert 132 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))))) : Finset (Fin 154)) 100 30 loads424
  decide +kernel
theorem node419 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 101 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))))) : Finset (Fin 154))
    132 node423 node424
def entries421 : List (Fin 1589 × ℕ) := [(7, 390302), (20, 115706), (37, 406223), (46, 334258), (77, 125565), (179, 35865), (472, 270870), (479, 269476), (498, 2631), (507, 220502), (531, 27154), (542, 1144), (550, 19482), (583, 517), (587, 206919), (588, 275077), (616, 57635), (617, 341259), (625, 352702), (630, 223628), (632, 263198), (639, 94680), (675, 63884), (690, 40898), (730, 41426), (737, 173589), (813, 283613), (815, 28914), (819, 92173), (834, 10519), (835, 128644), (846, 70033), (850, 401496), (856, 109733), (858, 443044), (870, 176190), (886, 339509), (906, 196114), (914, 211634), (920, 138139), (922, 77893), (925, 79150), (930, 25404), (940, 190857), (949, 249104), (951, 4523), (952, 65674), (963, 74737), (966, 90312), (978, 360110), (985, 18970), (991, 30649), (1004, 203510), (1006, 320914), (1012, 238394), (1061, 148367), (1070, 14363), (1076, 61269), (1081, 295540), (1093, 79878), (1094, 87881), (1100, 47361), (1103, 938731), (1108, 253840), (1111, 38332), (1122, 28751), (1123, 402206), (1149, 459054), (1173, 139338), (1212, 60670), (1220, 184295), (1233, 48766), (1234, 68373), (1251, 244811), (1276, 490088), (1277, 47036), (1285, 96519), (1358, 205326), (1486, 22504), (1491, 19918), (1501, 41350), (1548, 11064), (1549, 80308), (1565, 106952), (1577, 166192)]
def cs421 : List ℕ := [389621, 644630, 270870, 798016, 659778, 515956, 943494, 1000000, 621079, 220502, 125565, 828522, 1000000, 629681, 627159, 205592, 1000000, 2475434, 999999, 406223, 1000001, 725077, 666163, 925583, 989597, 1000000, 999999, 1000000, 585219, 1184289, 1000000, 1000000, 999999, 0, 1000000, 1000000, 1000000, 2339490, 768382, 999999, 1000000, 1000001, 1000000, 1000000, 1000000, 1427917, 1000001, 1000000, 252616, 1000000, 1000000, 999999, 1000001, 1000000, 139338, 1000001, 1000000, 1000000, 999999, 1000001, 1000000, 503807, 1000000, 986494, 1000001, 1000000, 999999, 1000000, 1000000, 1000000, 963333, 1000000, 1000001, 1000000, 665578, 1000000, 0, 1000001, 1000000, 735121, 1000000, 1000001, 566168, 1000000, 1000000, 474615, 949815, 1000001, 999999, 999177, 1000000, 1000000, 1000001, 1000002, 836361, 57635, 1000000, 1682752, 1000000, 1000001, 1000000, 360110, 1000001, 1000000, 494960, 1000000, 1000000, 999999, 1000001, 146471, 996133, 1000000, 518470, 1658443, 1000000, 1000000, 1000001, 150982, 1000000, 1183542, 715882, 999999, 510493, 1000001, 1000001, 919306, 0, 2352576, 1700337, 999999, 1000001, 0, 977004, 999999, 1763214, 1000001, 598392, 0, 1000001, 1000000, 1000000, 908295, 415516, 1000001, 1000000, 938731, 1000000, 401608, 1000000, 659062, 891370, 305481, 795569, 646560]
theorem loads421 : cs421.get =
    load (fun i : Fin entries421.length => support (entries421.get i).1)
      (fun i => (entries421.get i).2) := by
  apply load_eq_of_sparse_packed base cs421 support code
    entries421 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node421 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 101 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 45 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs421 support demand
    entries421 ((insert 101 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 45 (insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))))) : Finset (Fin 154)) 1000000 30 loads421
  decide +kernel
def entries422 : List (Fin 1589 × ℕ) := [(7, 158), (46, 85), (77, 306), (86, 101), (472, 182), (475, 216), (479, 313), (483, 38), (484, 15), (498, 13), (507, 273), (542, 128), (571, 95), (572, 41), (587, 76), (588, 353), (617, 308), (625, 122), (630, 204), (632, 1), (639, 69), (675, 207), (681, 52), (730, 166), (737, 165), (813, 346), (819, 24), (833, 117), (834, 28), (835, 116), (844, 136), (849, 251), (850, 108), (854, 64), (858, 258), (868, 34), (870, 239), (886, 397), (904, 52), (906, 102), (914, 470), (916, 188), (920, 30), (930, 68), (939, 74), (940, 238), (949, 127), (951, 83), (952, 140), (966, 42), (978, 355), (1004, 218), (1006, 418), (1033, 265), (1049, 346), (1061, 162), (1076, 52), (1090, 70), (1093, 68), (1094, 296), (1103, 948), (1108, 174), (1111, 24), (1123, 122), (1139, 15), (1149, 346), (1173, 235), (1220, 138), (1234, 38), (1240, 27), (1251, 252), (1257, 48), (1276, 418), (1293, 38), (1320, 213), (1358, 20), (1493, 68), (1549, 110), (1577, 76), (1578, 210)]
def cs422 : List ℕ := [294, 296, 182, 713, 681, 117, 629, 999, 13, 273, 550, 1000, 999, 158, 805, 354, 1000, 1829, 1001, 136, 1000, 453, 497, 999, 1001, 937, 1001, 1001, 428, 787, 999, 1000, 1001, 136, 1000, 1000, 1001, 2082, 491, 1000, 1001, 999, 1001, 998, 1000, 108, 1000, 1002, 204, 1000, 1000, 684, 832, 999, 299, 1000, 1000, 1001, 1001, 995, 999, 613, 1001, 1001, 999, 463, 999, 1001, 1001, 1001, 998, 957, 1001, 701, 673, 999, 0, 999, 1000, 862, 1002, 999, 481, 999, 1001, 999, 654, 999, 1000, 1000, 999, 1000, 1000, 999, 1000, 0, 962, 2282, 1000, 1000, 999, 425, 999, 1000, 889, 1000, 999, 999, 999, 0, 999, 999, 820, 1555, 999, 999, 1000, 42, 999, 1200, 981, 999, 627, 734, 999, 999, 0, 2476, 1644, 999, 999, 0, 916, 999, 1773, 998, 581, 0, 998, 902, 999, 927, 352, 967, 806, 948, 881, 316, 999, 581, 946, 252, 931, 418]
theorem loads422 : cs422.get =
    load (fun i : Fin entries422.length => support (entries422.get i).1)
      (fun i => (entries422.get i).2) := by
  apply load_eq_of_sparse_packed base cs422 support code
    entries422 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node422 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 45 (insert 101 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs422 support demand
    entries422 ((insert 45 (insert 101 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))) : Finset (Fin 154)) 1000 30 loads422
  decide +kernel
theorem node420 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 101 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 101 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))) : Finset (Fin 154))
    45 node421 node422
theorem node417 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 29 (insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))))) : Finset (Fin 154))
    101 node419 node420
def entries418 : List (Fin 1589 × ℕ) := [(7, 172), (72, 43), (77, 306), (83, 95), (86, 67), (271, 79), (273, 3), (472, 259), (479, 246), (491, 57), (494, 95), (507, 187), (587, 62), (588, 23), (616, 172), (617, 153), (639, 93), (675, 140), (681, 18), (730, 209), (813, 279), (833, 80), (835, 156), (843, 22), (850, 429), (856, 50), (858, 474), (870, 147), (872, 167), (886, 362), (905, 129), (906, 250), (916, 7), (920, 19), (922, 211), (929, 121), (938, 337), (939, 67), (952, 235), (966, 28), (973, 189), (978, 388), (985, 56), (1004, 166), (1006, 319), (1012, 158), (1021, 44), (1040, 80), (1061, 18), (1081, 310), (1086, 32), (1090, 388), (1094, 172), (1103, 1000), (1123, 290), (1133, 58), (1149, 136), (1153, 25), (1165, 25), (1173, 228), (1220, 196), (1246, 146), (1251, 176), (1263, 143), (1276, 437), (1293, 54), (1320, 172), (1358, 24), (1457, 158), (1486, 81), (1517, 20), (1548, 66), (1558, 18), (1565, 237), (1566, 97), (1577, 70), (1584, 3), (1587, 21)]
def cs418 : List ℕ := [378, 389, 259, 625, 418, 208, 621, 999, 143, 187, 507, 855, 1000, 360, 419, 91, 999, 2013, 1000, 0, 999, 333, 437, 999, 916, 1000, 1000, 999, 701, 0, 1000, 999, 747, 0, 1000, 1000, 1000, 1487, 968, 1000, 1000, 832, 730, 1000, 1000, 945, 1000, 1000, 689, 1000, 1000, 1001, 373, 1000, 228, 1000, 999, 947, 1000, 838, 1001, 979, 1000, 1000, 893, 1000, 1002, 999, 1001, 1000, 1001, 804, 1000, 772, 710, 1000, 0, 1000, 1000, 1000, 1000, 999, 392, 1000, 999, 758, 787, 999, 1000, 1001, 1001, 1000, 1001, 1000, 855, 172, 1001, 1815, 999, 1000, 1000, 1000, 1000, 999, 381, 1000, 1000, 1001, 1000, 66, 965, 999, 907, 1678, 920, 836, 1001, 28, 1000, 1423, 1000, 1000, 697, 1000, 1000, 916, 214, 2537, 1741, 1000, 1000, 189, 1000, 999, 1830, 1000, 553, 189, 999, 1000, 999, 943, 365, 901, 1000, 1189, 729, 580, 974, 553, 999, 423, 999, 626]
theorem loads418 : cs418.get =
    load (fun i : Fin entries418.length => support (entries418.get i).1)
      (fun i => (entries418.get i).2) := by
  apply load_eq_of_sparse_packed base cs418 support code
    entries418 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node418 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 29 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs418 support demand
    entries418 ((insert 29 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))) : Finset (Fin 154)) 1000 30 loads418
  decide +kernel
theorem node413 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 17 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))) : Finset (Fin 154))
    29 node417 node418
def entries415 : List (Fin 1589 × ℕ) := [(120, 15), (179, 414), (203, 12), (271, 55), (384, 28), (466, 253), (475, 112), (478, 216), (479, 187), (484, 372), (491, 357), (494, 155), (498, 66), (507, 171), (527, 15), (530, 101), (531, 36), (570, 7), (572, 122), (587, 210), (588, 24), (616, 37), (617, 342), (625, 258), (630, 24), (639, 325), (675, 1), (730, 45), (813, 68), (815, 117), (835, 340), (855, 161), (867, 112), (872, 33), (885, 121), (886, 233), (893, 61), (894, 109), (898, 256), (905, 185), (906, 354), (914, 562), (922, 333), (930, 39), (937, 128), (940, 106), (949, 141), (950, 201), (951, 17), (952, 95), (973, 186), (984, 373), (1004, 96), (1006, 131), (1007, 30), (1012, 103), (1033, 148), (1040, 167), (1049, 28), (1061, 95), (1090, 270), (1094, 268), (1103, 989), (1123, 281), (1149, 131), (1153, 154), (1160, 165), (1173, 434), (1177, 11), (1227, 96), (1228, 141), (1236, 13), (1251, 84), (1257, 23), (1276, 314), (1280, 7), (1320, 17), (1360, 70), (1469, 138), (1565, 55), (1577, 258)]
def cs415 : List ℕ := [273, 7, 0, 112, 416, 553, 615, 831, 66, 171, 112, 1000, 999, 170, 258, 273, 999, 0, 1000, 122, 1000, 281, 959, 1000, 1000, 1000, 1002, 1000, 466, 1000, 952, 1001, 999, 0, 1000, 1000, 1000, 2503, 619, 1000, 1001, 1000, 1000, 999, 1000, 1000, 999, 999, 652, 1001, 1000, 998, 763, 999, 434, 1001, 1000, 999, 1000, 1000, 1000, 723, 972, 999, 999, 670, 999, 1000, 1000, 1000, 999, 939, 1000, 826, 720, 1000, 11, 958, 1000, 999, 1000, 1000, 725, 1000, 999, 652, 685, 999, 1000, 1000, 999, 1001, 1000, 999, 827, 55, 999, 1557, 2094, 1000, 1000, 1000, 999, 999, 815, 1000, 1001, 999, 1001, 70, 690, 999, 720, 1435, 1001, 985, 1001, 0, 912, 1270, 986, 1000, 624, 1000, 1001, 882, 197, 2353, 1366, 1000, 1000, 197, 1001, 1000, 1739, 1000, 762, 186, 1000, 1000, 1001, 946, 434, 1001, 1001, 1186, 999, 620, 776, 751, 1000, 351, 848, 876]
theorem loads415 : cs415.get =
    load (fun i : Fin entries415.length => support (entries415.get i).1)
      (fun i => (entries415.get i).2) := by
  apply load_eq_of_sparse_packed base cs415 support code
    entries415 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node415 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 17 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs415 support demand
    entries415 ((insert 17 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 98 (insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))) : Finset (Fin 154)) 1000 30 loads415
  decide +kernel
def entries416 : List (Fin 1589 × ℕ) := [(62, 6), (120, 28), (384, 23), (466, 21), (472, 15), (475, 2), (478, 16), (491, 15), (494, 9), (507, 15), (531, 2), (555, 3), (571, 7), (572, 21), (581, 4), (587, 14), (588, 27), (617, 11), (625, 26), (630, 29), (639, 7), (675, 10), (730, 15), (737, 13), (797, 1), (812, 4), (813, 43), (834, 8), (835, 13), (855, 38), (867, 2), (872, 13), (883, 7), (886, 18), (894, 1), (897, 6), (905, 22), (914, 14), (916, 11), (922, 2), (925, 29), (940, 20), (944, 12), (952, 8), (973, 15), (984, 30), (1006, 10), (1012, 14), (1017, 9), (1028, 3), (1033, 33), (1040, 6), (1049, 32), (1052, 2), (1056, 5), (1061, 8), (1090, 16), (1094, 43), (1100, 2), (1103, 80), (1108, 2), (1149, 13), (1153, 18), (1160, 40), (1169, 5), (1173, 33), (1177, 7), (1186, 11), (1228, 15), (1246, 15), (1251, 22), (1268, 14), (1276, 6), (1280, 15), (1358, 23), (1403, 3), (1471, 27), (1491, 7), (1493, 1), (1537, 1), (1577, 24), (1585, 9), (1588, 1)]
def cs416 : List ℕ := [59, 15, 16, 2, 16, 54, 39, 100, 1, 21, 2, 100, 100, 36, 24, 63, 100, 0, 100, 48, 100, 60, 48, 100, 100, 100, 100, 100, 54, 43, 100, 101, 95, 5, 99, 101, 100, 175, 49, 101, 100, 99, 93, 93, 101, 100, 100, 101, 30, 101, 99, 100, 100, 100, 33, 100, 98, 100, 100, 101, 101, 100, 99, 99, 99, 100, 99, 100, 100, 100, 99, 99, 100, 100, 80, 100, 7, 98, 100, 101, 98, 100, 88, 99, 100, 100, 83, 100, 100, 100, 101, 100, 101, 99, 92, 12, 101, 230, 14, 101, 99, 100, 99, 100, 83, 100, 100, 101, 99, 11, 62, 99, 92, 145, 24, 100, 100, 23, 73, 124, 100, 72, 81, 100, 99, 76, 22, 237, 130, 100, 100, 27, 100, 100, 145, 100, 68, 20, 100, 100, 99, 99, 62, 100, 76, 102, 100, 64, 65, 72, 95, 55, 72, 87]
theorem loads416 : cs416.get =
    load (fun i : Fin entries416.length => support (entries416.get i).1)
      (fun i => (entries416.get i).2) := by
  apply load_eq_of_sparse_packed base cs416 support code
    entries416 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node416 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 98 (insert 17 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs416 support demand
    entries416 ((insert 98 (insert 17 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154)) 100 30 loads416
  decide +kernel
theorem node414 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 17 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 17 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154))
    98 node415 node416
theorem node409 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 145 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154))
    17 node413 node414
def entries411 : List (Fin 1589 × ℕ) := [(46, 95), (77, 241), (120, 123), (122, 323), (135, 74), (177, 118), (179, 97), (353, 4), (384, 98), (466, 245), (472, 97), (475, 217), (478, 68), (479, 139), (491, 45), (494, 100), (507, 247), (514, 39), (531, 9), (570, 40), (571, 154), (572, 228), (588, 230), (617, 206), (625, 161), (630, 318), (632, 43), (639, 102), (675, 313), (730, 15), (736, 30), (739, 68), (813, 221), (815, 16), (834, 49), (835, 68), (850, 86), (855, 252), (858, 279), (870, 101), (872, 37), (886, 432), (896, 26), (897, 220), (904, 74), (906, 173), (914, 325), (916, 58), (920, 101), (921, 35), (922, 207), (928, 12), (940, 134), (949, 173), (952, 183), (978, 433), (1004, 148), (1006, 365), (1010, 144), (1012, 25), (1017, 11), (1028, 159), (1031, 3), (1033, 179), (1040, 136), (1049, 311), (1061, 216), (1076, 1), (1090, 250), (1094, 345), (1098, 81), (1123, 333), (1133, 15), (1149, 269), (1160, 190), (1173, 284), (1251, 250), (1263, 87), (1276, 405), (1280, 114), (1320, 72), (1459, 12), (1471, 108), (1491, 23), (1501, 200), (1517, 6), (1552, 5), (1565, 66), (1577, 273)]
def cs411 : List ℕ := [359, 114, 97, 303, 207, 366, 698, 763, 87, 247, 280, 1001, 1001, 46, 609, 742, 1001, 1000, 1002, 382, 1001, 762, 931, 1000, 1001, 999, 1000, 1000, 914, 1001, 1000, 1000, 989, 0, 1000, 1000, 1001, 2604, 657, 1000, 1000, 1001, 1001, 1000, 1000, 1002, 1000, 1001, 619, 1000, 1001, 999, 1001, 1001, 284, 1001, 1978, 1001, 1001, 1000, 1000, 742, 1000, 1000, 1001, 1002, 1000, 1000, 1000, 1001, 1000, 1001, 1000, 1001, 893, 1001, 0, 1000, 999, 1000, 1001, 1001, 603, 1001, 1001, 1000, 683, 1001, 1001, 1000, 1000, 1001, 1000, 1001, 1000, 187, 999, 1393, 1000, 1000, 1001, 1000, 1002, 1001, 801, 287, 1001, 1000, 894, 0, 799, 1000, 545, 621, 1000, 1000, 1000, 0, 999, 409, 728, 1000, 800, 756, 1000, 918, 0, 1722, 638, 1000, 999, 144, 927, 1000, 686, 1000, 553, 3, 999, 1000, 1000, 1000, 332, 883, 1000, 0, 803, 250, 727, 553, 1000, 265, 727, 595]
theorem loads411 : cs411.get =
    load (fun i : Fin entries411.length => support (entries411.get i).1)
      (fun i => (entries411.get i).2) := by
  apply load_eq_of_sparse_packed base cs411 support code
    entries411 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node411 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 145 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 56 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs411 support demand
    entries411 ((insert 145 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 56 (insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154)) 1000 30 loads411
  decide +kernel
def entries412 : List (Fin 1589 × ℕ) := [(43, 102), (62, 49), (70, 148), (72, 113), (273, 39), (384, 181), (466, 73), (472, 19), (475, 88), (479, 477), (484, 171), (491, 309), (507, 288), (542, 26), (571, 8), (588, 94), (616, 211), (617, 280), (625, 254), (631, 33), (639, 121), (737, 88), (813, 142), (819, 94), (835, 73), (843, 30), (844, 54), (848, 9), (855, 271), (870, 130), (886, 279), (895, 157), (896, 107), (905, 119), (906, 301), (911, 27), (912, 7), (914, 222), (920, 227), (922, 62), (925, 104), (928, 147), (940, 85), (948, 47), (949, 139), (951, 51), (960, 125), (963, 8), (978, 555), (985, 49), (1004, 223), (1006, 222), (1012, 174), (1040, 107), (1052, 159), (1076, 166), (1081, 203), (1086, 52), (1090, 144), (1094, 261), (1101, 37), (1111, 2), (1123, 351), (1133, 93), (1149, 353), (1160, 1), (1173, 286), (1188, 41), (1212, 29), (1220, 159), (1222, 77), (1236, 108), (1240, 157), (1251, 237), (1276, 445), (1293, 22), (1320, 123), (1379, 100), (1471, 2), (1489, 168), (1493, 94), (1495, 14), (1552, 137), (1565, 109), (1577, 56), (1580, 24), (1584, 90)]
def cs412 : List ℕ := [394, 236, 105, 247, 609, 627, 467, 1000, 0, 337, 375, 1000, 1001, 73, 469, 164, 1000, 1000, 1001, 57, 1000, 616, 297, 1000, 999, 1000, 1000, 998, 476, 833, 1001, 1000, 1001, 54, 1000, 1000, 997, 1889, 743, 1000, 999, 1000, 999, 1001, 1000, 1000, 999, 999, 150, 1000, 1000, 1000, 999, 1000, 372, 999, 0, 999, 1000, 1001, 1001, 610, 999, 999, 1000, 1000, 1000, 999, 1001, 999, 1001, 1001, 1000, 694, 508, 1000, 166, 1001, 1000, 1000, 999, 1001, 766, 1001, 1000, 508, 807, 1000, 1000, 1000, 1001, 1001, 1000, 999, 929, 211, 1000, 705, 1001, 1000, 1001, 1000, 1000, 1000, 566, 454, 1001, 1000, 1001, 37, 943, 1000, 723, 976, 1001, 793, 1001, 29, 1000, 367, 803, 1000, 645, 899, 959, 861, 0, 1638, 782, 1000, 1000, 0, 1001, 1001, 826, 1000, 639, 0, 1001, 1000, 1001, 986, 432, 740, 1001, 0, 905, 265, 834, 668, 1001, 359, 834, 475]
theorem loads412 : cs412.get =
    load (fun i : Fin entries412.length => support (entries412.get i).1)
      (fun i => (entries412.get i).2) := by
  apply load_eq_of_sparse_packed base cs412 support code
    entries412 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node412 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 56 (insert 145 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs412 support demand
    entries412 ((insert 56 (insert 145 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)) 1000 30 loads412
  decide +kernel
theorem node410 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 145 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 145 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154))
    56 node411 node412
theorem node401 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 37 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154))
    145 node409 node410
def entries403 : List (Fin 1589 × ℕ) := [(7, 1), (20, 254), (72, 63), (75, 62), (77, 13), (86, 25), (122, 401), (137, 23), (177, 145), (203, 24), (384, 179), (387, 185), (419, 13), (466, 150), (469, 129), (472, 51), (479, 222), (494, 22), (496, 10), (507, 342), (515, 106), (531, 103), (542, 144), (551, 120), (571, 144), (616, 153), (617, 135), (675, 102), (680, 144), (731, 110), (737, 82), (739, 34), (843, 27), (870, 355), (886, 280), (894, 78), (895, 306), (904, 130), (920, 123), (923, 105), (925, 181), (928, 189), (938, 88), (940, 271), (946, 1), (952, 97), (978, 150), (984, 384), (1004, 181), (1006, 444), (1012, 78), (1017, 24), (1028, 146), (1031, 242), (1033, 144), (1049, 85), (1052, 54), (1061, 64), (1081, 201), (1094, 115), (1103, 1000), (1123, 259), (1133, 209), (1149, 327), (1173, 229), (1188, 241), (1212, 47), (1220, 215), (1227, 23), (1251, 144), (1252, 51), (1257, 157), (1267, 81), (1276, 374), (1292, 174), (1293, 66), (1320, 226), (1339, 189), (1471, 48), (1485, 6), (1489, 162), (1499, 60), (1580, 211)]
def cs403 : List ℕ := [365, 345, 51, 469, 434, 174, 0, 1000, 264, 342, 418, 874, 549, 569, 493, 521, 999, 1000, 1000, 144, 1000, 1000, 145, 1000, 970, 999, 999, 1000, 618, 461, 1000, 1000, 628, 0, 1000, 1000, 1000, 0, 739, 1000, 1000, 1000, 407, 1000, 1000, 1000, 1001, 999, 898, 1000, 1000, 999, 723, 1000, 289, 1001, 1000, 999, 1000, 1001, 999, 1000, 924, 859, 946, 1000, 999, 1000, 999, 1000, 1000, 999, 1000, 1001, 695, 1000, 242, 732, 999, 1000, 1000, 1000, 988, 999, 772, 1000, 512, 1001, 2740, 1000, 999, 1001, 1000, 1000, 413, 395, 1000, 2184, 1000, 1000, 1000, 1000, 1000, 999, 449, 1000, 1000, 1000, 991, 47, 978, 999, 630, 2214, 1000, 879, 1000, 53, 1000, 1404, 560, 1000, 1000, 999, 999, 1000, 0, 2755, 1727, 1000, 999, 0, 1001, 999, 1840, 999, 556, 242, 999, 999, 1000, 842, 399, 711, 999, 1000, 955, 204, 999, 654, 999, 400, 999, 421]
theorem loads403 : cs403.get =
    load (fun i : Fin entries403.length => support (entries403.get i).1)
      (fun i => (entries403.get i).2) := by
  apply load_eq_of_sparse_packed base cs403 support code
    entries403 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node403 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs403 support demand
    entries403 ((insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 88 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)) 1000 30 loads403
  decide +kernel
def entries407 : List (Fin 1589 × ℕ) := [(7, 97), (17, 125), (20, 407), (43, 41), (46, 430), (72, 211), (77, 134), (179, 122), (271, 11), (384, 259), (472, 138), (479, 238), (507, 355), (515, 48), (527, 37), (531, 10), (542, 68), (551, 85), (552, 117), (583, 35), (616, 109), (617, 218), (625, 231), (731, 275), (737, 364), (739, 39), (813, 260), (815, 4), (835, 134), (844, 90), (846, 5), (856, 49), (868, 135), (869, 149), (870, 78), (872, 66), (881, 19), (886, 154), (905, 150), (906, 23), (920, 63), (922, 63), (925, 358), (929, 152), (930, 23), (938, 155), (940, 114), (949, 43), (952, 115), (966, 12), (973, 134), (978, 354), (1004, 265), (1006, 362), (1012, 246), (1017, 102), (1030, 217), (1040, 29), (1049, 1), (1055, 6), (1076, 150), (1081, 272), (1086, 116), (1090, 70), (1093, 169), (1123, 250), (1133, 90), (1149, 294), (1160, 18), (1171, 97), (1173, 113), (1186, 93), (1212, 143), (1220, 468), (1227, 106), (1234, 19), (1246, 75), (1257, 31), (1263, 166), (1276, 250), (1292, 131), (1312, 158), (1317, 1), (1320, 243), (1335, 29), (1358, 61), (1403, 146), (1551, 96)]
def cs407 : List ℕ := [619, 570, 138, 1000, 335, 180, 471, 1000, 698, 355, 659, 756, 1002, 801, 884, 221, 1000, 2244, 1000, 0, 1001, 1000, 122, 1001, 999, 1001, 1000, 1001, 672, 1000, 1000, 999, 724, 187, 1000, 1001, 1000, 0, 1000, 999, 1000, 1000, 515, 1001, 1000, 1576, 1001, 1000, 649, 999, 1000, 1000, 1000, 1001, 210, 1000, 1000, 1001, 999, 994, 1000, 999, 999, 1000, 1001, 1000, 1001, 999, 999, 1000, 1001, 1000, 999, 981, 633, 1001, 0, 805, 1000, 999, 999, 1000, 718, 999, 829, 893, 837, 1000, 0, 1000, 1000, 999, 1000, 999, 536, 326, 1000, 904, 999, 965, 999, 999, 999, 999, 429, 519, 999, 1001, 1000, 236, 1000, 1000, 485, 846, 999, 821, 999, 248, 1000, 441, 1000, 999, 719, 999, 998, 1000, 134, 1717, 753, 999, 999, 351, 998, 999, 581, 999, 638, 140, 999, 1000, 972, 940, 487, 998, 998, 134, 841, 471, 999, 903, 831, 461, 924, 638]
theorem loads407 : cs407.get =
    load (fun i : Fin entries407.length => support (entries407.get i).1)
      (fun i => (entries407.get i).2) := by
  apply load_eq_of_sparse_packed base cs407 support code
    entries407 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node407 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 17 (insert 45 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs407 support demand
    entries407 ((insert 88 (insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 17 (insert 45 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154)) 1000 30 loads407
  decide +kernel
def entries408 : List (Fin 1589 × ℕ) := [(35, 48), (75, 13), (120, 15), (179, 39), (384, 21), (466, 34), (507, 9), (526, 5), (542, 8), (552, 15), (570, 18), (572, 28), (617, 2), (625, 19), (731, 8), (737, 42), (739, 1), (777, 3), (813, 25), (819, 4), (835, 8), (856, 3), (863, 10), (864, 13), (872, 19), (883, 8), (893, 5), (894, 15), (905, 20), (916, 6), (919, 5), (920, 12), (925, 41), (929, 7), (938, 15), (940, 13), (944, 5), (952, 2), (973, 27), (984, 27), (1004, 13), (1006, 16), (1012, 26), (1017, 18), (1030, 6), (1033, 7), (1049, 32), (1055, 5), (1056, 2), (1070, 1), (1076, 18), (1081, 2), (1086, 4), (1090, 11), (1093, 12), (1123, 31), (1133, 11), (1149, 12), (1160, 22), (1173, 27), (1186, 14), (1212, 20), (1236, 19), (1246, 22), (1257, 1), (1267, 17), (1268, 6), (1276, 5), (1280, 14), (1310, 1), (1312, 17), (1320, 8), (1358, 23), (1403, 23), (1471, 11), (1490, 13), (1518, 3), (1559, 1), (1587, 8)]
def cs408 : List ℕ := [90, 25, 0, 0, 19, 87, 0, 101, 48, 35, 13, 101, 101, 81, 21, 54, 101, 0, 100, 34, 101, 76, 39, 101, 101, 99, 101, 101, 53, 100, 101, 101, 71, 0, 101, 101, 101, 0, 100, 100, 91, 101, 33, 71, 100, 183, 100, 100, 88, 100, 100, 101, 77, 100, 27, 101, 100, 99, 100, 100, 100, 100, 88, 100, 100, 100, 100, 101, 100, 100, 101, 99, 100, 100, 71, 101, 16, 90, 101, 100, 101, 101, 100, 100, 100, 101, 90, 100, 0, 99, 101, 100, 101, 100, 48, 24, 102, 108, 100, 96, 101, 100, 99, 100, 62, 54, 100, 101, 99, 34, 88, 101, 56, 71, 86, 76, 99, 39, 83, 44, 74, 101, 75, 100, 90, 82, 27, 181, 67, 101, 101, 33, 97, 101, 50, 100, 66, 32, 101, 100, 88, 101, 68, 100, 100, 27, 87, 73, 73, 100, 87, 72, 75, 88]
theorem loads408 : cs408.get =
    load (fun i : Fin entries408.length => support (entries408.get i).1)
      (fun i => (entries408.get i).2) := by
  apply load_eq_of_sparse_packed base cs408 support code
    entries408 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node408 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 17 (insert 88 (insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 45 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs408 support demand
    entries408 ((insert 17 (insert 88 (insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 45 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)) 100 30 loads408
  decide +kernel
theorem node405 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 45 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 45 (insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154))
    17 node407 node408
def entries406 : List (Fin 1589 × ℕ) := [(7, 11), (10, 4), (75, 52), (77, 11), (120, 4), (384, 13), (466, 8), (472, 7), (479, 10), (483, 2), (507, 27), (515, 7), (531, 12), (542, 9), (552, 12), (577, 4), (616, 5), (617, 20), (625, 30), (639, 2), (731, 26), (737, 36), (740, 15), (813, 24), (835, 14), (844, 9), (868, 10), (869, 6), (870, 18), (871, 7), (886, 14), (905, 11), (906, 9), (922, 12), (929, 27), (937, 12), (938, 16), (939, 16), (940, 2), (944, 8), (950, 11), (952, 9), (973, 21), (978, 24), (1004, 41), (1006, 30), (1010, 5), (1028, 22), (1030, 24), (1033, 9), (1040, 9), (1049, 17), (1061, 5), (1076, 25), (1081, 9), (1093, 29), (1100, 2), (1111, 1), (1123, 8), (1133, 16), (1149, 14), (1173, 29), (1186, 17), (1212, 19), (1219, 32), (1227, 7), (1234, 22), (1236, 2), (1246, 1), (1263, 19), (1276, 7), (1320, 24), (1358, 10), (1360, 3), (1403, 14), (1498, 19), (1580, 11), (1584, 4), (1587, 12)]
def cs406 : List ℕ := [29, 55, 11, 32, 38, 23, 0, 101, 19, 27, 80, 88, 101, 57, 83, 47, 101, 100, 101, 0, 102, 97, 0, 101, 101, 100, 101, 101, 45, 52, 101, 100, 58, 9, 100, 87, 101, 0, 72, 100, 100, 100, 68, 79, 100, 0, 100, 100, 49, 100, 99, 99, 81, 100, 29, 99, 100, 100, 100, 100, 99, 100, 100, 100, 100, 99, 100, 99, 101, 100, 99, 100, 100, 98, 74, 100, 0, 99, 101, 101, 99, 100, 58, 100, 78, 100, 71, 101, 0, 101, 100, 100, 100, 99, 90, 34, 101, 112, 98, 100, 100, 100, 99, 100, 66, 83, 99, 100, 100, 39, 100, 100, 72, 76, 100, 100, 100, 44, 100, 66, 93, 100, 90, 78, 101, 94, 21, 192, 56, 101, 100, 50, 100, 101, 62, 101, 64, 21, 101, 100, 100, 99, 65, 100, 78, 21, 85, 62, 100, 100, 72, 76, 91, 67]
theorem loads406 : cs406.get =
    load (fun i : Fin entries406.length => support (entries406.get i).1)
      (fun i => (entries406.get i).2) := by
  apply load_eq_of_sparse_packed base cs406 support code
    entries406 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node406 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 45 (insert 88 (insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs406 support demand
    entries406 ((insert 45 (insert 88 (insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)) 100 30 loads406
  decide +kernel
theorem node404 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154))
    45 node405 node406
theorem node402 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154))
    88 node403 node404
theorem node387 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 97 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154))
    37 node401 node402
def entries399 : List (Fin 1589 × ℕ) := [(86, 5), (122, 3), (177, 19), (466, 10), (472, 5), (475, 10), (490, 28), (491, 49), (507, 4), (530, 12), (551, 1), (572, 4), (583, 19), (588, 24), (616, 3), (617, 45), (625, 24), (632, 19), (639, 14), (731, 23), (738, 21), (780, 1), (819, 18), (842, 14), (846, 15), (857, 23), (865, 26), (867, 50), (868, 12), (872, 16), (881, 4), (886, 10), (890, 6), (896, 18), (898, 12), (906, 41), (912, 5), (914, 21), (922, 9), (925, 1), (928, 1), (947, 11), (948, 10), (951, 17), (952, 9), (960, 30), (963, 12), (966, 17), (973, 32), (978, 32), (985, 2), (1006, 35), (1012, 18), (1040, 18), (1049, 16), (1055, 4), (1061, 15), (1081, 19), (1090, 31), (1093, 12), (1094, 18), (1098, 16), (1122, 6), (1123, 29), (1139, 18), (1173, 12), (1186, 19), (1212, 2), (1219, 24), (1236, 15), (1263, 6), (1267, 6), (1268, 4), (1276, 31), (1280, 10), (1358, 16), (1374, 2), (1379, 1), (1489, 2), (1493, 24), (1494, 8), (1552, 1), (1580, 5)]
def cs399 : List ℕ := [51, 49, 5, 34, 20, 33, 100, 100, 14, 4, 97, 167, 99, 37, 5, 32, 99, 99, 100, 8, 277, 67, 79, 99, 100, 100, 100, 318, 33, 65, 99, 100, 99, 0, 99, 99, 100, 301, 22, 99, 77, 100, 99, 99, 100, 99, 100, 99, 45, 100, 99, 100, 100, 99, 12, 100, 100, 101, 99, 71, 99, 77, 100, 100, 99, 99, 100, 101, 93, 100, 100, 90, 99, 99, 63, 99, 30, 100, 100, 66, 99, 99, 98, 66, 99, 85, 66, 100, 100, 99, 98, 99, 100, 100, 82, 3, 100, 0, 100, 99, 98, 99, 99, 100, 73, 55, 100, 99, 99, 33, 99, 99, 99, 44, 97, 99, 99, 38, 97, 32, 97, 100, 42, 99, 99, 79, 32, 172, 83, 99, 99, 32, 99, 99, 52, 99, 44, 36, 99, 99, 72, 97, 50, 99, 99, 32, 46, 84, 83, 65, 99, 53, 84, 84]
theorem loads399 : cs399.get =
    load (fun i : Fin entries399.length => support (entries399.get i).1)
      (fun i => (entries399.get i).2) := by
  apply load_eq_of_sparse_packed base cs399 support code
    entries399 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node399 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 11 (insert 20 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs399 support demand
    entries399 ((insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 27 (insert 11 (insert 20 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))))) : Finset (Fin 154)) 100 30 loads399
  decide +kernel
def entries400 : List (Fin 1589 × ℕ) := [(17, 173), (35, 58), (72, 36), (77, 107), (86, 36), (177, 204), (203, 13), (384, 214), (466, 371), (472, 206), (475, 130), (479, 115), (494, 46), (507, 273), (531, 176), (542, 262), (572, 225), (577, 39), (587, 151), (588, 202), (617, 236), (625, 295), (629, 107), (632, 188), (639, 96), (730, 28), (738, 112), (815, 10), (819, 44), (842, 69), (850, 237), (855, 92), (866, 100), (867, 123), (868, 227), (870, 156), (886, 135), (898, 23), (906, 415), (912, 116), (914, 91), (918, 198), (920, 151), (922, 80), (924, 126), (944, 118), (948, 194), (951, 22), (952, 232), (973, 135), (978, 398), (985, 50), (1004, 209), (1006, 215), (1012, 125), (1030, 148), (1040, 195), (1049, 17), (1061, 82), (1076, 252), (1086, 131), (1090, 188), (1094, 180), (1111, 3), (1122, 73), (1123, 443), (1133, 150), (1149, 201), (1152, 95), (1173, 399), (1188, 103), (1212, 45), (1232, 56), (1236, 14), (1276, 435), (1310, 41), (1312, 73), (1320, 68), (1358, 157), (1360, 9), (1374, 73), (1496, 72), (1525, 46), (1552, 186), (1580, 46)]
def cs400 : List ℕ := [542, 0, 252, 540, 175, 164, 0, 1001, 231, 319, 711, 864, 1001, 453, 451, 0, 1001, 1000, 1000, 225, 1457, 173, 580, 1001, 967, 1000, 1000, 123, 479, 950, 1001, 1002, 1000, 0, 1000, 1001, 1001, 1646, 420, 1000, 1001, 1000, 680, 1001, 1001, 1001, 1001, 1001, 449, 1000, 1000, 1000, 993, 1000, 399, 1001, 1000, 1001, 1001, 1001, 1000, 919, 820, 986, 1000, 1000, 1000, 1001, 1000, 1002, 1000, 1000, 1000, 1002, 817, 1000, 103, 908, 999, 1001, 1001, 1001, 1001, 1000, 1001, 779, 371, 1000, 1001, 1000, 1000, 999, 1000, 1001, 1000, 148, 1001, 0, 1000, 1001, 1000, 1000, 1001, 1001, 652, 900, 1000, 1001, 1001, 54, 1000, 1000, 733, 593, 1000, 804, 1001, 163, 1000, 489, 435, 1000, 882, 989, 1001, 950, 135, 1454, 687, 1000, 1000, 283, 999, 1000, 800, 1000, 735, 135, 1000, 1000, 1000, 947, 488, 1000, 1000, 135, 836, 371, 812, 780, 927, 490, 692, 680]
theorem loads400 : cs400.get =
    load (fun i : Fin entries400.length => support (entries400.get i).1)
      (fun i => (entries400.get i).2) := by
  apply load_eq_of_sparse_packed base cs400 support code
    entries400 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node400 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 27 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 11 (insert 20 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs400 support demand
    entries400 ((insert 27 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 11 (insert 20 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154)) 1000 30 loads400
  decide +kernel
theorem node397 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 11 (insert 20 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 11 (insert 20 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))))) : Finset (Fin 154))
    27 node399 node400
def entries398 : List (Fin 1589 × ℕ) := [(122, 7), (177, 5), (384, 1), (385, 3), (419, 1), (439, 1), (472, 14), (478, 11), (479, 23), (484, 16), (494, 10), (507, 16), (514, 38), (531, 17), (541, 13), (542, 12), (550, 2), (572, 11), (587, 31), (588, 10), (617, 39), (625, 33), (632, 23), (693, 3), (731, 3), (742, 3), (815, 2), (819, 6), (842, 4), (844, 25), (850, 41), (855, 3), (858, 1), (867, 46), (868, 8), (885, 1), (886, 17), (898, 18), (905, 1), (906, 49), (912, 21), (914, 11), (918, 6), (920, 11), (922, 25), (924, 16), (947, 7), (948, 28), (951, 11), (952, 5), (963, 11), (973, 18), (978, 28), (1004, 10), (1006, 14), (1010, 15), (1012, 12), (1030, 1), (1031, 6), (1040, 25), (1049, 5), (1061, 33), (1076, 1), (1081, 1), (1090, 32), (1093, 10), (1094, 29), (1098, 17), (1122, 1), (1123, 39), (1133, 7), (1149, 8), (1173, 44), (1188, 3), (1232, 3), (1276, 50), (1291, 6), (1374, 1), (1401, 23), (1493, 6), (1494, 3), (1500, 11), (1552, 10), (1582, 5)]
def cs398 : List ℕ := [25, 0, 14, 46, 34, 33, 6, 83, 9, 16, 100, 0, 99, 17, 54, 20, 100, 100, 98, 11, 180, 10, 70, 91, 99, 100, 100, 101, 40, 70, 66, 101, 100, 25, 101, 100, 101, 283, 5, 101, 101, 99, 100, 100, 101, 100, 101, 100, 29, 101, 99, 100, 100, 100, 44, 99, 101, 100, 100, 101, 101, 63, 100, 100, 93, 99, 100, 100, 101, 99, 99, 100, 100, 100, 83, 101, 14, 99, 100, 73, 100, 99, 90, 100, 99, 70, 53, 100, 99, 100, 101, 101, 99, 99, 101, 22, 100, 0, 101, 101, 100, 100, 99, 100, 88, 78, 102, 101, 100, 11, 61, 101, 89, 73, 87, 100, 101, 0, 101, 44, 63, 101, 59, 100, 96, 84, 18, 156, 55, 101, 100, 34, 101, 100, 62, 100, 70, 24, 100, 101, 65, 101, 39, 101, 100, 18, 73, 50, 82, 70, 100, 28, 68, 71]
theorem loads398 : cs398.get =
    load (fun i : Fin entries398.length => support (entries398.get i).1)
      (fun i => (entries398.get i).2) := by
  apply load_eq_of_sparse_packed base cs398 support code
    entries398 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node398 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 11 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs398 support demand
    entries398 ((insert 11 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 20 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)) 100 30 loads398
  decide +kernel
theorem node393 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 20 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154))
    11 node397 node398
def entries395 : List (Fin 1589 × ℕ) := [(17, 20), (20, 5), (43, 11), (46, 27), (72, 5), (77, 50), (86, 25), (177, 6), (384, 16), (419, 2), (439, 1), (472, 35), (475, 1), (479, 17), (494, 13), (507, 6), (550, 3), (587, 9), (588, 34), (616, 1), (617, 42), (625, 21), (632, 27), (639, 34), (672, 8), (739, 3), (814, 1), (815, 20), (819, 20), (842, 31), (843, 6), (846, 25), (848, 3), (850, 64), (856, 9), (869, 13), (870, 22), (884, 3), (886, 27), (896, 18), (906, 25), (912, 12), (914, 8), (918, 6), (920, 4), (928, 15), (951, 32), (952, 2), (960, 17), (968, 10), (973, 32), (978, 36), (985, 3), (1004, 29), (1006, 14), (1040, 19), (1049, 11), (1076, 12), (1081, 3), (1090, 29), (1098, 10), (1108, 6), (1114, 6), (1123, 58), (1124, 1), (1128, 12), (1133, 20), (1152, 3), (1173, 26), (1188, 15), (1232, 10), (1246, 7), (1263, 23), (1276, 36), (1482, 4), (1493, 26), (1537, 4), (1584, 3)]
def cs395 : List ℕ := [0, 25, 42, 90, 17, 13, 38, 97, 52, 6, 55, 61, 101, 29, 93, 29, 69, 248, 100, 0, 0, 99, 75, 69, 99, 100, 100, 99, 76, 100, 99, 99, 79, 0, 99, 100, 100, 185, 83, 99, 100, 100, 98, 100, 99, 100, 100, 100, 28, 100, 100, 99, 99, 100, 29, 100, 99, 100, 100, 100, 99, 48, 84, 99, 99, 100, 100, 100, 99, 100, 99, 87, 100, 99, 53, 100, 32, 99, 99, 99, 100, 100, 99, 100, 87, 51, 72, 99, 100, 100, 99, 100, 100, 99, 100, 9, 99, 0, 100, 100, 99, 100, 100, 99, 79, 58, 96, 100, 82, 10, 100, 100, 101, 44, 89, 100, 100, 0, 100, 62, 100, 99, 79, 93, 100, 72, 32, 153, 92, 100, 100, 32, 100, 100, 100, 100, 58, 32, 100, 100, 100, 91, 64, 92, 100, 33, 68, 70, 78, 76, 100, 65, 68, 78]
theorem loads395 : cs395.get =
    load (fun i : Fin entries395.length => support (entries395.get i).1)
      (fun i => (entries395.get i).2) := by
  apply load_eq_of_sparse_packed base cs395 support code
    entries395 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node395 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 20 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 17 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs395 support demand
    entries395 ((insert 20 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 17 (insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)) 100 30 loads395
  decide +kernel
def entries396 : List (Fin 1589 × ℕ) := [(62, 2), (120, 24), (177, 36), (179, 2), (384, 28), (385, 2), (469, 8), (472, 17), (475, 37), (478, 9), (479, 20), (494, 26), (550, 7), (571, 5), (572, 3), (581, 1), (583, 9), (587, 12), (588, 16), (617, 32), (625, 6), (632, 23), (639, 21), (730, 21), (798, 7), (815, 26), (819, 7), (842, 4), (855, 35), (881, 7), (885, 13), (886, 20), (890, 8), (896, 17), (898, 18), (906, 26), (912, 2), (914, 14), (918, 17), (922, 16), (928, 3), (944, 14), (947, 2), (951, 1), (952, 16), (973, 26), (984, 32), (1004, 28), (1006, 21), (1012, 8), (1030, 25), (1040, 19), (1049, 3), (1061, 4), (1076, 16), (1090, 17), (1123, 48), (1133, 21), (1138, 4), (1149, 9), (1152, 6), (1173, 42), (1212, 20), (1269, 2), (1276, 29), (1310, 12), (1320, 3), (1374, 15), (1482, 5), (1489, 22), (1493, 8), (1498, 14), (1537, 14), (1545, 4), (1587, 6)]
def cs396 : List ℕ := [0, 14, 31, 37, 29, 63, 0, 100, 14, 2, 0, 51, 100, 22, 0, 66, 78, 0, 100, 10, 0, 59, 92, 43, 100, 100, 100, 99, 42, 82, 54, 100, 100, 0, 101, 100, 100, 170, 89, 100, 100, 101, 78, 100, 100, 101, 99, 100, 71, 100, 100, 99, 71, 100, 42, 99, 101, 100, 100, 100, 98, 55, 101, 92, 100, 100, 99, 99, 99, 100, 99, 80, 101, 100, 89, 100, 0, 81, 100, 100, 99, 95, 100, 94, 101, 99, 66, 96, 99, 100, 99, 100, 99, 99, 101, 25, 100, 0, 100, 99, 100, 100, 85, 100, 77, 79, 100, 100, 99, 20, 95, 99, 85, 67, 100, 100, 99, 38, 98, 72, 30, 100, 99, 100, 101, 98, 26, 135, 55, 100, 101, 51, 101, 99, 102, 101, 77, 26, 100, 99, 87, 99, 64, 90, 100, 26, 99, 63, 84, 97, 99, 73, 80, 75]
theorem loads396 : cs396.get =
    load (fun i : Fin entries396.length => support (entries396.get i).1)
      (fun i => (entries396.get i).2) := by
  apply load_eq_of_sparse_packed base cs396 support code
    entries396 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node396 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 17 (insert 20 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs396 support demand
    entries396 ((insert 17 (insert 20 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)) 100 30 loads396
  decide +kernel
theorem node394 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 20 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 20 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154))
    17 node395 node396
theorem node389 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154))
    20 node393 node394
def entries391 : List (Fin 1589 × ℕ) := [(20, 67893), (43, 103591), (75, 160623), (77, 77863), (120, 7625), (122, 160849), (177, 127286), (179, 129415), (384, 282864), (466, 239811), (472, 74961), (479, 264591), (507, 387053), (527, 81807), (531, 85005), (583, 88019), (616, 49803), (617, 182822), (625, 24830), (639, 194393), (672, 62867), (731, 124417), (739, 246488), (741, 97528), (797, 20776), (819, 12188), (842, 170594), (846, 58758), (864, 13814), (868, 324288), (870, 172115), (872, 93490), (881, 12051), (886, 140565), (896, 186480), (906, 246439), (920, 160809), (925, 229327), (936, 208803), (938, 161231), (940, 130995), (952, 254108), (978, 344526), (984, 96252), (985, 17625), (1004, 282594), (1006, 265397), (1012, 145889), (1017, 170448), (1030, 233997), (1049, 29055), (1061, 113113), (1076, 155253), (1081, 137610), (1086, 25501), (1094, 149427), (1114, 61862), (1123, 296781), (1133, 40690), (1147, 24617), (1149, 469631), (1152, 110113), (1173, 247347), (1188, 123366), (1212, 98440), (1219, 253117), (1227, 30038), (1233, 36869), (1249, 129275), (1263, 133719), (1267, 57865), (1276, 290955), (1292, 182784), (1310, 80400), (1312, 82179), (1320, 289207), (1342, 117579), (1420, 71191), (1489, 193216), (1537, 108762)]
def cs391 : List ℕ := [239811, 311875, 183723, 321010, 264591, 291546, 103591, 1000000, 310374, 400867, 745558, 665043, 1000000, 355150, 342077, 180525, 1000000, 1000000, 999999, 0, 1000000, 1000000, 256701, 1000000, 999999, 1000000, 999999, 1000000, 480623, 588808, 1000001, 999999, 616380, 0, 1000000, 999999, 999999, 0, 765201, 1000000, 999103, 999999, 282594, 1000000, 1000001, 999999, 1000000, 1000000, 945491, 999999, 999999, 1000001, 861048, 1000000, 247347, 1000000, 1000000, 1000000, 999999, 1000000, 1000000, 999999, 928797, 830805, 806952, 999999, 1000000, 1000001, 999999, 999999, 1818861, 999999, 999999, 1000000, 512744, 999999, 137180, 908728, 1000000, 999999, 1000000, 999998, 860278, 999999, 999999, 951093, 455195, 945502, 1000000, 999998, 1000000, 999999, 1000000, 1000000, 773063, 346667, 1000000, 0, 1000000, 999998, 999999, 999999, 1000000, 999999, 459224, 784533, 999999, 999999, 999998, 123057, 861428, 999999, 811370, 578173, 1000000, 670266, 999998, 98440, 1000000, 274687, 767562, 1000000, 948935, 993909, 999998, 982375, 0, 1525628, 709354, 999999, 999999, 233997, 999999, 999999, 564815, 999999, 716978, 0, 999999, 999998, 999999, 883643, 419837, 927329, 1000000, 0, 981562, 264584, 844746, 877280, 999999, 249243, 832494, 426264]
theorem loads391 : cs391.get =
    load (fun i : Fin entries391.length => support (entries391.get i).1)
      (fun i => (entries391.get i).2) := by
  apply load_eq_of_sparse_packed base cs391 support code
    entries391 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node391 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs391 support demand
    entries391 ((insert 37 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 70 (insert 113 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)) 1000000 30 loads391
  decide +kernel
def entries392 : List (Fin 1589 × ℕ) := [(43, 164), (62, 150), (72, 184), (75, 176), (86, 60), (122, 277), (179, 122), (384, 50), (387, 167), (466, 457), (477, 63), (479, 180), (483, 104), (494, 110), (507, 224), (531, 357), (542, 303), (552, 298), (577, 67), (583, 86), (584, 6), (617, 300), (738, 62), (739, 76), (815, 145), (819, 97), (846, 210), (868, 137), (869, 66), (870, 356), (886, 120), (896, 118), (905, 56), (918, 253), (922, 59), (925, 95), (928, 280), (929, 53), (934, 261), (937, 170), (939, 241), (944, 222), (963, 102), (973, 138), (978, 81), (984, 292), (985, 92), (1004, 138), (1006, 358), (1012, 222), (1030, 266), (1031, 43), (1040, 129), (1049, 25), (1061, 37), (1076, 131), (1081, 120), (1090, 180), (1093, 6), (1094, 404), (1098, 16), (1111, 47), (1123, 239), (1124, 18), (1133, 291), (1138, 125), (1147, 111), (1149, 88), (1173, 308), (1186, 54), (1188, 66), (1233, 42), (1276, 371), (1312, 53), (1320, 160), (1335, 12), (1342, 158), (1372, 53), (1498, 283), (1500, 6), (1525, 35), (1559, 76), (1576, 60)]
def cs392 : List ℕ := [457, 210, 35, 63, 180, 387, 164, 992, 0, 409, 532, 939, 907, 560, 827, 858, 999, 1000, 942, 150, 999, 827, 122, 1000, 1000, 1001, 999, 1001, 597, 462, 999, 1001, 637, 0, 1001, 1000, 999, 0, 1000, 1000, 999, 992, 658, 1000, 1001, 1000, 1000, 999, 818, 997, 991, 999, 848, 1001, 569, 1000, 1000, 1000, 1000, 1001, 1000, 1000, 999, 967, 1001, 967, 1000, 1000, 1000, 1000, 0, 1000, 1001, 1000, 776, 1000, 125, 637, 1000, 1000, 999, 1001, 1001, 1000, 951, 1000, 720, 837, 1000, 1000, 1002, 1000, 990, 1000, 1000, 362, 1000, 0, 1001, 1003, 1001, 1000, 1001, 1000, 633, 784, 1000, 1001, 1001, 267, 1000, 1001, 821, 708, 958, 1001, 1000, 276, 1000, 695, 974, 1001, 1002, 1000, 1001, 892, 138, 1753, 614, 1001, 1001, 404, 1000, 1001, 990, 1002, 534, 181, 1001, 1000, 1001, 808, 339, 760, 1001, 156, 588, 461, 854, 600, 1001, 483, 846, 605]
theorem loads392 : cs392.get =
    load (fun i : Fin entries392.length => support (entries392.get i).1)
      (fun i => (entries392.get i).2) := by
  apply load_eq_of_sparse_packed base cs392 support code
    entries392 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node392 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 70 (insert 37 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 113 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs392 support demand
    entries392 ((insert 70 (insert 37 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 113 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)) 1000 30 loads392
  decide +kernel
theorem node390 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 113 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 113 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154))
    70 node391 node392
theorem node388 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 113 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 97 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 113 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154))
    37 node389 node390
theorem node377 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 113 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 113 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154))
    97 node387 node388
def entries385 : List (Fin 1589 × ℕ) := [(20, 14517), (62, 14472), (116, 96861), (120, 30912), (122, 457216), (352, 49068), (466, 155750), (472, 226967), (475, 113653), (479, 310337), (491, 62995), (494, 148234), (507, 199921), (572, 197061), (587, 77969), (588, 201784), (617, 338125), (625, 227709), (632, 510149), (639, 64214), (731, 237106), (813, 412179), (819, 236169), (835, 43592), (850, 224616), (855, 347268), (858, 133665), (868, 109411), (870, 150352), (886, 454306), (890, 19278), (895, 35185), (896, 35185), (898, 181017), (906, 172384), (911, 4243), (912, 217560), (913, 62775), (916, 9335), (920, 111162), (921, 108416), (922, 97460), (925, 55442), (940, 52745), (947, 250611), (949, 135347), (952, 52636), (963, 94529), (966, 119852), (973, 81381), (978, 356967), (995, 24600), (1004, 294450), (1006, 313321), (1010, 89665), (1012, 65808), (1021, 116325), (1033, 87779), (1040, 111725), (1049, 430796), (1052, 208704), (1076, 126665), (1077, 13654), (1098, 98133), (1123, 479913), (1128, 28396), (1133, 237573), (1149, 248830), (1167, 5340), (1186, 76041), (1212, 91474), (1219, 114541), (1235, 88736), (1236, 37927), (1249, 257941), (1261, 111416), (1276, 255116), (1293, 8165), (1320, 89291), (1323, 6761), (1356, 89014), (1358, 6244), (1374, 51658), (1401, 16664), (1471, 236349), (1495, 4265), (1577, 358536)]
def cs385 : List ℕ := [199921, 114541, 315981, 467327, 437278, 385195, 555196, 1000000, 14517, 214393, 113676, 999998, 999999, 118003, 375200, 947790, 1000000, 999998, 999999, 211533, 999998, 1000000, 460770, 999999, 1000000, 999999, 1000001, 999999, 812698, 809244, 999998, 1000000, 653034, 5340, 1000000, 1000001, 1000000, 2500495, 142245, 999999, 1000001, 1000000, 999999, 999998, 999998, 1000001, 1000000, 1000000, 694322, 1000000, 999999, 1000001, 931680, 999998, 0, 1000000, 1000000, 1000000, 1000000, 999999, 1000000, 634088, 999998, 947528, 606217, 999999, 1000001, 999999, 999999, 1000000, 999999, 1000000, 1783243, 1000000, 728197, 1000001, 0, 999998, 1000000, 999999, 1000001, 1000000, 999999, 999998, 949039, 885060, 816112, 1000000, 1000000, 938115, 1000000, 999999, 1000001, 999999, 1000001, 144073, 1000000, 999999, 1000001, 1000000, 1000000, 999998, 1000000, 1000000, 768921, 885881, 1847441, 1000000, 1000000, 262044, 999999, 1000000, 676063, 0, 1000001, 964068, 1000000, 287367, 1000000, 415380, 901194, 1000000, 492881, 800856, 1000000, 765197, 81381, 1863501, 981383, 1000000, 1000001, 176386, 999999, 1000000, 763866, 1000001, 330211, 100375, 1000001, 1000001, 1000000, 872732, 660934, 628460, 1000000, 81381, 679626, 512177, 775203, 532883, 1000000, 493230, 851244, 504012]
theorem loads385 : cs385.get =
    load (fun i : Fin entries385.length => support (entries385.get i).1)
      (fun i => (entries385.get i).2) := by
  apply load_eq_of_sparse_packed base cs385 support code
    entries385 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node385 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 106 (insert 72 (insert 37 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs385 support demand
    entries385 ((insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 106 (insert 72 (insert 37 (insert 128 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)) 1000000 30 loads385
  decide +kernel
def entries386 : List (Fin 1589 × ℕ) := [(86, 74992), (122, 304831), (177, 164836), (273, 156839), (466, 438903), (472, 38332), (475, 40100), (479, 207091), (491, 11106), (494, 14539), (498, 13858), (507, 345364), (571, 41471), (572, 241770), (588, 194213), (617, 333062), (625, 323128), (630, 19869), (631, 110242), (632, 369554), (639, 52722), (674, 37227), (676, 42876), (731, 30497), (736, 258432), (815, 185171), (819, 205361), (833, 2440), (835, 112904), (846, 107397), (850, 58427), (855, 448712), (858, 119832), (868, 89832), (870, 189367), (886, 299384), (893, 42279), (894, 80664), (896, 123007), (897, 56201), (904, 986), (905, 49372), (906, 171916), (914, 281923), (917, 33080), (920, 182616), (922, 70255), (930, 71543), (940, 94833), (949, 111681), (950, 239997), (951, 128247), (966, 262563), (973, 56242), (978, 387455), (1004, 358991), (1006, 301058), (1009, 11460), (1010, 23198), (1021, 176420), (1040, 93604), (1049, 393604), (1055, 31714), (1056, 124883), (1076, 16295), (1086, 114419), (1093, 126932), (1098, 21190), (1123, 294857), (1133, 204162), (1149, 228090), (1153, 74320), (1167, 62530), (1172, 54928), (1212, 22889), (1232, 150859), (1249, 188099), (1269, 35240), (1275, 89447), (1276, 419739), (1356, 162072), (1379, 75173), (1401, 19623), (1447, 56333), (1471, 46513), (1491, 148498), (1501, 114985), (1552, 53576), (1577, 97325), (1578, 148208)]
def cs386 : List ℕ := [438903, 107397, 200404, 98527, 517371, 448712, 376471, 954470, 13858, 345364, 313213, 1000001, 1000000, 162072, 265156, 698862, 1000000, 1000000, 1000000, 283241, 1000002, 982747, 530235, 1000000, 1000001, 1000000, 999999, 1000002, 627959, 1000000, 999999, 1000000, 999999, 62530, 1000000, 999999, 1000002, 2242322, 236379, 1000000, 1000000, 999999, 1000001, 999999, 999999, 1000000, 1000000, 1000001, 500164, 1000000, 1000000, 999999, 960045, 999999, 54928, 1000001, 1000001, 999999, 1000000, 999999, 999999, 964439, 1000002, 1000001, 860260, 1000000, 1000000, 1000001, 999999, 1000000, 999999, 1000000, 1778425, 1000000, 644133, 999999, 0, 857930, 1000000, 1000000, 1000000, 999999, 999999, 1000001, 999999, 1000000, 518233, 999999, 1000000, 999999, 999999, 1000000, 1000000, 999999, 905363, 140656, 1000000, 863962, 1000001, 999998, 1000000, 1000000, 1000000, 999999, 726666, 906189, 294857, 1000000, 1000000, 22889, 1000000, 1000000, 1000000, 0, 1000001, 1000000, 999998, 285452, 1000000, 434461, 457944, 1000001, 377910, 999999, 999999, 890728, 56242, 1355944, 294857, 999999, 1000000, 196898, 998739, 1000001, 1149027, 999999, 284332, 205414, 1000000, 1000000, 1000000, 771540, 733155, 812296, 901252, 56242, 681419, 384688, 1000000, 307221, 837633, 523599, 796529, 739176]
theorem loads386 : cs386.get =
    load (fun i : Fin entries386.length => support (entries386.get i).1)
      (fun i => (entries386.get i).2) := by
  apply load_eq_of_sparse_packed base cs386 support code
    entries386 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node386 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 106 (insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 72 (insert 37 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs386 support demand
    entries386 ((insert 106 (insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 72 (insert 37 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)) 1000000 30 loads386
  decide +kernel
theorem node383 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 72 (insert 37 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 72 (insert 37 (insert 128 (insert 134 (insert 127 ∅))))) : Finset (Fin 154))
    106 node385 node386
def entries384 : List (Fin 1589 × ℕ) := [(10, 73), (20, 151), (43, 53), (70, 24), (77, 79), (120, 176), (122, 145), (135, 4), (137, 76), (384, 159), (466, 276), (472, 285), (478, 49), (479, 194), (491, 134), (507, 197), (514, 65), (531, 215), (572, 6), (587, 167), (588, 274), (617, 456), (625, 383), (629, 20), (632, 447), (639, 207), (736, 173), (739, 86), (813, 23), (834, 207), (843, 5), (855, 521), (858, 158), (870, 321), (894, 208), (896, 86), (897, 10), (904, 77), (906, 239), (914, 183), (916, 73), (920, 87), (921, 18), (922, 51), (930, 93), (947, 317), (949, 54), (952, 262), (960, 147), (973, 297), (978, 318), (1006, 189), (1010, 180), (1012, 91), (1021, 149), (1030, 70), (1033, 137), (1049, 275), (1052, 134), (1070, 23), (1076, 46), (1093, 33), (1094, 25), (1098, 128), (1111, 123), (1114, 90), (1122, 207), (1123, 227), (1133, 70), (1139, 66), (1149, 58), (1186, 240), (1212, 121), (1217, 67), (1264, 7), (1276, 252), (1320, 90), (1342, 62), (1356, 156), (1358, 129), (1378, 73), (1466, 20), (1491, 67), (1493, 44), (1494, 7), (1501, 152), (1509, 92)]
def cs384 : List ℕ := [472, 0, 581, 151, 472, 595, 418, 1000, 158, 197, 267, 1000, 1000, 595, 229, 524, 1001, 1001, 1000, 6, 1001, 1001, 647, 875, 1001, 1000, 1000, 1001, 783, 885, 1000, 1000, 1000, 0, 1000, 1000, 1000, 2354, 417, 1000, 1000, 1001, 1001, 999, 999, 1002, 1000, 1001, 207, 1001, 1001, 1000, 1001, 999, 0, 1002, 1001, 1000, 1000, 1000, 1001, 694, 1002, 783, 1000, 1000, 1001, 1001, 1001, 1000, 1000, 940, 0, 828, 647, 1001, 147, 1000, 1000, 1001, 1000, 1000, 734, 1001, 1000, 706, 590, 935, 1001, 1000, 999, 999, 1000, 1000, 516, 250, 1000, 1000, 1001, 816, 1001, 999, 1000, 995, 754, 1000, 1000, 999, 1001, 361, 999, 999, 383, 0, 1001, 855, 1000, 361, 1000, 617, 315, 1001, 869, 895, 935, 693, 297, 1516, 760, 1001, 1000, 547, 1000, 1000, 703, 1000, 355, 297, 1000, 999, 1000, 653, 592, 1000, 1001, 297, 476, 781, 1000, 806, 826, 728, 1000, 910]
theorem loads384 : cs384.get =
    load (fun i : Fin entries384.length => support (entries384.get i).1)
      (fun i => (entries384.get i).2) := by
  apply load_eq_of_sparse_packed base cs384 support code
    entries384 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node384 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 72 (insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs384 support demand
    entries384 ((insert 72 (insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 37 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)) 1000 30 loads384
  decide +kernel
theorem node379 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154))
    72 node383 node384
def entries381 : List (Fin 1589 × ℕ) := [(35, 37), (46, 19), (75, 8), (77, 21), (122, 35), (179, 22), (203, 11), (384, 14), (466, 40), (469, 13), (472, 5), (479, 4), (496, 13), (507, 28), (570, 12), (617, 32), (625, 21), (673, 2), (674, 1), (736, 2), (738, 6), (739, 32), (813, 3), (815, 2), (819, 13), (868, 21), (870, 11), (872, 4), (881, 2), (882, 6), (886, 13), (894, 31), (904, 3), (905, 8), (920, 22), (922, 6), (923, 22), (924, 6), (925, 13), (927, 17), (929, 5), (930, 3), (938, 27), (940, 15), (944, 22), (952, 18), (973, 6), (978, 51), (1004, 3), (1006, 41), (1010, 10), (1017, 14), (1028, 7), (1030, 3), (1033, 40), (1040, 4), (1049, 52), (1076, 2), (1090, 9), (1093, 7), (1094, 28), (1098, 21), (1111, 3), (1114, 2), (1123, 28), (1133, 25), (1139, 7), (1149, 32), (1160, 10), (1186, 1), (1212, 21), (1220, 18), (1227, 1), (1234, 19), (1236, 8), (1263, 4), (1268, 13), (1276, 23), (1280, 1), (1320, 9), (1342, 12), (1348, 12), (1358, 8), (1372, 7), (1403, 6), (1491, 16), (1498, 7), (1580, 3)]
def cs381 : List ℕ := [75, 32, 5, 18, 15, 53, 19, 100, 54, 28, 50, 99, 99, 64, 51, 66, 100, 99, 99, 13, 99, 98, 22, 99, 100, 100, 100, 99, 89, 86, 99, 99, 92, 0, 99, 100, 101, 0, 100, 98, 101, 99, 25, 100, 98, 100, 100, 100, 100, 100, 100, 100, 56, 99, 0, 100, 243, 99, 100, 100, 100, 100, 70, 101, 90, 79, 99, 99, 100, 99, 99, 100, 100, 100, 59, 100, 7, 99, 100, 99, 101, 99, 91, 99, 100, 100, 65, 100, 99, 99, 99, 100, 101, 99, 80, 32, 95, 99, 100, 99, 99, 100, 100, 99, 86, 62, 100, 99, 100, 22, 100, 99, 86, 0, 99, 99, 100, 44, 100, 44, 52, 99, 99, 77, 99, 79, 6, 198, 47, 99, 99, 19, 100, 99, 72, 79, 38, 6, 99, 99, 89, 94, 50, 70, 99, 6, 59, 40, 66, 62, 99, 53, 60, 61]
theorem loads381 : cs381.get =
    load (fun i : Fin entries381.length => support (entries381.get i).1)
      (fun i => (entries381.get i).2) := by
  apply load_eq_of_sparse_packed base cs381 support code
    entries381 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node381 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 56 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs381 support demand
    entries381 ((insert 37 (insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 56 (insert 128 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)) 100 30 loads381
  decide +kernel
def entries382 : List (Fin 1589 × ℕ) := [(10, 17), (17, 10), (35, 52), (62, 1), (384, 8), (419, 12), (439, 4), (472, 7), (479, 7), (496, 17), (507, 23), (529, 1), (531, 3), (551, 11), (570, 13), (572, 6), (583, 8), (617, 21), (625, 17), (639, 4), (731, 2), (736, 9), (739, 17), (740, 14), (819, 14), (843, 4), (854, 3), (870, 33), (886, 3), (893, 1), (894, 17), (895, 17), (905, 7), (906, 9), (920, 13), (925, 19), (927, 19), (929, 3), (935, 12), (936, 6), (940, 10), (950, 16), (952, 7), (957, 7), (960, 8), (963, 16), (973, 13), (978, 31), (985, 3), (995, 13), (1004, 25), (1006, 45), (1012, 15), (1017, 3), (1030, 5), (1031, 15), (1049, 35), (1052, 32), (1076, 11), (1077, 10), (1093, 4), (1094, 24), (1098, 13), (1111, 2), (1114, 11), (1123, 7), (1133, 26), (1139, 4), (1147, 6), (1149, 14), (1186, 15), (1188, 25), (1212, 14), (1220, 26), (1222, 10), (1227, 1), (1263, 7), (1276, 8), (1280, 8), (1292, 13), (1320, 37), (1342, 29), (1358, 17), (1403, 6), (1491, 4), (1525, 17), (1527, 6), (1580, 9)]
def cs382 : List ℕ := [51, 44, 51, 36, 33, 86, 0, 101, 86, 41, 30, 94, 101, 93, 9, 15, 101, 100, 100, 7, 100, 78, 0, 101, 99, 101, 100, 100, 17, 52, 101, 101, 63, 0, 100, 101, 100, 0, 59, 100, 100, 100, 36, 100, 101, 100, 100, 100, 56, 99, 100, 100, 27, 100, 13, 100, 4, 100, 100, 100, 100, 100, 82, 100, 93, 99, 100, 100, 100, 101, 99, 100, 99, 78, 62, 100, 33, 98, 100, 100, 100, 100, 99, 100, 90, 100, 49, 99, 101, 99, 100, 100, 100, 99, 67, 33, 100, 94, 100, 99, 100, 99, 100, 100, 56, 99, 99, 100, 100, 51, 100, 101, 99, 0, 100, 72, 100, 36, 101, 44, 100, 99, 90, 100, 99, 72, 13, 226, 85, 101, 100, 18, 100, 99, 69, 99, 27, 38, 100, 101, 100, 62, 51, 87, 95, 13, 41, 44, 76, 67, 99, 68, 93, 50]
theorem loads382 : cs382.get =
    load (fun i : Fin entries382.length => support (entries382.get i).1)
      (fun i => (entries382.get i).2) := by
  apply load_eq_of_sparse_packed base cs382 support code
    entries382 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node382 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 56 (insert 37 (insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 128 (insert 134 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs382 support demand
    entries382 ((insert 56 (insert 37 (insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 128 (insert 134 (insert 127 ∅))) : Finset (Fin 154)) 100 30 loads382
  decide +kernel
theorem node380 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 128 (insert 134 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 128 (insert 134 (insert 127 ∅))) : Finset (Fin 154))
    56 node381 node382
theorem node378 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 128 (insert 134 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 113 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 128 (insert 134 (insert 127 ∅))) : Finset (Fin 154))
    37 node379 node380
theorem node361 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 128 (insert 134 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 128 (insert 134 (insert 127 ∅))) : Finset (Fin 154))
    113 node377 node378
def entries375 : List (Fin 1589 × ℕ) := [(7, 2), (35, 21), (77, 326), (86, 49), (120, 106), (179, 17), (205, 28), (229, 82), (344, 2), (386, 7), (387, 18), (420, 156), (472, 103), (475, 121), (478, 27), (479, 244), (484, 167), (491, 29), (507, 134), (572, 357), (585, 107), (588, 327), (616, 75), (617, 146), (621, 16), (630, 421), (639, 151), (674, 275), (730, 279), (731, 70), (797, 158), (812, 158), (835, 467), (847, 64), (850, 241), (855, 105), (858, 291), (870, 121), (886, 364), (896, 57), (898, 189), (906, 309), (912, 198), (914, 261), (916, 155), (922, 230), (924, 69), (928, 61), (929, 59), (940, 174), (947, 287), (948, 133), (950, 89), (966, 96), (968, 96), (973, 342), (978, 296), (1004, 5), (1006, 68), (1012, 358), (1017, 53), (1052, 13), (1070, 40), (1076, 75), (1081, 180), (1090, 212), (1094, 307), (1111, 40), (1123, 132), (1126, 96), (1133, 34), (1149, 68), (1160, 90), (1173, 371), (1212, 129), (1217, 121), (1228, 84), (1236, 110), (1250, 7), (1268, 45), (1276, 189), (1293, 41), (1308, 20), (1358, 133), (1360, 84), (1499, 86), (1522, 2), (1556, 10), (1577, 316)]
def cs375 : List ℕ := [364, 2, 288, 362, 383, 526, 636, 802, 21, 134, 326, 1000, 1000, 70, 642, 422, 1000, 1000, 1000, 402, 1000, 272, 533, 1000, 1000, 1001, 999, 1001, 600, 918, 1000, 999, 820, 0, 1001, 1000, 999, 2668, 569, 1000, 1000, 1000, 679, 648, 1000, 1000, 1000, 999, 366, 999, 1000, 999, 1000, 1001, 457, 1000, 1000, 1000, 999, 999, 999, 999, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1945, 999, 700, 999, 1001, 572, 1000, 0, 1000, 2187, 999, 999, 999, 734, 1000, 1000, 479, 767, 1000, 1000, 1000, 1000, 1001, 999, 2813, 1000, 75, 1000, 1000, 999, 1000, 1000, 1000, 1000, 1000, 557, 1000, 999, 1000, 1000, 316, 781, 1001, 1000, 831, 701, 999, 999, 225, 985, 376, 1001, 1000, 534, 999, 1000, 849, 342, 1481, 132, 1000, 999, 342, 1000, 1001, 600, 1000, 781, 342, 1000, 1000, 1000, 1001, 637, 930, 665, 342, 1001, 903, 751, 910, 1001, 596, 751, 918]
theorem loads375 : cs375.get =
    load (fun i : Fin entries375.length => support (entries375.get i).1)
      (fun i => (entries375.get i).2) := by
  apply load_eq_of_sparse_packed base cs375 support code
    entries375 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node375 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 78 (insert 69 (insert 93 (insert 37 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs375 support demand
    entries375 ((insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 78 (insert 69 (insert 93 (insert 37 (insert 134 (insert 127 ∅)))))) : Finset (Fin 154)) 1000 30 loads375
  decide +kernel
def entries376 : List (Fin 1589 × ℕ) := [(10, 499), (86, 137), (135, 17), (179, 20), (360, 44), (478, 118), (484, 241), (494, 24), (497, 21), (507, 164), (514, 107), (570, 86), (571, 37), (572, 367), (588, 79), (616, 201), (624, 438), (630, 170), (632, 172), (639, 239), (674, 46), (690, 182), (730, 64), (731, 116), (739, 149), (819, 124), (835, 256), (850, 274), (855, 103), (856, 22), (858, 186), (870, 156), (886, 296), (896, 246), (898, 267), (904, 302), (906, 135), (912, 232), (914, 336), (920, 6), (922, 155), (924, 84), (951, 177), (952, 238), (973, 388), (978, 248), (1004, 95), (1006, 244), (1009, 18), (1010, 13), (1012, 176), (1021, 120), (1031, 55), (1033, 86), (1049, 563), (1061, 8), (1090, 278), (1094, 284), (1098, 175), (1100, 22), (1111, 31), (1123, 126), (1126, 51), (1133, 43), (1160, 27), (1186, 49), (1212, 202), (1217, 64), (1226, 122), (1234, 90), (1268, 39), (1276, 186), (1293, 61), (1308, 85), (1354, 76), (1358, 246), (1403, 59), (1486, 12), (1501, 54), (1522, 30), (1556, 39), (1577, 398)]
def cs376 : List ℕ := [310, 0, 563, 274, 617, 460, 584, 452, 21, 164, 107, 1001, 1001, 568, 398, 398, 1001, 1001, 1001, 443, 1001, 745, 420, 1001, 999, 1001, 999, 1001, 438, 930, 1001, 1001, 652, 0, 1000, 1000, 1000, 2649, 110, 1000, 999, 827, 733, 1001, 1001, 1000, 1000, 1000, 456, 1000, 1001, 999, 1001, 1001, 0, 1000, 999, 1000, 1000, 1001, 1000, 999, 1001, 926, 666, 1001, 1000, 1000, 1000, 2439, 940, 985, 1001, 1000, 665, 1001, 122, 1000, 0, 1000, 803, 1000, 698, 1000, 1001, 1000, 587, 1001, 1000, 1000, 999, 1001, 1000, 2142, 1000, 355, 1000, 1000, 999, 998, 999, 1000, 1001, 1000, 563, 810, 1000, 999, 1000, 251, 1000, 1000, 1001, 22, 692, 999, 1000, 251, 1000, 444, 1000, 1001, 681, 999, 1001, 770, 388, 1773, 126, 1000, 999, 401, 931, 1000, 626, 759, 388, 443, 1000, 999, 763, 951, 765, 911, 727, 388, 612, 999, 776, 639, 1000, 682, 825, 852]
theorem loads376 : cs376.get =
    load (fun i : Fin entries376.length => support (entries376.get i).1)
      (fun i => (entries376.get i).2) := by
  apply load_eq_of_sparse_packed base cs376 support code
    entries376 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node376 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 78 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 93 (insert 37 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs376 support demand
    entries376 ((insert 78 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 69 (insert 93 (insert 37 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)) 1000 30 loads376
  decide +kernel
theorem node373 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 93 (insert 37 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 69 (insert 93 (insert 37 (insert 134 (insert 127 ∅))))) : Finset (Fin 154))
    78 node375 node376
def entries374 : List (Fin 1589 × ℕ) := [(10, 5), (35, 163), (75, 4), (86, 92), (122, 389), (179, 209), (387, 175), (420, 263), (472, 234), (475, 78), (478, 21), (479, 38), (491, 164), (494, 45), (498, 259), (507, 330), (542, 164), (550, 25), (552, 5), (572, 326), (583, 164), (587, 200), (588, 267), (617, 28), (623, 219), (625, 134), (639, 92), (736, 69), (739, 16), (798, 15), (812, 42), (835, 308), (850, 125), (855, 284), (858, 211), (870, 199), (872, 86), (882, 37), (886, 478), (906, 143), (913, 29), (918, 170), (922, 352), (928, 82), (930, 154), (936, 160), (937, 153), (952, 112), (968, 71), (973, 234), (978, 372), (985, 32), (1004, 5), (1006, 263), (1012, 219), (1033, 111), (1049, 164), (1052, 4), (1056, 94), (1061, 28), (1076, 102), (1078, 34), (1081, 65), (1090, 297), (1094, 327), (1108, 30), (1123, 17), (1149, 121), (1160, 10), (1173, 351), (1186, 27), (1212, 33), (1217, 35), (1251, 262), (1263, 22), (1276, 360), (1293, 183), (1354, 36), (1358, 197), (1379, 56), (1420, 7), (1425, 12), (1489, 51), (1491, 39), (1556, 207), (1577, 162), (1587, 61)]
def cs374 : List ℕ := [232, 61, 274, 203, 64, 482, 549, 631, 444, 330, 60, 1000, 1000, 315, 342, 718, 1000, 999, 999, 326, 1001, 659, 676, 1002, 999, 1001, 1000, 1000, 749, 405, 1001, 1000, 1000, 0, 999, 1001, 1000, 1588, 496, 999, 1001, 1000, 871, 1001, 999, 1000, 1002, 1001, 598, 1000, 999, 1001, 1000, 1000, 351, 1000, 1000, 1001, 1000, 1001, 1001, 1000, 999, 1001, 738, 1000, 1000, 1000, 1000, 0, 1001, 1000, 1000, 806, 856, 1001, 0, 1001, 1000, 1000, 1001, 1000, 916, 998, 854, 864, 496, 1001, 999, 1001, 1001, 1001, 1001, 2009, 1000, 0, 1001, 1000, 1000, 1001, 1000, 1001, 1000, 999, 543, 836, 1001, 1001, 1000, 131, 1001, 1001, 1000, 549, 685, 1001, 1001, 60, 1001, 496, 925, 1000, 801, 783, 1000, 969, 234, 1146, 17, 1000, 1002, 234, 933, 1001, 936, 1000, 706, 234, 1001, 1002, 1000, 935, 759, 722, 666, 234, 1001, 621, 889, 766, 873, 556, 916, 664]
theorem loads374 : cs374.get =
    load (fun i : Fin entries374.length => support (entries374.get i).1)
      (fun i => (entries374.get i).2) := by
  apply load_eq_of_sparse_packed base cs374 support code
    entries374 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node374 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 69 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 37 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs374 support demand
    entries374 ((insert 69 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 93 (insert 37 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)) 1000 30 loads374
  decide +kernel
theorem node371 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 37 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 93 (insert 37 (insert 134 (insert 127 ∅)))) : Finset (Fin 154))
    69 node373 node374
def entries372 : List (Fin 1589 × ℕ) := [(10, 169), (75, 31), (77, 27), (86, 126), (122, 157), (177, 183), (179, 107), (466, 68), (472, 196), (475, 228), (479, 247), (484, 3), (507, 132), (514, 219), (531, 11), (542, 163), (571, 139), (587, 83), (588, 196), (616, 133), (617, 320), (625, 224), (631, 135), (632, 31), (639, 230), (731, 104), (737, 21), (812, 349), (819, 111), (843, 90), (844, 21), (847, 174), (850, 177), (855, 274), (858, 118), (870, 182), (886, 271), (895, 52), (898, 32), (904, 145), (906, 128), (914, 467), (920, 109), (921, 141), (924, 86), (928, 85), (938, 50), (948, 38), (949, 201), (952, 118), (973, 203), (978, 376), (1004, 185), (1006, 191), (1010, 11), (1012, 140), (1017, 114), (1021, 49), (1033, 96), (1040, 136), (1049, 198), (1052, 148), (1078, 170), (1081, 16), (1094, 160), (1101, 170), (1123, 57), (1133, 203), (1149, 69), (1160, 273), (1169, 33), (1173, 208), (1212, 293), (1232, 116), (1236, 80), (1275, 114), (1358, 149), (1379, 14), (1469, 115), (1471, 103), (1489, 152), (1491, 17), (1493, 134), (1577, 168), (1584, 116), (1588, 2)]
def cs372 : List ℕ := [318, 0, 539, 405, 496, 357, 286, 935, 0, 132, 291, 1001, 1000, 180, 389, 476, 1000, 1000, 999, 139, 1000, 526, 735, 1001, 1000, 1000, 1000, 999, 523, 954, 1001, 1000, 879, 54, 998, 999, 1000, 2279, 554, 999, 1001, 687, 999, 1000, 1000, 999, 1001, 999, 666, 999, 1000, 1000, 1001, 1000, 208, 1001, 999, 1001, 1000, 859, 1000, 518, 1000, 999, 831, 1000, 1000, 1002, 1000, 1000, 1001, 1000, 999, 1000, 641, 999, 0, 1001, 1000, 1000, 1000, 1000, 852, 999, 1000, 679, 944, 1000, 999, 1000, 999, 1000, 1000, 0, 1000, 177, 1000, 1000, 1000, 999, 999, 1001, 1000, 1001, 726, 384, 1000, 999, 999, 293, 852, 1000, 1000, 690, 978, 772, 999, 293, 836, 703, 471, 1000, 938, 556, 999, 753, 203, 1623, 57, 999, 999, 247, 1000, 999, 728, 999, 480, 236, 999, 1000, 999, 1000, 815, 999, 829, 203, 889, 645, 612, 773, 943, 929, 496, 999]
theorem loads372 : cs372.get =
    load (fun i : Fin entries372.length => support (entries372.get i).1)
      (fun i => (entries372.get i).2) := by
  apply load_eq_of_sparse_packed base cs372 support code
    entries372 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node372 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 134 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs372 support demand
    entries372 ((insert 93 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 37 (insert 134 (insert 127 ∅))) : Finset (Fin 154)) 1000 30 loads372
  decide +kernel
theorem node363 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 134 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 134 (insert 127 ∅))) : Finset (Fin 154))
    93 node371 node372
def entries369 : List (Fin 1589 × ℕ) := [(10, 42), (35, 68), (43, 191), (46, 194), (77, 206), (122, 259), (179, 86), (387, 19), (479, 388), (483, 81), (496, 24), (498, 40), (507, 370), (531, 51), (541, 187), (542, 201), (551, 131), (570, 42), (616, 32), (617, 223), (623, 70), (673, 73), (731, 307), (736, 76), (737, 121), (739, 76), (798, 41), (812, 109), (819, 139), (835, 5), (870, 191), (872, 55), (882, 21), (886, 197), (895, 100), (896, 78), (906, 156), (922, 203), (924, 152), (925, 139), (929, 279), (930, 125), (938, 256), (939, 74), (940, 188), (952, 328), (968, 223), (978, 424), (985, 39), (1004, 172), (1006, 525), (1012, 365), (1017, 110), (1028, 55), (1031, 114), (1040, 64), (1049, 140), (1052, 236), (1056, 34), (1076, 51), (1081, 235), (1086, 27), (1094, 406), (1101, 235), (1149, 364), (1160, 389), (1173, 72), (1182, 83), (1186, 132), (1212, 185), (1217, 449), (1227, 9), (1232, 206), (1233, 86), (1234, 158), (1236, 150), (1263, 100), (1358, 12), (1434, 33), (1469, 44), (1498, 111)]
def cs369 : List ℕ := [611, 0, 491, 0, 580, 859, 385, 999, 265, 370, 206, 802, 1000, 249, 979, 522, 1000, 1000, 1000, 0, 999, 973, 86, 1584, 999, 1001, 1000, 999, 579, 539, 999, 1000, 772, 0, 999, 1000, 1001, 0, 863, 999, 1001, 1001, 303, 1000, 999, 1001, 999, 1000, 854, 1001, 1000, 893, 720, 999, 72, 1001, 1001, 1000, 1000, 1000, 1001, 1000, 533, 1000, 724, 1000, 999, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 609, 999, 0, 869, 1000, 1000, 1000, 1001, 473, 1000, 1001, 906, 899, 1001, 999, 1000, 1000, 1000, 1000, 1000, 840, 188, 1000, 986, 1000, 953, 1834, 1000, 1000, 1001, 508, 557, 1000, 1000, 1000, 540, 1000, 1000, 1001, 746, 836, 1000, 1000, 400, 1000, 441, 985, 999, 999, 517, 1001, 961, 0, 2132, 83, 999, 1001, 0, 938, 1000, 746, 1000, 436, 114, 1000, 1000, 1000, 1110, 645, 733, 789, 0, 996, 403, 560, 753, 966, 523, 400, 998]
theorem loads369 : cs369.get =
    load (fun i : Fin entries369.length => support (entries369.get i).1)
      (fun i => (entries369.get i).2) := by
  apply load_eq_of_sparse_packed base cs369 support code
    entries369 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node369 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 23 (insert 141 (insert 100 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs369 support demand
    entries369 ((insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 23 (insert 141 (insert 100 (insert 134 (insert 127 ∅))))) : Finset (Fin 154)) 1000 30 loads369
  decide +kernel
def entries370 : List (Fin 1589 × ℕ) := [(20, 1), (35, 12), (43, 7), (77, 11), (120, 1), (122, 23), (179, 11), (387, 11), (483, 14), (507, 34), (515, 38), (526, 26), (529, 11), (531, 11), (570, 6), (572, 13), (583, 24), (617, 20), (625, 4), (730, 11), (731, 31), (737, 23), (798, 1), (812, 17), (819, 12), (835, 11), (844, 42), (853, 6), (869, 1), (870, 28), (872, 13), (882, 24), (883, 6), (886, 23), (896, 19), (906, 22), (922, 28), (924, 24), (925, 1), (928, 6), (929, 5), (930, 11), (938, 37), (939, 4), (949, 2), (952, 25), (968, 13), (973, 15), (978, 21), (1004, 18), (1006, 10), (1012, 45), (1017, 7), (1021, 15), (1031, 27), (1040, 2), (1049, 10), (1052, 14), (1056, 2), (1076, 11), (1081, 26), (1094, 44), (1101, 12), (1108, 9), (1133, 1), (1149, 22), (1160, 35), (1173, 25), (1186, 12), (1212, 16), (1227, 17), (1232, 22), (1471, 10), (1489, 3), (1525, 20), (1584, 13)]
def cs370 : List ℕ := [42, 0, 20, 1, 0, 32, 7, 62, 13, 54, 69, 29, 88, 48, 18, 48, 101, 100, 101, 13, 100, 101, 11, 0, 90, 100, 101, 100, 39, 31, 100, 101, 79, 42, 101, 100, 100, 0, 65, 101, 51, 93, 56, 99, 101, 101, 100, 100, 76, 102, 101, 101, 59, 99, 25, 101, 101, 100, 100, 87, 102, 100, 72, 100, 94, 99, 100, 100, 102, 100, 101, 102, 100, 99, 76, 100, 0, 56, 100, 101, 99, 101, 77, 100, 100, 100, 88, 100, 100, 100, 101, 99, 101, 100, 93, 33, 99, 101, 101, 101, 144, 99, 99, 100, 55, 44, 100, 100, 102, 41, 81, 100, 100, 95, 95, 101, 100, 28, 100, 50, 99, 101, 101, 77, 100, 87, 15, 220, 0, 101, 99, 15, 99, 99, 64, 100, 62, 42, 99, 101, 97, 112, 66, 100, 63, 15, 100, 65, 53, 90, 97, 66, 43, 100]
theorem loads370 : cs370.get =
    load (fun i : Fin entries370.length => support (entries370.get i).1)
      (fun i => (entries370.get i).2) := by
  apply load_eq_of_sparse_packed base cs370 support code
    entries370 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node370 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 23 (insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 141 (insert 100 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs370 support demand
    entries370 ((insert 23 (insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 141 (insert 100 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)) 100 30 loads370
  decide +kernel
theorem node367 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 141 (insert 100 (insert 134 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 141 (insert 100 (insert 134 (insert 127 ∅)))) : Finset (Fin 154))
    23 node369 node370
def entries368 : List (Fin 1589 × ℕ) := [(10, 4), (35, 3), (43, 13), (75, 12), (77, 5), (120, 5), (122, 28), (273, 14), (384, 4), (386, 6), (387, 1), (419, 6), (421, 15), (466, 15), (479, 25), (483, 16), (507, 24), (515, 11), (531, 1), (542, 3), (551, 16), (570, 3), (583, 11), (617, 22), (731, 32), (737, 32), (798, 18), (812, 13), (849, 11), (856, 6), (868, 3), (870, 38), (872, 20), (882, 19), (886, 9), (896, 25), (906, 17), (922, 18), (924, 4), (925, 23), (928, 1), (929, 8), (930, 20), (937, 5), (938, 9), (939, 2), (940, 18), (948, 3), (951, 12), (952, 19), (957, 13), (963, 1), (978, 38), (985, 33), (1006, 22), (1009, 6), (1012, 29), (1017, 20), (1021, 20), (1031, 30), (1047, 1), (1076, 20), (1082, 8), (1086, 6), (1094, 32), (1114, 41), (1122, 7), (1133, 22), (1153, 37), (1160, 10), (1182, 24), (1217, 16), (1227, 2), (1232, 18), (1233, 11), (1234, 1), (1236, 15), (1258, 14), (1268, 5), (1292, 9), (1342, 15), (1358, 7), (1360, 2), (1469, 8), (1525, 2), (1580, 18), (1588, 12)]
def cs368 : List ℕ := [53, 0, 22, 11, 62, 65, 13, 98, 3, 26, 42, 91, 95, 51, 51, 68, 100, 100, 100, 5, 99, 100, 0, 99, 99, 100, 99, 100, 46, 28, 100, 99, 67, 0, 100, 101, 99, 0, 57, 100, 98, 88, 27, 100, 100, 101, 99, 99, 84, 100, 99, 99, 72, 101, 0, 100, 100, 99, 99, 100, 99, 100, 100, 99, 94, 100, 99, 99, 101, 100, 99, 100, 100, 100, 55, 100, 0, 100, 99, 99, 99, 99, 61, 100, 88, 99, 79, 100, 100, 100, 99, 100, 101, 100, 92, 34, 100, 100, 99, 100, 163, 100, 99, 100, 22, 69, 100, 100, 100, 3, 100, 100, 99, 68, 100, 99, 100, 37, 75, 40, 99, 99, 100, 100, 99, 48, 0, 121, 31, 100, 99, 0, 100, 100, 105, 99, 0, 31, 99, 100, 97, 0, 73, 69, 99, 0, 61, 11, 74, 41, 85, 42, 77, 41]
theorem loads368 : cs368.get =
    load (fun i : Fin entries368.length => support (entries368.get i).1)
      (fun i => (entries368.get i).2) := by
  apply load_eq_of_sparse_packed base cs368 support code
    entries368 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node368 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 141 (insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 100 (insert 134 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs368 support demand
    entries368 ((insert 141 (insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 100 (insert 134 (insert 127 ∅))) : Finset (Fin 154)) 100 30 loads368
  decide +kernel
theorem node365 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 100 (insert 134 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 100 (insert 134 (insert 127 ∅))) : Finset (Fin 154))
    141 node367 node368
def entries366 : List (Fin 1589 × ℕ) := [(35, 256), (72, 25), (86, 127), (122, 211), (137, 166), (179, 97), (203, 59), (384, 180), (466, 73), (507, 352), (531, 102), (542, 166), (570, 69), (572, 59), (617, 211), (625, 170), (639, 55), (730, 122), (731, 227), (737, 96), (738, 19), (739, 230), (812, 180), (815, 55), (819, 53), (835, 283), (844, 42), (868, 197), (870, 402), (872, 236), (882, 161), (886, 123), (896, 121), (905, 124), (918, 178), (920, 79), (923, 78), (924, 197), (929, 88), (930, 42), (938, 323), (949, 25), (966, 49), (978, 385), (1004, 401), (1006, 358), (1012, 214), (1017, 18), (1028, 110), (1030, 75), (1049, 47), (1052, 120), (1056, 79), (1076, 29), (1081, 195), (1086, 50), (1094, 384), (1101, 23), (1123, 170), (1149, 358), (1153, 137), (1160, 370), (1173, 285), (1217, 58), (1220, 44), (1226, 50), (1227, 185), (1229, 79), (1233, 116), (1236, 16), (1249, 163), (1263, 163), (1267, 35), (1280, 28), (1292, 133), (1320, 9), (1358, 160), (1360, 234), (1489, 119), (1491, 59), (1498, 118), (1525, 83), (1587, 29)]
def cs366 : List ℕ := [421, 101, 141, 44, 16, 609, 0, 533, 419, 435, 438, 937, 835, 623, 191, 578, 1002, 1000, 1001, 59, 1000, 715, 97, 1001, 1001, 1000, 1001, 1001, 441, 353, 1001, 1001, 916, 42, 1001, 1000, 1001, 0, 556, 1001, 1002, 1000, 401, 1000, 1001, 1000, 1000, 1000, 707, 1001, 1000, 1002, 711, 1001, 285, 1000, 1000, 999, 1000, 980, 1000, 1000, 1001, 949, 1001, 853, 1000, 1001, 1001, 999, 1000, 1000, 1000, 1000, 803, 1000, 50, 668, 1000, 1001, 1000, 1001, 767, 1000, 999, 1001, 839, 1001, 1000, 1000, 1001, 1000, 1000, 1001, 1000, 144, 1001, 1000, 1001, 1000, 0, 1000, 1000, 1000, 543, 505, 1000, 1001, 637, 313, 772, 1001, 999, 718, 723, 373, 999, 49, 1001, 98, 999, 1001, 515, 909, 999, 1001, 0, 2004, 179, 1000, 1000, 75, 1000, 1000, 505, 1000, 643, 0, 1000, 1000, 896, 908, 466, 800, 999, 0, 1001, 279, 367, 643, 921, 234, 622, 799]
theorem loads366 : cs366.get =
    load (fun i : Fin entries366.length => support (entries366.get i).1)
      (fun i => (entries366.get i).2) := by
  apply load_eq_of_sparse_packed base cs366 support code
    entries366 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node366 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 100 (insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 134 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs366 support demand
    entries366 ((insert 100 (insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 134 (insert 127 ∅)) : Finset (Fin 154)) 1000 30 loads366
  decide +kernel
theorem node364 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 134 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 134 (insert 127 ∅)) : Finset (Fin 154))
    100 node365 node366
theorem node362 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 134 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 128 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 134 (insert 127 ∅)) : Finset (Fin 154))
    37 node363 node364
theorem node341 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 134 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 134 (insert 127 ∅)) : Finset (Fin 154))
    128 node361 node362
def entries359 : List (Fin 1589 × ℕ) := [(46, 23), (77, 8), (120, 7), (122, 12), (179, 12), (205, 7), (439, 26), (472, 15), (475, 22), (478, 1), (491, 13), (494, 36), (507, 34), (529, 10), (530, 15), (542, 13), (617, 19), (630, 6), (639, 8), (673, 2), (736, 5), (797, 9), (814, 23), (816, 2), (832, 6), (835, 31), (847, 9), (850, 18), (855, 26), (858, 11), (870, 12), (872, 7), (882, 10), (886, 57), (894, 2), (906, 13), (912, 23), (914, 22), (922, 39), (925, 9), (928, 22), (930, 8), (940, 4), (951, 12), (952, 7), (963, 2), (973, 31), (978, 12), (1004, 2), (1006, 43), (1012, 35), (1033, 17), (1049, 17), (1052, 15), (1076, 5), (1081, 23), (1086, 6), (1090, 35), (1094, 32), (1114, 3), (1123, 33), (1131, 9), (1149, 7), (1160, 60), (1164, 1), (1173, 19), (1220, 24), (1241, 3), (1324, 6), (1403, 9), (1434, 6), (1447, 7), (1481, 14), (1489, 8), (1537, 4), (1548, 3), (1565, 12), (1566, 23), (1577, 27), (1580, 12)]
def cs359 : List ℕ := [24, 24, 28, 64, 13, 30, 74, 101, 10, 34, 8, 98, 100, 60, 83, 56, 100, 100, 193, 6, 100, 44, 47, 87, 100, 100, 100, 100, 62, 100, 101, 100, 100, 0, 101, 100, 100, 217, 100, 101, 86, 99, 77, 99, 100, 100, 100, 100, 59, 101, 100, 100, 99, 100, 19, 100, 100, 198, 100, 100, 100, 97, 100, 100, 81, 100, 100, 99, 101, 100, 100, 100, 100, 100, 98, 99, 0, 100, 99, 99, 100, 99, 69, 100, 101, 86, 79, 99, 101, 100, 100, 100, 100, 233, 72, 0, 100, 100, 101, 100, 100, 99, 100, 100, 57, 49, 100, 100, 100, 5, 91, 100, 100, 72, 60, 99, 149, 0, 100, 40, 101, 100, 38, 81, 100, 100, 31, 205, 59, 100, 100, 31, 100, 100, 0, 91, 57, 31, 100, 95, 91, 97, 40, 100, 93, 31, 61, 66, 35, 69, 100, 31, 31, 95]
theorem loads359 : cs359.get =
    load (fun i : Fin entries359.length => support (entries359.get i).1)
      (fun i => (entries359.get i).2) := by
  apply load_eq_of_sparse_packed base cs359 support code
    entries359 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node359 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 93 (insert 18 (insert 37 (insert 116 (insert 127 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs359 support demand
    entries359 ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 57 (insert 93 (insert 18 (insert 37 (insert 116 (insert 127 ∅)))))) : Finset (Fin 154)) 100 30 loads359
  decide +kernel
def entries360 : List (Fin 1589 × ℕ) := [(20, 10), (46, 34), (77, 13), (86, 13), (122, 13), (135, 4), (179, 3), (203, 2), (273, 1), (387, 4), (420, 10), (439, 12), (475, 9), (478, 18), (479, 4), (491, 6), (494, 33), (506, 12), (507, 19), (531, 9), (572, 33), (588, 41), (617, 12), (624, 36), (631, 2), (639, 15), (730, 14), (736, 8), (797, 42), (816, 15), (832, 32), (835, 16), (850, 6), (855, 46), (886, 36), (896, 17), (904, 3), (906, 28), (916, 12), (922, 17), (938, 2), (940, 26), (947, 12), (948, 3), (949, 3), (952, 28), (973, 40), (978, 3), (1006, 26), (1012, 34), (1030, 10), (1033, 8), (1049, 23), (1052, 6), (1061, 15), (1090, 40), (1094, 15), (1114, 3), (1123, 28), (1149, 3), (1160, 45), (1173, 31), (1183, 15), (1188, 24), (1220, 23), (1261, 9), (1280, 6), (1315, 2), (1358, 9), (1379, 15), (1517, 11), (1525, 7), (1577, 23)]
def cs360 : List ℕ := [38, 29, 7, 48, 22, 52, 74, 100, 10, 38, 35, 100, 99, 19, 70, 36, 100, 100, 137, 33, 100, 79, 44, 100, 100, 99, 101, 101, 62, 49, 100, 100, 100, 0, 100, 100, 99, 159, 16, 100, 100, 87, 85, 86, 100, 100, 99, 100, 54, 100, 100, 101, 101, 99, 31, 100, 100, 0, 100, 98, 101, 100, 101, 99, 93, 99, 100, 101, 99, 100, 101, 74, 99, 100, 99, 100, 24, 100, 99, 100, 83, 101, 98, 100, 101, 90, 46, 98, 101, 100, 100, 100, 100, 256, 69, 10, 99, 99, 101, 100, 100, 99, 100, 102, 66, 64, 100, 100, 100, 0, 69, 100, 96, 51, 62, 93, 161, 15, 100, 52, 78, 99, 62, 97, 100, 100, 40, 156, 79, 100, 100, 50, 88, 100, 0, 96, 74, 40, 100, 101, 85, 99, 55, 100, 88, 40, 91, 80, 55, 77, 100, 40, 40, 100]
theorem loads360 : cs360.get =
    load (fun i : Fin entries360.length => support (entries360.get i).1)
      (fun i => (entries360.get i).2) := by
  apply load_eq_of_sparse_packed base cs360 support code
    entries360 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node360 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 57 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 18 (insert 37 (insert 116 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs360 support demand
    entries360 ((insert 57 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 93 (insert 18 (insert 37 (insert 116 (insert 127 ∅))))) : Finset (Fin 154)) 100 30 loads360
  decide +kernel
theorem node357 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 18 (insert 37 (insert 116 (insert 127 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 93 (insert 18 (insert 37 (insert 116 (insert 127 ∅))))) : Finset (Fin 154))
    57 node359 node360
def entries358 : List (Fin 1589 × ℕ) := [(77, 18), (86, 5), (122, 24), (352, 21), (399, 9), (415, 10), (472, 14), (475, 21), (478, 8), (479, 20), (491, 13), (494, 1), (506, 5), (507, 41), (514, 14), (531, 34), (542, 8), (588, 27), (616, 11), (617, 21), (625, 29), (632, 18), (639, 13), (672, 2), (675, 9), (681, 18), (814, 21), (846, 14), (850, 9), (855, 41), (858, 6), (870, 16), (886, 41), (895, 5), (897, 26), (906, 22), (914, 34), (916, 11), (920, 6), (925, 6), (928, 5), (938, 8), (949, 13), (952, 32), (966, 3), (978, 23), (1004, 29), (1006, 39), (1012, 18), (1017, 6), (1033, 19), (1040, 4), (1049, 36), (1052, 27), (1076, 4), (1081, 11), (1086, 14), (1094, 27), (1101, 5), (1108, 8), (1123, 28), (1149, 32), (1160, 51), (1173, 12), (1183, 8), (1220, 29), (1228, 12), (1231, 10), (1269, 10), (1280, 1), (1297, 5), (1310, 1), (1471, 2), (1489, 2), (1499, 14), (1577, 16), (1580, 13), (1584, 17)]
def cs358 : List ℕ := [30, 44, 14, 59, 41, 42, 35, 100, 0, 46, 32, 101, 101, 47, 55, 40, 99, 102, 208, 0, 100, 31, 53, 100, 99, 100, 100, 100, 86, 52, 100, 100, 100, 0, 101, 100, 98, 225, 43, 101, 99, 101, 99, 76, 100, 100, 99, 99, 25, 99, 101, 100, 80, 100, 26, 101, 101, 100, 100, 80, 99, 100, 100, 99, 56, 100, 100, 101, 100, 100, 100, 100, 99, 54, 73, 100, 0, 100, 99, 100, 99, 100, 47, 94, 93, 96, 73, 99, 99, 100, 99, 99, 100, 0, 89, 43, 100, 99, 101, 99, 100, 99, 99, 100, 69, 47, 100, 99, 100, 0, 74, 100, 76, 66, 95, 77, 126, 11, 100, 15, 37, 100, 59, 37, 100, 83, 0, 210, 46, 100, 100, 0, 99, 100, 0, 89, 44, 0, 100, 100, 59, 100, 49, 100, 87, 0, 89, 37, 45, 59, 100, 0, 10, 86]
theorem loads358 : cs358.get =
    load (fun i : Fin entries358.length => support (entries358.get i).1)
      (fun i => (entries358.get i).2) := by
  apply load_eq_of_sparse_packed base cs358 support code
    entries358 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node358 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 37 (insert 116 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs358 support demand
    entries358 ((insert 93 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 37 (insert 116 (insert 127 ∅)))) : Finset (Fin 154)) 100 30 loads358
  decide +kernel
theorem node355 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 37 (insert 116 (insert 127 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 18 (insert 37 (insert 116 (insert 127 ∅)))) : Finset (Fin 154))
    93 node357 node358
def entries356 : List (Fin 1589 × ℕ) := [(7, 324), (72, 130), (77, 249), (86, 122), (122, 6), (137, 95), (415, 58), (439, 63), (472, 321), (491, 103), (494, 84), (496, 44), (497, 84), (498, 91), (572, 320), (583, 123), (588, 247), (617, 58), (625, 179), (631, 120), (639, 66), (675, 105), (731, 266), (737, 57), (814, 269), (817, 91), (842, 17), (843, 83), (844, 98), (856, 185), (857, 8), (865, 22), (870, 6), (886, 220), (896, 62), (906, 166), (912, 131), (914, 444), (920, 118), (922, 228), (925, 140), (928, 72), (940, 197), (948, 45), (952, 193), (966, 105), (973, 67), (978, 195), (1004, 45), (1006, 195), (1012, 383), (1017, 219), (1021, 91), (1030, 171), (1033, 61), (1040, 89), (1049, 106), (1052, 20), (1061, 249), (1076, 120), (1081, 190), (1090, 43), (1094, 138), (1104, 98), (1123, 366), (1149, 280), (1160, 481), (1173, 268), (1183, 70), (1228, 186), (1231, 76), (1263, 41), (1358, 363), (1403, 221), (1483, 71), (1491, 235), (1501, 132), (1517, 246), (1552, 27), (1577, 159), (1584, 100)]
def cs356 : List ℕ := [461, 324, 321, 0, 324, 185, 516, 866, 260, 0, 401, 999, 906, 324, 538, 400, 999, 999, 0, 320, 999, 556, 379, 999, 881, 999, 968, 999, 564, 793, 999, 1000, 1000, 98, 999, 1001, 999, 1710, 451, 999, 1000, 999, 686, 1001, 1000, 1000, 1001, 999, 272, 999, 999, 999, 944, 1001, 268, 1000, 999, 1000, 1000, 1001, 999, 879, 999, 999, 935, 1000, 999, 1000, 998, 1001, 999, 1000, 999, 585, 1001, 1000, 0, 999, 999, 1000, 1000, 1000, 884, 1000, 1001, 831, 710, 999, 999, 1000, 999, 1000, 1000, 1000, 1001, 171, 1000, 999, 1001, 999, 1000, 1001, 999, 1001, 432, 900, 1000, 1001, 1000, 0, 668, 1000, 792, 905, 1000, 1001, 1565, 175, 1001, 412, 625, 1000, 537, 621, 1000, 901, 67, 1684, 655, 1000, 1000, 238, 795, 1001, 0, 1000, 615, 67, 1000, 1001, 666, 1000, 519, 897, 1000, 67, 947, 396, 497, 691, 903, 67, 67, 880]
theorem loads356 : cs356.get =
    load (fun i : Fin entries356.length => support (entries356.get i).1)
      (fun i => (entries356.get i).2) := by
  apply load_eq_of_sparse_packed base cs356 support code
    entries356 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node356 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 18 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 116 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs356 support demand
    entries356 ((insert 18 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 37 (insert 116 (insert 127 ∅))) : Finset (Fin 154)) 1000 30 loads356
  decide +kernel
theorem node351 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 116 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 116 (insert 127 ∅))) : Finset (Fin 154))
    18 node355 node356
def entries353 : List (Fin 1589 × ℕ) := [(20, 3), (46, 17), (72, 52), (86, 7), (122, 25), (384, 8), (387, 7), (439, 3), (472, 10), (479, 4), (496, 15), (507, 30), (515, 1), (531, 6), (542, 15), (551, 6), (572, 8), (583, 10), (617, 10), (731, 40), (736, 16), (737, 16), (814, 17), (842, 2), (844, 2), (846, 7), (847, 18), (869, 11), (870, 23), (872, 27), (882, 14), (886, 5), (896, 6), (906, 5), (922, 18), (925, 21), (928, 23), (929, 16), (930, 9), (937, 8), (938, 16), (939, 3), (940, 14), (943, 10), (952, 39), (966, 17), (973, 6), (978, 20), (1004, 34), (1006, 36), (1028, 29), (1033, 12), (1040, 2), (1049, 22), (1052, 19), (1061, 28), (1076, 29), (1081, 15), (1093, 44), (1101, 9), (1114, 4), (1123, 26), (1149, 17), (1160, 40), (1173, 15), (1183, 4), (1188, 10), (1220, 10), (1236, 17), (1267, 22), (1280, 2), (1292, 24), (1297, 19), (1358, 30), (1403, 4), (1491, 6), (1537, 1), (1548, 3), (1584, 25)]
def cs353 : List ℕ := [61, 19, 29, 13, 21, 44, 17, 101, 19, 30, 77, 100, 101, 37, 84, 51, 100, 100, 101, 8, 101, 80, 0, 101, 101, 101, 100, 102, 99, 20, 100, 102, 57, 2, 100, 101, 101, 0, 100, 101, 101, 58, 51, 88, 101, 100, 102, 101, 75, 100, 100, 100, 89, 100, 15, 100, 99, 101, 100, 99, 100, 100, 100, 73, 87, 53, 227, 99, 99, 100, 101, 100, 100, 100, 81, 100, 10, 99, 99, 101, 100, 101, 66, 99, 94, 100, 56, 100, 100, 100, 99, 100, 100, 101, 101, 0, 99, 100, 99, 99, 100, 99, 100, 100, 47, 68, 100, 99, 99, 13, 91, 100, 101, 82, 98, 57, 149, 21, 99, 15, 99, 100, 77, 40, 99, 74, 6, 218, 43, 101, 98, 6, 100, 99, 0, 99, 38, 6, 98, 99, 46, 86, 58, 99, 70, 6, 61, 31, 73, 61, 55, 6, 6, 69]
theorem loads353 : cs353.get =
    load (fun i : Fin entries353.length => support (entries353.get i).1)
      (fun i => (entries353.get i).2) := by
  apply load_eq_of_sparse_packed base cs353 support code
    entries353 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node353 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 116 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs353 support demand
    entries353 ((insert 37 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 66 (insert 116 (insert 127 ∅))) : Finset (Fin 154)) 100 30 loads353
  decide +kernel
def entries354 : List (Fin 1589 × ℕ) := [(10, 8), (17, 19), (20, 15), (46, 24), (77, 3), (86, 7), (179, 2), (315, 24), (399, 3), (439, 6), (483, 8), (506, 8), (507, 23), (542, 19), (617, 23), (625, 13), (673, 4), (731, 15), (737, 1), (739, 5), (797, 22), (814, 13), (835, 8), (847, 41), (868, 24), (870, 20), (882, 15), (886, 23), (895, 1), (896, 3), (906, 12), (920, 8), (922, 8), (925, 35), (938, 27), (940, 18), (955, 4), (966, 15), (973, 29), (978, 3), (985, 1), (1004, 15), (1006, 36), (1012, 48), (1017, 3), (1028, 1), (1030, 29), (1052, 3), (1061, 3), (1081, 26), (1086, 5), (1093, 17), (1101, 27), (1111, 9), (1114, 14), (1123, 16), (1149, 14), (1160, 33), (1167, 7), (1183, 31), (1188, 17), (1220, 5), (1234, 14), (1236, 16), (1246, 9), (1263, 11), (1266, 14), (1268, 9), (1285, 4), (1297, 7), (1342, 5), (1358, 35), (1400, 9), (1477, 20), (1498, 10), (1537, 2), (1551, 7), (1584, 20)]
def cs354 : List ℕ := [56, 5, 51, 43, 24, 36, 24, 99, 51, 31, 27, 87, 100, 64, 46, 25, 99, 100, 99, 9, 99, 66, 2, 99, 83, 100, 99, 101, 23, 41, 99, 99, 76, 7, 100, 100, 100, 0, 53, 100, 100, 100, 15, 91, 100, 100, 101, 99, 62, 101, 100, 99, 57, 100, 0, 100, 99, 100, 99, 101, 99, 99, 84, 98, 78, 100, 0, 100, 100, 99, 100, 100, 98, 99, 87, 100, 17, 86, 99, 100, 100, 99, 98, 99, 99, 84, 89, 100, 100, 100, 100, 99, 101, 99, 39, 39, 100, 100, 99, 101, 100, 100, 100, 100, 27, 100, 99, 101, 101, 4, 75, 100, 99, 99, 81, 94, 153, 46, 100, 85, 68, 100, 50, 78, 100, 86, 29, 185, 70, 101, 100, 65, 99, 100, 0, 100, 43, 36, 100, 101, 72, 96, 74, 90, 80, 29, 81, 65, 84, 64, 83, 29, 29, 100]
theorem loads354 : cs354.get =
    load (fun i : Fin entries354.length => support (entries354.get i).1)
      (fun i => (entries354.get i).2) := by
  apply load_eq_of_sparse_packed base cs354 support code
    entries354 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node354 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 66 (insert 37 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 116 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs354 support demand
    entries354 ((insert 66 (insert 37 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 116 (insert 127 ∅)) : Finset (Fin 154)) 100 30 loads354
  decide +kernel
theorem node352 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 116 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 116 (insert 127 ∅)) : Finset (Fin 154))
    66 node353 node354
theorem node343 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 116 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 116 (insert 127 ∅)) : Finset (Fin 154))
    37 node351 node352
def entries349 : List (Fin 1589 × ℕ) := [(10, 57), (77, 333), (86, 20), (122, 337), (179, 165), (287, 19), (353, 90), (384, 120), (419, 63), (439, 122), (472, 282), (475, 3), (491, 31), (507, 137), (542, 132), (571, 165), (572, 151), (583, 83), (617, 20), (632, 78), (639, 89), (675, 168), (730, 356), (736, 43), (737, 26), (777, 132), (813, 334), (846, 169), (850, 323), (856, 23), (868, 37), (870, 145), (872, 239), (881, 2), (882, 40), (886, 169), (898, 38), (905, 27), (906, 168), (913, 275), (918, 224), (922, 60), (925, 361), (928, 151), (929, 45), (938, 120), (948, 81), (949, 13), (952, 285), (958, 143), (973, 103), (978, 207), (984, 136), (985, 238), (1004, 308), (1006, 34), (1030, 43), (1049, 77), (1070, 451), (1076, 520), (1081, 120), (1090, 511), (1093, 379), (1098, 81), (1101, 44), (1111, 72), (1123, 103), (1131, 17), (1160, 778), (1173, 86), (1220, 87), (1227, 76), (1234, 22), (1236, 180), (1257, 296), (1263, 95), (1267, 86), (1268, 41), (1277, 119), (1339, 103), (1356, 7), (1358, 281), (1400, 7), (1471, 71), (1517, 48), (1577, 205)]
def cs349 : List ℕ := [548, 256, 346, 413, 244, 203, 284, 999, 95, 137, 370, 1000, 999, 344, 670, 584, 999, 999, 999, 357, 1001, 812, 203, 1000, 999, 1000, 999, 1000, 756, 518, 999, 1000, 549, 0, 999, 999, 1000, 1001, 792, 999, 1000, 476, 544, 999, 1000, 1000, 999, 1001, 880, 998, 1000, 1000, 974, 999, 86, 1000, 1000, 999, 1000, 999, 1000, 872, 1000, 1000, 998, 806, 1000, 1001, 999, 1001, 1000, 1000, 1000, 999, 408, 999, 0, 1000, 1002, 999, 1000, 1000, 880, 999, 1000, 937, 595, 1000, 999, 999, 998, 999, 1000, 999, 1000, 43, 1001, 999, 1000, 998, 1000, 1000, 999, 1001, 634, 955, 1001, 999, 758, 0, 1000, 999, 820, 779, 1001, 999, 0, 143, 1000, 207, 967, 1000, 491, 999, 1000, 223, 103, 1253, 810, 858, 2623, 146, 862, 1000, 0, 1000, 189, 103, 1897, 999, 897, 881, 1000, 1000, 1000, 103, 485, 982, 897, 206, 621, 103, 399, 1000]
theorem loads349 : cs349.get =
    load (fun i : Fin entries349.length => support (entries349.get i).1)
      (fun i => (entries349.get i).2) := by
  apply load_eq_of_sparse_packed base cs349 support code
    entries349 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node349 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 138 (insert 130 (insert 127 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs349 support demand
    entries349 ((insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 138 (insert 130 (insert 127 ∅))) : Finset (Fin 154)) 1000 30 loads349
  decide +kernel
def entries350 : List (Fin 1589 × ℕ) := [(43, 129), (77, 21), (86, 127), (122, 310), (177, 19), (179, 20), (273, 62), (384, 91), (419, 20), (466, 243), (472, 251), (479, 90), (491, 130), (507, 122), (542, 184), (550, 98), (616, 88), (617, 220), (625, 213), (639, 99), (730, 157), (731, 95), (737, 57), (813, 334), (819, 41), (835, 187), (846, 59), (850, 411), (858, 3), (867, 51), (868, 101), (870, 262), (872, 115), (886, 236), (896, 194), (898, 201), (905, 51), (906, 141), (914, 86), (918, 23), (920, 83), (922, 190), (924, 13), (925, 110), (929, 67), (938, 196), (952, 104), (984, 491), (985, 101), (1004, 374), (1006, 194), (1012, 34), (1030, 28), (1031, 35), (1049, 179), (1056, 200), (1070, 44), (1081, 25), (1090, 246), (1093, 383), (1111, 89), (1123, 269), (1126, 54), (1131, 393), (1149, 272), (1173, 335), (1183, 148), (1234, 106), (1236, 37), (1240, 29), (1263, 193), (1268, 169), (1339, 86), (1358, 115), (1485, 83), (1489, 200), (1491, 105), (1509, 81), (1517, 8), (1525, 37), (1562, 9), (1580, 10), (1587, 77)]
def cs350 : List ℕ := [395, 136, 288, 411, 137, 37, 270, 919, 193, 159, 291, 999, 999, 371, 344, 671, 1000, 999, 1000, 169, 1000, 826, 240, 999, 1000, 1001, 1001, 999, 544, 283, 1000, 999, 713, 0, 1001, 1000, 1000, 1000, 471, 999, 1000, 1000, 585, 1000, 999, 999, 999, 1000, 716, 1001, 1000, 1000, 642, 1000, 335, 1000, 1000, 999, 999, 946, 1001, 1000, 1000, 865, 1002, 999, 1000, 1000, 989, 1000, 1000, 1000, 1001, 1000, 644, 1001, 0, 1000, 1000, 999, 1000, 1000, 696, 1000, 999, 930, 676, 1002, 999, 999, 1001, 1000, 1001, 998, 1000, 151, 1001, 1000, 1000, 1002, 1000, 1000, 1000, 1001, 778, 593, 999, 1001, 1000, 0, 685, 1001, 999, 851, 1001, 1000, 34, 231, 1000, 421, 999, 1000, 918, 515, 554, 801, 0, 1299, 751, 996, 915, 28, 452, 1000, 0, 1000, 607, 35, 148, 1000, 335, 855, 348, 54, 417, 0, 755, 389, 531, 1000, 417, 0, 0, 148]
theorem loads350 : cs350.get =
    load (fun i : Fin entries350.length => support (entries350.get i).1)
      (fun i => (entries350.get i).2) := by
  apply load_eq_of_sparse_packed base cs350 support code
    entries350 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node350 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 138 (insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 130 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs350 support demand
    entries350 ((insert 138 (insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 130 (insert 127 ∅)) : Finset (Fin 154)) 1000 30 loads350
  decide +kernel
theorem node345 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 130 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 130 (insert 127 ∅)) : Finset (Fin 154))
    138 node349 node350
def entries347 : List (Fin 1589 × ℕ) := [(43, 183), (75, 55), (86, 28), (122, 136), (177, 214), (179, 160), (273, 89), (384, 188), (399, 94), (466, 107), (472, 229), (475, 328), (479, 273), (507, 205), (531, 34), (542, 217), (588, 16), (616, 42), (617, 320), (639, 177), (730, 211), (737, 37), (813, 355), (819, 74), (835, 342), (850, 207), (858, 126), (868, 91), (870, 334), (881, 45), (882, 37), (886, 270), (894, 20), (895, 93), (896, 158), (906, 169), (913, 24), (914, 159), (920, 82), (922, 170), (928, 11), (938, 20), (949, 174), (951, 24), (952, 74), (957, 32), (963, 4), (973, 215), (978, 36), (984, 449), (1004, 191), (1006, 300), (1030, 202), (1040, 83), (1055, 26), (1061, 109), (1081, 74), (1093, 156), (1114, 143), (1123, 329), (1131, 151), (1138, 158), (1149, 81), (1173, 404), (1220, 73), (1231, 228), (1246, 200), (1249, 72), (1263, 76), (1267, 71), (1268, 46), (1292, 135), (1312, 43), (1358, 38), (1374, 99), (1379, 38), (1489, 178), (1491, 136), (1500, 36), (1537, 23), (1577, 17), (1578, 74), (1580, 72), (1582, 12)]
def cs347 : List ℕ := [218, 73, 252, 620, 419, 170, 412, 889, 99, 205, 405, 999, 999, 175, 618, 457, 999, 999, 1000, 46, 1000, 904, 390, 998, 1000, 1000, 1000, 999, 207, 795, 999, 999, 774, 0, 1000, 998, 1001, 1001, 806, 999, 999, 998, 348, 1000, 1000, 1000, 999, 1001, 1000, 999, 1000, 999, 720, 1000, 404, 1000, 1000, 999, 1001, 999, 1000, 1000, 1000, 937, 841, 1000, 1000, 1000, 999, 1000, 999, 1000, 1002, 1000, 742, 1000, 36, 814, 1001, 1000, 999, 1000, 845, 1000, 1000, 1000, 717, 1001, 999, 1000, 1001, 1000, 1000, 1000, 518, 338, 1001, 1000, 1001, 1000, 999, 1000, 999, 1000, 724, 480, 1001, 1001, 999, 4, 1000, 1000, 981, 704, 1001, 941, 109, 32, 1000, 796, 932, 1001, 1000, 290, 557, 1000, 215, 1074, 878, 1000, 72, 417, 600, 1000, 0, 1000, 700, 241, 709, 999, 500, 857, 515, 324, 365, 215, 1000, 287, 829, 1222, 880, 215, 287, 443]
theorem loads347 : cs347.get =
    load (fun i : Fin entries347.length => support (entries347.get i).1)
      (fun i => (entries347.get i).2) := by
  apply load_eq_of_sparse_packed base cs347 support code
    entries347 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node347 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 130 (insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 149 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs347 support demand
    entries347 ((insert 130 (insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 149 (insert 127 ∅)) : Finset (Fin 154)) 1000 30 loads347
  decide +kernel
def entries348 : List (Fin 1589 × ℕ) := [(20, 14), (35, 5), (43, 11), (122, 54), (179, 4), (273, 6), (384, 20), (430, 20), (466, 21), (472, 12), (475, 11), (479, 22), (491, 4), (507, 20), (531, 6), (542, 10), (550, 1), (551, 6), (588, 11), (617, 30), (623, 3), (625, 5), (632, 16), (673, 11), (681, 16), (730, 15), (731, 18), (736, 12), (813, 38), (819, 10), (835, 26), (847, 4), (850, 22), (858, 15), (870, 37), (872, 15), (882, 7), (886, 21), (895, 12), (896, 22), (898, 15), (906, 17), (914, 2), (920, 22), (922, 17), (925, 19), (929, 19), (938, 8), (949, 11), (951, 2), (952, 18), (966, 17), (984, 59), (985, 7), (995, 15), (1004, 19), (1006, 27), (1010, 4), (1021, 8), (1030, 19), (1040, 21), (1049, 10), (1055, 13), (1081, 47), (1086, 4), (1093, 18), (1123, 31), (1127, 43), (1138, 7), (1163, 46), (1183, 5), (1220, 2), (1236, 13), (1246, 2), (1292, 4), (1358, 7), (1374, 4), (1498, 21), (1577, 6), (1580, 19)]
def cs348 : List ℕ := [43, 2, 16, 49, 54, 43, 36, 100, 19, 20, 4, 101, 101, 59, 46, 95, 101, 101, 99, 0, 101, 99, 30, 100, 100, 100, 100, 100, 62, 52, 101, 99, 89, 0, 99, 99, 101, 102, 41, 99, 99, 100, 46, 100, 98, 100, 99, 100, 93, 100, 101, 98, 56, 99, 0, 100, 100, 99, 101, 99, 100, 71, 101, 83, 82, 100, 99, 101, 100, 100, 99, 99, 100, 100, 46, 101, 0, 92, 99, 100, 100, 98, 100, 100, 100, 99, 79, 100, 100, 100, 100, 100, 100, 99, 67, 43, 100, 100, 99, 100, 99, 99, 99, 100, 51, 95, 100, 100, 66, 0, 94, 100, 99, 52, 100, 62, 4, 22, 100, 23, 100, 100, 61, 33, 45, 35, 0, 159, 81, 100, 5, 23, 26, 100, 0, 75, 0, 13, 101, 50, 38, 78, 51, 4, 36, 0, 94, 0, 76, 0, 82, 0, 46, 5]
theorem loads348 : cs348.get =
    load (fun i : Fin entries348.length => support (entries348.get i).1)
      (fun i => (entries348.get i).2) := by
  apply load_eq_of_sparse_packed base cs348 support code
    entries348 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node348 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 149 (insert 130 (insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 127 ∅) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs348 support demand
    entries348 ((insert 149 (insert 130 (insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 127 ∅) : Finset (Fin 154)) 100 30 loads348
  decide +kernel
theorem node346 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 130 (insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 127 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 130 (insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 127 ∅) : Finset (Fin 154))
    149 node347 node348
theorem node344 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 127 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 116 (insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 127 ∅) : Finset (Fin 154))
    130 node345 node346
theorem node342 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 127 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 134 (insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 127 ∅) : Finset (Fin 154))
    116 node343 node344
theorem node340 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 127 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 137 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 127 ∅) : Finset (Fin 154))
    134 node341 node342
#print axioms node340
end OmissionResidualCover
