import ResidualCoverProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries153 : List (Fin 1589 × ℕ) := [(20, 5), (72, 18), (86, 47), (122, 4), (198, 6), (384, 3), (387, 5), (439, 28), (475, 3), (479, 3), (494, 14), (507, 45), (515, 14), (526, 23), (529, 7), (552, 10), (569, 27), (570, 58), (572, 20), (587, 6), (588, 3), (617, 17), (624, 8), (625, 14), (690, 3), (730, 8), (731, 2), (737, 9), (741, 1), (815, 5), (846, 15), (847, 31), (855, 57), (867, 13), (869, 29), (886, 53), (904, 1), (920, 5), (924, 3), (929, 10), (930, 10), (938, 2), (950, 1), (973, 28), (984, 63), (995, 8), (1005, 1), (1009, 11), (1010, 8), (1018, 8), (1020, 22), (1030, 33), (1055, 2), (1056, 14), (1090, 38), (1097, 15), (1114, 7), (1128, 3), (1137, 10), (1139, 15), (1149, 17), (1153, 21), (1173, 28), (1182, 26), (1188, 12), (1235, 14), (1261, 19), (1275, 21), (1292, 17), (1374, 2), (1466, 19), (1489, 16), (1491, 12), (1496, 8), (1517, 4), (1577, 7), (1578, 7), (1580, 29)]
def cs153 : List ℕ := [0, 15, 31, 8, 39, 74, 18, 99, 5, 45, 77, 97, 100, 41, 61, 40, 99, 100, 272, 20, 99, 11, 9, 99, 99, 260, 99, 99, 44, 5, 100, 98, 84, 0, 99, 205, 97, 100, 54, 100, 98, 99, 48, 100, 98, 100, 98, 98, 26, 100, 101, 99, 99, 289, 28, 99, 100, 99, 98, 99, 100, 99, 99, 66, 99, 239, 100, 100, 100, 98, 99, 99, 98, 92, 84, 99, 12, 155, 99, 99, 99, 99, 44, 99, 41, 99, 99, 99, 99, 101, 99, 100, 99, 99, 69, 99, 99, 100, 99, 99, 0, 237, 100, 97, 45, 98, 99, 98, 57, 0, 101, 99, 99, 79, 92, 79, 99, 26, 99, 69, 99, 99, 38, 100, 99, 94, 28, 30, 81, 99, 99, 79, 100, 99, 80, 99, 73, 55, 99, 100, 99, 73, 100, 73, 83, 28, 99, 76, 54, 83, 90, 49, 75, 49]
theorem loads153 : cs153.get =
    load (fun i : Fin entries153.length => support (entries153.get i).1)
      (fun i => (entries153.get i).2) := by
  apply load_eq_of_sparse_packed base cs153 support code
    entries153 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node153 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 35 (insert 18 (insert 25 (insert 77 (insert 65 (insert 53 (insert 101 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs153 support demand
    entries153 ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 35 (insert 18 (insert 25 (insert 77 (insert 65 (insert 53 (insert 101 ∅))))))) : Finset (Fin 154)) 100 30 loads153
  decide +kernel
def entries154 : List (Fin 1589 × ℕ) := [(72, 21), (86, 54), (122, 14), (137, 2), (179, 12), (344, 7), (386, 9), (439, 23), (472, 7), (475, 8), (507, 58), (515, 9), (540, 14), (542, 8), (619, 22), (624, 3), (625, 14), (632, 10), (673, 20), (690, 14), (730, 21), (737, 14), (741, 12), (815, 14), (835, 17), (844, 16), (846, 11), (847, 41), (855, 50), (863, 8), (867, 17), (869, 14), (884, 6), (886, 44), (904, 3), (920, 12), (929, 3), (930, 8), (938, 11), (973, 17), (984, 68), (985, 14), (1005, 1), (1009, 12), (1010, 1), (1018, 14), (1030, 34), (1056, 22), (1068, 19), (1070, 11), (1090, 16), (1114, 18), (1137, 16), (1139, 6), (1149, 15), (1153, 30), (1173, 23), (1182, 27), (1228, 18), (1234, 10), (1235, 15), (1238, 18), (1267, 4), (1275, 17), (1292, 4), (1401, 2), (1466, 24), (1489, 17), (1525, 5), (1527, 16), (1565, 6), (1566, 5), (1580, 2), (1582, 5)]
def cs154 : List ℕ := [34, 11, 71, 13, 2, 59, 5, 100, 18, 71, 61, 94, 101, 2, 47, 19, 100, 100, 188, 0, 100, 18, 23, 100, 100, 283, 100, 100, 67, 22, 100, 95, 82, 16, 100, 2, 100, 101, 98, 100, 70, 101, 33, 100, 100, 100, 100, 100, 68, 101, 100, 100, 99, 192, 23, 100, 100, 101, 100, 44, 100, 100, 62, 99, 71, 191, 100, 100, 100, 100, 100, 99, 99, 100, 36, 99, 0, 176, 100, 100, 101, 99, 36, 89, 97, 99, 80, 100, 100, 102, 99, 100, 100, 99, 81, 76, 100, 100, 100, 99, 0, 218, 100, 91, 54, 100, 100, 99, 70, 0, 101, 99, 100, 81, 100, 69, 100, 27, 99, 52, 99, 99, 41, 100, 100, 83, 17, 17, 56, 99, 100, 68, 100, 99, 100, 100, 55, 52, 100, 100, 100, 66, 100, 64, 80, 17, 100, 67, 62, 73, 85, 34, 74, 52]
theorem loads154 : cs154.get =
    load (fun i : Fin entries154.length => support (entries154.get i).1)
      (fun i => (entries154.get i).2) := by
  apply load_eq_of_sparse_packed base cs154 support code
    entries154 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node154 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 35 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 25 (insert 77 (insert 65 (insert 53 (insert 101 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs154 support demand
    entries154 ((insert 35 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 25 (insert 77 (insert 65 (insert 53 (insert 101 ∅)))))) : Finset (Fin 154)) 100 30 loads154
  decide +kernel
theorem node151 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 25 (insert 77 (insert 65 (insert 53 (insert 101 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 18 (insert 25 (insert 77 (insert 65 (insert 53 (insert 101 ∅)))))) : Finset (Fin 154))
    35 node153 node154
def entries152 : List (Fin 1589 × ℕ) := [(10, 236), (35, 254), (72, 153), (86, 352), (137, 21), (206, 13), (420, 40), (421, 170), (439, 54), (472, 282), (479, 13), (494, 218), (498, 135), (542, 139), (550, 131), (552, 146), (571, 62), (572, 201), (588, 40), (617, 31), (624, 15), (625, 102), (632, 107), (690, 205), (691, 14), (739, 19), (740, 13), (741, 337), (815, 214), (835, 211), (844, 45), (848, 60), (856, 363), (865, 229), (867, 248), (869, 232), (870, 77), (886, 397), (904, 140), (905, 88), (920, 191), (928, 60), (929, 60), (944, 34), (948, 78), (973, 280), (978, 255), (984, 272), (995, 176), (1009, 127), (1010, 160), (1018, 103), (1020, 131), (1030, 367), (1031, 76), (1053, 26), (1056, 75), (1061, 3), (1070, 144), (1090, 379), (1104, 64), (1114, 17), (1137, 193), (1149, 114), (1153, 413), (1160, 107), (1173, 285), (1182, 307), (1188, 265), (1234, 126), (1235, 147), (1241, 13), (1246, 86), (1261, 10), (1263, 40), (1275, 132), (1293, 6), (1308, 59), (1359, 210), (1500, 32), (1517, 39), (1558, 78), (1566, 97), (1573, 73), (1578, 90), (1588, 4)]
def cs152 : List ℕ := [45, 210, 578, 0, 339, 617, 129, 918, 429, 0, 720, 1000, 793, 490, 382, 367, 1000, 1000, 0, 263, 1000, 444, 215, 1000, 890, 2278, 999, 1001, 445, 434, 1000, 1000, 385, 45, 998, 1000, 1001, 1001, 582, 999, 1001, 1000, 485, 1000, 999, 999, 1002, 1000, 606, 999, 1000, 999, 1000, 1922, 345, 999, 1000, 1001, 1001, 1000, 999, 1000, 954, 964, 999, 1622, 999, 1000, 998, 1001, 999, 931, 1000, 1001, 1000, 999, 297, 2096, 1000, 999, 1000, 1000, 954, 1001, 831, 999, 308, 999, 1000, 999, 999, 999, 1000, 1001, 592, 603, 999, 1001, 1001, 998, 0, 2444, 1002, 1001, 460, 1000, 1001, 999, 699, 0, 1000, 999, 1002, 794, 1000, 906, 1001, 341, 999, 871, 1002, 1001, 321, 1000, 1000, 999, 280, 356, 722, 1001, 1000, 1000, 1001, 999, 975, 1001, 679, 549, 1000, 999, 978, 823, 999, 948, 1001, 280, 999, 852, 664, 696, 764, 412, 1000, 532]
theorem loads152 : cs152.get =
    load (fun i : Fin entries152.length => support (entries152.get i).1)
      (fun i => (entries152.get i).2) := by
  apply load_eq_of_sparse_packed base cs152 support code
    entries152 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node152 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 18 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 77 (insert 65 (insert 53 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs152 support demand
    entries152 ((insert 18 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 25 (insert 77 (insert 65 (insert 53 (insert 101 ∅))))) : Finset (Fin 154)) 1000 30 loads152
  decide +kernel
theorem node147 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 77 (insert 65 (insert 53 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 25 (insert 77 (insert 65 (insert 53 (insert 101 ∅))))) : Finset (Fin 154))
    18 node151 node152
def entries149 : List (Fin 1589 × ℕ) := [(62, 111), (86, 71), (177, 233), (179, 101), (384, 61), (385, 48), (439, 21), (466, 261), (472, 240), (478, 194), (491, 166), (507, 265), (514, 128), (530, 99), (542, 20), (569, 25), (570, 322), (572, 72), (587, 5), (588, 175), (617, 122), (618, 131), (625, 178), (632, 115), (639, 193), (690, 51), (731, 82), (737, 11), (739, 22), (813, 145), (815, 185), (835, 30), (850, 280), (870, 144), (905, 393), (917, 29), (920, 228), (923, 87), (924, 88), (930, 19), (936, 63), (938, 285), (944, 126), (950, 177), (973, 425), (978, 452), (980, 44), (995, 54), (1005, 68), (1007, 97), (1010, 306), (1018, 54), (1020, 12), (1030, 146), (1031, 127), (1056, 207), (1070, 83), (1086, 10), (1090, 393), (1114, 15), (1137, 122), (1138, 73), (1149, 1), (1153, 297), (1160, 122), (1173, 339), (1179, 99), (1182, 156), (1183, 54), (1227, 8), (1234, 164), (1235, 266), (1258, 23), (1261, 120), (1263, 96), (1267, 200), (1297, 24), (1342, 97), (1359, 305), (1379, 66), (1400, 49), (1434, 8), (1489, 254), (1491, 102), (1517, 53), (1545, 44), (1565, 12)]
def cs149 : List ℕ := [261, 305, 240, 280, 194, 0, 219, 1000, 104, 376, 194, 1000, 999, 218, 20, 102, 1000, 1000, 999, 183, 999, 370, 526, 999, 1000, 0, 1000, 999, 390, 449, 1000, 999, 787, 0, 999, 999, 1000, 1000, 999, 1000, 1000, 790, 746, 999, 999, 999, 999, 1000, 689, 999, 1000, 999, 993, 2131, 339, 1000, 1000, 998, 1001, 999, 999, 893, 970, 999, 999, 1631, 999, 1000, 734, 1000, 1604, 1000, 999, 1000, 999, 999, 99, 1166, 999, 999, 1000, 1000, 661, 1000, 1000, 999, 873, 999, 999, 999, 999, 999, 1000, 1001, 1001, 1000, 1000, 1000, 1000, 998, 0, 2395, 999, 1000, 643, 932, 1001, 999, 633, 99, 999, 999, 1000, 814, 1001, 845, 1000, 380, 999, 877, 958, 1000, 400, 1000, 999, 931, 425, 651, 548, 1000, 999, 999, 1000, 1000, 870, 999, 765, 773, 999, 990, 844, 947, 1000, 877, 751, 524, 999, 940, 755, 804, 758, 425, 1000, 625]
theorem loads149 : cs149.get =
    load (fun i : Fin entries149.length => support (entries149.get i).1)
      (fun i => (entries149.get i).2) := by
  apply load_eq_of_sparse_packed base cs149 support code
    entries149 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node149 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 70 (insert 77 (insert 65 (insert 53 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs149 support demand
    entries149 ((insert 25 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 70 (insert 77 (insert 65 (insert 53 (insert 101 ∅))))) : Finset (Fin 154)) 1000 30 loads149
  decide +kernel
def entries150 : List (Fin 1589 × ℕ) := [(62, 5), (86, 5), (177, 15), (179, 20), (385, 25), (387, 1), (419, 6), (420, 12), (472, 8), (475, 1), (478, 17), (479, 13), (484, 15), (507, 8), (552, 19), (570, 23), (572, 25), (583, 12), (620, 16), (632, 9), (691, 5), (737, 10), (815, 34), (835, 2), (850, 20), (863, 13), (870, 4), (871, 12), (895, 3), (905, 37), (914, 1), (918, 3), (919, 6), (920, 4), (923, 11), (924, 10), (928, 14), (930, 9), (937, 9), (960, 11), (973, 42), (975, 5), (978, 48), (1007, 10), (1009, 1), (1010, 19), (1020, 18), (1030, 26), (1031, 25), (1056, 19), (1090, 48), (1099, 6), (1104, 5), (1114, 5), (1137, 5), (1138, 14), (1153, 27), (1160, 16), (1173, 41), (1177, 7), (1182, 17), (1234, 2), (1235, 21), (1239, 15), (1240, 16), (1246, 20), (1261, 15), (1280, 9), (1310, 12), (1348, 2), (1359, 38), (1379, 13), (1466, 2), (1491, 4), (1494, 2), (1499, 1), (1500, 8), (1503, 2), (1517, 23), (1559, 3), (1576, 2)]
def cs150 : List ℕ := [9, 62, 23, 21, 30, 26, 23, 100, 17, 26, 15, 100, 100, 17, 0, 23, 100, 100, 101, 30, 100, 30, 35, 99, 100, 0, 100, 101, 20, 61, 94, 99, 74, 0, 100, 99, 101, 100, 101, 100, 100, 80, 32, 86, 99, 101, 99, 101, 86, 100, 100, 90, 99, 201, 42, 100, 100, 99, 101, 74, 100, 100, 89, 100, 99, 149, 101, 101, 46, 100, 4, 99, 99, 101, 99, 83, 28, 128, 100, 92, 100, 100, 69, 100, 96, 100, 66, 100, 101, 100, 99, 95, 100, 102, 100, 100, 100, 102, 100, 99, 7, 266, 101, 101, 48, 101, 100, 99, 81, 0, 100, 99, 101, 101, 99, 100, 101, 17, 99, 99, 100, 99, 53, 100, 100, 89, 49, 67, 64, 100, 100, 99, 99, 101, 91, 100, 90, 72, 99, 100, 101, 89, 101, 85, 70, 49, 100, 95, 87, 88, 67, 49, 86, 58]
theorem loads150 : cs150.get =
    load (fun i : Fin entries150.length => support (entries150.get i).1)
      (fun i => (entries150.get i).2) := by
  apply load_eq_of_sparse_packed base cs150 support code
    entries150 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node150 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 70 (insert 25 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 77 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs150 support demand
    entries150 ((insert 70 (insert 25 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 77 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)) 100 30 loads150
  decide +kernel
theorem node148 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 77 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 77 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154))
    70 node149 node150
theorem node137 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 77 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 77 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154))
    25 node147 node148
def entries145 : List (Fin 1589 × ℕ) := [(46, 25), (72, 150), (86, 134), (115, 29), (122, 291), (179, 320), (344, 51), (384, 27), (385, 39), (466, 75), (475, 82), (491, 313), (494, 466), (507, 280), (515, 20), (540, 55), (542, 457), (552, 1), (570, 221), (572, 163), (576, 136), (581, 56), (587, 45), (588, 285), (617, 50), (619, 245), (623, 86), (625, 221), (730, 100), (731, 78), (813, 48), (815, 117), (844, 114), (850, 121), (856, 190), (868, 65), (870, 197), (886, 411), (896, 84), (904, 120), (905, 128), (918, 204), (920, 60), (928, 66), (938, 398), (944, 129), (949, 81), (973, 304), (978, 261), (995, 63), (1005, 2), (1010, 113), (1030, 284), (1045, 137), (1048, 45), (1078, 73), (1082, 119), (1089, 145), (1090, 217), (1097, 99), (1104, 142), (1122, 35), (1137, 299), (1139, 62), (1153, 194), (1160, 385), (1173, 397), (1227, 4), (1234, 30), (1235, 98), (1238, 175), (1249, 180), (1261, 271), (1292, 71), (1308, 106), (1310, 76), (1348, 37), (1349, 4), (1359, 24), (1374, 48), (1471, 141), (1495, 5), (1499, 24), (1503, 67), (1508, 137), (1525, 71), (1580, 76), (1582, 149), (1588, 76)]
def cs145 : List ℕ := [364, 24, 246, 352, 76, 410, 487, 1001, 175, 351, 531, 1000, 1001, 76, 796, 446, 1001, 1001, 1000, 163, 1839, 601, 650, 1000, 1000, 1001, 1000, 998, 885, 345, 1000, 999, 768, 118, 999, 1000, 1001, 1000, 570, 999, 1000, 999, 1000, 1001, 999, 1001, 2221, 1001, 999, 1000, 1000, 998, 999, 1790, 421, 1000, 1001, 998, 999, 999, 1000, 997, 758, 999, 1000, 1554, 1000, 999, 999, 998, 999, 999, 999, 950, 1000, 1000, 67, 261, 999, 999, 998, 1880, 722, 999, 993, 999, 1000, 1001, 998, 1000, 996, 630, 911, 998, 999, 1000, 999, 998, 1000, 999, 0, 1803, 999, 999, 492, 999, 999, 999, 805, 0, 1001, 1001, 998, 930, 1000, 939, 999, 129, 1000, 888, 998, 999, 442, 999, 998, 1000, 304, 339, 491, 999, 1000, 1000, 1000, 1000, 728, 999, 746, 839, 1000, 1000, 998, 838, 1001, 883, 717, 304, 1000, 1000, 728, 701, 546, 304, 678, 689]
theorem loads145 : cs145.get =
    load (fun i : Fin entries145.length => support (entries145.get i).1)
      (fun i => (entries145.get i).2) := by
  apply load_eq_of_sparse_packed base cs145 support code
    entries145 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node145 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 46 (insert 81 (insert 65 (insert 53 (insert 101 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs145 support demand
    entries145 ((insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 20 (insert 46 (insert 81 (insert 65 (insert 53 (insert 101 ∅)))))) : Finset (Fin 154)) 1000 30 loads145
  decide +kernel
def entries146 : List (Fin 1589 × ℕ) := [(46, 9), (62, 4), (72, 2), (86, 3), (122, 21), (135, 13), (177, 18), (179, 19), (386, 21), (472, 34), (475, 16), (479, 1), (494, 50), (498, 16), (507, 25), (527, 8), (551, 7), (570, 14), (572, 6), (581, 17), (583, 27), (587, 5), (588, 34), (617, 2), (619, 23), (623, 16), (625, 20), (681, 2), (730, 14), (813, 10), (815, 34), (835, 11), (846, 14), (850, 25), (855, 3), (856, 29), (870, 23), (884, 1), (886, 52), (904, 13), (914, 11), (918, 16), (920, 10), (928, 1), (930, 8), (938, 22), (944, 9), (949, 9), (973, 25), (975, 11), (978, 26), (980, 12), (995, 10), (1009, 1), (1010, 11), (1020, 27), (1030, 38), (1031, 1), (1045, 14), (1082, 13), (1090, 38), (1097, 13), (1104, 10), (1137, 24), (1139, 13), (1153, 21), (1160, 38), (1173, 38), (1182, 11), (1249, 13), (1261, 27), (1285, 3), (1310, 17), (1466, 3), (1471, 10), (1489, 10), (1508, 13), (1566, 5), (1588, 1)]
def cs146 : List ℕ := [0, 14, 34, 44, 1, 32, 9, 99, 19, 29, 2, 56, 100, 7, 11, 28, 100, 100, 100, 10, 0, 84, 81, 48, 82, 100, 96, 101, 81, 57, 99, 100, 85, 0, 100, 100, 99, 99, 69, 100, 99, 100, 60, 84, 100, 100, 186, 101, 94, 100, 100, 100, 100, 187, 38, 100, 101, 101, 100, 99, 101, 100, 91, 88, 100, 152, 101, 100, 100, 101, 100, 99, 90, 100, 100, 87, 0, 37, 101, 100, 101, 179, 86, 99, 101, 100, 100, 99, 100, 100, 100, 72, 100, 99, 100, 101, 99, 99, 101, 100, 0, 227, 99, 100, 40, 99, 99, 100, 89, 0, 100, 99, 100, 96, 94, 100, 99, 20, 99, 84, 99, 100, 38, 100, 100, 100, 25, 26, 57, 99, 100, 98, 99, 99, 72, 100, 63, 77, 100, 100, 100, 76, 100, 84, 84, 25, 100, 100, 59, 63, 62, 25, 70, 63]
theorem loads146 : cs146.get =
    load (fun i : Fin entries146.length => support (entries146.get i).1)
      (fun i => (entries146.get i).2) := by
  apply load_eq_of_sparse_packed base cs146 support code
    entries146 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node146 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 20 (insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 81 (insert 65 (insert 53 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs146 support demand
    entries146 ((insert 20 (insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 46 (insert 81 (insert 65 (insert 53 (insert 101 ∅))))) : Finset (Fin 154)) 100 30 loads146
  decide +kernel
theorem node143 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 81 (insert 65 (insert 53 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 81 (insert 65 (insert 53 (insert 101 ∅))))) : Finset (Fin 154))
    20 node145 node146
def entries144 : List (Fin 1589 × ℕ) := [(72, 71), (75, 126), (86, 189), (116, 85), (122, 81), (177, 241), (179, 174), (203, 36), (385, 95), (421, 9), (466, 116), (478, 44), (491, 151), (498, 8), (507, 163), (527, 32), (552, 111), (570, 319), (572, 199), (588, 189), (617, 147), (730, 125), (731, 153), (736, 53), (813, 19), (815, 136), (835, 147), (844, 181), (846, 8), (850, 122), (856, 11), (866, 68), (870, 216), (882, 72), (886, 272), (905, 174), (912, 21), (914, 142), (916, 72), (918, 87), (924, 174), (928, 142), (938, 274), (944, 112), (949, 18), (964, 60), (966, 27), (973, 256), (975, 34), (978, 284), (985, 123), (1009, 70), (1010, 240), (1020, 64), (1030, 260), (1045, 181), (1056, 1), (1070, 27), (1078, 121), (1090, 186), (1104, 144), (1137, 244), (1139, 53), (1153, 319), (1160, 277), (1173, 430), (1217, 93), (1234, 61), (1239, 87), (1240, 53), (1246, 53), (1249, 314), (1277, 100), (1290, 54), (1293, 166), (1308, 113), (1374, 108), (1379, 136), (1466, 103), (1489, 120), (1491, 20), (1508, 164), (1537, 295), (1552, 72), (1577, 113)]
def cs144 : List ℕ := [390, 95, 475, 122, 44, 453, 264, 824, 444, 163, 455, 999, 999, 295, 310, 482, 999, 1000, 1000, 199, 999, 428, 604, 999, 999, 999, 1000, 999, 237, 829, 999, 1000, 546, 181, 999, 1000, 1000, 999, 1000, 999, 715, 999, 812, 620, 1000, 1000, 0, 1000, 888, 999, 1000, 999, 999, 1444, 430, 999, 1000, 999, 1000, 212, 999, 774, 921, 668, 753, 1198, 999, 998, 999, 999, 999, 1000, 998, 878, 740, 1000, 0, 285, 999, 1000, 1000, 1466, 232, 1000, 1000, 1000, 1001, 999, 1000, 1000, 999, 697, 1001, 1001, 1000, 1000, 858, 1001, 999, 999, 0, 1953, 1001, 1000, 604, 999, 1000, 1000, 829, 60, 999, 1000, 1001, 1000, 998, 1000, 1001, 139, 1000, 900, 1001, 999, 430, 1000, 1000, 1000, 256, 356, 480, 1000, 999, 1000, 1000, 1000, 1001, 1000, 686, 681, 1000, 1000, 771, 877, 1000, 952, 915, 256, 1000, 1000, 814, 686, 723, 256, 889, 633]
theorem loads144 : cs144.get =
    load (fun i : Fin entries144.length => support (entries144.get i).1)
      (fun i => (entries144.get i).2) := by
  apply load_eq_of_sparse_packed base cs144 support code
    entries144 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node144 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 46 (insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs144 support demand
    entries144 ((insert 46 (insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 81 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)) 1000 30 loads144
  decide +kernel
theorem node139 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 81 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 81 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154))
    46 node143 node144
def entries141 : List (Fin 1589 × ℕ) := [(37, 1), (46, 23), (62, 5), (86, 13), (177, 26), (179, 14), (383, 2), (384, 1), (387, 17), (419, 10), (472, 17), (475, 4), (478, 8), (491, 8), (494, 14), (507, 22), (515, 13), (541, 1), (551, 7), (572, 11), (588, 4), (617, 13), (625, 6), (730, 10), (731, 41), (847, 6), (855, 31), (856, 22), (870, 37), (886, 31), (896, 12), (904, 24), (914, 22), (916, 1), (920, 4), (937, 19), (948, 6), (950, 4), (958, 2), (973, 18), (975, 7), (978, 21), (980, 2), (985, 10), (1005, 4), (1010, 23), (1030, 26), (1031, 1), (1045, 20), (1061, 1), (1078, 15), (1090, 6), (1099, 24), (1104, 3), (1114, 8), (1137, 32), (1153, 37), (1160, 18), (1173, 47), (1219, 5), (1239, 7), (1240, 8), (1249, 34), (1261, 54), (1263, 14), (1266, 4), (1267, 4), (1277, 25), (1293, 2), (1342, 2), (1359, 11), (1379, 14), (1400, 5), (1471, 2), (1489, 16), (1491, 13), (1495, 1), (1577, 7), (1580, 31), (1582, 1)]
def cs141 : List ℕ := [0, 23, 30, 10, 39, 55, 39, 99, 22, 27, 29, 99, 100, 36, 62, 29, 100, 100, 100, 17, 99, 69, 44, 99, 99, 101, 100, 99, 10, 93, 100, 99, 44, 0, 100, 99, 99, 100, 72, 100, 98, 92, 59, 61, 100, 100, 99, 100, 93, 100, 100, 100, 100, 132, 47, 100, 100, 100, 100, 84, 102, 99, 99, 90, 100, 105, 101, 101, 82, 99, 89, 78, 99, 97, 100, 101, 0, 21, 101, 99, 99, 0, 43, 99, 95, 99, 13, 100, 100, 99, 100, 61, 54, 100, 93, 70, 89, 100, 101, 101, 0, 170, 100, 100, 60, 79, 100, 99, 57, 0, 98, 100, 100, 100, 100, 89, 100, 2, 99, 70, 99, 100, 55, 99, 100, 99, 18, 44, 28, 184, 100, 99, 99, 99, 39, 100, 65, 71, 99, 99, 100, 89, 99, 99, 82, 18, 99, 90, 80, 73, 77, 18, 89, 61]
theorem loads141 : cs141.get =
    load (fun i : Fin entries141.length => support (entries141.get i).1)
      (fun i => (entries141.get i).2) := by
  apply load_eq_of_sparse_packed base cs141 support code
    entries141 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node141 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 81 (insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 129 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs141 support demand
    entries141 ((insert 81 (insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 129 (insert 65 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)) 100 30 loads141
  decide +kernel
def entries142 : List (Fin 1589 × ℕ) := [(37, 14), (46, 23), (70, 4), (122, 35), (137, 12), (179, 14), (203, 7), (341, 2), (386, 4), (472, 15), (478, 16), (491, 15), (494, 24), (507, 37), (515, 5), (527, 6), (617, 27), (731, 30), (737, 11), (833, 8), (850, 13), (855, 29), (856, 5), (870, 32), (886, 32), (896, 10), (904, 7), (914, 20), (916, 1), (920, 21), (928, 8), (929, 5), (930, 7), (937, 19), (950, 31), (973, 32), (975, 7), (978, 19), (985, 3), (995, 5), (1009, 15), (1010, 26), (1012, 19), (1021, 5), (1030, 14), (1045, 25), (1056, 11), (1061, 15), (1082, 20), (1090, 7), (1097, 16), (1100, 17), (1104, 7), (1110, 3), (1137, 12), (1139, 8), (1160, 15), (1172, 15), (1177, 1), (1219, 13), (1233, 7), (1249, 20), (1262, 19), (1267, 20), (1293, 47), (1342, 13), (1359, 15), (1379, 7), (1380, 1), (1489, 13), (1491, 18), (1545, 13), (1576, 2), (1577, 16), (1580, 9), (1584, 7)]
def cs142 : List ℕ := [0, 28, 15, 26, 25, 48, 55, 92, 33, 37, 17, 99, 100, 9, 52, 69, 100, 100, 101, 14, 100, 100, 14, 100, 100, 99, 100, 100, 57, 61, 99, 101, 55, 0, 100, 100, 100, 101, 74, 99, 100, 32, 46, 86, 101, 99, 99, 100, 94, 99, 100, 101, 99, 137, 15, 100, 99, 100, 100, 100, 100, 100, 97, 96, 100, 145, 99, 101, 100, 100, 100, 81, 100, 100, 100, 100, 1, 30, 100, 100, 100, 0, 35, 99, 72, 100, 47, 100, 99, 100, 97, 100, 84, 100, 87, 81, 100, 99, 100, 100, 1, 170, 100, 100, 28, 100, 99, 100, 78, 0, 100, 100, 100, 77, 100, 100, 100, 13, 100, 80, 100, 83, 1, 100, 99, 79, 33, 51, 16, 0, 98, 100, 100, 100, 56, 99, 33, 100, 99, 100, 23, 32, 100, 69, 72, 33, 96, 100, 67, 32, 67, 33, 52, 54]
theorem loads142 : cs142.get =
    load (fun i : Fin entries142.length => support (entries142.get i).1)
      (fun i => (entries142.get i).2) := by
  apply load_eq_of_sparse_packed base cs142 support code
    entries142 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node142 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 129 (insert 81 (insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 65 (insert 53 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs142 support demand
    entries142 ((insert 129 (insert 81 (insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 65 (insert 53 (insert 101 ∅))) : Finset (Fin 154)) 100 30 loads142
  decide +kernel
theorem node140 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 81 (insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 65 (insert 53 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 81 (insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 65 (insert 53 (insert 101 ∅))) : Finset (Fin 154))
    129 node141 node142
theorem node138 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 65 (insert 53 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 77 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 65 (insert 53 (insert 101 ∅))) : Finset (Fin 154))
    81 node139 node140
theorem node125 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 65 (insert 53 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 65 (insert 53 (insert 101 ∅))) : Finset (Fin 154))
    77 node137 node138
def entries135 : List (Fin 1589 × ℕ) := [(35, 352), (62, 233), (86, 175), (122, 189), (179, 115), (198, 35), (203, 237), (344, 166), (421, 66), (439, 177), (472, 26), (475, 60), (483, 27), (491, 69), (494, 449), (507, 265), (531, 141), (542, 125), (588, 161), (617, 236), (625, 73), (630, 63), (632, 234), (639, 164), (673, 31), (691, 8), (730, 190), (737, 44), (739, 38), (814, 39), (815, 250), (835, 303), (849, 235), (863, 103), (870, 170), (886, 141), (905, 276), (914, 25), (920, 30), (924, 148), (928, 85), (929, 38), (930, 66), (937, 137), (938, 485), (950, 146), (973, 356), (978, 388), (995, 215), (1005, 42), (1009, 149), (1010, 109), (1018, 33), (1020, 23), (1021, 13), (1056, 55), (1070, 86), (1075, 42), (1090, 376), (1104, 70), (1123, 58), (1128, 50), (1137, 202), (1153, 311), (1173, 280), (1182, 298), (1188, 76), (1217, 164), (1219, 32), (1221, 294), (1228, 66), (1234, 104), (1235, 38), (1261, 28), (1263, 139), (1267, 8), (1275, 205), (1292, 49), (1293, 128), (1379, 232), (1491, 84), (1499, 21), (1558, 1), (1566, 118), (1578, 35)]
def cs135 : List ℕ := [458, 32, 484, 327, 35, 886, 104, 1000, 491, 601, 316, 999, 1000, 726, 160, 308, 1000, 1000, 1000, 233, 1000, 604, 395, 999, 999, 1000, 1000, 999, 410, 789, 1000, 998, 837, 0, 2342, 1000, 999, 998, 759, 999, 734, 1786, 824, 1001, 999, 1000, 1000, 1000, 792, 1000, 1000, 998, 998, 2042, 595, 999, 1000, 998, 999, 963, 1000, 999, 770, 999, 1587, 388, 1000, 1000, 999, 998, 999, 999, 1000, 999, 1000, 1000, 76, 955, 1000, 852, 1000, 999, 444, 1000, 999, 528, 556, 1001, 1000, 1000, 999, 1001, 999, 999, 1000, 109, 1001, 1001, 2001, 1000, 0, 1757, 1001, 999, 633, 582, 1001, 999, 824, 0, 1001, 1000, 999, 798, 1001, 551, 999, 298, 1000, 535, 1000, 1000, 368, 1000, 1000, 1000, 356, 414, 679, 999, 1000, 667, 1000, 1001, 932, 999, 636, 600, 1000, 1000, 942, 722, 1000, 922, 1000, 356, 1000, 1000, 790, 686, 983, 561, 965, 627]
theorem loads135 : cs135.get =
    load (fun i : Fin entries135.length => support (entries135.get i).1)
      (fun i => (entries135.get i).2) := by
  apply load_eq_of_sparse_packed base cs135 support code
    entries135 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node135 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 41 (insert 34 (insert 98 (insert 64 (insert 53 (insert 101 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs135 support demand
    entries135 ((insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 41 (insert 34 (insert 98 (insert 64 (insert 53 (insert 101 ∅)))))) : Finset (Fin 154)) 1000 30 loads135
  decide +kernel
def entries136 : List (Fin 1589 × ℕ) := [(62, 14), (137, 7), (179, 40), (198, 5), (203, 30), (385, 8), (438, 6), (439, 35), (479, 9), (491, 2), (494, 46), (507, 35), (526, 8), (542, 12), (571, 2), (584, 6), (617, 23), (623, 9), (672, 3), (730, 29), (737, 19), (739, 9), (815, 22), (835, 11), (849, 17), (853, 15), (870, 29), (872, 12), (886, 21), (905, 13), (913, 19), (914, 41), (920, 3), (924, 32), (930, 27), (938, 2), (949, 23), (950, 7), (973, 21), (978, 32), (995, 36), (1005, 11), (1009, 21), (1018, 3), (1020, 12), (1021, 11), (1056, 1), (1070, 18), (1075, 3), (1090, 34), (1104, 19), (1114, 7), (1137, 33), (1152, 4), (1153, 22), (1173, 14), (1182, 29), (1188, 12), (1202, 9), (1217, 9), (1221, 36), (1227, 8), (1228, 4), (1248, 2), (1261, 3), (1267, 6), (1275, 32), (1290, 3), (1293, 18), (1379, 2), (1380, 13), (1577, 10), (1582, 12)]
def cs136 : List ℕ := [54, 0, 54, 38, 18, 75, 37, 100, 12, 49, 30, 99, 100, 35, 31, 22, 100, 99, 100, 16, 99, 44, 40, 100, 100, 100, 99, 100, 15, 100, 100, 101, 67, 9, 193, 100, 100, 99, 89, 100, 66, 2, 50, 86, 100, 101, 101, 100, 81, 101, 75, 100, 82, 211, 50, 86, 101, 100, 101, 101, 101, 87, 90, 100, 194, 44, 100, 100, 100, 101, 54, 101, 99, 102, 100, 99, 12, 67, 100, 83, 100, 66, 42, 101, 81, 76, 48, 100, 101, 99, 100, 100, 101, 101, 94, 3, 81, 101, 273, 100, 0, 161, 101, 99, 55, 54, 101, 99, 63, 0, 100, 99, 102, 81, 99, 38, 101, 29, 100, 40, 101, 101, 30, 99, 101, 100, 21, 21, 95, 100, 100, 54, 100, 100, 98, 100, 35, 57, 100, 99, 98, 53, 100, 79, 101, 21, 68, 92, 73, 42, 86, 57, 72, 57]
theorem loads136 : cs136.get =
    load (fun i : Fin entries136.length => support (entries136.get i).1)
      (fun i => (entries136.get i).2) := by
  apply load_eq_of_sparse_packed base cs136 support code
    entries136 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node136 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 41 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 34 (insert 98 (insert 64 (insert 53 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs136 support demand
    entries136 ((insert 41 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 34 (insert 98 (insert 64 (insert 53 (insert 101 ∅))))) : Finset (Fin 154)) 100 30 loads136
  decide +kernel
theorem node133 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 34 (insert 98 (insert 64 (insert 53 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 34 (insert 98 (insert 64 (insert 53 (insert 101 ∅))))) : Finset (Fin 154))
    41 node135 node136
def entries134 : List (Fin 1589 × ℕ) := [(20, 32), (72, 6), (137, 6), (179, 44), (343, 4), (361, 1), (384, 5), (439, 25), (472, 3), (475, 16), (478, 16), (479, 11), (491, 7), (494, 25), (507, 32), (514, 16), (531, 4), (542, 19), (552, 8), (572, 26), (588, 8), (617, 13), (672, 8), (690, 18), (737, 7), (738, 1), (739, 12), (815, 17), (835, 1), (844, 3), (858, 2), (870, 31), (872, 19), (886, 45), (914, 13), (917, 2), (919, 2), (920, 25), (924, 17), (929, 9), (930, 21), (937, 13), (938, 23), (949, 9), (950, 5), (963, 4), (973, 30), (978, 32), (985, 22), (1005, 11), (1009, 15), (1010, 37), (1021, 5), (1048, 14), (1055, 5), (1056, 4), (1068, 3), (1070, 21), (1082, 2), (1090, 37), (1100, 1), (1104, 20), (1137, 33), (1153, 20), (1171, 17), (1182, 33), (1188, 19), (1227, 7), (1240, 10), (1261, 16), (1267, 10), (1275, 25), (1280, 21), (1293, 22), (1310, 18), (1493, 3), (1525, 7), (1537, 1), (1577, 25)]
def cs134 : List ℕ := [24, 21, 11, 48, 27, 22, 34, 87, 33, 39, 29, 100, 41, 56, 50, 36, 99, 100, 100, 26, 100, 17, 55, 99, 100, 99, 98, 100, 34, 99, 100, 99, 83, 20, 0, 99, 99, 100, 97, 100, 98, 99, 82, 99, 100, 99, 98, 100, 82, 96, 100, 98, 99, 132, 17, 100, 100, 99, 99, 99, 101, 99, 101, 99, 105, 32, 100, 100, 86, 99, 100, 100, 101, 100, 99, 98, 19, 94, 100, 100, 98, 99, 78, 92, 99, 94, 38, 100, 100, 100, 99, 95, 99, 101, 101, 48, 100, 101, 232, 99, 0, 193, 101, 101, 65, 99, 101, 99, 69, 4, 100, 100, 101, 94, 99, 75, 100, 33, 99, 101, 101, 100, 43, 99, 101, 100, 30, 35, 98, 99, 99, 100, 99, 100, 84, 100, 61, 71, 100, 100, 95, 68, 100, 75, 100, 30, 83, 100, 83, 47, 88, 55, 83, 55]
theorem loads134 : cs134.get =
    load (fun i : Fin entries134.length => support (entries134.get i).1)
      (fun i => (entries134.get i).2) := by
  apply load_eq_of_sparse_packed base cs134 support code
    entries134 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node134 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 34 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 64 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs134 support demand
    entries134 ((insert 34 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 98 (insert 64 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)) 100 30 loads134
  decide +kernel
theorem node131 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 64 (insert 53 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 98 (insert 64 (insert 53 (insert 101 ∅)))) : Finset (Fin 154))
    34 node133 node134
def entries132 : List (Fin 1589 × ℕ) := [(20, 39), (72, 17), (86, 7), (120, 15), (177, 19), (203, 1), (343, 17), (475, 12), (479, 6), (494, 51), (495, 19), (507, 33), (542, 8), (572, 8), (587, 8), (617, 12), (625, 10), (730, 7), (731, 16), (737, 9), (739, 4), (813, 16), (814, 7), (815, 12), (853, 2), (863, 2), (867, 19), (868, 1), (870, 27), (872, 17), (886, 26), (905, 11), (912, 1), (920, 24), (923, 18), (928, 5), (936, 3), (942, 4), (947, 1), (948, 8), (973, 19), (978, 27), (984, 8), (985, 5), (995, 17), (1005, 17), (1010, 5), (1034, 5), (1055, 6), (1056, 35), (1068, 21), (1082, 21), (1090, 35), (1137, 43), (1139, 29), (1152, 13), (1153, 18), (1160, 27), (1173, 38), (1217, 13), (1234, 11), (1239, 2), (1246, 10), (1249, 3), (1261, 25), (1267, 5), (1280, 21), (1290, 5), (1293, 13), (1310, 9), (1359, 6), (1379, 8), (1489, 6), (1491, 1), (1496, 4), (1498, 19), (1552, 36), (1565, 5), (1577, 11), (1588, 12)]
def cs132 : List ℕ := [34, 29, 15, 51, 6, 60, 11, 99, 65, 35, 54, 99, 99, 56, 36, 46, 99, 100, 100, 8, 98, 28, 32, 98, 99, 100, 100, 99, 61, 95, 99, 98, 100, 0, 100, 100, 99, 100, 88, 99, 89, 101, 66, 97, 99, 100, 100, 100, 77, 100, 100, 99, 75, 167, 38, 100, 99, 99, 100, 100, 100, 100, 99, 99, 142, 35, 99, 100, 89, 100, 99, 99, 100, 100, 100, 100, 0, 100, 99, 100, 99, 100, 32, 99, 100, 76, 59, 100, 98, 100, 100, 98, 99, 100, 89, 26, 100, 99, 0, 101, 0, 181, 99, 100, 50, 87, 100, 100, 73, 4, 97, 100, 100, 87, 91, 43, 100, 0, 100, 24, 99, 100, 42, 100, 99, 100, 19, 25, 45, 101, 100, 67, 100, 100, 68, 99, 57, 89, 100, 100, 65, 57, 100, 77, 99, 19, 81, 100, 22, 57, 51, 32, 40, 46]
theorem loads132 : cs132.get =
    load (fun i : Fin entries132.length => support (entries132.get i).1)
      (fun i => (entries132.get i).2) := by
  apply load_eq_of_sparse_packed base cs132 support code
    entries132 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node132 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 98 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 64 (insert 53 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs132 support demand
    entries132 ((insert 98 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 64 (insert 53 (insert 101 ∅))) : Finset (Fin 154)) 100 30 loads132
  decide +kernel
theorem node127 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 64 (insert 53 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 64 (insert 53 (insert 101 ∅))) : Finset (Fin 154))
    98 node131 node132
def entries129 : List (Fin 1589 × ℕ) := [(20, 409), (70, 35), (116, 47), (120, 5), (122, 169), (137, 74), (179, 99), (203, 102), (343, 21), (418, 37), (419, 166), (466, 81), (475, 124), (479, 597), (483, 370), (491, 370), (507, 158), (514, 25), (542, 53), (571, 30), (572, 187), (588, 88), (624, 24), (625, 84), (639, 292), (690, 22), (730, 207), (731, 102), (813, 28), (815, 333), (835, 163), (847, 186), (853, 157), (863, 38), (868, 79), (870, 374), (872, 100), (882, 35), (886, 202), (905, 191), (914, 109), (924, 155), (928, 124), (938, 188), (948, 121), (950, 32), (966, 1), (973, 346), (978, 217), (1009, 89), (1010, 417), (1021, 111), (1048, 320), (1068, 171), (1070, 209), (1075, 51), (1082, 17), (1090, 409), (1113, 219), (1114, 8), (1128, 164), (1137, 237), (1139, 63), (1153, 160), (1160, 173), (1182, 417), (1217, 51), (1227, 24), (1234, 104), (1246, 155), (1261, 75), (1290, 58), (1292, 159), (1308, 111), (1379, 38), (1491, 20), (1548, 172), (1549, 45), (1552, 114), (1558, 94), (1565, 38), (1580, 85), (1588, 151)]
def cs129 : List ℕ := [132, 0, 237, 533, 682, 795, 370, 1000, 467, 196, 394, 1000, 1000, 594, 173, 276, 1000, 1000, 899, 217, 999, 412, 319, 999, 1000, 1001, 1000, 1000, 461, 766, 1000, 998, 677, 0, 1001, 999, 999, 1000, 596, 1001, 1902, 1000, 674, 509, 1000, 1000, 999, 999, 874, 1000, 1000, 999, 890, 1250, 0, 1000, 1000, 1000, 1001, 996, 1001, 1001, 1000, 999, 0, 217, 999, 1000, 964, 1001, 999, 1001, 1001, 1001, 617, 1000, 0, 999, 999, 1000, 1001, 1000, 861, 736, 1001, 1000, 623, 999, 1000, 1000, 1000, 563, 1001, 1001, 794, 588, 999, 1000, 1000, 1001, 45, 1715, 1000, 1001, 529, 999, 1000, 1000, 878, 172, 962, 999, 1002, 999, 999, 871, 1002, 418, 1001, 1083, 1001, 1000, 711, 1000, 1000, 783, 346, 346, 508, 1001, 999, 1000, 1000, 999, 755, 999, 666, 805, 999, 1000, 828, 555, 1000, 843, 964, 346, 999, 992, 763, 518, 826, 346, 923, 519]
theorem loads129 : cs129.get =
    load (fun i : Fin entries129.length => support (entries129.get i).1)
      (fun i => (entries129.get i).2) := by
  apply load_eq_of_sparse_packed base cs129 support code
    entries129 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node129 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 64 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 40 (insert 53 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs129 support demand
    entries129 ((insert 64 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 40 (insert 53 (insert 101 ∅))) : Finset (Fin 154)) 1000 30 loads129
  decide +kernel
def entries130 : List (Fin 1589 × ℕ) := [(20, 74), (37, 369), (62, 61), (77, 131), (86, 101), (122, 230), (179, 113), (230, 380), (323, 153), (343, 9), (466, 178), (475, 184), (484, 100), (498, 68), (507, 401), (531, 36), (542, 121), (583, 154), (639, 164), (681, 7), (690, 24), (730, 329), (731, 123), (815, 257), (835, 6), (850, 82), (856, 48), (858, 84), (867, 17), (870, 198), (872, 137), (881, 35), (886, 122), (905, 528), (913, 77), (914, 194), (920, 121), (936, 18), (938, 265), (950, 50), (973, 275), (978, 402), (985, 52), (1009, 266), (1010, 402), (1034, 8), (1048, 74), (1068, 239), (1070, 276), (1082, 95), (1090, 301), (1113, 220), (1137, 323), (1160, 247), (1173, 8), (1182, 301), (1219, 59), (1227, 318), (1228, 82), (1241, 17), (1261, 284), (1275, 68), (1293, 59), (1308, 129), (1335, 2), (1356, 8), (1359, 27), (1379, 262), (1457, 252), (1491, 71), (1508, 142), (1548, 44)]
def cs130 : List ℕ := [430, 86, 8, 399, 8, 769, 84, 516, 511, 462, 662, 999, 998, 316, 252, 336, 1000, 1000, 999, 430, 1000, 972, 113, 806, 1000, 999, 701, 1000, 741, 458, 1000, 1000, 756, 0, 1000, 268, 1000, 1000, 999, 1001, 0, 999, 271, 653, 1001, 999, 1000, 999, 795, 721, 1000, 873, 1000, 1196, 8, 1000, 999, 999, 1001, 336, 1000, 960, 614, 993, 95, 484, 999, 1000, 975, 1000, 1000, 1000, 1000, 1000, 703, 957, 0, 1000, 1000, 1000, 839, 1000, 946, 744, 572, 1000, 528, 881, 1000, 1000, 1001, 762, 578, 1000, 473, 641, 1000, 1000, 1000, 1001, 0, 2051, 1000, 999, 358, 721, 1000, 1000, 894, 44, 1000, 1000, 1000, 1000, 999, 785, 1000, 301, 1000, 751, 1000, 1001, 304, 887, 999, 872, 275, 275, 443, 1000, 999, 1000, 1000, 1000, 655, 1000, 357, 837, 1000, 1000, 906, 701, 1000, 607, 675, 275, 1000, 981, 677, 285, 745, 343, 578, 689]
theorem loads130 : cs130.get =
    load (fun i : Fin entries130.length => support (entries130.get i).1)
      (fun i => (entries130.get i).2) := by
  apply load_eq_of_sparse_packed base cs130 support code
    entries130 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node130 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 40 (insert 64 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 53 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs130 support demand
    entries130 ((insert 40 (insert 64 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 53 (insert 101 ∅)) : Finset (Fin 154)) 1000 30 loads130
  decide +kernel
theorem node128 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 64 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 53 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 64 (insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 53 (insert 101 ∅)) : Finset (Fin 154))
    40 node129 node130
theorem node126 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 53 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 65 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 53 (insert 101 ∅)) : Finset (Fin 154))
    64 node127 node128
theorem node75 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 53 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 53 (insert 101 ∅)) : Finset (Fin 154))
    65 node125 node126
def entries123 : List (Fin 1589 × ℕ) := [(17, 215), (43, 3), (65, 41), (86, 134), (343, 37), (387, 13), (420, 38), (421, 12), (472, 412), (475, 78), (491, 351), (497, 361), (507, 201), (542, 412), (617, 681), (625, 243), (632, 48), (639, 231), (730, 421), (731, 294), (737, 82), (815, 209), (835, 2), (848, 238), (850, 268), (856, 134), (863, 185), (867, 78), (870, 87), (872, 143), (884, 26), (886, 497), (894, 75), (896, 136), (904, 162), (905, 159), (918, 317), (920, 115), (923, 90), (924, 279), (928, 97), (930, 45), (938, 22), (949, 368), (973, 467), (978, 134), (984, 29), (1005, 173), (1006, 20), (1030, 364), (1031, 183), (1056, 12), (1061, 87), (1082, 141), (1086, 28), (1090, 636), (1099, 347), (1100, 3), (1114, 229), (1137, 350), (1138, 4), (1149, 162), (1153, 36), (1182, 170), (1261, 219), (1263, 93), (1268, 84), (1275, 146), (1277, 36), (1293, 275), (1420, 42), (1489, 28), (1498, 66), (1517, 160), (1573, 18)]
def cs123 : List ℕ := [0, 0, 650, 561, 0, 200, 514, 650, 669, 427, 78, 810, 1000, 442, 415, 66, 1001, 1001, 1000, 84, 1001, 564, 0, 1000, 1000, 1002, 2403, 1001, 285, 69, 1001, 1000, 874, 0, 1000, 1001, 1001, 1001, 170, 1000, 940, 1001, 561, 414, 1001, 1000, 1001, 1000, 715, 1642, 1002, 1000, 1000, 163, 238, 1001, 1002, 1001, 999, 838, 2295, 1000, 899, 775, 1001, 996, 1000, 1001, 1001, 1001, 1000, 1000, 942, 1000, 20, 1000, 0, 832, 1000, 1000, 1851, 1000, 938, 1000, 791, 710, 931, 1000, 1000, 1001, 1000, 890, 1000, 1000, 1001, 547, 999, 1000, 1001, 1000, 0, 2203, 1000, 1001, 681, 999, 1001, 1000, 820, 0, 1000, 999, 1000, 868, 864, 1000, 1000, 170, 999, 831, 999, 758, 229, 1001, 1000, 999, 467, 686, 210, 977, 1000, 1181, 1000, 999, 666, 1000, 629, 1000, 999, 1959, 577, 976, 999, 800, 663, 467, 943, 1453, 677, 858, 819, 613, 673, 649]
theorem loads123 : cs123.get =
    load (fun i : Fin entries123.length => support (entries123.get i).1)
      (fun i => (entries123.get i).2) := by
  apply load_eq_of_sparse_packed base cs123 support code
    entries123 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node123 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 49 (insert 26 (insert 80 (insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs123 support demand
    entries123 ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 49 (insert 26 (insert 80 (insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅)))))))) : Finset (Fin 154)) 1000 30 loads123
  decide +kernel
def entries124 : List (Fin 1589 × ℕ) := [(17, 20), (20, 14), (30, 22), (43, 8), (75, 1), (86, 10), (122, 10), (137, 27), (384, 4), (466, 18), (475, 1), (485, 24), (491, 18), (507, 36), (542, 10), (571, 9), (572, 2), (617, 70), (624, 3), (625, 44), (632, 22), (639, 39), (672, 4), (675, 4), (730, 6), (731, 37), (741, 13), (813, 3), (815, 10), (844, 1), (850, 29), (856, 8), (867, 16), (869, 3), (870, 12), (872, 9), (882, 11), (883, 10), (894, 7), (896, 19), (905, 36), (918, 20), (920, 2), (923, 13), (924, 15), (930, 42), (947, 4), (949, 24), (973, 40), (985, 4), (1005, 26), (1030, 37), (1045, 19), (1061, 15), (1070, 4), (1082, 2), (1086, 10), (1090, 63), (1099, 10), (1100, 11), (1114, 36), (1137, 41), (1149, 19), (1153, 10), (1154, 14), (1182, 19), (1261, 23), (1275, 5), (1279, 5), (1293, 14), (1457, 11), (1489, 2), (1508, 12), (1577, 9), (1578, 2), (1580, 7), (1582, 2), (1586, 10)]
def cs124 : List ℕ := [30, 15, 0, 66, 9, 72, 39, 54, 56, 46, 32, 99, 99, 72, 37, 34, 99, 99, 99, 11, 99, 99, 0, 99, 100, 100, 170, 99, 57, 45, 99, 100, 99, 1, 99, 99, 100, 99, 44, 100, 94, 72, 57, 44, 99, 100, 100, 100, 53, 36, 98, 99, 76, 0, 0, 99, 98, 99, 100, 70, 137, 100, 100, 99, 82, 100, 100, 99, 100, 100, 100, 99, 75, 100, 0, 101, 0, 100, 100, 101, 207, 99, 62, 99, 67, 69, 99, 101, 98, 100, 101, 85, 99, 99, 78, 60, 100, 99, 100, 101, 0, 191, 99, 100, 74, 99, 99, 101, 84, 0, 100, 101, 99, 60, 75, 100, 99, 33, 100, 77, 99, 100, 36, 101, 100, 100, 40, 40, 34, 100, 101, 118, 100, 101, 51, 101, 59, 100, 101, 238, 61, 85, 100, 80, 62, 40, 91, 144, 59, 95, 64, 45, 83, 45]
theorem loads124 : cs124.get =
    load (fun i : Fin entries124.length => support (entries124.get i).1)
      (fun i => (entries124.get i).2) := by
  apply load_eq_of_sparse_packed base cs124 support code
    entries124 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node124 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 49 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 26 (insert 80 (insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs124 support demand
    entries124 ((insert 49 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 26 (insert 80 (insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅))))))) : Finset (Fin 154)) 100 30 loads124
  decide +kernel
theorem node121 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 26 (insert 80 (insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 26 (insert 80 (insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅))))))) : Finset (Fin 154))
    49 node123 node124
def entries122 : List (Fin 1589 × ℕ) := [(17, 83), (30, 153), (86, 93), (137, 196), (384, 31), (385, 95), (387, 123), (466, 296), (475, 59), (479, 224), (491, 227), (527, 112), (531, 62), (552, 31), (625, 72), (639, 181), (673, 438), (730, 404), (731, 128), (736, 108), (737, 102), (815, 326), (835, 5), (844, 100), (846, 190), (850, 418), (866, 96), (867, 45), (869, 62), (870, 3), (872, 256), (879, 75), (886, 307), (894, 20), (896, 72), (904, 179), (905, 232), (918, 199), (920, 12), (923, 45), (924, 366), (928, 145), (944, 42), (949, 294), (973, 390), (984, 103), (1005, 151), (1006, 50), (1030, 315), (1055, 153), (1061, 127), (1070, 268), (1082, 254), (1086, 81), (1090, 685), (1100, 62), (1114, 253), (1122, 22), (1137, 457), (1138, 83), (1149, 103), (1182, 153), (1220, 16), (1234, 127), (1261, 219), (1275, 131), (1293, 116), (1320, 31), (1342, 206), (1374, 12), (1489, 134), (1491, 72), (1493, 31), (1509, 11), (1517, 35), (1528, 128), (1578, 174)]
def cs122 : List ℕ := [412, 206, 0, 576, 398, 153, 436, 1000, 236, 0, 326, 965, 1001, 554, 174, 394, 1000, 1000, 1001, 0, 1000, 502, 31, 999, 730, 1000, 0, 999, 72, 0, 1000, 1000, 619, 100, 1000, 828, 1000, 1000, 612, 1000, 666, 261, 667, 546, 1001, 1000, 1000, 999, 865, 1000, 1000, 999, 754, 309, 0, 1001, 999, 1000, 999, 1000, 1603, 999, 999, 909, 776, 948, 1000, 1000, 1000, 999, 1001, 1000, 1001, 999, 178, 1001, 0, 732, 1000, 1000, 1654, 1001, 367, 986, 999, 1001, 892, 1000, 999, 999, 1000, 771, 1000, 1000, 1001, 443, 1001, 999, 1001, 1000, 0, 2184, 999, 1001, 834, 1000, 1002, 1000, 874, 0, 1000, 1000, 1000, 978, 871, 1000, 1000, 195, 1001, 705, 1000, 1001, 381, 1000, 1000, 1000, 518, 596, 289, 999, 1000, 1162, 1000, 1001, 573, 1000, 621, 1000, 1001, 2096, 644, 889, 1000, 760, 431, 390, 962, 1532, 679, 746, 705, 521, 574, 521]
theorem loads122 : cs122.get =
    load (fun i : Fin entries122.length => support (entries122.get i).1)
      (fun i => (entries122.get i).2) := by
  apply load_eq_of_sparse_packed base cs122 support code
    entries122 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node122 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 26 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 80 (insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs122 support demand
    entries122 ((insert 26 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 80 (insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅)))))) : Finset (Fin 154)) 1000 30 loads122
  decide +kernel
theorem node119 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 80 (insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 80 (insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅)))))) : Finset (Fin 154))
    26 node121 node122
def entries120 : List (Fin 1589 × ℕ) := [(17, 227), (122, 348), (137, 65), (385, 6), (387, 225), (421, 33), (466, 269), (475, 86), (479, 272), (507, 227), (515, 141), (527, 8), (542, 291), (552, 379), (571, 248), (588, 62), (616, 117), (622, 8), (624, 100), (632, 201), (639, 17), (737, 214), (739, 72), (815, 241), (819, 10), (846, 113), (850, 321), (856, 315), (866, 91), (870, 239), (872, 160), (879, 21), (886, 422), (894, 114), (895, 22), (896, 60), (903, 22), (905, 133), (918, 81), (920, 224), (924, 251), (944, 17), (948, 181), (949, 69), (950, 163), (973, 444), (978, 47), (984, 59), (985, 47), (1005, 78), (1006, 89), (1030, 469), (1055, 195), (1056, 23), (1061, 124), (1070, 222), (1082, 246), (1090, 531), (1100, 32), (1114, 157), (1122, 37), (1137, 362), (1149, 106), (1182, 172), (1240, 174), (1261, 287), (1268, 93), (1275, 274), (1293, 74), (1346, 34), (1374, 50), (1459, 42), (1491, 137), (1517, 53), (1528, 60), (1539, 52), (1578, 103)]
def cs120 : List ℕ := [269, 113, 0, 634, 375, 315, 156, 757, 227, 227, 335, 750, 999, 480, 394, 988, 1000, 1000, 1000, 341, 1000, 874, 62, 1000, 1001, 999, 1000, 1002, 456, 375, 1000, 1000, 816, 0, 1001, 1001, 1002, 1000, 174, 1002, 889, 657, 780, 319, 1001, 999, 1000, 1000, 348, 1000, 1000, 1001, 1000, 219, 0, 1000, 1000, 1000, 1001, 983, 1939, 713, 721, 907, 510, 956, 1000, 1001, 1000, 1001, 1000, 1000, 999, 1001, 149, 999, 0, 618, 1000, 1000, 0, 1001, 1000, 1000, 437, 1000, 512, 998, 1001, 1000, 1001, 799, 999, 1001, 999, 646, 1000, 1000, 1000, 999, 0, 2130, 999, 1000, 282, 1000, 999, 1001, 832, 0, 1001, 1000, 601, 999, 865, 1000, 1000, 189, 1000, 913, 696, 999, 323, 1000, 998, 1001, 504, 676, 303, 1000, 1000, 1275, 1000, 1000, 589, 999, 610, 1001, 1000, 1724, 770, 832, 1001, 842, 520, 444, 1000, 1337, 653, 707, 890, 718, 616, 718]
theorem loads120 : cs120.get =
    load (fun i : Fin entries120.length => support (entries120.get i).1)
      (fun i => (entries120.get i).2) := by
  apply load_eq_of_sparse_packed base cs120 support code
    entries120 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node120 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 80 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs120 support demand
    entries120 ((insert 80 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅))))) : Finset (Fin 154)) 1000 30 loads120
  decide +kernel
theorem node115 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 131 (insert 60 (insert 147 (insert 139 (insert 101 ∅))))) : Finset (Fin 154))
    80 node119 node120
def entries117 : List (Fin 1589 × ℕ) := [(17, 60), (20, 225), (77, 53), (86, 146), (122, 307), (137, 13), (274, 30), (466, 312), (479, 163), (491, 12), (497, 16), (515, 146), (527, 57), (541, 75), (542, 27), (588, 403), (617, 89), (625, 185), (629, 47), (631, 23), (639, 203), (730, 111), (731, 138), (737, 197), (740, 12), (815, 495), (835, 80), (844, 53), (850, 208), (855, 8), (856, 236), (863, 98), (868, 1), (870, 302), (871, 91), (872, 223), (886, 103), (894, 215), (896, 240), (905, 380), (906, 27), (920, 163), (924, 195), (930, 198), (937, 68), (938, 123), (939, 47), (950, 88), (973, 50), (980, 20), (984, 356), (985, 176), (1005, 17), (1006, 154), (1020, 371), (1045, 359), (1056, 25), (1070, 208), (1075, 81), (1090, 342), (1114, 341), (1138, 54), (1139, 30), (1149, 412), (1160, 94), (1163, 216), (1182, 321), (1220, 6), (1246, 213), (1261, 233), (1268, 298), (1275, 218), (1293, 26), (1374, 7), (1489, 66), (1490, 57), (1491, 65), (1498, 104), (1509, 78), (1525, 68), (1556, 37), (1577, 52), (1578, 170), (1588, 28)]
def cs117 : List ℕ := [371, 6, 68, 499, 333, 348, 234, 772, 301, 166, 516, 1000, 1000, 897, 377, 833, 1000, 1000, 1000, 298, 1000, 992, 403, 1000, 1001, 999, 1000, 999, 545, 295, 999, 1000, 1000, 53, 1000, 1000, 1001, 1001, 530, 1000, 1001, 1000, 878, 999, 998, 1000, 1000, 2440, 769, 1001, 1000, 1001, 1001, 362, 0, 1000, 999, 999, 1000, 916, 2067, 825, 1002, 1000, 462, 1000, 1000, 999, 1001, 1000, 999, 999, 1001, 1001, 154, 999, 0, 998, 999, 1000, 1000, 1000, 999, 572, 954, 1001, 649, 999, 999, 1000, 1000, 599, 1000, 999, 1000, 359, 999, 999, 1000, 1000, 74, 1164, 1000, 1001, 297, 716, 999, 1000, 966, 0, 1000, 999, 1000, 584, 1000, 342, 1000, 321, 1000, 50, 1000, 964, 341, 1000, 1000, 636, 50, 50, 405, 1000, 1000, 50, 1000, 1000, 767, 1000, 462, 490, 1000, 1361, 1000, 670, 983, 362, 717, 50, 999, 392, 641, 803, 835, 268, 587, 362]
theorem loads117 : cs117.get =
    load (fun i : Fin entries117.length => support (entries117.get i).1)
      (fun i => (entries117.get i).2) := by
  apply load_eq_of_sparse_packed base cs117 support code
    entries117 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node117 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 131 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 60 (insert 147 (insert 139 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs117 support demand
    entries117 ((insert 131 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 47 (insert 60 (insert 147 (insert 139 (insert 101 ∅))))) : Finset (Fin 154)) 1000 30 loads117
  decide +kernel
def entries118 : List (Fin 1589 × ℕ) := [(17, 25), (20, 10), (62, 31), (86, 13), (122, 7), (137, 10), (341, 11), (343, 4), (383, 1), (421, 4), (466, 34), (472, 24), (475, 1), (491, 26), (507, 19), (542, 21), (552, 19), (577, 10), (616, 29), (617, 26), (625, 35), (632, 21), (639, 11), (730, 13), (731, 27), (737, 9), (815, 34), (850, 24), (855, 24), (858, 4), (870, 24), (872, 25), (882, 2), (884, 13), (886, 18), (894, 2), (896, 11), (905, 18), (918, 32), (920, 6), (924, 10), (937, 17), (949, 6), (950, 31), (966, 12), (973, 14), (984, 17), (985, 16), (1005, 6), (1006, 12), (1020, 18), (1045, 34), (1048, 7), (1056, 3), (1061, 3), (1070, 23), (1075, 17), (1076, 6), (1086, 10), (1090, 46), (1114, 36), (1138, 2), (1149, 28), (1159, 10), (1163, 27), (1182, 32), (1261, 31), (1263, 17), (1275, 2), (1293, 8), (1491, 17), (1528, 8), (1580, 4), (1587, 3)]
def cs118 : List ℕ := [34, 3, 24, 60, 4, 24, 30, 65, 52, 50, 0, 101, 100, 98, 25, 48, 99, 100, 100, 31, 99, 62, 0, 99, 100, 98, 101, 101, 42, 31, 100, 100, 50, 0, 100, 101, 100, 100, 31, 100, 90, 86, 66, 66, 101, 99, 100, 0, 47, 99, 100, 99, 100, 17, 0, 100, 100, 100, 100, 79, 113, 79, 94, 82, 88, 99, 100, 102, 101, 101, 100, 100, 87, 101, 20, 101, 0, 100, 100, 100, 101, 101, 84, 99, 61, 101, 97, 99, 101, 100, 100, 56, 100, 100, 88, 71, 101, 99, 100, 101, 0, 108, 99, 84, 64, 101, 100, 100, 86, 0, 100, 101, 99, 56, 100, 46, 100, 44, 101, 21, 100, 100, 51, 99, 100, 54, 22, 14, 34, 100, 99, 14, 100, 100, 44, 100, 57, 65, 99, 164, 77, 73, 100, 39, 52, 14, 101, 60, 75, 78, 75, 16, 83, 16]
theorem loads118 : cs118.get =
    load (fun i : Fin entries118.length => support (entries118.get i).1)
      (fun i => (entries118.get i).2) := by
  apply load_eq_of_sparse_packed base cs118 support code
    entries118 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node118 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 131 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 147 (insert 139 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs118 support demand
    entries118 ((insert 47 (insert 131 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 60 (insert 147 (insert 139 (insert 101 ∅)))) : Finset (Fin 154)) 100 30 loads118
  decide +kernel
theorem node116 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 131 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 147 (insert 139 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 131 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 60 (insert 147 (insert 139 (insert 101 ∅)))) : Finset (Fin 154))
    47 node117 node118
theorem node111 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 147 (insert 139 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 60 (insert 147 (insert 139 (insert 101 ∅)))) : Finset (Fin 154))
    131 node115 node116
def entries113 : List (Fin 1589 × ℕ) := [(10, 8), (13, 6), (17, 17), (37, 2), (62, 30), (70, 6), (86, 27), (137, 27), (179, 8), (206, 4), (344, 16), (466, 17), (472, 25), (475, 16), (491, 6), (498, 7), (507, 9), (515, 8), (527, 5), (571, 6), (616, 40), (617, 14), (624, 13), (632, 8), (639, 44), (672, 2), (730, 39), (731, 33), (737, 1), (739, 28), (813, 22), (844, 7), (855, 27), (868, 8), (869, 6), (870, 7), (872, 12), (896, 54), (898, 6), (904, 35), (920, 9), (929, 48), (930, 2), (938, 6), (964, 3), (966, 10), (973, 31), (975, 5), (978, 2), (985, 4), (1005, 25), (1018, 2), (1020, 2), (1030, 24), (1031, 3), (1045, 17), (1056, 13), (1061, 34), (1070, 30), (1082, 14), (1090, 57), (1100, 12), (1114, 28), (1137, 45), (1149, 18), (1153, 6), (1171, 6), (1182, 9), (1188, 2), (1261, 10), (1267, 2), (1275, 17), (1277, 4), (1308, 7), (1401, 3), (1466, 16), (1517, 12), (1576, 10), (1577, 3), (1578, 1), (1580, 14), (1582, 22)]
def cs113 : List ℕ := [24, 0, 39, 55, 23, 51, 44, 70, 26, 39, 45, 100, 101, 81, 27, 26, 100, 100, 100, 38, 101, 88, 14, 99, 99, 101, 100, 100, 25, 22, 101, 100, 37, 13, 100, 99, 100, 101, 90, 100, 98, 99, 81, 71, 100, 101, 99, 100, 92, 99, 101, 99, 51, 2, 6, 100, 100, 99, 99, 100, 0, 99, 85, 99, 101, 100, 100, 100, 99, 257, 100, 95, 100, 99, 6, 101, 2, 89, 100, 100, 100, 101, 71, 99, 100, 97, 101, 101, 100, 100, 83, 101, 100, 98, 85, 86, 101, 100, 101, 100, 0, 184, 59, 100, 50, 100, 100, 100, 99, 3, 100, 101, 99, 42, 100, 81, 100, 19, 101, 55, 100, 100, 62, 100, 100, 100, 31, 38, 37, 100, 100, 100, 101, 100, 46, 100, 55, 96, 100, 213, 56, 85, 100, 92, 46, 31, 90, 133, 44, 83, 61, 48, 46, 52]
theorem loads113 : cs113.get =
    load (fun i : Fin entries113.length => support (entries113.get i).1)
      (fun i => (entries113.get i).2) := by
  apply load_eq_of_sparse_packed base cs113 support code
    entries113 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node113 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 60 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 147 (insert 139 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs113 support demand
    entries113 ((insert 60 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 69 (insert 147 (insert 139 (insert 101 ∅)))) : Finset (Fin 154)) 100 30 loads113
  decide +kernel
def entries114 : List (Fin 1589 × ℕ) := [(13, 1), (17, 23), (20, 8), (37, 18), (62, 29), (86, 1), (122, 27), (137, 24), (179, 18), (439, 16), (466, 32), (472, 11), (475, 8), (479, 12), (507, 41), (515, 9), (577, 8), (617, 42), (623, 11), (625, 15), (631, 39), (639, 15), (673, 4), (736, 9), (737, 3), (738, 9), (741, 21), (813, 2), (815, 22), (842, 2), (844, 16), (850, 9), (855, 9), (869, 2), (870, 22), (872, 19), (890, 6), (894, 23), (918, 15), (920, 15), (930, 27), (938, 7), (956, 11), (964, 2), (966, 24), (973, 32), (975, 2), (985, 31), (1005, 9), (1018, 17), (1020, 1), (1030, 33), (1045, 19), (1056, 9), (1061, 26), (1070, 23), (1075, 12), (1090, 52), (1100, 3), (1114, 33), (1137, 35), (1149, 3), (1182, 22), (1261, 28), (1263, 12), (1275, 7), (1277, 9), (1308, 3), (1466, 5), (1491, 20), (1508, 8), (1517, 11), (1537, 4), (1555, 1), (1577, 5), (1578, 10), (1582, 9)]
def cs114 : List ℕ := [48, 0, 16, 57, 22, 40, 35, 86, 65, 70, 28, 93, 99, 83, 15, 71, 99, 101, 99, 47, 100, 101, 18, 100, 100, 99, 99, 100, 53, 65, 100, 101, 80, 16, 100, 99, 99, 100, 92, 100, 99, 90, 42, 70, 101, 100, 101, 99, 45, 57, 100, 98, 84, 0, 0, 100, 100, 99, 100, 100, 0, 72, 90, 99, 99, 100, 99, 100, 73, 0, 99, 101, 86, 58, 0, 100, 0, 100, 99, 101, 99, 101, 100, 101, 57, 100, 86, 99, 100, 100, 99, 100, 100, 101, 100, 52, 100, 100, 99, 99, 0, 181, 100, 76, 69, 100, 100, 100, 101, 13, 100, 99, 100, 36, 99, 94, 101, 47, 100, 65, 86, 100, 33, 101, 100, 70, 32, 41, 57, 101, 100, 100, 101, 99, 45, 99, 35, 98, 100, 181, 74, 66, 99, 75, 39, 32, 60, 119, 63, 68, 70, 39, 54, 49]
theorem loads114 : cs114.get =
    load (fun i : Fin entries114.length => support (entries114.get i).1)
      (fun i => (entries114.get i).2) := by
  apply load_eq_of_sparse_packed base cs114 support code
    entries114 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node114 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 147 (insert 139 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs114 support demand
    entries114 ((insert 69 (insert 60 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 147 (insert 139 (insert 101 ∅))) : Finset (Fin 154)) 100 30 loads114
  decide +kernel
theorem node112 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 60 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 147 (insert 139 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 60 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 147 (insert 139 (insert 101 ∅))) : Finset (Fin 154))
    69 node113 node114
theorem node103 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 147 (insert 139 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 147 (insert 139 (insert 101 ∅))) : Finset (Fin 154))
    60 node111 node112
def entries109 : List (Fin 1589 × ℕ) := [(13, 33), (17, 231), (62, 179), (116, 57), (122, 16), (179, 95), (418, 54), (466, 147), (472, 295), (475, 66), (479, 97), (498, 71), (507, 81), (531, 122), (541, 77), (616, 18), (617, 225), (624, 74), (625, 120), (632, 184), (639, 95), (672, 249), (675, 174), (730, 39), (731, 100), (737, 6), (812, 121), (813, 387), (844, 51), (850, 55), (855, 208), (868, 90), (870, 385), (872, 261), (882, 152), (886, 110), (894, 8), (895, 290), (905, 207), (920, 210), (924, 194), (930, 134), (937, 92), (949, 24), (950, 132), (958, 175), (964, 95), (965, 40), (966, 4), (978, 278), (985, 296), (1006, 280), (1020, 88), (1030, 384), (1045, 75), (1053, 10), (1056, 95), (1061, 108), (1075, 182), (1076, 10), (1089, 230), (1114, 280), (1139, 284), (1149, 424), (1152, 339), (1164, 247), (1182, 329), (1240, 94), (1261, 166), (1275, 120), (1293, 268), (1379, 133), (1434, 62), (1457, 213), (1469, 78), (1491, 125), (1499, 89), (1509, 29), (1537, 74), (1566, 40), (1577, 190), (1580, 71)]
def cs109 : List ℕ := [411, 0, 402, 352, 168, 495, 190, 981, 438, 260, 465, 1001, 947, 1000, 338, 569, 1001, 1000, 1000, 179, 1001, 735, 135, 1002, 1001, 1001, 1001, 1001, 474, 373, 1001, 1000, 535, 51, 1000, 1001, 2587, 999, 599, 1001, 1000, 836, 392, 1000, 1000, 1001, 1000, 1000, 368, 1001, 1000, 1000, 970, 278, 89, 1000, 1001, 999, 999, 568, 1001, 674, 1000, 999, 1001, 1000, 1000, 999, 810, 998, 1000, 1000, 1000, 561, 280, 1001, 0, 999, 999, 1000, 999, 999, 769, 1001, 630, 1000, 1000, 1000, 1001, 1001, 1000, 682, 1000, 999, 854, 726, 999, 2028, 1000, 1001, 0, 1085, 1000, 999, 225, 1000, 1851, 1000, 542, 95, 825, 1000, 999, 598, 999, 614, 1001, 548, 1000, 384, 999, 1000, 280, 1000, 1001, 704, 0, 0, 1000, 1000, 999, 384, 1000, 999, 727, 1001, 424, 257, 1000, 1059, 954, 424, 999, 567, 1001, 0, 1000, 0, 576, 704, 980, 459, 329, 367]
theorem loads109 : cs109.get =
    load (fun i : Fin entries109.length => support (entries109.get i).1)
      (fun i => (entries109.get i).2) := by
  apply load_eq_of_sparse_packed base cs109 support code
    entries109 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node109 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 106 (insert 97 (insert 139 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs109 support demand
    entries109 ((insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 36 (insert 106 (insert 97 (insert 139 (insert 101 ∅))))) : Finset (Fin 154)) 1000 30 loads109
  decide +kernel
def entries110 : List (Fin 1589 × ℕ) := [(17, 15), (20, 26), (37, 20), (86, 4), (135, 7), (137, 5), (203, 12), (344, 26), (386, 2), (421, 17), (466, 30), (479, 30), (484, 31), (491, 38), (507, 14), (514, 2), (542, 8), (571, 19), (572, 6), (588, 25), (617, 20), (639, 19), (730, 18), (731, 21), (737, 26), (740, 5), (741, 17), (812, 7), (813, 37), (833, 4), (844, 5), (850, 4), (856, 23), (863, 17), (870, 22), (871, 1), (872, 16), (886, 18), (890, 1), (894, 31), (896, 20), (904, 31), (905, 25), (920, 15), (924, 10), (928, 13), (938, 9), (940, 2), (948, 3), (949, 3), (958, 4), (978, 24), (985, 22), (994, 1), (1006, 16), (1020, 5), (1030, 41), (1045, 8), (1048, 3), (1061, 8), (1070, 14), (1086, 3), (1089, 43), (1114, 24), (1139, 30), (1149, 49), (1152, 29), (1164, 18), (1182, 33), (1234, 21), (1235, 5), (1261, 14), (1275, 19), (1281, 7), (1293, 18), (1342, 1), (1580, 10)]
def cs110 : List ℕ := [42, 0, 7, 52, 40, 74, 38, 82, 61, 31, 2, 101, 100, 68, 18, 0, 100, 100, 100, 45, 100, 67, 25, 101, 89, 100, 100, 99, 0, 26, 101, 100, 80, 6, 100, 101, 0, 100, 55, 100, 82, 89, 91, 87, 99, 100, 100, 101, 61, 100, 100, 100, 70, 24, 0, 100, 100, 101, 100, 100, 100, 100, 99, 64, 68, 99, 100, 99, 101, 100, 100, 99, 88, 61, 17, 100, 0, 98, 100, 100, 100, 99, 99, 100, 86, 100, 64, 100, 100, 100, 99, 54, 99, 98, 100, 49, 100, 180, 100, 100, 2, 117, 101, 76, 37, 99, 199, 99, 52, 0, 48, 99, 100, 78, 100, 86, 100, 37, 101, 44, 100, 101, 27, 99, 100, 66, 0, 0, 100, 100, 99, 41, 100, 99, 75, 99, 52, 8, 100, 102, 100, 63, 99, 59, 100, 0, 100, 0, 51, 73, 100, 48, 33, 37]
theorem loads110 : cs110.get =
    load (fun i : Fin entries110.length => support (entries110.get i).1)
      (fun i => (entries110.get i).2) := by
  apply load_eq_of_sparse_packed base cs110 support code
    entries110 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node110 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 36 (insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 106 (insert 97 (insert 139 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs110 support demand
    entries110 ((insert 36 (insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 106 (insert 97 (insert 139 (insert 101 ∅)))) : Finset (Fin 154)) 100 30 loads110
  decide +kernel
theorem node107 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 106 (insert 97 (insert 139 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 106 (insert 97 (insert 139 (insert 101 ∅)))) : Finset (Fin 154))
    36 node109 node110
def entries108 : List (Fin 1589 × ℕ) := [(10, 27), (20, 34), (86, 5), (122, 22), (137, 1), (179, 18), (203, 9), (421, 7), (439, 3), (466, 24), (479, 5), (484, 31), (491, 11), (507, 23), (542, 20), (577, 1), (616, 41), (617, 17), (625, 8), (632, 4), (675, 7), (730, 11), (736, 4), (737, 28), (815, 27), (833, 21), (835, 14), (844, 3), (850, 2), (855, 25), (856, 13), (863, 2), (870, 32), (872, 13), (884, 14), (886, 14), (893, 7), (895, 12), (896, 13), (904, 13), (920, 28), (923, 6), (930, 30), (935, 4), (949, 13), (950, 29), (956, 25), (958, 1), (978, 25), (985, 3), (1006, 14), (1020, 4), (1030, 22), (1045, 27), (1056, 39), (1061, 35), (1070, 24), (1075, 22), (1089, 9), (1099, 10), (1114, 48), (1149, 48), (1153, 14), (1159, 48), (1164, 48), (1263, 3), (1268, 4), (1275, 4), (1310, 7), (1312, 16), (1401, 14), (1469, 4), (1491, 27), (1577, 11), (1578, 17)]
def cs108 : List ℕ := [27, 0, 27, 36, 49, 69, 39, 49, 37, 25, 17, 100, 101, 78, 62, 77, 101, 101, 100, 4, 101, 101, 18, 100, 100, 100, 100, 101, 41, 56, 101, 98, 87, 3, 100, 100, 100, 101, 64, 100, 58, 99, 39, 60, 100, 100, 99, 100, 78, 100, 100, 100, 98, 25, 0, 100, 100, 101, 100, 99, 99, 92, 101, 100, 100, 101, 100, 101, 96, 100, 100, 100, 70, 71, 14, 100, 0, 101, 100, 100, 100, 100, 100, 100, 60, 100, 85, 88, 100, 101, 100, 63, 101, 101, 0, 90, 100, 136, 100, 100, 0, 99, 99, 47, 41, 100, 0, 99, 97, 25, 88, 99, 100, 45, 101, 31, 101, 1, 99, 22, 85, 100, 48, 101, 101, 62, 0, 0, 3, 100, 101, 22, 101, 100, 66, 100, 48, 49, 100, 179, 66, 82, 100, 101, 66, 0, 96, 0, 48, 96, 52, 4, 62, 52]
theorem loads108 : cs108.get =
    load (fun i : Fin entries108.length => support (entries108.get i).1)
      (fun i => (entries108.get i).2) := by
  apply load_eq_of_sparse_packed base cs108 support code
    entries108 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node108 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 106 (insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 139 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs108 support demand
    entries108 ((insert 106 (insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 97 (insert 139 (insert 101 ∅))) : Finset (Fin 154)) 100 30 loads108
  decide +kernel
theorem node105 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 97 (insert 139 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 97 (insert 139 (insert 101 ∅))) : Finset (Fin 154))
    106 node107 node108
def entries106 : List (Fin 1589 × ℕ) := [(10, 125032), (20, 226362), (62, 73025), (86, 9846), (122, 91653), (135, 145987), (179, 7704), (206, 235163), (343, 213900), (344, 64565), (421, 9896), (439, 182400), (466, 337756), (472, 281184), (475, 211782), (479, 176221), (491, 169835), (507, 94501), (531, 29736), (542, 171289), (552, 138778), (588, 179552), (616, 25587), (617, 391410), (632, 95692), (639, 201800), (738, 85951), (815, 140441), (842, 236149), (844, 65186), (850, 87743), (855, 125215), (863, 137055), (870, 160090), (872, 238989), (881, 198293), (886, 145321), (893, 18532), (896, 261815), (903, 80891), (905, 58887), (918, 188916), (920, 166716), (924, 253144), (930, 12606), (932, 42339), (950, 192933), (956, 49694), (960, 224062), (964, 110360), (966, 59021), (978, 341438), (985, 56681), (1006, 68581), (1020, 231224), (1030, 210763), (1031, 38750), (1045, 176602), (1056, 338506), (1061, 30806), (1086, 162659), (1089, 305008), (1100, 124799), (1114, 193380), (1139, 393452), (1149, 483624), (1152, 282102), (1153, 147843), (1159, 356486), (1171, 266314), (1246, 334552), (1251, 125263), (1263, 82567), (1292, 70263), (1310, 35669), (1374, 52689), (1469, 216948), (1489, 8815), (1517, 89848), (1577, 20844), (1580, 55491), (1582, 19489)]
def cs106 : List ℕ := [402942, 0, 406216, 545376, 356744, 214967, 300016, 915838, 308929, 304581, 89752, 1000001, 1000001, 748635, 247624, 469057, 1000000, 1000002, 1000001, 73025, 1000001, 579599, 187256, 1000001, 1000000, 999999, 1000000, 1000001, 344270, 329758, 1000001, 1000001, 828827, 331500, 999999, 1000001, 1000000, 1000000, 436702, 1000000, 960682, 1000000, 806963, 1000000, 1000000, 1000000, 1000000, 1000001, 686526, 999999, 1000000, 1000000, 894411, 341438, 308653, 1000000, 999998, 1000001, 1000000, 1000001, 999998, 935468, 1000000, 986883, 825943, 1000000, 1000000, 1000000, 1000000, 999999, 1000000, 1000000, 999999, 1000000, 334895, 999999, 224062, 971592, 1000000, 1000000, 1000000, 999999, 1000000, 834806, 878932, 999999, 557438, 999999, 1000000, 1000001, 999999, 428925, 1000000, 1000000, 999999, 451702, 1000000, 0, 999999, 999999, 125263, 1628348, 1000000, 1000000, 657724, 1000000, 999999, 999999, 780283, 160054, 586621, 999999, 1000001, 442267, 999999, 726985, 1000000, 59021, 999999, 336026, 1000000, 1000000, 584957, 999999, 1000000, 818519, 0, 38750, 799914, 999999, 1000000, 210763, 999999, 1000001, 695649, 1000000, 749938, 215352, 1000000, 995732, 1000000, 749938, 1000001, 979896, 897781, 0, 1000000, 0, 125263, 943318, 518715, 407365, 629592, 0]
theorem loads106 : cs106.get =
    load (fun i : Fin entries106.length => support (entries106.get i).1)
      (fun i => (entries106.get i).2) := by
  apply load_eq_of_sparse_packed base cs106 support code
    entries106 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node106 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 97 (insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 139 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs106 support demand
    entries106 ((insert 97 (insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 139 (insert 101 ∅)) : Finset (Fin 154)) 1000000 30 loads106
  decide +kernel
theorem node104 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 139 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 147 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 139 (insert 101 ∅)) : Finset (Fin 154))
    97 node105 node106
theorem node77 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 139 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 139 (insert 101 ∅)) : Finset (Fin 154))
    147 node103 node104
def entries101 : List (Fin 1589 × ℕ) := [(10, 5), (17, 6), (122, 21), (177, 17), (179, 25), (385, 19), (466, 37), (478, 11), (491, 1), (498, 8), (507, 36), (531, 14), (542, 36), (552, 31), (572, 14), (617, 11), (632, 35), (639, 7), (681, 11), (736, 30), (737, 3), (815, 36), (819, 5), (835, 9), (850, 8), (863, 17), (870, 41), (872, 17), (879, 15), (885, 30), (886, 19), (894, 3), (895, 2), (896, 1), (901, 8), (905, 9), (914, 22), (919, 10), (920, 4), (924, 16), (928, 22), (938, 4), (956, 1), (960, 8), (966, 22), (973, 31), (978, 45), (980, 18), (985, 21), (1030, 23), (1070, 9), (1082, 3), (1089, 45), (1099, 2), (1100, 10), (1139, 28), (1153, 29), (1159, 10), (1169, 24), (1173, 26), (1182, 21), (1188, 4), (1238, 9), (1261, 33), (1263, 33), (1281, 5), (1293, 2), (1342, 1), (1401, 3), (1489, 2), (1493, 4), (1552, 1), (1565, 1), (1566, 21), (1577, 6), (1580, 3)]
def cs101 : List ℕ := [51, 0, 19, 19, 19, 0, 7, 65, 56, 53, 0, 99, 100, 45, 48, 77, 100, 100, 100, 14, 100, 71, 68, 177, 100, 99, 98, 101, 43, 100, 177, 100, 78, 32, 99, 100, 100, 99, 100, 99, 92, 101, 64, 100, 98, 98, 101, 100, 90, 99, 100, 101, 99, 95, 26, 99, 100, 219, 100, 101, 100, 99, 98, 100, 91, 100, 99, 98, 99, 100, 100, 100, 98, 100, 50, 99, 12, 100, 99, 182, 87, 97, 99, 100, 101, 99, 47, 131, 99, 185, 98, 97, 100, 99, 92, 47, 99, 100, 100, 98, 0, 186, 99, 99, 46, 100, 100, 99, 80, 1, 100, 99, 100, 89, 99, 92, 100, 43, 99, 54, 94, 99, 26, 99, 99, 99, 31, 31, 61, 99, 100, 78, 99, 100, 67, 99, 57, 55, 100, 31, 73, 68, 121, 70, 90, 31, 91, 55, 52, 57, 80, 31, 91, 31]
theorem loads101 : cs101.get =
    load (fun i : Fin entries101.length => support (entries101.get i).1)
      (fun i => (entries101.get i).2) := by
  apply load_eq_of_sparse_packed base cs101 support code
    entries101 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node101 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 23 (insert 57 (insert 30 (insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs101 support demand
    entries101 ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 23 (insert 57 (insert 30 (insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅)))))))) : Finset (Fin 154)) 100 30 loads101
  decide +kernel
def entries102 : List (Fin 1589 × ℕ) := [(20, 7), (62, 24), (65, 12), (122, 43), (177, 1), (179, 28), (385, 9), (439, 1), (472, 4), (475, 14), (491, 29), (507, 31), (514, 5), (515, 28), (529, 10), (552, 17), (571, 2), (572, 17), (577, 20), (583, 26), (587, 3), (588, 5), (617, 16), (625, 4), (632, 28), (639, 1), (731, 13), (736, 9), (737, 18), (738, 2), (815, 30), (835, 5), (870, 57), (872, 11), (884, 1), (886, 39), (894, 10), (896, 10), (905, 4), (914, 10), (918, 13), (920, 27), (923, 6), (924, 4), (930, 21), (938, 7), (964, 9), (966, 4), (973, 30), (977, 5), (978, 28), (985, 37), (1030, 39), (1045, 20), (1082, 11), (1089, 43), (1099, 3), (1100, 5), (1139, 21), (1153, 24), (1159, 27), (1167, 8), (1169, 5), (1173, 17), (1182, 16), (1234, 10), (1261, 43), (1292, 17), (1374, 12), (1420, 3), (1489, 10), (1508, 3), (1551, 21), (1565, 5)]
def cs102 : List ℕ := [0, 0, 4, 21, 0, 17, 29, 4, 7, 67, 50, 100, 31, 73, 0, 60, 99, 100, 99, 43, 99, 92, 42, 0, 73, 99, 99, 100, 76, 74, 103, 100, 68, 13, 100, 77, 99, 99, 99, 101, 73, 99, 92, 99, 101, 99, 99, 99, 100, 99, 100, 99, 100, 58, 17, 99, 99, 185, 99, 70, 98, 99, 100, 99, 99, 100, 100, 100, 100, 99, 99, 98, 99, 100, 30, 99, 0, 78, 99, 149, 99, 99, 100, 90, 99, 100, 61, 153, 100, 141, 100, 100, 99, 101, 78, 72, 99, 100, 99, 99, 0, 153, 100, 100, 33, 100, 99, 100, 83, 9, 91, 100, 100, 83, 99, 97, 100, 20, 100, 69, 100, 97, 17, 100, 100, 60, 30, 30, 41, 99, 99, 82, 101, 100, 57, 80, 47, 63, 99, 30, 91, 53, 102, 81, 88, 30, 79, 43, 46, 47, 67, 30, 97, 30]
theorem loads102 : cs102.get =
    load (fun i : Fin entries102.length => support (entries102.get i).1)
      (fun i => (entries102.get i).2) := by
  apply load_eq_of_sparse_packed base cs102 support code
    entries102 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node102 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 23 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 30 (insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs102 support demand
    entries102 ((insert 23 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 57 (insert 30 (insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅))))))) : Finset (Fin 154)) 100 30 loads102
  decide +kernel
theorem node99 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 30 (insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 57 (insert 30 (insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅))))))) : Finset (Fin 154))
    23 node101 node102
def entries100 : List (Fin 1589 × ℕ) := [(35, 26), (62, 28), (122, 8), (177, 5), (179, 34), (203, 4), (206, 2), (385, 3), (439, 6), (466, 6), (475, 11), (479, 33), (484, 8), (507, 27), (514, 9), (531, 23), (541, 28), (572, 17), (588, 21), (617, 27), (625, 23), (629, 8), (639, 42), (730, 23), (731, 10), (737, 10), (815, 30), (855, 6), (858, 14), (870, 57), (871, 7), (886, 37), (893, 3), (896, 44), (904, 22), (920, 7), (921, 4), (937, 2), (938, 11), (949, 23), (950, 6), (956, 6), (966, 16), (973, 30), (978, 29), (980, 7), (984, 1), (985, 26), (1030, 42), (1031, 2), (1045, 19), (1089, 57), (1099, 7), (1139, 27), (1153, 16), (1159, 29), (1169, 1), (1171, 1), (1173, 35), (1182, 14), (1239, 13), (1261, 40), (1282, 8), (1293, 5), (1374, 4), (1379, 7), (1466, 9), (1493, 11), (1496, 2), (1503, 1), (1525, 9), (1577, 4)]
def cs100 : List ℕ := [6, 21, 30, 19, 33, 40, 18, 69, 39, 64, 27, 99, 52, 84, 32, 23, 99, 100, 99, 45, 100, 62, 71, 99, 100, 100, 100, 100, 31, 73, 172, 99, 89, 2, 99, 100, 100, 99, 67, 100, 99, 93, 52, 100, 101, 99, 100, 100, 81, 99, 99, 100, 65, 66, 36, 101, 99, 0, 101, 99, 101, 101, 100, 82, 99, 100, 100, 102, 100, 101, 100, 101, 100, 95, 37, 100, 1, 101, 100, 135, 101, 101, 78, 101, 89, 100, 66, 144, 100, 145, 100, 86, 100, 101, 84, 64, 100, 100, 101, 99, 4, 169, 100, 98, 63, 101, 102, 101, 90, 6, 80, 99, 100, 67, 102, 100, 100, 30, 99, 72, 101, 100, 36, 101, 100, 74, 30, 32, 48, 99, 101, 73, 100, 101, 60, 100, 66, 52, 101, 30, 93, 73, 102, 75, 91, 30, 80, 31, 45, 66, 71, 30, 89, 30]
theorem loads100 : cs100.get =
    load (fun i : Fin entries100.length => support (entries100.get i).1)
      (fun i => (entries100.get i).2) := by
  apply load_eq_of_sparse_packed base cs100 support code
    entries100 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node100 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 57 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 30 (insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs100 support demand
    entries100 ((insert 57 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 30 (insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅)))))) : Finset (Fin 154)) 100 30 loads100
  decide +kernel
theorem node97 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 30 (insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 30 (insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅)))))) : Finset (Fin 154))
    57 node99 node100
def entries98 : List (Fin 1589 × ℕ) := [(17, 20), (35, 8), (43, 110), (62, 177), (86, 196), (122, 164), (137, 38), (177, 3), (179, 143), (343, 48), (385, 116), (439, 1), (472, 229), (475, 418), (479, 261), (491, 167), (498, 65), (507, 199), (514, 154), (515, 256), (531, 1), (542, 274), (552, 35), (571, 103), (588, 19), (616, 3), (617, 196), (625, 107), (730, 126), (736, 16), (737, 184), (738, 54), (797, 125), (798, 42), (814, 129), (815, 38), (855, 139), (856, 162), (867, 57), (870, 198), (872, 206), (881, 160), (882, 49), (896, 204), (905, 399), (920, 356), (924, 66), (925, 121), (928, 7), (938, 47), (949, 170), (956, 72), (973, 298), (978, 284), (985, 340), (1030, 287), (1045, 98), (1070, 10), (1082, 156), (1089, 246), (1099, 64), (1139, 181), (1152, 86), (1153, 181), (1159, 220), (1167, 192), (1171, 185), (1173, 22), (1182, 301), (1188, 261), (1234, 19), (1261, 157), (1263, 107), (1292, 71), (1293, 117), (1342, 259), (1344, 85), (1374, 11), (1491, 9), (1508, 82), (1537, 38), (1566, 25), (1578, 21)]
def cs98 : List ℕ := [0, 0, 267, 438, 282, 418, 298, 549, 238, 376, 559, 1000, 1000, 450, 405, 438, 807, 1000, 1001, 280, 1000, 626, 190, 1000, 1001, 1000, 1001, 1001, 296, 264, 198, 1000, 857, 377, 1000, 1001, 1000, 1000, 633, 1000, 1000, 1001, 725, 1001, 1000, 1000, 999, 999, 1000, 1000, 1000, 1001, 1000, 498, 207, 1000, 1000, 1000, 1001, 999, 1000, 1002, 1000, 999, 1000, 1000, 1000, 1000, 1000, 1001, 1000, 1001, 1000, 1000, 399, 1000, 261, 1001, 1001, 1376, 1000, 1000, 869, 820, 852, 1000, 533, 1521, 999, 1087, 1000, 922, 1000, 999, 559, 580, 1002, 1000, 1000, 1000, 121, 1307, 999, 1000, 413, 1000, 1000, 1001, 783, 72, 872, 1001, 1001, 1001, 1000, 779, 1000, 301, 1001, 585, 1000, 1001, 207, 1000, 1001, 697, 298, 298, 911, 1001, 1001, 777, 1000, 1001, 504, 1001, 505, 588, 1000, 298, 764, 661, 1037, 785, 1000, 298, 962, 490, 599, 505, 780, 384, 1000, 298]
theorem loads98 : cs98.get =
    load (fun i : Fin entries98.length => support (entries98.get i).1)
      (fun i => (entries98.get i).2) := by
  apply load_eq_of_sparse_packed base cs98 support code
    entries98 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node98 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 30 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs98 support demand
    entries98 ((insert 30 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅))))) : Finset (Fin 154)) 1000 30 loads98
  decide +kernel
theorem node93 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 87 (insert 142 (insert 89 (insert 79 (insert 101 ∅))))) : Finset (Fin 154))
    30 node97 node98
def entries95 : List (Fin 1589 × ℕ) := [(17, 26), (35, 115), (62, 105), (122, 419), (135, 45), (137, 17), (179, 283), (203, 138), (385, 161), (466, 246), (472, 31), (475, 148), (479, 234), (491, 100), (498, 56), (507, 390), (514, 85), (515, 171), (531, 105), (541, 144), (542, 52), (552, 7), (572, 92), (588, 104), (616, 98), (617, 214), (625, 193), (632, 99), (731, 205), (738, 105), (739, 229), (813, 255), (815, 32), (835, 20), (850, 16), (855, 269), (870, 475), (872, 32), (882, 46), (886, 234), (894, 170), (896, 193), (905, 91), (920, 259), (923, 48), (924, 28), (930, 263), (938, 15), (949, 232), (950, 146), (966, 103), (973, 487), (978, 202), (980, 45), (985, 184), (994, 126), (1030, 231), (1056, 179), (1070, 329), (1075, 30), (1089, 176), (1113, 158), (1139, 262), (1153, 262), (1167, 282), (1188, 33), (1235, 230), (1263, 128), (1267, 30), (1292, 136), (1293, 225), (1317, 251), (1372, 39), (1379, 35), (1482, 113), (1491, 175), (1527, 86), (1577, 31)]
def cs95 : List ℕ := [246, 0, 31, 190, 234, 520, 131, 511, 325, 495, 427, 1000, 999, 422, 227, 678, 1000, 1001, 999, 197, 1000, 1001, 387, 998, 999, 1000, 1000, 1000, 642, 610, 1000, 1000, 893, 408, 1000, 998, 999, 1000, 737, 1000, 999, 824, 533, 794, 1001, 1000, 1000, 1000, 940, 1001, 999, 1000, 895, 484, 0, 999, 999, 999, 999, 1000, 1001, 1000, 1000, 1000, 869, 1000, 1000, 1000, 1000, 1001, 999, 1000, 1000, 1000, 408, 1000, 72, 806, 1000, 1398, 1000, 1000, 742, 912, 923, 1000, 638, 184, 1000, 1248, 1000, 873, 1001, 1002, 748, 650, 787, 999, 1000, 1001, 0, 1728, 1000, 1000, 543, 1001, 1000, 1001, 841, 0, 1001, 1000, 1000, 0, 1000, 794, 1000, 103, 1000, 718, 1000, 1000, 387, 1001, 1000, 940, 487, 487, 550, 1000, 1001, 1000, 1621, 1000, 1000, 967, 487, 799, 1000, 487, 501, 816, 1124, 1000, 1000, 487, 645, 769, 487, 487, 1000, 738, 1000, 487]
theorem loads95 : cs95.get =
    load (fun i : Fin entries95.length => support (entries95.get i).1)
      (fun i => (entries95.get i).2) := by
  apply load_eq_of_sparse_packed base cs95 support code
    entries95 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node95 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 87 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 132 (insert 142 (insert 89 (insert 79 (insert 101 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs95 support demand
    entries95 ((insert 87 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 132 (insert 142 (insert 89 (insert 79 (insert 101 ∅))))) : Finset (Fin 154)) 1000 30 loads95
  decide +kernel
def entries96 : List (Fin 1589 × ℕ) := [(17, 1), (35, 28), (43, 4), (62, 1), (122, 33), (137, 8), (179, 22), (203, 9), (386, 1), (421, 3), (439, 14), (466, 10), (472, 32), (475, 21), (479, 5), (491, 15), (507, 13), (515, 7), (531, 16), (542, 13), (588, 21), (616, 6), (617, 37), (632, 2), (680, 4), (730, 24), (731, 9), (739, 2), (813, 23), (855, 12), (863, 11), (870, 46), (882, 6), (886, 16), (894, 21), (896, 14), (905, 22), (920, 15), (924, 22), (928, 2), (929, 8), (930, 5), (949, 26), (963, 13), (966, 3), (973, 18), (978, 31), (980, 28), (985, 2), (1005, 9), (1030, 8), (1048, 38), (1055, 15), (1076, 2), (1085, 43), (1089, 21), (1113, 10), (1160, 28), (1167, 19), (1169, 30), (1171, 5), (1246, 11), (1293, 29), (1308, 26), (1379, 19), (1481, 2), (1491, 17), (1499, 11), (1527, 3), (1578, 8), (1580, 27)]
def cs96 : List ℕ := [10, 0, 32, 22, 40, 40, 27, 82, 29, 25, 34, 100, 43, 73, 52, 64, 100, 101, 100, 1, 99, 100, 43, 99, 101, 101, 99, 100, 44, 58, 100, 100, 94, 54, 100, 99, 100, 100, 56, 100, 100, 100, 79, 87, 100, 100, 99, 99, 99, 100, 101, 100, 60, 80, 16, 101, 100, 98, 101, 96, 100, 101, 100, 101, 52, 100, 99, 100, 101, 99, 99, 101, 101, 93, 54, 99, 0, 99, 100, 174, 99, 100, 98, 102, 98, 100, 92, 7, 100, 192, 101, 60, 99, 101, 82, 63, 92, 101, 101, 100, 0, 213, 101, 98, 80, 91, 101, 100, 100, 13, 100, 101, 101, 56, 100, 78, 100, 3, 25, 64, 101, 39, 55, 100, 100, 100, 18, 33, 37, 15, 100, 75, 18, 101, 55, 75, 61, 82, 100, 18, 28, 23, 90, 46, 57, 18, 33, 67, 18, 23, 18, 18, 18, 46]
theorem loads96 : cs96.get =
    load (fun i : Fin entries96.length => support (entries96.get i).1)
      (fun i => (entries96.get i).2) := by
  apply load_eq_of_sparse_packed base cs96 support code
    entries96 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node96 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 132 (insert 87 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 142 (insert 89 (insert 79 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs96 support demand
    entries96 ((insert 132 (insert 87 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))))) : Finset (Fin 154)) ((insert 142 (insert 89 (insert 79 (insert 101 ∅)))) : Finset (Fin 154)) 100 30 loads96
  decide +kernel
theorem node94 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 87 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 142 (insert 89 (insert 79 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 87 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 142 (insert 89 (insert 79 (insert 101 ∅)))) : Finset (Fin 154))
    132 node95 node96
theorem node91 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 142 (insert 89 (insert 79 (insert 101 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 142 (insert 89 (insert 79 (insert 101 ∅)))) : Finset (Fin 154))
    87 node93 node94
def entries92 : List (Fin 1589 × ℕ) := [(62, 168), (86, 45), (116, 199), (120, 58), (122, 282), (179, 375), (203, 47), (387, 9), (439, 49), (466, 165), (475, 283), (479, 241), (483, 18), (484, 29), (507, 231), (531, 144), (542, 303), (551, 116), (552, 4), (572, 186), (588, 104), (617, 173), (625, 125), (629, 6), (631, 85), (632, 41), (730, 317), (736, 4), (737, 48), (738, 76), (813, 244), (815, 232), (863, 27), (867, 104), (870, 372), (872, 193), (885, 48), (886, 315), (894, 2), (895, 132), (896, 266), (905, 68), (906, 9), (914, 206), (920, 406), (924, 84), (928, 121), (937, 40), (938, 144), (949, 92), (958, 96), (964, 129), (973, 27), (978, 583), (980, 55), (985, 340), (1006, 77), (1018, 228), (1030, 417), (1060, 50), (1068, 78), (1070, 235), (1075, 313), (1082, 544), (1085, 117), (1090, 483), (1113, 34), (1138, 157), (1160, 295), (1221, 45), (1234, 25), (1261, 412), (1275, 126), (1292, 147), (1379, 53), (1489, 53), (1491, 96), (1498, 136), (1508, 64), (1525, 37), (1577, 83), (1578, 7), (1580, 56)]
def cs92 : List ℕ := [210, 0, 82, 283, 304, 375, 90, 551, 0, 463, 348, 1000, 823, 561, 449, 981, 1000, 1000, 1000, 354, 1000, 999, 479, 1000, 999, 999, 1000, 999, 664, 713, 1000, 999, 1000, 0, 999, 1000, 999, 1001, 999, 999, 1000, 873, 367, 1000, 999, 1000, 1000, 1000, 999, 999, 1000, 999, 956, 583, 45, 1000, 999, 1000, 1000, 893, 999, 999, 1000, 999, 686, 1000, 1000, 999, 954, 999, 999, 1000, 999, 808, 77, 1000, 0, 1000, 999, 1567, 1000, 1000, 1000, 1000, 1000, 1000, 713, 1000, 999, 1653, 999, 1000, 1000, 1001, 953, 495, 1000, 1000, 999, 1000, 9, 1910, 1001, 1000, 408, 1000, 1001, 1000, 960, 129, 1000, 1000, 1000, 830, 999, 976, 1001, 96, 821, 444, 1001, 1000, 34, 1000, 1000, 159, 27, 27, 514, 1000, 1000, 444, 1000, 1000, 422, 999, 27, 418, 1000, 510, 990, 326, 27, 448, 421, 27, 605, 510, 184, 27, 153, 153, 27, 448]
theorem loads92 : cs92.get =
    load (fun i : Fin entries92.length => support (entries92.get i).1)
      (fun i => (entries92.get i).2) := by
  apply load_eq_of_sparse_packed base cs92 support code
    entries92 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node92 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 142 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 89 (insert 79 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs92 support demand
    entries92 ((insert 142 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 89 (insert 79 (insert 101 ∅))) : Finset (Fin 154)) 1000 30 loads92
  decide +kernel
theorem node85 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 89 (insert 79 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 89 (insert 79 (insert 101 ∅))) : Finset (Fin 154))
    142 node91 node92
def entries87 : List (Fin 1589 × ℕ) := [(17, 41), (62, 22), (70, 1), (86, 10), (116, 8), (122, 9), (177, 13), (343, 14), (439, 15), (475, 17), (479, 41), (491, 13), (507, 11), (530, 8), (531, 25), (552, 4), (577, 1), (583, 27), (585, 7), (588, 20), (617, 30), (632, 17), (672, 2), (673, 1), (730, 14), (731, 1), (737, 2), (738, 7), (813, 7), (815, 10), (844, 9), (850, 5), (858, 3), (863, 5), (886, 31), (905, 1), (920, 46), (923, 7), (924, 15), (930, 11), (938, 9), (948, 2), (949, 2), (950, 13), (956, 18), (973, 35), (975, 15), (985, 31), (994, 3), (1005, 4), (1006, 4), (1030, 39), (1045, 19), (1056, 22), (1082, 9), (1089, 4), (1128, 8), (1153, 11), (1167, 7), (1169, 6), (1171, 22), (1182, 26), (1227, 2), (1234, 4), (1238, 45), (1245, 5), (1261, 24), (1275, 35), (1308, 18), (1342, 14), (1374, 8), (1469, 10), (1489, 15), (1491, 14), (1580, 4), (1582, 24), (1588, 1)]
def cs87 : List ℕ := [54, 0, 45, 87, 45, 24, 40, 99, 86, 38, 25, 100, 100, 100, 5, 59, 100, 99, 99, 22, 99, 100, 33, 100, 99, 100, 99, 99, 27, 31, 100, 285, 84, 47, 100, 100, 100, 99, 94, 100, 100, 99, 79, 83, 100, 100, 100, 100, 65, 100, 100, 101, 99, 13, 22, 99, 101, 100, 100, 100, 99, 101, 67, 101, 95, 100, 100, 99, 56, 101, 99, 99, 74, 98, 42, 99, 0, 65, 100, 91, 100, 99, 99, 100, 100, 100, 69, 99, 101, 17, 100, 85, 99, 100, 86, 73, 100, 99, 99, 100, 0, 131, 100, 98, 53, 100, 99, 100, 60, 18, 86, 100, 100, 76, 99, 63, 99, 26, 100, 74, 100, 100, 30, 100, 100, 77, 35, 35, 48, 100, 100, 87, 100, 100, 75, 100, 57, 67, 100, 35, 85, 57, 100, 89, 73, 35, 92, 48, 61, 65, 96, 70, 72, 70]
theorem loads87 : cs87.get =
    load (fun i : Fin entries87.length => support (entries87.get i).1)
      (fun i => (entries87.get i).2) := by
  apply load_eq_of_sparse_packed base cs87 support code
    entries87 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node87 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 89 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 79 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs87 support demand
    entries87 ((insert 89 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 31 (insert 79 (insert 101 ∅))) : Finset (Fin 154)) 100 30 loads87
  decide +kernel
def entries89 : List (Fin 1589 × ℕ) := [(116, 21), (122, 25), (137, 9), (179, 1), (414, 6), (466, 27), (472, 26), (475, 4), (491, 8), (498, 14), (507, 14), (542, 20), (571, 14), (572, 3), (587, 14), (588, 47), (617, 41), (625, 46), (630, 6), (632, 42), (736, 3), (813, 3), (815, 8), (835, 14), (846, 13), (850, 48), (855, 7), (858, 13), (863, 1), (870, 2), (872, 14), (885, 2), (886, 35), (890, 3), (896, 29), (898, 12), (905, 11), (906, 22), (920, 20), (924, 9), (949, 33), (950, 4), (973, 33), (975, 20), (980, 5), (985, 27), (1005, 6), (1006, 13), (1020, 1), (1030, 11), (1045, 17), (1056, 6), (1082, 11), (1089, 16), (1128, 3), (1153, 16), (1167, 17), (1171, 20), (1173, 4), (1182, 28), (1188, 7), (1225, 1), (1261, 22), (1275, 34), (1308, 17), (1401, 1), (1491, 3), (1501, 1), (1517, 7), (1556, 7), (1565, 1), (1577, 24), (1588, 2)]
def cs89 : List ℕ := [27, 13, 26, 52, 0, 7, 52, 66, 14, 15, 0, 92, 100, 14, 45, 73, 99, 100, 101, 17, 100, 78, 76, 100, 100, 100, 99, 100, 93, 49, 99, 20, 100, 37, 100, 86, 100, 234, 23, 100, 99, 74, 101, 78, 100, 100, 100, 100, 35, 100, 100, 100, 101, 34, 24, 100, 99, 101, 100, 29, 101, 49, 83, 100, 95, 100, 100, 100, 81, 100, 101, 100, 76, 100, 54, 100, 8, 72, 100, 57, 99, 101, 47, 99, 100, 99, 78, 101, 100, 37, 99, 86, 100, 100, 100, 45, 100, 100, 101, 100, 22, 109, 99, 100, 65, 101, 100, 93, 85, 0, 100, 100, 66, 63, 101, 44, 99, 28, 100, 44, 75, 100, 27, 100, 100, 92, 33, 33, 39, 99, 101, 61, 100, 101, 77, 100, 57, 67, 101, 33, 98, 57, 101, 86, 80, 33, 96, 50, 61, 60, 95, 67, 77, 67]
theorem loads89 : cs89.get =
    load (fun i : Fin entries89.length => support (entries89.get i).1)
      (fun i => (entries89.get i).2) := by
  apply load_eq_of_sparse_packed base cs89 support code
    entries89 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node89 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 31 (insert 89 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 79 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs89 support demand
    entries89 ((insert 31 (insert 89 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))))) : Finset (Fin 154)) ((insert 37 (insert 79 (insert 101 ∅))) : Finset (Fin 154)) 100 30 loads89
  decide +kernel
def entries90 : List (Fin 1589 × ℕ) := [(20, 45), (122, 25), (137, 6), (179, 10), (344, 1), (421, 12), (439, 12), (466, 44), (498, 26), (507, 31), (515, 9), (542, 24), (551, 9), (571, 17), (572, 1), (617, 8), (625, 16), (639, 2), (710, 7), (731, 22), (737, 27), (739, 1), (741, 32), (813, 15), (815, 17), (844, 4), (846, 13), (863, 13), (870, 15), (882, 18), (886, 11), (894, 10), (896, 35), (905, 20), (906, 7), (920, 18), (924, 16), (930, 28), (938, 6), (944, 19), (950, 9), (958, 3), (973, 30), (975, 24), (985, 30), (994, 1), (1005, 16), (1006, 5), (1018, 3), (1020, 18), (1030, 19), (1045, 16), (1056, 16), (1075, 1), (1089, 7), (1113, 4), (1152, 8), (1167, 23), (1171, 34), (1182, 6), (1246, 9), (1261, 9), (1275, 45), (1292, 15), (1293, 11), (1342, 2), (1348, 12), (1469, 2), (1491, 3), (1498, 11), (1525, 4), (1588, 10)]
def cs90 : List ℕ := [48, 13, 4, 45, 0, 26, 0, 65, 71, 48, 28, 83, 100, 45, 24, 66, 100, 100, 61, 18, 100, 70, 10, 100, 100, 100, 100, 99, 55, 55, 100, 18, 65, 62, 99, 52, 99, 0, 49, 100, 84, 84, 54, 99, 99, 99, 99, 100, 82, 99, 100, 99, 48, 36, 34, 100, 98, 99, 99, 48, 99, 99, 99, 101, 100, 90, 99, 99, 78, 99, 100, 99, 100, 100, 63, 100, 0, 80, 99, 73, 100, 99, 94, 99, 57, 98, 50, 99, 99, 45, 100, 100, 100, 100, 85, 58, 98, 99, 100, 100, 7, 141, 101, 100, 42, 100, 100, 99, 55, 0, 99, 99, 100, 67, 100, 49, 100, 28, 99, 49, 100, 99, 39, 100, 100, 93, 30, 30, 33, 100, 100, 72, 100, 100, 91, 100, 64, 70, 100, 30, 68, 64, 100, 83, 72, 30, 74, 53, 36, 64, 81, 83, 36, 75]
theorem loads90 : cs90.get =
    load (fun i : Fin entries90.length => support (entries90.get i).1)
      (fun i => (entries90.get i).2) := by
  apply load_eq_of_sparse_packed base cs90 support code
    entries90 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node90 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 31 (insert 89 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 79 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs90 support demand
    entries90 ((insert 37 (insert 31 (insert 89 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))))) : Finset (Fin 154)) ((insert 79 (insert 101 ∅)) : Finset (Fin 154)) 100 30 loads90
  decide +kernel
theorem node88 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 31 (insert 89 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 79 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 31 (insert 89 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))))) : Finset (Fin 154)) ((insert 79 (insert 101 ∅)) : Finset (Fin 154))
    37 node89 node90
theorem node86 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 89 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 79 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 89 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 79 (insert 101 ∅)) : Finset (Fin 154))
    31 node87 node88
theorem node79 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 79 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 79 (insert 101 ∅)) : Finset (Fin 154))
    89 node85 node86
def entries83 : List (Fin 1589 × ℕ) := [(17, 24), (35, 25), (62, 10), (179, 12), (438, 1), (439, 11), (466, 43), (472, 25), (475, 12), (479, 13), (484, 8), (491, 26), (507, 21), (515, 1), (542, 1), (588, 12), (616, 3), (617, 40), (624, 13), (625, 14), (630, 3), (631, 1), (737, 6), (814, 2), (815, 31), (833, 4), (835, 12), (848, 3), (850, 16), (856, 9), (868, 1), (872, 22), (881, 10), (886, 18), (896, 23), (905, 34), (918, 26), (924, 22), (928, 1), (938, 18), (944, 13), (948, 2), (949, 11), (950, 4), (966, 7), (973, 30), (975, 14), (978, 49), (980, 20), (985, 7), (988, 1), (1006, 8), (1018, 2), (1020, 40), (1030, 12), (1031, 1), (1045, 16), (1056, 6), (1075, 11), (1082, 1), (1100, 6), (1107, 3), (1108, 48), (1139, 16), (1171, 36), (1173, 5), (1182, 21), (1234, 40), (1240, 5), (1261, 30), (1263, 6), (1267, 7), (1275, 22), (1293, 2), (1308, 4), (1491, 15), (1508, 5), (1517, 5), (1566, 5), (1580, 16), (1582, 6)]
def cs83 : List ℕ := [43, 0, 28, 58, 29, 48, 37, 100, 55, 31, 8, 100, 100, 97, 17, 31, 101, 100, 101, 10, 99, 60, 29, 99, 101, 99, 101, 98, 39, 46, 100, 99, 100, 36, 101, 100, 100, 99, 73, 101, 99, 99, 63, 100, 100, 100, 98, 98, 57, 101, 101, 99, 85, 54, 44, 100, 99, 99, 99, 88, 100, 81, 100, 99, 100, 100, 100, 99, 65, 99, 100, 100, 99, 99, 49, 100, 0, 92, 99, 0, 100, 100, 69, 99, 75, 100, 85, 98, 100, 100, 100, 100, 99, 231, 92, 32, 99, 99, 100, 100, 0, 175, 99, 101, 81, 99, 100, 100, 90, 0, 179, 100, 100, 83, 100, 63, 100, 41, 97, 42, 99, 99, 41, 101, 100, 100, 30, 31, 53, 100, 100, 42, 100, 100, 68, 100, 71, 58, 100, 30, 85, 76, 100, 100, 61, 30, 99, 78, 51, 71, 89, 52, 51, 52]
theorem loads83 : cs83.get =
    load (fun i : Fin entries83.length => support (entries83.get i).1)
      (fun i => (entries83.get i).2) := by
  apply load_eq_of_sparse_packed base cs83 support code
    entries83 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node83 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 79 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 110 (insert 101 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs83 support demand
    entries83 ((insert 79 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 93 (insert 110 (insert 101 ∅))) : Finset (Fin 154)) 100 30 loads83
  decide +kernel
def entries84 : List (Fin 1589 × ℕ) := [(17, 39), (35, 14), (62, 4), (177, 8), (179, 30), (466, 20), (472, 10), (475, 7), (479, 21), (484, 34), (491, 33), (507, 18), (542, 11), (571, 23), (616, 1), (617, 16), (625, 25), (632, 7), (639, 1), (672, 12), (680, 2), (730, 9), (737, 20), (815, 21), (842, 23), (844, 6), (856, 26), (863, 4), (871, 2), (872, 18), (886, 17), (893, 6), (895, 23), (905, 26), (906, 21), (924, 8), (929, 2), (938, 17), (944, 14), (948, 11), (964, 4), (966, 1), (973, 17), (975, 27), (978, 46), (980, 26), (984, 5), (985, 5), (1006, 6), (1018, 13), (1030, 42), (1056, 10), (1068, 4), (1070, 3), (1075, 4), (1097, 8), (1104, 4), (1108, 43), (1113, 24), (1139, 22), (1152, 25), (1171, 27), (1182, 32), (1188, 11), (1246, 3), (1275, 16), (1280, 1), (1342, 30), (1471, 11), (1489, 6), (1491, 6), (1517, 1), (1528, 1), (1578, 11), (1580, 10), (1582, 7), (1588, 15)]
def cs84 : List ℕ := [27, 1, 10, 53, 42, 82, 52, 79, 53, 26, 18, 100, 101, 87, 32, 24, 100, 99, 101, 27, 100, 90, 38, 100, 100, 100, 100, 99, 25, 59, 99, 100, 74, 33, 100, 100, 100, 100, 85, 100, 100, 101, 65, 96, 99, 101, 101, 99, 91, 100, 101, 100, 75, 51, 27, 100, 99, 100, 100, 100, 100, 100, 99, 100, 82, 100, 100, 100, 78, 100, 100, 100, 99, 86, 34, 100, 11, 99, 100, 0, 100, 100, 54, 77, 98, 100, 66, 100, 101, 94, 99, 100, 100, 0, 73, 60, 100, 100, 100, 99, 21, 186, 100, 99, 47, 100, 100, 100, 57, 4, 148, 99, 72, 101, 99, 85, 100, 47, 71, 63, 100, 100, 52, 100, 100, 76, 18, 17, 69, 100, 101, 59, 100, 100, 77, 100, 45, 33, 100, 17, 100, 48, 59, 101, 85, 17, 100, 60, 53, 44, 87, 58, 49, 33]
theorem loads84 : cs84.get =
    load (fun i : Fin entries84.length => support (entries84.get i).1)
      (fun i => (entries84.get i).2) := by
  apply load_eq_of_sparse_packed base cs84 support code
    entries84 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node84 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 79 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 110 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs84 support demand
    entries84 ((insert 93 (insert 79 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))))) : Finset (Fin 154)) ((insert 110 (insert 101 ∅)) : Finset (Fin 154)) 100 30 loads84
  decide +kernel
theorem node81 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 79 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 110 (insert 101 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 79 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 110 (insert 101 ∅)) : Finset (Fin 154))
    93 node83 node84
def entries82 : List (Fin 1589 × ℕ) := [(17, 297), (35, 81), (43, 85), (62, 11), (179, 164), (439, 57), (466, 329), (472, 154), (475, 158), (479, 198), (485, 61), (507, 93), (515, 65), (542, 118), (552, 159), (571, 166), (572, 73), (588, 31), (617, 157), (625, 98), (632, 10), (639, 96), (737, 149), (742, 109), (813, 119), (835, 86), (850, 321), (856, 54), (863, 170), (869, 81), (870, 47), (872, 154), (886, 175), (895, 48), (896, 248), (905, 142), (906, 108), (918, 35), (920, 191), (924, 115), (930, 126), (944, 135), (949, 206), (964, 10), (966, 217), (980, 31), (985, 418), (994, 286), (1005, 113), (1020, 204), (1030, 325), (1031, 34), (1053, 1), (1056, 256), (1089, 227), (1113, 65), (1138, 54), (1139, 315), (1152, 249), (1171, 201), (1182, 136), (1188, 197), (1221, 72), (1261, 94), (1263, 5), (1275, 382), (1342, 211), (1471, 27), (1481, 108), (1489, 78), (1491, 201), (1517, 169), (1567, 59), (1578, 144), (1580, 104), (1588, 168)]
def cs82 : List ℕ := [401, 0, 226, 776, 446, 268, 398, 1001, 383, 274, 209, 1000, 1000, 647, 451, 504, 1000, 1000, 1000, 250, 1001, 854, 195, 1001, 1001, 1001, 1000, 1001, 157, 507, 1000, 1001, 828, 487, 1001, 1001, 1000, 1000, 649, 1001, 1001, 806, 647, 1001, 1000, 1001, 1001, 999, 631, 1001, 1000, 1001, 643, 0, 273, 1000, 1001, 1000, 999, 980, 1001, 1000, 1001, 1000, 997, 789, 1000, 1001, 607, 999, 1001, 1001, 1001, 889, 487, 1000, 197, 847, 1001, 465, 999, 1000, 1002, 1001, 858, 1000, 444, 1001, 1000, 491, 1001, 531, 1000, 1000, 715, 359, 1002, 1002, 1001, 1001, 108, 1364, 1000, 1001, 358, 1000, 1002, 970, 565, 10, 0, 1001, 890, 564, 1001, 661, 1001, 488, 619, 325, 991, 1000, 266, 1000, 1002, 518, 0, 34, 878, 1001, 1001, 325, 1000, 1002, 799, 1001, 201, 34, 1001, 0, 1001, 201, 823, 631, 1001, 0, 402, 0, 190, 201, 833, 631, 136, 382]
theorem loads82 : cs82.get =
    load (fun i : Fin entries82.length => support (entries82.get i).1)
      (fun i => (entries82.get i).2) := by
  apply load_eq_of_sparse_packed base cs82 support code
    entries82 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node82 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 110 (insert 79 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 101 ∅) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs82 support demand
    entries82 ((insert 110 (insert 79 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))))) : Finset (Fin 154)) ((insert 101 ∅) : Finset (Fin 154)) 1000 30 loads82
  decide +kernel
theorem node80 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 79 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 101 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 79 (insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 101 ∅) : Finset (Fin 154))
    110 node81 node82
theorem node78 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 101 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 139 (insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 101 ∅) : Finset (Fin 154))
    79 node79 node80
theorem node76 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 101 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 53 (insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 101 ∅) : Finset (Fin 154))
    139 node77 node78
theorem node19 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 101 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 101 ∅) : Finset (Fin 154))
    53 node75 node76
#print axioms node19
end OmissionResidualCover
