import ResidualCoverProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries213 : List (Fin 1589 × ℕ) := [(17, 15), (30, 49), (35, 14), (77, 22), (179, 22), (205, 12), (386, 17), (421, 4), (431, 32), (466, 50), (479, 36), (491, 34), (496, 6), (507, 51), (550, 4), (551, 11), (552, 7), (616, 8), (617, 27), (623, 14), (629, 5), (632, 27), (639, 15), (640, 18), (672, 20), (681, 32), (717, 26), (730, 6), (798, 4), (813, 8), (815, 14), (833, 5), (835, 11), (844, 6), (850, 27), (867, 1), (872, 20), (884, 3), (893, 4), (895, 6), (896, 7), (913, 2), (916, 8), (918, 6), (921, 86), (925, 38), (930, 7), (939, 14), (952, 16), (968, 25), (978, 53), (985, 5), (1005, 17), (1006, 2), (1009, 23), (1045, 21), (1068, 31), (1070, 17), (1104, 17), (1114, 13), (1137, 24), (1148, 10), (1149, 10), (1152, 2), (1173, 24), (1182, 27), (1235, 4), (1236, 8), (1241, 25), (1246, 13), (1258, 17), (1267, 16), (1297, 14), (1308, 9), (1372, 2), (1374, 21), (1379, 2), (1493, 4), (1498, 4), (1561, 12), (1588, 12)]
def cs213 : List ℕ := [64, 0, 0, 42, 44, 75, 34, 100, 84, 51, 25, 92, 101, 100, 22, 30, 67, 101, 100, 0, 101, 99, 26, 100, 101, 100, 100, 100, 52, 70, 100, 244, 101, 6, 100, 99, 100, 102, 96, 100, 96, 81, 101, 99, 250, 101, 99, 100, 41, 101, 100, 83, 101, 100, 24, 100, 101, 99, 100, 89, 100, 100, 101, 100, 86, 101, 99, 99, 101, 99, 98, 259, 100, 100, 49, 187, 2, 100, 99, 100, 99, 100, 49, 286, 100, 170, 100, 99, 100, 100, 99, 100, 100, 99, 73, 82, 99, 99, 100, 99, 261, 100, 99, 81, 100, 57, 100, 94, 244, 37, 100, 99, 99, 100, 100, 0, 100, 27, 99, 17, 100, 100, 99, 83, 100, 93, 0, 0, 52, 99, 48, 34, 100, 100, 100, 99, 34, 86, 100, 96, 78, 51, 100, 56, 68, 0, 100, 34, 100, 61, 66, 2, 56, 39]
theorem loads213 : cs213.get =
    load (fun i : Fin entries213.length => support (entries213.get i).1)
      (fun i => (entries213.get i).2) := by
  apply load_eq_of_sparse_packed base cs213 support code
    entries213 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node213 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 31 (insert 44 (insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs213 support demand
    entries213 ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 31 (insert 44 (insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅)))))))) : Finset (Fin 154)) 100 30 loads213
  decide +kernel
def entries214 : List (Fin 1589 × ℕ) := [(20, 83), (72, 57), (77, 186), (179, 301), (344, 148), (398, 12), (421, 186), (431, 399), (466, 312), (472, 267), (491, 169), (498, 169), (507, 192), (542, 18), (571, 64), (572, 33), (587, 109), (588, 238), (617, 366), (622, 314), (625, 183), (629, 267), (632, 39), (639, 162), (640, 105), (672, 79), (680, 5), (681, 223), (730, 117), (762, 228), (798, 119), (800, 43), (813, 83), (815, 252), (833, 60), (850, 97), (856, 1), (872, 367), (894, 101), (896, 305), (906, 461), (921, 195), (925, 462), (939, 441), (952, 58), (968, 213), (970, 34), (978, 352), (985, 314), (1005, 256), (1006, 66), (1009, 185), (1045, 243), (1068, 385), (1070, 116), (1086, 2), (1090, 122), (1104, 82), (1114, 164), (1137, 338), (1139, 6), (1152, 173), (1173, 119), (1182, 366), (1219, 344), (1221, 77), (1234, 42), (1235, 56), (1241, 78), (1246, 35), (1258, 76), (1261, 133), (1297, 218), (1556, 38), (1577, 80), (1588, 169)]
def cs214 : List ℕ := [389, 344, 344, 524, 0, 78, 249, 1000, 252, 192, 243, 982, 1000, 450, 341, 80, 1000, 876, 1000, 97, 1000, 406, 648, 1000, 1000, 635, 1000, 999, 740, 690, 1000, 195, 1001, 0, 1001, 999, 1000, 999, 849, 1000, 861, 999, 1000, 999, 1616, 1001, 1000, 1000, 495, 1000, 1000, 1000, 801, 1000, 196, 1000, 1001, 999, 1000, 267, 1000, 797, 1000, 1001, 955, 704, 1001, 1000, 1001, 1000, 899, 2293, 941, 1000, 370, 1829, 0, 999, 1001, 1000, 999, 999, 734, 3063, 1000, 1880, 999, 999, 1000, 778, 1001, 1000, 999, 1000, 1000, 707, 999, 999, 1001, 1000, 2546, 999, 1001, 556, 1000, 791, 999, 979, 2549, 213, 999, 1000, 999, 966, 1000, 122, 999, 400, 1000, 82, 1000, 1000, 1001, 999, 999, 708, 0, 0, 537, 999, 683, 338, 999, 1000, 999, 999, 119, 966, 1000, 922, 920, 235, 1000, 329, 617, 0, 781, 460, 820, 501, 668, 173, 442, 296]
theorem loads214 : cs214.get =
    load (fun i : Fin entries214.length => support (entries214.get i).1)
      (fun i => (entries214.get i).2) := by
  apply load_eq_of_sparse_packed base cs214 support code
    entries214 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node214 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 31 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 44 (insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs214 support demand
    entries214 ((insert 31 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 44 (insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)) 1000 30 loads214
  decide +kernel
theorem node209 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 44 (insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 44 (insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154))
    31 node213 node214
def entries211 : List (Fin 1589 × ℕ) := [(13, 9), (20, 197), (46, 89), (65, 28), (72, 338), (77, 86), (315, 47), (361, 52), (421, 128), (431, 400), (466, 585), (478, 72), (479, 182), (491, 109), (507, 283), (530, 185), (569, 136), (584, 50), (588, 467), (616, 282), (617, 141), (618, 46), (640, 156), (673, 106), (692, 172), (762, 358), (798, 150), (815, 299), (818, 31), (847, 5), (850, 216), (868, 8), (870, 62), (882, 196), (884, 125), (906, 717), (913, 86), (925, 221), (930, 30), (939, 502), (952, 123), (968, 145), (973, 206), (978, 347), (984, 35), (985, 212), (1005, 199), (1009, 36), (1021, 37), (1045, 78), (1068, 326), (1070, 13), (1078, 18), (1090, 67), (1114, 321), (1123, 97), (1137, 297), (1149, 97), (1152, 223), (1153, 38), (1171, 108), (1182, 467), (1188, 127), (1217, 44), (1228, 11), (1234, 257), (1258, 103), (1261, 194), (1263, 14), (1308, 89), (1310, 108), (1379, 122), (1392, 134), (1400, 141), (1420, 138), (1469, 27), (1496, 29), (1503, 13), (1580, 103), (1588, 54)]
def cs211 : List ℕ := [629, 0, 58, 413, 357, 44, 198, 1000, 211, 311, 583, 800, 1000, 485, 616, 196, 905, 911, 1000, 0, 1000, 547, 467, 1000, 1000, 999, 1000, 999, 831, 372, 1001, 1000, 1000, 108, 999, 999, 999, 1000, 711, 1000, 825, 1001, 897, 999, 85, 1000, 999, 999, 584, 999, 1001, 999, 1000, 999, 108, 1001, 1000, 999, 2151, 815, 1000, 1000, 1000, 1000, 999, 999, 999, 1000, 1000, 1000, 891, 2518, 1000, 999, 322, 1911, 140, 999, 999, 1000, 999, 999, 909, 2943, 999, 1321, 999, 998, 1000, 1000, 999, 999, 999, 1000, 1000, 686, 666, 1000, 1000, 1000, 2513, 999, 999, 429, 768, 485, 1000, 908, 2434, 145, 1000, 998, 1000, 975, 999, 78, 1000, 467, 999, 206, 1000, 999, 999, 846, 999, 781, 206, 303, 756, 1000, 847, 503, 1000, 998, 951, 999, 411, 907, 999, 999, 1000, 424, 999, 570, 759, 206, 889, 581, 800, 732, 781, 429, 814, 217]
theorem loads211 : cs211.get =
    load (fun i : Fin entries211.length => support (entries211.get i).1)
      (fun i => (entries211.get i).2) := by
  apply load_eq_of_sparse_packed base cs211 support code
    entries211 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node211 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 44 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 58 (insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs211 support demand
    entries211 ((insert 44 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 58 (insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)) 1000 30 loads211
  decide +kernel
def entries212 : List (Fin 1589 × ℕ) := [(11, 5), (13, 4), (20, 8), (46, 7), (72, 12), (77, 10), (179, 27), (196, 12), (344, 9), (431, 54), (466, 46), (472, 5), (478, 7), (479, 18), (571, 11), (581, 6), (616, 33), (617, 25), (618, 15), (623, 25), (625, 16), (632, 19), (639, 2), (640, 29), (680, 13), (681, 17), (762, 29), (813, 5), (815, 2), (833, 6), (835, 4), (850, 34), (856, 4), (863, 4), (867, 5), (906, 84), (914, 4), (925, 12), (930, 18), (939, 54), (952, 8), (968, 20), (970, 15), (973, 6), (978, 8), (984, 43), (985, 18), (995, 3), (1005, 18), (1009, 5), (1021, 21), (1068, 38), (1078, 14), (1082, 3), (1086, 9), (1114, 33), (1137, 22), (1139, 1), (1149, 13), (1152, 14), (1153, 1), (1182, 42), (1227, 2), (1228, 7), (1241, 4), (1258, 17), (1261, 8), (1263, 6), (1267, 5), (1280, 11), (1297, 5), (1308, 1), (1379, 38), (1448, 7), (1556, 17), (1561, 22), (1588, 17)]
def cs212 : List ℕ := [57, 11, 14, 42, 25, 15, 7, 96, 14, 4, 65, 57, 101, 8, 29, 0, 100, 57, 54, 18, 100, 71, 27, 100, 100, 101, 100, 100, 68, 65, 100, 100, 12, 0, 100, 100, 100, 100, 99, 100, 100, 100, 65, 100, 5, 101, 100, 101, 27, 100, 100, 101, 100, 100, 0, 100, 100, 101, 0, 67, 99, 49, 99, 101, 83, 100, 100, 99, 100, 100, 96, 192, 99, 80, 26, 211, 0, 100, 99, 99, 101, 99, 45, 282, 76, 133, 100, 99, 99, 100, 100, 100, 100, 100, 52, 71, 99, 100, 100, 101, 298, 100, 100, 61, 79, 73, 100, 100, 230, 42, 100, 100, 100, 99, 99, 7, 101, 57, 99, 6, 100, 99, 100, 99, 101, 67, 6, 6, 48, 100, 80, 28, 99, 99, 100, 100, 19, 66, 100, 99, 100, 19, 100, 73, 100, 6, 80, 35, 81, 57, 65, 20, 88, 22]
theorem loads212 : cs212.get =
    load (fun i : Fin entries212.length => support (entries212.get i).1)
      (fun i => (entries212.get i).2) := by
  apply load_eq_of_sparse_packed base cs212 support code
    entries212 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node212 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 58 (insert 44 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs212 support demand
    entries212 ((insert 58 (insert 44 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)) 100 30 loads212
  decide +kernel
theorem node210 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 44 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 44 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154))
    58 node211 node212
theorem node207 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 85 (insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154))
    44 node209 node210
def entries208 : List (Fin 1589 × ℕ) := [(13, 27), (17, 98), (20, 161), (46, 173), (72, 301), (77, 65), (198, 64), (344, 191), (386, 5), (387, 25), (466, 486), (472, 113), (491, 142), (507, 263), (588, 264), (616, 180), (617, 271), (624, 110), (625, 190), (632, 142), (640, 253), (673, 4), (717, 182), (730, 50), (731, 10), (762, 222), (797, 29), (815, 71), (843, 46), (850, 232), (882, 111), (886, 28), (894, 159), (896, 15), (906, 456), (921, 375), (925, 307), (930, 337), (938, 121), (939, 339), (949, 29), (952, 295), (965, 80), (968, 233), (970, 181), (973, 124), (978, 168), (984, 523), (985, 56), (995, 102), (1007, 1), (1018, 1), (1061, 27), (1075, 2), (1078, 14), (1097, 500), (1098, 10), (1104, 182), (1114, 105), (1123, 11), (1137, 184), (1139, 8), (1149, 170), (1152, 39), (1153, 139), (1173, 37), (1182, 278), (1219, 169), (1234, 108), (1258, 26), (1261, 100), (1263, 113), (1267, 70), (1297, 390), (1317, 164), (1372, 146), (1374, 2), (1379, 36), (1551, 123), (1558, 18), (1575, 30), (1578, 168), (1588, 328)]
def cs208 : List ℕ := [486, 169, 140, 660, 168, 0, 483, 963, 372, 263, 570, 965, 1000, 528, 707, 279, 1000, 1001, 933, 0, 1001, 850, 282, 1000, 1000, 1000, 1000, 1001, 907, 476, 1000, 1001, 852, 0, 1000, 1001, 1000, 1002, 811, 1000, 935, 1001, 1001, 1000, 1000, 1001, 1000, 1001, 198, 999, 1001, 999, 1002, 1000, 37, 1001, 1000, 1000, 1000, 598, 1000, 584, 1001, 875, 824, 923, 999, 1000, 1000, 1002, 1000, 2287, 1001, 1000, 37, 799, 146, 1000, 999, 1000, 1000, 1000, 628, 2721, 622, 37, 1000, 1000, 1000, 1000, 999, 1000, 999, 999, 985, 326, 1000, 999, 999, 999, 2590, 1001, 999, 932, 312, 1001, 999, 849, 2407, 233, 1001, 999, 999, 497, 1000, 0, 999, 539, 1000, 306, 999, 999, 827, 899, 999, 515, 124, 135, 479, 1000, 572, 308, 1002, 1000, 1000, 1000, 331, 810, 1001, 1000, 1000, 331, 1000, 519, 1000, 124, 999, 308, 1000, 826, 975, 327, 731, 514]
theorem loads208 : cs208.get =
    load (fun i : Fin entries208.length => support (entries208.get i).1)
      (fun i => (entries208.get i).2) := by
  apply load_eq_of_sparse_packed base cs208 support code
    entries208 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node208 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 85 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs208 support demand
    entries208 ((insert 85 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)) 1000 30 loads208
  decide +kernel
theorem node205 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 75 (insert 83 (insert 108 (insert 71 (insert 100 ∅))))) : Finset (Fin 154))
    85 node207 node208
def entries206 : List (Fin 1589 × ℕ) := [(20, 136), (30, 70), (46, 176), (72, 181), (77, 104), (179, 172), (344, 107), (466, 117), (472, 30), (479, 18), (491, 27), (507, 372), (530, 7), (531, 47), (570, 19), (571, 181), (572, 48), (587, 6), (588, 278), (625, 301), (632, 201), (640, 186), (681, 55), (717, 7), (730, 293), (736, 26), (762, 47), (813, 178), (815, 163), (844, 3), (850, 168), (870, 109), (872, 212), (882, 43), (896, 168), (906, 445), (920, 40), (921, 231), (925, 343), (930, 302), (938, 28), (939, 352), (952, 305), (958, 2), (965, 182), (967, 25), (968, 119), (970, 217), (973, 152), (978, 234), (984, 375), (1005, 110), (1006, 110), (1009, 105), (1031, 104), (1045, 99), (1061, 67), (1078, 21), (1097, 350), (1098, 7), (1104, 37), (1114, 155), (1128, 86), (1137, 30), (1148, 111), (1149, 168), (1153, 332), (1182, 391), (1186, 29), (1219, 175), (1221, 268), (1258, 51), (1261, 18), (1263, 178), (1267, 39), (1297, 288), (1358, 92), (1379, 166), (1448, 51), (1466, 257), (1508, 16), (1545, 154), (1548, 35), (1578, 153), (1588, 33)]
def cs206 : List ℕ := [480, 175, 298, 479, 171, 338, 356, 856, 384, 372, 604, 941, 1001, 472, 614, 196, 1001, 1001, 1000, 280, 1001, 1001, 456, 1001, 1000, 1001, 957, 1000, 625, 685, 950, 1000, 999, 3, 1001, 999, 1000, 999, 814, 1000, 999, 1000, 854, 1000, 1001, 1000, 1000, 999, 465, 1000, 1000, 999, 1000, 1000, 268, 1000, 1000, 999, 999, 693, 1000, 999, 917, 1000, 386, 999, 1000, 1001, 1000, 999, 1000, 2397, 1000, 1000, 307, 0, 0, 1000, 1000, 999, 999, 999, 599, 2275, 999, 630, 666, 1000, 1000, 1000, 999, 938, 1000, 1001, 992, 222, 1000, 999, 1000, 1000, 2120, 1000, 1001, 910, 0, 1000, 1000, 999, 2008, 208, 1000, 1000, 999, 444, 1000, 29, 1001, 975, 1000, 189, 1001, 999, 863, 1000, 1000, 676, 152, 256, 622, 1000, 837, 293, 1000, 999, 1000, 1000, 320, 846, 999, 1000, 1000, 336, 1000, 717, 836, 152, 999, 322, 919, 878, 831, 181, 955, 469]
theorem loads206 : cs206.get =
    load (fun i : Fin entries206.length => support (entries206.get i).1)
      (fun i => (entries206.get i).2) := by
  apply load_eq_of_sparse_packed base cs206 support code
    entries206 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node206 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 75 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 108 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs206 support demand
    entries206 ((insert 75 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 83 (insert 108 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)) 1000 30 loads206
  decide +kernel
theorem node191 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 108 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 83 (insert 108 (insert 71 (insert 100 ∅)))) : Finset (Fin 154))
    75 node205 node206
def entries203 : List (Fin 1589 × ℕ) := [(20, 340), (30, 29), (122, 329), (179, 3), (205, 158), (351, 9), (384, 198), (398, 130), (415, 119), (472, 390), (485, 64), (498, 181), (507, 268), (515, 29), (542, 123), (551, 28), (577, 16), (588, 278), (614, 102), (631, 60), (632, 174), (736, 32), (798, 10), (815, 244), (850, 90), (863, 147), (868, 112), (870, 388), (872, 235), (881, 28), (884, 16), (886, 220), (894, 120), (896, 49), (920, 275), (924, 316), (927, 43), (928, 118), (929, 104), (930, 219), (952, 58), (973, 97), (978, 110), (984, 360), (985, 67), (1006, 203), (1009, 75), (1045, 175), (1056, 303), (1061, 132), (1068, 174), (1070, 63), (1099, 38), (1104, 54), (1114, 53), (1137, 54), (1149, 313), (1153, 150), (1159, 54), (1173, 44), (1182, 196), (1217, 163), (1227, 119), (1234, 323), (1246, 17), (1258, 303), (1263, 86), (1268, 25), (1292, 32), (1297, 349), (1339, 133), (1342, 53), (1358, 212), (1374, 43), (1400, 26), (1433, 269), (1466, 171), (1498, 74), (1539, 5), (1552, 91), (1578, 235), (1582, 72)]
def cs203 : List ℕ := [375, 0, 553, 502, 235, 434, 307, 1000, 636, 415, 480, 998, 1000, 629, 358, 766, 1507, 1000, 1000, 25, 999, 967, 281, 1000, 1359, 999, 1000, 1000, 329, 668, 999, 999, 1000, 0, 1000, 1000, 1000, 1000, 999, 1000, 1000, 1000, 642, 999, 999, 1000, 991, 2449, 725, 999, 1000, 1000, 1000, 999, 44, 1001, 1000, 2322, 999, 999, 1000, 963, 831, 999, 523, 968, 1000, 1000, 1000, 998, 1000, 1537, 873, 999, 560, 1000, 0, 1000, 1000, 1000, 999, 999, 999, 0, 999, 1000, 828, 999, 999, 1000, 999, 766, 999, 998, 868, 349, 1000, 999, 1000, 998, 457, 999, 653, 999, 107, 768, 1000, 999, 921, 0, 999, 998, 999, 857, 1000, 0, 1000, 196, 999, 151, 592, 1000, 637, 1000, 999, 786, 97, 97, 374, 1000, 999, 151, 1000, 999, 868, 999, 454, 500, 999, 998, 778, 555, 999, 736, 703, 97, 999, 151, 999, 856, 642, 97, 800, 446]
theorem loads203 : cs203.get =
    load (fun i : Fin entries203.length => support (entries203.get i).1)
      (fun i => (entries203.get i).2) := by
  apply load_eq_of_sparse_packed base cs203 support code
    entries203 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node203 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 47 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs203 support demand
    entries203 ((insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 57 (insert 47 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)) 1000 30 loads203
  decide +kernel
def entries204 : List (Fin 1589 × ℕ) := [(20, 389), (30, 125), (72, 191), (122, 214), (135, 40), (179, 127), (273, 39), (384, 22), (398, 140), (421, 195), (466, 264), (472, 72), (484, 203), (507, 336), (531, 94), (551, 50), (571, 122), (588, 166), (614, 385), (616, 76), (617, 171), (625, 164), (631, 89), (639, 10), (730, 409), (736, 88), (739, 158), (740, 47), (741, 59), (813, 159), (850, 124), (870, 40), (871, 116), (884, 126), (885, 242), (896, 126), (920, 206), (924, 110), (936, 122), (947, 95), (949, 13), (952, 417), (958, 273), (973, 165), (978, 398), (985, 183), (1006, 234), (1009, 152), (1031, 89), (1045, 94), (1056, 50), (1061, 255), (1068, 139), (1070, 7), (1086, 6), (1090, 32), (1114, 15), (1122, 112), (1123, 18), (1137, 110), (1148, 56), (1149, 68), (1153, 359), (1155, 1), (1173, 148), (1178, 20), (1182, 406), (1217, 78), (1219, 49), (1258, 49), (1275, 146), (1295, 36), (1297, 213), (1298, 22), (1317, 21), (1358, 176), (1393, 174), (1403, 29), (1466, 94), (1495, 23), (1496, 16), (1498, 106), (1577, 33), (1578, 361)]
def cs204 : List ℕ := [518, 49, 150, 562, 361, 512, 394, 1000, 514, 336, 591, 1001, 1000, 724, 585, 961, 1756, 1000, 1000, 122, 1000, 1000, 293, 1001, 1540, 1001, 999, 1000, 743, 605, 1001, 1000, 999, 0, 999, 1000, 999, 999, 318, 1000, 999, 999, 807, 1001, 1000, 1000, 1001, 1134, 750, 951, 999, 999, 992, 1001, 148, 1000, 999, 0, 1000, 999, 999, 1000, 1000, 1000, 1000, 1000, 1000, 999, 1001, 1001, 998, 1084, 1000, 1000, 710, 1000, 20, 999, 999, 1001, 744, 998, 757, 0, 827, 883, 660, 999, 999, 1002, 999, 1001, 999, 998, 517, 418, 1000, 999, 1001, 1000, 981, 1002, 956, 548, 346, 999, 1000, 1000, 1038, 20, 1001, 1000, 756, 590, 1000, 32, 1001, 680, 1000, 201, 311, 1000, 951, 1000, 1000, 933, 165, 440, 751, 1000, 1000, 331, 1000, 1001, 725, 999, 381, 673, 1000, 921, 907, 408, 1000, 1001, 1000, 221, 1000, 363, 1001, 609, 969, 352, 1000, 525]
theorem loads204 : cs204.get =
    load (fun i : Fin entries204.length => support (entries204.get i).1)
      (fun i => (entries204.get i).2) := by
  apply load_eq_of_sparse_packed base cs204 support code
    entries204 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node204 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 57 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs204 support demand
    entries204 ((insert 57 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 47 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)) 1000 30 loads204
  decide +kernel
theorem node197 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154))
    57 node203 node204
def entries201 : List (Fin 1589 × ℕ) := [(30, 176), (70, 152), (72, 163), (77, 81), (120, 86), (122, 90), (135, 83), (273, 36), (287, 28), (384, 178), (398, 43), (420, 155), (421, 103), (466, 523), (472, 194), (483, 385), (484, 47), (507, 51), (514, 98), (531, 132), (550, 110), (583, 234), (614, 396), (616, 370), (624, 55), (625, 148), (632, 329), (675, 2), (676, 38), (730, 61), (731, 504), (776, 63), (777, 104), (798, 71), (815, 359), (818, 60), (849, 146), (850, 222), (855, 58), (870, 194), (872, 176), (896, 133), (912, 113), (920, 96), (924, 245), (925, 28), (939, 110), (952, 583), (958, 79), (973, 107), (978, 342), (985, 287), (1006, 160), (1009, 195), (1031, 31), (1045, 171), (1061, 236), (1068, 5), (1070, 185), (1075, 52), (1099, 18), (1104, 167), (1114, 172), (1128, 71), (1137, 167), (1139, 56), (1149, 89), (1152, 10), (1153, 284), (1173, 78), (1182, 497), (1228, 157), (1263, 111), (1280, 73), (1297, 71), (1307, 96), (1310, 106), (1317, 111), (1339, 25), (1358, 211), (1459, 33)]
def cs201 : List ℕ := [807, 73, 194, 464, 0, 835, 96, 1001, 287, 51, 494, 1001, 1872, 484, 396, 286, 1710, 1000, 1001, 0, 1001, 982, 0, 1001, 1305, 1000, 1000, 1001, 729, 594, 1001, 1001, 517, 0, 1000, 1000, 1000, 1001, 330, 1001, 999, 1000, 98, 1000, 1000, 1000, 1000, 0, 761, 1000, 1000, 999, 1001, 1000, 78, 1001, 999, 1001, 999, 443, 999, 1000, 620, 968, 1001, 1001, 1000, 1000, 1001, 2008, 999, 1332, 343, 1000, 644, 1001, 0, 1000, 1000, 940, 988, 1000, 1001, 138, 1000, 1001, 1000, 1000, 1000, 1000, 1000, 972, 1000, 907, 245, 577, 1000, 1000, 1000, 1000, 1224, 999, 1000, 930, 263, 1000, 998, 1000, 1225, 0, 999, 999, 333, 820, 1000, 157, 1000, 576, 1000, 274, 1000, 1000, 1000, 999, 1000, 796, 107, 138, 857, 1000, 1000, 274, 999, 999, 764, 1000, 274, 533, 999, 999, 785, 477, 999, 819, 948, 107, 999, 431, 999, 588, 999, 228, 999, 335]
theorem loads201 : cs201.get =
    load (fun i : Fin entries201.length => support (entries201.get i).1)
      (fun i => (entries201.get i).2) := by
  apply load_eq_of_sparse_packed base cs201 support code
    entries201 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node201 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 12 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs201 support demand
    entries201 ((insert 47 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 69 (insert 12 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)) 1000 30 loads201
  decide +kernel
def entries202 : List (Fin 1589 × ℕ) := [(30, 2), (37, 15), (70, 17), (72, 15), (122, 37), (205, 15), (384, 7), (398, 13), (415, 5), (420, 9), (421, 20), (466, 33), (472, 24), (491, 26), (496, 11), (498, 36), (507, 53), (514, 23), (542, 2), (550, 28), (583, 21), (614, 27), (617, 23), (625, 48), (689, 6), (736, 20), (739, 2), (813, 22), (850, 27), (855, 6), (870, 24), (872, 13), (884, 20), (886, 6), (918, 32), (920, 17), (924, 19), (937, 4), (939, 18), (947, 1), (949, 1), (952, 30), (958, 20), (973, 7), (978, 48), (985, 17), (1006, 19), (1009, 17), (1045, 4), (1048, 1), (1056, 14), (1061, 27), (1068, 27), (1075, 8), (1122, 12), (1137, 14), (1148, 1), (1149, 10), (1153, 25), (1155, 1), (1173, 19), (1182, 24), (1232, 12), (1241, 1), (1258, 2), (1263, 2), (1294, 2), (1297, 28), (1317, 27), (1358, 16), (1466, 19)]
def cs202 : List ℕ := [49, 0, 24, 27, 0, 23, 26, 73, 66, 53, 55, 99, 131, 15, 34, 65, 122, 99, 99, 15, 100, 79, 0, 100, 147, 98, 100, 100, 100, 17, 99, 100, 100, 0, 100, 101, 100, 82, 36, 100, 100, 77, 49, 100, 100, 99, 100, 0, 37, 99, 98, 100, 99, 100, 19, 98, 100, 80, 81, 100, 99, 101, 100, 100, 97, 98, 101, 101, 100, 0, 100, 195, 55, 100, 71, 100, 0, 94, 100, 99, 77, 100, 96, 18, 2, 100, 77, 100, 101, 100, 100, 100, 101, 89, 44, 31, 101, 100, 100, 100, 115, 100, 100, 58, 43, 101, 100, 100, 119, 0, 100, 100, 47, 46, 99, 12, 101, 45, 100, 22, 48, 100, 92, 100, 101, 87, 7, 21, 65, 101, 88, 22, 100, 101, 87, 101, 37, 61, 101, 101, 99, 36, 101, 89, 79, 9, 101, 22, 88, 64, 101, 46, 85, 49]
theorem loads202 : cs202.get =
    load (fun i : Fin entries202.length => support (entries202.get i).1)
      (fun i => (entries202.get i).2) := by
  apply load_eq_of_sparse_packed base cs202 support code
    entries202 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node202 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 12 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs202 support demand
    entries202 ((insert 69 (insert 47 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 12 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)) 100 30 loads202
  decide +kernel
theorem node199 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 12 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 12 (insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154))
    69 node201 node202
def entries200 : List (Fin 1589 × ℕ) := [(30, 16), (43, 4), (62, 30), (70, 14), (72, 5), (122, 25), (135, 18), (353, 3), (384, 7), (398, 21), (420, 12), (421, 30), (469, 14), (472, 43), (479, 3), (494, 20), (507, 32), (514, 48), (542, 6), (550, 20), (570, 12), (614, 6), (617, 25), (625, 27), (632, 17), (730, 33), (736, 3), (813, 8), (815, 2), (847, 3), (857, 10), (870, 42), (872, 23), (884, 25), (886, 14), (896, 2), (912, 17), (918, 20), (920, 12), (924, 33), (952, 21), (973, 14), (978, 41), (985, 5), (1006, 19), (1009, 5), (1045, 14), (1056, 27), (1061, 17), (1068, 20), (1104, 14), (1114, 2), (1137, 13), (1138, 3), (1148, 1), (1149, 21), (1153, 11), (1173, 20), (1182, 13), (1297, 31), (1317, 34), (1338, 5), (1339, 5), (1370, 2), (1374, 7), (1401, 16), (1466, 29), (1469, 10), (1500, 5), (1517, 3), (1552, 4), (1580, 17)]
def cs200 : List ℕ := [0, 14, 46, 0, 20, 16, 17, 100, 16, 62, 67, 59, 0, 86, 62, 45, 148, 100, 101, 30, 100, 61, 0, 60, 115, 100, 100, 100, 67, 56, 100, 100, 88, 0, 100, 100, 100, 99, 35, 100, 100, 100, 48, 101, 101, 99, 101, 0, 73, 101, 99, 99, 100, 101, 20, 100, 99, 100, 100, 101, 100, 100, 100, 85, 83, 101, 99, 100, 100, 100, 100, 142, 93, 100, 64, 101, 5, 100, 100, 100, 100, 100, 95, 0, 69, 101, 100, 101, 100, 100, 100, 77, 100, 77, 71, 46, 100, 101, 100, 101, 51, 100, 100, 88, 45, 100, 100, 89, 88, 0, 101, 99, 99, 57, 101, 0, 100, 13, 100, 28, 56, 100, 84, 91, 100, 93, 14, 14, 43, 100, 81, 28, 101, 99, 76, 100, 55, 62, 100, 99, 93, 55, 99, 76, 65, 14, 99, 28, 75, 88, 97, 48, 72, 45]
theorem loads200 : cs200.get =
    load (fun i : Fin entries200.length => support (entries200.get i).1)
      (fun i => (entries200.get i).2) := by
  apply load_eq_of_sparse_packed base cs200 support code
    entries200 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node200 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 12 (insert 47 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs200 support demand
    entries200 ((insert 12 (insert 47 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)) 100 30 loads200
  decide +kernel
theorem node198 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅))))) : Finset (Fin 154))
    12 node199 node200
theorem node195 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 24 (insert 16 (insert 108 (insert 71 (insert 100 ∅))))) : Finset (Fin 154))
    47 node197 node198
def entries196 : List (Fin 1589 × ℕ) := [(70, 158), (122, 257), (273, 143), (353, 22), (384, 272), (398, 138), (420, 62), (421, 153), (478, 166), (479, 252), (484, 9), (494, 128), (514, 246), (515, 302), (530, 237), (571, 117), (588, 261), (616, 67), (617, 184), (625, 80), (632, 252), (730, 154), (736, 99), (798, 69), (815, 236), (848, 4), (850, 201), (853, 176), (856, 32), (870, 388), (872, 120), (884, 46), (886, 116), (890, 111), (896, 44), (920, 179), (924, 347), (928, 218), (930, 29), (947, 28), (952, 251), (958, 24), (973, 298), (978, 154), (984, 172), (985, 105), (1006, 281), (1031, 121), (1045, 96), (1056, 256), (1061, 218), (1070, 61), (1114, 246), (1138, 61), (1149, 142), (1153, 289), (1173, 113), (1177, 97), (1182, 218), (1183, 132), (1188, 5), (1219, 257), (1222, 193), (1234, 109), (1263, 131), (1267, 17), (1297, 96), (1302, 15), (1317, 195), (1339, 107), (1374, 55), (1380, 2), (1466, 62), (1469, 191), (1499, 1), (1556, 125), (1566, 29)]
def cs196 : List ℕ := [0, 450, 197, 458, 418, 410, 2, 1000, 131, 0, 708, 840, 999, 357, 158, 257, 1171, 1000, 1000, 117, 1000, 735, 290, 999, 0, 1002, 1000, 999, 590, 410, 1000, 999, 789, 0, 1000, 999, 1000, 1000, 385, 1000, 999, 1000, 840, 840, 1000, 1000, 999, 999, 745, 732, 1000, 1000, 813, 1000, 311, 1001, 1000, 999, 1001, 897, 1000, 1001, 1001, 960, 1000, 1001, 999, 1001, 887, 1000, 1000, 1082, 805, 1000, 522, 999, 102, 1001, 1000, 1001, 1000, 1000, 866, 0, 1001, 1000, 931, 1000, 1000, 1001, 1001, 947, 1000, 1000, 754, 381, 1000, 1000, 1001, 1001, 651, 1001, 1001, 903, 455, 999, 1000, 915, 880, 0, 1001, 1000, 666, 886, 1001, 97, 1000, 374, 1000, 395, 494, 954, 910, 973, 1001, 834, 395, 419, 513, 1000, 1001, 395, 1000, 1000, 879, 1000, 650, 515, 1000, 1000, 765, 614, 1000, 1000, 834, 395, 999, 298, 902, 895, 939, 590, 1000, 526]
theorem loads196 : cs196.get =
    load (fun i : Fin entries196.length => support (entries196.get i).1)
      (fun i => (entries196.get i).2) := by
  apply load_eq_of_sparse_packed base cs196 support code
    entries196 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node196 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 24 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 16 (insert 108 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs196 support demand
    entries196 ((insert 24 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 16 (insert 108 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)) 1000 30 loads196
  decide +kernel
theorem node193 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 16 (insert 108 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 16 (insert 108 (insert 71 (insert 100 ∅)))) : Finset (Fin 154))
    24 node195 node196
def entries194 : List (Fin 1589 × ℕ) := [(70, 277903), (122, 198620), (179, 65890), (273, 35831), (384, 126166), (398, 207937), (420, 46788), (421, 104371), (475, 10642), (478, 158409), (479, 237070), (491, 273041), (494, 156669), (507, 428428), (526, 50068), (531, 30634), (541, 98707), (542, 12984), (588, 66465), (616, 158402), (617, 41049), (625, 260442), (632, 179856), (730, 101742), (736, 140739), (739, 27141), (798, 20418), (813, 66951), (814, 153727), (815, 171073), (844, 377203), (847, 70649), (850, 240958), (870, 256968), (872, 150556), (896, 120408), (906, 357782), (920, 220767), (924, 364799), (928, 193402), (949, 5634), (952, 304929), (958, 99962), (973, 365587), (978, 25368), (984, 259626), (1006, 83308), (1009, 59002), (1045, 218354), (1056, 202216), (1061, 349419), (1068, 31991), (1070, 78171), (1090, 40443), (1114, 126858), (1128, 8977), (1138, 101108), (1148, 90996), (1149, 10111), (1153, 36154), (1159, 71228), (1167, 47758), (1173, 330860), (1182, 276856), (1188, 66367), (1234, 267776), (1246, 14281), (1263, 107418), (1290, 14619), (1294, 138754), (1297, 16587), (1299, 130959), (1317, 168635), (1339, 60128), (1370, 12356), (1374, 69296), (1434, 68133), (1466, 40959), (1468, 31991), (1469, 22949), (1490, 42090), (1515, 67675), (1517, 51745), (1552, 5593), (1577, 171700)]
def cs194 : List ℕ := [377203, 0, 70649, 251600, 395479, 14619, 496486, 1000000, 321129, 428428, 292522, 764096, 1000000, 249323, 561294, 412410, 0, 1000000, 1000000, 0, 999999, 867299, 132355, 999999, 1000000, 1000000, 999999, 1000001, 482011, 529242, 685916, 1000000, 1000000, 424961, 1000001, 999999, 999999, 1000000, 541349, 1000001, 999999, 1000001, 511206, 1000000, 1000000, 1000000, 999999, 999999, 769616, 1000000, 1000001, 1000000, 1000000, 1000000, 330860, 1000001, 1000000, 999999, 999999, 1000000, 1000001, 999999, 1000000, 999998, 965056, 1000001, 1000000, 1000000, 1000000, 999999, 1000001, 1819048, 603815, 999999, 727665, 1000000, 66367, 883987, 1000001, 1000001, 999999, 999999, 771615, 357782, 961664, 1000000, 907773, 1000000, 1000000, 1000000, 1000001, 1000000, 999999, 1000000, 692629, 456505, 1000000, 999999, 1000001, 1000001, 906479, 1000000, 999999, 887866, 450080, 999999, 1000000, 934560, 1368166, 0, 1000001, 1000001, 999999, 1000000, 1000001, 88201, 999998, 376818, 1000001, 504341, 519409, 1000000, 875480, 737176, 999999, 987622, 365587, 504341, 650036, 1000000, 1000000, 504341, 1000000, 1000000, 555575, 1000001, 706558, 754686, 1000001, 1000001, 797540, 784729, 1000000, 1000000, 565229, 504341, 1000001, 544784, 898892, 858980, 966419, 534222, 918460, 382174]
theorem loads194 : cs194.get =
    load (fun i : Fin entries194.length => support (entries194.get i).1)
      (fun i => (entries194.get i).2) := by
  apply load_eq_of_sparse_packed base cs194 support code
    entries194 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node194 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 16 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 108 (insert 71 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs194 support demand
    entries194 ((insert 16 (insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 108 (insert 71 (insert 100 ∅))) : Finset (Fin 154)) 1000000 30 loads194
  decide +kernel
theorem node192 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 108 (insert 71 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 83 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 108 (insert 71 (insert 100 ∅))) : Finset (Fin 154))
    16 node193 node194
theorem node171 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 108 (insert 71 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 108 (insert 71 (insert 100 ∅))) : Finset (Fin 154))
    83 node191 node192
def entries189 : List (Fin 1589 × ℕ) := [(30, 32), (35, 42), (86, 66), (122, 82), (135, 39), (179, 189), (205, 40), (273, 269), (384, 45), (385, 111), (466, 522), (479, 268), (485, 3), (494, 186), (507, 413), (515, 308), (541, 61), (588, 287), (617, 353), (629, 4), (631, 131), (632, 95), (639, 23), (680, 44), (731, 17), (797, 34), (813, 478), (819, 3), (842, 48), (843, 73), (846, 6), (850, 374), (856, 91), (863, 17), (870, 368), (872, 78), (881, 331), (886, 51), (894, 27), (896, 277), (904, 353), (905, 139), (920, 98), (924, 17), (929, 67), (930, 392), (934, 386), (938, 241), (944, 28), (950, 93), (952, 171), (968, 71), (978, 187), (984, 175), (985, 370), (1005, 268), (1006, 223), (1009, 246), (1031, 64), (1056, 62), (1075, 150), (1100, 64), (1128, 73), (1137, 65), (1138, 215), (1148, 3), (1149, 262), (1153, 61), (1159, 291), (1164, 551), (1169, 200), (1227, 59), (1258, 116), (1267, 181), (1268, 112), (1297, 118), (1317, 330), (1322, 4), (1342, 147), (1379, 66), (1489, 90), (1498, 10), (1515, 169), (1548, 37), (1561, 128), (1577, 42), (1578, 2), (1585, 36)]
def cs189 : List ℕ := [522, 6, 0, 374, 270, 178, 44, 984, 74, 430, 376, 1000, 1000, 264, 105, 467, 1001, 1001, 1000, 112, 1001, 726, 476, 1000, 999, 1000, 999, 1001, 263, 461, 1000, 999, 999, 200, 1000, 999, 1001, 1001, 988, 1000, 999, 999, 1001, 1400, 1000, 999, 1000, 2445, 435, 975, 1000, 998, 939, 1000, 386, 999, 1000, 999, 999, 999, 999, 998, 1001, 1000, 909, 1000, 999, 1000, 1000, 999, 999, 1430, 1837, 998, 855, 1000, 0, 831, 1000, 1000, 999, 1000, 535, 1000, 1000, 811, 1000, 1001, 1001, 1000, 999, 1000, 1740, 1001, 1000, 264, 999, 1000, 999, 1000, 1065, 999, 1000, 1000, 353, 858, 1000, 998, 0, 236, 1000, 999, 1000, 158, 999, 200, 1000, 28, 999, 0, 962, 937, 752, 1334, 1000, 999, 0, 64, 693, 999, 999, 268, 1000, 999, 706, 999, 262, 482, 1957, 999, 1000, 262, 999, 999, 999, 0, 999, 268, 1000, 453, 999, 330, 926, 669]
theorem loads189 : cs189.get =
    load (fun i : Fin entries189.length => support (entries189.get i).1)
      (fun i => (entries189.get i).2) := by
  apply load_eq_of_sparse_packed base cs189 support code
    entries189 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node189 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 123 (insert 92 (insert 72 (insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs189 support demand
    entries189 ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 123 (insert 92 (insert 72 (insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅)))))))) : Finset (Fin 154)) 1000 30 loads189
  decide +kernel
def entries190 : List (Fin 1589 × ℕ) := [(30, 8), (35, 17), (86, 15), (120, 2), (122, 10), (179, 10), (273, 20), (341, 6), (383, 25), (415, 14), (466, 43), (479, 26), (491, 2), (494, 9), (507, 26), (515, 27), (542, 4), (572, 5), (588, 42), (617, 36), (629, 3), (631, 1), (639, 17), (737, 8), (813, 51), (817, 22), (843, 14), (846, 9), (850, 40), (856, 5), (863, 7), (868, 13), (870, 28), (871, 3), (872, 8), (881, 14), (884, 9), (894, 8), (896, 21), (903, 3), (904, 35), (905, 13), (920, 9), (929, 22), (930, 26), (934, 18), (938, 27), (939, 4), (952, 24), (958, 15), (968, 15), (973, 13), (978, 7), (984, 43), (985, 6), (1005, 12), (1006, 24), (1009, 31), (1056, 5), (1070, 36), (1076, 12), (1138, 17), (1139, 16), (1149, 17), (1159, 68), (1164, 20), (1234, 26), (1241, 18), (1266, 6), (1267, 23), (1268, 6), (1297, 32), (1342, 1), (1489, 5), (1498, 12), (1500, 1), (1528, 3), (1577, 2), (1578, 10), (1585, 3)]
def cs190 : List ℕ := [43, 9, 0, 40, 36, 42, 14, 97, 25, 33, 50, 100, 100, 42, 16, 50, 101, 99, 99, 11, 101, 82, 52, 100, 101, 101, 100, 101, 35, 31, 100, 100, 100, 0, 101, 100, 101, 100, 92, 100, 100, 93, 101, 109, 100, 99, 101, 248, 48, 101, 99, 99, 100, 99, 18, 99, 102, 100, 100, 100, 100, 99, 100, 100, 62, 90, 100, 101, 100, 100, 99, 131, 188, 99, 67, 99, 1, 84, 102, 99, 100, 99, 84, 100, 86, 99, 90, 101, 101, 99, 99, 99, 168, 100, 100, 3, 100, 100, 100, 100, 81, 99, 99, 79, 75, 38, 99, 99, 22, 15, 99, 99, 100, 22, 100, 0, 91, 15, 99, 13, 96, 99, 77, 0, 100, 85, 16, 13, 99, 99, 100, 13, 86, 100, 15, 100, 33, 13, 209, 100, 85, 69, 100, 99, 99, 13, 100, 13, 100, 62, 100, 13, 81, 83]
theorem loads190 : cs190.get =
    load (fun i : Fin entries190.length => support (entries190.get i).1)
      (fun i => (entries190.get i).2) := by
  apply load_eq_of_sparse_packed base cs190 support code
    entries190 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node190 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 123 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 72 (insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs190 support demand
    entries190 ((insert 123 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 92 (insert 72 (insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)) 100 30 loads190
  decide +kernel
theorem node187 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 92 (insert 72 (insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 92 (insert 72 (insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅))))))) : Finset (Fin 154))
    123 node189 node190
def entries188 : List (Fin 1589 × ℕ) := [(17, 4), (20, 4), (86, 7), (179, 13), (205, 5), (273, 31), (384, 10), (431, 2), (466, 36), (491, 5), (494, 31), (507, 18), (515, 1), (541, 26), (588, 41), (616, 13), (625, 3), (639, 3), (672, 4), (681, 20), (731, 6), (736, 14), (777, 14), (800, 6), (843, 24), (850, 27), (856, 13), (863, 9), (868, 3), (870, 27), (871, 13), (872, 6), (881, 23), (886, 31), (890, 2), (894, 8), (896, 16), (898, 3), (904, 45), (913, 4), (920, 25), (930, 43), (938, 30), (942, 3), (968, 32), (973, 4), (978, 20), (984, 23), (985, 28), (1005, 19), (1006, 23), (1018, 4), (1034, 6), (1056, 14), (1070, 2), (1075, 1), (1137, 18), (1138, 36), (1139, 1), (1149, 33), (1153, 6), (1159, 6), (1164, 16), (1167, 11), (1173, 11), (1182, 7), (1217, 3), (1228, 5), (1246, 8), (1258, 8), (1262, 5), (1263, 2), (1267, 10), (1268, 23), (1297, 25), (1317, 43), (1342, 6), (1370, 5), (1403, 14), (1498, 10), (1577, 2), (1578, 19)]
def cs188 : List ℕ := [39, 0, 3, 35, 19, 26, 26, 89, 15, 27, 23, 99, 96, 50, 47, 54, 100, 100, 99, 23, 100, 61, 57, 100, 99, 101, 99, 100, 13, 21, 100, 100, 100, 11, 100, 99, 101, 101, 90, 100, 77, 100, 87, 144, 99, 100, 100, 277, 33, 100, 101, 100, 83, 99, 11, 100, 100, 100, 100, 99, 99, 97, 100, 101, 101, 100, 99, 100, 101, 100, 90, 63, 149, 101, 76, 100, 0, 99, 101, 88, 100, 101, 71, 100, 94, 62, 31, 100, 100, 100, 100, 100, 0, 101, 100, 28, 78, 100, 100, 100, 76, 99, 60, 100, 15, 77, 100, 100, 0, 35, 100, 101, 100, 20, 100, 16, 100, 7, 101, 4, 87, 100, 44, 101, 99, 100, 4, 4, 58, 100, 99, 33, 101, 100, 89, 100, 48, 34, 180, 101, 100, 50, 100, 67, 100, 4, 101, 38, 101, 73, 101, 47, 74, 50]
theorem loads188 : cs188.get =
    load (fun i : Fin entries188.length => support (entries188.get i).1)
      (fun i => (entries188.get i).2) := by
  apply load_eq_of_sparse_packed base cs188 support code
    entries188 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node188 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 92 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 72 (insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs188 support demand
    entries188 ((insert 92 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 72 (insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)) 100 30 loads188
  decide +kernel
theorem node185 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 72 (insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 72 (insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅)))))) : Finset (Fin 154))
    92 node187 node188
def entries186 : List (Fin 1589 × ℕ) := [(20, 14), (30, 9), (86, 10), (120, 27), (179, 19), (273, 17), (466, 14), (472, 18), (479, 16), (491, 5), (494, 24), (507, 7), (531, 20), (542, 30), (552, 1), (588, 23), (616, 8), (617, 15), (625, 5), (631, 12), (639, 14), (672, 3), (730, 8), (731, 19), (736, 2), (737, 3), (797, 7), (812, 6), (813, 23), (843, 21), (850, 33), (855, 1), (863, 9), (867, 1), (870, 44), (871, 1), (872, 10), (882, 3), (894, 2), (896, 18), (904, 11), (914, 4), (920, 21), (929, 1), (930, 39), (934, 18), (938, 19), (952, 23), (958, 25), (968, 36), (973, 13), (984, 39), (985, 31), (1006, 31), (1009, 9), (1031, 18), (1034, 7), (1045, 9), (1056, 13), (1068, 4), (1104, 1), (1137, 8), (1138, 13), (1149, 9), (1152, 16), (1153, 17), (1159, 16), (1164, 13), (1173, 12), (1182, 18), (1217, 14), (1236, 12), (1241, 10), (1246, 13), (1258, 7), (1268, 5), (1297, 26), (1299, 2), (1317, 21), (1359, 2), (1419, 4), (1435, 1), (1491, 11), (1498, 22), (1501, 3), (1509, 18), (1556, 11)]
def cs186 : List ℕ := [40, 2, 32, 47, 28, 62, 5, 100, 29, 16, 23, 101, 100, 63, 30, 86, 100, 101, 100, 5, 100, 62, 45, 100, 100, 99, 99, 101, 32, 49, 100, 99, 101, 0, 100, 100, 99, 100, 99, 101, 98, 99, 50, 141, 100, 100, 100, 152, 59, 99, 100, 100, 100, 100, 30, 100, 100, 99, 100, 100, 99, 100, 100, 75, 100, 100, 99, 100, 81, 99, 99, 73, 0, 99, 78, 99, 0, 99, 99, 100, 99, 98, 99, 65, 97, 93, 67, 99, 101, 100, 100, 100, 100, 99, 59, 42, 99, 100, 100, 79, 94, 100, 99, 91, 27, 63, 100, 99, 10, 36, 100, 100, 99, 35, 100, 0, 99, 43, 100, 14, 99, 100, 79, 99, 100, 82, 13, 31, 55, 99, 100, 21, 100, 101, 97, 100, 34, 52, 144, 79, 92, 34, 101, 100, 100, 13, 101, 21, 101, 60, 101, 50, 92, 62]
theorem loads186 : cs186.get =
    load (fun i : Fin entries186.length => support (entries186.get i).1)
      (fun i => (entries186.get i).2) := by
  apply load_eq_of_sparse_packed base cs186 support code
    entries186 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node186 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 72 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs186 support demand
    entries186 ((insert 72 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)) 100 30 loads186
  decide +kernel
theorem node183 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 138 (insert 43 (insert 47 (insert 71 (insert 100 ∅))))) : Finset (Fin 154))
    72 node185 node186
def entries184 : List (Fin 1589 × ℕ) := [(20, 270), (30, 24), (35, 30), (86, 114), (120, 73), (179, 67), (205, 43), (273, 51), (341, 105), (466, 417), (472, 62), (479, 131), (491, 116), (494, 278), (507, 181), (514, 25), (515, 41), (527, 40), (541, 234), (542, 45), (588, 375), (617, 175), (625, 55), (629, 18), (631, 74), (632, 6), (639, 72), (640, 62), (737, 56), (798, 98), (812, 153), (813, 407), (843, 171), (850, 322), (863, 122), (867, 17), (870, 294), (872, 136), (881, 141), (886, 142), (896, 292), (904, 314), (906, 99), (920, 294), (924, 139), (929, 3), (930, 419), (934, 60), (938, 242), (944, 77), (952, 149), (958, 49), (968, 328), (984, 467), (985, 307), (1006, 207), (1009, 83), (1020, 17), (1045, 167), (1056, 274), (1061, 75), (1068, 184), (1082, 125), (1114, 182), (1123, 64), (1137, 159), (1149, 130), (1152, 401), (1153, 245), (1155, 453), (1173, 172), (1182, 67), (1221, 12), (1246, 257), (1267, 154), (1268, 194), (1342, 94), (1403, 4), (1498, 209), (1525, 46), (1545, 59), (1578, 47)]
def cs184 : List ℕ := [429, 0, 120, 592, 178, 275, 163, 993, 324, 349, 176, 1000, 1000, 654, 326, 470, 1001, 1000, 1001, 194, 1000, 590, 442, 1000, 1001, 999, 1001, 1001, 282, 465, 999, 1001, 1001, 0, 1000, 1001, 1001, 1000, 913, 1001, 1001, 999, 786, 1433, 1001, 1001, 1002, 2428, 418, 1000, 1001, 1000, 958, 1000, 244, 1000, 1000, 1000, 999, 1000, 1001, 820, 908, 1000, 1000, 1000, 1001, 1000, 1000, 1000, 999, 1293, 1000, 1000, 740, 1000, 0, 999, 1000, 810, 1000, 1000, 700, 1000, 873, 989, 735, 999, 1001, 1000, 999, 849, 1000, 1001, 1000, 351, 1000, 1001, 1001, 999, 730, 1000, 999, 1000, 347, 637, 1001, 1000, 174, 328, 1000, 999, 1000, 420, 1001, 0, 1001, 705, 1000, 0, 1000, 1000, 563, 1001, 1000, 751, 0, 64, 538, 1000, 1000, 159, 997, 1000, 974, 999, 302, 510, 67, 999, 921, 302, 517, 721, 1000, 0, 494, 159, 67, 484, 131, 401, 312, 453]
theorem loads184 : cs184.get =
    load (fun i : Fin entries184.length => support (entries184.get i).1)
      (fun i => (entries184.get i).2) := by
  apply load_eq_of_sparse_packed base cs184 support code
    entries184 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node184 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 138 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 43 (insert 47 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs184 support demand
    entries184 ((insert 138 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 43 (insert 47 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)) 1000 30 loads184
  decide +kernel
theorem node181 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 43 (insert 47 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 43 (insert 47 (insert 71 (insert 100 ∅)))) : Finset (Fin 154))
    138 node183 node184
def entries182 : List (Fin 1589 × ℕ) := [(20, 185), (30, 169), (35, 220), (75, 99), (86, 27), (179, 138), (273, 57), (341, 50), (344, 2), (466, 291), (479, 204), (507, 201), (541, 53), (542, 185), (551, 20), (570, 167), (587, 12), (588, 343), (616, 75), (617, 215), (619, 55), (631, 158), (673, 114), (681, 75), (737, 95), (797, 31), (798, 73), (813, 276), (843, 270), (848, 4), (850, 258), (856, 87), (867, 78), (868, 97), (870, 442), (872, 144), (886, 178), (896, 103), (904, 181), (906, 114), (920, 174), (924, 55), (930, 311), (934, 39), (938, 194), (952, 165), (968, 416), (973, 351), (984, 68), (995, 120), (997, 31), (1005, 122), (1009, 29), (1021, 150), (1045, 278), (1056, 227), (1061, 132), (1076, 1), (1090, 173), (1114, 151), (1128, 30), (1137, 121), (1149, 56), (1152, 21), (1153, 204), (1160, 82), (1173, 293), (1182, 300), (1219, 88), (1246, 248), (1267, 230), (1268, 86), (1317, 145), (1342, 38), (1403, 51), (1498, 275), (1515, 97), (1525, 57), (1577, 41), (1578, 110)]
def cs182 : List ℕ := [291, 88, 61, 531, 314, 751, 151, 754, 574, 258, 441, 999, 999, 804, 488, 446, 999, 1000, 1001, 86, 1000, 711, 493, 999, 999, 1000, 1000, 1000, 230, 800, 999, 1000, 1000, 0, 1000, 1001, 1001, 1000, 810, 999, 1001, 927, 700, 68, 1000, 1000, 1001, 2241, 424, 943, 1000, 1001, 903, 1001, 336, 1001, 1000, 1001, 1000, 622, 1000, 630, 1000, 1000, 916, 908, 1000, 1001, 1000, 1002, 825, 924, 1000, 1001, 472, 1001, 0, 860, 1001, 816, 1001, 1001, 611, 897, 1000, 894, 999, 1002, 1000, 1001, 1000, 824, 1001, 1001, 1000, 575, 1000, 1000, 1000, 1001, 791, 1000, 1001, 1002, 622, 779, 1000, 1000, 246, 416, 1000, 1000, 1001, 688, 1000, 173, 1001, 300, 1000, 351, 1000, 1001, 678, 1000, 1002, 1000, 351, 351, 576, 941, 1001, 472, 999, 1000, 786, 1001, 700, 750, 1001, 984, 548, 700, 1000, 965, 1001, 351, 1000, 645, 651, 881, 796, 517, 1000, 433]
theorem loads182 : cs182.get =
    load (fun i : Fin entries182.length => support (entries182.get i).1)
      (fun i => (entries182.get i).2) := by
  apply load_eq_of_sparse_packed base cs182 support code
    entries182 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node182 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 43 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 71 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs182 support demand
    entries182 ((insert 43 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 47 (insert 71 (insert 100 ∅))) : Finset (Fin 154)) 1000 30 loads182
  decide +kernel
theorem node173 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 71 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 71 (insert 100 ∅))) : Finset (Fin 154))
    43 node181 node182
def entries179 : List (Fin 1589 × ℕ) := [(17, 65), (35, 131), (120, 81), (122, 101), (135, 3), (179, 23), (205, 81), (273, 329), (341, 44), (384, 2), (421, 90), (466, 338), (472, 329), (478, 12), (479, 197), (483, 53), (491, 153), (507, 221), (527, 18), (531, 172), (542, 259), (550, 17), (580, 34), (583, 178), (616, 65), (617, 315), (625, 256), (630, 105), (730, 429), (736, 148), (812, 24), (813, 310), (843, 277), (850, 383), (867, 131), (870, 385), (872, 122), (885, 36), (886, 122), (914, 141), (919, 42), (920, 140), (924, 134), (937, 62), (949, 249), (950, 109), (952, 241), (958, 18), (968, 413), (973, 297), (984, 331), (985, 154), (1005, 53), (1006, 151), (1009, 93), (1045, 41), (1056, 99), (1068, 118), (1137, 20), (1152, 159), (1153, 179), (1154, 127), (1160, 20), (1164, 56), (1167, 68), (1169, 92), (1173, 279), (1182, 192), (1219, 98), (1263, 72), (1297, 177), (1317, 206), (1359, 21), (1400, 17), (1447, 31), (1481, 87), (1491, 294), (1545, 179), (1548, 16), (1556, 1), (1586, 4)]
def cs179 : List ℕ := [338, 123, 329, 546, 209, 184, 153, 999, 268, 225, 131, 999, 1000, 490, 259, 493, 1000, 999, 1000, 0, 1000, 535, 23, 1000, 999, 1000, 999, 998, 438, 487, 1000, 1000, 999, 160, 999, 999, 999, 1000, 104, 999, 1000, 999, 250, 852, 999, 1000, 1000, 0, 553, 1000, 1000, 1000, 1000, 999, 279, 999, 1000, 999, 999, 595, 991, 1581, 1104, 864, 999, 950, 1000, 1000, 1000, 999, 1000, 1101, 577, 1801, 721, 998, 0, 1000, 1000, 981, 1000, 1000, 1000, 999, 539, 999, 715, 1000, 1000, 999, 1001, 835, 1000, 1000, 765, 384, 974, 1000, 1000, 1000, 1064, 1000, 1000, 1000, 594, 631, 1000, 1000, 0, 429, 1000, 1000, 930, 471, 1000, 160, 999, 516, 999, 297, 1000, 695, 697, 999, 1001, 1000, 297, 297, 502, 1000, 1001, 477, 1000, 1001, 957, 1001, 576, 636, 1001, 677, 704, 576, 1001, 861, 1001, 297, 1001, 477, 722, 753, 928, 662, 1001, 550]
theorem loads179 : cs179.get =
    load (fun i : Fin entries179.length => support (entries179.get i).1)
      (fun i => (entries179.get i).2) := by
  apply load_eq_of_sparse_packed base cs179 support code
    entries179 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node179 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 73 (insert 61 (insert 62 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs179 support demand
    entries179 ((insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 73 (insert 61 (insert 62 (insert 71 (insert 100 ∅))))) : Finset (Fin 154)) 1000 30 loads179
  decide +kernel
def entries180 : List (Fin 1589 × ℕ) := [(17, 29), (35, 30), (179, 3), (341, 15), (343, 13), (361, 5), (384, 6), (421, 36), (466, 13), (472, 30), (479, 10), (491, 22), (507, 24), (514, 2), (530, 17), (531, 8), (542, 14), (550, 13), (571, 4), (616, 9), (617, 8), (622, 11), (632, 33), (736, 16), (797, 17), (813, 27), (843, 10), (850, 24), (870, 32), (872, 5), (885, 14), (886, 8), (896, 3), (912, 20), (918, 3), (920, 4), (924, 19), (925, 11), (947, 3), (949, 8), (952, 48), (973, 16), (984, 33), (985, 16), (1005, 5), (1006, 16), (1009, 10), (1045, 14), (1056, 27), (1061, 4), (1068, 2), (1075, 7), (1104, 3), (1128, 8), (1137, 15), (1138, 10), (1149, 18), (1153, 26), (1154, 7), (1160, 15), (1164, 9), (1173, 24), (1179, 13), (1182, 17), (1219, 15), (1262, 16), (1263, 13), (1297, 17), (1317, 13), (1359, 19), (1372, 8), (1459, 3), (1491, 33), (1499, 13), (1545, 22), (1548, 2), (1556, 1)]
def cs180 : List ℕ := [13, 34, 30, 68, 10, 30, 22, 87, 88, 24, 2, 101, 100, 97, 14, 46, 101, 100, 101, 4, 101, 45, 3, 100, 100, 101, 100, 101, 24, 86, 101, 100, 100, 0, 101, 100, 100, 101, 3, 101, 97, 101, 57, 100, 101, 100, 99, 0, 8, 100, 100, 100, 101, 101, 37, 100, 100, 101, 100, 94, 101, 123, 150, 50, 100, 100, 101, 100, 97, 101, 101, 156, 101, 0, 69, 100, 21, 101, 101, 80, 26, 101, 101, 101, 36, 100, 69, 101, 100, 100, 101, 74, 100, 93, 86, 46, 101, 100, 101, 101, 59, 101, 100, 101, 45, 100, 100, 79, 15, 15, 101, 101, 47, 60, 101, 0, 100, 46, 100, 19, 45, 101, 97, 100, 101, 99, 16, 29, 78, 101, 101, 31, 101, 101, 52, 101, 58, 67, 102, 86, 65, 71, 101, 82, 101, 29, 101, 31, 72, 83, 85, 29, 92, 57]
theorem loads180 : cs180.get =
    load (fun i : Fin entries180.length => support (entries180.get i).1)
      (fun i => (entries180.get i).2) := by
  apply load_eq_of_sparse_packed base cs180 support code
    entries180 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node180 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 73 (insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 61 (insert 62 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs180 support demand
    entries180 ((insert 73 (insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 61 (insert 62 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)) 100 30 loads180
  decide +kernel
theorem node177 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 61 (insert 62 (insert 71 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 61 (insert 62 (insert 71 (insert 100 ∅)))) : Finset (Fin 154))
    73 node179 node180
def entries178 : List (Fin 1589 × ℕ) := [(17, 20), (20, 26), (35, 239), (62, 187), (65, 77), (120, 115), (122, 152), (135, 50), (341, 171), (343, 107), (361, 126), (421, 195), (466, 80), (472, 291), (479, 111), (484, 37), (491, 151), (542, 117), (552, 362), (583, 181), (617, 285), (625, 187), (632, 275), (736, 205), (737, 50), (777, 247), (813, 204), (816, 56), (843, 194), (850, 368), (867, 62), (870, 379), (872, 69), (884, 38), (885, 113), (896, 57), (903, 1), (905, 181), (914, 33), (918, 188), (919, 1), (920, 3), (924, 103), (949, 173), (950, 119), (952, 343), (958, 46), (968, 225), (973, 185), (984, 431), (985, 38), (1005, 29), (1006, 256), (1009, 128), (1045, 51), (1056, 178), (1068, 236), (1114, 56), (1149, 147), (1152, 22), (1153, 278), (1154, 49), (1167, 78), (1173, 109), (1182, 251), (1219, 129), (1236, 160), (1262, 73), (1263, 52), (1280, 5), (1297, 308), (1317, 227), (1356, 29), (1359, 96), (1372, 188), (1447, 42), (1483, 9), (1484, 65), (1545, 107), (1580, 127)]
def cs178 : List ℕ := [245, 230, 320, 543, 427, 441, 151, 999, 410, 264, 62, 1000, 1000, 885, 244, 629, 999, 1000, 1000, 187, 1000, 606, 0, 1000, 1000, 1000, 1001, 999, 454, 647, 1000, 1000, 140, 78, 1000, 1001, 1000, 1000, 302, 1000, 1001, 880, 820, 1001, 999, 1000, 1001, 0, 278, 927, 1000, 1001, 1001, 1000, 109, 1001, 1000, 1001, 1000, 905, 1001, 0, 1165, 795, 1000, 1001, 1000, 1000, 1001, 1000, 1001, 572, 1002, 1000, 667, 1000, 188, 1000, 1001, 777, 845, 1000, 821, 1001, 349, 1000, 1001, 1000, 999, 1001, 1001, 712, 1001, 1000, 711, 553, 1000, 999, 1000, 1001, 568, 1000, 1000, 1000, 394, 999, 999, 938, 0, 225, 1001, 1000, 508, 410, 1000, 78, 999, 453, 1000, 185, 996, 674, 816, 999, 1000, 903, 185, 185, 828, 1000, 1001, 263, 999, 1000, 752, 1000, 441, 550, 1000, 745, 549, 441, 1000, 712, 999, 185, 1000, 263, 744, 805, 971, 434, 990, 493]
theorem loads178 : cs178.get =
    load (fun i : Fin entries178.length => support (entries178.get i).1)
      (fun i => (entries178.get i).2) := by
  apply load_eq_of_sparse_packed base cs178 support code
    entries178 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node178 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 61 (insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 62 (insert 71 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs178 support demand
    entries178 ((insert 61 (insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 62 (insert 71 (insert 100 ∅))) : Finset (Fin 154)) 1000 30 loads178
  decide +kernel
theorem node175 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 62 (insert 71 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 62 (insert 71 (insert 100 ∅))) : Finset (Fin 154))
    61 node177 node178
def entries176 : List (Fin 1589 × ℕ) := [(35, 3), (46, 23), (62, 18), (86, 14), (120, 4), (273, 8), (420, 14), (421, 11), (466, 24), (472, 6), (475, 4), (479, 16), (507, 28), (552, 7), (572, 7), (583, 8), (617, 44), (625, 10), (632, 40), (640, 1), (736, 18), (813, 16), (818, 3), (843, 10), (844, 4), (850, 15), (857, 17), (865, 5), (872, 22), (886, 26), (890, 3), (894, 3), (906, 23), (914, 5), (918, 6), (920, 25), (924, 21), (925, 8), (938, 5), (939, 12), (949, 7), (952, 18), (968, 28), (973, 18), (984, 50), (985, 10), (1006, 24), (1045, 8), (1048, 14), (1056, 12), (1061, 21), (1068, 5), (1070, 2), (1082, 5), (1090, 16), (1104, 6), (1139, 7), (1148, 17), (1149, 6), (1152, 22), (1153, 17), (1154, 6), (1173, 18), (1182, 34), (1183, 4), (1219, 22), (1236, 12), (1249, 3), (1263, 3), (1297, 12), (1304, 5), (1317, 22), (1359, 10), (1392, 7), (1469, 32), (1491, 14), (1515, 8), (1552, 8), (1559, 7), (1587, 4)]
def cs176 : List ℕ := [40, 36, 6, 46, 28, 15, 45, 98, 6, 46, 5, 95, 99, 47, 23, 29, 100, 100, 100, 25, 99, 51, 0, 101, 99, 98, 101, 98, 60, 79, 99, 100, 87, 4, 99, 102, 99, 99, 22, 99, 100, 101, 7, 99, 99, 100, 99, 0, 39, 99, 100, 100, 100, 100, 18, 100, 100, 99, 99, 79, 100, 100, 0, 93, 100, 100, 100, 100, 100, 99, 100, 134, 62, 99, 52, 101, 0, 100, 100, 70, 100, 100, 80, 99, 87, 96, 68, 100, 100, 91, 99, 99, 100, 99, 31, 13, 100, 100, 101, 99, 97, 99, 99, 100, 78, 96, 100, 99, 64, 28, 100, 100, 29, 81, 101, 19, 100, 44, 100, 38, 93, 89, 62, 101, 100, 83, 18, 18, 67, 101, 100, 35, 101, 100, 89, 101, 56, 48, 100, 99, 94, 44, 100, 100, 100, 18, 100, 54, 77, 54, 100, 62, 100, 34]
theorem loads176 : cs176.get =
    load (fun i : Fin entries176.length => support (entries176.get i).1)
      (fun i => (entries176.get i).2) := by
  apply load_eq_of_sparse_packed base cs176 support code
    entries176 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node176 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 62 (insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 100 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs176 support demand
    entries176 ((insert 62 (insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 71 (insert 100 ∅)) : Finset (Fin 154)) 100 30 loads176
  decide +kernel
theorem node174 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 100 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 71 (insert 100 ∅)) : Finset (Fin 154))
    62 node175 node176
theorem node172 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 100 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 108 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 71 (insert 100 ∅)) : Finset (Fin 154))
    47 node173 node174
theorem node157 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 71 (insert 100 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 71 (insert 100 ∅)) : Finset (Fin 154))
    108 node171 node172
def entries169 : List (Fin 1589 × ℕ) := [(20, 194994), (30, 252646), (62, 35238), (120, 119719), (273, 107682), (398, 69208), (466, 275301), (479, 239459), (506, 129820), (515, 88164), (542, 102290), (551, 466861), (571, 342217), (588, 38901), (616, 17862), (617, 123490), (631, 381399), (672, 54683), (679, 121744), (681, 197027), (717, 217040), (737, 134882), (739, 188069), (741, 50068), (844, 115), (855, 265411), (863, 104776), (870, 341749), (871, 47955), (885, 47738), (890, 52667), (898, 186359), (906, 149619), (913, 10668), (920, 188069), (930, 105078), (936, 98359), (938, 91135), (942, 28990), (950, 93747), (952, 389823), (958, 227804), (968, 182216), (969, 100559), (973, 167647), (978, 190316), (984, 219342), (985, 214749), (1005, 71774), (1006, 211622), (1009, 120660), (1031, 35073), (1045, 57901), (1056, 56250), (1061, 136173), (1068, 196560), (1090, 57541), (1104, 71994), (1114, 255177), (1137, 153172), (1149, 74837), (1152, 304071), (1153, 136173), (1155, 9405), (1163, 113703), (1173, 134585), (1182, 476882), (1219, 203418), (1227, 105126), (1246, 263698), (1268, 97439), (1275, 101518), (1293, 239891), (1297, 32346), (1342, 52371), (1359, 131679), (1403, 7142), (1417, 36131), (1469, 66604), (1498, 54667), (1499, 69989), (1525, 81772), (1548, 38901), (1578, 47853), (1582, 69408)]
def cs169 : List ℕ := [275416, 335097, 81772, 467820, 287312, 642132, 117261, 979597, 447640, 351606, 287197, 1000000, 999999, 628272, 150143, 758508, 1000000, 1000000, 999999, 474894, 1000000, 578011, 225260, 1000000, 1000000, 1000001, 999998, 1000000, 256312, 587061, 1000000, 1000000, 412842, 115, 1000001, 999999, 1000001, 999999, 1000001, 1000001, 1000000, 999998, 1000001, 967823, 1000000, 999999, 870350, 2651086, 382673, 678998, 1000000, 2208964, 903373, 1000000, 204574, 999999, 1000000, 1000001, 1000000, 1000000, 999999, 1000000, 1000001, 1700865, 999999, 1000000, 1000000, 999999, 1000001, 1000000, 1000000, 149619, 1000001, 1000000, 598546, 999999, 36131, 1000000, 1000000, 1000000, 1000001, 854499, 669332, 1000000, 1000000, 845199, 301374, 999999, 999999, 1000001, 1000000, 1000001, 1000000, 999998, 967893, 398210, 999999, 999999, 1000000, 1000000, 1216147, 1000001, 1809846, 1000000, 294206, 710627, 999999, 1000000, 1000000, 286238, 1000000, 1000001, 1000000, 888332, 1000000, 57541, 1000000, 814650, 1000000, 239641, 541082, 846423, 1000000, 1000001, 1000000, 862523, 167647, 238851, 585007, 1000001, 965531, 320819, 1000001, 1000001, 1000000, 1386494, 377069, 646484, 1000001, 1000001, 1000001, 413200, 1000000, 881713, 1000000, 203778, 1000000, 378360, 898703, 664592, 928227, 609367, 930536, 310916]
theorem loads169 : cs169.get =
    load (fun i : Fin entries169.length => support (entries169.get i).1)
      (fun i => (entries169.get i).2) := by
  apply load_eq_of_sparse_packed base cs169 support code
    entries169 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node169 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 102 (insert 135 (insert 63 (insert 51 (insert 47 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs169 support demand
    entries169 ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 102 (insert 135 (insert 63 (insert 51 (insert 47 (insert 100 ∅)))))) : Finset (Fin 154)) 1000000 30 loads169
  decide +kernel
def entries170 : List (Fin 1589 × ℕ) := [(20, 35), (30, 18), (37, 11), (75, 1), (122, 22), (273, 14), (344, 8), (431, 21), (466, 15), (475, 1), (479, 15), (484, 5), (506, 16), (515, 5), (541, 9), (542, 9), (551, 41), (571, 15), (572, 14), (588, 34), (617, 11), (623, 19), (629, 17), (680, 18), (681, 24), (717, 8), (736, 16), (741, 13), (762, 21), (777, 8), (842, 9), (843, 6), (855, 24), (870, 33), (871, 12), (882, 2), (883, 1), (886, 4), (894, 1), (897, 4), (898, 11), (906, 20), (920, 26), (936, 12), (938, 2), (950, 36), (958, 16), (973, 25), (978, 13), (984, 18), (985, 22), (1006, 19), (1009, 3), (1031, 15), (1045, 7), (1056, 2), (1061, 22), (1068, 15), (1086, 3), (1090, 2), (1104, 16), (1114, 18), (1137, 18), (1139, 1), (1153, 33), (1173, 19), (1182, 42), (1219, 19), (1227, 22), (1234, 24), (1268, 13), (1275, 18), (1297, 13), (1359, 28), (1403, 9), (1443, 1), (1471, 1), (1498, 8), (1525, 11), (1578, 4)]
def cs170 : List ℕ := [15, 47, 11, 55, 19, 66, 4, 92, 64, 27, 21, 100, 100, 78, 23, 77, 100, 100, 101, 53, 100, 69, 49, 99, 100, 99, 100, 98, 41, 53, 100, 99, 89, 0, 100, 100, 99, 100, 99, 100, 99, 100, 100, 100, 99, 99, 99, 273, 46, 59, 100, 246, 99, 100, 19, 100, 99, 99, 100, 90, 100, 99, 100, 156, 96, 99, 99, 99, 101, 100, 99, 20, 100, 99, 69, 100, 0, 98, 99, 101, 100, 80, 84, 80, 100, 99, 19, 99, 99, 100, 101, 100, 80, 99, 68, 37, 87, 98, 99, 101, 84, 99, 0, 73, 51, 98, 99, 100, 74, 0, 100, 100, 99, 99, 98, 2, 100, 58, 100, 42, 23, 99, 71, 99, 100, 84, 25, 40, 68, 101, 80, 43, 100, 99, 51, 111, 44, 80, 100, 101, 86, 44, 100, 101, 100, 25, 100, 45, 97, 75, 99, 43, 100, 56]
theorem loads170 : cs170.get =
    load (fun i : Fin entries170.length => support (entries170.get i).1)
      (fun i => (entries170.get i).2) := by
  apply load_eq_of_sparse_packed base cs170 support code
    entries170 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node170 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 102 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 135 (insert 63 (insert 51 (insert 47 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs170 support demand
    entries170 ((insert 102 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 135 (insert 63 (insert 51 (insert 47 (insert 100 ∅))))) : Finset (Fin 154)) 100 30 loads170
  decide +kernel
theorem node167 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 135 (insert 63 (insert 51 (insert 47 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 135 (insert 63 (insert 51 (insert 47 (insert 100 ∅))))) : Finset (Fin 154))
    102 node169 node170
def entries168 : List (Fin 1589 × ℕ) := [(20, 240), (30, 167), (120, 118), (122, 194), (273, 258), (398, 98), (431, 120), (466, 251), (472, 33), (479, 248), (506, 215), (515, 66), (542, 118), (551, 365), (571, 304), (588, 404), (616, 109), (617, 67), (623, 68), (629, 94), (631, 60), (681, 231), (717, 35), (739, 293), (741, 18), (762, 99), (798, 100), (843, 77), (855, 277), (863, 91), (870, 333), (882, 92), (886, 55), (896, 67), (897, 1), (898, 44), (906, 151), (920, 250), (930, 329), (934, 3), (936, 78), (938, 204), (952, 450), (965, 112), (973, 83), (978, 161), (984, 146), (985, 346), (1005, 11), (1006, 171), (1009, 330), (1031, 13), (1034, 85), (1045, 197), (1070, 160), (1075, 1), (1076, 66), (1104, 145), (1137, 175), (1139, 79), (1149, 231), (1153, 223), (1164, 252), (1173, 9), (1180, 96), (1181, 161), (1182, 165), (1219, 177), (1227, 150), (1234, 88), (1249, 91), (1261, 156), (1268, 66), (1269, 168), (1342, 84), (1359, 176), (1469, 14), (1496, 8), (1498, 30), (1525, 85), (1545, 129), (1576, 119), (1578, 30), (1582, 89)]
def cs168 : List ℕ := [251, 353, 118, 506, 278, 563, 119, 1000, 407, 391, 278, 967, 1000, 473, 148, 918, 1000, 1000, 1000, 370, 1000, 726, 449, 1000, 998, 999, 1000, 1000, 513, 394, 1000, 1000, 1000, 0, 999, 1000, 999, 999, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 990, 2530, 499, 658, 999, 2170, 680, 999, 12, 999, 999, 1000, 1000, 1000, 1000, 1001, 737, 1584, 1000, 999, 999, 999, 1000, 1001, 1000, 151, 999, 1001, 686, 1000, 0, 999, 998, 1000, 1000, 793, 859, 768, 1000, 1000, 274, 999, 999, 999, 999, 1000, 1000, 999, 1000, 319, 999, 999, 999, 1000, 1214, 999, 1000, 999, 356, 779, 1000, 851, 1000, 257, 1000, 999, 1000, 696, 1000, 91, 1000, 406, 1000, 228, 450, 999, 875, 782, 999, 999, 83, 353, 646, 805, 663, 258, 1000, 1000, 480, 174, 323, 726, 1000, 1000, 562, 740, 1000, 474, 824, 340, 999, 349, 1000, 323, 999, 179, 891, 335]
theorem loads168 : cs168.get =
    load (fun i : Fin entries168.length => support (entries168.get i).1)
      (fun i => (entries168.get i).2) := by
  apply load_eq_of_sparse_packed base cs168 support code
    entries168 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node168 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 135 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 63 (insert 51 (insert 47 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs168 support demand
    entries168 ((insert 135 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 63 (insert 51 (insert 47 (insert 100 ∅)))) : Finset (Fin 154)) 1000 30 loads168
  decide +kernel
theorem node165 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 63 (insert 51 (insert 47 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 63 (insert 51 (insert 47 (insert 100 ∅)))) : Finset (Fin 154))
    135 node167 node168
def entries166 : List (Fin 1589 × ℕ) := [(20, 15), (30, 33), (62, 11), (122, 3), (179, 7), (273, 21), (398, 18), (472, 18), (479, 26), (506, 19), (531, 1), (540, 13), (552, 5), (571, 12), (581, 13), (588, 36), (617, 16), (623, 9), (631, 3), (672, 16), (717, 12), (731, 21), (736, 20), (739, 22), (762, 25), (843, 24), (855, 19), (865, 11), (868, 14), (870, 41), (872, 16), (881, 6), (882, 5), (898, 16), (905, 14), (920, 9), (930, 41), (936, 4), (942, 1), (952, 31), (958, 6), (968, 25), (973, 23), (978, 18), (984, 18), (985, 4), (1005, 6), (1006, 29), (1009, 15), (1031, 3), (1045, 3), (1056, 15), (1061, 13), (1068, 30), (1070, 1), (1104, 2), (1114, 27), (1137, 8), (1149, 11), (1152, 20), (1153, 12), (1160, 17), (1173, 1), (1182, 36), (1219, 26), (1235, 1), (1261, 9), (1268, 10), (1280, 9), (1291, 2), (1335, 18), (1359, 20), (1384, 14), (1401, 3), (1403, 10), (1490, 1), (1498, 23), (1552, 14), (1561, 11)]
def cs166 : List ℕ := [9, 55, 18, 41, 26, 86, 0, 99, 50, 30, 25, 96, 99, 86, 18, 43, 98, 100, 100, 33, 98, 49, 59, 99, 91, 99, 100, 99, 12, 39, 99, 101, 100, 0, 100, 101, 99, 99, 59, 100, 100, 100, 59, 92, 100, 100, 100, 185, 45, 100, 100, 155, 48, 98, 1, 101, 100, 101, 100, 100, 100, 101, 100, 0, 99, 100, 100, 100, 101, 101, 101, 0, 78, 100, 65, 100, 0, 100, 99, 100, 101, 101, 28, 99, 95, 98, 50, 99, 100, 100, 100, 82, 78, 100, 95, 52, 99, 101, 100, 99, 143, 100, 99, 79, 18, 101, 100, 99, 100, 37, 99, 99, 100, 39, 101, 0, 100, 42, 99, 25, 91, 93, 99, 90, 100, 87, 23, 26, 38, 99, 74, 31, 100, 100, 69, 100, 35, 67, 100, 100, 85, 36, 100, 96, 100, 23, 89, 31, 79, 80, 77, 43, 100, 40]
theorem loads166 : cs166.get =
    load (fun i : Fin entries166.length => support (entries166.get i).1)
      (fun i => (entries166.get i).2) := by
  apply load_eq_of_sparse_packed base cs166 support code
    entries166 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node166 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 63 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 47 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs166 support demand
    entries166 ((insert 63 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 51 (insert 47 (insert 100 ∅))) : Finset (Fin 154)) 100 30 loads166
  decide +kernel
theorem node163 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 47 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 51 (insert 47 (insert 100 ∅))) : Finset (Fin 154))
    63 node165 node166
def entries164 : List (Fin 1589 × ℕ) := [(20, 242), (30, 112), (120, 63), (122, 135), (205, 142), (472, 344), (494, 82), (527, 1), (531, 267), (542, 369), (551, 311), (570, 35), (581, 132), (588, 458), (617, 209), (625, 67), (631, 71), (632, 11), (673, 42), (711, 90), (717, 112), (731, 358), (737, 27), (739, 197), (762, 112), (781, 147), (855, 124), (856, 363), (863, 85), (870, 344), (872, 191), (881, 46), (884, 53), (886, 91), (896, 23), (898, 114), (905, 84), (920, 275), (925, 72), (930, 325), (934, 204), (938, 84), (958, 130), (970, 30), (973, 381), (978, 117), (984, 153), (985, 103), (1006, 241), (1009, 65), (1031, 165), (1045, 109), (1056, 71), (1061, 155), (1090, 13), (1097, 95), (1104, 35), (1114, 310), (1128, 24), (1148, 35), (1149, 70), (1152, 137), (1160, 40), (1173, 36), (1182, 386), (1183, 91), (1219, 297), (1249, 36), (1261, 215), (1267, 71), (1275, 65), (1293, 48), (1359, 215), (1398, 15), (1403, 183), (1552, 103), (1561, 197), (1577, 119)]
def cs164 : List ℕ := [0, 512, 344, 539, 0, 599, 119, 938, 354, 85, 0, 975, 1000, 812, 488, 674, 1000, 1000, 999, 0, 1000, 536, 572, 1000, 1000, 999, 1001, 999, 336, 427, 1000, 999, 530, 0, 1000, 1000, 1000, 1000, 388, 1000, 828, 1000, 1000, 912, 999, 1000, 1001, 1963, 493, 1000, 1000, 0, 986, 1000, 240, 999, 1000, 1000, 1001, 1000, 1000, 899, 1000, 1000, 911, 887, 1000, 1000, 1000, 1000, 999, 72, 999, 1000, 639, 1001, 0, 1001, 1000, 1000, 1001, 804, 957, 876, 1001, 823, 286, 999, 1000, 1001, 1000, 909, 841, 1000, 906, 309, 1000, 1000, 1000, 1000, 959, 1001, 1000, 774, 302, 987, 1001, 1000, 1001, 197, 1001, 1000, 932, 590, 1001, 49, 1000, 637, 1000, 416, 848, 1000, 771, 1000, 1000, 828, 381, 546, 512, 999, 832, 416, 999, 1000, 447, 1000, 487, 785, 999, 1000, 999, 502, 1000, 999, 827, 381, 1000, 465, 929, 821, 959, 583, 1000, 577]
theorem loads164 : cs164.get =
    load (fun i : Fin entries164.length => support (entries164.get i).1)
      (fun i => (entries164.get i).2) := by
  apply load_eq_of_sparse_packed base cs164 support code
    entries164 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node164 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 51 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 100 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs164 support demand
    entries164 ((insert 51 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 47 (insert 100 ∅)) : Finset (Fin 154)) 1000 30 loads164
  decide +kernel
theorem node159 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 100 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 100 ∅)) : Finset (Fin 154))
    51 node163 node164
def entries161 : List (Fin 1589 × ℕ) := [(20, 192), (30, 107), (35, 53), (62, 153), (421, 116), (466, 174), (472, 395), (491, 35), (496, 70), (531, 324), (542, 209), (570, 63), (572, 45), (583, 190), (616, 425), (622, 22), (624, 219), (632, 304), (639, 35), (673, 23), (717, 302), (730, 246), (731, 290), (736, 74), (739, 186), (762, 67), (776, 31), (777, 226), (798, 27), (843, 129), (855, 285), (857, 151), (870, 360), (872, 32), (882, 133), (896, 153), (903, 158), (905, 53), (914, 137), (920, 133), (925, 117), (950, 220), (952, 446), (958, 80), (973, 102), (984, 363), (985, 192), (1005, 100), (1006, 239), (1009, 177), (1031, 14), (1045, 75), (1056, 41), (1068, 205), (1090, 82), (1104, 48), (1114, 205), (1122, 72), (1137, 220), (1149, 161), (1152, 105), (1153, 131), (1173, 100), (1178, 49), (1182, 365), (1183, 42), (1219, 296), (1235, 65), (1236, 134), (1260, 6), (1261, 15), (1263, 40), (1269, 167), (1275, 161), (1335, 63), (1545, 28), (1552, 86), (1559, 74), (1561, 172)]
def cs161 : List ℕ := [308, 296, 395, 488, 134, 579, 186, 999, 462, 153, 0, 999, 999, 861, 209, 133, 999, 999, 1000, 198, 999, 490, 0, 923, 740, 1000, 999, 998, 315, 772, 999, 998, 117, 0, 1000, 999, 1000, 998, 153, 1000, 999, 999, 437, 829, 998, 1000, 1000, 0, 610, 1000, 999, 1000, 999, 999, 100, 999, 1000, 998, 1000, 538, 1000, 1001, 999, 808, 1000, 1000, 1000, 999, 999, 2600, 998, 117, 830, 1001, 516, 1000, 49, 873, 1001, 750, 935, 1000, 824, 999, 1000, 891, 817, 1000, 999, 999, 1000, 924, 1000, 999, 337, 831, 999, 999, 1001, 1000, 1104, 999, 1000, 877, 172, 809, 1000, 999, 919, 221, 999, 1000, 1000, 555, 1000, 82, 1000, 515, 999, 150, 971, 1001, 1000, 1000, 999, 999, 102, 237, 802, 1001, 826, 322, 1000, 1000, 683, 1001, 363, 665, 1000, 1000, 922, 412, 1000, 838, 1000, 151, 1000, 404, 908, 631, 900, 417, 1000, 305]
theorem loads161 : cs161.get =
    load (fun i : Fin entries161.length => support (entries161.get i).1)
      (fun i => (entries161.get i).2) := by
  apply load_eq_of_sparse_packed base cs161 support code
    entries161 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node161 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 100 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs161 support demand
    entries161 ((insert 47 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 69 (insert 100 ∅)) : Finset (Fin 154)) 1000 30 loads161
  decide +kernel
def entries162 : List (Fin 1589 × ℕ) := [(20, 230), (30, 79), (122, 95), (179, 111), (205, 86), (273, 221), (398, 116), (466, 29), (472, 430), (475, 127), (479, 179), (484, 37), (491, 53), (542, 322), (552, 186), (572, 35), (583, 99), (617, 460), (691, 7), (717, 13), (736, 97), (739, 34), (762, 26), (842, 94), (843, 18), (855, 438), (870, 265), (872, 216), (882, 121), (886, 141), (903, 111), (905, 112), (918, 143), (920, 41), (922, 6), (949, 164), (950, 160), (952, 312), (958, 281), (973, 244), (978, 189), (984, 184), (985, 92), (1006, 246), (1009, 119), (1045, 72), (1068, 118), (1090, 171), (1114, 246), (1122, 68), (1123, 81), (1137, 63), (1138, 81), (1148, 85), (1153, 193), (1173, 148), (1182, 148), (1183, 269), (1219, 182), (1235, 121), (1236, 75), (1249, 29), (1261, 121), (1263, 7), (1269, 161), (1275, 68), (1356, 66), (1359, 104), (1401, 70), (1420, 188), (1425, 31), (1517, 133), (1561, 224)]
def cs162 : List ℕ := [104, 286, 496, 539, 320, 629, 217, 999, 316, 0, 0, 999, 999, 591, 423, 402, 998, 999, 1000, 35, 999, 565, 111, 999, 1000, 1000, 1000, 1000, 283, 341, 999, 1000, 518, 0, 1000, 1001, 1000, 819, 111, 1000, 1000, 856, 283, 951, 1000, 1000, 1000, 0, 206, 1000, 1000, 1000, 1000, 999, 148, 1000, 1001, 933, 495, 688, 1000, 342, 802, 609, 1001, 999, 1000, 1000, 999, 0, 1001, 0, 403, 1000, 617, 1000, 0, 1000, 1000, 935, 683, 417, 1001, 1000, 111, 919, 576, 1001, 1000, 999, 1000, 936, 1001, 1000, 354, 190, 1000, 1000, 1001, 1000, 1004, 999, 1000, 799, 608, 664, 1001, 1000, 592, 224, 998, 1000, 738, 565, 1001, 206, 1000, 698, 999, 244, 578, 955, 740, 875, 1000, 905, 244, 393, 647, 1000, 966, 392, 1000, 1000, 606, 1000, 392, 582, 1000, 999, 970, 392, 999, 890, 1001, 244, 999, 592, 1000, 638, 1000, 312, 999, 581]
theorem loads162 : cs162.get =
    load (fun i : Fin entries162.length => support (entries162.get i).1)
      (fun i => (entries162.get i).2) := by
  apply load_eq_of_sparse_packed base cs162 support code
    entries162 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node162 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 69 (insert 47 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 100 ∅) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs162 support demand
    entries162 ((insert 69 (insert 47 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 100 ∅) : Finset (Fin 154)) 1000 30 loads162
  decide +kernel
theorem node160 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 100 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 100 ∅) : Finset (Fin 154))
    69 node161 node162
theorem node158 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 100 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 71 (insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 100 ∅) : Finset (Fin 154))
    47 node159 node160
theorem node156 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 100 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 115 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 100 ∅) : Finset (Fin 154))
    71 node157 node158
#print axioms node156
end OmissionResidualCover
