import ResidualCoverProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries337 : List (Fin 1589 × ℕ) := [(43, 241), (179, 101), (344, 46), (360, 92), (386, 71), (472, 231), (484, 115), (494, 57), (507, 106), (542, 198), (572, 211), (588, 417), (617, 448), (623, 20), (624, 250), (625, 68), (632, 345), (692, 20), (763, 141), (797, 90), (798, 32), (799, 36), (842, 204), (843, 19), (844, 61), (847, 21), (850, 294), (853, 117), (856, 2), (870, 259), (882, 86), (885, 23), (897, 84), (906, 624), (910, 9), (912, 313), (922, 485), (925, 55), (930, 123), (940, 45), (948, 50), (950, 192), (951, 469), (952, 36), (955, 8), (967, 25), (968, 449), (970, 18), (973, 139), (980, 153), (981, 46), (984, 345), (985, 431), (1006, 42), (1009, 324), (1039, 189), (1045, 254), (1061, 38), (1076, 65), (1078, 141), (1082, 53), (1086, 38), (1108, 154), (1113, 16), (1114, 360), (1132, 3), (1139, 165), (1148, 8), (1149, 333), (1153, 79), (1177, 107), (1183, 375), (1219, 52), (1233, 60), (1261, 121), (1275, 173), (1280, 294), (1297, 23), (1358, 64), (1449, 12), (1489, 21), (1491, 99), (1501, 115), (1517, 93), (1561, 190), (1577, 17), (1578, 220)]
def cs337 : List ℕ := [419, 346, 252, 346, 220, 528, 571, 1000, 0, 106, 220, 999, 999, 0, 676, 422, 999, 1000, 999, 211, 999, 461, 717, 998, 1637, 1000, 998, 999, 347, 1000, 999, 999, 1000, 61, 999, 1000, 1000, 2013, 245, 2133, 1000, 839, 815, 1000, 999, 999, 886, 999, 193, 1000, 999, 999, 1000, 1000, 9, 1000, 999, 1000, 999, 999, 998, 436, 1000, 999, 1000, 1000, 1000, 1001, 999, 1000, 998, 999, 633, 1000, 487, 1000, 107, 1000, 1000, 999, 992, 999, 859, 2003, 999, 727, 555, 1000, 2033, 999, 1000, 999, 990, 2865, 1001, 361, 1000, 999, 1000, 998, 2683, 999, 999, 1000, 555, 1001, 1001, 999, 998, 672, 999, 2276, 999, 615, 1000, 1500, 972, 393, 999, 249, 1001, 1000, 557, 1000, 1000, 999, 246, 139, 647, 999, 1000, 254, 1000, 999, 1001, 1000, 579, 401, 1000, 999, 1001, 472, 1000, 811, 1001, 246, 999, 361, 707, 855, 935, 419, 408, 770]
theorem loads337 : cs337.get =
    load (fun i : Fin entries337.length => support (entries337.get i).1)
      (fun i => (entries337.get i).2) := by
  apply load_eq_of_sparse_packed base cs337 support code
    entries337 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node337 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 24 (insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs337 support demand
    entries337 ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 88 (insert 24 (insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154)) 1000 30 loads337
  decide +kernel
def entries338 : List (Fin 1589 × ℕ) := [(77, 23), (120, 77), (179, 373), (273, 26), (387, 152), (421, 143), (466, 49), (472, 102), (479, 173), (507, 293), (552, 63), (572, 156), (587, 123), (588, 89), (617, 274), (625, 145), (630, 320), (632, 206), (675, 133), (676, 49), (692, 102), (731, 83), (797, 36), (813, 106), (835, 79), (842, 218), (850, 345), (856, 148), (872, 16), (883, 113), (885, 121), (894, 40), (898, 109), (903, 20), (905, 161), (906, 601), (914, 101), (916, 52), (922, 375), (940, 193), (944, 58), (950, 122), (951, 327), (952, 133), (973, 293), (980, 29), (981, 89), (984, 261), (985, 316), (995, 8), (1009, 72), (1030, 34), (1041, 82), (1048, 254), (1061, 24), (1078, 137), (1082, 387), (1108, 135), (1114, 288), (1138, 91), (1139, 190), (1148, 157), (1149, 137), (1153, 101), (1167, 293), (1169, 19), (1219, 134), (1233, 91), (1241, 10), (1261, 286), (1275, 325), (1280, 186), (1358, 112), (1517, 229), (1537, 27), (1558, 31), (1565, 210), (1577, 134), (1578, 157)]
def cs338 : List ℕ := [347, 320, 129, 479, 330, 361, 520, 940, 27, 293, 180, 1001, 1001, 43, 314, 431, 1001, 1001, 1001, 156, 1001, 305, 935, 1001, 1833, 1001, 1000, 1001, 486, 1000, 973, 1001, 1001, 312, 1001, 915, 1002, 2103, 683, 2210, 1001, 1001, 865, 1001, 1001, 1001, 1001, 1001, 666, 1000, 1001, 1001, 1000, 1001, 0, 1001, 1002, 1000, 1001, 1000, 1000, 768, 1000, 1002, 843, 1001, 1000, 999, 1001, 1000, 1001, 1000, 875, 1001, 496, 1000, 0, 1000, 1001, 1001, 1001, 1001, 667, 1241, 992, 688, 380, 1001, 0, 1001, 1000, 1001, 1001, 2058, 1001, 346, 1000, 653, 1000, 1000, 1655, 1001, 1001, 999, 528, 532, 1000, 1000, 1000, 0, 1001, 2340, 851, 774, 983, 1467, 1000, 58, 1000, 581, 982, 933, 675, 1000, 1000, 1000, 293, 293, 387, 1000, 1000, 796, 1000, 1000, 426, 1000, 684, 762, 1000, 1000, 999, 430, 1000, 888, 616, 293, 1000, 988, 485, 718, 909, 618, 394, 719]
theorem loads338 : cs338.get =
    load (fun i : Fin entries338.length => support (entries338.get i).1)
      (fun i => (entries338.get i).2) := by
  apply load_eq_of_sparse_packed base cs338 support code
    entries338 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node338 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 24 (insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs338 support demand
    entries338 ((insert 88 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 24 (insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)) 1000 30 loads338
  decide +kernel
theorem node333 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 24 (insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 24 (insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154))
    88 node337 node338
def entries335 : List (Fin 1589 × ℕ) := [(13, 19), (35, 2), (229, 6), (341, 11), (344, 4), (386, 10), (420, 14), (479, 30), (484, 15), (491, 38), (514, 3), (530, 1), (542, 1), (572, 39), (588, 37), (617, 22), (623, 13), (624, 14), (631, 8), (632, 27), (690, 14), (763, 6), (798, 10), (799, 8), (842, 19), (850, 30), (870, 11), (882, 22), (886, 18), (897, 27), (906, 14), (912, 47), (921, 25), (922, 33), (925, 32), (930, 13), (940, 12), (946, 5), (951, 37), (959, 13), (960, 5), (967, 18), (968, 44), (969, 2), (973, 13), (977, 6), (978, 32), (980, 14), (984, 7), (985, 35), (994, 15), (1006, 6), (1009, 14), (1039, 23), (1045, 22), (1048, 35), (1061, 7), (1078, 2), (1082, 13), (1090, 5), (1108, 20), (1111, 3), (1113, 1), (1114, 22), (1126, 2), (1138, 4), (1139, 21), (1148, 14), (1149, 25), (1152, 5), (1177, 8), (1183, 36), (1212, 8), (1219, 27), (1221, 19), (1261, 6), (1263, 3), (1275, 14), (1297, 5), (1358, 5), (1379, 7), (1489, 8), (1561, 21)]
def cs335 : List ℕ := [24, 27, 38, 57, 30, 36, 38, 100, 5, 0, 10, 100, 99, 3, 1, 22, 100, 100, 73, 39, 100, 10, 64, 99, 14, 100, 100, 100, 33, 84, 100, 99, 84, 15, 101, 99, 100, 239, 21, 124, 99, 68, 100, 100, 99, 99, 72, 100, 5, 101, 100, 100, 100, 99, 19, 99, 100, 99, 100, 99, 101, 71, 100, 75, 100, 99, 101, 99, 101, 99, 88, 90, 101, 99, 40, 100, 31, 99, 100, 100, 100, 100, 90, 236, 80, 100, 30, 100, 262, 100, 102, 100, 100, 301, 95, 30, 100, 99, 100, 101, 268, 100, 99, 99, 65, 99, 100, 101, 100, 91, 100, 240, 100, 100, 99, 142, 91, 46, 101, 56, 100, 100, 79, 100, 100, 101, 21, 13, 79, 100, 100, 35, 100, 101, 100, 101, 81, 49, 101, 102, 100, 38, 101, 90, 100, 21, 101, 65, 74, 73, 97, 48, 42, 76]
theorem loads335 : cs335.get =
    load (fun i : Fin entries335.length => support (entries335.get i).1)
      (fun i => (entries335.get i).2) := by
  apply load_eq_of_sparse_packed base cs335 support code
    entries335 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node335 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 24 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs335 support demand
    entries335 ((insert 24 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 88 (insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)) 100 30 loads335
  decide +kernel
def entries336 : List (Fin 1589 × ℕ) := [(13, 19), (46, 14), (65, 13), (120, 3), (179, 46), (273, 1), (341, 3), (387, 6), (420, 7), (421, 16), (475, 19), (478, 1), (479, 32), (484, 7), (491, 23), (530, 4), (572, 18), (587, 27), (588, 19), (617, 23), (624, 5), (625, 17), (630, 14), (640, 8), (676, 29), (737, 10), (763, 8), (797, 8), (798, 2), (813, 18), (843, 6), (847, 1), (850, 18), (858, 16), (870, 10), (881, 7), (886, 20), (898, 2), (906, 28), (914, 16), (916, 7), (922, 23), (925, 21), (930, 6), (940, 25), (944, 9), (951, 33), (952, 14), (973, 37), (977, 13), (980, 2), (984, 11), (985, 30), (1009, 8), (1030, 9), (1039, 11), (1046, 4), (1048, 44), (1061, 8), (1078, 7), (1081, 2), (1082, 45), (1108, 18), (1111, 9), (1114, 24), (1139, 31), (1148, 3), (1149, 18), (1167, 13), (1169, 19), (1219, 29), (1261, 43), (1275, 31), (1312, 9), (1358, 18), (1379, 13), (1434, 9), (1468, 10), (1566, 7), (1567, 10)]
def cs336 : List ℕ := [18, 29, 20, 66, 33, 7, 53, 100, 9, 13, 13, 99, 100, 13, 14, 10, 100, 100, 100, 18, 99, 40, 101, 91, 28, 100, 87, 99, 42, 100, 100, 99, 101, 32, 100, 100, 98, 220, 81, 98, 99, 99, 101, 99, 100, 101, 99, 100, 82, 100, 100, 101, 98, 99, 0, 100, 100, 100, 101, 100, 101, 59, 98, 98, 100, 99, 101, 99, 100, 100, 98, 94, 99, 100, 58, 101, 0, 98, 100, 98, 100, 99, 75, 131, 101, 97, 54, 101, 0, 97, 100, 99, 100, 250, 99, 45, 101, 100, 99, 99, 153, 99, 100, 99, 67, 81, 100, 99, 100, 0, 98, 257, 97, 101, 99, 161, 99, 9, 101, 94, 86, 100, 82, 98, 99, 100, 37, 39, 49, 100, 99, 85, 99, 100, 31, 100, 99, 72, 99, 99, 74, 57, 90, 94, 68, 37, 100, 99, 37, 79, 99, 68, 37, 68]
theorem loads336 : cs336.get =
    load (fun i : Fin entries336.length => support (entries336.get i).1)
      (fun i => (entries336.get i).2) := by
  apply load_eq_of_sparse_packed base cs336 support code
    entries336 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node336 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 24 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs336 support demand
    entries336 ((insert 88 (insert 24 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)) 100 30 loads336
  decide +kernel
theorem node334 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 24 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 24 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154))
    88 node335 node336
theorem node327 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 83 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154))
    24 node333 node334
def entries331 : List (Fin 1589 × ℕ) := [(13, 170), (43, 29), (65, 175), (75, 65), (273, 9), (287, 70), (387, 82), (420, 164), (466, 114), (475, 35), (479, 284), (491, 116), (498, 165), (507, 231), (514, 320), (542, 11), (550, 108), (572, 32), (588, 370), (617, 231), (623, 108), (625, 414), (630, 99), (631, 132), (632, 20), (665, 46), (675, 21), (731, 444), (776, 113), (798, 18), (814, 23), (843, 114), (850, 289), (870, 279), (886, 168), (898, 227), (903, 145), (905, 93), (906, 239), (912, 290), (922, 555), (928, 88), (930, 149), (940, 166), (951, 95), (952, 396), (973, 172), (978, 109), (981, 24), (984, 233), (985, 364), (994, 151), (1009, 336), (1039, 344), (1041, 32), (1045, 143), (1046, 12), (1049, 34), (1061, 18), (1070, 99), (1076, 78), (1078, 12), (1082, 45), (1108, 265), (1114, 236), (1138, 7), (1149, 341), (1153, 12), (1177, 226), (1180, 11), (1181, 102), (1182, 265), (1219, 109), (1232, 37), (1234, 34), (1241, 79), (1257, 13), (1258, 190), (1266, 30), (1275, 159), (1323, 104), (1358, 144), (1499, 18), (1517, 185), (1537, 144), (1556, 4), (1586, 17), (1588, 158)]
def cs331 : List ℕ := [258, 126, 314, 433, 284, 144, 330, 982, 309, 423, 385, 999, 1000, 144, 105, 108, 999, 1000, 1000, 32, 999, 111, 597, 971, 1001, 1000, 1000, 999, 540, 635, 999, 1000, 1001, 151, 1001, 1000, 1000, 2083, 271, 1790, 1000, 1001, 806, 1001, 1000, 1001, 1000, 1000, 478, 1001, 1000, 1001, 845, 1001, 18, 1000, 1000, 1000, 1851, 1001, 1001, 1001, 1000, 999, 1000, 1000, 1000, 1000, 1001, 1000, 1000, 1001, 1000, 1000, 631, 1000, 226, 1001, 999, 1000, 1652, 1001, 681, 239, 1000, 1001, 1000, 999, 1000, 1001, 1001, 999, 1000, 1851, 1001, 381, 1000, 1000, 1000, 1001, 1943, 1001, 999, 900, 590, 1000, 1001, 1001, 1000, 113, 1000, 2116, 657, 806, 864, 1473, 1000, 265, 1000, 551, 716, 987, 999, 999, 1001, 1000, 398, 319, 611, 1000, 1000, 410, 999, 999, 999, 999, 739, 428, 1000, 1000, 999, 759, 1000, 999, 1000, 511, 984, 450, 1000, 853, 827, 709, 754, 447]
theorem loads331 : cs331.get =
    load (fun i : Fin entries331.length => support (entries331.get i).1)
      (fun i => (entries331.get i).2) := by
  apply load_eq_of_sparse_packed base cs331 support code
    entries331 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node331 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 83 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 80 (insert 58 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs331 support demand
    entries331 ((insert 83 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 80 (insert 58 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)) 1000 30 loads331
  decide +kernel
def entries332 : List (Fin 1589 × ℕ) := [(13, 17), (65, 13), (122, 23), (273, 4), (287, 8), (353, 9), (420, 12), (421, 19), (472, 17), (479, 17), (491, 6), (507, 27), (514, 17), (542, 11), (571, 2), (588, 49), (624, 18), (630, 30), (631, 3), (632, 11), (797, 11), (798, 5), (813, 7), (814, 4), (815, 4), (843, 9), (850, 40), (857, 2), (863, 3), (870, 33), (881, 2), (886, 12), (896, 3), (898, 17), (905, 10), (906, 18), (912, 8), (914, 15), (922, 44), (940, 5), (948, 17), (951, 6), (952, 41), (973, 37), (977, 2), (978, 6), (980, 1), (984, 5), (985, 43), (1009, 34), (1039, 11), (1041, 7), (1045, 8), (1046, 21), (1061, 5), (1070, 7), (1082, 11), (1108, 18), (1114, 30), (1133, 17), (1139, 3), (1149, 11), (1152, 8), (1153, 6), (1169, 18), (1177, 11), (1180, 4), (1182, 33), (1219, 1), (1221, 3), (1232, 1), (1258, 13), (1263, 10), (1267, 12), (1275, 13), (1358, 29), (1377, 2), (1459, 4), (1490, 1), (1494, 1), (1517, 18), (1537, 16), (1577, 10), (1588, 23)]
def cs332 : List ℕ := [32, 1, 53, 41, 17, 20, 36, 100, 27, 43, 20, 100, 100, 16, 23, 36, 100, 100, 100, 2, 100, 49, 66, 101, 99, 100, 99, 99, 53, 67, 101, 100, 100, 18, 99, 74, 99, 227, 0, 141, 93, 100, 82, 101, 100, 99, 100, 100, 23, 99, 99, 100, 100, 101, 3, 99, 100, 101, 109, 101, 99, 33, 100, 100, 100, 99, 99, 99, 99, 99, 100, 100, 100, 87, 81, 98, 11, 100, 101, 100, 0, 99, 77, 18, 63, 99, 83, 100, 99, 101, 99, 98, 100, 165, 101, 58, 100, 99, 100, 100, 164, 101, 88, 101, 18, 98, 100, 100, 100, 4, 92, 208, 62, 80, 97, 141, 100, 33, 100, 87, 47, 100, 100, 99, 101, 101, 48, 41, 62, 85, 100, 87, 99, 100, 100, 100, 59, 67, 100, 101, 100, 59, 100, 100, 100, 52, 100, 73, 99, 78, 87, 91, 89, 51]
theorem loads332 : cs332.get =
    load (fun i : Fin entries332.length => support (entries332.get i).1)
      (fun i => (entries332.get i).2) := by
  apply load_eq_of_sparse_packed base cs332 support code
    entries332 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node332 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 80 (insert 83 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 58 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs332 support demand
    entries332 ((insert 80 (insert 83 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 58 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)) 100 30 loads332
  decide +kernel
theorem node329 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 83 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 58 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 83 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 58 (insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154))
    80 node331 node332
def entries330 : List (Fin 1589 × ℕ) := [(13, 165), (122, 93), (179, 290), (273, 79), (387, 75), (421, 122), (475, 25), (479, 212), (484, 275), (485, 25), (506, 188), (515, 73), (531, 21), (572, 257), (585, 54), (617, 221), (625, 279), (630, 290), (632, 168), (797, 83), (798, 50), (813, 74), (843, 261), (846, 20), (850, 181), (858, 251), (863, 36), (870, 334), (886, 99), (896, 9), (905, 69), (906, 411), (912, 118), (914, 134), (916, 9), (922, 421), (924, 92), (928, 207), (930, 35), (940, 93), (951, 161), (952, 219), (973, 312), (978, 9), (980, 100), (981, 88), (984, 188), (985, 373), (988, 18), (994, 36), (1009, 184), (1041, 114), (1045, 147), (1049, 20), (1061, 8), (1070, 29), (1076, 14), (1078, 133), (1081, 102), (1082, 118), (1108, 176), (1114, 323), (1133, 30), (1139, 92), (1148, 65), (1149, 133), (1153, 104), (1169, 152), (1177, 321), (1181, 57), (1182, 195), (1219, 204), (1257, 22), (1258, 43), (1267, 205), (1275, 215), (1297, 106), (1358, 241), (1379, 13), (1466, 196), (1496, 22), (1537, 48), (1577, 195), (1588, 33)]
def cs330 : List ℕ := [241, 224, 213, 410, 212, 348, 446, 890, 48, 224, 108, 999, 999, 69, 195, 288, 1000, 999, 998, 257, 999, 374, 290, 1000, 999, 999, 940, 999, 577, 1000, 1000, 1001, 706, 188, 998, 1000, 1000, 1650, 532, 1622, 1001, 999, 281, 999, 999, 999, 1000, 999, 383, 902, 1000, 999, 1000, 998, 0, 999, 1000, 1000, 0, 1001, 999, 357, 1001, 1001, 1000, 998, 999, 1000, 1000, 999, 648, 806, 1000, 1000, 613, 1000, 321, 999, 1000, 1000, 999, 999, 571, 411, 458, 889, 845, 1000, 1000, 1000, 999, 978, 1000, 1559, 582, 620, 1000, 876, 1000, 1000, 1735, 999, 941, 1000, 591, 999, 1000, 999, 999, 57, 998, 2247, 761, 1000, 999, 1376, 1000, 195, 1000, 663, 564, 999, 999, 999, 1001, 1000, 633, 491, 739, 999, 1000, 850, 999, 1000, 999, 1000, 766, 733, 999, 999, 1000, 653, 999, 858, 1000, 690, 1000, 727, 999, 874, 999, 878, 733, 633]
theorem loads330 : cs330.get =
    load (fun i : Fin entries330.length => support (entries330.get i).1)
      (fun i => (entries330.get i).2) := by
  apply load_eq_of_sparse_packed base cs330 support code
    entries330 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node330 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 58 (insert 83 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs330 support demand
    entries330 ((insert 58 (insert 83 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 1000 30 loads330
  decide +kernel
theorem node328 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 83 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 83 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154))
    58 node329 node330
theorem node307 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 111 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154))
    83 node327 node328
def entries325 : List (Fin 1589 × ℕ) := [(13, 42), (35, 147), (77, 43), (179, 200), (387, 184), (466, 121), (472, 241), (479, 267), (588, 734), (617, 481), (624, 323), (630, 61), (631, 229), (632, 227), (674, 188), (675, 16), (681, 284), (692, 5), (799, 18), (813, 145), (818, 119), (843, 260), (844, 42), (847, 436), (850, 491), (868, 203), (869, 84), (870, 162), (881, 102), (886, 224), (906, 420), (914, 137), (916, 128), (922, 436), (930, 181), (940, 169), (951, 241), (952, 365), (968, 391), (969, 24), (978, 127), (984, 321), (1006, 348), (1020, 6), (1030, 57), (1045, 5), (1056, 100), (1061, 23), (1068, 56), (1070, 241), (1104, 158), (1126, 130), (1128, 174), (1133, 76), (1137, 199), (1138, 46), (1139, 158), (1171, 51), (1182, 274), (1212, 42), (1234, 37), (1235, 7), (1249, 190), (1257, 59), (1261, 15), (1267, 28), (1269, 129), (1276, 60), (1293, 7), (1320, 24), (1323, 281), (1354, 39), (1358, 111), (1443, 17), (1457, 162), (1517, 94), (1537, 73), (1556, 9), (1561, 136), (1577, 198), (1578, 68)]
def cs325 : List ℕ := [436, 0, 792, 491, 335, 382, 360, 1563, 220, 0, 476, 1000, 1000, 220, 309, 368, 1000, 1000, 1000, 0, 999, 96, 934, 1000, 1000, 1671, 999, 999, 394, 1001, 1000, 1000, 828, 93, 1000, 1000, 1644, 2239, 745, 1838, 1000, 1000, 1000, 1000, 1000, 1000, 1001, 2226, 237, 1000, 1000, 1000, 1001, 1000, 51, 1001, 1000, 1000, 1000, 1015, 1001, 37, 796, 999, 889, 1001, 1000, 1001, 1000, 1001, 990, 574, 999, 1000, 510, 1000, 0, 1000, 1000, 999, 999, 1000, 499, 1000, 1711, 758, 635, 1001, 1000, 999, 1000, 600, 1000, 2438, 1291, 118, 901, 836, 1000, 995, 2599, 1000, 1000, 1001, 773, 803, 1001, 999, 1000, 569, 1000, 110, 999, 516, 1001, 1699, 999, 340, 1000, 589, 1000, 1001, 989, 998, 999, 598, 0, 24, 822, 1000, 998, 256, 1000, 999, 1000, 1000, 51, 260, 999, 999, 1000, 292, 999, 999, 1000, 0, 762, 620, 999, 548, 876, 399, 914, 102]
theorem loads325 : cs325.get =
    load (fun i : Fin entries325.length => support (entries325.get i).1)
      (fun i => (entries325.get i).2) := by
  apply load_eq_of_sparse_packed base cs325 support code
    entries325 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node325 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 94 (insert 36 (insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs325 support demand
    entries325 ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 25 (insert 94 (insert 36 (insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))))))) : Finset (Fin 154)) 1000 30 loads325
  decide +kernel
def entries326 : List (Fin 1589 × ℕ) := [(273, 19), (314, 10), (430, 6), (472, 24), (478, 19), (479, 2), (484, 5), (494, 23), (572, 5), (588, 48), (617, 43), (624, 41), (631, 33), (632, 28), (639, 12), (640, 4), (673, 3), (674, 4), (681, 22), (692, 16), (797, 13), (813, 12), (843, 9), (850, 45), (863, 6), (870, 8), (871, 4), (881, 25), (889, 1), (893, 2), (898, 8), (905, 17), (906, 30), (914, 26), (916, 12), (922, 59), (924, 4), (930, 23), (951, 19), (952, 35), (968, 18), (973, 19), (976, 13), (978, 11), (1005, 5), (1006, 22), (1030, 17), (1045, 20), (1056, 9), (1061, 13), (1070, 29), (1075, 2), (1090, 9), (1100, 5), (1104, 1), (1108, 2), (1126, 5), (1128, 20), (1133, 24), (1137, 11), (1177, 7), (1182, 34), (1183, 5), (1212, 12), (1219, 22), (1235, 7), (1249, 11), (1266, 3), (1276, 4), (1293, 6), (1323, 1), (1358, 28), (1370, 10), (1379, 8), (1443, 5), (1481, 2), (1501, 10), (1517, 13), (1561, 20), (1577, 29)]
def cs326 : List ℕ := [28, 22, 24, 67, 21, 5, 42, 118, 0, 6, 8, 100, 100, 4, 29, 54, 100, 99, 82, 5, 100, 11, 66, 100, 100, 0, 101, 100, 41, 89, 100, 100, 99, 0, 100, 101, 156, 255, 45, 190, 101, 100, 100, 100, 100, 99, 101, 219, 0, 100, 98, 100, 100, 100, 0, 100, 99, 101, 99, 166, 99, 24, 91, 100, 101, 100, 101, 101, 99, 101, 101, 56, 99, 100, 73, 102, 7, 101, 101, 99, 96, 100, 72, 96, 143, 101, 65, 100, 100, 101, 99, 61, 101, 209, 140, 50, 101, 94, 100, 100, 260, 100, 99, 101, 82, 90, 100, 101, 100, 50, 100, 19, 100, 60, 101, 182, 100, 51, 100, 74, 82, 101, 99, 101, 100, 52, 26, 19, 64, 99, 101, 54, 100, 101, 99, 99, 26, 52, 100, 100, 100, 48, 101, 96, 100, 26, 91, 69, 98, 52, 81, 63, 100, 40]
theorem loads326 : cs326.get =
    load (fun i : Fin entries326.length => support (entries326.get i).1)
      (fun i => (entries326.get i).2) := by
  apply load_eq_of_sparse_packed base cs326 support code
    entries326 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node326 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 94 (insert 36 (insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs326 support demand
    entries326 ((insert 25 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 94 (insert 36 (insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))))))) : Finset (Fin 154)) 100 30 loads326
  decide +kernel
theorem node323 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 94 (insert 36 (insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 94 (insert 36 (insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))))))) : Finset (Fin 154))
    25 node325 node326
def entries324 : List (Fin 1589 × ℕ) := [(33, 9), (179, 20), (273, 6), (387, 14), (431, 1), (472, 28), (475, 9), (479, 40), (494, 27), (507, 2), (515, 6), (550, 10), (587, 44), (617, 33), (624, 6), (625, 14), (632, 58), (639, 1), (640, 7), (673, 5), (675, 5), (777, 3), (797, 4), (798, 4), (799, 18), (813, 11), (817, 11), (818, 5), (819, 9), (846, 34), (847, 1), (855, 39), (856, 2), (868, 13), (870, 16), (886, 10), (906, 41), (911, 13), (912, 5), (916, 1), (922, 49), (928, 8), (934, 8), (940, 16), (951, 24), (952, 38), (975, 4), (976, 4), (978, 23), (1006, 42), (1012, 6), (1030, 27), (1045, 4), (1061, 27), (1068, 4), (1070, 22), (1104, 1), (1123, 10), (1126, 17), (1128, 15), (1133, 10), (1137, 22), (1139, 1), (1153, 20), (1181, 11), (1182, 38), (1183, 8), (1219, 15), (1232, 13), (1234, 28), (1249, 19), (1276, 10), (1323, 9), (1379, 10), (1443, 11), (1457, 26), (1499, 4), (1517, 11), (1561, 2), (1577, 18)]
def cs324 : List ℕ := [26, 49, 29, 24, 40, 76, 29, 171, 0, 2, 55, 99, 100, 0, 18, 28, 99, 99, 100, 0, 99, 10, 64, 99, 99, 100, 100, 99, 24, 96, 94, 100, 82, 0, 100, 100, 154, 207, 56, 176, 100, 100, 78, 100, 100, 99, 101, 168, 48, 100, 99, 100, 100, 100, 12, 100, 101, 99, 100, 137, 100, 50, 85, 100, 79, 99, 99, 101, 100, 100, 87, 64, 100, 100, 69, 99, 0, 100, 101, 100, 100, 100, 74, 100, 106, 100, 58, 101, 101, 100, 99, 64, 99, 175, 0, 35, 101, 101, 101, 101, 235, 99, 99, 85, 61, 101, 99, 100, 100, 13, 99, 0, 50, 87, 101, 202, 100, 46, 100, 71, 16, 101, 94, 100, 101, 64, 0, 27, 94, 100, 101, 49, 100, 100, 75, 100, 0, 41, 100, 100, 100, 33, 100, 100, 100, 11, 89, 58, 100, 24, 100, 32, 100, 31]
theorem loads324 : cs324.get =
    load (fun i : Fin entries324.length => support (entries324.get i).1)
      (fun i => (entries324.get i).2) := by
  apply load_eq_of_sparse_packed base cs324 support code
    entries324 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node324 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 94 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs324 support demand
    entries324 ((insert 94 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 36 (insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))))) : Finset (Fin 154)) 100 30 loads324
  decide +kernel
theorem node321 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 36 (insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))))) : Finset (Fin 154))
    94 node323 node324
def entries322 : List (Fin 1589 × ℕ) := [(35, 71), (137, 63), (179, 182), (273, 179), (420, 51), (430, 54), (479, 425), (491, 136), (494, 72), (506, 143), (507, 108), (514, 260), (588, 479), (617, 418), (630, 194), (631, 100), (632, 219), (690, 8), (692, 104), (731, 183), (737, 243), (799, 294), (813, 60), (818, 165), (819, 37), (843, 164), (855, 389), (856, 179), (870, 260), (871, 13), (883, 112), (886, 104), (896, 75), (904, 356), (906, 298), (914, 188), (916, 128), (922, 437), (930, 269), (940, 147), (951, 281), (952, 204), (968, 217), (978, 302), (984, 82), (1005, 44), (1006, 459), (1030, 192), (1045, 35), (1056, 146), (1061, 35), (1068, 92), (1070, 168), (1104, 8), (1123, 34), (1126, 92), (1128, 189), (1137, 122), (1139, 177), (1152, 60), (1154, 19), (1182, 259), (1219, 347), (1234, 130), (1241, 61), (1249, 156), (1251, 256), (1267, 10), (1276, 30), (1320, 17), (1323, 351), (1354, 98), (1358, 85), (1370, 116), (1517, 91), (1556, 76), (1561, 86), (1577, 80)]
def cs322 : List ℕ := [85, 347, 0, 347, 425, 639, 307, 929, 71, 251, 260, 999, 1000, 84, 80, 80, 971, 1000, 1000, 0, 999, 85, 661, 1000, 985, 1000, 861, 999, 10, 954, 999, 1000, 1000, 0, 1001, 1000, 90, 2136, 581, 2141, 498, 1001, 999, 1000, 1000, 1000, 667, 1403, 495, 1001, 999, 1000, 999, 1000, 0, 1000, 1000, 1000, 1000, 1502, 1000, 600, 983, 628, 818, 1000, 1000, 999, 1000, 999, 948, 898, 999, 999, 616, 1000, 0, 1000, 1001, 1000, 1000, 1001, 1001, 1001, 1293, 1000, 554, 1002, 1001, 1000, 1000, 524, 1001, 2377, 1001, 373, 1000, 1002, 1000, 1001, 2804, 1000, 1001, 1001, 586, 810, 1001, 1000, 1001, 303, 1000, 0, 976, 510, 999, 2260, 1001, 278, 1000, 807, 924, 1000, 1000, 1000, 1001, 581, 0, 51, 555, 1000, 1000, 314, 999, 1000, 1000, 1000, 0, 249, 1000, 1000, 1000, 168, 1000, 921, 1000, 0, 732, 370, 787, 540, 960, 667, 823, 91]
theorem loads322 : cs322.get =
    load (fun i : Fin entries322.length => support (entries322.get i).1)
      (fun i => (entries322.get i).2) := by
  apply load_eq_of_sparse_packed base cs322 support code
    entries322 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node322 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 36 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs322 support demand
    entries322 ((insert 36 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154)) 1000 30 loads322
  decide +kernel
theorem node319 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 84 (insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154))
    36 node321 node322
def entries320 : List (Fin 1589 × ℕ) := [(35, 4), (77, 12), (137, 9), (273, 7), (387, 18), (420, 8), (475, 3), (479, 28), (485, 17), (491, 13), (494, 8), (497, 11), (507, 18), (515, 11), (572, 11), (587, 39), (617, 39), (623, 5), (624, 19), (625, 1), (629, 1), (630, 31), (639, 7), (640, 18), (675, 25), (692, 3), (737, 14), (799, 3), (819, 2), (843, 29), (847, 13), (850, 10), (855, 34), (856, 3), (868, 2), (870, 16), (886, 21), (897, 5), (898, 36), (904, 16), (906, 36), (912, 7), (914, 18), (916, 5), (922, 47), (927, 25), (928, 12), (930, 7), (934, 13), (940, 20), (951, 25), (952, 15), (968, 3), (978, 36), (1006, 30), (1030, 5), (1045, 14), (1056, 23), (1061, 11), (1070, 36), (1102, 18), (1104, 1), (1126, 14), (1128, 2), (1133, 20), (1137, 19), (1139, 6), (1153, 6), (1173, 14), (1182, 13), (1219, 21), (1248, 5), (1249, 16), (1251, 29), (1276, 33), (1322, 3), (1323, 5), (1354, 12), (1370, 1), (1379, 6), (1517, 16), (1556, 3), (1577, 17), (1578, 13)]
def cs320 : List ℕ := [0, 21, 13, 34, 41, 58, 59, 83, 15, 18, 44, 99, 99, 4, 42, 30, 98, 99, 99, 11, 99, 19, 80, 99, 100, 98, 99, 99, 37, 61, 99, 99, 100, 0, 100, 99, 99, 249, 56, 178, 99, 93, 99, 99, 100, 99, 99, 205, 0, 100, 99, 100, 99, 100, 27, 98, 100, 100, 99, 161, 100, 41, 99, 99, 100, 99, 101, 100, 100, 100, 101, 73, 99, 101, 52, 100, 0, 100, 101, 99, 100, 100, 85, 100, 0, 99, 42, 101, 100, 100, 100, 47, 100, 227, 78, 19, 100, 100, 100, 101, 223, 99, 101, 86, 89, 100, 100, 100, 101, 3, 99, 14, 57, 100, 100, 184, 100, 13, 99, 78, 45, 100, 101, 100, 101, 63, 0, 0, 20, 100, 100, 24, 100, 100, 96, 102, 14, 33, 100, 100, 101, 50, 100, 71, 100, 0, 93, 49, 92, 21, 64, 54, 97, 33]
theorem loads320 : cs320.get =
    load (fun i : Fin entries320.length => support (entries320.get i).1)
      (fun i => (entries320.get i).2) := by
  apply load_eq_of_sparse_packed base cs320 support code
    entries320 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node320 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 84 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs320 support demand
    entries320 ((insert 84 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)) 100 30 loads320
  decide +kernel
theorem node315 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 47 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154))
    84 node319 node320
def entries317 : List (Fin 1589 × ℕ) := [(13, 160), (35, 228), (46, 63), (77, 12), (179, 211), (387, 59), (420, 205), (421, 40), (472, 93), (475, 144), (479, 418), (491, 262), (494, 45), (507, 324), (542, 208), (583, 14), (617, 215), (625, 147), (630, 108), (632, 286), (673, 59), (675, 75), (730, 193), (799, 65), (819, 133), (843, 275), (844, 3), (850, 326), (853, 55), (855, 72), (885, 305), (886, 165), (890, 104), (894, 71), (903, 8), (905, 37), (906, 381), (912, 13), (914, 90), (922, 488), (951, 374), (952, 236), (968, 242), (973, 85), (978, 376), (1005, 221), (1006, 255), (1030, 5), (1045, 32), (1056, 76), (1061, 112), (1068, 36), (1070, 197), (1090, 15), (1104, 31), (1126, 237), (1128, 66), (1133, 62), (1137, 252), (1139, 106), (1152, 67), (1153, 138), (1173, 123), (1177, 163), (1182, 395), (1219, 79), (1249, 192), (1266, 41), (1323, 282), (1348, 95), (1358, 296), (1370, 85), (1400, 26), (1471, 81), (1491, 156), (1517, 153), (1556, 138), (1559, 215)]
def cs317 : List ℕ := [299, 79, 253, 549, 418, 355, 478, 1094, 228, 324, 12, 934, 1001, 228, 283, 156, 938, 1000, 1000, 0, 1001, 333, 211, 1001, 999, 1000, 792, 1001, 469, 999, 1001, 1001, 777, 3, 999, 1000, 1000, 1454, 223, 1743, 968, 1000, 483, 1001, 1001, 1000, 1854, 0, 714, 1000, 1000, 1001, 1000, 1000, 123, 1001, 998, 1001, 983, 1354, 999, 983, 1000, 1001, 999, 1000, 1000, 1001, 1000, 1000, 1000, 999, 1000, 1000, 745, 998, 163, 1000, 1000, 1000, 999, 1000, 1002, 1000, 1000, 941, 575, 998, 1000, 1000, 1000, 794, 999, 2087, 581, 236, 1001, 999, 1000, 999, 2293, 1001, 999, 1000, 757, 821, 999, 888, 1000, 242, 1000, 208, 1000, 828, 999, 1883, 1000, 395, 999, 628, 817, 999, 932, 999, 1000, 715, 248, 85, 695, 999, 1000, 505, 943, 1000, 954, 999, 371, 405, 999, 1000, 1000, 405, 1000, 987, 999, 248, 795, 781, 866, 556, 778, 659, 810, 85]
theorem loads317 : cs317.get =
    load (fun i : Fin entries317.length => support (entries317.get i).1)
      (fun i => (entries317.get i).2) := by
  apply load_eq_of_sparse_packed base cs317 support code
    entries317 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node317 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs317 support demand
    entries317 ((insert 47 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)) 1000 30 loads317
  decide +kernel
def entries318 : List (Fin 1589 × ℕ) := [(35, 15), (37, 14), (75, 2), (77, 20), (205, 12), (273, 9), (387, 21), (420, 5), (421, 25), (466, 39), (472, 6), (478, 11), (491, 28), (507, 9), (514, 5), (529, 3), (550, 6), (569, 4), (617, 56), (630, 42), (632, 2), (691, 1), (692, 8), (730, 11), (731, 1), (737, 14), (777, 19), (799, 4), (818, 19), (819, 13), (843, 31), (850, 32), (855, 12), (872, 11), (885, 26), (886, 7), (905, 13), (906, 14), (912, 9), (914, 16), (922, 55), (924, 2), (925, 17), (951, 44), (952, 17), (968, 11), (973, 1), (978, 46), (985, 4), (1005, 8), (1006, 43), (1010, 9), (1030, 6), (1056, 11), (1068, 4), (1070, 18), (1126, 15), (1137, 9), (1138, 1), (1139, 11), (1153, 7), (1154, 1), (1164, 2), (1173, 15), (1182, 31), (1219, 11), (1232, 27), (1249, 19), (1269, 1), (1323, 41), (1324, 13), (1358, 6), (1370, 5), (1491, 35), (1517, 11), (1561, 15), (1586, 5)]
def cs318 : List ℕ := [45, 16, 6, 43, 11, 41, 39, 78, 29, 14, 27, 100, 100, 42, 22, 41, 100, 100, 100, 27, 100, 7, 0, 67, 100, 100, 100, 101, 20, 86, 100, 99, 94, 0, 100, 93, 63, 157, 34, 179, 42, 100, 41, 99, 101, 101, 6, 0, 12, 100, 100, 100, 100, 100, 15, 101, 101, 100, 99, 84, 100, 101, 99, 54, 95, 100, 101, 101, 99, 100, 100, 101, 99, 101, 73, 101, 0, 100, 100, 100, 100, 100, 100, 100, 14, 101, 75, 101, 101, 100, 100, 60, 100, 231, 46, 19, 100, 100, 100, 100, 266, 101, 100, 99, 89, 67, 100, 100, 100, 26, 99, 20, 100, 60, 100, 220, 100, 32, 100, 84, 82, 101, 100, 101, 101, 68, 1, 1, 62, 101, 101, 25, 98, 101, 101, 101, 16, 14, 101, 101, 101, 34, 101, 80, 101, 1, 96, 44, 82, 57, 92, 69, 75, 30]
theorem loads318 : cs318.get =
    load (fun i : Fin entries318.length => support (entries318.get i).1)
      (fun i => (entries318.get i).2) := by
  apply load_eq_of_sparse_packed base cs318 support code
    entries318 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node318 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs318 support demand
    entries318 ((insert 46 (insert 47 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)) 100 30 loads318
  decide +kernel
theorem node316 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154))
    46 node317 node318
theorem node313 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 7 (insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154))
    47 node315 node316
def entries314 : List (Fin 1589 × ℕ) := [(35, 17), (62, 1), (65, 4), (120, 5), (179, 23), (420, 3), (421, 3), (491, 20), (496, 8), (507, 13), (515, 2), (526, 24), (530, 15), (542, 19), (572, 23), (588, 49), (617, 39), (624, 32), (630, 17), (632, 15), (640, 6), (674, 2), (675, 16), (691, 3), (692, 6), (730, 3), (813, 8), (818, 7), (843, 31), (849, 11), (850, 22), (855, 28), (866, 1), (869, 1), (884, 6), (885, 20), (886, 27), (904, 1), (906, 48), (914, 24), (916, 16), (922, 53), (930, 12), (950, 9), (951, 35), (952, 18), (968, 41), (973, 5), (978, 37), (1006, 34), (1030, 5), (1045, 4), (1056, 6), (1068, 24), (1070, 10), (1102, 4), (1104, 13), (1126, 2), (1128, 6), (1137, 20), (1139, 12), (1173, 20), (1177, 4), (1182, 25), (1234, 6), (1241, 4), (1249, 27), (1251, 12), (1266, 1), (1275, 12), (1323, 31), (1370, 20), (1380, 1), (1434, 7), (1443, 2), (1491, 10), (1517, 29), (1556, 2), (1577, 28)]
def cs314 : List ℕ := [0, 0, 0, 33, 0, 45, 78, 0, 32, 18, 4, 79, 100, 40, 47, 43, 56, 100, 100, 24, 100, 6, 72, 62, 100, 99, 101, 99, 37, 96, 89, 100, 101, 0, 100, 101, 99, 233, 47, 198, 70, 100, 100, 101, 100, 100, 101, 99, 32, 99, 100, 99, 100, 101, 20, 100, 100, 100, 100, 116, 99, 70, 99, 99, 101, 100, 100, 101, 99, 99, 100, 101, 98, 99, 78, 101, 4, 101, 99, 100, 99, 101, 81, 100, 96, 101, 57, 99, 100, 100, 100, 46, 100, 221, 100, 37, 101, 91, 99, 99, 242, 100, 99, 100, 73, 66, 100, 101, 99, 41, 100, 25, 87, 85, 100, 169, 99, 25, 101, 76, 100, 99, 91, 100, 99, 79, 9, 5, 64, 100, 99, 34, 100, 98, 100, 100, 29, 53, 99, 99, 99, 35, 99, 60, 100, 9, 99, 54, 92, 62, 97, 64, 69, 21]
theorem loads314 : cs314.get =
    load (fun i : Fin entries314.length => support (entries314.get i).1)
      (fun i => (entries314.get i).2) := by
  apply load_eq_of_sparse_packed base cs314 support code
    entries314 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node314 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 7 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs314 support demand
    entries314 ((insert 7 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 100 30 loads314
  decide +kernel
theorem node309 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 59 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154))
    7 node313 node314
def entries311 : List (Fin 1589 × ℕ) := [(77, 110), (179, 126), (273, 198), (420, 94), (421, 170), (466, 186), (469, 107), (471, 12), (472, 78), (478, 51), (491, 295), (507, 138), (530, 104), (531, 103), (542, 182), (588, 664), (617, 510), (623, 57), (624, 280), (625, 128), (630, 80), (632, 210), (673, 105), (675, 134), (763, 213), (799, 17), (813, 138), (816, 7), (817, 47), (818, 255), (819, 16), (843, 291), (847, 284), (850, 384), (855, 148), (863, 50), (868, 35), (869, 110), (872, 204), (884, 14), (885, 237), (886, 171), (897, 70), (898, 24), (904, 136), (906, 331), (914, 143), (917, 67), (919, 133), (921, 19), (930, 68), (940, 121), (951, 413), (952, 149), (968, 110), (973, 57), (978, 424), (1005, 21), (1006, 416), (1010, 92), (1045, 44), (1056, 92), (1068, 121), (1070, 98), (1090, 163), (1104, 38), (1126, 2), (1128, 189), (1137, 59), (1139, 130), (1152, 42), (1173, 117), (1182, 375), (1219, 83), (1241, 63), (1249, 113), (1251, 241), (1268, 70), (1280, 199), (1308, 42), (1323, 304), (1380, 20), (1551, 114), (1561, 203)]
def cs311 : List ℕ := [385, 389, 374, 467, 51, 347, 315, 1000, 0, 188, 165, 1000, 1000, 595, 292, 0, 1000, 1001, 2000, 70, 1000, 20, 884, 701, 1001, 999, 1001, 1000, 689, 559, 1000, 999, 1000, 0, 1001, 1001, 1002, 2038, 304, 1718, 778, 1000, 1000, 840, 999, 1000, 1000, 1001, 126, 1000, 1000, 1001, 1000, 1000, 117, 1000, 1000, 1001, 1000, 0, 1000, 784, 896, 1001, 866, 1000, 1001, 1000, 1000, 1000, 1001, 975, 1000, 999, 625, 1001, 0, 1001, 1000, 999, 1002, 1001, 1001, 999, 1000, 1000, 795, 1000, 999, 1000, 1000, 565, 1001, 1835, 1000, 257, 1000, 1000, 1000, 1000, 2319, 1000, 999, 1000, 830, 597, 1000, 1000, 1000, 313, 1000, 174, 837, 664, 999, 1679, 999, 375, 1000, 732, 784, 1000, 1000, 999, 1000, 649, 57, 57, 681, 1000, 1000, 208, 999, 1000, 942, 1001, 174, 281, 1000, 1000, 1000, 272, 1000, 860, 999, 57, 966, 394, 887, 667, 979, 644, 989, 120]
theorem loads311 : cs311.get =
    load (fun i : Fin entries311.length => support (entries311.get i).1)
      (fun i => (entries311.get i).2) := by
  apply load_eq_of_sparse_packed base cs311 support code
    entries311 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node311 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 59 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 18 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs311 support demand
    entries311 ((insert 59 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 18 (insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 1000 30 loads311
  decide +kernel
def entries312 : List (Fin 1589 × ℕ) := [(10, 26), (37, 24), (43, 27), (77, 23), (179, 4), (205, 10), (352, 9), (387, 8), (421, 10), (466, 59), (478, 21), (483, 15), (491, 26), (527, 8), (550, 16), (572, 13), (583, 16), (585, 12), (588, 50), (617, 51), (624, 14), (625, 12), (630, 9), (632, 21), (675, 11), (676, 5), (799, 14), (813, 19), (816, 2), (817, 3), (818, 25), (819, 14), (843, 20), (857, 6), (870, 6), (885, 26), (894, 3), (896, 4), (897, 3), (898, 6), (905, 21), (906, 36), (914, 23), (917, 7), (930, 10), (940, 33), (951, 47), (952, 12), (968, 9), (978, 41), (1006, 41), (1010, 32), (1012, 9), (1045, 8), (1056, 1), (1068, 4), (1070, 22), (1090, 15), (1100, 1), (1123, 5), (1126, 9), (1128, 13), (1139, 7), (1153, 6), (1154, 6), (1163, 14), (1167, 11), (1173, 7), (1182, 12), (1183, 22), (1241, 2), (1251, 39), (1267, 7), (1308, 1), (1322, 4), (1323, 22), (1501, 20), (1517, 9), (1561, 23), (1566, 4)]
def cs312 : List ℕ := [59, 0, 26, 0, 47, 39, 68, 80, 24, 0, 23, 100, 82, 26, 50, 16, 100, 100, 0, 37, 100, 95, 87, 80, 98, 99, 100, 99, 60, 84, 100, 99, 99, 11, 100, 72, 100, 182, 65, 105, 96, 99, 100, 101, 99, 99, 83, 100, 8, 100, 100, 100, 99, 100, 7, 100, 99, 99, 99, 0, 100, 43, 75, 100, 69, 88, 100, 100, 101, 99, 100, 99, 100, 100, 100, 101, 0, 101, 101, 100, 101, 100, 99, 99, 99, 101, 80, 101, 100, 101, 101, 52, 100, 217, 100, 64, 102, 100, 100, 100, 254, 100, 99, 99, 80, 96, 101, 100, 100, 32, 101, 7, 89, 57, 101, 231, 92, 40, 101, 93, 72, 101, 97, 100, 101, 59, 0, 14, 65, 100, 101, 43, 101, 101, 100, 101, 7, 23, 101, 98, 101, 29, 101, 75, 101, 0, 101, 35, 89, 42, 101, 61, 100, 24]
theorem loads312 : cs312.get =
    load (fun i : Fin entries312.length => support (entries312.get i).1)
      (fun i => (entries312.get i).2) := by
  apply load_eq_of_sparse_packed base cs312 support code
    entries312 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node312 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 18 (insert 59 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs312 support demand
    entries312 ((insert 18 (insert 59 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)) 100 30 loads312
  decide +kernel
theorem node310 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 59 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 59 (insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    18 node311 node312
theorem node308 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 111 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    59 node309 node310
theorem node299 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 93 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    111 node307 node308
def entries305 : List (Fin 1589 × ℕ) := [(177, 161), (421, 27), (475, 34), (479, 223), (485, 181), (494, 200), (498, 29), (515, 13), (531, 49), (541, 96), (571, 126), (588, 555), (616, 318), (617, 201), (625, 336), (629, 124), (631, 7), (632, 341), (639, 57), (640, 25), (681, 16), (813, 281), (817, 158), (843, 382), (847, 78), (850, 187), (855, 255), (856, 7), (863, 44), (870, 208), (885, 23), (886, 150), (897, 227), (898, 56), (904, 52), (906, 526), (914, 89), (916, 47), (920, 129), (921, 71), (930, 367), (938, 110), (952, 398), (960, 70), (973, 429), (978, 126), (985, 211), (1006, 8), (1045, 74), (1061, 47), (1068, 15), (1070, 71), (1075, 64), (1082, 118), (1090, 128), (1100, 65), (1104, 103), (1108, 3), (1114, 129), (1123, 7), (1128, 67), (1132, 69), (1133, 158), (1149, 43), (1152, 56), (1153, 60), (1167, 296), (1173, 71), (1177, 63), (1182, 275), (1186, 45), (1217, 230), (1268, 46), (1275, 41), (1317, 191), (1342, 31), (1379, 87), (1489, 50), (1496, 46), (1517, 183), (1537, 77), (1577, 153), (1578, 192), (1584, 20), (1585, 78)]
def cs305 : List ℕ := [230, 0, 385, 221, 415, 750, 528, 1000, 106, 44, 338, 1000, 1000, 172, 441, 345, 999, 1000, 1000, 172, 1000, 279, 999, 1000, 1000, 1000, 1000, 1000, 336, 722, 1000, 999, 999, 296, 1001, 1461, 1000, 2490, 625, 1702, 1000, 1000, 1000, 1001, 1000, 1000, 951, 2298, 192, 1000, 1000, 1000, 1000, 1001, 71, 1000, 1000, 1000, 1000, 951, 1000, 322, 846, 1001, 1001, 1001, 1000, 1000, 999, 1000, 1000, 1000, 1000, 652, 575, 1001, 133, 1001, 1001, 998, 1001, 1000, 521, 1000, 1000, 598, 863, 1001, 1001, 999, 1000, 813, 1000, 0, 1000, 766, 1001, 1001, 1001, 1001, 1330, 999, 1000, 953, 406, 801, 1001, 999, 999, 45, 1000, 1001, 1000, 745, 930, 782, 1000, 320, 1000, 822, 764, 1001, 1000, 993, 1001, 847, 492, 436, 799, 889, 999, 788, 1001, 1001, 683, 1002, 606, 878, 1001, 999, 1001, 614, 1000, 959, 1001, 492, 1001, 921, 939, 784, 943, 983, 1000, 515]
theorem loads305 : cs305.get =
    load (fun i : Fin entries305.length => support (entries305.get i).1)
      (fun i => (entries305.get i).2) := by
  apply load_eq_of_sparse_packed base cs305 support code
    entries305 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node305 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 35 (insert 47 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs305 support demand
    entries305 ((insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 35 (insert 47 (insert 39 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 1000 30 loads305
  decide +kernel
def entries306 : List (Fin 1589 × ℕ) := [(177, 32), (341, 2), (399, 5), (466, 10), (478, 1), (506, 16), (542, 4), (581, 14), (587, 5), (588, 40), (622, 26), (623, 1), (625, 31), (629, 12), (632, 23), (639, 6), (681, 4), (690, 10), (692, 5), (731, 13), (737, 2), (813, 38), (817, 2), (819, 1), (843, 32), (850, 7), (855, 12), (856, 15), (863, 8), (869, 7), (870, 23), (886, 9), (897, 9), (898, 14), (904, 13), (906, 47), (914, 4), (916, 8), (920, 22), (929, 13), (930, 31), (934, 28), (938, 19), (949, 1), (952, 10), (960, 2), (973, 28), (978, 14), (985, 38), (1005, 12), (1006, 3), (1030, 12), (1045, 9), (1070, 25), (1082, 15), (1102, 8), (1104, 7), (1114, 11), (1123, 2), (1133, 31), (1137, 7), (1153, 5), (1155, 1), (1167, 38), (1173, 6), (1177, 3), (1182, 13), (1186, 9), (1212, 3), (1217, 26), (1241, 7), (1257, 3), (1266, 6), (1276, 7), (1280, 8), (1317, 26), (1342, 7), (1379, 25), (1489, 13), (1517, 11), (1522, 22), (1577, 15)]
def cs306 : List ℕ := [44, 8, 26, 7, 1, 83, 26, 45, 0, 24, 25, 100, 100, 22, 19, 15, 100, 100, 99, 0, 99, 39, 100, 64, 99, 100, 62, 99, 58, 71, 100, 100, 94, 38, 100, 0, 99, 199, 100, 180, 87, 101, 99, 99, 100, 100, 76, 249, 52, 100, 101, 100, 79, 99, 34, 100, 101, 99, 100, 81, 100, 63, 95, 99, 46, 100, 100, 100, 100, 100, 100, 100, 72, 100, 47, 101, 5, 99, 100, 100, 100, 100, 64, 100, 100, 101, 41, 99, 100, 99, 101, 99, 100, 0, 100, 67, 99, 99, 99, 100, 136, 99, 100, 99, 34, 86, 99, 100, 100, 12, 99, 101, 89, 73, 99, 104, 99, 26, 100, 89, 92, 100, 101, 100, 99, 82, 31, 30, 65, 100, 100, 88, 100, 99, 84, 100, 37, 82, 99, 100, 100, 59, 99, 85, 98, 31, 83, 88, 71, 57, 82, 100, 94, 55]
theorem loads306 : cs306.get =
    load (fun i : Fin entries306.length => support (entries306.get i).1)
      (fun i => (entries306.get i).2) := by
  apply load_eq_of_sparse_packed base cs306 support code
    entries306 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node306 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 35 (insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs306 support demand
    entries306 ((insert 35 (insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)) 100 30 loads306
  decide +kernel
theorem node301 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 47 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    35 node305 node306
def entries303 : List (Fin 1589 × ℕ) := [(17, 174), (37, 21), (177, 184), (179, 97), (273, 132), (344, 14), (421, 235), (466, 230), (472, 253), (475, 246), (479, 295), (491, 180), (498, 21), (507, 141), (542, 284), (552, 133), (571, 97), (572, 28), (617, 422), (625, 112), (632, 464), (731, 223), (813, 225), (817, 66), (819, 1), (843, 336), (850, 102), (855, 204), (870, 37), (872, 137), (885, 93), (886, 195), (890, 94), (895, 166), (906, 292), (920, 183), (922, 209), (924, 74), (925, 106), (949, 200), (952, 286), (959, 37), (973, 302), (978, 166), (985, 258), (1005, 130), (1010, 96), (1018, 37), (1041, 86), (1045, 65), (1061, 144), (1070, 57), (1082, 8), (1090, 14), (1099, 110), (1102, 18), (1104, 79), (1108, 83), (1114, 73), (1123, 26), (1131, 56), (1133, 182), (1139, 8), (1149, 88), (1153, 107), (1167, 384), (1173, 184), (1177, 79), (1182, 313), (1217, 169), (1310, 3), (1317, 206), (1323, 141), (1327, 59), (1469, 213), (1491, 121), (1517, 136), (1534, 3), (1585, 79)]
def cs303 : List ℕ := [399, 0, 422, 522, 295, 453, 316, 947, 275, 141, 0, 998, 972, 370, 284, 254, 999, 999, 999, 146, 999, 493, 281, 999, 999, 999, 941, 999, 328, 745, 998, 999, 956, 384, 999, 1000, 1001, 1332, 302, 1378, 1001, 999, 457, 887, 1934, 999, 1001, 0, 720, 999, 998, 1001, 965, 999, 184, 1000, 998, 1000, 1000, 766, 999, 998, 627, 933, 864, 1000, 1001, 999, 999, 1000, 1000, 999, 902, 1000, 664, 1000, 119, 999, 999, 999, 1001, 987, 934, 999, 1000, 1000, 726, 999, 1000, 1000, 1000, 1000, 1001, 209, 591, 624, 999, 1001, 999, 1000, 1483, 999, 1002, 1000, 742, 969, 999, 1000, 1000, 0, 1000, 999, 767, 791, 999, 1244, 1000, 313, 999, 953, 1000, 999, 1001, 1000, 1000, 958, 381, 328, 733, 1000, 1000, 861, 999, 999, 715, 1000, 653, 751, 999, 1000, 1000, 741, 999, 983, 999, 381, 999, 783, 773, 844, 858, 910, 928, 302]
theorem loads303 : cs303.get =
    load (fun i : Fin entries303.length => support (entries303.get i).1)
      (fun i => (entries303.get i).2) := by
  apply load_eq_of_sparse_packed base cs303 support code
    entries303 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node303 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 44 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs303 support demand
    entries303 ((insert 47 (insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 44 (insert 39 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)) 1000 30 loads303
  decide +kernel
def entries304 : List (Fin 1589 × ℕ) := [(35, 8), (37, 96), (43, 64), (77, 18), (122, 189), (177, 51), (179, 86), (385, 103), (419, 65), (421, 104), (475, 83), (479, 234), (491, 276), (494, 153), (507, 220), (526, 6), (530, 73), (531, 60), (542, 153), (572, 31), (617, 208), (625, 226), (632, 354), (692, 8), (730, 24), (731, 376), (813, 240), (817, 107), (819, 30), (843, 364), (850, 270), (870, 70), (882, 166), (885, 256), (886, 131), (905, 83), (906, 312), (914, 166), (920, 140), (925, 149), (949, 117), (950, 188), (952, 333), (973, 246), (978, 236), (985, 295), (995, 59), (1005, 150), (1021, 211), (1045, 1), (1056, 31), (1070, 171), (1075, 33), (1078, 29), (1082, 123), (1086, 38), (1090, 95), (1111, 82), (1114, 148), (1133, 36), (1137, 56), (1139, 58), (1152, 34), (1153, 114), (1167, 216), (1173, 17), (1177, 249), (1182, 339), (1221, 168), (1228, 82), (1236, 86), (1280, 52), (1303, 27), (1317, 126), (1323, 217), (1358, 94), (1420, 113), (1469, 21), (1491, 7), (1517, 144), (1537, 214)]
def cs304 : List ℕ := [400, 52, 382, 380, 320, 651, 484, 1001, 318, 220, 45, 1000, 1000, 355, 235, 362, 1001, 1000, 999, 127, 1000, 366, 137, 1001, 1001, 999, 1000, 999, 567, 729, 1001, 999, 603, 216, 1001, 1000, 1001, 1320, 251, 1313, 925, 1000, 426, 1000, 373, 1000, 1000, 0, 747, 1001, 999, 1000, 999, 1000, 185, 1000, 1000, 1000, 1000, 635, 1001, 812, 999, 700, 1000, 999, 1000, 999, 1001, 1001, 1000, 1001, 773, 1000, 697, 999, 249, 999, 1000, 1000, 999, 438, 720, 1000, 861, 865, 697, 999, 1001, 1001, 999, 986, 1000, 0, 617, 466, 999, 1001, 1000, 998, 1296, 1000, 999, 1001, 645, 897, 1001, 999, 1001, 0, 999, 999, 882, 728, 990, 977, 1000, 339, 999, 748, 1001, 1000, 1000, 1000, 1000, 746, 495, 246, 886, 999, 1000, 767, 1000, 1000, 776, 1000, 512, 552, 1001, 1000, 1001, 434, 999, 775, 1001, 495, 807, 777, 916, 628, 851, 908, 825, 328]
theorem loads304 : cs304.get =
    load (fun i : Fin entries304.length => support (entries304.get i).1)
      (fun i => (entries304.get i).2) := by
  apply load_eq_of_sparse_packed base cs304 support code
    entries304 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node304 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 44 (insert 47 (insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs304 support demand
    entries304 ((insert 44 (insert 47 (insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 39 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)) 1000 30 loads304
  decide +kernel
theorem node302 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 39 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154))
    44 node303 node304
theorem node300 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 93 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 39 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154))
    47 node301 node302
theorem node263 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 39 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 39 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154))
    93 node299 node300
def entries297 : List (Fin 1589 × ℕ) := [(7, 365), (33, 2), (46, 153), (122, 84), (205, 122), (314, 9), (337, 201), (387, 52), (472, 92), (475, 187), (479, 305), (483, 34), (491, 40), (494, 260), (506, 150), (570, 10), (572, 133), (587, 85), (588, 130), (617, 164), (625, 141), (631, 159), (632, 35), (639, 26), (640, 46), (730, 27), (737, 69), (763, 19), (813, 106), (843, 441), (844, 42), (850, 479), (858, 235), (863, 121), (870, 90), (886, 537), (896, 134), (902, 12), (925, 130), (929, 350), (930, 219), (939, 177), (940, 194), (951, 14), (952, 210), (960, 122), (968, 132), (973, 319), (978, 229), (985, 199), (1006, 48), (1009, 265), (1045, 30), (1070, 236), (1078, 30), (1082, 58), (1099, 80), (1108, 224), (1114, 11), (1130, 3), (1132, 89), (1133, 117), (1149, 33), (1167, 150), (1173, 86), (1182, 258), (1186, 121), (1221, 220), (1227, 80), (1228, 37), (1232, 79), (1246, 249), (1252, 128), (1268, 48), (1275, 89), (1276, 91), (1323, 156), (1342, 68), (1403, 102), (1459, 131), (1493, 12), (1498, 36), (1501, 270), (1556, 64), (1577, 382), (1578, 80)]
def cs297 : List ℕ := [262, 365, 312, 666, 750, 292, 890, 999, 0, 271, 80, 999, 1000, 413, 615, 594, 999, 1743, 995, 181, 999, 896, 497, 999, 908, 1000, 1000, 999, 225, 347, 973, 1000, 1000, 204, 1000, 1000, 999, 2094, 966, 90, 1000, 1001, 999, 1000, 1000, 1000, 1000, 2439, 428, 999, 1830, 1000, 1000, 1000, 306, 1000, 1000, 1001, 1000, 807, 1900, 769, 1000, 1000, 1000, 1000, 1000, 1001, 1000, 1001, 1000, 1000, 999, 1000, 809, 1001, 122, 1000, 1001, 1001, 1001, 1001, 337, 806, 938, 815, 475, 1001, 1000, 999, 1000, 747, 999, 1001, 1000, 190, 1001, 1000, 1001, 1000, 1901, 1000, 1000, 1428, 486, 738, 1000, 1000, 1000, 253, 1000, 1001, 1000, 682, 1001, 1541, 1000, 379, 1001, 891, 1000, 1001, 1000, 1000, 1000, 901, 319, 319, 617, 1001, 1000, 469, 1001, 1001, 874, 1001, 438, 499, 1001, 1001, 1000, 754, 1001, 1000, 1000, 319, 1001, 851, 1001, 854, 910, 881, 917, 736]
theorem loads297 : cs297.get =
    load (fun i : Fin entries297.length => support (entries297.get i).1)
      (fun i => (entries297.get i).2) := by
  apply load_eq_of_sparse_packed base cs297 support code
    entries297 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node297 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 17 (insert 47 (insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs297 support demand
    entries297 ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 17 (insert 47 (insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)) 1000 30 loads297
  decide +kernel
def entries298 : List (Fin 1589 × ℕ) := [(10, 3), (120, 6), (122, 22), (205, 19), (352, 17), (387, 13), (472, 8), (475, 17), (479, 14), (491, 7), (494, 5), (542, 10), (587, 8), (588, 3), (617, 20), (631, 13), (639, 8), (640, 15), (673, 11), (737, 23), (741, 15), (763, 3), (798, 4), (813, 19), (843, 33), (855, 17), (863, 13), (871, 8), (881, 14), (884, 1), (886, 32), (894, 2), (896, 23), (898, 17), (906, 7), (914, 20), (924, 5), (925, 19), (930, 39), (939, 17), (940, 15), (951, 2), (952, 23), (968, 19), (970, 1), (973, 44), (984, 14), (985, 10), (1006, 9), (1009, 8), (1045, 9), (1056, 9), (1070, 20), (1082, 17), (1090, 1), (1099, 2), (1132, 7), (1133, 15), (1159, 8), (1169, 24), (1173, 15), (1182, 6), (1186, 23), (1232, 11), (1236, 6), (1246, 7), (1258, 9), (1267, 1), (1268, 26), (1275, 6), (1276, 10), (1297, 5), (1342, 24), (1359, 16), (1403, 19), (1459, 3), (1501, 29), (1522, 12), (1525, 7), (1577, 34), (1578, 19)]
def cs298 : List ℕ := [6, 16, 18, 17, 42, 35, 60, 75, 0, 20, 26, 99, 68, 49, 63, 95, 101, 0, 100, 26, 99, 76, 57, 99, 100, 101, 100, 100, 29, 33, 78, 100, 100, 24, 99, 100, 100, 196, 76, 7, 100, 100, 100, 101, 100, 100, 101, 274, 53, 84, 165, 101, 100, 99, 15, 101, 100, 102, 101, 100, 197, 76, 99, 101, 100, 98, 100, 100, 100, 101, 100, 99, 101, 101, 94, 100, 0, 99, 100, 100, 101, 99, 74, 100, 76, 85, 53, 99, 100, 100, 100, 68, 99, 100, 100, 50, 100, 99, 100, 100, 198, 100, 100, 138, 66, 98, 98, 100, 99, 42, 100, 99, 79, 66, 99, 118, 100, 30, 100, 77, 99, 99, 99, 101, 99, 100, 44, 44, 28, 90, 100, 68, 100, 99, 100, 99, 59, 77, 99, 99, 96, 81, 99, 100, 95, 44, 98, 92, 92, 87, 72, 99, 100, 99]
theorem loads298 : cs298.get =
    load (fun i : Fin entries298.length => support (entries298.get i).1)
      (fun i => (entries298.get i).2) := by
  apply load_eq_of_sparse_packed base cs298 support code
    entries298 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node298 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 17 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs298 support demand
    entries298 ((insert 17 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)) 100 30 loads298
  decide +kernel
theorem node293 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 47 (insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154))
    17 node297 node298
def entries295 : List (Fin 1589 × ℕ) := [(10, 34), (13, 8), (37, 18), (352, 24), (420, 3), (421, 14), (472, 1), (475, 34), (479, 63), (491, 28), (507, 27), (514, 9), (530, 2), (542, 7), (552, 7), (572, 7), (617, 28), (625, 29), (632, 43), (730, 35), (731, 1), (737, 1), (763, 13), (813, 27), (843, 37), (850, 37), (857, 5), (867, 22), (870, 10), (882, 28), (884, 20), (886, 42), (914, 21), (924, 1), (925, 38), (940, 21), (949, 22), (950, 4), (951, 25), (952, 23), (960, 5), (968, 24), (973, 11), (978, 33), (985, 33), (1006, 19), (1009, 24), (1021, 1), (1039, 10), (1045, 6), (1046, 5), (1061, 10), (1070, 28), (1082, 5), (1090, 16), (1099, 4), (1102, 10), (1104, 1), (1108, 15), (1114, 7), (1139, 3), (1149, 2), (1153, 2), (1167, 14), (1169, 2), (1173, 2), (1182, 29), (1221, 28), (1231, 5), (1232, 29), (1263, 1), (1266, 4), (1275, 22), (1323, 19), (1370, 1), (1561, 4)]
def cs295 : List ℕ := [28, 0, 71, 71, 97, 46, 33, 100, 19, 27, 31, 100, 100, 36, 7, 35, 100, 99, 100, 25, 99, 35, 0, 99, 35, 207, 101, 100, 29, 64, 100, 100, 100, 16, 100, 99, 101, 199, 18, 10, 101, 101, 44, 101, 100, 99, 100, 0, 36, 100, 146, 100, 100, 100, 30, 100, 100, 72, 100, 65, 179, 77, 82, 63, 100, 97, 99, 101, 100, 100, 100, 100, 94, 100, 86, 100, 5, 100, 99, 100, 100, 100, 52, 101, 79, 101, 55, 99, 101, 100, 99, 87, 99, 101, 39, 51, 100, 100, 99, 99, 225, 100, 100, 137, 58, 85, 98, 100, 101, 28, 101, 99, 99, 56, 100, 188, 99, 29, 100, 80, 99, 99, 85, 100, 99, 75, 11, 11, 65, 98, 99, 32, 99, 100, 100, 99, 15, 33, 99, 99, 100, 47, 100, 83, 98, 11, 93, 58, 75, 46, 99, 81, 46, 67]
theorem loads295 : cs295.get =
    load (fun i : Fin entries295.length => support (entries295.get i).1)
      (fun i => (entries295.get i).2) := by
  apply load_eq_of_sparse_packed base cs295 support code
    entries295 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node295 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs295 support demand
    entries295 ((insert 47 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 25 (insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)) 100 30 loads295
  decide +kernel
def entries296 : List (Fin 1589 × ℕ) := [(7, 6), (62, 2), (120, 2), (122, 10), (195, 1), (205, 20), (352, 11), (421, 23), (468, 19), (472, 38), (475, 30), (479, 23), (491, 28), (507, 4), (530, 10), (542, 22), (552, 16), (583, 15), (617, 47), (632, 35), (640, 10), (731, 35), (736, 8), (737, 5), (813, 5), (817, 5), (819, 9), (843, 21), (850, 32), (858, 11), (870, 3), (872, 3), (882, 27), (894, 3), (905, 11), (914, 11), (922, 25), (924, 20), (925, 46), (937, 4), (940, 11), (950, 1), (951, 44), (952, 17), (968, 11), (973, 33), (977, 23), (978, 19), (1006, 8), (1045, 10), (1046, 10), (1061, 18), (1070, 7), (1082, 7), (1090, 19), (1108, 1), (1114, 4), (1128, 6), (1132, 10), (1133, 16), (1139, 9), (1152, 2), (1153, 18), (1167, 29), (1173, 22), (1182, 30), (1186, 2), (1232, 7), (1236, 1), (1266, 14), (1275, 20), (1295, 12), (1358, 19), (1469, 7), (1499, 10), (1559, 1), (1573, 11)]
def cs296 : List ℕ := [20, 25, 38, 62, 30, 1, 39, 100, 0, 6, 0, 100, 101, 21, 22, 55, 100, 100, 79, 2, 100, 36, 0, 85, 90, 0, 100, 100, 30, 57, 76, 100, 100, 29, 100, 92, 100, 158, 4, 39, 100, 101, 44, 85, 99, 100, 100, 0, 53, 97, 157, 82, 100, 100, 32, 101, 100, 100, 100, 100, 192, 87, 42, 70, 101, 101, 99, 100, 100, 100, 100, 100, 86, 100, 89, 100, 0, 100, 99, 100, 100, 100, 101, 100, 90, 89, 52, 101, 100, 101, 100, 93, 100, 100, 68, 60, 99, 101, 100, 101, 220, 100, 101, 90, 76, 100, 100, 101, 99, 13, 100, 99, 85, 100, 100, 185, 100, 32, 99, 88, 92, 99, 84, 101, 100, 92, 33, 45, 56, 100, 101, 72, 99, 99, 98, 100, 55, 72, 99, 99, 99, 62, 99, 100, 100, 45, 99, 84, 92, 67, 99, 80, 83, 62]
theorem loads296 : cs296.get =
    load (fun i : Fin entries296.length => support (entries296.get i).1)
      (fun i => (entries296.get i).2) := by
  apply load_eq_of_sparse_packed base cs296 support code
    entries296 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node296 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 47 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs296 support demand
    entries296 ((insert 25 (insert 47 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 100 30 loads296
  decide +kernel
theorem node294 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154))
    25 node295 node296
theorem node287 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 50 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154))
    47 node293 node294
def entries291 : List (Fin 1589 × ℕ) := [(7, 403), (120, 187), (122, 56), (179, 27), (314, 66), (399, 357), (468, 273), (472, 17), (479, 98), (491, 126), (494, 305), (497, 147), (506, 327), (526, 25), (528, 170), (588, 451), (617, 256), (625, 378), (629, 24), (631, 193), (632, 207), (639, 131), (640, 21), (736, 52), (737, 107), (797, 47), (798, 122), (813, 400), (815, 112), (843, 190), (856, 433), (858, 169), (863, 98), (871, 10), (881, 49), (884, 93), (886, 401), (896, 109), (897, 229), (898, 102), (902, 50), (906, 121), (914, 397), (925, 110), (929, 15), (930, 366), (960, 2), (967, 139), (968, 36), (969, 143), (970, 160), (973, 407), (977, 23), (978, 192), (985, 65), (1009, 165), (1045, 139), (1061, 10), (1078, 28), (1082, 96), (1097, 1), (1099, 73), (1128, 19), (1132, 139), (1139, 95), (1149, 90), (1167, 235), (1173, 77), (1182, 74), (1183, 15), (1186, 252), (1212, 105), (1222, 9), (1232, 86), (1258, 124), (1267, 13), (1268, 244), (1275, 44), (1297, 49), (1481, 14), (1497, 26), (1498, 112), (1528, 79), (1556, 61), (1561, 38), (1577, 350), (1578, 72), (1588, 63)]
def cs291 : List ℕ := [0, 685, 26, 0, 573, 554, 717, 774, 147, 425, 72, 830, 999, 827, 422, 826, 1000, 999, 849, 244, 999, 840, 809, 999, 999, 1001, 1823, 1000, 634, 862, 1001, 1000, 1000, 285, 1000, 1000, 1000, 2334, 595, 121, 1000, 999, 999, 1000, 999, 999, 1000, 3405, 83, 1001, 110, 1000, 999, 999, 86, 999, 1001, 999, 999, 927, 2229, 246, 900, 1000, 1001, 949, 999, 999, 999, 999, 263, 869, 1001, 1001, 912, 1000, 2, 999, 1000, 999, 1000, 1000, 385, 1000, 892, 999, 971, 1001, 1001, 998, 1000, 697, 1001, 1000, 999, 836, 1000, 1001, 998, 999, 1752, 999, 1001, 1055, 412, 958, 1000, 999, 998, 570, 999, 1000, 1000, 521, 999, 1266, 999, 749, 860, 632, 1001, 999, 806, 999, 999, 1000, 512, 407, 586, 999, 999, 668, 1000, 999, 999, 998, 653, 782, 999, 999, 999, 726, 999, 999, 1000, 407, 999, 999, 999, 999, 875, 894, 1000, 958]
theorem loads291 : cs291.get =
    load (fun i : Fin entries291.length => support (entries291.get i).1)
      (fun i => (entries291.get i).2) := by
  apply load_eq_of_sparse_packed base cs291 support code
    entries291 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node291 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 50 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 26 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs291 support demand
    entries291 ((insert 50 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 26 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)) 1000 30 loads291
  decide +kernel
def entries292 : List (Fin 1589 × ℕ) := [(7, 234), (30, 17), (122, 37), (179, 215), (205, 59), (273, 210), (344, 65), (352, 238), (420, 9), (421, 195), (468, 409), (472, 19), (479, 403), (487, 14), (491, 351), (496, 8), (507, 520), (526, 41), (531, 98), (583, 1), (617, 291), (625, 331), (632, 552), (639, 19), (714, 47), (717, 49), (731, 92), (737, 123), (763, 35), (781, 35), (798, 161), (813, 198), (842, 110), (843, 350), (854, 286), (858, 155), (864, 89), (872, 2), (882, 279), (884, 147), (886, 339), (894, 55), (896, 4), (914, 233), (925, 172), (948, 55), (949, 102), (950, 106), (951, 433), (967, 22), (968, 48), (970, 30), (973, 296), (978, 208), (985, 197), (1005, 123), (1006, 70), (1009, 47), (1045, 11), (1070, 70), (1082, 276), (1090, 45), (1099, 43), (1108, 11), (1128, 164), (1132, 4), (1138, 5), (1139, 162), (1149, 127), (1167, 403), (1177, 301), (1182, 54), (1186, 170), (1231, 70), (1232, 118), (1238, 85), (1249, 1), (1258, 93), (1263, 94), (1266, 11), (1297, 58), (1323, 115), (1398, 34), (1400, 63), (1500, 21), (1545, 61), (1561, 151)]
def cs292 : List ℕ := [85, 643, 104, 0, 637, 317, 506, 916, 204, 609, 0, 845, 1000, 351, 0, 316, 999, 1000, 723, 0, 1000, 442, 215, 999, 683, 1000, 1290, 1002, 368, 1000, 999, 999, 902, 403, 1001, 1000, 1000, 1305, 215, 0, 999, 1001, 588, 1001, 1000, 1001, 1000, 0, 365, 999, 172, 1000, 1000, 1000, 286, 1000, 1001, 1000, 1001, 751, 1434, 1000, 1000, 536, 1001, 1000, 999, 1000, 999, 1000, 1001, 1000, 999, 1001, 862, 1002, 411, 1000, 999, 1000, 735, 899, 547, 1000, 880, 1001, 879, 1000, 1002, 999, 1000, 824, 874, 1001, 709, 953, 1001, 1000, 1000, 1000, 2272, 1000, 1000, 1578, 696, 1000, 1000, 969, 999, 391, 999, 1001, 1001, 897, 1000, 1991, 1000, 315, 1001, 904, 1000, 1001, 1000, 1000, 999, 943, 597, 296, 741, 1001, 999, 1000, 1001, 1000, 1000, 1000, 724, 710, 1001, 1000, 1000, 570, 1000, 1000, 1001, 597, 1000, 926, 1000, 1000, 780, 1000, 765, 712]
theorem loads292 : cs292.get =
    load (fun i : Fin entries292.length => support (entries292.get i).1)
      (fun i => (entries292.get i).2) := by
  apply load_eq_of_sparse_packed base cs292 support code
    entries292 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node292 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 50 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 26 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs292 support demand
    entries292 ((insert 47 (insert 50 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 26 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 1000 30 loads292
  decide +kernel
theorem node289 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 50 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 26 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 50 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 26 (insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154))
    47 node291 node292
def entries290 : List (Fin 1589 × ℕ) := [(7, 48), (10, 177), (116, 50), (122, 110), (179, 129), (205, 129), (273, 70), (352, 274), (399, 44), (420, 150), (421, 90), (468, 326), (479, 344), (491, 302), (498, 225), (526, 12), (531, 197), (550, 202), (570, 45), (588, 357), (625, 409), (632, 502), (640, 57), (673, 131), (737, 117), (763, 98), (798, 186), (813, 210), (843, 505), (844, 41), (850, 96), (858, 232), (879, 92), (884, 156), (886, 420), (897, 323), (898, 50), (906, 307), (914, 255), (950, 202), (951, 294), (952, 75), (960, 124), (967, 104), (968, 23), (969, 32), (970, 56), (973, 317), (978, 168), (985, 207), (1005, 84), (1006, 101), (1039, 2), (1061, 6), (1070, 165), (1082, 304), (1090, 101), (1104, 26), (1128, 99), (1133, 93), (1139, 102), (1149, 26), (1153, 93), (1160, 30), (1167, 414), (1173, 86), (1177, 190), (1186, 68), (1232, 209), (1258, 201), (1261, 4), (1263, 5), (1297, 57), (1323, 122), (1459, 78), (1489, 12), (1493, 67), (1556, 52), (1578, 98)]
def cs290 : List ℕ := [41, 374, 177, 96, 667, 0, 632, 809, 230, 0, 98, 726, 705, 422, 98, 619, 1000, 999, 338, 0, 999, 488, 926, 998, 803, 1001, 0, 998, 569, 886, 1000, 998, 696, 455, 999, 926, 999, 2282, 191, 307, 985, 999, 908, 1000, 999, 1000, 999, 999, 239, 1000, 96, 1000, 1000, 999, 86, 999, 1000, 999, 999, 633, 1448, 722, 1000, 761, 553, 957, 1001, 999, 1000, 999, 1000, 973, 1000, 1000, 887, 1001, 314, 1000, 1000, 999, 552, 1000, 583, 1000, 1000, 1000, 706, 1000, 1000, 1000, 1000, 782, 1001, 1001, 1000, 967, 905, 1000, 1000, 1000, 2188, 1000, 1000, 1682, 572, 1000, 1001, 983, 999, 195, 1000, 999, 1001, 813, 999, 1907, 999, 156, 1001, 957, 1000, 1001, 999, 999, 1000, 944, 507, 317, 730, 999, 1000, 921, 1000, 999, 999, 999, 619, 731, 1000, 999, 999, 594, 999, 936, 999, 507, 999, 900, 1000, 775, 685, 999, 679, 681]
theorem loads290 : cs290.get =
    load (fun i : Fin entries290.length => support (entries290.get i).1)
      (fun i => (entries290.get i).2) := by
  apply load_eq_of_sparse_packed base cs290 support code
    entries290 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node290 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 26 (insert 50 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs290 support demand
    entries290 ((insert 26 (insert 50 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)) 1000 30 loads290
  decide +kernel
theorem node288 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 50 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 50 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    26 node289 node290
theorem node283 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 103 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    50 node287 node288
def entries285 : List (Fin 1589 × ℕ) := [(10, 289), (17, 42), (122, 41), (179, 108), (341, 129), (385, 162), (399, 54), (421, 133), (472, 338), (475, 149), (479, 342), (491, 484), (494, 8), (498, 93), (507, 228), (526, 55), (531, 158), (542, 29), (588, 224), (616, 79), (625, 113), (630, 199), (672, 37), (673, 91), (681, 254), (731, 313), (737, 84), (763, 1), (813, 248), (844, 8), (850, 271), (858, 99), (863, 169), (872, 25), (882, 74), (884, 157), (886, 172), (896, 49), (898, 61), (912, 65), (924, 12), (925, 336), (930, 129), (940, 232), (950, 65), (951, 69), (952, 298), (968, 207), (973, 279), (977, 64), (978, 271), (985, 189), (1006, 89), (1009, 85), (1034, 5), (1041, 72), (1045, 51), (1061, 178), (1070, 142), (1090, 56), (1104, 117), (1123, 115), (1133, 39), (1138, 13), (1139, 55), (1149, 36), (1153, 65), (1167, 310), (1173, 201), (1177, 43), (1181, 40), (1183, 275), (1186, 186), (1221, 185), (1232, 63), (1258, 50), (1263, 169), (1275, 38), (1276, 87), (1297, 74), (1308, 66), (1323, 90), (1358, 70), (1500, 63), (1509, 14), (1556, 48), (1561, 28), (1566, 37), (1577, 112)]
def cs285 : List ℕ := [263, 0, 812, 462, 631, 185, 695, 951, 304, 397, 14, 1000, 1000, 514, 141, 241, 1000, 1001, 1000, 0, 1001, 590, 430, 1000, 692, 1000, 999, 1001, 191, 372, 656, 1000, 1000, 318, 1001, 999, 1001, 1715, 528, 0, 999, 1000, 1000, 1000, 1001, 1000, 1000, 1000, 562, 1000, 1000, 999, 1001, 1000, 386, 1000, 1001, 1000, 1000, 728, 1404, 799, 1001, 750, 999, 1000, 999, 1001, 1001, 1000, 999, 1001, 1001, 1001, 818, 999, 106, 1000, 1000, 1001, 1000, 1000, 235, 1002, 999, 1000, 612, 999, 1002, 1001, 1000, 986, 1000, 1001, 625, 574, 1000, 1000, 1001, 1000, 1646, 1001, 1001, 0, 477, 1001, 1001, 1001, 1001, 461, 1000, 1000, 895, 760, 922, 1143, 957, 461, 1000, 631, 925, 1345, 994, 1001, 981, 1000, 322, 434, 969, 1001, 1002, 632, 1001, 1000, 1002, 1001, 559, 680, 1002, 1001, 1001, 698, 1001, 1001, 1002, 362, 1000, 831, 1001, 866, 1002, 738, 735, 1002]
theorem loads285 : cs285.get =
    load (fun i : Fin entries285.length => support (entries285.get i).1)
      (fun i => (entries285.get i).2) := by
  apply load_eq_of_sparse_packed base cs285 support code
    entries285 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node285 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 103 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 121 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs285 support demand
    entries285 ((insert 103 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 121 (insert 60 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)) 1000 30 loads285
  decide +kernel
def entries286 : List (Fin 1589 × ℕ) := [(10, 2), (17, 18), (179, 24), (205, 12), (344, 16), (352, 15), (385, 17), (399, 13), (468, 1), (472, 6), (475, 25), (479, 52), (491, 33), (498, 2), (507, 22), (514, 13), (531, 15), (542, 4), (588, 6), (616, 20), (617, 7), (625, 19), (630, 19), (631, 6), (639, 8), (731, 16), (737, 14), (777, 11), (813, 14), (819, 2), (850, 19), (858, 8), (863, 14), (872, 4), (882, 11), (884, 29), (886, 19), (894, 14), (898, 5), (912, 9), (925, 24), (937, 30), (940, 2), (951, 38), (968, 11), (973, 26), (978, 37), (985, 17), (995, 2), (1006, 20), (1009, 20), (1012, 8), (1061, 9), (1068, 18), (1078, 13), (1104, 16), (1113, 1), (1149, 15), (1167, 17), (1173, 2), (1175, 6), (1177, 5), (1183, 5), (1186, 11), (1212, 24), (1221, 32), (1252, 9), (1266, 8), (1275, 25), (1276, 2), (1297, 4), (1317, 3), (1344, 10), (1369, 2), (1489, 37), (1493, 12), (1566, 11), (1577, 9)]
def cs286 : List ℕ := [32, 1, 40, 62, 54, 32, 50, 91, 20, 36, 13, 100, 79, 39, 13, 32, 100, 99, 99, 0, 100, 34, 58, 100, 61, 99, 101, 100, 30, 58, 89, 99, 100, 17, 99, 100, 100, 175, 72, 0, 100, 99, 100, 99, 98, 99, 100, 100, 51, 100, 100, 100, 101, 99, 40, 99, 98, 100, 100, 74, 211, 76, 96, 80, 100, 99, 100, 100, 99, 101, 99, 100, 100, 100, 80, 101, 11, 75, 100, 99, 101, 99, 36, 101, 100, 99, 81, 100, 100, 98, 99, 99, 101, 100, 91, 94, 99, 100, 80, 99, 172, 100, 101, 0, 20, 99, 99, 99, 100, 46, 100, 100, 68, 93, 53, 142, 100, 40, 100, 64, 62, 7, 64, 100, 98, 100, 37, 34, 67, 101, 100, 54, 82, 100, 89, 90, 54, 61, 100, 100, 99, 43, 100, 100, 70, 37, 88, 78, 99, 93, 98, 100, 75, 99]
theorem loads286 : cs286.get =
    load (fun i : Fin entries286.length => support (entries286.get i).1)
      (fun i => (entries286.get i).2) := by
  apply load_eq_of_sparse_packed base cs286 support code
    entries286 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node286 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 121 (insert 103 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs286 support demand
    entries286 ((insert 121 (insert 103 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 60 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)) 100 30 loads286
  decide +kernel
theorem node284 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 103 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 103 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 60 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154))
    121 node285 node286
theorem node265 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 60 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 60 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154))
    103 node283 node284
def entries281 : List (Fin 1589 × ℕ) := [(17, 171), (46, 367), (72, 274), (116, 394), (196, 228), (198, 26), (205, 26), (273, 70), (341, 144), (385, 78), (419, 20), (430, 116), (472, 305), (475, 513), (479, 225), (507, 12), (531, 169), (542, 70), (570, 179), (571, 27), (572, 44), (588, 336), (617, 163), (625, 24), (639, 15), (640, 84), (681, 35), (730, 211), (731, 261), (737, 210), (763, 221), (800, 207), (812, 181), (813, 279), (817, 4), (842, 48), (843, 121), (844, 8), (848, 32), (850, 126), (867, 225), (896, 431), (897, 23), (906, 216), (914, 633), (925, 114), (928, 53), (930, 25), (938, 99), (955, 68), (966, 40), (968, 186), (973, 305), (978, 307), (980, 19), (985, 319), (1005, 68), (1009, 119), (1041, 27), (1045, 247), (1056, 70), (1061, 2), (1070, 239), (1082, 46), (1090, 38), (1133, 201), (1139, 63), (1167, 23), (1169, 119), (1173, 138), (1183, 242), (1186, 212), (1212, 216), (1221, 24), (1238, 214), (1246, 98), (1258, 81), (1297, 26), (1308, 39), (1359, 115), (1379, 118), (1433, 27), (1495, 148), (1561, 65), (1566, 58), (1577, 2), (1578, 77)]
def cs281 : List ℕ := [246, 115, 575, 810, 302, 24, 446, 1000, 385, 12, 842, 945, 1000, 340, 790, 621, 1001, 1002, 999, 71, 1001, 1558, 417, 1000, 1000, 1001, 821, 1001, 750, 1000, 733, 1000, 1251, 150, 1001, 999, 1002, 2259, 937, 216, 1000, 999, 951, 990, 1001, 1001, 1000, 1000, 628, 1001, 1000, 1000, 1001, 1000, 194, 1000, 1001, 999, 999, 999, 114, 976, 1001, 924, 1001, 1001, 1000, 2804, 1000, 2067, 471, 868, 1001, 999, 514, 1002, 0, 1001, 999, 1001, 999, 1000, 961, 1001, 999, 1001, 868, 1001, 1000, 1001, 1001, 1001, 1001, 1000, 921, 684, 1000, 1001, 999, 1001, 1850, 1000, 1000, 999, 540, 1001, 1000, 1001, 1000, 747, 1001, 999, 999, 716, 1496, 1146, 1000, 710, 1001, 506, 999, 1000, 1000, 1001, 1000, 723, 305, 305, 584, 1001, 1001, 447, 1000, 1000, 1000, 1001, 443, 694, 1001, 1000, 1000, 682, 1001, 881, 1000, 305, 1000, 913, 870, 897, 852, 934, 879, 1001]
theorem loads281 : cs281.get =
    load (fun i : Fin entries281.length => support (entries281.get i).1)
      (fun i => (entries281.get i).2) := by
  apply load_eq_of_sparse_packed base cs281 support code
    entries281 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node281 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 69 (insert 32 (insert 114 (insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs281 support demand
    entries281 ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 69 (insert 32 (insert 114 (insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154)) 1000 30 loads281
  decide +kernel
def entries282 : List (Fin 1589 × ℕ) := [(17, 23), (46, 31), (72, 20), (116, 29), (122, 8), (177, 3), (273, 22), (341, 1), (387, 2), (431, 5), (466, 11), (472, 19), (475, 18), (479, 25), (507, 39), (527, 6), (529, 4), (569, 15), (583, 14), (588, 37), (617, 23), (625, 23), (681, 25), (717, 2), (737, 23), (763, 36), (799, 12), (813, 33), (814, 6), (815, 4), (818, 2), (842, 18), (843, 9), (850, 20), (855, 6), (867, 35), (886, 9), (894, 13), (895, 24), (906, 18), (928, 1), (930, 22), (934, 8), (938, 57), (968, 24), (969, 9), (970, 1), (973, 33), (978, 26), (980, 19), (985, 13), (1005, 7), (1006, 8), (1045, 10), (1056, 1), (1061, 8), (1068, 2), (1070, 14), (1078, 7), (1082, 3), (1097, 8), (1108, 5), (1132, 7), (1133, 12), (1139, 20), (1169, 18), (1173, 22), (1183, 20), (1186, 26), (1212, 14), (1228, 3), (1238, 20), (1297, 3), (1323, 1), (1344, 1), (1359, 20), (1379, 9), (1472, 2), (1545, 3), (1561, 11), (1578, 5)]
def cs282 : List ℕ := [31, 20, 39, 61, 30, 6, 36, 100, 43, 39, 69, 74, 101, 27, 56, 42, 93, 100, 102, 0, 100, 156, 40, 100, 101, 101, 101, 100, 80, 34, 79, 100, 116, 18, 100, 98, 100, 130, 100, 18, 100, 101, 61, 91, 100, 100, 100, 99, 11, 97, 101, 100, 100, 101, 30, 101, 100, 100, 100, 100, 9, 61, 100, 88, 101, 101, 99, 240, 100, 0, 101, 101, 50, 101, 68, 100, 0, 100, 100, 100, 94, 101, 101, 101, 62, 100, 67, 101, 101, 100, 99, 87, 98, 101, 75, 30, 100, 101, 101, 100, 210, 100, 101, 91, 64, 54, 101, 99, 101, 75, 100, 100, 101, 74, 145, 136, 101, 73, 100, 55, 101, 101, 100, 100, 100, 100, 33, 33, 74, 100, 99, 51, 101, 100, 101, 100, 55, 71, 100, 100, 101, 69, 99, 100, 100, 33, 100, 99, 82, 99, 93, 88, 84, 99]
theorem loads282 : cs282.get =
    load (fun i : Fin entries282.length => support (entries282.get i).1)
      (fun i => (entries282.get i).2) := by
  apply load_eq_of_sparse_packed base cs282 support code
    entries282 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node282 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 69 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 32 (insert 114 (insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs282 support demand
    entries282 ((insert 69 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 32 (insert 114 (insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)) 100 30 loads282
  decide +kernel
theorem node279 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 32 (insert 114 (insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 32 (insert 114 (insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154))
    69 node281 node282
def entries280 : List (Fin 1589 × ℕ) := [(30, 9), (46, 37), (72, 22), (116, 19), (196, 1), (198, 11), (205, 13), (244, 12), (341, 5), (343, 7), (430, 2), (472, 29), (479, 2), (515, 11), (529, 13), (530, 20), (531, 1), (572, 2), (617, 17), (681, 8), (730, 37), (737, 15), (763, 29), (800, 6), (813, 38), (817, 3), (819, 3), (842, 10), (843, 1), (844, 9), (850, 18), (855, 23), (864, 10), (867, 16), (893, 8), (894, 18), (895, 2), (896, 29), (897, 9), (906, 24), (928, 5), (930, 9), (934, 10), (938, 53), (955, 4), (968, 17), (973, 32), (978, 37), (980, 9), (985, 12), (1005, 9), (1006, 5), (1009, 1), (1045, 15), (1046, 18), (1056, 13), (1068, 9), (1070, 16), (1082, 2), (1108, 4), (1133, 16), (1139, 15), (1152, 1), (1169, 8), (1172, 3), (1173, 22), (1182, 4), (1183, 22), (1186, 35), (1212, 11), (1222, 1), (1234, 2), (1238, 6), (1246, 7), (1269, 6), (1308, 9), (1342, 14), (1359, 29), (1434, 14), (1548, 4), (1561, 11), (1577, 5), (1578, 23)]
def cs280 : List ℕ := [15, 30, 36, 18, 25, 33, 65, 99, 29, 10, 72, 64, 100, 57, 87, 47, 99, 101, 99, 2, 100, 145, 9, 101, 100, 100, 99, 101, 41, 49, 66, 101, 0, 17, 101, 101, 99, 106, 86, 24, 99, 101, 60, 100, 100, 101, 101, 101, 60, 99, 94, 101, 102, 100, 36, 102, 100, 102, 101, 100, 0, 96, 102, 76, 99, 101, 100, 260, 101, 102, 101, 101, 88, 101, 68, 99, 10, 100, 100, 102, 101, 101, 84, 101, 68, 99, 74, 98, 99, 101, 100, 96, 91, 101, 40, 55, 99, 99, 100, 99, 174, 100, 100, 101, 55, 99, 99, 100, 101, 82, 101, 99, 100, 70, 154, 126, 100, 72, 99, 66, 100, 99, 100, 101, 99, 80, 32, 32, 79, 99, 100, 61, 99, 99, 100, 99, 54, 67, 99, 100, 99, 70, 99, 100, 99, 32, 99, 93, 75, 100, 90, 95, 99, 100]
theorem loads280 : cs280.get =
    load (fun i : Fin entries280.length => support (entries280.get i).1)
      (fun i => (entries280.get i).2) := by
  apply load_eq_of_sparse_packed base cs280 support code
    entries280 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node280 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 32 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 114 (insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs280 support demand
    entries280 ((insert 32 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 114 (insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)) 100 30 loads280
  decide +kernel
theorem node277 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 114 (insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 114 (insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154))
    32 node279 node280
def entries278 : List (Fin 1589 × ℕ) := [(30, 14), (46, 23), (72, 13), (75, 13), (116, 5), (122, 4), (179, 24), (196, 23), (205, 14), (273, 15), (341, 2), (352, 5), (386, 32), (399, 2), (421, 26), (430, 6), (431, 13), (472, 23), (475, 31), (479, 29), (507, 18), (515, 3), (529, 14), (570, 7), (572, 9), (587, 9), (588, 21), (617, 17), (625, 7), (639, 17), (675, 8), (681, 8), (717, 1), (737, 16), (813, 36), (819, 2), (843, 20), (850, 22), (867, 33), (870, 5), (872, 8), (886, 5), (894, 8), (895, 10), (896, 32), (906, 24), (912, 13), (925, 2), (930, 9), (940, 30), (952, 2), (960, 1), (968, 2), (970, 5), (973, 31), (978, 50), (985, 6), (1005, 1), (1006, 13), (1046, 2), (1070, 15), (1082, 11), (1099, 6), (1110, 20), (1132, 1), (1133, 10), (1137, 6), (1148, 7), (1153, 4), (1160, 12), (1173, 22), (1177, 19), (1186, 10), (1188, 8), (1212, 22), (1222, 16), (1238, 17), (1246, 17), (1249, 13), (1275, 7), (1276, 13), (1342, 17), (1359, 15), (1380, 12), (1507, 4), (1545, 2), (1548, 10), (1552, 6), (1588, 11)]
def cs278 : List ℕ := [17, 31, 56, 53, 29, 30, 39, 100, 31, 18, 78, 100, 101, 36, 49, 13, 95, 100, 100, 9, 100, 121, 54, 100, 100, 100, 100, 99, 29, 79, 98, 100, 100, 0, 99, 99, 100, 151, 93, 29, 99, 100, 53, 101, 99, 100, 99, 100, 70, 101, 100, 100, 98, 99, 38, 100, 100, 100, 100, 100, 9, 99, 98, 94, 100, 100, 99, 205, 100, 100, 100, 100, 100, 98, 55, 100, 28, 100, 99, 99, 100, 99, 88, 100, 101, 100, 90, 100, 100, 100, 100, 88, 100, 100, 99, 41, 100, 100, 100, 99, 183, 100, 102, 83, 86, 85, 99, 100, 100, 44, 100, 99, 101, 95, 0, 140, 99, 39, 100, 63, 100, 100, 99, 99, 99, 79, 50, 31, 64, 99, 99, 65, 76, 99, 99, 99, 72, 44, 99, 99, 99, 74, 99, 99, 99, 50, 99, 89, 99, 85, 73, 99, 93, 95]
theorem loads278 : cs278.get =
    load (fun i : Fin entries278.length => support (entries278.get i).1)
      (fun i => (entries278.get i).2) := by
  apply load_eq_of_sparse_packed base cs278 support code
    entries278 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node278 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 114 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs278 support demand
    entries278 ((insert 114 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 100 30 loads278
  decide +kernel
theorem node275 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 21 (insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154))
    114 node277 node278
def entries276 : List (Fin 1589 × ℕ) := [(72, 52), (83, 5), (179, 13), (205, 6), (273, 9), (341, 12), (352, 13), (421, 12), (430, 15), (472, 25), (475, 52), (479, 49), (491, 10), (507, 14), (514, 23), (515, 1), (529, 4), (530, 2), (531, 6), (542, 12), (551, 16), (572, 9), (588, 24), (617, 30), (625, 6), (639, 5), (640, 8), (659, 17), (730, 17), (731, 2), (737, 8), (743, 4), (763, 20), (799, 5), (800, 13), (813, 48), (843, 21), (844, 3), (850, 22), (858, 18), (881, 11), (882, 12), (886, 6), (898, 4), (906, 29), (914, 32), (917, 8), (918, 4), (930, 10), (934, 4), (938, 4), (952, 1), (968, 18), (969, 5), (970, 2), (973, 37), (978, 26), (980, 1), (985, 18), (1005, 6), (1009, 12), (1045, 12), (1061, 12), (1070, 14), (1082, 2), (1099, 8), (1132, 16), (1133, 13), (1139, 2), (1167, 25), (1173, 22), (1182, 8), (1183, 17), (1186, 25), (1222, 20), (1232, 2), (1233, 8), (1234, 3), (1246, 22), (1252, 3), (1317, 17), (1359, 2), (1552, 18), (1561, 10), (1577, 10)]
def cs276 : List ℕ := [3, 22, 45, 74, 49, 20, 38, 99, 0, 14, 76, 99, 99, 12, 74, 49, 77, 99, 100, 9, 99, 0, 41, 99, 100, 99, 100, 100, 58, 63, 45, 101, 99, 28, 100, 100, 101, 213, 100, 41, 99, 100, 102, 87, 101, 100, 69, 101, 57, 100, 100, 100, 98, 100, 46, 101, 100, 101, 100, 98, 7, 90, 99, 100, 100, 89, 100, 159, 99, 100, 45, 101, 92, 100, 74, 99, 0, 99, 100, 100, 99, 101, 76, 102, 99, 100, 78, 99, 102, 100, 99, 99, 100, 102, 67, 65, 99, 101, 100, 99, 226, 101, 101, 101, 66, 100, 100, 100, 100, 53, 100, 100, 100, 65, 100, 162, 101, 57, 99, 71, 101, 95, 99, 101, 100, 97, 37, 37, 75, 99, 100, 62, 100, 99, 101, 99, 59, 74, 100, 100, 100, 81, 100, 101, 100, 37, 99, 95, 91, 87, 94, 94, 100, 89]
theorem loads276 : cs276.get =
    load (fun i : Fin entries276.length => support (entries276.get i).1)
      (fun i => (entries276.get i).2) := by
  apply load_eq_of_sparse_packed base cs276 support code
    entries276 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node276 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 21 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs276 support demand
    entries276 ((insert 21 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)) 100 30 loads276
  decide +kernel
theorem node269 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 67 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    21 node275 node276
def entries273 : List (Fin 1589 × ℕ) := [(17, 478), (62, 83), (72, 205), (122, 401), (179, 144), (198, 44), (341, 115), (343, 5), (344, 109), (421, 428), (430, 38), (468, 57), (472, 254), (475, 137), (479, 362), (491, 341), (498, 71), (507, 254), (514, 137), (531, 39), (567, 166), (572, 192), (588, 246), (617, 151), (621, 28), (623, 86), (625, 34), (632, 336), (639, 384), (672, 72), (736, 40), (737, 69), (798, 24), (813, 368), (843, 210), (850, 385), (855, 61), (872, 84), (882, 157), (898, 68), (906, 315), (929, 130), (930, 17), (940, 417), (960, 30), (968, 168), (970, 2), (973, 365), (978, 137), (984, 297), (985, 82), (1009, 61), (1045, 67), (1046, 52), (1070, 216), (1075, 130), (1078, 87), (1089, 21), (1104, 155), (1108, 3), (1113, 3), (1114, 12), (1123, 8), (1133, 105), (1139, 42), (1160, 54), (1172, 113), (1173, 224), (1177, 53), (1186, 191), (1212, 208), (1217, 40), (1221, 148), (1227, 120), (1228, 71), (1235, 55), (1246, 170), (1249, 48), (1258, 68), (1275, 78), (1277, 32), (1293, 75), (1359, 100), (1500, 33), (1565, 59), (1566, 12), (1577, 177)]
def cs273 : List ℕ := [188, 157, 442, 1000, 362, 249, 518, 961, 549, 337, 342, 1000, 999, 684, 382, 735, 902, 1000, 1000, 275, 1000, 999, 529, 999, 1000, 999, 999, 1000, 797, 480, 939, 999, 708, 0, 1959, 999, 999, 1959, 940, 355, 999, 1000, 1201, 1000, 1000, 999, 873, 999, 819, 992, 1000, 998, 1111, 1000, 485, 1000, 999, 999, 999, 999, 0, 875, 908, 1000, 999, 1000, 999, 0, 1000, 999, 1000, 1000, 1000, 999, 498, 1001, 116, 1000, 999, 1000, 754, 999, 1000, 1001, 1000, 908, 644, 999, 999, 1000, 999, 881, 1000, 1000, 954, 395, 999, 1000, 999, 999, 1497, 1000, 1001, 1000, 644, 696, 1000, 999, 1002, 567, 999, 999, 1000, 501, 642, 1320, 1000, 401, 1000, 730, 1000, 1000, 796, 998, 1000, 763, 418, 405, 721, 1000, 998, 583, 999, 998, 1001, 1000, 642, 675, 999, 1000, 1001, 805, 913, 999, 999, 418, 919, 999, 1000, 1000, 885, 1000, 880, 999]
theorem loads273 : cs273.get =
    load (fun i : Fin entries273.length => support (entries273.get i).1)
      (fun i => (entries273.get i).2) := by
  apply load_eq_of_sparse_packed base cs273 support code
    entries273 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node273 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 34 (insert 52 (insert 42 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs273 support demand
    entries273 ((insert 67 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 34 (insert 52 (insert 42 (insert 37 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 1000 30 loads273
  decide +kernel
def entries274 : List (Fin 1589 × ℕ) := [(37, 9), (72, 254), (77, 278), (137, 46), (179, 18), (273, 51), (341, 188), (343, 6), (352, 213), (415, 64), (421, 2), (438, 107), (439, 179), (472, 162), (475, 216), (479, 300), (491, 118), (507, 287), (550, 26), (571, 4), (588, 57), (616, 69), (617, 278), (632, 473), (639, 158), (675, 11), (717, 104), (730, 381), (737, 157), (741, 70), (753, 129), (756, 18), (800, 122), (813, 325), (850, 487), (872, 11), (886, 26), (890, 271), (897, 59), (898, 119), (929, 1), (930, 211), (940, 227), (968, 169), (969, 36), (973, 310), (978, 357), (985, 295), (1009, 277), (1010, 55), (1045, 82), (1061, 19), (1070, 262), (1075, 186), (1078, 18), (1099, 40), (1104, 29), (1108, 64), (1111, 7), (1132, 1), (1133, 85), (1170, 53), (1171, 39), (1177, 4), (1182, 98), (1183, 130), (1186, 170), (1212, 390), (1238, 200), (1261, 52), (1293, 95), (1323, 18), (1359, 98), (1379, 216), (1380, 12), (1425, 32), (1472, 23), (1499, 47), (1500, 71), (1561, 6), (1577, 84), (1578, 240), (1588, 39)]
def cs274 : List ℕ := [200, 98, 362, 703, 540, 9, 486, 1000, 209, 287, 1000, 1000, 1001, 11, 888, 350, 1000, 844, 1001, 13, 1000, 771, 253, 1000, 999, 1000, 1000, 999, 579, 491, 482, 1000, 637, 92, 0, 1000, 998, 2113, 771, 0, 999, 999, 1057, 1000, 827, 1001, 999, 999, 470, 592, 1000, 590, 1175, 1000, 139, 1000, 1000, 999, 1000, 1000, 26, 931, 1000, 1000, 1000, 1000, 1000, 228, 1000, 999, 916, 812, 1000, 1000, 735, 1000, 75, 999, 999, 1000, 999, 998, 282, 1001, 1000, 999, 715, 999, 999, 1000, 1000, 981, 999, 1000, 556, 476, 999, 999, 1000, 999, 1766, 999, 1001, 730, 583, 786, 999, 1000, 1000, 735, 999, 999, 1000, 555, 709, 1439, 1000, 824, 999, 525, 1000, 999, 870, 999, 999, 679, 314, 310, 900, 1000, 930, 422, 998, 999, 1000, 999, 353, 631, 999, 999, 1000, 651, 999, 1000, 999, 314, 990, 994, 985, 927, 999, 1000, 974, 1000]
theorem loads274 : cs274.get =
    load (fun i : Fin entries274.length => support (entries274.get i).1)
      (fun i => (entries274.get i).2) := by
  apply load_eq_of_sparse_packed base cs274 support code
    entries274 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node274 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 34 (insert 67 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 52 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs274 support demand
    entries274 ((insert 34 (insert 67 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 52 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)) 1000 30 loads274
  decide +kernel
theorem node271 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 52 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 52 (insert 42 (insert 37 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    34 node273 node274
def entries272 : List (Fin 1589 × ℕ) := [(7, 46), (17, 6), (72, 20), (137, 2), (179, 22), (198, 2), (273, 2), (315, 4), (341, 21), (343, 11), (344, 2), (420, 1), (421, 9), (431, 3), (439, 3), (468, 23), (472, 23), (479, 23), (490, 23), (507, 41), (529, 4), (551, 28), (567, 16), (572, 1), (579, 2), (588, 2), (617, 20), (621, 2), (625, 15), (639, 16), (680, 32), (717, 3), (730, 17), (731, 7), (737, 7), (800, 3), (813, 26), (850, 31), (858, 12), (865, 1), (872, 12), (882, 6), (896, 1), (898, 8), (906, 3), (929, 16), (930, 4), (940, 40), (968, 12), (969, 14), (970, 2), (973, 35), (978, 5), (984, 37), (985, 14), (1006, 4), (1009, 7), (1045, 10), (1068, 5), (1070, 14), (1075, 10), (1078, 15), (1082, 1), (1090, 17), (1132, 1), (1133, 5), (1139, 2), (1172, 7), (1173, 22), (1177, 17), (1183, 14), (1186, 13), (1212, 29), (1222, 11), (1246, 1), (1261, 13), (1263, 15), (1320, 5), (1323, 2), (1359, 20), (1401, 4), (1448, 5), (1495, 5), (1499, 8), (1500, 15), (1561, 8), (1566, 4), (1588, 14)]
def cs272 : List ℕ := [0, 100, 34, 37, 69, 11, 35, 100, 21, 41, 26, 77, 100, 68, 24, 39, 100, 100, 88, 6, 99, 75, 36, 100, 100, 101, 101, 100, 47, 22, 92, 101, 77, 0, 101, 100, 100, 86, 99, 3, 100, 100, 76, 100, 101, 101, 99, 100, 66, 72, 100, 100, 0, 100, 48, 101, 99, 99, 101, 99, 0, 101, 49, 100, 101, 101, 101, 27, 100, 100, 100, 99, 99, 100, 60, 102, 32, 100, 100, 101, 92, 100, 35, 98, 100, 101, 77, 100, 100, 101, 101, 91, 99, 100, 75, 39, 100, 99, 99, 101, 161, 101, 99, 77, 76, 66, 99, 101, 100, 62, 101, 101, 99, 72, 100, 131, 100, 72, 101, 60, 100, 100, 99, 101, 99, 75, 52, 40, 82, 101, 100, 59, 101, 100, 101, 100, 74, 67, 100, 101, 101, 71, 100, 92, 100, 52, 101, 101, 101, 101, 100, 101, 90, 91]
theorem loads272 : cs272.get =
    load (fun i : Fin entries272.length => support (entries272.get i).1)
      (fun i => (entries272.get i).2) := by
  apply load_eq_of_sparse_packed base cs272 support code
    entries272 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node272 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 52 (insert 67 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 42 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs272 support demand
    entries272 ((insert 52 (insert 67 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 42 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)) 100 30 loads272
  decide +kernel
theorem node270 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 42 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 42 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154))
    52 node271 node272
theorem node267 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 42 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 42 (insert 37 (insert 115 (insert 100 ∅)))) : Finset (Fin 154))
    67 node269 node270
def entries268 : List (Fin 1589 × ℕ) := [(7, 354), (46, 112), (72, 202), (137, 30), (179, 206), (273, 130), (352, 1), (387, 150), (421, 123), (430, 61), (468, 249), (472, 305), (475, 440), (479, 214), (507, 285), (541, 84), (550, 49), (570, 83), (572, 62), (582, 127), (583, 122), (617, 322), (632, 124), (639, 148), (673, 3), (730, 30), (737, 38), (813, 369), (842, 17), (843, 297), (850, 79), (858, 241), (865, 142), (867, 1), (868, 51), (872, 113), (882, 109), (886, 181), (896, 52), (897, 94), (898, 51), (902, 68), (906, 271), (914, 49), (929, 123), (930, 138), (934, 117), (940, 306), (955, 46), (968, 276), (969, 25), (973, 346), (980, 123), (984, 229), (985, 164), (1006, 39), (1045, 124), (1061, 38), (1070, 87), (1078, 76), (1082, 24), (1099, 96), (1104, 125), (1108, 48), (1131, 55), (1132, 65), (1139, 104), (1167, 214), (1173, 266), (1177, 96), (1183, 135), (1186, 277), (1227, 157), (1228, 88), (1238, 26), (1246, 174), (1251, 67), (1258, 4), (1269, 74), (1310, 169), (1317, 158), (1323, 55), (1359, 206), (1403, 32), (1469, 14), (1499, 63), (1500, 25), (1508, 1)]
def cs268 : List ℕ := [26, 809, 331, 519, 568, 0, 353, 1000, 26, 285, 396, 921, 1000, 467, 398, 158, 997, 1000, 1000, 62, 1000, 924, 351, 1000, 936, 1000, 1000, 1000, 448, 491, 1001, 1000, 904, 282, 1000, 1000, 1000, 1221, 1000, 271, 1000, 1000, 0, 1000, 1000, 1000, 1000, 999, 618, 1001, 999, 1001, 922, 999, 446, 999, 1000, 1000, 1000, 977, 181, 1001, 470, 1000, 999, 999, 999, 1000, 1001, 1000, 790, 1000, 612, 1000, 726, 999, 121, 1000, 999, 1000, 1000, 999, 923, 822, 742, 1000, 874, 999, 1000, 1000, 1000, 851, 1000, 999, 411, 579, 999, 999, 1000, 1000, 1802, 1000, 1000, 966, 774, 792, 999, 1000, 999, 599, 1000, 999, 999, 844, 1000, 1333, 999, 437, 999, 809, 999, 999, 998, 1000, 1000, 988, 442, 346, 855, 999, 1000, 656, 1000, 1000, 999, 999, 708, 684, 1001, 1000, 999, 796, 1000, 1000, 1000, 442, 1000, 973, 1000, 999, 997, 999, 926, 846]
theorem loads268 : cs268.get =
    load (fun i : Fin entries268.length => support (entries268.get i).1)
      (fun i => (entries268.get i).2) := by
  apply load_eq_of_sparse_packed base cs268 support code
    entries268 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node268 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 42 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 115 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs268 support demand
    entries268 ((insert 42 (insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 37 (insert 115 (insert 100 ∅))) : Finset (Fin 154)) 1000 30 loads268
  decide +kernel
theorem node266 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 115 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 60 (insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 37 (insert 115 (insert 100 ∅))) : Finset (Fin 154))
    42 node267 node268
theorem node264 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 115 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 39 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 37 (insert 115 (insert 100 ∅))) : Finset (Fin 154))
    60 node265 node266
theorem node215 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 115 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 37 (insert 115 (insert 100 ∅))) : Finset (Fin 154))
    39 node263 node264
#print axioms node215
end OmissionResidualCover
