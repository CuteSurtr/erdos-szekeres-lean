import ResidualCoverProof.Part00000
import ResidualCoverProof.Part00001
import ResidualCoverProof.Part00002
import ResidualCoverProof.Part00003
import ResidualCoverProof.Part00004
import ResidualCoverProof.Part00005
import ResidualCoverProof.Part00006
import ResidualCoverProof.Part00007
import ResidualCoverProof.Part00008
import ResidualCoverProof.Part00009
import ResidualCoverProof.Part00010
import ResidualCoverProof.Part00011
import ResidualCoverProof.Part00012
import ResidualCoverProof.Part00013
import ResidualCoverProof.Part00014
import ResidualCoverProof.Part00015
import ResidualCoverProof.Part00016
import ResidualCoverProof.Part00017
import ResidualCoverProof.Part00018
import ResidualCoverProof.Part00019
import ResidualCoverProof.Part00020
import ResidualCoverProof.Part00021
import ResidualCoverProof.Part00022
import ResidualCoverProof.Part00023
import ResidualCoverProof.Part00024
import ResidualCoverProof.Part00025
import ResidualCoverProof.Part00026
import ResidualCoverProof.Part00027
import ResidualCoverProof.Part00028
import ResidualCoverProof.Part00029
import ResidualCoverProof.Part00030
import ResidualCoverProof.Part00031
import ResidualCoverProof.Part00032
import ResidualCoverProof.Part00033
import ResidualCoverProof.Part00034
import ResidualCoverProof.Part00035
import ResidualCoverProof.Part00036
import ResidualCoverProof.Part00037
import ResidualCoverProof.Part00038
import ResidualCoverProof.Part00039
import ResidualCoverProof.Part00040
import ResidualCoverProof.Part00041
import ResidualCoverProof.Part00042
import ResidualCoverProof.Part00043
import ResidualCoverProof.Part00044
import ResidualCoverProof.Part00045
import ResidualCoverProof.Part00046
import ResidualCoverProof.Part00047
import ResidualCoverProof.Part00048
import ResidualCoverProof.Part00049
import ResidualCoverProof.Part00050
import ResidualCoverProof.Part00051
import ResidualCoverProof.Part00052
import ResidualCoverProof.Part00053
import ResidualCoverProof.Part00054
import ResidualCoverProof.Part00055
import ResidualCoverProof.Part00056
import ResidualCoverProof.Part00057
import ResidualCoverProof.Part00058
import ResidualCoverProof.Part00059
import ResidualCoverProof.Part00060
import ResidualCoverProof.Part00061
import ResidualCoverProof.Part00062
import ResidualCoverProof.Part00063
import ResidualCoverProof.Part00064
import ResidualCoverProof.Part00065
import ResidualCoverProof.Part00066
import ResidualCoverProof.Part00067
import ResidualCoverProof.Part00068
import ResidualCoverProof.Part00069
import ResidualCoverProof.Part00070
import ResidualCoverProof.Part00071
import ResidualCoverProof.Part00072
import ResidualCoverProof.Part00073
import ResidualCoverProof.Part00074
import ResidualCoverProof.Part00075
import ResidualCoverProof.Part00076
import ResidualCoverProof.Part00077
import ResidualCoverProof.Part00078
import ResidualCoverProof.Part00079
import ResidualCoverProof.Part00080
import ResidualCoverProof.Part00081
import ResidualCoverProof.Part00082
import ResidualCoverProof.Part00083
import ResidualCoverProof.Part00084
import ResidualCoverProof.Part00085
import ResidualCoverProof.Part00086
import ResidualCoverProof.Part00087
import ResidualCoverProof.Part00088
import ResidualCoverProof.Part00089
import ResidualCoverProof.Part00090
import ResidualCoverProof.Part00091
import ResidualCoverProof.Part00092
import ResidualCoverProof.Part00093
import ResidualCoverProof.Part00094
import ResidualCoverProof.Part00095
import ResidualCoverProof.Part00096
import ResidualCoverProof.Part00097
import ResidualCoverProof.Part00098
import ResidualCoverProof.Part00099
import ResidualCoverProof.Part00100
import ResidualCoverProof.Part00101
import ResidualCoverProof.Part00102
import ResidualCoverProof.Part00103
import ResidualCoverProof.Part00104
import ResidualCoverProof.Part00105
import ResidualCoverProof.Part00106
import ResidualCoverProof.Part00107
import ResidualCoverProof.Part00108
import ResidualCoverProof.Part00109
import ResidualCoverProof.Part00110
import ResidualCoverProof.Part00111
import ResidualCoverProof.Part00112
import ResidualCoverProof.Part00113
import ResidualCoverProof.Part00114
import ResidualCoverProof.Part00115
import ResidualCoverProof.Part00116
import ResidualCoverProof.Part00117
import ResidualCoverProof.Part00118
import ResidualCoverProof.Part00119
import ResidualCoverProof.Part00120
import ResidualCoverProof.Part00121
import ResidualCoverProof.Part00122
import ResidualCoverProof.Part00123
import ResidualCoverProof.Part00124
import ResidualCoverProof.Part00125
import ResidualCoverProof.Part00126
import ResidualCoverProof.Part00127
import ResidualCoverProof.Part00128
import ResidualCoverProof.Part00129
import ResidualCoverProof.Part00130
import ResidualCoverProof.Part00131
import ResidualCoverProof.Part00132
import ResidualCoverProof.Part00133
import ResidualCoverProof.Part00134
import ResidualCoverProof.Part00135
import ResidualCoverProof.Part00136
import ResidualCoverProof.Part00137
import ResidualCoverProof.Part00138
import ResidualCoverProof.Part00139
import ResidualCoverProof.Part00140
import ResidualCoverProof.Part00141
import ResidualCoverProof.Part00142
import ResidualCoverProof.Part00143
import ResidualCoverProof.Part00144
import ResidualCoverProof.Part00145
import ResidualCoverProof.Part00146
import ResidualCoverProof.Part00147
import ResidualCoverProof.Part00148
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
theorem node9061 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 67 (insert 33 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 ∅) : Finset (Fin 154)) ((insert 88 (insert 67 (insert 33 (insert 54 (insert 117 ∅))))) : Finset (Fin 154))
    27 node9189 node9190
theorem node9062 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 25 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 25 ∅)) : Finset (Fin 154)) ((insert 67 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154))
    20 node9063 node9064
theorem node9060 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 ∅) : Finset (Fin 154)) ((insert 67 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154))
    88 node9061 node9062
theorem node8535 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 (∅ : Finset (Fin 154)) ((insert 67 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154))
    25 node9059 node9060
theorem node8878 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 67 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 67 ∅)) : Finset (Fin 154)) ((insert 88 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154))
    36 node8879 node8880
theorem node8537 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 ∅) : Finset (Fin 154)) ((insert 88 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154))
    25 node8877 node8878
theorem node8718 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 88 (insert 67 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 88 (insert 67 ∅))) : Finset (Fin 154)) ((insert 36 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154))
    27 node8719 node8720
theorem node8539 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 67 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 67 ∅)) : Finset (Fin 154)) ((insert 36 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154))
    25 node8717 node8718
theorem node8541 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 36 (insert 88 (insert 67 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 36 (insert 88 (insert 67 ∅))) : Finset (Fin 154)) ((insert 27 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154))
    20 node8611 node8612
theorem node8540 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 36 (insert 88 (insert 67 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 36 (insert 88 (insert 67 ∅))) : Finset (Fin 154)) ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154))
    27 node8541 node8542
theorem node8538 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 67 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 67 ∅)) : Finset (Fin 154)) ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154))
    36 node8539 node8540
theorem node8536 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 ∅) : Finset (Fin 154)) ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154))
    88 node8537 node8538
theorem node7617 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 (∅ : Finset (Fin 154)) ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154))
    67 node8535 node8536
theorem node8271 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 25 (insert 67 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 ∅) : Finset (Fin 154)) ((insert 88 (insert 25 (insert 67 (insert 54 (insert 117 ∅))))) : Finset (Fin 154))
    93 node8433 node8434
theorem node8273 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 33 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 25 (insert 67 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 33 ∅)) : Finset (Fin 154)) ((insert 20 (insert 25 (insert 67 (insert 54 (insert 117 ∅))))) : Finset (Fin 154))
    27 node8337 node8338
theorem node8272 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 33 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 67 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 33 ∅)) : Finset (Fin 154)) ((insert 25 (insert 67 (insert 54 (insert 117 ∅)))) : Finset (Fin 154))
    20 node8273 node8274
theorem node8155 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 67 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 ∅) : Finset (Fin 154)) ((insert 25 (insert 67 (insert 54 (insert 117 ∅)))) : Finset (Fin 154))
    88 node8271 node8272
theorem node8156 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 33 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 33 ∅)) : Finset (Fin 154)) ((insert 67 (insert 54 (insert 117 ∅))) : Finset (Fin 154))
    88 node8157 node8158
theorem node7619 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 ∅) : Finset (Fin 154)) ((insert 67 (insert 54 (insert 117 ∅))) : Finset (Fin 154))
    25 node8155 node8156
theorem node7919 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 33 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 88 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 33 ∅)) : Finset (Fin 154)) ((insert 20 (insert 88 (insert 54 (insert 117 ∅)))) : Finset (Fin 154))
    36 node8017 node8018
theorem node7920 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 20 (insert 67 (insert 33 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 20 (insert 67 (insert 33 ∅))) : Finset (Fin 154)) ((insert 88 (insert 54 (insert 117 ∅))) : Finset (Fin 154))
    36 node7921 node7922
theorem node7621 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 33 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 33 ∅)) : Finset (Fin 154)) ((insert 88 (insert 54 (insert 117 ∅))) : Finset (Fin 154))
    20 node7919 node7920
theorem node7623 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 67 (insert 33 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 67 (insert 33 ∅))) : Finset (Fin 154)) ((insert 36 (insert 54 (insert 117 ∅))) : Finset (Fin 154))
    27 node7755 node7756
theorem node7624 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 36 (insert 88 (insert 67 (insert 33 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 54 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 36 (insert 88 (insert 67 (insert 33 ∅)))) : Finset (Fin 154)) ((insert 54 (insert 117 ∅)) : Finset (Fin 154))
    20 node7625 node7626
theorem node7622 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 67 (insert 33 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 54 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 67 (insert 33 ∅))) : Finset (Fin 154)) ((insert 54 (insert 117 ∅)) : Finset (Fin 154))
    36 node7623 node7624
theorem node7620 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 33 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 54 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 33 ∅)) : Finset (Fin 154)) ((insert 54 (insert 117 ∅)) : Finset (Fin 154))
    88 node7621 node7622
theorem node7618 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 54 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 ∅) : Finset (Fin 154)) ((insert 54 (insert 117 ∅)) : Finset (Fin 154))
    67 node7619 node7620
theorem node5835 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 54 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 (∅ : Finset (Fin 154)) ((insert 54 (insert 117 ∅)) : Finset (Fin 154))
    33 node7617 node7618
theorem node7273 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 54 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 25 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 54 ∅) : Finset (Fin 154)) ((insert 67 (insert 25 (insert 33 (insert 117 ∅)))) : Finset (Fin 154))
    88 node7497 node7498
theorem node7275 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 54 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 25 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 54 ∅)) : Finset (Fin 154)) ((insert 88 (insert 25 (insert 33 (insert 117 ∅)))) : Finset (Fin 154))
    27 node7391 node7392
theorem node7276 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 67 (insert 54 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 67 (insert 54 ∅))) : Finset (Fin 154)) ((insert 25 (insert 33 (insert 117 ∅))) : Finset (Fin 154))
    27 node7277 node7278
theorem node7274 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 54 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 54 ∅)) : Finset (Fin 154)) ((insert 25 (insert 33 (insert 117 ∅))) : Finset (Fin 154))
    88 node7275 node7276
theorem node6729 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 54 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 54 ∅) : Finset (Fin 154)) ((insert 25 (insert 33 (insert 117 ∅))) : Finset (Fin 154))
    67 node7273 node7274
theorem node7106 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 25 (insert 54 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 25 (insert 54 ∅))) : Finset (Fin 154)) ((insert 67 (insert 33 (insert 117 ∅))) : Finset (Fin 154))
    20 node7107 node7108
theorem node6731 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 54 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 54 ∅)) : Finset (Fin 154)) ((insert 67 (insert 33 (insert 117 ∅))) : Finset (Fin 154))
    88 node7105 node7106
theorem node6733 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 25 (insert 54 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 25 (insert 54 ∅))) : Finset (Fin 154)) ((insert 88 (insert 33 (insert 117 ∅))) : Finset (Fin 154))
    27 node6959 node6960
theorem node6735 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 67 (insert 25 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 67 (insert 25 (insert 54 ∅)))) : Finset (Fin 154)) ((insert 27 (insert 33 (insert 117 ∅))) : Finset (Fin 154))
    34 node6849 node6850
theorem node6736 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 27 (insert 88 (insert 67 (insert 25 (insert 54 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 27 (insert 88 (insert 67 (insert 25 (insert 54 ∅))))) : Finset (Fin 154)) ((insert 33 (insert 117 ∅)) : Finset (Fin 154))
    34 node6737 node6738
theorem node6734 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 67 (insert 25 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 67 (insert 25 (insert 54 ∅)))) : Finset (Fin 154)) ((insert 33 (insert 117 ∅)) : Finset (Fin 154))
    27 node6735 node6736
theorem node6732 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 25 (insert 54 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 25 (insert 54 ∅))) : Finset (Fin 154)) ((insert 33 (insert 117 ∅)) : Finset (Fin 154))
    88 node6733 node6734
theorem node6730 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 54 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 54 ∅)) : Finset (Fin 154)) ((insert 33 (insert 117 ∅)) : Finset (Fin 154))
    67 node6731 node6732
theorem node5837 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 54 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 54 ∅) : Finset (Fin 154)) ((insert 33 (insert 117 ∅)) : Finset (Fin 154))
    25 node6729 node6730
theorem node6381 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 54 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 67 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 54 ∅)) : Finset (Fin 154)) ((insert 88 (insert 67 (insert 117 ∅))) : Finset (Fin 154))
    93 node6571 node6572
theorem node6383 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 33 (insert 54 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 67 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 33 (insert 54 ∅))) : Finset (Fin 154)) ((insert 27 (insert 67 (insert 117 ∅))) : Finset (Fin 154))
    20 node6455 node6456
theorem node6382 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 33 (insert 54 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 33 (insert 54 ∅))) : Finset (Fin 154)) ((insert 67 (insert 117 ∅)) : Finset (Fin 154))
    27 node6383 node6384
theorem node5839 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 54 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 54 ∅)) : Finset (Fin 154)) ((insert 67 (insert 117 ∅)) : Finset (Fin 154))
    88 node6381 node6382
theorem node6189 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 88 (insert 117 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154)) ((insert 27 (insert 88 (insert 117 ∅))) : Finset (Fin 154))
    20 node6267 node6268
theorem node5841 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 88 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154)) ((insert 88 (insert 117 ∅)) : Finset (Fin 154))
    27 node6189 node6190
theorem node5843 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 67 (insert 33 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 27 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 67 (insert 33 (insert 54 ∅)))) : Finset (Fin 154)) ((insert 27 (insert 117 ∅)) : Finset (Fin 154))
    20 node6019 node6020
theorem node5845 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 27 (insert 88 (insert 67 (insert 33 (insert 54 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 56 (insert 117 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 27 (insert 88 (insert 67 (insert 33 (insert 54 ∅))))) : Finset (Fin 154)) ((insert 56 (insert 117 ∅)) : Finset (Fin 154))
    44 node5891 node5892
theorem node5844 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 27 (insert 88 (insert 67 (insert 33 (insert 54 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 117 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 27 (insert 88 (insert 67 (insert 33 (insert 54 ∅))))) : Finset (Fin 154)) ((insert 117 ∅) : Finset (Fin 154))
    56 node5845 node5846
theorem node5842 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 88 (insert 67 (insert 33 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 117 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 88 (insert 67 (insert 33 (insert 54 ∅)))) : Finset (Fin 154)) ((insert 117 ∅) : Finset (Fin 154))
    27 node5843 node5844
theorem node5840 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 117 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154)) ((insert 117 ∅) : Finset (Fin 154))
    88 node5841 node5842
theorem node5838 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 54 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 117 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 54 ∅)) : Finset (Fin 154)) ((insert 117 ∅) : Finset (Fin 154))
    67 node5839 node5840
theorem node5836 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 54 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 117 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 54 ∅) : Finset (Fin 154)) ((insert 117 ∅) : Finset (Fin 154))
    33 node5837 node5838
theorem node1 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 117 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 (∅ : Finset (Fin 154)) ((insert 117 ∅) : Finset (Fin 154))
    54 node5835 node5836
theorem node5584 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 27 (insert 25 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 67 (insert 33 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 27 (insert 25 (insert 117 ∅))) : Finset (Fin 154)) ((insert 36 (insert 67 (insert 33 (insert 54 ∅)))) : Finset (Fin 154))
    88 node5585 node5586
theorem node5435 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 67 (insert 33 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 117 ∅)) : Finset (Fin 154)) ((insert 36 (insert 67 (insert 33 (insert 54 ∅)))) : Finset (Fin 154))
    27 node5583 node5584
theorem node5437 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 36 (insert 25 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 67 (insert 33 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 36 (insert 25 (insert 117 ∅))) : Finset (Fin 154)) ((insert 20 (insert 67 (insert 33 (insert 54 ∅)))) : Finset (Fin 154))
    27 node5483 node5484
theorem node5436 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 36 (insert 25 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 36 (insert 25 (insert 117 ∅))) : Finset (Fin 154)) ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154))
    20 node5437 node5438
theorem node5434 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 117 ∅)) : Finset (Fin 154)) ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154))
    36 node5435 node5436
theorem node4913 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 117 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 117 ∅) : Finset (Fin 154)) ((insert 67 (insert 33 (insert 54 ∅))) : Finset (Fin 154))
    25 node5433 node5434
theorem node5212 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 27 (insert 25 (insert 67 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 37 (insert 33 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 27 (insert 25 (insert 67 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 36 (insert 37 (insert 33 (insert 54 ∅)))) : Finset (Fin 154))
    88 node5213 node5214
theorem node5075 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 67 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 37 (insert 33 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 67 (insert 117 ∅))) : Finset (Fin 154)) ((insert 36 (insert 37 (insert 33 (insert 54 ∅)))) : Finset (Fin 154))
    27 node5211 node5212
theorem node5076 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 36 (insert 25 (insert 67 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 33 (insert 54 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 36 (insert 25 (insert 67 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 37 (insert 33 (insert 54 ∅))) : Finset (Fin 154))
    20 node5077 node5078
theorem node5074 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 67 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 33 (insert 54 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 67 (insert 117 ∅))) : Finset (Fin 154)) ((insert 37 (insert 33 (insert 54 ∅))) : Finset (Fin 154))
    36 node5075 node5076
theorem node4915 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 33 (insert 54 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 117 ∅)) : Finset (Fin 154)) ((insert 37 (insert 33 (insert 54 ∅))) : Finset (Fin 154))
    25 node5073 node5074
theorem node4918 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 37 (insert 67 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 54 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 37 (insert 67 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 33 (insert 54 ∅)) : Finset (Fin 154))
    109 node4919 node4920
theorem node4916 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 67 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 54 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 67 (insert 117 ∅))) : Finset (Fin 154)) ((insert 33 (insert 54 ∅)) : Finset (Fin 154))
    25 node4917 node4918
theorem node4914 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 54 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 117 ∅)) : Finset (Fin 154)) ((insert 33 (insert 54 ∅)) : Finset (Fin 154))
    37 node4915 node4916
theorem node3477 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 117 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 54 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 117 ∅) : Finset (Fin 154)) ((insert 33 (insert 54 ∅)) : Finset (Fin 154))
    67 node4913 node4914
theorem node4743 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 67 (insert 37 (insert 109 (insert 54 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 117 ∅)) : Finset (Fin 154)) ((insert 25 (insert 67 (insert 37 (insert 109 (insert 54 ∅))))) : Finset (Fin 154))
    20 node4805 node4806
theorem node4525 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 37 (insert 109 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 117 ∅)) : Finset (Fin 154)) ((insert 67 (insert 37 (insert 109 (insert 54 ∅)))) : Finset (Fin 154))
    25 node4743 node4744
theorem node4527 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 36 (insert 37 (insert 109 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 33 (insert 117 ∅))) : Finset (Fin 154)) ((insert 36 (insert 37 (insert 109 (insert 54 ∅)))) : Finset (Fin 154))
    27 node4621 node4622
theorem node4526 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 109 (insert 54 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 33 (insert 117 ∅))) : Finset (Fin 154)) ((insert 37 (insert 109 (insert 54 ∅))) : Finset (Fin 154))
    36 node4527 node4528
theorem node4377 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 109 (insert 54 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 117 ∅)) : Finset (Fin 154)) ((insert 37 (insert 109 (insert 54 ∅))) : Finset (Fin 154))
    67 node4525 node4526
theorem node4378 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 109 (insert 54 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 33 (insert 117 ∅))) : Finset (Fin 154)) ((insert 109 (insert 54 ∅)) : Finset (Fin 154))
    67 node4379 node4380
theorem node3479 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 109 (insert 54 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 117 ∅)) : Finset (Fin 154)) ((insert 109 (insert 54 ∅)) : Finset (Fin 154))
    37 node4377 node4378
theorem node4031 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 109 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 25 (insert 37 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 109 (insert 33 (insert 117 ∅))) : Finset (Fin 154)) ((insert 67 (insert 25 (insert 37 (insert 54 ∅)))) : Finset (Fin 154))
    27 node4227 node4228
theorem node4033 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 25 (insert 37 (insert 54 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 57 (insert 25 (insert 37 (insert 54 ∅)))) : Finset (Fin 154))
    88 node4113 node4114
theorem node4032 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 37 (insert 54 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 25 (insert 37 (insert 54 ∅))) : Finset (Fin 154))
    57 node4033 node4034
theorem node3787 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 109 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 37 (insert 54 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 109 (insert 33 (insert 117 ∅))) : Finset (Fin 154)) ((insert 25 (insert 37 (insert 54 ∅))) : Finset (Fin 154))
    67 node4031 node4032
theorem node3789 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 20 (insert 37 (insert 54 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 20 (insert 37 (insert 54 ∅))) : Finset (Fin 154))
    27 node3915 node3916
theorem node3790 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 20 (insert 25 (insert 109 (insert 33 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 54 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 20 (insert 25 (insert 109 (insert 33 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 37 (insert 54 ∅)) : Finset (Fin 154))
    57 node3791 node3792
theorem node3788 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 54 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 37 (insert 54 ∅)) : Finset (Fin 154))
    20 node3789 node3790
theorem node3481 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 109 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 54 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 109 (insert 33 (insert 117 ∅))) : Finset (Fin 154)) ((insert 37 (insert 54 ∅)) : Finset (Fin 154))
    25 node3787 node3788
theorem node3483 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 54 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 67 (insert 54 ∅)) : Finset (Fin 154))
    25 node3643 node3644
theorem node3485 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 37 (insert 109 (insert 33 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 57 (insert 54 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 37 (insert 109 (insert 33 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 57 (insert 54 ∅)) : Finset (Fin 154))
    20 node3547 node3548
theorem node3484 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 37 (insert 109 (insert 33 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 54 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 37 (insert 109 (insert 33 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 54 ∅) : Finset (Fin 154))
    57 node3485 node3486
theorem node3482 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 54 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 109 (insert 33 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 54 ∅) : Finset (Fin 154))
    67 node3483 node3484
theorem node3480 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 109 (insert 33 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 54 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 109 (insert 33 (insert 117 ∅))) : Finset (Fin 154)) ((insert 54 ∅) : Finset (Fin 154))
    37 node3481 node3482
theorem node3478 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 54 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 117 ∅)) : Finset (Fin 154)) ((insert 54 ∅) : Finset (Fin 154))
    109 node3479 node3480
theorem node3 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 117 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 54 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 117 ∅) : Finset (Fin 154)) ((insert 54 ∅) : Finset (Fin 154))
    33 node3477 node3478
theorem node3199 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 54 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 37 (insert 33 (insert 109 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 54 (insert 117 ∅)) : Finset (Fin 154)) ((insert 25 (insert 37 (insert 33 (insert 109 ∅)))) : Finset (Fin 154))
    67 node3367 node3368
theorem node3202 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 25 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 33 (insert 109 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 25 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 37 (insert 33 (insert 109 ∅))) : Finset (Fin 154))
    88 node3203 node3204
theorem node3200 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 33 (insert 109 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 54 (insert 117 ∅))) : Finset (Fin 154)) ((insert 37 (insert 33 (insert 109 ∅))) : Finset (Fin 154))
    67 node3201 node3202
theorem node3043 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 54 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 33 (insert 109 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 54 (insert 117 ∅)) : Finset (Fin 154)) ((insert 37 (insert 33 (insert 109 ∅))) : Finset (Fin 154))
    25 node3199 node3200
theorem node3046 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 37 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 109 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 37 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 33 (insert 109 ∅)) : Finset (Fin 154))
    67 node3047 node3048
theorem node3044 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 109 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 54 (insert 117 ∅))) : Finset (Fin 154)) ((insert 33 (insert 109 ∅)) : Finset (Fin 154))
    25 node3045 node3046
theorem node2581 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 54 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 (insert 109 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 54 (insert 117 ∅)) : Finset (Fin 154)) ((insert 33 (insert 109 ∅)) : Finset (Fin 154))
    37 node3043 node3044
theorem node2739 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 37 (insert 109 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154)) ((insert 67 (insert 37 (insert 109 ∅))) : Finset (Fin 154))
    27 node2901 node2902
theorem node2740 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 109 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 37 (insert 109 ∅)) : Finset (Fin 154))
    88 node2741 node2742
theorem node2583 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 109 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154)) ((insert 37 (insert 109 ∅)) : Finset (Fin 154))
    67 node2739 node2740
theorem node2584 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 109 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 33 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 109 ∅) : Finset (Fin 154))
    67 node2585 node2586
theorem node2582 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 109 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 54 (insert 117 ∅))) : Finset (Fin 154)) ((insert 109 ∅) : Finset (Fin 154))
    37 node2583 node2584
theorem node5 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 54 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 109 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 54 (insert 117 ∅)) : Finset (Fin 154)) ((insert 109 ∅) : Finset (Fin 154))
    33 node2581 node2582
theorem node2215 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 109 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 37 (insert 33 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 109 (insert 54 (insert 117 ∅))) : Finset (Fin 154)) ((insert 25 (insert 37 (insert 33 ∅))) : Finset (Fin 154))
    67 node2445 node2446
theorem node2218 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 25 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 33 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 25 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 37 (insert 33 ∅)) : Finset (Fin 154))
    34 node2219 node2220
theorem node2216 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 33 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 37 (insert 33 ∅)) : Finset (Fin 154))
    67 node2217 node2218
theorem node1841 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 109 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 33 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 109 (insert 54 (insert 117 ∅))) : Finset (Fin 154)) ((insert 37 (insert 33 ∅)) : Finset (Fin 154))
    25 node2215 node2216
theorem node2008 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 37 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 76 (insert 33 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 37 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 76 (insert 33 ∅)) : Finset (Fin 154))
    67 node2009 node2010
theorem node1843 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 76 (insert 33 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 76 (insert 33 ∅)) : Finset (Fin 154))
    25 node2007 node2008
theorem node1846 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 25 (insert 76 (insert 37 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 25 (insert 76 (insert 37 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)) ((insert 33 ∅) : Finset (Fin 154))
    67 node1847 node1848
theorem node1844 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 76 (insert 37 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 76 (insert 37 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 33 ∅) : Finset (Fin 154))
    25 node1845 node1846
theorem node1842 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 33 ∅) : Finset (Fin 154))
    76 node1843 node1844
theorem node7 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 109 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 33 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 109 (insert 54 (insert 117 ∅))) : Finset (Fin 154)) ((insert 33 ∅) : Finset (Fin 154))
    37 node1841 node1842
theorem node1623 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 25 (insert 67 (insert 37 (insert 76 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 25 (insert 67 (insert 37 (insert 76 ∅)))) : Finset (Fin 154))
    70 node1641 node1642
theorem node1622 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 37 (insert 76 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 67 (insert 37 (insert 76 ∅))) : Finset (Fin 154))
    25 node1623 node1624
theorem node1467 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 37 (insert 76 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 67 (insert 37 (insert 76 ∅))) : Finset (Fin 154))
    47 node1621 node1622
theorem node1468 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 67 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 76 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 67 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 37 (insert 76 ∅)) : Finset (Fin 154))
    47 node1469 node1470
theorem node1261 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 76 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 37 (insert 76 ∅)) : Finset (Fin 154))
    67 node1467 node1468
theorem node1263 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 67 (insert 76 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 67 (insert 76 ∅)) : Finset (Fin 154))
    47 node1347 node1348
theorem node1262 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 76 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 76 ∅) : Finset (Fin 154))
    67 node1263 node1264
theorem node9 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 76 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)) ((insert 76 ∅) : Finset (Fin 154))
    37 node1261 node1262
theorem node913 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 119 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 37 (insert 119 ∅)) : Finset (Fin 154))
    67 node1095 node1096
theorem node915 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 125 (insert 119 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)) ((insert 125 (insert 119 ∅)) : Finset (Fin 154))
    67 node975 node976
theorem node914 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 119 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)) ((insert 119 ∅) : Finset (Fin 154))
    125 node915 node916
theorem node11 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 119 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)) ((insert 119 ∅) : Finset (Fin 154))
    37 node913 node914
theorem node718 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 126 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)) ((insert 37 (insert 126 ∅)) : Finset (Fin 154))
    69 node719 node720
theorem node549 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 37 (insert 126 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)) ((insert 37 (insert 126 ∅)) : Finset (Fin 154))
    47 node717 node718
theorem node579 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 95 (insert 104 (insert 126 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)) ((insert 95 (insert 104 (insert 126 ∅))) : Finset (Fin 154))
    86 node603 node604
theorem node551 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 104 (insert 126 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)) ((insert 104 (insert 126 ∅)) : Finset (Fin 154))
    95 node579 node580
theorem node550 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 126 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)) ((insert 126 ∅) : Finset (Fin 154))
    104 node551 node552
theorem node13 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 126 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)) ((insert 126 ∅) : Finset (Fin 154))
    37 node549 node550
theorem node339 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 137 (insert 127 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)) ((insert 137 (insert 127 ∅)) : Finset (Fin 154))
    37 node429 node430
theorem node15 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 127 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)) ((insert 127 ∅) : Finset (Fin 154))
    137 node339 node340
theorem node155 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 115 (insert 100 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 115 (insert 100 ∅)) : Finset (Fin 154))
    37 node215 node216
theorem node17 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 100 ∅) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) ((insert 100 ∅) : Finset (Fin 154))
    115 node155 node156
theorem node18 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 100 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) (∅ : Finset (Fin 154))
    101 node19 node20
theorem node16 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))) : Finset (Fin 154)) (∅ : Finset (Fin 154))
    100 node17 node18
theorem node14 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))) : Finset (Fin 154)) (∅ : Finset (Fin 154))
    127 node15 node16
theorem node12 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))) : Finset (Fin 154)) (∅ : Finset (Fin 154))
    126 node13 node14
theorem node10 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))) : Finset (Fin 154)) (∅ : Finset (Fin 154))
    119 node11 node12
theorem node8 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 33 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 33 (insert 109 (insert 54 (insert 117 ∅)))) : Finset (Fin 154)) (∅ : Finset (Fin 154))
    76 node9 node10
theorem node6 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 109 (insert 54 (insert 117 ∅))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 109 (insert 54 (insert 117 ∅))) : Finset (Fin 154)) (∅ : Finset (Fin 154))
    33 node7 node8
theorem node4 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 54 (insert 117 ∅)) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 54 (insert 117 ∅)) : Finset (Fin 154)) (∅ : Finset (Fin 154))
    109 node5 node6
theorem node2 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 117 ∅) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 117 ∅) : Finset (Fin 154)) (∅ : Finset (Fin 154))
    54 node3 node4
theorem node0 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ (∅ : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 (∅ : Finset (Fin 154)) (∅ : Finset (Fin 154))
    117 node1 node2
theorem excludes_budget :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 := by
  rintro ⟨holes, hbool, hrows, hb⟩
  exact node0 ⟨holes, hbool, hrows, hb, by simp, by simp⟩
#print axioms excludes_budget
end OmissionResidualCover
