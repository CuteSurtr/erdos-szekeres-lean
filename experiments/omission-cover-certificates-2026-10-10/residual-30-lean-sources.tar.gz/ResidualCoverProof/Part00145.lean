import ResidualCoverProof.Catalog
open scoped BigOperators
open ErdosSzekeres.OmissionCertificates
namespace OmissionResidualCover
set_option maxRecDepth 100000
set_option maxHeartbeats 100000000
def entries259 : List (Fin 1589 × ℕ) := [(20, 291), (30, 3), (43, 73), (46, 317), (77, 131), (96, 12), (122, 185), (179, 247), (205, 25), (341, 257), (343, 207), (466, 270), (479, 185), (485, 157), (506, 178), (507, 117), (570, 4), (583, 156), (616, 47), (617, 181), (673, 119), (680, 18), (730, 96), (776, 28), (813, 129), (842, 91), (868, 185), (869, 98), (870, 59), (871, 185), (872, 222), (881, 58), (882, 34), (886, 28), (906, 224), (916, 6), (922, 126), (924, 234), (929, 27), (930, 147), (934, 408), (940, 581), (952, 163), (973, 236), (984, 294), (985, 193), (1006, 3), (1030, 235), (1031, 1), (1045, 49), (1061, 200), (1099, 119), (1104, 3), (1108, 183), (1110, 80), (1113, 74), (1114, 56), (1128, 178), (1132, 173), (1133, 249), (1139, 173), (1148, 15), (1149, 155), (1153, 325), (1159, 58), (1167, 70), (1169, 164), (1173, 101), (1177, 155), (1183, 345), (1219, 92), (1236, 61), (1267, 265), (1268, 55), (1275, 99), (1280, 117), (1335, 89), (1342, 429), (1359, 275), (1372, 18), (1403, 28), (1491, 279)]
def cs259 : List ℕ := [448, 484, 0, 383, 246, 338, 390, 1000, 294, 295, 316, 972, 972, 786, 521, 556, 1000, 1000, 1000, 55, 1000, 999, 247, 1000, 1001, 998, 999, 1001, 581, 928, 1000, 999, 965, 234, 1001, 999, 1001, 0, 999, 1001, 999, 1000, 464, 999, 999, 1000, 1000, 1704, 957, 1000, 1000, 1000, 738, 1000, 509, 2007, 2577, 999, 1001, 1000, 1000, 1001, 649, 999, 934, 1000, 1000, 1000, 1000, 999, 1000, 1001, 1000, 1000, 613, 999, 173, 999, 1000, 1000, 1000, 1000, 190, 1001, 790, 1000, 681, 1001, 1001, 998, 999, 923, 1000, 1000, 789, 755, 808, 1001, 1000, 999, 2104, 1000, 1000, 593, 556, 1000, 1000, 998, 1001, 0, 999, 999, 362, 723, 829, 2016, 1000, 345, 1000, 1051, 649, 913, 1646, 999, 1000, 744, 391, 237, 805, 1041, 999, 875, 1001, 1000, 1001, 1000, 647, 535, 1000, 1000, 1173, 611, 999, 1279, 1000, 391, 1000, 668, 1001, 815, 942, 739, 708, 680]
theorem loads259 : cs259.get =
    load (fun i : Fin entries259.length => support (entries259.get i).1)
      (fun i => (entries259.get i).2) := by
  apply load_eq_of_sparse_packed base cs259 support code
    entries259 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node259 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 56 (insert 129 (insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs259 support demand
    entries259 ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 56 (insert 129 (insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))))))) : Finset (Fin 154)) 1000 30 loads259
  decide +kernel
def entries261 : List (Fin 1589 × ℕ) := [(30, 32), (43, 401), (205, 37), (387, 348), (479, 191), (496, 284), (507, 336), (515, 92), (582, 159), (616, 144), (617, 219), (623, 52), (637, 111), (639, 117), (673, 34), (737, 193), (797, 24), (798, 281), (799, 59), (813, 183), (842, 170), (844, 108), (864, 37), (866, 22), (868, 28), (870, 126), (872, 18), (886, 124), (893, 57), (894, 125), (895, 18), (905, 151), (906, 217), (922, 74), (925, 227), (927, 192), (928, 12), (929, 23), (930, 163), (940, 599), (952, 217), (970, 322), (973, 176), (984, 236), (985, 126), (1005, 62), (1006, 122), (1030, 203), (1031, 46), (1070, 52), (1082, 60), (1099, 141), (1108, 126), (1114, 17), (1122, 75), (1123, 142), (1128, 100), (1133, 134), (1137, 137), (1139, 26), (1149, 189), (1153, 442), (1160, 92), (1169, 202), (1173, 90), (1177, 264), (1183, 139), (1217, 68), (1219, 316), (1221, 53), (1234, 297), (1261, 154), (1266, 46), (1267, 173), (1269, 4), (1275, 160), (1312, 170), (1335, 342), (1359, 88), (1398, 3), (1498, 34), (1499, 53), (1525, 176), (1582, 49)]
def cs261 : List ℕ := [229, 404, 297, 365, 191, 236, 450, 1000, 316, 549, 367, 651, 1000, 50, 401, 83, 1000, 1000, 1000, 0, 1000, 965, 0, 1000, 1000, 999, 999, 999, 278, 512, 1000, 999, 773, 310, 1001, 944, 1000, 49, 857, 1001, 1000, 1000, 203, 999, 1000, 1000, 1000, 1758, 467, 1001, 1001, 999, 680, 1000, 196, 1893, 167, 1000, 969, 1000, 1000, 945, 841, 999, 947, 1000, 1001, 1000, 886, 999, 1000, 1000, 1000, 999, 502, 1000, 301, 999, 1001, 1001, 1000, 1000, 1000, 1000, 467, 1000, 881, 1000, 1000, 999, 1000, 604, 1000, 2693, 497, 859, 999, 1000, 1001, 1000, 2150, 1000, 1000, 1000, 662, 1000, 1000, 999, 1000, 0, 999, 1000, 1000, 1001, 1001, 1661, 1000, 461, 999, 777, 999, 891, 1164, 1000, 1000, 916, 440, 439, 829, 1547, 1000, 982, 1000, 1000, 1000, 1000, 719, 561, 1001, 999, 1510, 651, 1000, 1100, 1001, 440, 1000, 641, 1000, 914, 989, 734, 964, 567]
theorem loads261 : cs261.get =
    load (fun i : Fin entries261.length => support (entries261.get i).1)
      (fun i => (entries261.get i).2) := by
  apply load_eq_of_sparse_packed base cs261 support code
    entries261 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node261 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 56 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 129 (insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs261 support demand
    entries261 ((insert 56 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 93 (insert 129 (insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))))))) : Finset (Fin 154)) 1000 30 loads261
  decide +kernel
def entries262 : List (Fin 1589 × ℕ) := [(20, 4), (43, 48), (205, 9), (315, 15), (399, 18), (421, 17), (466, 23), (479, 28), (485, 12), (496, 8), (506, 5), (507, 11), (515, 7), (542, 12), (552, 9), (582, 6), (583, 27), (584, 12), (616, 30), (617, 9), (639, 23), (730, 7), (731, 27), (800, 1), (813, 30), (819, 3), (842, 33), (843, 5), (853, 16), (855, 3), (863, 1), (870, 25), (871, 2), (872, 20), (895, 7), (905, 10), (906, 25), (920, 1), (925, 14), (928, 2), (929, 9), (930, 9), (935, 7), (938, 32), (939, 7), (940, 2), (952, 22), (973, 42), (984, 23), (985, 22), (995, 1), (1005, 19), (1090, 5), (1099, 2), (1104, 8), (1108, 5), (1113, 4), (1114, 16), (1126, 2), (1128, 10), (1133, 17), (1137, 5), (1153, 39), (1169, 26), (1173, 15), (1177, 21), (1183, 27), (1186, 16), (1219, 13), (1221, 10), (1225, 1), (1246, 21), (1258, 3), (1275, 5), (1359, 5), (1498, 1), (1499, 19), (1500, 4), (1525, 20), (1528, 5), (1582, 10)]
def cs262 : List ℕ := [33, 18, 30, 27, 28, 52, 58, 99, 12, 37, 37, 76, 101, 26, 60, 20, 101, 100, 101, 0, 100, 100, 0, 99, 100, 100, 101, 101, 19, 52, 99, 101, 63, 26, 100, 100, 101, 13, 41, 100, 100, 100, 45, 99, 100, 101, 99, 105, 60, 100, 100, 100, 57, 99, 44, 200, 27, 100, 99, 99, 101, 99, 44, 101, 97, 101, 101, 99, 99, 99, 100, 99, 73, 90, 51, 101, 26, 99, 99, 100, 99, 99, 84, 100, 60, 100, 95, 98, 96, 100, 100, 107, 100, 2, 57, 100, 98, 100, 99, 99, 167, 101, 100, 100, 50, 100, 99, 100, 100, 16, 101, 100, 100, 99, 98, 112, 101, 43, 99, 88, 100, 80, 142, 101, 92, 88, 68, 42, 91, 115, 89, 94, 100, 100, 101, 99, 83, 73, 100, 101, 130, 64, 100, 122, 99, 63, 88, 101, 101, 99, 78, 101, 100, 90]
theorem loads262 : cs262.get =
    load (fun i : Fin entries262.length => support (entries262.get i).1)
      (fun i => (entries262.get i).2) := by
  apply load_eq_of_sparse_packed base cs262 support code
    entries262 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node262 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 56 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 129 (insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs262 support demand
    entries262 ((insert 93 (insert 56 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 129 (insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154)) 100 30 loads262
  decide +kernel
theorem node260 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 56 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 129 (insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 56 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 129 (insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154))
    93 node261 node262
theorem node257 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 129 (insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 129 (insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))))) : Finset (Fin 154))
    56 node259 node260
def entries258 : List (Fin 1589 × ℕ) := [(20, 7), (30, 96), (43, 412), (75, 7), (179, 168), (205, 80), (315, 382), (341, 68), (386, 21), (466, 190), (479, 251), (485, 31), (496, 64), (506, 272), (507, 190), (515, 188), (582, 94), (583, 49), (616, 158), (617, 132), (673, 55), (681, 35), (731, 123), (797, 59), (813, 140), (843, 442), (848, 64), (863, 23), (868, 127), (869, 67), (870, 153), (871, 101), (872, 129), (886, 96), (894, 52), (905, 51), (906, 149), (911, 71), (917, 1), (920, 44), (922, 20), (925, 185), (930, 315), (938, 132), (940, 440), (952, 232), (955, 61), (968, 105), (973, 349), (978, 104), (984, 96), (985, 232), (995, 22), (1005, 81), (1006, 48), (1012, 5), (1030, 168), (1045, 120), (1061, 220), (1068, 53), (1082, 201), (1097, 21), (1100, 92), (1110, 11), (1111, 132), (1126, 184), (1133, 246), (1139, 87), (1159, 33), (1169, 282), (1177, 201), (1182, 305), (1188, 58), (1219, 257), (1227, 77), (1233, 53), (1246, 150), (1267, 213), (1268, 9), (1342, 131), (1359, 238), (1372, 18), (1403, 23), (1477, 62), (1491, 258)]
def cs258 : List ℕ := [190, 495, 64, 264, 251, 127, 412, 1000, 167, 485, 322, 905, 780, 360, 419, 258, 1000, 1000, 999, 9, 1000, 1000, 168, 1000, 1000, 1000, 998, 1000, 213, 665, 1001, 998, 936, 282, 1000, 999, 999, 71, 938, 1000, 999, 1000, 337, 1000, 1000, 1001, 999, 1899, 630, 1001, 1000, 999, 522, 999, 64, 1961, 1000, 1000, 999, 999, 1000, 999, 595, 999, 919, 999, 1001, 999, 1002, 999, 1000, 999, 1000, 999, 568, 1000, 277, 998, 1000, 1000, 999, 998, 366, 1000, 727, 1001, 709, 1000, 999, 999, 1001, 1109, 999, 999, 673, 1000, 1001, 999, 999, 1001, 2040, 999, 1000, 999, 388, 1000, 1000, 754, 1001, 166, 999, 1000, 1000, 799, 1000, 1737, 940, 305, 1001, 964, 999, 1000, 1061, 1000, 1000, 679, 550, 354, 791, 0, 1000, 1000, 635, 1000, 552, 631, 550, 825, 1000, 1000, 785, 349, 1000, 786, 867, 550, 1000, 1000, 908, 349, 794, 796, 687, 402]
theorem loads258 : cs258.get =
    load (fun i : Fin entries258.length => support (entries258.get i).1)
      (fun i => (entries258.get i).2) := by
  apply load_eq_of_sparse_packed base cs258 support code
    entries258 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node258 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 129 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs258 support demand
    entries258 ((insert 129 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)) 1000 30 loads258
  decide +kernel
theorem node255 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 140 (insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))))) : Finset (Fin 154))
    129 node257 node258
def entries256 : List (Fin 1589 × ℕ) := [(43, 43), (122, 2), (179, 14), (205, 12), (315, 37), (399, 12), (415, 6), (466, 21), (479, 29), (485, 14), (506, 20), (507, 12), (582, 13), (583, 13), (616, 19), (617, 10), (637, 8), (639, 1), (673, 9), (731, 2), (798, 9), (800, 2), (813, 5), (819, 3), (843, 48), (855, 7), (856, 3), (868, 24), (869, 9), (870, 9), (871, 19), (872, 15), (882, 10), (886, 9), (894, 1), (906, 36), (916, 3), (920, 3), (925, 13), (928, 9), (930, 17), (938, 17), (940, 40), (952, 21), (968, 5), (973, 38), (978, 14), (985, 17), (1005, 20), (1006, 4), (1030, 10), (1056, 1), (1061, 20), (1068, 7), (1082, 17), (1099, 6), (1100, 4), (1108, 7), (1111, 18), (1114, 6), (1128, 22), (1139, 13), (1153, 13), (1169, 36), (1173, 1), (1176, 15), (1181, 19), (1182, 7), (1188, 12), (1219, 21), (1221, 2), (1234, 19), (1252, 15), (1267, 22), (1293, 1), (1297, 3), (1342, 22), (1359, 27), (1478, 4), (1491, 15), (1582, 4)]
def cs256 : List ℕ := [23, 48, 2, 25, 29, 30, 47, 100, 0, 32, 28, 89, 99, 34, 43, 31, 98, 100, 98, 0, 99, 94, 14, 100, 99, 98, 99, 99, 24, 65, 99, 99, 74, 36, 99, 100, 99, 11, 85, 100, 100, 100, 24, 99, 99, 99, 101, 198, 71, 99, 99, 100, 48, 99, 3, 226, 100, 100, 100, 100, 99, 100, 51, 99, 85, 98, 100, 101, 99, 100, 100, 99, 97, 100, 68, 100, 27, 100, 100, 100, 100, 99, 39, 100, 73, 100, 58, 99, 100, 99, 100, 109, 100, 100, 77, 99, 100, 72, 100, 99, 208, 99, 100, 101, 35, 100, 101, 100, 100, 24, 99, 100, 100, 78, 100, 153, 101, 7, 99, 78, 101, 99, 122, 100, 92, 79, 53, 57, 62, 100, 82, 99, 96, 101, 38, 94, 54, 100, 100, 100, 7, 79, 100, 100, 101, 57, 100, 99, 63, 100, 95, 38, 92, 41]
theorem loads256 : cs256.get =
    load (fun i : Fin entries256.length => support (entries256.get i).1)
      (fun i => (entries256.get i).2) := by
  apply load_eq_of_sparse_packed base cs256 support code
    entries256 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node256 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 140 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs256 support demand
    entries256 ((insert 140 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)) 100 30 loads256
  decide +kernel
theorem node253 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 143 (insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154))
    140 node255 node256
def entries254 : List (Fin 1589 × ℕ) := [(30, 4), (33, 28), (35, 135), (43, 227), (96, 129), (179, 162), (205, 112), (315, 187), (341, 51), (343, 2), (415, 28), (466, 238), (479, 365), (485, 140), (496, 26), (506, 225), (507, 147), (515, 174), (583, 93), (584, 60), (617, 182), (640, 68), (673, 3), (730, 4), (731, 30), (737, 135), (739, 57), (813, 76), (815, 16), (842, 35), (843, 528), (844, 26), (856, 73), (863, 65), (868, 191), (870, 220), (871, 35), (872, 59), (882, 39), (886, 77), (894, 67), (905, 29), (906, 293), (916, 22), (922, 6), (925, 142), (928, 122), (930, 237), (938, 212), (940, 426), (952, 213), (968, 61), (978, 291), (985, 126), (1005, 159), (1006, 16), (1030, 96), (1045, 80), (1060, 74), (1070, 216), (1075, 9), (1090, 9), (1099, 128), (1111, 267), (1113, 148), (1114, 43), (1127, 75), (1132, 223), (1137, 266), (1149, 380), (1150, 185), (1151, 111), (1169, 338), (1177, 195), (1182, 361), (1219, 236), (1234, 196), (1267, 311), (1335, 35), (1342, 225), (1359, 135), (1372, 104), (1491, 194), (1528, 58)]
def cs254 : List ℕ := [264, 371, 0, 236, 365, 380, 227, 1000, 165, 437, 365, 829, 902, 466, 227, 233, 1000, 1000, 1000, 0, 1000, 762, 162, 1000, 1000, 998, 999, 1000, 311, 524, 1000, 999, 848, 364, 1000, 1000, 1000, 0, 942, 1000, 1001, 1000, 386, 1000, 1000, 999, 1000, 1994, 617, 1000, 1000, 999, 464, 1000, 0, 1956, 1000, 999, 999, 1001, 999, 936, 432, 999, 828, 1000, 999, 1000, 1000, 999, 1000, 1000, 994, 999, 547, 999, 299, 999, 1000, 999, 999, 997, 250, 1001, 617, 1000, 634, 999, 1000, 1000, 999, 650, 897, 1000, 775, 1000, 999, 1000, 1000, 999, 1858, 1000, 1000, 1000, 654, 999, 1000, 999, 1000, 61, 1000, 999, 1000, 999, 1000, 1560, 1000, 361, 999, 514, 999, 1000, 1234, 999, 1000, 1000, 253, 0, 660, 999, 975, 895, 787, 1000, 791, 662, 633, 693, 1000, 1000, 999, 782, 1000, 0, 1000, 195, 999, 880, 999, 458, 507, 195, 396, 0]
theorem loads254 : cs254.get =
    load (fun i : Fin entries254.length => support (entries254.get i).1)
      (fun i => (entries254.get i).2) := by
  apply load_eq_of_sparse_packed base cs254 support code
    entries254 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node254 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 143 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs254 support demand
    entries254 ((insert 143 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 1000 30 loads254
  decide +kernel
theorem node247 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 47 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154))
    143 node253 node254
def entries251 : List (Fin 1589 × ℕ) := [(20, 1), (35, 35), (43, 27), (72, 8), (77, 1), (179, 37), (341, 4), (421, 2), (466, 12), (472, 15), (479, 9), (507, 8), (542, 17), (552, 1), (572, 11), (583, 41), (585, 13), (617, 22), (622, 23), (624, 10), (673, 9), (675, 4), (730, 3), (731, 31), (737, 11), (797, 3), (798, 7), (800, 9), (812, 6), (817, 1), (842, 12), (843, 33), (844, 3), (850, 17), (864, 31), (870, 12), (872, 23), (882, 1), (886, 11), (894, 18), (903, 9), (905, 13), (906, 24), (922, 17), (923, 1), (925, 26), (938, 12), (940, 26), (950, 6), (952, 33), (968, 21), (973, 43), (978, 20), (985, 15), (995, 4), (1005, 18), (1061, 3), (1068, 6), (1070, 14), (1082, 12), (1090, 10), (1108, 10), (1114, 27), (1126, 2), (1128, 16), (1133, 8), (1139, 4), (1152, 3), (1153, 6), (1169, 27), (1177, 29), (1181, 15), (1182, 28), (1186, 7), (1219, 14), (1236, 13), (1275, 6), (1304, 6), (1310, 17), (1317, 2), (1323, 3), (1359, 35), (1491, 4), (1575, 2)]
def cs251 : List ℕ := [28, 49, 15, 38, 22, 48, 33, 101, 36, 39, 9, 92, 100, 59, 53, 6, 100, 100, 99, 11, 100, 99, 37, 100, 93, 100, 100, 98, 61, 100, 100, 99, 39, 30, 100, 100, 99, 23, 46, 99, 100, 101, 23, 100, 99, 218, 198, 0, 90, 100, 100, 100, 71, 100, 0, 203, 100, 99, 98, 72, 99, 99, 44, 99, 100, 99, 99, 100, 100, 99, 100, 100, 67, 98, 62, 99, 60, 100, 100, 99, 99, 101, 98, 100, 90, 99, 97, 99, 99, 99, 100, 103, 100, 99, 69, 62, 100, 99, 100, 99, 203, 100, 98, 69, 74, 99, 100, 99, 100, 43, 100, 101, 82, 99, 92, 139, 100, 35, 100, 83, 99, 87, 132, 100, 100, 70, 72, 58, 76, 100, 99, 99, 102, 101, 100, 101, 72, 91, 101, 101, 100, 72, 98, 101, 101, 87, 83, 99, 100, 96, 98, 101, 101, 56]
theorem loads251 : cs251.get =
    load (fun i : Fin entries251.length => support (entries251.get i).1)
      (fun i => (entries251.get i).2) := by
  apply load_eq_of_sparse_packed base cs251 support code
    entries251 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node251 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 45 (insert 46 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs251 support demand
    entries251 ((insert 47 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 45 (insert 46 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)) 100 30 loads251
  decide +kernel
def entries252 : List (Fin 1589 × ℕ) := [(75, 1), (77, 2), (122, 13), (341, 19), (343, 8), (421, 14), (472, 41), (482, 3), (483, 1), (496, 26), (507, 28), (531, 15), (542, 41), (583, 18), (585, 21), (617, 28), (673, 16), (689, 4), (731, 27), (737, 8), (797, 4), (798, 15), (843, 27), (844, 26), (849, 13), (853, 6), (869, 1), (870, 25), (872, 11), (882, 12), (886, 23), (894, 8), (906, 23), (922, 10), (929, 10), (937, 27), (938, 3), (939, 8), (940, 36), (949, 1), (950, 2), (952, 39), (973, 35), (978, 21), (985, 20), (1005, 11), (1030, 23), (1045, 11), (1061, 2), (1070, 1), (1082, 6), (1099, 12), (1108, 13), (1111, 10), (1114, 13), (1128, 17), (1131, 1), (1132, 3), (1133, 19), (1153, 4), (1169, 21), (1171, 1), (1173, 14), (1177, 18), (1181, 7), (1182, 31), (1183, 1), (1219, 14), (1232, 12), (1310, 25), (1317, 9), (1323, 7), (1359, 11), (1372, 2), (1491, 4), (1561, 14), (1580, 7), (1588, 7)]
def cs252 : List ℕ := [26, 25, 41, 27, 7, 10, 0, 99, 26, 28, 3, 51, 100, 35, 51, 29, 93, 100, 99, 0, 99, 61, 0, 99, 100, 100, 100, 99, 40, 1, 100, 100, 32, 48, 99, 100, 99, 0, 16, 99, 100, 96, 38, 100, 99, 18, 173, 10, 65, 100, 100, 74, 81, 100, 15, 149, 99, 99, 98, 62, 100, 99, 83, 100, 100, 94, 100, 100, 100, 100, 99, 99, 75, 100, 47, 100, 20, 101, 101, 100, 100, 99, 100, 99, 52, 100, 71, 100, 100, 101, 100, 89, 100, 100, 99, 75, 101, 88, 100, 100, 190, 100, 100, 67, 78, 101, 100, 89, 100, 21, 101, 99, 93, 98, 85, 173, 100, 32, 100, 118, 75, 100, 144, 100, 100, 71, 53, 42, 57, 100, 100, 97, 100, 99, 100, 100, 68, 74, 99, 99, 100, 70, 100, 101, 100, 60, 100, 79, 100, 88, 95, 100, 100, 48]
theorem loads252 : cs252.get =
    load (fun i : Fin entries252.length => support (entries252.get i).1)
      (fun i => (entries252.get i).2) := by
  apply load_eq_of_sparse_packed base cs252 support code
    entries252 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node252 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 45 (insert 47 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs252 support demand
    entries252 ((insert 45 (insert 47 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 46 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 100 30 loads252
  decide +kernel
theorem node249 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 46 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 46 (insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154))
    45 node251 node252
def entries250 : List (Fin 1589 × ℕ) := [(20, 32), (37, 14), (77, 19), (122, 16), (205, 15), (314, 20), (341, 10), (343, 4), (387, 13), (420, 4), (421, 38), (570, 11), (571, 1), (572, 12), (584, 1), (616, 20), (617, 21), (730, 19), (731, 46), (737, 14), (798, 13), (813, 5), (818, 8), (843, 40), (869, 1), (870, 11), (872, 22), (882, 28), (905, 7), (922, 10), (925, 32), (934, 11), (937, 25), (940, 30), (952, 36), (973, 28), (978, 20), (985, 31), (1005, 19), (1006, 4), (1030, 3), (1061, 7), (1075, 5), (1082, 14), (1090, 5), (1099, 10), (1104, 3), (1111, 2), (1114, 6), (1128, 21), (1133, 34), (1138, 1), (1139, 4), (1153, 26), (1167, 14), (1169, 29), (1171, 3), (1173, 4), (1177, 22), (1182, 17), (1219, 21), (1222, 5), (1225, 1), (1236, 28), (1280, 33), (1317, 11), (1323, 5), (1335, 12), (1443, 7), (1491, 4), (1503, 1), (1537, 12), (1561, 2)]
def cs250 : List ℕ := [61, 59, 17, 53, 28, 92, 0, 99, 58, 0, 19, 99, 99, 66, 19, 48, 99, 99, 99, 27, 87, 17, 0, 99, 99, 101, 99, 99, 35, 32, 99, 99, 36, 46, 100, 99, 78, 0, 33, 99, 99, 99, 33, 101, 100, 100, 0, 0, 83, 101, 99, 75, 14, 99, 23, 177, 99, 34, 100, 55, 100, 99, 71, 61, 98, 99, 101, 99, 86, 99, 100, 68, 90, 101, 54, 101, 24, 99, 99, 99, 100, 99, 76, 100, 67, 101, 79, 101, 101, 99, 101, 105, 101, 100, 98, 99, 100, 100, 99, 101, 217, 99, 101, 78, 50, 100, 100, 100, 100, 2, 100, 100, 101, 94, 95, 174, 101, 17, 101, 102, 95, 100, 154, 99, 100, 82, 50, 28, 61, 100, 99, 96, 100, 100, 100, 100, 57, 76, 100, 99, 101, 45, 100, 100, 100, 50, 85, 78, 91, 79, 72, 100, 96, 28]
theorem loads250 : cs250.get =
    load (fun i : Fin entries250.length => support (entries250.get i).1)
      (fun i => (entries250.get i).2) := by
  apply load_eq_of_sparse_packed base cs250 support code
    entries250 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node250 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 46 (insert 47 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs250 support demand
    entries250 ((insert 46 (insert 47 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)) 100 30 loads250
  decide +kernel
theorem node248 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 47 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 47 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    46 node249 node250
theorem node239 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 91 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    47 node247 node248
def entries245 : List (Fin 1589 × ℕ) := [(20, 223), (46, 267), (179, 257), (205, 90), (341, 37), (343, 34), (387, 234), (421, 96), (469, 28), (472, 106), (496, 243), (507, 263), (542, 129), (550, 109), (583, 11), (616, 132), (617, 323), (624, 23), (674, 26), (736, 80), (737, 119), (797, 70), (798, 370), (799, 26), (813, 79), (817, 17), (819, 47), (833, 69), (843, 213), (844, 85), (847, 154), (849, 86), (853, 31), (868, 110), (870, 69), (882, 126), (886, 339), (906, 206), (922, 146), (925, 225), (927, 153), (930, 149), (937, 107), (940, 551), (952, 329), (968, 75), (970, 145), (973, 64), (1006, 49), (1007, 52), (1018, 71), (1028, 124), (1030, 347), (1075, 167), (1082, 186), (1099, 82), (1104, 86), (1108, 172), (1128, 238), (1137, 108), (1139, 207), (1149, 392), (1152, 47), (1153, 244), (1169, 235), (1171, 47), (1173, 75), (1177, 247), (1182, 158), (1219, 222), (1234, 73), (1236, 140), (1251, 252), (1258, 10), (1267, 116), (1312, 292), (1317, 55), (1335, 184), (1358, 146), (1453, 23), (1469, 13), (1491, 10), (1553, 36), (1576, 114), (1580, 120), (1582, 48)]
def cs245 : List ℕ := [371, 250, 260, 579, 260, 219, 315, 1001, 466, 263, 158, 605, 1001, 343, 516, 293, 1001, 1000, 952, 36, 1000, 453, 257, 1000, 1000, 1001, 1000, 1000, 302, 747, 1001, 1001, 607, 367, 1000, 1000, 1000, 48, 983, 1000, 1001, 1001, 119, 562, 1001, 1000, 1000, 1000, 749, 1000, 1000, 1000, 887, 1001, 122, 1882, 999, 986, 1000, 854, 1000, 1000, 885, 1000, 1000, 1001, 1000, 1001, 1000, 1001, 1000, 999, 1000, 1000, 552, 1000, 247, 1000, 1000, 1001, 1000, 1001, 1000, 998, 749, 1000, 905, 999, 1000, 916, 1000, 64, 1000, 2622, 576, 961, 999, 1000, 1001, 999, 2292, 1001, 910, 1001, 692, 1499, 1002, 1000, 999, 75, 795, 1000, 1001, 1000, 1001, 1976, 1000, 303, 999, 996, 1000, 1000, 1372, 1000, 1001, 970, 311, 188, 777, 999, 1000, 1001, 1000, 1001, 999, 1000, 825, 574, 1001, 1000, 1000, 660, 1001, 830, 1001, 311, 1358, 579, 1001, 1000, 920, 665, 967, 64]
theorem loads245 : cs245.get =
    load (fun i : Fin entries245.length => support (entries245.get i).1)
      (fun i => (entries245.get i).2) := by
  apply load_eq_of_sparse_packed base cs245 support code
    entries245 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node245 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 146 (insert 105 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs245 support demand
    entries245 ((insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 93 (insert 146 (insert 105 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)) 1000 30 loads245
  decide +kernel
def entries246 : List (Fin 1589 × ℕ) := [(20, 50), (122, 26), (343, 10), (344, 4), (386, 4), (421, 16), (469, 10), (472, 24), (474, 1), (496, 40), (507, 9), (515, 1), (542, 8), (551, 7), (571, 6), (583, 35), (616, 18), (617, 13), (640, 8), (680, 3), (681, 1), (731, 35), (737, 4), (813, 29), (819, 3), (843, 29), (854, 4), (855, 7), (868, 26), (870, 30), (871, 5), (872, 4), (882, 4), (886, 14), (906, 14), (920, 2), (925, 19), (930, 14), (934, 5), (938, 38), (939, 7), (952, 42), (1007, 9), (1018, 15), (1028, 13), (1030, 14), (1070, 6), (1082, 18), (1086, 7), (1099, 15), (1104, 8), (1126, 7), (1128, 4), (1139, 4), (1149, 49), (1153, 16), (1169, 41), (1173, 9), (1177, 25), (1182, 16), (1186, 1), (1188, 7), (1212, 12), (1217, 8), (1219, 20), (1228, 1), (1236, 7), (1246, 30), (1251, 16), (1275, 22), (1280, 1), (1335, 14), (1358, 13), (1372, 2), (1491, 14), (1525, 14), (1580, 5)]
def cs246 : List ℕ := [29, 31, 46, 71, 12, 27, 0, 102, 90, 23, 41, 90, 101, 66, 13, 51, 102, 100, 86, 6, 103, 61, 0, 102, 101, 100, 102, 100, 26, 50, 101, 101, 56, 41, 99, 101, 101, 7, 48, 100, 101, 100, 22, 62, 100, 101, 101, 101, 98, 100, 101, 101, 62, 100, 18, 206, 100, 100, 101, 77, 101, 101, 63, 101, 72, 100, 99, 99, 100, 101, 99, 101, 100, 98, 63, 100, 34, 57, 99, 101, 100, 100, 72, 91, 76, 99, 100, 100, 100, 100, 99, 0, 100, 0, 62, 100, 99, 100, 99, 88, 141, 100, 100, 100, 53, 104, 99, 99, 101, 13, 41, 99, 100, 95, 99, 117, 100, 29, 99, 63, 100, 98, 128, 100, 100, 99, 25, 13, 89, 99, 100, 80, 76, 100, 92, 99, 83, 41, 100, 100, 100, 79, 100, 69, 100, 25, 135, 62, 92, 89, 85, 76, 75, 36]
theorem loads246 : cs246.get =
    load (fun i : Fin entries246.length => support (entries246.get i).1)
      (fun i => (entries246.get i).2) := by
  apply load_eq_of_sparse_packed base cs246 support code
    entries246 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node246 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 146 (insert 105 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs246 support demand
    entries246 ((insert 93 (insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 146 (insert 105 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 100 30 loads246
  decide +kernel
theorem node243 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 146 (insert 105 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 146 (insert 105 (insert 55 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154))
    93 node245 node246
def entries244 : List (Fin 1589 × ℕ) := [(20, 43), (46, 12), (77, 16), (179, 21), (205, 21), (399, 20), (415, 16), (421, 1), (469, 13), (472, 20), (474, 5), (495, 15), (496, 8), (507, 2), (526, 6), (542, 9), (571, 3), (583, 20), (616, 1), (617, 24), (622, 3), (624, 5), (731, 16), (737, 6), (797, 12), (798, 4), (819, 22), (843, 30), (853, 2), (868, 24), (870, 20), (871, 10), (882, 21), (886, 18), (894, 5), (895, 1), (906, 31), (925, 9), (930, 21), (934, 8), (936, 7), (937, 19), (940, 26), (950, 16), (952, 28), (968, 7), (985, 6), (1006, 17), (1007, 4), (1018, 31), (1028, 2), (1053, 5), (1056, 13), (1070, 5), (1078, 12), (1099, 15), (1104, 17), (1108, 1), (1114, 47), (1132, 22), (1133, 5), (1137, 11), (1139, 35), (1148, 31), (1160, 3), (1165, 1), (1169, 33), (1177, 25), (1181, 5), (1219, 24), (1234, 7), (1236, 3), (1267, 4), (1275, 24), (1280, 6), (1323, 4), (1342, 25), (1358, 31), (1372, 21), (1403, 19), (1469, 3), (1478, 8), (1500, 1), (1576, 2), (1580, 5), (1584, 2)]
def cs244 : List ℕ := [40, 43, 20, 72, 8, 11, 12, 102, 66, 2, 40, 102, 100, 79, 42, 21, 102, 100, 88, 3, 102, 42, 21, 101, 101, 100, 99, 101, 33, 76, 102, 100, 11, 33, 100, 99, 101, 0, 98, 101, 100, 100, 0, 94, 100, 99, 101, 99, 75, 101, 100, 100, 76, 101, 8, 206, 100, 100, 99, 64, 100, 99, 94, 100, 100, 100, 100, 100, 100, 99, 101, 99, 100, 99, 87, 99, 47, 100, 100, 101, 99, 100, 100, 100, 83, 100, 74, 100, 100, 100, 101, 7, 101, 101, 82, 100, 100, 100, 100, 100, 206, 101, 100, 100, 54, 151, 100, 100, 99, 12, 63, 100, 100, 68, 99, 138, 101, 0, 81, 73, 100, 99, 139, 100, 101, 92, 26, 7, 99, 100, 100, 100, 92, 100, 92, 100, 25, 80, 100, 100, 100, 25, 100, 35, 100, 30, 0, 78, 64, 51, 65, 58, 5, 27]
theorem loads244 : cs244.get =
    load (fun i : Fin entries244.length => support (entries244.get i).1)
      (fun i => (entries244.get i).2) := by
  apply load_eq_of_sparse_packed base cs244 support code
    entries244 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node244 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 146 (insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 105 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs244 support demand
    entries244 ((insert 146 (insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 105 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)) 100 30 loads244
  decide +kernel
theorem node241 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 105 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 105 (insert 55 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    146 node243 node244
def entries242 : List (Fin 1589 × ℕ) := [(20, 286), (46, 139), (70, 235), (122, 116), (179, 237), (205, 77), (341, 110), (386, 101), (387, 150), (398, 133), (421, 212), (466, 239), (472, 62), (474, 81), (478, 123), (496, 139), (507, 227), (542, 208), (571, 181), (583, 19), (616, 65), (617, 178), (681, 97), (730, 118), (731, 257), (737, 70), (798, 236), (813, 258), (843, 380), (847, 140), (850, 184), (868, 44), (870, 279), (872, 151), (882, 258), (886, 250), (894, 20), (906, 235), (922, 111), (928, 207), (929, 7), (930, 21), (935, 140), (938, 225), (940, 114), (949, 1), (952, 350), (970, 33), (978, 55), (1006, 177), (1007, 275), (1028, 72), (1029, 12), (1045, 203), (1082, 223), (1099, 169), (1108, 67), (1114, 110), (1128, 42), (1132, 300), (1137, 273), (1139, 144), (1148, 25), (1149, 115), (1153, 6), (1169, 225), (1171, 106), (1173, 79), (1212, 49), (1227, 133), (1228, 89), (1232, 284), (1236, 5), (1258, 223), (1262, 60), (1266, 21), (1267, 195), (1275, 111), (1297, 55), (1358, 227), (1489, 78), (1491, 96), (1500, 45), (1525, 160), (1561, 27), (1582, 58)]
def cs242 : List ℕ := [471, 0, 362, 609, 128, 63, 197, 956, 485, 387, 497, 831, 993, 437, 582, 528, 1001, 1001, 1001, 181, 1001, 857, 237, 1001, 1001, 1000, 1001, 1000, 311, 897, 1000, 1001, 483, 331, 1001, 1001, 1001, 242, 780, 1000, 1002, 1000, 168, 850, 1001, 1000, 1001, 1000, 773, 1001, 1000, 1000, 945, 1001, 185, 1835, 1000, 1001, 1001, 607, 1000, 1001, 876, 1000, 1000, 1002, 1000, 1000, 1000, 1001, 1000, 1001, 991, 1001, 814, 1001, 45, 516, 998, 1000, 1001, 1000, 999, 1000, 832, 1001, 706, 999, 1000, 1000, 999, 55, 1000, 999, 591, 493, 999, 976, 999, 999, 1713, 1001, 998, 999, 363, 225, 1000, 999, 1001, 76, 1000, 1000, 999, 953, 1000, 1239, 999, 82, 1000, 584, 1000, 999, 1375, 1000, 999, 1000, 0, 72, 447, 998, 1000, 523, 1000, 1000, 1000, 998, 300, 726, 1000, 1000, 1000, 469, 1000, 525, 985, 0, 1000, 728, 1000, 556, 777, 444, 305, 588]
theorem loads242 : cs242.get =
    load (fun i : Fin entries242.length => support (entries242.get i).1)
      (fun i => (entries242.get i).2) := by
  apply load_eq_of_sparse_packed base cs242 support code
    entries242 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node242 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 105 (insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs242 support demand
    entries242 ((insert 105 (insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 55 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)) 1000 30 loads242
  decide +kernel
theorem node240 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 91 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 55 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154))
    105 node241 node242
theorem node223 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 55 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 55 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154))
    91 node239 node240
def entries237 : List (Fin 1589 × ℕ) := [(7, 90), (37, 785), (46, 62), (72, 2), (122, 2), (273, 33), (341, 221), (343, 13), (387, 68), (420, 105), (421, 79), (466, 255), (472, 75), (483, 179), (507, 310), (531, 68), (542, 75), (550, 23), (572, 77), (617, 212), (624, 4), (737, 152), (763, 274), (798, 60), (813, 169), (818, 37), (843, 176), (844, 50), (870, 242), (882, 179), (886, 25), (896, 206), (906, 254), (922, 246), (924, 149), (925, 30), (930, 288), (951, 518), (952, 240), (968, 105), (973, 149), (978, 363), (985, 137), (1006, 157), (1009, 48), (1020, 122), (1039, 15), (1045, 144), (1046, 216), (1048, 217), (1056, 81), (1061, 97), (1075, 187), (1090, 238), (1126, 15), (1128, 324), (1133, 157), (1139, 105), (1152, 18), (1153, 115), (1173, 218), (1183, 310), (1219, 194), (1227, 19), (1232, 324), (1234, 50), (1238, 55), (1267, 280), (1275, 113), (1298, 43), (1312, 181), (1323, 36), (1339, 103), (1342, 144), (1358, 178), (1434, 53), (1491, 65), (1498, 35), (1525, 3), (1561, 134), (1576, 48), (1580, 190)]
def cs237 : List ℕ := [538, 284, 133, 194, 280, 999, 62, 1000, 893, 313, 5, 924, 999, 401, 329, 304, 999, 1001, 818, 862, 1000, 659, 0, 1000, 999, 999, 999, 1001, 336, 62, 999, 1001, 648, 50, 1002, 778, 999, 0, 1469, 1001, 999, 344, 234, 885, 1002, 999, 1000, 1000, 425, 999, 421, 2378, 900, 1001, 218, 0, 1001, 1000, 1000, 869, 1000, 999, 1000, 1000, 1000, 507, 2484, 1001, 915, 1000, 1001, 1000, 921, 1000, 601, 1000, 0, 1001, 1000, 1000, 1000, 1001, 1000, 1001, 423, 1000, 381, 1000, 1001, 1000, 1001, 746, 1001, 2618, 650, 360, 1001, 978, 999, 999, 2351, 1001, 1000, 921, 647, 1000, 1000, 1000, 1001, 239, 1000, 1000, 999, 1000, 1000, 2024, 1001, 310, 1000, 1099, 1000, 1000, 1619, 1000, 1000, 572, 149, 149, 584, 1001, 1000, 365, 1001, 1001, 1002, 1001, 584, 480, 1001, 1001, 1001, 367, 1001, 1001, 1001, 149, 1001, 402, 783, 727, 1001, 797, 398, 896]
theorem loads237 : cs237.get =
    load (fun i : Fin entries237.length => support (entries237.get i).1)
      (fun i => (entries237.get i).2) := by
  apply load_eq_of_sparse_packed base cs237 support code
    entries237 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node237 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 38 (insert 66 (insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs237 support demand
    entries237 ((insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 38 (insert 66 (insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅))))))) : Finset (Fin 154)) 1000 30 loads237
  decide +kernel
def entries238 : List (Fin 1589 × ℕ) := [(30, 31), (46, 261), (273, 232), (315, 2), (341, 109), (343, 11), (387, 111), (420, 64), (421, 78), (466, 265), (472, 160), (479, 101), (498, 116), (507, 337), (529, 150), (542, 258), (551, 272), (570, 226), (572, 194), (617, 46), (730, 79), (731, 6), (737, 253), (739, 20), (763, 93), (777, 120), (798, 114), (813, 42), (843, 229), (844, 291), (856, 65), (863, 130), (864, 19), (870, 30), (882, 191), (883, 85), (885, 237), (896, 146), (906, 181), (922, 375), (924, 278), (925, 142), (930, 308), (940, 130), (946, 95), (951, 128), (952, 210), (968, 132), (970, 71), (973, 198), (978, 326), (985, 115), (1005, 11), (1006, 140), (1020, 101), (1045, 264), (1046, 26), (1056, 238), (1061, 59), (1075, 72), (1090, 136), (1104, 61), (1111, 4), (1114, 172), (1128, 63), (1133, 106), (1139, 113), (1160, 88), (1170, 72), (1171, 56), (1173, 356), (1177, 86), (1183, 65), (1219, 92), (1232, 325), (1263, 122), (1267, 176), (1275, 200), (1292, 48), (1339, 83), (1403, 99), (1561, 153), (1576, 152), (1580, 45)]
def cs238 : List ℕ := [556, 92, 160, 92, 146, 144, 261, 954, 269, 486, 48, 387, 999, 226, 564, 463, 887, 1000, 999, 194, 999, 736, 0, 999, 998, 1000, 999, 999, 328, 261, 1000, 1000, 989, 419, 1000, 1000, 999, 0, 308, 1000, 1000, 795, 403, 1000, 1000, 1000, 1000, 999, 332, 747, 1001, 1349, 1000, 1000, 484, 216, 1000, 999, 999, 1001, 1001, 1000, 1001, 1000, 1001, 1001, 1485, 999, 1001, 1000, 1000, 999, 804, 1001, 624, 1000, 200, 999, 999, 1001, 1000, 1000, 1001, 1001, 237, 1000, 539, 1000, 1000, 1001, 1000, 709, 1002, 2128, 790, 674, 999, 1000, 999, 1000, 2366, 999, 1002, 953, 544, 865, 999, 999, 1002, 285, 1000, 999, 999, 960, 999, 1481, 1001, 136, 1000, 802, 1000, 976, 1479, 1000, 1001, 822, 284, 198, 582, 1000, 1000, 382, 1000, 999, 1002, 1000, 696, 606, 1000, 1000, 1002, 610, 999, 761, 1000, 284, 1000, 410, 735, 845, 901, 915, 351, 876]
theorem loads238 : cs238.get =
    load (fun i : Fin entries238.length => support (entries238.get i).1)
      (fun i => (entries238.get i).2) := by
  apply load_eq_of_sparse_packed base cs238 support code
    entries238 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node238 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 38 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs238 support demand
    entries238 ((insert 38 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 66 (insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 1000 30 loads238
  decide +kernel
theorem node233 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 66 (insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 66 (insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154))
    38 node237 node238
def entries235 : List (Fin 1589 × ℕ) := [(7, 46), (179, 444), (229, 21), (271, 17), (273, 33), (315, 218), (337, 297), (387, 436), (415, 60), (421, 223), (439, 136), (485, 44), (498, 63), (507, 282), (513, 106), (515, 68), (531, 32), (617, 247), (673, 140), (674, 44), (763, 16), (777, 57), (799, 93), (813, 139), (818, 29), (843, 92), (844, 79), (846, 171), (864, 68), (868, 52), (870, 193), (882, 31), (886, 209), (896, 118), (905, 85), (906, 89), (922, 257), (924, 9), (925, 353), (946, 46), (968, 216), (973, 176), (978, 421), (985, 231), (1006, 269), (1009, 137), (1012, 76), (1020, 8), (1045, 134), (1056, 58), (1070, 240), (1082, 98), (1090, 181), (1111, 107), (1114, 184), (1133, 8), (1153, 210), (1173, 66), (1182, 38), (1183, 335), (1186, 38), (1217, 115), (1219, 90), (1221, 240), (1227, 14), (1232, 287), (1234, 431), (1235, 33), (1261, 98), (1263, 317), (1268, 66), (1275, 164), (1293, 44), (1339, 32), (1393, 91), (1403, 148), (1496, 74), (1498, 53), (1576, 79), (1580, 176), (1584, 18)]
def cs235 : List ℕ := [434, 307, 355, 90, 222, 452, 0, 871, 380, 350, 300, 638, 1001, 320, 176, 175, 999, 1000, 1000, 66, 1000, 586, 444, 1001, 600, 1000, 1000, 1000, 191, 444, 1000, 999, 971, 79, 1001, 901, 999, 0, 889, 1000, 1000, 1001, 159, 1000, 1000, 1000, 1000, 999, 1000, 1000, 1000, 1473, 565, 1000, 306, 0, 1000, 1001, 994, 1000, 999, 1000, 801, 999, 1000, 779, 66, 1001, 1000, 999, 1001, 1000, 956, 1000, 472, 1000, 114, 1000, 1000, 1000, 1000, 999, 999, 1000, 971, 846, 727, 999, 1001, 999, 1000, 904, 915, 2641, 355, 134, 1001, 999, 1744, 999, 1905, 999, 1000, 999, 693, 762, 1000, 1000, 1000, 254, 1000, 999, 1000, 569, 1001, 1302, 1000, 411, 1000, 471, 1000, 1000, 833, 1000, 1000, 648, 176, 252, 811, 1000, 1000, 176, 1000, 1000, 1000, 1000, 242, 310, 1000, 999, 1001, 482, 902, 606, 1000, 176, 1000, 520, 836, 464, 1000, 673, 462, 1000]
theorem loads235 : cs235.get =
    load (fun i : Fin entries235.length => support (entries235.get i).1)
      (fun i => (entries235.get i).2) := by
  apply load_eq_of_sparse_packed base cs235 support code
    entries235 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node235 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 66 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 98 (insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs235 support demand
    entries235 ((insert 66 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 98 (insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅)))))) : Finset (Fin 154)) 1000 30 loads235
  decide +kernel
def entries236 : List (Fin 1589 × ℕ) := [(7, 3), (46, 8), (75, 23), (177, 4), (273, 32), (315, 9), (337, 18), (472, 4), (479, 15), (483, 22), (498, 12), (506, 7), (507, 3), (617, 28), (673, 12), (680, 12), (737, 5), (740, 8), (741, 1), (763, 19), (777, 5), (798, 9), (799, 40), (813, 20), (843, 47), (844, 12), (864, 19), (868, 4), (870, 18), (882, 27), (886, 10), (896, 25), (904, 18), (906, 1), (922, 27), (925, 38), (952, 16), (968, 15), (978, 37), (985, 34), (1006, 9), (1009, 17), (1021, 11), (1045, 37), (1056, 25), (1070, 19), (1075, 2), (1076, 1), (1078, 2), (1082, 23), (1090, 19), (1114, 18), (1128, 20), (1133, 11), (1137, 3), (1138, 7), (1139, 10), (1159, 8), (1173, 7), (1219, 21), (1221, 2), (1227, 4), (1232, 50), (1234, 42), (1263, 3), (1268, 9), (1275, 25), (1280, 14), (1285, 1), (1342, 3), (1358, 8), (1370, 11), (1403, 17), (1496, 14), (1498, 4), (1499, 10), (1580, 23)]
def cs236 : List ℕ := [36, 38, 6, 22, 41, 42, 8, 99, 16, 29, 41, 64, 99, 36, 54, 31, 99, 99, 97, 9, 98, 66, 4, 99, 74, 99, 98, 99, 10, 35, 99, 99, 98, 12, 98, 99, 99, 0, 65, 100, 99, 98, 0, 100, 100, 93, 100, 99, 49, 99, 100, 192, 54, 101, 19, 0, 98, 100, 99, 100, 98, 99, 63, 101, 96, 100, 23, 100, 99, 100, 99, 99, 79, 100, 52, 100, 19, 100, 100, 101, 100, 100, 100, 99, 57, 100, 84, 100, 99, 100, 100, 71, 100, 235, 58, 37, 97, 100, 0, 100, 276, 101, 69, 100, 66, 80, 101, 101, 100, 15, 100, 101, 100, 45, 85, 184, 100, 0, 100, 61, 101, 66, 131, 100, 100, 47, 0, 0, 42, 100, 100, 3, 100, 100, 101, 101, 7, 42, 101, 101, 101, 26, 81, 53, 101, 0, 80, 22, 57, 45, 85, 86, 8, 75]
theorem loads236 : cs236.get =
    load (fun i : Fin entries236.length => support (entries236.get i).1)
      (fun i => (entries236.get i).2) := by
  apply load_eq_of_sparse_packed base cs236 support code
    entries236 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node236 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 98 (insert 66 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs236 support demand
    entries236 ((insert 98 (insert 66 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)) 100 30 loads236
  decide +kernel
theorem node234 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 66 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 66 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    98 node235 node236
theorem node231 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 51 (insert 93 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154))
    66 node233 node234
def entries232 : List (Fin 1589 × ℕ) := [(46, 183292), (179, 437555), (205, 31220), (337, 216895), (387, 185749), (472, 128375), (479, 297938), (483, 33290), (507, 422674), (515, 89149), (527, 184599), (531, 149811), (542, 280953), (551, 214580), (570, 17252), (583, 85598), (617, 231118), (625, 162456), (730, 246996), (731, 149299), (737, 238966), (742, 12082), (763, 150616), (776, 29798), (798, 62237), (812, 45567), (813, 37296), (843, 447404), (844, 152578), (849, 74796), (856, 77418), (870, 154447), (882, 151233), (886, 271866), (896, 24535), (905, 59700), (906, 53950), (922, 321640), (925, 428817), (927, 268516), (928, 31558), (930, 148776), (934, 106727), (952, 94292), (968, 296238), (973, 264025), (978, 99420), (984, 194775), (985, 115729), (994, 56648), (1006, 81014), (1009, 842), (1039, 47088), (1045, 227888), (1056, 227888), (1090, 156402), (1099, 77143), (1108, 132877), (1114, 144185), (1128, 85290), (1132, 48254), (1133, 175610), (1138, 74253), (1139, 56301), (1148, 48254), (1153, 75699), (1171, 80509), (1173, 242721), (1183, 227921), (1219, 335467), (1222, 50914), (1232, 184825), (1261, 69763), (1267, 113792), (1275, 192675), (1292, 56210), (1323, 26700), (1358, 34728), (1403, 187759), (1528, 5315), (1556, 11696)]
def cs232 : List ℕ := [187306, 386381, 179289, 410263, 297938, 217832, 183292, 1000000, 0, 422674, 145359, 575556, 1000000, 149811, 464245, 365813, 999999, 1000000, 1000000, 0, 999999, 407217, 437555, 1000000, 999999, 999999, 999999, 1000001, 276248, 620847, 1000000, 999999, 851491, 289735, 1000001, 915446, 999999, 0, 886405, 1000000, 930008, 366706, 303729, 1000000, 1000001, 1000000, 1000000, 999999, 833850, 999998, 1000000, 94292, 1000000, 1000001, 480871, 0, 1000001, 1000000, 1000000, 999999, 999999, 1000000, 740808, 993616, 1000000, 923775, 1000000, 1000001, 1000000, 999999, 707323, 1000000, 796175, 1000001, 501777, 1000000, 0, 1000000, 1000001, 1000000, 1000001, 999998, 1000000, 1000001, 833850, 874221, 378042, 1000000, 1000001, 999999, 1000000, 673949, 765662, 1968606, 517167, 250455, 1000001, 999999, 1000001, 1000000, 2135784, 1000000, 1000000, 1000000, 559663, 948315, 999999, 980488, 1000001, 296238, 999999, 1000001, 1000000, 904133, 1000000, 1425901, 1000000, 227921, 1000000, 699414, 1000000, 1000000, 1194428, 1000000, 1000000, 774013, 269340, 264025, 395771, 1000000, 1000000, 312279, 999999, 1000001, 1000001, 1000001, 592570, 540167, 1000000, 1000001, 1000001, 669713, 1000001, 777266, 1000000, 264025, 1000001, 601558, 799278, 843430, 925747, 843835, 339724, 869446]
theorem loads232 : cs232.get =
    load (fun i : Fin entries232.length => support (entries232.get i).1)
      (fun i => (entries232.get i).2) := by
  apply load_eq_of_sparse_packed base cs232 support code
    entries232 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node232 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 51 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs232 support demand
    entries232 ((insert 51 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 93 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)) 1000000 30 loads232
  decide +kernel
theorem node225 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 93 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154))
    51 node231 node232
def entries229 : List (Fin 1589 × ℕ) := [(30, 2), (177, 42), (179, 1), (273, 8), (344, 5), (352, 13), (386, 40), (421, 8), (472, 28), (479, 19), (496, 4), (507, 18), (515, 24), (526, 3), (531, 31), (542, 21), (551, 13), (552, 6), (583, 8), (617, 16), (730, 6), (731, 15), (737, 1), (739, 12), (741, 31), (776, 17), (777, 9), (813, 30), (817, 1), (843, 45), (844, 19), (853, 1), (856, 11), (863, 10), (870, 43), (882, 5), (886, 9), (894, 13), (895, 1), (906, 24), (920, 7), (921, 2), (924, 10), (925, 16), (928, 14), (934, 6), (952, 34), (973, 24), (978, 6), (984, 17), (985, 33), (1006, 13), (1045, 12), (1090, 25), (1114, 15), (1128, 2), (1132, 28), (1133, 6), (1137, 19), (1139, 10), (1153, 53), (1159, 18), (1167, 10), (1173, 28), (1183, 37), (1219, 23), (1222, 6), (1232, 11), (1246, 17), (1263, 27), (1292, 2), (1310, 5), (1498, 3), (1525, 5)]
def cs229 : List ℕ := [19, 29, 39, 23, 19, 25, 0, 100, 33, 33, 31, 72, 99, 33, 21, 27, 100, 101, 88, 0, 100, 51, 43, 100, 99, 100, 99, 100, 5, 43, 100, 100, 60, 29, 99, 100, 98, 0, 74, 100, 99, 66, 48, 101, 100, 100, 100, 99, 86, 98, 100, 99, 69, 101, 40, 10, 100, 100, 99, 79, 100, 100, 88, 96, 99, 76, 99, 101, 100, 100, 99, 100, 100, 99, 67, 100, 0, 101, 100, 100, 99, 97, 58, 99, 44, 63, 72, 100, 99, 101, 99, 80, 99, 0, 100, 35, 101, 100, 101, 100, 148, 101, 98, 93, 44, 60, 234, 100, 99, 0, 101, 100, 99, 80, 100, 93, 99, 37, 100, 69, 99, 100, 142, 100, 100, 94, 24, 24, 86, 99, 90, 53, 99, 100, 98, 100, 52, 65, 100, 100, 100, 52, 101, 97, 163, 24, 100, 78, 100, 69, 82, 41, 95, 72]
theorem loads229 : cs229.get =
    load (fun i : Fin entries229.length => support (entries229.get i).1)
      (fun i => (entries229.get i).2) := by
  apply load_eq_of_sparse_packed base cs229 support code
    entries229 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node229 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 106 (insert 144 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs229 support demand
    entries229 ((insert 93 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 106 (insert 144 (insert 122 (insert 115 (insert 100 ∅))))) : Finset (Fin 154)) 100 30 loads229
  decide +kernel
def entries230 : List (Fin 1589 × ℕ) := [(30, 27), (77, 1), (177, 25), (179, 3), (273, 7), (335, 7), (385, 18), (421, 37), (466, 14), (472, 34), (507, 16), (515, 15), (527, 2), (531, 14), (542, 17), (551, 19), (552, 5), (570, 18), (583, 2), (616, 5), (617, 7), (639, 4), (681, 8), (731, 41), (737, 33), (743, 3), (815, 10), (844, 7), (856, 16), (863, 5), (864, 3), (869, 21), (870, 30), (882, 12), (894, 2), (895, 2), (906, 13), (920, 11), (923, 31), (925, 8), (930, 22), (934, 6), (949, 4), (952, 23), (955, 12), (973, 25), (978, 18), (984, 7), (985, 28), (1006, 13), (1009, 17), (1045, 34), (1056, 30), (1061, 12), (1104, 3), (1137, 3), (1171, 10), (1173, 16), (1183, 8), (1186, 25), (1188, 20), (1212, 4), (1219, 24), (1232, 27), (1258, 30), (1263, 24), (1275, 3), (1292, 3), (1335, 3), (1411, 2), (1498, 10), (1502, 7), (1580, 21)]
def cs230 : List ℕ := [21, 24, 34, 24, 21, 56, 0, 100, 51, 24, 19, 89, 100, 62, 39, 46, 100, 100, 101, 2, 101, 57, 28, 100, 100, 99, 101, 100, 1, 28, 100, 99, 72, 17, 100, 93, 100, 0, 61, 99, 100, 73, 39, 89, 99, 101, 66, 100, 91, 99, 100, 99, 49, 100, 32, 0, 101, 100, 101, 99, 100, 100, 81, 101, 99, 82, 99, 100, 99, 100, 99, 101, 101, 100, 56, 99, 23, 88, 100, 100, 100, 83, 73, 101, 74, 99, 50, 99, 101, 99, 98, 90, 99, 0, 30, 64, 100, 89, 101, 98, 113, 100, 99, 14, 40, 48, 8, 99, 99, 41, 100, 99, 89, 70, 83, 63, 99, 37, 99, 55, 71, 100, 114, 99, 100, 84, 32, 25, 31, 98, 100, 35, 99, 100, 99, 99, 51, 62, 100, 99, 100, 58, 100, 99, 70, 25, 93, 57, 100, 83, 70, 84, 87, 92]
theorem loads230 : cs230.get =
    load (fun i : Fin entries230.length => support (entries230.get i).1)
      (fun i => (entries230.get i).2) := by
  apply load_eq_of_sparse_packed base cs230 support code
    entries230 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node230 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 106 (insert 93 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 144 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs230 support demand
    entries230 ((insert 106 (insert 93 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 144 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)) 100 30 loads230
  decide +kernel
theorem node227 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 144 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 93 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 144 (insert 122 (insert 115 (insert 100 ∅)))) : Finset (Fin 154))
    106 node229 node230
def entries228 : List (Fin 1589 × ℕ) := [(30, 7), (77, 2), (122, 19), (177, 21), (179, 24), (273, 8), (385, 32), (421, 8), (472, 28), (479, 15), (485, 3), (496, 19), (506, 5), (507, 31), (515, 20), (527, 3), (531, 25), (542, 24), (551, 17), (570, 7), (583, 2), (616, 11), (617, 9), (625, 10), (680, 4), (731, 12), (737, 25), (741, 20), (743, 2), (777, 17), (800, 2), (819, 4), (842, 35), (844, 23), (847, 1), (856, 4), (869, 6), (870, 31), (882, 11), (886, 9), (894, 5), (895, 5), (906, 10), (920, 8), (925, 34), (930, 28), (934, 8), (938, 7), (949, 3), (952, 33), (973, 21), (978, 10), (984, 21), (985, 32), (1005, 9), (1006, 9), (1009, 7), (1045, 27), (1056, 14), (1070, 9), (1076, 11), (1102, 4), (1128, 7), (1169, 2), (1173, 22), (1177, 10), (1180, 17), (1188, 14), (1219, 30), (1228, 26), (1263, 8), (1269, 8), (1323, 27), (1335, 18), (1342, 10), (1359, 1), (1466, 12), (1471, 13), (1498, 9), (1580, 2)]
def cs228 : List ℕ := [23, 31, 29, 30, 17, 23, 0, 100, 34, 36, 22, 68, 100, 34, 28, 56, 100, 100, 101, 0, 100, 59, 45, 99, 100, 101, 100, 101, 31, 45, 100, 99, 90, 25, 100, 100, 100, 0, 89, 99, 99, 63, 46, 101, 100, 101, 99, 100, 100, 89, 100, 98, 58, 101, 30, 19, 100, 99, 100, 99, 100, 100, 78, 99, 100, 102, 100, 101, 100, 100, 99, 101, 101, 94, 41, 100, 24, 101, 100, 99, 100, 101, 66, 101, 64, 89, 66, 100, 101, 100, 100, 101, 101, 0, 88, 57, 100, 101, 101, 100, 132, 101, 100, 93, 50, 58, 101, 99, 101, 17, 101, 100, 101, 78, 101, 65, 101, 0, 100, 62, 100, 100, 127, 101, 91, 61, 31, 38, 58, 100, 53, 33, 101, 100, 66, 82, 53, 67, 93, 100, 101, 69, 100, 63, 0, 48, 99, 49, 100, 95, 73, 75, 47, 47]
theorem loads228 : cs228.get =
    load (fun i : Fin entries228.length => support (entries228.get i).1)
      (fun i => (entries228.get i).2) := by
  apply load_eq_of_sparse_packed base cs228 support code
    entries228 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node228 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 144 (insert 93 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 122 (insert 115 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs228 support demand
    entries228 ((insert 144 (insert 93 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))))) : Finset (Fin 154)) ((insert 122 (insert 115 (insert 100 ∅))) : Finset (Fin 154)) 100 30 loads228
  decide +kernel
theorem node226 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 122 (insert 115 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 93 (insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 122 (insert 115 (insert 100 ∅))) : Finset (Fin 154))
    144 node227 node228
theorem node224 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 122 (insert 115 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 55 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 122 (insert 115 (insert 100 ∅))) : Finset (Fin 154))
    93 node225 node226
theorem node217 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 122 (insert 115 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 122 (insert 115 (insert 100 ∅))) : Finset (Fin 154))
    55 node223 node224
def entries221 : List (Fin 1589 × ℕ) := [(35, 20), (37, 2), (62, 13), (70, 16), (119, 2), (120, 32), (273, 10), (387, 15), (420, 14), (466, 9), (472, 19), (479, 2), (496, 33), (507, 34), (527, 9), (550, 5), (552, 8), (570, 3), (617, 32), (673, 3), (730, 3), (731, 40), (737, 15), (738, 7), (740, 1), (763, 10), (799, 31), (813, 15), (843, 13), (868, 11), (869, 4), (870, 20), (886, 4), (893, 2), (894, 30), (896, 5), (905, 4), (906, 12), (922, 27), (925, 32), (927, 6), (928, 13), (929, 21), (932, 4), (940, 42), (948, 19), (949, 5), (950, 12), (967, 16), (973, 15), (978, 61), (985, 6), (1006, 24), (1030, 22), (1061, 18), (1070, 40), (1082, 8), (1090, 1), (1104, 3), (1111, 16), (1138, 7), (1148, 7), (1149, 3), (1152, 19), (1153, 18), (1160, 3), (1172, 5), (1182, 33), (1217, 16), (1219, 15), (1233, 40), (1234, 8), (1236, 10), (1258, 1), (1267, 13), (1280, 2), (1292, 5), (1293, 32), (1393, 1), (1496, 19), (1580, 12)]
def cs221 : List ℕ := [37, 17, 35, 15, 24, 55, 0, 85, 55, 47, 51, 76, 99, 45, 28, 48, 99, 100, 82, 15, 99, 99, 0, 99, 100, 99, 100, 99, 46, 36, 99, 100, 100, 0, 99, 91, 98, 0, 95, 100, 99, 100, 9, 100, 100, 100, 99, 99, 51, 99, 99, 100, 39, 100, 9, 100, 99, 99, 100, 100, 100, 100, 49, 99, 68, 96, 101, 99, 100, 100, 100, 100, 99, 99, 29, 100, 0, 99, 265, 100, 99, 100, 100, 100, 51, 100, 55, 99, 99, 100, 100, 100, 100, 228, 45, 30, 100, 99, 100, 100, 180, 99, 99, 100, 75, 75, 100, 86, 101, 16, 100, 100, 84, 95, 100, 201, 101, 33, 100, 40, 100, 100, 0, 100, 100, 54, 15, 15, 58, 94, 99, 49, 100, 99, 70, 77, 18, 27, 99, 100, 66, 58, 100, 74, 100, 15, 99, 84, 99, 18, 88, 34, 67, 58]
theorem loads221 : cs221.get =
    load (fun i : Fin entries221.length => support (entries221.get i).1)
      (fun i => (entries221.get i).2) := by
  apply load_eq_of_sparse_packed base cs221 support code
    entries221 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node221 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 122 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 78 (insert 93 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs221 support demand
    entries221 ((insert 122 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 78 (insert 93 (insert 115 (insert 100 ∅)))) : Finset (Fin 154)) 100 30 loads221
  decide +kernel
def entries222 : List (Fin 1589 × ℕ) := [(37, 5), (46, 62), (70, 175), (122, 245), (179, 192), (387, 450), (399, 10), (430, 173), (466, 236), (472, 18), (479, 183), (507, 330), (515, 7), (531, 108), (551, 163), (583, 131), (617, 347), (673, 91), (737, 266), (819, 52), (843, 74), (844, 66), (847, 24), (869, 34), (870, 142), (872, 153), (882, 108), (886, 150), (896, 77), (906, 261), (922, 254), (924, 157), (925, 252), (927, 148), (940, 415), (951, 224), (967, 87), (973, 112), (978, 484), (985, 46), (1006, 239), (1009, 52), (1020, 81), (1030, 82), (1041, 32), (1049, 79), (1056, 10), (1061, 195), (1070, 47), (1090, 14), (1099, 332), (1104, 133), (1111, 24), (1138, 40), (1139, 133), (1149, 225), (1152, 36), (1153, 217), (1167, 165), (1182, 201), (1217, 229), (1219, 46), (1222, 87), (1233, 431), (1234, 359), (1258, 83), (1263, 108), (1267, 105), (1272, 31), (1280, 9), (1292, 218), (1293, 292), (1298, 73), (1559, 203), (1580, 101)]
def cs222 : List ℕ := [540, 142, 358, 46, 284, 548, 62, 999, 113, 330, 400, 783, 999, 362, 338, 516, 1000, 999, 1000, 5, 999, 903, 192, 999, 999, 1000, 1000, 1000, 553, 429, 999, 999, 739, 231, 1000, 1000, 1000, 0, 704, 999, 936, 907, 170, 1000, 1000, 999, 999, 1000, 999, 1000, 1000, 1000, 829, 1000, 87, 1000, 999, 1000, 1000, 912, 1001, 1000, 707, 1000, 837, 741, 1000, 999, 1000, 1000, 1001, 1000, 613, 999, 456, 1001, 0, 894, 349, 1000, 1000, 1001, 850, 1000, 754, 1000, 438, 1001, 999, 1000, 1002, 837, 907, 2799, 627, 430, 999, 1000, 1000, 1002, 1676, 1000, 833, 1001, 564, 999, 1001, 925, 1000, 87, 1000, 1001, 1000, 932, 999, 1792, 1001, 201, 1001, 327, 673, 832, 0, 1001, 1001, 793, 112, 191, 507, 954, 1001, 359, 1000, 1000, 628, 659, 337, 277, 1000, 1001, 597, 795, 1000, 643, 1000, 112, 1001, 746, 1000, 337, 877, 148, 613, 543]
theorem loads222 : cs222.get =
    load (fun i : Fin entries222.length => support (entries222.get i).1)
      (fun i => (entries222.get i).2) := by
  apply load_eq_of_sparse_packed base cs222 support code
    entries222 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node222 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 78 (insert 122 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 115 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs222 support demand
    entries222 ((insert 78 (insert 122 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 93 (insert 115 (insert 100 ∅))) : Finset (Fin 154)) 1000 30 loads222
  decide +kernel
theorem node219 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 122 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 93 (insert 115 (insert 100 ∅))) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 122 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 93 (insert 115 (insert 100 ∅))) : Finset (Fin 154))
    78 node221 node222
def entries220 : List (Fin 1589 × ℕ) := [(30, 8), (70, 42), (72, 254), (122, 313), (179, 29), (344, 156), (399, 249), (430, 49), (466, 101), (472, 108), (479, 60), (496, 98), (507, 178), (531, 146), (542, 10), (551, 244), (552, 29), (583, 102), (616, 79), (617, 190), (640, 20), (731, 273), (737, 268), (741, 52), (815, 25), (817, 25), (819, 50), (843, 242), (856, 131), (863, 42), (869, 24), (870, 223), (872, 85), (882, 136), (886, 121), (894, 178), (906, 187), (920, 206), (921, 48), (925, 342), (929, 99), (930, 54), (932, 14), (938, 295), (939, 64), (950, 26), (966, 161), (973, 269), (978, 421), (985, 145), (1005, 38), (1006, 149), (1030, 101), (1061, 127), (1070, 201), (1082, 28), (1086, 48), (1099, 102), (1100, 38), (1104, 96), (1111, 234), (1138, 51), (1149, 93), (1153, 377), (1160, 35), (1167, 161), (1173, 2), (1177, 2), (1182, 342), (1217, 141), (1219, 171), (1233, 228), (1236, 95), (1268, 18), (1292, 158), (1310, 81), (1342, 156), (1359, 104), (1466, 152), (1469, 148), (1489, 98), (1580, 219), (1588, 5)]
def cs220 : List ℕ := [337, 275, 249, 171, 374, 533, 0, 999, 106, 220, 454, 859, 999, 476, 525, 722, 999, 1000, 1000, 18, 999, 643, 29, 999, 999, 1000, 999, 1001, 796, 71, 1000, 1000, 520, 161, 1000, 999, 999, 0, 690, 1000, 999, 784, 467, 1000, 1000, 1000, 1000, 1000, 1000, 999, 1000, 1000, 112, 1000, 16, 999, 1000, 1001, 1001, 989, 1000, 1000, 441, 1000, 788, 986, 1000, 1000, 1000, 1000, 1001, 1001, 795, 1000, 416, 999, 2, 1000, 1002, 999, 1000, 1001, 752, 1000, 785, 999, 453, 1000, 1001, 1000, 1001, 1000, 778, 0, 593, 641, 1000, 1001, 1001, 1000, 941, 1000, 1001, 1001, 395, 1000, 1000, 1000, 1000, 0, 1000, 999, 894, 990, 1000, 1024, 1001, 503, 999, 468, 1001, 1001, 4, 1000, 1001, 674, 271, 269, 491, 707, 1000, 533, 1000, 1001, 561, 656, 366, 430, 1001, 999, 678, 667, 1000, 856, 1001, 271, 1000, 892, 988, 364, 839, 271, 988, 532]
theorem loads220 : cs220.get =
    load (fun i : Fin entries220.length => support (entries220.get i).1)
      (fun i => (entries220.get i).2) := by
  apply load_eq_of_sparse_packed base cs220 support code
    entries220 code_correct
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
theorem node220 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 93 (insert 122 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 115 (insert 100 ∅)) : Finset (Fin 154)), holes i = 0) := by
  apply sparse_list_conditioned_excludes cs220 support demand
    entries220 ((insert 93 (insert 122 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))))) : Finset (Fin 154)) ((insert 115 (insert 100 ∅)) : Finset (Fin 154)) 1000 30 loads220
  decide +kernel
theorem node218 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 122 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 115 (insert 100 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 122 (insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅)))))))))) : Finset (Fin 154)) ((insert 115 (insert 100 ∅)) : Finset (Fin 154))
    93 node219 node220
theorem node216 :
    ¬ ∃ holes : Fin 154 → ℕ, (∀ i, holes i ≤ 1) ∧
      (∀ r, demand r ≤ ∑ i ∈ support r, holes i) ∧
      (∑ i, holes i) ≤ 30 ∧
      (∀ i ∈ ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)), holes i = 1) ∧
      (∀ i ∈ ((insert 115 (insert 100 ∅)) : Finset (Fin 154)), holes i = 0) := by
  exact split_excludes support demand 30 ((insert 37 (insert 127 (insert 126 (insert 119 (insert 76 (insert 33 (insert 109 (insert 54 (insert 117 ∅))))))))) : Finset (Fin 154)) ((insert 115 (insert 100 ∅)) : Finset (Fin 154))
    122 node217 node218
#print axioms node216
end OmissionResidualCover
